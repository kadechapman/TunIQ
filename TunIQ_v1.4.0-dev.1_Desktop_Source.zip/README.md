# TunIQ v1.4.0-dev.1

Built directly on `v1.3.0-dev.2`. Existing profiles, Garage vehicles, projects, BINs, XDFs, revisions, tool paths, and settings remain in `%APPDATA%\TunIQ`.

## First TunIQ 1.4 milestone

### Full AI Tuner foundation

- Added a dedicated Full AI Tuner page.
- Saves the complete vehicle build and tune goal inside the active project.
- Collects engine, transmission, fuel, aspiration, driving use, modifications, symptoms, injector information, gearing, tire size, converter, desired idle, and notes.
- Shows camshaft fields only for an actual aftermarket-cam build or camshaft tune.
- Ghost-cam goals receive an idle strategy without requiring a physical cam card.
- Requires intake duration, exhaust duration, and LSA for a real camshaft tune.
- Generates a dynamic project-specific diagnostic and tuning plan.
- Adds cam, boost, transmission, fuel-system, airflow, spark, validation, revision, flash-confirmation, and post-flash steps only when applicable.
- Adds the Full AI intake to Guided Tune Path when Full AI mode is active.
- Saves `AI\intake.json` and `AI\plan.json` in the active project.

This build creates and explains the plan. It does not autonomously edit calibration bytes or write a controller.

### Local Tune Library

- Added a Saved Tunes page.
- Saves the active project's latest revision, or original BIN when no revision exists, into `%APPDATA%\TunIQ\TuneLibrary`.
- Stores engine, transmission, controller, OS, fuel, tune goal, modifications, tags, description, fingerprint, and source project.
- Search and filter by tune details.
- Favorite and delete tunes.
- Export and import `.tuniqtune` packages.
- Import a saved tune into the active project as a new revision.
- Blocks controller and operating-system mismatches.
- Never replaces the protected original BIN.

### Community Hub foundation

- Added Problems & Help, Community Tunes, Guide, and Builds & Results categories.
- Search and filter by engine, transmission, controller, category, body text, and tags.
- Create local draft posts.
- Optionally attach active project context.
- Includes official local safety and posting guides.
- Stores local posts in `%APPDATA%\TunIQ\Community`.

Online accounts, hosting, moderation, ratings, comments, cloud tune downloads, and public posting are not enabled in this development build.

## Safety status

- Original BINs remain protected.
- Library tunes are copied into Revisions only after compatibility checks.
- Full AI controller writing is not enabled.
- All future flash operations will continue to require deliberate user confirmation.
