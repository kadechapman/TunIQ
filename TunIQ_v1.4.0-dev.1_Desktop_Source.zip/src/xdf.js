const fs = require('fs');
const path = require('path');

const MAX_AXIS = 256;
const MAX_TABLE_CELLS = 65536;
const MAX_DEFINITIONS = 5000;

function decodeXml(value = '') {
  return String(value)
    .replace(/&#x([0-9a-f]+);/gi, (_match, hex) => String.fromCodePoint(parseInt(hex, 16)))
    .replace(/&#(\d+);/g, (_match, decimal) => String.fromCodePoint(parseInt(decimal, 10)))
    .replace(/&quot;/gi, '"')
    .replace(/&apos;/gi, "'")
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&amp;/gi, '&');
}

function attrs(source = '') {
  const result = {};
  for (const match of source.matchAll(/([\w:-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)) {
    result[match[1].toLowerCase()] = decodeXml(match[2] ?? match[3] ?? '');
  }
  return result;
}

function num(value, fallback = 0) {
  if (value == null || value === '') return fallback;
  const text = decodeXml(String(value)).trim();
  if (/^[-+]?0x/i.test(text)) return parseInt(text, 16);
  const parsed = Number(text);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function positiveInt(value, fallback = 1, max = MAX_AXIS) {
  const parsed = Math.floor(num(value, fallback));
  if (!Number.isFinite(parsed) || parsed < 1) return fallback;
  return Math.min(parsed, max);
}

function text(block, tag) {
  const match = block.match(new RegExp(`<${tag}[^>]*>([\\s\\S]*?)<\\/${tag}>`, 'i'));
  return match ? decodeXml(match[1].replace(/<[^>]+>/g, '').trim()) : '';
}

function tagAttrs(block, tag) {
  const match = block.match(new RegExp(`<${tag}\\b([^>]*)>`, 'i'));
  return match ? attrs(match[1]) : {};
}

function allTagAttrs(block, tag) {
  return [...block.matchAll(new RegExp(`<${tag}\\b([^>]*)>`, 'gi'))].map(match => attrs(match[1]));
}

function axisBlock(block, id) {
  for (const match of block.matchAll(/<XDFAXIS\b([^>]*)>([\s\S]*?)<\/XDFAXIS>/gi)) {
    const axisAttributes = attrs(match[1]);
    if (String(axisAttributes.id || '').toLowerCase() === id.toLowerCase()) {
      return { attrs: axisAttributes, body: match[2] };
    }
  }
  return null;
}

function equation(block) {
  const match = block.match(/<MATH\b([^>]*)>/i);
  return match ? decodeXml(attrs(match[1]).equation || 'X').trim() : 'X';
}

function equationIsSafe(eq) {
  return Boolean(eq) && /^[Xx0-9+\-*/().\s%]+$/.test(eq);
}

function evalEquation(eq, x) {
  if (!eq || /^X$/i.test(eq.trim())) return x;
  if (!equationIsSafe(eq)) return x;
  try {
    const result = Function('X', `"use strict";return (${eq.replace(/x/g, 'X')})`)(x);
    return Number.isFinite(Number(result)) ? Number(result) : x;
  } catch {
    return x;
  }
}

function rawRange(bits, signed) {
  if (signed) return [-(2 ** (bits - 1)), (2 ** (bits - 1)) - 1];
  return [0, bits === 32 ? 0xFFFFFFFF : (2 ** bits) - 1];
}

function inverseEquation(eq, y, bits, signed) {
  const target = Number(y);
  if (!Number.isFinite(target)) throw new Error('Calibration value is not numeric.');
  if (!eq || /^X$/i.test(eq.trim())) return target;
  if (!equationIsSafe(eq)) throw new Error(`Unsupported XDF equation: ${eq}`);

  const f0 = evalEquation(eq, 0);
  const f1 = evalEquation(eq, 1);
  const slope = f1 - f0;
  const check = evalEquation(eq, 10);
  if (Number.isFinite(slope) && Math.abs(slope) > 1e-12 && Math.abs(check - (f0 + slope * 10)) < 1e-7 * Math.max(1, Math.abs(check))) {
    return (target - f0) / slope;
  }

  let [low, high] = rawRange(bits, signed);
  let lowValue = evalEquation(eq, low);
  let highValue = evalEquation(eq, high);
  if (!Number.isFinite(lowValue) || !Number.isFinite(highValue) || lowValue === highValue) {
    throw new Error(`TunIQ cannot safely invert XDF equation: ${eq}`);
  }
  const increasing = highValue > lowValue;
  const minValue = Math.min(lowValue, highValue);
  const maxValue = Math.max(lowValue, highValue);
  if (target < minValue || target > maxValue) throw new Error(`Value ${target} is outside the invertible range for equation ${eq}.`);

  for (let iteration = 0; iteration < 64 && high - low > 1; iteration += 1) {
    const middle = Math.floor((low + high) / 2);
    const middleValue = evalEquation(eq, middle);
    if (!Number.isFinite(middleValue)) throw new Error(`TunIQ cannot safely invert XDF equation: ${eq}`);
    if ((increasing && middleValue < target) || (!increasing && middleValue > target)) low = middle;
    else high = middle;
  }
  const candidates = [low, high];
  return candidates.sort((a, b) => Math.abs(evalEquation(eq, a) - target) - Math.abs(evalEquation(eq, b) - target))[0];
}

function parseAxis(block, id, fallbackCount, warnings) {
  const chosen = axisBlock(block, id);
  const safeFallback = positiveInt(fallbackCount, 1);
  if (!chosen) return { count: safeFallback, labels: Array.from({ length: safeFallback }, (_, index) => String(index)) };

  const requested = Math.floor(num(text(chosen.body, 'indexcount') || chosen.attrs.indexcount || chosen.attrs.count, safeFallback));
  const count = positiveInt(requested, safeFallback);
  if (requested > MAX_AXIS) warnings.push(`Axis ${id} was limited from ${requested} to ${MAX_AXIS} cells.`);

  const indexedLabels = allTagAttrs(chosen.body, 'LABEL')
    .map((item, order) => ({ index: Math.max(0, Math.floor(num(item.index, order))), value: item.value ?? item.label }))
    .filter(item => item.value != null)
    .sort((a, b) => a.index - b.index);
  const labels = Array.from({ length: count }, (_, index) => String(index));
  for (const item of indexedLabels) if (item.index < count) labels[item.index] = String(item.value);
  return { count, labels };
}

function normalizeDefinition(definition, warnings) {
  let rows = positiveInt(definition.rows, 1);
  let cols = positiveInt(definition.cols, 1);
  if (rows * cols > MAX_TABLE_CELLS) {
    const limitedCols = Math.max(1, Math.floor(MAX_TABLE_CELLS / rows));
    warnings.push(`${definition.name} was limited from ${rows * cols} to ${rows * limitedCols} cells.`);
    cols = limitedCols;
  }

  const elementBits = [8, 16, 32].includes(Number(definition.elementBits)) ? Number(definition.elementBits) : 8;
  const bytes = elementBits / 8;
  const majorStride = Math.max(0, Number(definition.majorStride) || 0);
  const minorStride = Math.max(0, Number(definition.minorStride) || 0);
  const columnMajor = Boolean(definition.columnMajor);
  const rowStride = columnMajor ? (minorStride || bytes) : (majorStride || cols * bytes);
  const colStride = columnMajor ? (majorStride || rows * bytes) : (minorStride || bytes);
  const unsupportedReason = definition.float ? '32-bit floating-point XDF data is not writable in this build.' : null;
  if (unsupportedReason) warnings.push(`${definition.name}: ${unsupportedReason}`);
  if (!equationIsSafe(definition.equation || 'X')) warnings.push(`${definition.name}: unsupported equation will display raw values and cannot be written safely.`);

  return {
    ...definition,
    address: Math.max(0, Math.floor(Number(definition.address) || 0)),
    elementBits,
    rows,
    cols,
    rowHeaders: (definition.rowHeaders || []).slice(0, rows),
    colHeaders: (definition.colHeaders || []).slice(0, cols),
    rowStride,
    colStride,
    columnMajor,
    unsupportedReason
  };
}

function dataSettings(embedded, defaults) {
  const flags = Math.max(0, Math.floor(num(embedded.mmedtypeflags, 0)));
  const explicitSigned = embedded.signed;
  const signed = explicitSigned != null ? num(explicitSigned, 0) === 1 : Boolean(flags & 0x01) || defaults.signed;
  let littleEndian = defaults.littleEndian;
  if (flags & 0x02) littleEndian = false;
  return {
    flags,
    signed,
    littleEndian,
    columnMajor: Boolean(flags & 0x04),
    float: defaults.float || num(embedded.float, 0) === 1
  };
}

function parseXdf(file) {
  const xml = fs.readFileSync(file, 'utf8');
  const tables = [];
  const warnings = [];
  const defaultAttributes = tagAttrs(xml, 'DEFAULTS');
  const defaults = {
    elementBits: num(defaultAttributes.datasizeinbits, 8),
    signed: num(defaultAttributes.signed, 0) === 1,
    littleEndian: defaultAttributes.lsbfirst == null ? true : num(defaultAttributes.lsbfirst, 1) === 1,
    float: num(defaultAttributes.float, 0) === 1
  };
  const baseOffset = num(text(xml, 'baseoffset'), 0);

  for (const match of xml.matchAll(/<XDFTABLE\b([^>]*)>([\s\S]*?)<\/XDFTABLE>/gi)) {
    if (tables.length >= MAX_DEFINITIONS) {
      warnings.push(`Definition import stopped at ${MAX_DEFINITIONS} items.`);
      break;
    }
    const tableAttributes = attrs(match[1]);
    const body = match[2];
    const z = axisBlock(body, 'z');
    const dataBody = z?.body || body;
    const embedded = tagAttrs(dataBody, 'EMBEDDEDDATA');
    const x = parseAxis(body, 'x', num(embedded.mmedcolcount || embedded.colcount, 1), warnings);
    const y = parseAxis(body, 'y', num(embedded.mmedrowcount || embedded.rowcount, 1), warnings);
    const settings = dataSettings(embedded, defaults);
    const math = equation(dataBody);
    tables.push(normalizeDefinition({
      id: tableAttributes.uniqueid || tableAttributes.id || `table-${tables.length}`,
      type: 'table',
      name: tableAttributes.title || text(body, 'title') || `Table ${tables.length + 1}`,
      description: text(body, 'description'),
      address: baseOffset + num(embedded.mmedaddress || embedded.address),
      elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, defaults.elementBits),
      majorStride: num(embedded.mmedmajorstridebits || embedded.mmedrowstridebits, 0) / 8,
      minorStride: num(embedded.mmedminorstridebits || embedded.mmedcolstridebits, 0) / 8,
      rows: num(embedded.mmedrowcount || embedded.rowcount, y.count),
      cols: num(embedded.mmedcolcount || embedded.colcount, x.count),
      rowHeaders: y.labels,
      colHeaders: x.labels,
      equation: math,
      equationSupported: equationIsSafe(math),
      unit: text(dataBody, 'units') || tagAttrs(dataBody, 'MATH').units || '',
      min: text(dataBody, 'min') === '' ? null : num(text(dataBody, 'min')),
      max: text(dataBody, 'max') === '' ? null : num(text(dataBody, 'max')),
      ...settings
    }, warnings));
  }

  if (tables.length < MAX_DEFINITIONS) {
    for (const match of xml.matchAll(/<XDFCONSTANT\b([^>]*)>([\s\S]*?)<\/XDFCONSTANT>/gi)) {
      if (tables.length >= MAX_DEFINITIONS) {
        warnings.push(`Definition import stopped at ${MAX_DEFINITIONS} items.`);
        break;
      }
      const constantAttributes = attrs(match[1]);
      const body = match[2];
      const embedded = tagAttrs(body, 'EMBEDDEDDATA');
      const settings = dataSettings(embedded, defaults);
      const math = equation(body);
      tables.push(normalizeDefinition({
        id: constantAttributes.uniqueid || constantAttributes.id || `constant-${tables.length}`,
        type: 'constant',
        name: constantAttributes.title || text(body, 'title') || `Constant ${tables.length + 1}`,
        description: text(body, 'description'),
        address: baseOffset + num(embedded.mmedaddress || embedded.address),
        elementBits: num(embedded.mmedelementsizebits || embedded.elementsizebits, defaults.elementBits),
        rows: 1,
        cols: 1,
        rowHeaders: ['Value'],
        colHeaders: ['Value'],
        equation: math,
        equationSupported: equationIsSafe(math),
        unit: text(body, 'units') || tagAttrs(body, 'MATH').units || '',
        min: text(body, 'min') === '' ? null : num(text(body, 'min')),
        max: text(body, 'max') === '' ? null : num(text(body, 'max')),
        ...settings
      }, warnings));
    }
  }

  return {
    title: text(xml, 'deftitle') || tagAttrs(xml, 'XDFHEADER').deftitle || path.basename(file),
    baseOffset,
    tables,
    warnings
  };
}

function readRaw(buffer, offset, bits, signed = false, littleEndian = true) {
  const bytes = bits / 8;
  if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) return 0;
  if (bits === 8) return signed ? buffer.readInt8(offset) : buffer.readUInt8(offset);
  if (bits === 16) return signed ? (littleEndian ? buffer.readInt16LE(offset) : buffer.readInt16BE(offset)) : (littleEndian ? buffer.readUInt16LE(offset) : buffer.readUInt16BE(offset));
  if (bits === 32) return signed ? (littleEndian ? buffer.readInt32LE(offset) : buffer.readInt32BE(offset)) : (littleEndian ? buffer.readUInt32LE(offset) : buffer.readUInt32BE(offset));
  return buffer.readUInt8(offset);
}

function writeRaw(buffer, offset, bits, value, signed = false, littleEndian = true) {
  value = Math.round(Number(value));
  const bytes = bits / 8;
  if (!Number.isInteger(offset) || offset < 0 || offset + bytes > buffer.length) {
    throw new Error(`Address 0x${Math.max(0, Number(offset) || 0).toString(16)} is outside BIN`);
  }
  if (bits === 8) return signed ? buffer.writeInt8(Math.max(-128, Math.min(127, value)), offset) : buffer.writeUInt8(Math.max(0, Math.min(255, value)), offset);
  if (bits === 16) {
    if (signed) return littleEndian ? buffer.writeInt16LE(Math.max(-32768, Math.min(32767, value)), offset) : buffer.writeInt16BE(Math.max(-32768, Math.min(32767, value)), offset);
    return littleEndian ? buffer.writeUInt16LE(Math.max(0, Math.min(65535, value)), offset) : buffer.writeUInt16BE(Math.max(0, Math.min(65535, value)), offset);
  }
  if (bits === 32) {
    if (signed) return littleEndian ? buffer.writeInt32LE(Math.max(-2147483648, Math.min(2147483647, value)), offset) : buffer.writeInt32BE(Math.max(-2147483648, Math.min(2147483647, value)), offset);
    const clamped = Math.max(0, Math.min(4294967295, value));
    return littleEndian ? buffer.writeUInt32LE(clamped, offset) : buffer.writeUInt32BE(clamped, offset);
  }
  return buffer.writeUInt8(value & 255, offset);
}

function hydrate(definition, bin) {
  const rows = positiveInt(definition.rows, 1);
  const cols = positiveInt(definition.cols, 1);
  const values = Array.from({ length: rows }, (_, row) => Array.from({ length: cols }, (_, col) => {
    const offset = definition.address + definition.rowStride * row + definition.colStride * col;
    const raw = readRaw(bin, offset, definition.elementBits, definition.signed, definition.littleEndian);
    return Number(evalEquation(definition.equation, raw).toFixed(6));
  }));
  return { ...definition, rows, cols, values };
}

function applyTable(buffer, table, changedCells = null) {
  if (!table || !Array.isArray(table.values)) return;
  if (table.unsupportedReason) throw new Error(`${table.name}: ${table.unsupportedReason}`);
  const rows = Math.min(positiveInt(table.rows, table.values.length), table.values.length);
  const cols = Math.min(positiveInt(table.cols, table.values[0]?.length || 1), table.values[0]?.length || 1);
  for (let row = 0; row < rows; row += 1) {
    for (let col = 0; col < cols; col += 1) {
      if (changedCells && !changedCells.has(`${row}:${col}`)) continue;
      const offset = table.address + table.rowStride * row + table.colStride * col;
      const raw = inverseEquation(table.equation, Number(table.values[row][col]), table.elementBits, table.signed);
      writeRaw(buffer, offset, table.elementBits, raw, table.signed, table.littleEndian);
    }
  }
}

module.exports = { parseXdf, hydrate, applyTable, evalEquation, inverseEquation };
