const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const crypto = require('crypto');
const { parseXdf, hydrate, applyTable } = require('./xdf');

const APP_VERSION = '1.4.0-dev.1';
const RUNTIME_ROOT = path.join(app.getPath('appData'), 'TunIQ', 'Runtime');
try { app.setPath('userData', RUNTIME_ROOT); } catch {}
let mainWindow;
let recoveryWindowAttempts = 0;

function dataRoot() {
  return path.join(app.getPath('appData'), 'TunIQ');
}
function startupLogFile() { return path.join(dataRoot(), 'Logs', 'startup.log'); }
function logStartup(stage, details = '') {
  try {
    fs.mkdirSync(path.join(dataRoot(), 'Logs'), { recursive: true });
    const extra = details ? ` | ${String(details).replace(/\r?\n/g, ' ')}` : '';
    fs.appendFileSync(startupLogFile(), `[${new Date().toISOString()}] ${stage}${extra}\n`, 'utf8');
  } catch {}
}
function legacyDataRoot() {
  return path.join(app.getPath('documents'), 'TunIQ');
}
function copyMissing(source, destination, depth = 0) {
  if (depth > 20 || !fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) continue;
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    try {
      if (entry.isDirectory()) copyMissing(from, to, depth + 1);
      else if (entry.isFile() && !fs.existsSync(to)) fs.copyFileSync(from, to);
    } catch (error) {
      logStartup('migration:item-skipped', `${from}: ${error.message}`);
    }
  }
}
function migrateLegacyData() {
  const marker = path.join(dataRoot(), 'Settings', 'appdata-migration.json');
  if (fs.existsSync(marker)) return readJson(marker, { migrated: false });
  const legacy = legacyDataRoot();
  let result = { migrated: false, source: legacy, destination: dataRoot(), at: new Date().toISOString() };
  try {
    if (fs.existsSync(legacy) && path.resolve(legacy) !== path.resolve(dataRoot())) {
      copyMissing(legacy, dataRoot());
      result.migrated = true;
    }
  } catch (error) { result.error = error.message; }
  writeJson(marker, result);
  return result;
}
function ensureDataFolders() {
  const folders = ['Profile','Vehicles','Projects','Logs','AI','Settings','Backups','Tools','Calibration','Definitions','TuneLibrary','Community'];
  fs.mkdirSync(dataRoot(), { recursive: true });
  for (const folder of folders) fs.mkdirSync(path.join(dataRoot(), folder), { recursive: true });
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function profileFile() { return path.join(dataRoot(), 'Profile', 'profile.json'); }
function settingsFile() { return path.join(dataRoot(), 'Settings', 'settings.json'); }
function toolsFile() { return path.join(dataRoot(), 'Tools', 'paths.json'); }
function vehiclesFile() { return path.join(dataRoot(), 'Vehicles', 'vehicles.json'); }
function activityFile() { return path.join(dataRoot(), 'Logs', 'activity.json'); }
function activeProjectFile() { return path.join(dataRoot(), 'Settings', 'active-project.json'); }
function appendActivity(type, details = {}) {
  const raw = readJson(activityFile(), []);
  const items = Array.isArray(raw) ? raw : [];
  items.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, type, details, at: new Date().toISOString() });
  writeJson(activityFile(), items.slice(0, 250));
}
function listVehicles() { const value = readJson(vehiclesFile(), []); return Array.isArray(value) ? value : []; }
function normalizeVehicle(payload, existing = {}) {
  const name = String(payload.name || '').trim();
  if (!name) throw new Error('Vehicle name is required.');
  return { ...existing, id: existing.id || `${Date.now()}-${name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}`, name, year: String(payload.year || '').trim(), make: String(payload.make || '').trim(), model: String(payload.model || '').trim(), engine: String(payload.engine || '').trim(), controller: String(payload.controller || '').trim(), vin: String(payload.vin || '').trim(), notes: String(payload.notes || '').trim(), updatedAt: new Date().toISOString(), createdAt: existing.createdAt || new Date().toISOString() };
}

function logCrash(label, error) {
  try {
    fs.mkdirSync(path.join(dataRoot(), 'Logs'), { recursive: true });
    const line = `[${new Date().toISOString()}] ${label}\n${error?.stack || error || 'Unknown error'}\n\n`;
    fs.appendFileSync(path.join(dataRoot(), 'Logs', 'desktop-crash.log'), line, 'utf8');
    logStartup(`ERROR:${label}`, error?.message || error || 'Unknown error');
  } catch {}
}
process.on('uncaughtException', error => logCrash('uncaughtException', error));
process.on('unhandledRejection', error => logCrash('unhandledRejection', error));

function createWindow() {
  logStartup('createWindow:start');
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#111714',
    show: false,
    title: `TunIQ ${APP_VERSION}`,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });

  let shown = false;
  const showWindow = () => {
    if (!shown && mainWindow && !mainWindow.isDestroyed()) {
      shown = true;
      mainWindow.show();
      logStartup('window:shown');
    }
  };

  mainWindow.once('ready-to-show', showWindow);
  const showFallback = setTimeout(showWindow, 3500);
  mainWindow.on('closed', () => {
    clearTimeout(showFallback);
    mainWindow = null;
    logStartup('window:closed');
  });
  mainWindow.webContents.on('did-finish-load', () => logStartup('renderer:did-finish-load'));
  mainWindow.webContents.on('preload-error', (_event, preloadPath, error) => logCrash(`preload-error:${preloadPath}`, error));
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    logCrash('render-process-gone', JSON.stringify(details));
    if (recoveryWindowAttempts < 1 && !app.isQuitting) {
      recoveryWindowAttempts += 1;
      setTimeout(() => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
      }, 500);
    }
  });
  mainWindow.webContents.on('did-fail-load', (_event, code, description, url) => logCrash('did-fail-load', `${code} ${description} ${url}`));
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html')).catch(error => {
    logCrash('loadFile', error);
    showWindow();
  });
}

function isExecutableFile(file) {
  try {
    return Boolean(file) && path.extname(file).toLowerCase() === '.exe' && fs.statSync(file).isFile();
  } catch {
    return false;
  }
}

const TOOL_DEFINITIONS = {
  pcmHammer: {
    names: ['pcmhammer.exe'],
    folders: ['PCM Hammer', 'PcmHammer', 'PCMhammer_2.0.0_Portable', 'PCMhammer']
  },
  tunerPro: {
    names: ['tunerpro.exe'],
    folders: ['TunerPro', 'TunerPro RT']
  },
  universalPatcher: {
    names: ['universalpatcher.exe', 'universal patcher.exe'],
    folders: ['Universal Patcher', 'UniversalPatcher', 'UniversalPatcher-Full']
  }
};

function firstExecutable(candidates) {
  for (const candidate of candidates) {
    if (isExecutableFile(candidate)) return path.resolve(candidate);
  }
  return null;
}

function findExecutableRecursive(root, names, maxDepth = 4, maxEntries = 12000) {
  if (!root || !fs.existsSync(root)) return null;
  const targets = new Set(names.map(name => name.toLowerCase()));
  const queue = [{ folder: root, depth: 0 }];
  let visited = 0;
  const skip = new Set(['node_modules', '.git', '$recycle.bin', 'windows', 'winsxs', 'appdata']);
  while (queue.length && visited < maxEntries) {
    const current = queue.shift();
    let entries;
    try { entries = fs.readdirSync(current.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      visited += 1;
      if (visited >= maxEntries) break;
      const full = path.join(current.folder, entry.name);
      if (entry.isFile() && targets.has(entry.name.toLowerCase()) && isExecutableFile(full)) return path.resolve(full);
      if (entry.isDirectory() && current.depth < maxDepth && !skip.has(entry.name.toLowerCase())) {
        queue.push({ folder: full, depth: current.depth + 1 });
      }
    }
  }
  return null;
}

function commonToolCandidates(key) {
  const definition = TOOL_DEFINITIONS[key];
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const local = process.env.LOCALAPPDATA || '';
  const desktop = app.getPath('desktop');
  const downloads = app.getPath('downloads');
  const roots = [pf, pfx86, local, desktop, downloads];
  const candidates = [];
  for (const root of roots) {
    for (const folder of definition.folders) {
      for (const name of definition.names) {
        candidates.push(path.join(root, folder, name));
        for (const nested of definition.folders) candidates.push(path.join(root, folder, nested, name));
      }
    }
  }
  return candidates;
}

function scanTools(deep = false) {
  const configured = readJson(toolsFile(), {});
  const results = {};
  const deepRoots = [app.getPath('downloads'), app.getPath('desktop'), process.env.LOCALAPPDATA || ''];
  for (const [key, definition] of Object.entries(TOOL_DEFINITIONS)) {
    let found = firstExecutable([configured[key], ...commonToolCandidates(key)]);
    if (!found && deep) {
      for (const root of deepRoots) {
        found = findExecutableRecursive(root, definition.names);
        if (found) break;
      }
    }
    results[key] = found;
  }
  writeJson(toolsFile(), results);
  return results;
}


function projectsRoot() { return path.join(dataRoot(), 'Projects'); }
function projectManifestFile(folder) { return path.join(folder, 'project.json'); }
function removeFileQuietly(file) { try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch {} }
function firstFileWithExtension(folder, extension) {
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && path.extname(entry.name).toLowerCase() === extension)
      .map(entry => ({ path: path.join(folder, entry.name), time: fs.statSync(path.join(folder, entry.name)).mtimeMs }))
      .sort((a, b) => b.time - a.time)[0]?.path || null;
  } catch {
    return null;
  }
}
function binInfoFor(file, existing = null) {
  if (!file || !fs.existsSync(file)) return null;
  const stat = fs.statSync(file);
  if (existing?.path === file && existing.size === stat.size && existing.sha256) return existing;
  return { path: file, name: path.basename(file), size: stat.size, sha256: sha256(file) };
}
function xdfInfoFor(file, existing = null) {
  if (!file || !fs.existsSync(file)) return null;
  if (existing?.path === file && Number.isFinite(existing.tableCount)) return existing;
  try {
    const parsed = parseXdf(file);
    return { path: file, name: path.basename(file), tableCount: parsed.tables.length, title: parsed.title, warnings: parsed.warnings || [] };
  } catch (error) {
    return { path: file, name: path.basename(file), tableCount: 0, title: path.basename(file), error: error.message };
  }
}
function osCandidatesFromText(value) {
  const text = String(value || '');
  const matches = [...text.matchAll(/(?:^|\D)(\d{7,9})(?!\d)/g)].map(match => match[1]);
  return [...new Set(matches)].filter(candidate => {
    const numeric = Number(candidate);
    return Number.isFinite(numeric) && numeric > 1000000 && numeric < 999999999;
  });
}
function detectProjectOperatingSystem(active) {
  if (!active) return { detected: false, os: '', source: '', message: 'Create or activate a project first.' };
  const sources = [
    ['XDF title', active.xdfInfo?.title],
    ['XDF filename', active.xdfInfo?.name || (active.xdf ? path.basename(active.xdf) : '')],
    ['BIN filename', active.binInfo?.name || (active.bin ? path.basename(active.bin) : '')]
  ];
  for (const [source, value] of sources) {
    const candidate = osCandidatesFromText(value)[0];
    if (candidate) return { detected: true, os: candidate, source, message: `Detected OS ${candidate} from ${source}.` };
  }
  return {
    detected: false,
    os: active.os || '',
    source: active.osSource || '',
    message: 'No operating-system number was found yet. Leave it blank until PCM identification or a clearly named matching XDF is available.'
  };
}
function applyAutomaticOperatingSystem(active) {
  if (!active || (active.os && active.osSource === 'manual')) return { active, detection: detectProjectOperatingSystem(active) };
  const detection = detectProjectOperatingSystem(active);
  if (!detection.detected) return { active, detection };
  const updated = { ...active, os: detection.os, osSource: detection.source };
  persistProjectState(updated);
  appendActivity('os-detected', { projectId: updated.id, projectName: updated.name, os: detection.os, source: detection.source });
  return { active: updated, detection };
}

function hydrateProjectRecord(manifest, folder, selectedAt = null) {
  if (!manifest || !folder || !fs.existsSync(folder)) return null;
  const originals = path.join(folder, 'Originals');
  const definitions = path.join(folder, 'Definitions');
  const storedBin = manifest.bin && fs.existsSync(manifest.bin) ? manifest.bin : null;
  const storedXdf = manifest.xdf && fs.existsSync(manifest.xdf) ? manifest.xdf : null;
  const bin = storedBin || firstFileWithExtension(originals, '.bin');
  const xdf = storedXdf || firstFileWithExtension(definitions, '.xdf') || firstFileWithExtension(folder, '.xdf');
  return {
    id: manifest.id,
    name: manifest.name,
    folder,
    vehicle: manifest.vehicle || '',
    controller: manifest.controller || '',
    os: manifest.os || '',
    osSource: manifest.osSource || '',
    notes: manifest.notes || '',
    selectedAt: selectedAt || new Date().toISOString(),
    bin: bin || null,
    binInfo: binInfoFor(bin, manifest.binInfo),
    xdf: xdf || null,
    xdfInfo: xdfInfoFor(xdf, manifest.xdfInfo)
  };
}
function getActiveProject() {
  const raw = readJson(activeProjectFile(), null);
  if (!raw?.id) return null;
  const folder = raw.folder || path.join(projectsRoot(), raw.id);
  const manifest = readJson(projectManifestFile(folder), null);
  const active = hydrateProjectRecord(manifest, folder, raw.selectedAt);
  if (!active) {
    removeFileQuietly(activeProjectFile());
    logStartup('active-project:cleared', raw?.id || 'invalid');
    return null;
  }
  persistProjectState(active);
  return active;
}
function persistProjectState(active) {
  if (!active?.id || !active?.folder) throw new Error('Project state is invalid.');
  const manifestFile = projectManifestFile(active.folder);
  const manifest = readJson(manifestFile, {});
  const updatedManifest = {
    ...manifest,
    id: active.id,
    name: active.name,
    vehicle: active.vehicle || '',
    controller: active.controller || '',
    os: active.os || '',
    osSource: active.osSource || manifest.osSource || '',
    notes: active.notes || manifest.notes || '',
    bin: active.bin || null,
    binInfo: active.binInfo || null,
    xdf: active.xdf || null,
    xdfInfo: active.xdfInfo || null,
    updatedAt: new Date().toISOString()
  };
  writeJson(manifestFile, updatedManifest);
  writeJson(activeProjectFile(), active);
  return active;
}
function requireActive() {
  const active = getActiveProject();
  if (!active) throw new Error('Create or activate a project first.');
  return active;
}
function updateActiveFiles(patch) {
  const active = { ...requireActive(), ...patch, updatedAt: new Date().toISOString() };
  return persistProjectState(active);
}
function copyProjectFile(source, destinationFolder) {
  fs.mkdirSync(destinationFolder, { recursive: true });
  const parsed = path.parse(source);
  let destination = path.join(destinationFolder, parsed.base);
  if (fs.existsSync(destination)) {
    try {
      if (sha256(source) === sha256(destination)) return destination;
    } catch {}
    let index = 2;
    do {
      destination = path.join(destinationFolder, `${parsed.name}-${index}${parsed.ext}`);
      index += 1;
    } while (fs.existsSync(destination));
  }
  fs.copyFileSync(source, destination);
  return destination;
}

function listFilesSafe(folder, extensions = null, limit = 250) {
  if (!folder || !fs.existsSync(folder)) return [];
  const allowed = extensions ? new Set(extensions.map(ext => ext.toLowerCase())) : null;
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile())
      .map(entry => {
        const file = path.join(folder, entry.name);
        const stat = fs.statSync(file);
        return {
          name: entry.name,
          path: file,
          extension: path.extname(entry.name).toLowerCase(),
          size: stat.size,
          modifiedAt: stat.mtime.toISOString()
        };
      })
      .filter(item => !allowed || allowed.has(item.extension))
      .sort((a, b) => String(b.modifiedAt).localeCompare(String(a.modifiedAt)))
      .slice(0, limit);
  } catch (error) {
    logStartup('workspace:list-files-failed', `${folder}: ${error.message}`);
    return [];
  }
}

function buildTunePath(active, files, calibration, tools) {
  const aiBundle = active ? loadAiBundle(active) : { intake: null, plan: null };
  const fullAiEnabled = readJson(settingsFile(), {}).aiMode === 'full-ai';
  const calibrationReady = Boolean(
    active && calibration?.mode === 'xdf' && calibration?.projectId === active.id &&
    calibration?.sourceBin && calibration?.sourceXdf
  );
  const hasRevision = files.revisions.some(file => file.extension === '.bin');
  const definitions = [
    { id: 'project', title: 'Create or select project', page: 'workflow', target: '#projectForm', complete: Boolean(active), description: active ? active.name : 'Vehicle, controller, and build notes; OS can be detected later' },
    { id: 'controller', title: 'Confirm controller', page: 'workflow', target: '#projectController', complete: Boolean(active?.controller), description: active?.controller ? `${active.controller}${active.os ? ` / OS ${active.os}` : ' / OS auto-detect pending'}` : 'Choose the PCM/ECM family; OS can be detected later' },
    ...(fullAiEnabled ? [{ id: 'ai-intake', title: 'Describe the build and tune goal', page: 'fullai', target: '#fullAiForm', complete: Boolean(aiBundle.intake?.completedAt && aiBundle.plan?.steps?.length), description: aiBundle.intake?.tuneGoal || 'Full AI asks only the questions needed for this build' }] : []),
    { id: 'original', title: 'Import protected original BIN', page: 'files', target: '#importBin', complete: Boolean(active?.bin), description: active?.binInfo?.name || 'Preserve the stock read first' },
    { id: 'definition', title: 'Import matching XDF', page: 'files', target: '#importXdf', complete: Boolean(active?.xdf && !active?.xdfInfo?.error), description: active?.xdfInfo?.name || 'TunIQ will inspect the XDF title and filename for the OS' },
    { id: 'calibration', title: 'Load calibration mapping', page: 'sandbox', target: '#labLoadXdf', complete: calibrationReady, description: calibrationReady ? `${Object.keys(calibration.tables || {}).length} items mapped` : 'Open the active BIN and XDF together' },
    { id: 'revision', title: 'Export a revision BIN', page: 'sandbox', target: '#labExportBin', complete: hasRevision, description: hasRevision ? `${files.revisions.filter(file => file.extension === '.bin').length} revision BIN(s)` : 'Never overwrite the protected original' },
    { id: 'validate', title: 'Review checksums and changes', page: 'patches', target: '#patchAnalyze', complete: false, description: 'Native checksum report foundation' },
    { id: 'flash', title: 'Prepare controlled flash', page: 'flash', target: '#flashPrepareIdentify', complete: false, locked: true, description: 'Write operations remain locked in 1.4 dev.1' }
  ];
  let foundCurrent = false;
  return definitions.map(step => {
    let status = step.complete ? 'complete' : step.locked ? 'locked' : 'waiting';
    if (!step.complete && !step.locked && !foundCurrent) {
      status = 'current';
      foundCurrent = true;
    }
    return { ...step, status };
  });
}

function getWorkspaceSummary() {
  const active = getActiveProject();
  const tools = scanTools(false);
  const folders = active ? {
    originals: path.join(active.folder, 'Originals'),
    definitions: path.join(active.folder, 'Definitions'),
    revisions: path.join(active.folder, 'Revisions'),
    logs: path.join(active.folder, 'Logs'),
    backups: path.join(active.folder, 'Backups')
  } : {};
  const files = {
    originals: active ? listFilesSafe(folders.originals) : [],
    definitions: active ? listFilesSafe(folders.definitions) : [],
    revisions: active ? listFilesSafe(folders.revisions) : [],
    logs: active ? listFilesSafe(folders.logs) : [],
    backups: active ? listFilesSafe(folders.backups) : []
  };
  const calibration = readJson(calibrationFile(), null);
  const activity = (() => {
    const items = readJson(activityFile(), []);
    return (Array.isArray(items) ? items : [])
      .filter(item => !active || !item.details?.projectId || item.details.projectId === active.id || item.details?.activeProjectId === active.id)
      .slice(0, 40);
  })();
  const steps = buildTunePath(active, files, calibration, tools);
  const completed = steps.filter(step => step.status === 'complete').length;
  return {
    generatedAt: new Date().toISOString(),
    activeProject: active,
    tools,
    files,
    folders,
    activity,
    calibration: calibration ? {
      mode: calibration.mode || 'local',
      projectId: calibration.projectId || null,
      tableCount: Object.keys(calibration.tables || {}).length,
      modifiedCells: Object.keys(calibration.modified || {}).length,
      mappingSummary: calibration.mappingSummary || null
    } : null,
    tunePath: {
      steps,
      completed,
      total: steps.length,
      progress: steps.length ? Math.round((completed / steps.length) * 100) : 0
    },
    ai: active ? loadAiBundle(active) : { intake: null, plan: null },
    libraryCount: listTuneLibrary().length,
    communityCount: listCommunityPosts().length,
    integrations: {
      pcmHammer: { configured: isExecutableFile(tools.pcmHammer), mode: 'native-adapter-foundation', writeLocked: true },
      tunerPro: { configured: isExecutableFile(tools.tunerPro), mode: 'native-calibration-workspace' },
      universalPatcher: { configured: isExecutableFile(tools.universalPatcher), mode: 'native-report-foundation', writeLocked: true }
    }
  };
}



// TunIQ 1.4: Full AI intake, local Tune Library, and Community Hub foundation.
function aiProjectFolder(active) {
  const folder = path.join(active.folder, 'AI');
  fs.mkdirSync(folder, { recursive: true });
  return folder;
}
function aiIntakeFile(active) { return path.join(aiProjectFolder(active), 'intake.json'); }
function aiPlanFile(active) { return path.join(aiProjectFolder(active), 'plan.json'); }
function cleanText(value, max = 5000) { return String(value || '').trim().slice(0, max); }
function cleanList(value, limit = 50) {
  const list = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(list.map(item => cleanText(item, 120)).filter(Boolean))].slice(0, limit);
}
function normalizeAiIntake(payload, active) {
  const cam = payload?.cam && typeof payload.cam === 'object' ? payload.cam : {};
  return {
    projectId: active.id,
    projectName: active.name,
    vehicle: cleanText(payload?.vehicle || active.vehicle, 160),
    year: cleanText(payload?.year, 12),
    make: cleanText(payload?.make, 80),
    model: cleanText(payload?.model, 100),
    engine: cleanText(payload?.engine, 120),
    transmission: cleanText(payload?.transmission, 120),
    controller: cleanText(payload?.controller || active.controller, 80),
    operatingSystem: cleanText(payload?.operatingSystem || active.os, 80),
    fuel: cleanText(payload?.fuel, 80),
    aspiration: cleanText(payload?.aspiration, 80),
    tuneGoal: cleanText(payload?.tuneGoal, 100),
    drivingUse: cleanText(payload?.drivingUse, 100),
    modifications: cleanList(payload?.modifications, 60),
    injectorData: cleanText(payload?.injectorData, 500),
    gearRatio: cleanText(payload?.gearRatio, 30),
    tireSize: cleanText(payload?.tireSize, 40),
    converterStall: cleanText(payload?.converterStall, 40),
    boostPsi: cleanText(payload?.boostPsi, 30),
    desiredIdle: cleanText(payload?.desiredIdle, 40),
    symptoms: cleanText(payload?.symptoms, 2500),
    notes: cleanText(payload?.notes, 5000),
    cam: {
      brand: cleanText(cam.brand, 80),
      partNumber: cleanText(cam.partNumber, 80),
      durationIntake: cleanText(cam.durationIntake, 30),
      durationExhaust: cleanText(cam.durationExhaust, 30),
      liftIntake: cleanText(cam.liftIntake, 30),
      liftExhaust: cleanText(cam.liftExhaust, 30),
      lsa: cleanText(cam.lsa, 30),
      icl: cleanText(cam.icl, 30)
    },
    updatedAt: new Date().toISOString(),
    completedAt: new Date().toISOString()
  };
}
function buildFullAiPlan(active, intake) {
  const mods = new Set((intake?.modifications || []).map(item => item.toLowerCase()));
  const goal = String(intake?.tuneGoal || '').toLowerCase();
  const hasCam = mods.has('aftermarket camshaft') || goal.includes('camshaft');
  const ghostCam = goal.includes('ghost-cam') || goal.includes('ghost cam');
  const hasBoost = ['turbo','supercharger','forced induction'].some(item => mods.has(item) || String(intake?.aspiration || '').toLowerCase().includes(item));
  const hasTransmission = Boolean(intake?.transmission);
  const steps = [
    { id: 'intake', title: 'Confirm vehicle build and goal', type: 'review', reason: 'The AI plan must match the exact hardware and intended use.', complete: true },
    { id: 'identify', title: 'Identify PCM/TCM and operating system', type: 'controller', reason: 'Definition, segment, checksum, and flash support depend on exact controller identity.', complete: Boolean(active.controller && active.os) },
    { id: 'read', title: 'Read and protect the original calibration', type: 'flash', reason: 'A verified stock recovery file must exist before any tune changes.', complete: Boolean(active.bin) },
    { id: 'baseline', title: 'Run baseline diagnostics and log', type: 'diagnostics', reason: 'Mechanical, sensor, fuel-delivery, and wiring problems should be fixed before tuning.', complete: false },
    { id: 'fuel-system', title: 'Validate injectors and fuel-system data', type: 'calibration', reason: 'Incorrect injector data can corrupt idle, transient, and load fueling.', complete: false }
  ];
  if (hasCam || ghostCam) steps.push(
    { id: 'cam-idle', title: 'Build camshaft idle-airflow strategy', type: 'calibration', reason: 'Cam overlap changes airflow demand, vacuum, idle spark authority, and startup behavior.', complete: false },
    { id: 'cam-diagnostics', title: 'Review cam-related diagnostics and airflow limits', type: 'calibration', reason: 'Only hardware-related diagnostics should be adjusted, never used to hide mechanical faults.', complete: false }
  );
  if (hasBoost) steps.push({ id: 'boost-safety', title: 'Validate boost, fuel pressure, MAP range, and enrichment safety', type: 'safety', reason: 'Forced-induction tuning requires verified fuel supply and conservative load protection.', complete: false });
  steps.push(
    { id: 'airflow', title: 'Calibrate MAF and/or VE airflow model', type: 'calibration', reason: 'The PCM must correctly calculate cylinder airmass before spark and fueling optimization.', complete: false },
    { id: 'fueling', title: 'Calibrate commanded fueling and power enrichment', type: 'calibration', reason: 'Target fueling must match fuel type, load, hardware, and measured wideband data.', complete: false },
    { id: 'spark', title: 'Optimize spark with knock and temperature safeguards', type: 'calibration', reason: 'Timing changes require repeatable logs and must preserve knock protection.', complete: false }
  );
  if (hasTransmission) steps.push({ id: 'transmission', title: 'Review shift, torque-management, and converter behavior', type: 'transmission', reason: `The ${intake.transmission} calibration must match engine torque, gearing, tires, and intended use.`, complete: false });
  steps.push(
    { id: 'validate', title: 'Validate changes, checksums, and compatibility', type: 'validation', reason: 'Every proposed change must be reviewable and tied to the original BIN.', complete: false },
    { id: 'revision', title: 'Create a named AI tune revision', type: 'revision', reason: 'Full AI always creates a new revision and never overwrites the original.', complete: false },
    { id: 'flash', title: 'Prepare controlled flash confirmation', type: 'flash', reason: 'The user must confirm controller, file, voltage, interface, backup, and recovery status.', complete: false, locked: true },
    { id: 'verify', title: 'Run post-flash checks and follow-up log', type: 'diagnostics', reason: 'The AI should verify results and revise from measured data instead of guessing.', complete: false, locked: true }
  );
  return {
    id: `${Date.now()}-ai-plan`,
    projectId: active.id,
    projectName: active.name,
    goal: intake.tuneGoal || 'Custom tune',
    mode: 'full-ai-foundation',
    generatedAt: new Date().toISOString(),
    warnings: [
      'This development build creates the structured plan but does not autonomously alter or flash a controller.',
      'Mechanical faults, missing injector data, or unsafe logs must block automatic calibration changes.',
      'Controller writing always requires explicit user confirmation.'
    ],
    steps
  };
}
function loadAiBundle(active = getActiveProject()) {
  if (!active) return { intake: null, plan: null };
  return { intake: readJson(aiIntakeFile(active), null), plan: readJson(aiPlanFile(active), null) };
}

function tuneLibraryRoot() { const folder = path.join(dataRoot(), 'TuneLibrary'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function tuneLibraryFilesRoot() { const folder = path.join(tuneLibraryRoot(), 'Files'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function tuneLibraryFile() { return path.join(tuneLibraryRoot(), 'library.json'); }
function listTuneLibrary() { const value = readJson(tuneLibraryFile(), []); return Array.isArray(value) ? value : []; }
function latestTuneSource(active) {
  const revisions = listFilesSafe(path.join(active.folder, 'Revisions'), ['.bin']);
  return revisions[0]?.path || (active.bin && fs.existsSync(active.bin) ? active.bin : null);
}
function safeTuneName(value) { return cleanText(value, 120).replace(/[<>:"/\\|?*]/g, '-'); }
function saveTuneToLibrary(payload) {
  const active = requireActive();
  const source = latestTuneSource(active);
  if (!source) throw new Error('Import an original BIN or export a revision before saving a tune to the library.');
  const name = safeTuneName(payload?.name || `${active.name} Tune`);
  if (!name) throw new Error('Tune name is required.');
  const id = `${Date.now()}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`;
  const destination = path.join(tuneLibraryFilesRoot(), `${id}${path.extname(source).toLowerCase() || '.bin'}`);
  fs.copyFileSync(source, destination);
  const ai = loadAiBundle(active).intake;
  const entry = {
    id, name,
    description: cleanText(payload?.description, 3000),
    engine: cleanText(payload?.engine || ai?.engine, 120),
    transmission: cleanText(payload?.transmission || ai?.transmission, 120),
    controller: cleanText(payload?.controller || active.controller, 80),
    os: cleanText(payload?.os || active.os, 80),
    fuel: cleanText(payload?.fuel || ai?.fuel, 80),
    tuneGoal: cleanText(payload?.tuneGoal || ai?.tuneGoal, 100),
    modifications: cleanList(payload?.modifications || ai?.modifications, 60),
    tags: cleanList(payload?.tags, 30),
    favorite: false,
    sourceProjectId: active.id,
    sourceProjectName: active.name,
    sourceFile: destination,
    sourceFileName: path.basename(destination),
    sourceSha256: sha256(destination),
    sourceWasRevision: path.dirname(source) === path.join(active.folder, 'Revisions'),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  const items = listTuneLibrary(); items.unshift(entry); writeJson(tuneLibraryFile(), items);
  appendActivity('tune-library-saved', { id, name, projectId: active.id, sourceFileName: entry.sourceFileName });
  return entry;
}
function getTuneEntry(id) { return listTuneLibrary().find(item => item.id === id) || null; }
function tuneCompatibility(entry, active) {
  const problems = [];
  if (entry.controller && !active.controller) problems.push('Identify the active project controller before importing this tune');
  else if (entry.controller && active.controller && entry.controller.toLowerCase() !== active.controller.toLowerCase()) problems.push(`Controller mismatch: ${entry.controller} vs ${active.controller}`);
  if (entry.os && !active.os) problems.push('Detect the active project operating system before importing this tune');
  else if (entry.os && active.os && entry.os.toLowerCase() !== active.os.toLowerCase()) problems.push(`Operating-system mismatch: ${entry.os} vs ${active.os}`);
  return { compatible: problems.length === 0, problems, status: problems.length ? 'incompatible' : (entry.controller && active.controller ? 'compatible' : 'review') };
}

function communityRoot() { const folder = path.join(dataRoot(), 'Community'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function communityPostsFile() { return path.join(communityRoot(), 'posts.json'); }
function defaultCommunityPosts() {
  const at = new Date().toISOString();
  return [
    { id: 'official-welcome', official: true, category: 'Guide', title: 'How to create a useful troubleshooting post', engine: 'Any', transmission: 'Any', controller: 'Any', body: 'Attach the controller, operating system, DTCs, exact symptoms, modifications, and a log from the conditions where the problem occurs.', author: 'TunIQ', createdAt: at, tags: ['posting','diagnostics'] },
    { id: 'official-p01-cam', official: true, category: 'Guide', title: 'P01/P59 camshaft tune intake checklist', engine: 'Gen III LS', transmission: 'Any', controller: 'P01 / P59', body: 'Record cam specifications, injector data, intake and exhaust setup, transmission, converter, gear ratio, tire size, fuel, desired idle, and a baseline log before changing airflow tables.', author: 'TunIQ', createdAt: at, tags: ['cam','idle','p01','p59'] },
    { id: 'official-tune-safety', official: true, category: 'Community Tunes', title: 'Why community tunes are imported as revisions', engine: 'Any', transmission: 'Any', controller: 'Any', body: 'TunIQ checks controller and OS compatibility, preserves the protected original, and imports a tune as a new revision. Community files never replace the stock read.', author: 'TunIQ', createdAt: at, tags: ['safety','compatibility'] }
  ];
}
function listCommunityPosts() {
  let posts = readJson(communityPostsFile(), null);
  if (!Array.isArray(posts)) { posts = defaultCommunityPosts(); writeJson(communityPostsFile(), posts); }
  return posts;
}


app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');
logStartup('process:start', `version=${APP_VERSION} platform=${process.platform} arch=${process.arch}`);
app.whenReady().then(() => {
  logStartup('app:ready');
  ensureDataFolders();
  logStartup('folders:ready', dataRoot());
  const migration = migrateLegacyData();
  logStartup('migration:checked', JSON.stringify(migration));
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
}).catch(error => {
  logCrash('startup-failure', error);
  try { dialog.showErrorBox('TunIQ could not start', `${error?.message || error}\n\nCrash log: ${path.join(dataRoot(), 'Logs', 'desktop-crash.log')}`); } catch {}
  app.quit();
});
app.on('before-quit', () => { app.isQuitting = true; logStartup('app:before-quit'); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('app:get-bootstrap', async () => ({
  version: APP_VERSION,
  dataRoot: dataRoot(),
  profile: readJson(profileFile(), null),
  settings: readJson(settingsFile(), { aiMode: null, units: 'US' }),
  tools: scanTools(false),
  vehicles: listVehicles(),
  activity: (() => { const v = readJson(activityFile(), []); return Array.isArray(v) ? v : []; })(),
  activeProject: getActiveProject(),
  ai: loadAiBundle(getActiveProject()),
  tuneLibrary: listTuneLibrary(),
  communityPosts: listCommunityPosts(),
  migration: readJson(path.join(dataRoot(), 'Settings', 'appdata-migration.json'), null)
}));
ipcMain.handle('profile:save', async (_event, payload) => {
  const profile = { name: String(payload.name || '').trim(), email: String(payload.email || '').trim(), createdAt: new Date().toISOString() };
  const settings = { aiMode: payload.aiMode, units: payload.units || 'US', updatedAt: new Date().toISOString() };
  if (!profile.name || !profile.email || !['guided','manual','full-ai'].includes(settings.aiMode)) throw new Error('Name, email, and AI mode are required.');
  writeJson(profileFile(), profile);
  writeJson(settingsFile(), settings);
  return { profile, settings };
});
ipcMain.handle('settings:set-ai-mode', async (_event, aiMode) => {
  if (!['guided','manual','full-ai'].includes(aiMode)) throw new Error('Invalid AI mode.');
  const settings = { ...readJson(settingsFile(), {}), aiMode, updatedAt: new Date().toISOString() };
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('bridge:scan-tools', async () => scanTools(true));
ipcMain.handle('bridge:verify-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool.');
  const tools = scanTools(false);
  const toolPath = tools[key];
  return { valid: isExecutableFile(toolPath), path: toolPath || null };
});
ipcMain.handle('bridge:choose-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool selection.');
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Windows programs', extensions: ['exe'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const selected = result.filePaths[0];
  if (!isExecutableFile(selected)) throw new Error('Select a valid Windows .exe file.');
  const tools = scanTools(false);
  tools[key] = path.resolve(selected);
  writeJson(toolsFile(), tools);
  return tools[key];
});
ipcMain.handle('bridge:launch-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool.');
  let tools = scanTools(false);
  let exe = tools[key];
  if (!isExecutableFile(exe)) {
    tools = scanTools(true);
    exe = tools[key];
  }
  if (!isExecutableFile(exe)) {
    tools[key] = null;
    writeJson(toolsFile(), tools);
    throw new Error('The saved tool path no longer exists. Click Scan This PC or Browse to select the program again.');
  }
  const active = getActiveProject();
  const cwd = active?.folder && fs.existsSync(active.folder) ? active.folder : path.dirname(exe);
  const args = [];
  if (key === 'tunerPro' && active?.bin && fs.existsSync(active.bin)) {
    args.push(active.bin);
    if (active.xdf && fs.existsSync(active.xdf)) args.push(active.xdf);
  }
  let child;
  await new Promise((resolve, reject) => {
    child = spawn(exe, args, { detached: true, stdio: 'ignore', cwd, windowsHide: false });
    child.once('spawn', resolve);
    child.once('error', reject);
  }).catch(error => {
    throw new Error(`Windows could not launch ${path.basename(exe)}: ${error.message}`);
  });
  child.unref();
  appendActivity('tool-launched', { key, exe, args, cwd, activeProjectId: active?.id || null, activeProjectName: active?.name || null });
  return { launched: true, activeProject: active, exe, args };
});
ipcMain.handle('workspace:get-summary', async () => getWorkspaceSummary());
ipcMain.handle('workspace:open-subfolder', async (_event, key) => {
  const active = requireActive();
  const allowed = {
    project: active.folder,
    originals: path.join(active.folder, 'Originals'),
    definitions: path.join(active.folder, 'Definitions'),
    revisions: path.join(active.folder, 'Revisions'),
    logs: path.join(active.folder, 'Logs'),
    backups: path.join(active.folder, 'Backups')
  };
  const folder = allowed[key];
  if (!folder) throw new Error('Unknown project folder.');
  fs.mkdirSync(folder, { recursive: true });
  const error = await shell.openPath(folder);
  if (error) throw new Error(error);
  return folder;
});
ipcMain.handle('workspace:plan-action', async (_event, payload) => {
  const active = requireActive();
  const action = String(payload?.action || 'unknown');
  const allowed = new Set(['identify-controller', 'read-original', 'analyze-bin']);
  if (!allowed.has(action)) throw new Error('Unsupported workspace action.');
  const tools = scanTools(false);
  if ((action === 'identify-controller' || action === 'read-original') && !active.controller) throw new Error('Enter the project controller before preparing a PCM operation.');
  if ((action === 'identify-controller' || action === 'read-original') && !isExecutableFile(tools.pcmHammer)) throw new Error('Configure PCM Hammer in Tool Setup before preparing this operation.');
  if (action === 'analyze-bin' && (!active.bin || !fs.existsSync(active.bin))) throw new Error('Import the protected original BIN before running analysis.');
  const details = {
    action,
    projectId: active.id,
    projectName: active.name,
    controller: active.controller || null,
    os: active.os || null,
    bin: active.binInfo?.name || null,
    at: new Date().toISOString()
  };
  appendActivity('workspace-action-prepared', details);
  return details;
});


ipcMain.handle('ai:get-intake', async () => loadAiBundle(requireActive()));
ipcMain.handle('ai:save-intake', async (_event, payload) => {
  const active = requireActive();
  const intake = normalizeAiIntake(payload, active);
  if (!intake.engine) throw new Error('Enter the engine before building a Full AI plan.');
  if (!intake.transmission) throw new Error('Enter the transmission or choose Manual / No transmission control.');
  if (!intake.tuneGoal) throw new Error('Choose what you want the tune to accomplish.');
  const camNeeded = intake.modifications.map(item => item.toLowerCase()).includes('aftermarket camshaft') || intake.tuneGoal.toLowerCase().includes('camshaft');
  if (camNeeded && !(intake.cam.durationIntake && intake.cam.durationExhaust && intake.cam.lsa)) {
    throw new Error('A camshaft tune needs at least intake duration, exhaust duration, and LSA.');
  }
  writeJson(aiIntakeFile(active), intake);
  appendActivity('ai-intake-saved', { projectId: active.id, projectName: active.name, goal: intake.tuneGoal, engine: intake.engine, transmission: intake.transmission });
  return intake;
});
ipcMain.handle('ai:generate-plan', async (_event, payload) => {
  const active = requireActive();
  const intake = normalizeAiIntake(payload, active);
  if (!intake.engine || !intake.transmission || !intake.tuneGoal) throw new Error('Engine, transmission, and tune goal are required.');
  const camNeeded = intake.modifications.map(item => item.toLowerCase()).includes('aftermarket camshaft') || intake.tuneGoal.toLowerCase().includes('camshaft');
  if (camNeeded && !(intake.cam.durationIntake && intake.cam.durationExhaust && intake.cam.lsa)) throw new Error('Enter the cam duration and LSA before generating this plan.');
  const plan = buildFullAiPlan(active, intake);
  writeJson(aiIntakeFile(active), intake);
  writeJson(aiPlanFile(active), plan);
  appendActivity('ai-plan-generated', { projectId: active.id, projectName: active.name, planId: plan.id, goal: plan.goal, steps: plan.steps.length });
  return { intake, plan };
});

ipcMain.handle('tune-library:list', async () => listTuneLibrary());
ipcMain.handle('tune-library:save-active', async (_event, payload) => saveTuneToLibrary(payload));
ipcMain.handle('tune-library:favorite', async (_event, id) => {
  const items = listTuneLibrary();
  const entry = items.find(item => item.id === id);
  if (!entry) throw new Error('Tune not found.');
  entry.favorite = !entry.favorite; entry.updatedAt = new Date().toISOString(); writeJson(tuneLibraryFile(), items); return entry;
});
ipcMain.handle('tune-library:delete', async (_event, id) => {
  const items = listTuneLibrary(); const entry = items.find(item => item.id === id); if (!entry) return true;
  removeFileQuietly(entry.sourceFile); writeJson(tuneLibraryFile(), items.filter(item => item.id !== id));
  appendActivity('tune-library-deleted', { id, name: entry.name }); return true;
});
ipcMain.handle('tune-library:apply', async (_event, id) => {
  const active = requireActive(); const entry = getTuneEntry(id); if (!entry) throw new Error('Tune not found.');
  if (!entry.sourceFile || !fs.existsSync(entry.sourceFile)) throw new Error('The tune file is missing from the local library.');
  const compatibility = tuneCompatibility(entry, active);
  if (!compatibility.compatible) throw new Error(`This tune cannot be imported: ${compatibility.problems.join('; ')}`);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = path.join(active.folder, 'Revisions', `Library-${safeTuneName(entry.name)}-${stamp}.bin`);
  fs.mkdirSync(path.dirname(output), { recursive: true }); fs.copyFileSync(entry.sourceFile, output);
  const result = { name: path.basename(output), path: output, size: fs.statSync(output).size, sha256: sha256(output), compatibility };
  appendActivity('tune-library-imported', { tuneId: entry.id, tuneName: entry.name, projectId: active.id, projectName: active.name, output: result.name });
  return result;
});
ipcMain.handle('tune-library:export', async (_event, id) => {
  const entry = getTuneEntry(id); if (!entry) throw new Error('Tune not found.');
  if (!entry.sourceFile || !fs.existsSync(entry.sourceFile)) throw new Error('The tune file is missing.');
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath: `${safeTuneName(entry.name)}.tuniqtune`, filters: [{ name: 'TunIQ Tune Package', extensions: ['tuniqtune'] }] });
  if (result.canceled || !result.filePath) return null;
  const packageData = { format: 'TunIQTunePackage', version: 1, exportedAt: new Date().toISOString(), tune: { ...entry, sourceFile: null }, binBase64: fs.readFileSync(entry.sourceFile).toString('base64') };
  writeJson(result.filePath, packageData); return result.filePath;
});
ipcMain.handle('tune-library:import', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'TunIQ Tune Package', extensions: ['tuniqtune'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const raw = readJson(result.filePaths[0], null);
  if (raw?.format !== 'TunIQTunePackage' || raw?.version !== 1 || !raw?.tune || !raw?.binBase64) throw new Error('This is not a supported TunIQ tune package.');
  const buffer = Buffer.from(raw.binBase64, 'base64');
  if (!buffer.length || buffer.length > 16 * 1024 * 1024) throw new Error('Tune package BIN size is invalid.');
  const name = safeTuneName(raw.tune.name || 'Imported Tune'); const id = `${Date.now()}-imported-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  const destination = path.join(tuneLibraryFilesRoot(), `${id}.bin`); fs.writeFileSync(destination, buffer);
  const entry = { ...raw.tune, id, name, sourceFile: destination, sourceFileName: path.basename(destination), sourceSha256: sha256(destination), favorite: false, importedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  const items = listTuneLibrary(); items.unshift(entry); writeJson(tuneLibraryFile(), items);
  appendActivity('tune-package-imported', { id, name }); return entry;
});

ipcMain.handle('community:list', async () => listCommunityPosts());
ipcMain.handle('community:create-post', async (_event, payload) => {
  const title = cleanText(payload?.title, 180); const body = cleanText(payload?.body, 8000); if (!title || !body) throw new Error('Post title and details are required.');
  const active = getActiveProject(); const profile = readJson(profileFile(), {});
  const post = { id: `${Date.now()}-post`, official: false, category: cleanText(payload?.category, 60) || 'Problems & Help', title, engine: cleanText(payload?.engine, 120) || 'Unspecified', transmission: cleanText(payload?.transmission, 120) || 'Unspecified', controller: cleanText(payload?.controller || active?.controller, 80) || 'Unspecified', body, author: cleanText(profile.name, 100) || 'Local User', tags: cleanList(payload?.tags, 30), projectContext: payload?.attachProject && active ? { projectId: active.id, projectName: active.name, vehicle: active.vehicle, controller: active.controller, os: active.os, bin: active.binInfo?.name || null, xdf: active.xdfInfo?.name || null } : null, createdAt: new Date().toISOString() };
  const posts = listCommunityPosts(); posts.unshift(post); writeJson(communityPostsFile(), posts);
  appendActivity('community-post-created', { id: post.id, title: post.title, category: post.category, projectId: active?.id || null }); return post;
});
ipcMain.handle('community:delete-post', async (_event, id) => {
  const posts = listCommunityPosts(); const post = posts.find(item => item.id === id); if (!post || post.official) throw new Error('Official posts cannot be deleted.');
  writeJson(communityPostsFile(), posts.filter(item => item.id !== id)); return true;
});

ipcMain.handle('system:open-data-folder', async () => shell.openPath(dataRoot()));

ipcMain.handle('vehicle:list', async () => listVehicles());
ipcMain.handle('vehicle:save', async (_event, payload) => {
  const vehicles = listVehicles();
  const index = payload.id ? vehicles.findIndex(v => v.id === payload.id) : -1;
  const vehicle = normalizeVehicle(payload, index >= 0 ? vehicles[index] : {});
  if (index >= 0) vehicles[index] = vehicle; else vehicles.unshift(vehicle);
  writeJson(vehiclesFile(), vehicles);
  appendActivity(index >= 0 ? 'vehicle-updated' : 'vehicle-created', { id: vehicle.id, name: vehicle.name });
  return vehicle;
});
ipcMain.handle('vehicle:delete', async (_event, id) => {
  const vehicles = listVehicles();
  const found = vehicles.find(v => v.id === id);
  writeJson(vehiclesFile(), vehicles.filter(v => v.id !== id));
  if (found) appendActivity('vehicle-deleted', { id: found.id, name: found.name });
  return true;
});
ipcMain.handle('project:set-active', async (_event, id) => {
  const base = projectsRoot();
  const projects = fs.existsSync(base)
    ? fs.readdirSync(base, { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .map(entry => ({ manifest: readJson(projectManifestFile(path.join(base, entry.name)), null), folder: path.join(base, entry.name) }))
      .filter(entry => entry.manifest)
    : [];
  const found = projects.find(entry => entry.manifest.id === id);
  if (!found) throw new Error('Project not found.');
  const active = hydrateProjectRecord(found.manifest, found.folder, new Date().toISOString());
  if (!active) throw new Error('The project folder is missing or damaged.');
  persistProjectState(active);
  appendActivity('project-activated', { id: active.id, name: active.name });
  return active;
});
ipcMain.handle('activity:list', async () => {
  const activity = readJson(activityFile(), []);
  return Array.isArray(activity) ? activity : [];
});

ipcMain.handle('project:create', async (_event, payload) => {
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const id = `${Date.now()}-${safeName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`;
  const folder = path.join(projectsRoot(), id);
  for (const subfolder of ['Originals', 'Definitions', 'Revisions', 'Logs', 'Backups', 'AI']) {
    fs.mkdirSync(path.join(folder, subfolder), { recursive: true });
  }
  const manifest = {
    id,
    name: safeName,
    vehicle: payload.vehicle || '',
    controller: payload.controller || '',
    os: String(payload.os || '').trim(),
    osSource: String(payload.os || '').trim() ? 'manual' : '',
    notes: payload.notes || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    revisions: [],
    bin: null,
    binInfo: null,
    xdf: null,
    xdfInfo: null
  };
  writeJson(projectManifestFile(folder), manifest);
  const active = hydrateProjectRecord(manifest, folder, new Date().toISOString());
  persistProjectState(active);
  appendActivity('project-created', { id, name: safeName, vehicle: manifest.vehicle, controller: manifest.controller });
  return { ...manifest, active };
});
ipcMain.handle('project:update', async (_event, payload) => {
  const id = String(payload?.id || '').trim();
  if (!id) throw new Error('Choose a project to edit first.');
  const base = projectsRoot();
  const entry = fs.existsSync(base)
    ? fs.readdirSync(base, { withFileTypes: true })
      .filter(item => item.isDirectory())
      .map(item => ({ folder: path.join(base, item.name), manifest: readJson(projectManifestFile(path.join(base, item.name)), null) }))
      .find(item => item.manifest?.id === id)
    : null;
  if (!entry) throw new Error('The project could not be found. It may have been moved or removed.');
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const manifest = {
    ...entry.manifest,
    name: safeName,
    vehicle: String(payload.vehicle || '').trim(),
    controller: String(payload.controller || '').trim(),
    os: String(payload.os || '').trim(),
    osSource: String(payload.os || '').trim() ? 'manual' : '',
    notes: String(payload.notes || '').trim(),
    updatedAt: new Date().toISOString()
  };
  writeJson(projectManifestFile(entry.folder), manifest);
  const current = getActiveProject();
  let active = null;
  if (current?.id === id) {
    active = hydrateProjectRecord(manifest, entry.folder, current.selectedAt);
    persistProjectState(active);
  }
  appendActivity('project-updated', { id, name: manifest.name, vehicle: manifest.vehicle, controller: manifest.controller, os: manifest.os });
  return { ...manifest, active };
});
ipcMain.handle('project:list', async () => {
  const base = projectsRoot();
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base, { withFileTypes: true })
    .filter(entry => entry.isDirectory())
    .map(entry => readJson(projectManifestFile(path.join(base, entry.name)), null))
    .filter(Boolean)
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')));
});
ipcMain.handle('diagnostics:export', async () => {
  const report = { version: APP_VERSION, platform: process.platform, arch: process.arch, os: os.release(), dataRoot: dataRoot(), profileExists: fs.existsSync(profileFile()), settings: readJson(settingsFile(), {}), tools: scanTools(false), activeProject: getActiveProject(), workspace: getWorkspaceSummary(), generatedAt: new Date().toISOString() };
  const out = path.join(dataRoot(), 'Logs', `diagnostics-${Date.now()}.json`);
  writeJson(out, report);
  return out;
});

ipcMain.handle('system:open-external', async (_event, url) => {
  const allowed = ['https://github.com/PcmHammer/PcmHammer/releases','https://github.com/LegacyNsfw/PcmHacks/releases','https://www.tunerpro.net/downloadApp.htm','https://universalpatcher.net/download/'];
  if (!allowed.includes(url)) throw new Error('Blocked unapproved external URL.');
  await shell.openExternal(url);
  return true;
});


function calibrationFile() { return path.join(dataRoot(), 'Calibration', 'workspace.json'); }
function calibrationHistoryFile() { return path.join(dataRoot(), 'Calibration', 'history.json'); }
function defaultCalibrationWorkspace() {
  const makeGrid = (rows, cols, fn) => Array.from({ length: rows }, (_, r) => Array.from({ length: cols }, (_, c) => Number(fn(r, c).toFixed(2))));
  return {
    activeTable: 'spark',
    tables: {
      spark: { name: 'High-Octane Spark', unit: '°', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['0.20','0.32','0.44','0.56','0.68','0.80','0.92','1.04'], min: -10, max: 50, values: makeGrid(8,8,(r,c)=>12+r*1.75-c*.65) },
      ve: { name: 'VE Main', unit: '%', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['20','30','40','50','60','70','80','90'], min: 20, max: 125, values: makeGrid(8,8,(r,c)=>42+r*3.1+c*4.2) },
      idle: { name: 'Idle Airflow', unit: 'g/s', rowHeaders: ['-20','0','20','40','60','80','100','120'], colHeaders: ['P/N','Drive'], min: 0, max: 30, values: makeGrid(8,2,(r,c)=>15-r*1.25+c*1.2) },
      fans: { name: 'Fan Temperatures', unit: '°F', rowHeaders: ['Fan 1 On','Fan 1 Off','Fan 2 On','Fan 2 Off'], colHeaders: ['Value'], min: 100, max: 240, values: [[205],[198],[215],[208]] },
      fuel: { name: 'Power Enrichment EQ', unit: 'EQ', rowHeaders: ['2000','2400','2800','3200','3600','4000'], colHeaders: ['40','50','60','70','80','90','100'], min: 0.7, max: 1.6, values: makeGrid(6,7,(r,c)=>1.0+Math.max(0,c-2)*.035+r*.006) },
      transmission: { name: 'WOT Shift RPM', unit: 'RPM', rowHeaders: ['1-2','2-3','3-4'], colHeaders: ['Normal','Performance'], min: 1000, max: 7500, values: [[5400,5600],[5350,5550],[5250,5450]] },
      limits: { name: 'Engine & Speed Limits', unit: '', rowHeaders: ['Rev limiter fuel cut','Rev limiter resume','Speed limiter'], colHeaders: ['Value'], min: 0, max: 8000, values: [[5800],[5700],[130]] }
    },
    stock: null,
    modified: {},
    updatedAt: new Date().toISOString()
  };
}
function loadCalibration() {
  let existing = null;
  try {
    if (fs.existsSync(calibrationFile())) {
      const size = fs.statSync(calibrationFile()).size;
      if (size > 24 * 1024 * 1024) throw new Error(`Calibration workspace is ${Math.round(size / 1024 / 1024)} MB and was isolated to prevent a startup crash.`);
      existing = JSON.parse(fs.readFileSync(calibrationFile(), 'utf8'));
      validateCalibrationWorkspace(existing);
    }
  } catch (error) {
    const backup = `${calibrationFile()}.recovery-${Date.now()}.json`;
    try { fs.renameSync(calibrationFile(), backup); } catch {}
    logCrash('calibration-workspace-recovered', `${error.message} Backup: ${backup}`);
    existing = null;
  }
  if (existing?.tables) return existing;
  const workspace = defaultCalibrationWorkspace();
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  writeJson(calibrationFile(), workspace);
  return workspace;
}
function validateCalibrationWorkspace(payload) {
  if (!payload || typeof payload !== 'object' || !payload.tables || typeof payload.tables !== 'object') {
    throw new Error('Invalid calibration workspace.');
  }
  const entries = Object.entries(payload.tables);
  if (!entries.length || entries.length > 800) throw new Error('Calibration workspace table count is outside the supported range.');
  let cells = 0;
  for (const [key, table] of entries) {
    if (!table || !Array.isArray(table.values) || !table.values.length) throw new Error(`Calibration item ${key} has no value grid.`);
    if (table.values.length > 256) throw new Error(`Calibration item ${key} exceeds the supported 256-row display limit.`);
    const columns = Array.isArray(table.values[0]) ? table.values[0].length : 0;
    if (!columns || columns > 256) throw new Error(`Calibration item ${key} has an unsupported column count.`);
    for (const row of table.values) {
      if (!Array.isArray(row) || row.length !== columns) throw new Error(`Calibration item ${key} contains a non-rectangular value grid.`);
      cells += row.length;
      if (cells > 200000) throw new Error('Calibration workspace is too large to save safely.');
      for (const value of row) if (!Number.isFinite(Number(value))) throw new Error(`Calibration item ${key} contains a non-numeric value.`);
    }
    if (Array.isArray(table.rowHeaders) && table.rowHeaders.length !== table.values.length) throw new Error(`Calibration item ${key} row labels do not match its value grid.`);
    if (Array.isArray(table.colHeaders) && table.colHeaders.length !== columns) throw new Error(`Calibration item ${key} column labels do not match its value grid.`);
  }
  const serialized = JSON.stringify(payload);
  if (Buffer.byteLength(serialized, 'utf8') > 24 * 1024 * 1024) throw new Error('Calibration workspace is too large to save safely.');
  return serialized;
}

ipcMain.handle('calibration:load', async () => loadCalibration());
ipcMain.handle('calibration:save', async (_event, payload) => {
  validateCalibrationWorkspace(payload);
  payload.updatedAt = new Date().toISOString();
  writeJson(calibrationFile(), payload);
  return payload;
});
ipcMain.handle('calibration:revision', async (_event, payload) => {
  const workspace = loadCalibration();
  const rawHistory = readJson(calibrationHistoryFile(), []);
  const history = Array.isArray(rawHistory) ? rawHistory : [];
  const revision = {
    id: `${Date.now()}`,
    name: String(payload?.name || `Revision ${history.length + 1}`),
    note: String(payload?.note || ''),
    at: new Date().toISOString(),
    activeProject: getActiveProject(),
    workspace
  };
  history.unshift(revision);
  writeJson(calibrationHistoryFile(), history.slice(0, 100));
  appendActivity('calibration-revision', { id: revision.id, name: revision.name, project: revision.activeProject?.name || null });
  return revision;
});
ipcMain.handle('calibration:history', async () => {
  const history = readJson(calibrationHistoryFile(), []);
  return Array.isArray(history) ? history : [];
});
ipcMain.handle('calibration:reset', async () => {
  const workspace = defaultCalibrationWorkspace();
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  writeJson(calibrationFile(), workspace);
  return workspace;
});

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

ipcMain.handle('project:import-bin', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'Calibration BIN', extensions: ['bin'] }, { name: 'All files', extensions: ['*'] }]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  const destination = copyProjectFile(source, path.join(active.folder, 'Originals'));
  const info = binInfoFor(destination);
  const updated = updateActiveFiles({ bin: destination, binInfo: info });
  const { active: detectedActive, detection } = applyAutomaticOperatingSystem(updated);
  appendActivity('bin-imported', { ...info, projectId: active.id, detectedOs: detection.detected ? detection.os : null });
  return { ...info, detectedOs: detection.detected ? detection.os : null, osSource: detection.source || null, active: detectedActive };
});

ipcMain.handle('project:import-xdf', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'TunerPro Definition', extensions: ['xdf'] }, { name: 'All files', extensions: ['*'] }]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  const destination = copyProjectFile(source, path.join(active.folder, 'Definitions'));
  const parsed = parseXdf(destination);
  if (!parsed.tables.length) throw new Error('The selected XDF does not contain readable tables or constants.');
  const info = { path: destination, name: path.basename(destination), tableCount: parsed.tables.length, title: parsed.title, warnings: parsed.warnings || [] };
  const updated = updateActiveFiles({ xdf: destination, xdfInfo: info });
  const { active: detectedActive, detection } = applyAutomaticOperatingSystem(updated);
  appendActivity('xdf-imported', { name: info.name, tables: info.tableCount, projectId: active.id, detectedOs: detection.detected ? detection.os : null });
  return { ...info, detectedOs: detection.detected ? detection.os : null, osSource: detection.source || null, active: detectedActive };
});

ipcMain.handle('project:detect-os', async () => {
  const active = requireActive();
  const detection = detectProjectOperatingSystem(active);
  if (!detection.detected) return { ...detection, active };
  const updated = { ...active, os: detection.os, osSource: detection.source };
  persistProjectState(updated);
  appendActivity('os-detected', { projectId: updated.id, projectName: updated.name, os: detection.os, source: detection.source, requested: true });
  return { ...detection, active: updated };
});

ipcMain.handle('project:files', async () => {
  const active = getActiveProject();
  if (!active) return { active: null, bin: null, xdf: null };
  return { active, bin: active.binInfo || null, xdf: active.xdfInfo || null };
});

ipcMain.handle('calibration:load-xdf', async () => {
  const active = requireActive();
  if (!active.bin || !fs.existsSync(active.bin) || !active.xdf || !fs.existsSync(active.xdf)) {
    throw new Error('Import both an original BIN and its matching XDF first.');
  }
  const parsed = parseXdf(active.xdf);
  const bin = fs.readFileSync(active.bin);
  const tables = {};
  let totalCells = 0;
  let skipped = 0;
  for (const definition of parsed.tables) {
    if (definition.unsupportedReason) { skipped += 1; continue; }
    const cells = Math.max(1, Number(definition.rows) || 1) * Math.max(1, Number(definition.cols) || 1);
    if (Object.keys(tables).length >= 800 || totalCells + cells > 200000) {
      skipped += 1;
      continue;
    }
    let key = String(definition.id).replace(/[^a-zA-Z0-9_-]/g, '_') || `item_${Object.keys(tables).length}`;
    while (tables[key]) key = `${key}_${Object.keys(tables).length}`;
    tables[key] = hydrate(definition, bin);
    totalCells += cells;
  }
  if (!Object.keys(tables).length) throw new Error('The XDF did not contain any safely loadable tables or constants.');
  const workspace = {
    mode: 'xdf',
    projectId: active.id,
    sourceBin: active.bin,
    sourceBinSha256: active.binInfo?.sha256 || sha256(active.bin),
    sourceXdf: active.xdf,
    sourceXdfSha256: sha256(active.xdf),
    title: parsed.title,
    activeTable: Object.keys(tables)[0],
    tables,
    stock: JSON.parse(JSON.stringify(tables)),
    modified: {},
    mappingSummary: { loaded: Object.keys(tables).length, skipped, totalCells, warnings: parsed.warnings || [] },
    updatedAt: new Date().toISOString()
  };
  validateCalibrationWorkspace(workspace);
  writeJson(calibrationFile(), workspace);
  appendActivity('xdf-mapping-loaded', { ...workspace.mappingSummary, projectId: active.id });
  return workspace;
});

ipcMain.handle('calibration:export-bin', async (_event, payload) => {
  const active = requireActive();
  const workspace = payload?.tables ? payload : loadCalibration();
  validateCalibrationWorkspace(workspace);
  if (!active.bin || !fs.existsSync(active.bin)) throw new Error('No original BIN is attached to the active project.');
  if (workspace.mode !== 'xdf') throw new Error('Load the active project BIN and XDF before exporting.');
  if (workspace.projectId !== active.id || path.resolve(workspace.sourceBin || '') !== path.resolve(active.bin) || path.resolve(workspace.sourceXdf || '') !== path.resolve(active.xdf || '')) {
    throw new Error('This calibration workspace does not match the active project BIN/XDF pair. Reload the mapping before exporting.');
  }
  const originalHash = sha256(active.bin);
  if (workspace.sourceBinSha256 && workspace.sourceBinSha256 !== originalHash) {
    throw new Error('The protected original BIN changed after the workspace was loaded. Reload the BIN and XDF before exporting.');
  }
  if (workspace.sourceXdfSha256 && workspace.sourceXdfSha256 !== sha256(active.xdf)) {
    throw new Error('The XDF changed after the workspace was loaded. Reload the BIN and XDF before exporting.');
  }
  const buffer = Buffer.from(fs.readFileSync(active.bin));
  const modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
  for (const [tableKey, table] of Object.entries(workspace.tables)) {
    if (table.address == null) continue;
    const changedCells = new Set(
      Object.keys(modified)
        .filter(key => key.startsWith(`${tableKey}:`))
        .map(key => key.slice(tableKey.length + 1))
    );
    if (changedCells.size) applyTable(buffer, table, changedCells);
  }
  fs.mkdirSync(path.join(active.folder, 'Revisions'), { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = path.join(active.folder, 'Revisions', `${path.basename(active.bin, '.bin')}-TunIQ-${stamp}.bin`);
  fs.writeFileSync(output, buffer);
  const info = { path: output, name: path.basename(output), size: buffer.length, sha256: sha256(output), originalSha256: originalHash, modifiedCells: Object.keys(modified).length, at: new Date().toISOString() };
  appendActivity('bin-exported', { ...info, projectId: active.id });
  return info;
});

ipcMain.handle('project:open-folder', async () => {
  const active = requireActive();
  const error = await shell.openPath(active.folder);
  if (error) throw new Error(error);
  return active.folder;
});

