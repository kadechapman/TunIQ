const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');
const crypto = require('crypto');
const { parseXdf, hydrate, applyTable } = require('./xdf');
const { ObdManager, SENSOR_PROFILES } = require('./obd');
const { analyzeBin, compareFiles, parseUniversalPatcherReport, correctDefinitions } = require('./checksum');
const { FlashManager, FlashStopError, parseIdentityText } = require('./flash');
const { generateProposal, applyApproved, saveProposal, listProposals, getProposal } = require('./ai-tune');
const { importPhoneLog, recommendedFields } = require('./log-import');
const { parseTuneRequest, buildGoalProposal, applyGoalApproved } = require('./goal-executor');
const { BetaManager } = require('./beta');
const { UpdateManager } = require('./updater');
const { P01CommissioningManager } = require('./p01-commissioning');
const { P01EvidenceManager } = require('./p01-evidence');
const { P01AutoManager, discoverExactXdfs, selectGoalMapCandidates } = require('./p01-auto');
const { P01LabManager } = require('./p01-lab');
const { normalizeUiPreferences, mergeUiPreferences } = require('./qol');
const { GarageManager, projectVehicleFields, vehicleSnapshot } = require('./garage');
const { TuneWorkspaceManager } = require('./tune-workspace');
const { TuneEngineManager, buildStageProposal, applyStageProposal } = require('./tune-engine');
const { AutonomousTuneManager, deriveAutonomousTargets, executeAutonomousTune } = require('./autonomous-tune');
const { ClosedLoopTuneManager, executeClosedLoopCorrection, analyzeClosedLoopValidation } = require('./closed-loop-tune');
const { scanDefinitionSources, buildXdfFromUniversalTunerXml, createDefinitionJob, inspectDefinitionJob, universalPatcherLayout, isCommissioningOnlyXdf, buildCommissioningOnlyXdf } = require('./definition-pipeline');
const { ensureProtectedOriginal, createOrReuseStockClone, buildFinalizerAudit } = require('./p01-finalizer');
const { HardwareSessionDoctor } = require('./hardware-session-doctor');
const { HardwareSessionGuard } = require('./hardware-session-guard');
const { ProjectSafetyVault } = require('./project-safety-vault');

const { safeIpcResult } = require('./ipc-safe');
const APP_VERSION = '1.8.4';
const RUNTIME_ROOT = path.join(app.getPath('appData'), 'TunIQ', 'Runtime');
try { app.setPath('userData', RUNTIME_ROOT); } catch {}
let mainWindow;
let recoveryWindowAttempts = 0;
let p01AutoManager = null;
let p01AutoTimer = null;
let p01AutoBusy = false;
let hardwareSessionDoctor = null;

function dataRoot() {
  return path.join(app.getPath('appData'), 'TunIQ');
}
function startupLogFile() { return path.join(dataRoot(), 'Logs', 'startup.log'); }
function logStartup(stage, details = '') {
  try {
    fs.mkdirSync(path.join(dataRoot(), 'Logs'), { recursive: true });
    const extra = details ? ` | ${String(details).replace(/\r?\n/g, ' ')}` : '';
    fs.appendFileSync(startupLogFile(), `[${new Date().toISOString()}] ${stage}${extra}\n`, 'utf8');
  } catch {}
}
function legacyDataRoot() {
  return path.join(app.getPath('documents'), 'TunIQ');
}
function copyMissing(source, destination, depth = 0) {
  if (depth > 20 || !fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) continue;
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    try {
      if (entry.isDirectory()) copyMissing(from, to, depth + 1);
      else if (entry.isFile() && !fs.existsSync(to)) fs.copyFileSync(from, to);
    } catch (error) {
      logStartup('migration:item-skipped', `${from}: ${error.message}`);
    }
  }
}
function migrateLegacyData() {
  const marker = path.join(dataRoot(), 'Settings', 'appdata-migration.json');
  if (fs.existsSync(marker)) return readJson(marker, { migrated: false });
  const legacy = legacyDataRoot();
  let result = { migrated: false, source: legacy, destination: dataRoot(), at: new Date().toISOString() };
  try {
    if (fs.existsSync(legacy) && path.resolve(legacy) !== path.resolve(dataRoot())) {
      copyMissing(legacy, dataRoot());
      result.migrated = true;
    }
  } catch (error) { result.error = error.message; }
  writeJson(marker, result);
  return result;
}
function ensureDataFolders() {
  const folders = ['Profile','Vehicles','Projects','Logs','AI','Settings','Backups','Tools','Calibration','Definitions','TuneLibrary','Community','Devices','Reports','Checksums','Beta','Compatibility','P01Evidence','Labs'];
  fs.mkdirSync(dataRoot(), { recursive: true });
  for (const folder of folders) fs.mkdirSync(path.join(dataRoot(), folder), { recursive: true });
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function profileFile() { return path.join(dataRoot(), 'Profile', 'profile.json'); }
function settingsFile() { return path.join(dataRoot(), 'Settings', 'settings.json'); }
function toolsFile() { return path.join(dataRoot(), 'Tools', 'paths.json'); }
function vehiclesFile() { return path.join(dataRoot(), 'Vehicles', 'vehicles.json'); }
function activityFile() { return path.join(dataRoot(), 'Logs', 'activity.json'); }
function activeProjectFile() { return path.join(dataRoot(), 'Settings', 'active-project.json'); }
function appendActivity(type, details = {}) {
  const raw = readJson(activityFile(), []);
  const items = Array.isArray(raw) ? raw : [];
  items.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, type, details, at: new Date().toISOString() });
  writeJson(activityFile(), items.slice(0, 250));
}
function listVehicles() { return garageManager.listWithUsage(); }

function logCrash(label, error) {
  try {
    fs.mkdirSync(path.join(dataRoot(), 'Logs'), { recursive: true });
    const line = `[${new Date().toISOString()}] ${label}\n${error?.stack || error || 'Unknown error'}\n\n`;
    fs.appendFileSync(path.join(dataRoot(), 'Logs', 'desktop-crash.log'), line, 'utf8');
    logStartup(`ERROR:${label}`, error?.message || error || 'Unknown error');
  } catch {}
}
process.on('uncaughtException', error => logCrash('uncaughtException', error));
process.on('unhandledRejection', error => logCrash('unhandledRejection', error));

function createWindow() {
  logStartup('createWindow:start');
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#111714',
    show: false,
    title: `TunIQ ${APP_VERSION}`,
    icon: path.join(__dirname, 'assets', 'tuniq-icon.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      backgroundThrottling: false
    }
  });

  let shown = false;
  const showWindow = () => {
    if (!shown && mainWindow && !mainWindow.isDestroyed()) {
      shown = true;
      mainWindow.show();
      logStartup('window:shown');
    }
  };

  mainWindow.once('ready-to-show', showWindow);
  const showFallback = setTimeout(showWindow, 3500);
  mainWindow.on('closed', () => {
    clearTimeout(showFallback);
    mainWindow = null;
    logStartup('window:closed');
  });
  mainWindow.webContents.on('did-finish-load', () => logStartup('renderer:did-finish-load'));
  mainWindow.webContents.on('preload-error', (_event, preloadPath, error) => logCrash(`preload-error:${preloadPath}`, error));
  mainWindow.webContents.on('render-process-gone', (_event, details) => {
    logCrash('render-process-gone', JSON.stringify(details));
    if (recoveryWindowAttempts < 1 && !app.isQuitting) {
      recoveryWindowAttempts += 1;
      setTimeout(() => {
        if (BrowserWindow.getAllWindows().length === 0) createWindow();
      }, 500);
    }
  });
  mainWindow.webContents.on('did-fail-load', (_event, code, description, url) => logCrash('did-fail-load', `${code} ${description} ${url}`));
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html')).catch(error => {
    logCrash('loadFile', error);
    showWindow();
  });
}

function isExecutableFile(file) {
  try {
    return Boolean(file) && path.extname(file).toLowerCase() === '.exe' && fs.statSync(file).isFile();
  } catch {
    return false;
  }
}

const TOOL_DEFINITIONS = {
  pcmHammer: {
    names: ['pcmhammer.exe', 'pcmhammercli.exe', 'pcmhammer-cli.exe'],
    folders: ['PCM Hammer', 'PcmHammer', 'PCMhammer_2.0.0_Portable', 'PCMhammer']
  },
  tunerPro: {
    names: ['tunerpro.exe'],
    folders: ['TunerPro', 'TunerPro RT']
  },
  universalPatcher: {
    names: ['universalpatcher.exe', 'universal patcher.exe'],
    folders: ['Universal Patcher', 'UniversalPatcher', 'UniversalPatcher-Full']
  }
};

function firstExecutable(candidates) {
  for (const candidate of candidates) {
    if (isExecutableFile(candidate)) return path.resolve(candidate);
  }
  return null;
}

function findExecutableRecursive(root, names, maxDepth = 4, maxEntries = 12000) {
  if (!root || !fs.existsSync(root)) return null;
  const targets = new Set(names.map(name => name.toLowerCase()));
  const queue = [{ folder: root, depth: 0 }];
  let visited = 0;
  const skip = new Set(['node_modules', '.git', '$recycle.bin', 'windows', 'winsxs', 'appdata']);
  while (queue.length && visited < maxEntries) {
    const current = queue.shift();
    let entries;
    try { entries = fs.readdirSync(current.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      visited += 1;
      if (visited >= maxEntries) break;
      const full = path.join(current.folder, entry.name);
      if (entry.isFile() && targets.has(entry.name.toLowerCase()) && isExecutableFile(full)) return path.resolve(full);
      if (entry.isDirectory() && current.depth < maxDepth && !skip.has(entry.name.toLowerCase())) {
        queue.push({ folder: full, depth: current.depth + 1 });
      }
    }
  }
  return null;
}

function commonToolCandidates(key) {
  const definition = TOOL_DEFINITIONS[key];
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const local = process.env.LOCALAPPDATA || '';
  const desktop = app.getPath('desktop');
  const downloads = app.getPath('downloads');
  const roots = [pf, pfx86, local, desktop, downloads];
  const candidates = [];
  for (const root of roots) {
    for (const folder of definition.folders) {
      for (const name of definition.names) {
        candidates.push(path.join(root, folder, name));
        for (const nested of definition.folders) candidates.push(path.join(root, folder, nested, name));
      }
    }
  }
  return candidates;
}

function scanTools(deep = false) {
  const configured = readJson(toolsFile(), {});
  const results = {};
  const deepRoots = [app.getPath('downloads'), app.getPath('desktop'), process.env.LOCALAPPDATA || ''];
  for (const [key, definition] of Object.entries(TOOL_DEFINITIONS)) {
    let found = firstExecutable([configured[key], ...commonToolCandidates(key)]);
    if (!found && deep) {
      for (const root of deepRoots) {
        found = findExecutableRecursive(root, definition.names);
        if (found) break;
      }
    }
    results[key] = found;
  }
  writeJson(toolsFile(), results);
  return results;
}


function projectsRoot() { return path.join(dataRoot(), 'Projects'); }
function projectManifestFile(folder) { return path.join(folder, 'project.json'); }
function removeFileQuietly(file) { try { if (fs.existsSync(file)) fs.unlinkSync(file); } catch {} }
function firstFileWithExtension(folder, extension) {
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && path.extname(entry.name).toLowerCase() === extension)
      .map(entry => ({ path: path.join(folder, entry.name), time: fs.statSync(path.join(folder, entry.name)).mtimeMs }))
      .sort((a, b) => b.time - a.time)[0]?.path || null;
  } catch {
    return null;
  }
}
function binInfoFor(file, existing = null) {
  if (!file || !fs.existsSync(file)) return null;
  const stat = fs.statSync(file);
  if (existing?.path === file && existing.size === stat.size && existing.sha256) return existing;
  return { path: file, name: path.basename(file), size: stat.size, sha256: sha256(file) };
}
function fileShaSafe(file) { try { return sha256(file); } catch { return null; } }
function xdfInfoFor(file, existing = null) {
  if (!file || !fs.existsSync(file)) return null;
  if (existing?.path === file && Number.isFinite(existing.tableCount)) return existing;
  try {
    const parsed = parseXdf(file);
    return { path: file, name: path.basename(file), tableCount: parsed.tables.length, title: parsed.title, warnings: parsed.warnings || [], sha256: fileShaSafe(file), commissioningOnly: isCommissioningOnlyXdf(file), writableTables: isCommissioningOnlyXdf(file) ? 0 : parsed.tables.length };
  } catch (error) {
    return { path: file, name: path.basename(file), tableCount: 0, title: path.basename(file), error: error.message };
  }
}
function osCandidatesFromText(value) {
  const text = String(value || '');
  const matches = [...text.matchAll(/(?:^|\D)(\d{7,9})(?!\d)/g)].map(match => match[1]);
  return [...new Set(matches)].filter(candidate => {
    const numeric = Number(candidate);
    return Number.isFinite(numeric) && numeric > 1000000 && numeric < 999999999;
  });
}
function detectProjectOperatingSystem(active) {
  if (!active) return { detected: false, os: '', source: '', message: 'Create or activate a project first.' };
  const sources = [
    ['XDF title', active.xdfInfo?.title],
    ['XDF filename', active.xdfInfo?.name || (active.xdf ? path.basename(active.xdf) : '')],
    ['BIN filename', active.binInfo?.name || (active.bin ? path.basename(active.bin) : '')]
  ];
  for (const [source, value] of sources) {
    const candidate = osCandidatesFromText(value)[0];
    if (candidate) return { detected: true, os: candidate, source, message: `Detected OS ${candidate} from ${source}.` };
  }
  return {
    detected: false,
    os: active.os || '',
    source: active.osSource || '',
    message: 'No operating-system number was found yet. Leave it blank until PCM identification or a clearly named matching XDF is available.'
  };
}
function applyAutomaticOperatingSystem(active) {
  if (!active || (active.os && active.osSource === 'manual')) return { active, detection: detectProjectOperatingSystem(active) };
  const detection = detectProjectOperatingSystem(active);
  if (!detection.detected) return { active, detection };
  const updated = { ...active, os: detection.os, osSource: detection.source };
  persistProjectState(updated);
  appendActivity('os-detected', { projectId: updated.id, projectName: updated.name, os: detection.os, source: detection.source });
  return { active: updated, detection };
}

function hydrateProjectRecord(manifest, folder, selectedAt = null) {
  if (!manifest || !folder || !fs.existsSync(folder)) return null;
  const originals = path.join(folder, 'Originals');
  const definitions = path.join(folder, 'Definitions');
  const storedBin = manifest.bin && fs.existsSync(manifest.bin) ? manifest.bin : null;
  const storedXdf = manifest.xdf && fs.existsSync(manifest.xdf) ? manifest.xdf : null;
  const bin = storedBin || firstFileWithExtension(originals, '.bin');
  const xdf = storedXdf || firstFileWithExtension(definitions, '.xdf') || firstFileWithExtension(folder, '.xdf');
  const vehicleFields = projectVehicleFields(manifest, garageManager.list());
  return {
    id: manifest.id,
    name: manifest.name,
    folder,
    ...vehicleFields,
    controller: manifest.controller || '',
    os: manifest.os || '',
    osSource: manifest.osSource || '',
    notes: manifest.notes || '',
    selectedAt: selectedAt || new Date().toISOString(),
    bin: bin || null,
    binInfo: binInfoFor(bin, manifest.binInfo),
    xdf: xdf || null,
    xdfInfo: xdfInfoFor(xdf, manifest.xdfInfo)
  };
}
function getActiveProject() {
  const raw = readJson(activeProjectFile(), null);
  if (!raw?.id) return null;
  const folder = raw.folder || path.join(projectsRoot(), raw.id);
  const manifest = readJson(projectManifestFile(folder), null);
  const active = hydrateProjectRecord(manifest, folder, raw.selectedAt);
  if (!active) {
    removeFileQuietly(activeProjectFile());
    logStartup('active-project:cleared', raw?.id || 'invalid');
    return null;
  }
  persistProjectState(active);
  return active;
}
function persistProjectState(active) {
  if (!active?.id || !active?.folder) throw new Error('Project state is invalid.');
  const manifestFile = projectManifestFile(active.folder);
  const manifest = readJson(manifestFile, {});
  const updatedManifest = {
    ...manifest,
    id: active.id,
    name: active.name,
    vehicleId: active.vehicleId || '',
    vehicle: active.vehicle || '',
    vehicleSnapshot: active.vehicleSnapshot || manifest.vehicleSnapshot || null,
    controller: active.controller || '',
    os: active.os || '',
    osSource: active.osSource || manifest.osSource || '',
    notes: active.notes || manifest.notes || '',
    bin: active.bin || null,
    binInfo: active.binInfo || null,
    xdf: active.xdf || null,
    xdfInfo: active.xdfInfo || null,
    updatedAt: new Date().toISOString()
  };
  writeJson(manifestFile, updatedManifest);
  writeJson(activeProjectFile(), active);
  return active;
}
function requireActive() {
  const active = getActiveProject();
  if (!active) throw new Error('Create or activate a project first.');
  return active;
}
function updateActiveFiles(patch) {
  const active = { ...requireActive(), ...patch, updatedAt: new Date().toISOString() };
  return persistProjectState(active);
}
function copyProjectFile(source, destinationFolder) {
  fs.mkdirSync(destinationFolder, { recursive: true });
  const parsed = path.parse(source);
  let destination = path.join(destinationFolder, parsed.base);
  if (fs.existsSync(destination)) {
    try {
      if (sha256(source) === sha256(destination)) return destination;
    } catch {}
    let index = 2;
    do {
      destination = path.join(destinationFolder, `${parsed.name}-${index}${parsed.ext}`);
      index += 1;
    } while (fs.existsSync(destination));
  }
  fs.copyFileSync(source, destination);
  return destination;
}

function projectReportsRoot(active) { const folder = path.join(active.folder, 'Reports'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function projectChecksumsRoot(active) { const folder = path.join(active.folder, 'Checksums'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function projectAiCyclesRoot(active) { const folder = path.join(active.folder, 'AI', 'CalibrationCycles'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function listAiCycles(active) { return listFilesSafe(projectAiCyclesRoot(active), ['.json']).map(item => readJson(item.path, null)).filter(Boolean); }
function projectGoalRequestsRoot(active) { const folder = path.join(active.folder, 'AI', 'GoalRequests'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function saveGoalRequest(active, proposal) { const file = path.join(projectGoalRequestsRoot(active), `${proposal.id}.json`); writeJson(file, proposal); return { ...proposal, file }; }
function getGoalRequest(active, id) { const file = path.join(projectGoalRequestsRoot(active), `${id}.json`); const item = readJson(file, null); return item ? { ...item, file } : null; }
function listGoalRequests(active) { return listFilesSafe(projectGoalRequestsRoot(active), ['.json']).map(item => { const value = readJson(item.path, null); return value ? { ...value, file: item.path } : null; }).filter(Boolean); }
function latestValidationReport(active) {
  if (!active) return null;
  const files = listFilesSafe(projectReportsRoot(active), ['.json']);
  for (const file of files) {
    const report = readJson(file.path, null);
    if (report?.type === 'revision-validation' || report?.type === 'bin-analysis') return { ...report, file: file.path };
  }
  return null;
}
function latestRevisionFile(active) { return active ? listFilesSafe(path.join(active.folder, 'Revisions'), ['.bin'])[0]?.path || null : null; }

function listFilesSafe(folder, extensions = null, limit = 250) {
  if (!folder || !fs.existsSync(folder)) return [];
  const allowed = extensions ? new Set(extensions.map(ext => ext.toLowerCase())) : null;
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile())
      .map(entry => {
        const file = path.join(folder, entry.name);
        const stat = fs.statSync(file);
        return {
          name: entry.name,
          path: file,
          extension: path.extname(entry.name).toLowerCase(),
          size: stat.size,
          modifiedAt: stat.mtime.toISOString()
        };
      })
      .filter(item => !allowed || allowed.has(item.extension))
      .sort((a, b) => String(b.modifiedAt).localeCompare(String(a.modifiedAt)))
      .slice(0, limit);
  } catch (error) {
    logStartup('workspace:list-files-failed', `${folder}: ${error.message}`);
    return [];
  }
}

function buildTunePath(active, files, calibration, tools) {
  const aiBundle = active ? loadAiBundle(active) : { intake: null, plan: null };
  const fullAiEnabled = readJson(settingsFile(), {}).aiMode === 'full-ai';
  const calibrationReady = Boolean(
    active && calibration?.mode === 'xdf' && calibration?.projectId === active.id &&
    calibration?.sourceBin && calibration?.sourceXdf
  );
  const deviceStatus = obdManager.getStatus();
  const preferredDevice = deviceStatus.preferred?.port;
  const hasRevision = files.revisions.some(file => file.extension === '.bin');
  const hasBaselineLog = files.logs.some(file => file.extension === '.csv');
  const validation = active ? latestValidationReport(active) : null;
  const flashStatus = flashManager?.status?.() || { configured: false, capabilities: {} };
  const validationPassed = Boolean(validation && validation.compatible !== false && !['invalid','failed'].includes(validation.checksumStatus || validation.nativeChecksumStatus));
  const definitions = [
    { id: 'project', title: 'Create or select project', page: 'workflow', target: '#projectForm', complete: Boolean(active), description: active ? active.name : 'Vehicle, controller, and build notes; OS can be detected later' },
    { id: 'controller', title: 'Confirm controller', page: 'workflow', target: '#projectController', complete: Boolean(active?.controller), description: active?.controller ? `${active.controller}${active.os ? ` / OS ${active.os}` : ' / OS auto-detect pending'}` : 'Choose the PCM/ECM family; OS can be detected later' },
    { id: 'device', title: 'Connect a diagnostic adapter', page: 'devices', target: '#deviceScan', complete: Boolean(preferredDevice), description: deviceStatus.connected ? `${deviceStatus.connection.adapter} connected` : preferredDevice ? `${preferredDevice} saved; reconnect when the vehicle is ready` : 'Pair the OBDLink MX+ in Windows, then scan its COM port' },
    ...(fullAiEnabled ? [{ id: 'ai-intake', title: 'Describe the build and tune goal', page: 'fullai', target: '#fullAiForm', complete: Boolean(aiBundle.intake?.completedAt && aiBundle.plan?.steps?.length), description: aiBundle.intake?.tuneGoal || 'Full AI asks only the questions needed for this build' }] : []),
    { id: 'original', title: 'Import protected original BIN', page: 'files', target: '#importBin', complete: Boolean(active?.bin), description: active?.binInfo?.name || 'Preserve the stock read first' },
    { id: 'definition', title: 'Resolve exact calibration definition', page: 'files', target: '#definitionScan', complete: Boolean(active?.xdf && !active?.xdfInfo?.error), description: active?.xdfInfo?.name || 'Definition Center scans XDF sources and Universal Patcher table data for the exact OS' },
    { id: 'baseline-log', title: 'Record a baseline live log', page: 'scanner', target: '#logStart', complete: hasBaselineLog, description: hasBaselineLog ? `${files.logs.filter(file => file.extension === '.csv').length} drive log(s) saved` : 'Warm the vehicle, record the problem area, and mark the event' },
    { id: 'calibration', title: 'Load calibration mapping', page: 'sandbox', target: '#labLoadXdf', complete: calibrationReady, description: calibrationReady ? `${Object.keys(calibration.tables || {}).length} items mapped` : 'Open the active BIN and XDF together' },
    { id: 'revision', title: 'Export a revision BIN', page: 'sandbox', target: '#labExportBin', complete: hasRevision, description: hasRevision ? `${files.revisions.filter(file => file.extension === '.bin').length} revision BIN(s)` : 'Never overwrite the protected original' },
    { id: 'validate', title: 'Review checksums and changes', page: 'patches', target: '#patchAnalyze', complete: validationPassed, description: validationPassed ? 'Latest revision passed size, segment, and available checksum validation' : 'Analyze the original/revision pair and import a Universal Patcher report when required' },
    { id: 'flash', title: 'Run controlled flash operation', page: 'flash', target: '#flashProbe', complete: false, locked: !flashStatus.configured, description: flashStatus.configured ? 'PCM Hammer CLI operations are capability-probed and confirmation-gated' : 'Install and probe PCM Hammer CLI to enable read/write operations' }
  ];
  let foundCurrent = false;
  return definitions.map(step => {
    let status = step.complete ? 'complete' : step.locked ? 'locked' : 'waiting';
    if (!step.complete && !step.locked && !foundCurrent) {
      status = 'current';
      foundCurrent = true;
    }
    return { ...step, status };
  });
}

function getWorkspaceSummary() {
  const active = getActiveProject();
  const tools = scanTools(false);
  const folders = active ? {
    originals: path.join(active.folder, 'Originals'),
    definitions: path.join(active.folder, 'Definitions'),
    revisions: path.join(active.folder, 'Revisions'),
    logs: path.join(active.folder, 'Logs'),
    backups: path.join(active.folder, 'Backups'),
    reports: path.join(active.folder, 'Reports'),
    checksums: path.join(active.folder, 'Checksums')
  } : {};
  const files = {
    originals: active ? listFilesSafe(folders.originals) : [],
    definitions: active ? listFilesSafe(folders.definitions) : [],
    revisions: active ? listFilesSafe(folders.revisions) : [],
    logs: active ? listFilesSafe(folders.logs) : [],
    backups: active ? listFilesSafe(folders.backups) : [],
    reports: active ? listFilesSafe(folders.reports) : [],
    checksums: active ? listFilesSafe(folders.checksums) : []
  };
  let calibration = null;
  let calibrationHistory = [];
  if (active) {
    try { calibration = loadCalibration(); calibrationHistory = tuneWorkspaceManager.history(active); }
    catch (error) { logStartup('workspace-summary:calibration-unavailable', error.message); }
  }
  const activity = (() => {
    const items = readJson(activityFile(), []);
    return (Array.isArray(items) ? items : [])
      .filter(item => !active || !item.details?.projectId || item.details.projectId === active.id || item.details?.activeProjectId === active.id)
      .slice(0, 40);
  })();
  const steps = buildTunePath(active, files, calibration, tools);
  const completed = steps.filter(step => step.status === 'complete').length;
  return {
    generatedAt: new Date().toISOString(),
    activeProject: active,
    tools,
    files,
    folders,
    activity,
    calibration: calibration ? {
      mode: calibration.mode || 'local',
      projectId: calibration.projectId || null,
      tableCount: Object.keys(calibration.tables || {}).length,
      modifiedCells: Object.keys(calibration.modified || {}).length,
      mappingSummary: calibration.mappingSummary || null
    } : null,
    calibrationHistory,
    tunePath: {
      steps,
      completed,
      total: steps.length,
      progress: steps.length ? Math.round((completed / steps.length) * 100) : 0
    },
    ai: active ? loadAiBundle(active) : { intake: null, plan: null },
    libraryCount: listTuneLibrary().length,
    communityCount: listCommunityPosts().length,
    device: obdManager.getStatus(),
    liveLogs: obdManager.listLogs(),
    sensorProfiles: SENSOR_PROFILES,
    flash: flashManager.status(),
    p01: active ? p01Manager.status(active, latestRevisionFile(active)) : null,
    p01Auto: active && p01AutoManager ? p01AutoSnapshot(p01AutoManager.load(active)) : null,
    validation: active ? latestValidationReport(active) : null,
    aiProposals: active ? listProposals(active) : [],
    beta: betaManager ? betaManager.state() : null,
    updates: updateManager ? updateManager.status() : null,
    definitionCenter: active ? definitionCenterState(active, false) : null,
    integrations: {
      pcmHammer: { ...flashManager.status(), mode: 'managed-cli', writeLocked: !flashManager.status().capabilities?.writeCalibration },
      tunerPro: { configured: isExecutableFile(tools.tunerPro), mode: 'optional-managed-roundtrip', nativeEditor: true },
      universalPatcher: { ...universalPatcherLayout(tools.universalPatcher), configured: isExecutableFile(tools.universalPatcher), mode: 'definition-database-and-managed-validation', writeLocked: false }
    }
  };
}



// TunIQ AI/community foundation, extended by 1.6 controlled tuning and connected diagnostics.
function aiProjectFolder(active) {
  const folder = path.join(active.folder, 'AI');
  fs.mkdirSync(folder, { recursive: true });
  return folder;
}
function aiIntakeFile(active) { return path.join(aiProjectFolder(active), 'intake.json'); }
function aiPlanFile(active) { return path.join(aiProjectFolder(active), 'plan.json'); }
function cleanText(value, max = 5000) { return String(value || '').trim().slice(0, max); }
function cleanList(value, limit = 50) {
  const list = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(list.map(item => cleanText(item, 120)).filter(Boolean))].slice(0, limit);
}
function normalizeAiIntake(payload, active) {
  const cam = payload?.cam && typeof payload.cam === 'object' ? payload.cam : {};
  return {
    projectId: active.id,
    projectName: active.name,
    vehicle: cleanText(payload?.vehicle || active.vehicle, 160),
    year: cleanText(payload?.year, 12),
    make: cleanText(payload?.make, 80),
    model: cleanText(payload?.model, 100),
    engine: cleanText(payload?.engine, 160),
    engineFamily: cleanText(payload?.engineFamily, 80),
    engineDisplacement: cleanText(payload?.engineDisplacement, 40),
    engineCode: cleanText(payload?.engineCode, 80),
    engineCustom: cleanText(payload?.engineCustom, 160),
    transmission: cleanText(payload?.transmission, 120),
    controller: cleanText(payload?.controller || active.controller, 80),
    operatingSystem: cleanText(payload?.operatingSystem || active.os, 80),
    fuel: cleanText(payload?.fuel, 80),
    aspiration: cleanText(payload?.aspiration, 80),
    tuneGoal: cleanText(payload?.tuneGoal, 100),
    drivingUse: cleanText(payload?.drivingUse, 100),
    modifications: cleanList(payload?.modifications, 60),
    injectorData: cleanText(payload?.injectorData, 500),
    gearRatio: cleanText(payload?.gearRatio, 30),
    tireSize: cleanText(payload?.tireSize, 40),
    converterStall: cleanText(payload?.converterStall, 40),
    boostPsi: cleanText(payload?.boostPsi, 30),
    desiredIdle: cleanText(payload?.desiredIdle, 40),
    optionalDetails: {
      gearRatio: cleanText(payload?.gearRatio, 30) ? 'confirmed-or-user-entered' : 'unknown',
      tireSize: cleanText(payload?.tireSize, 40) ? 'confirmed-or-user-entered' : 'unknown',
      converterStall: cleanText(payload?.converterStall, 40) ? 'confirmed-or-user-entered' : 'unknown',
      desiredIdle: cleanText(payload?.desiredIdle, 40) ? 'confirmed-or-user-entered' : 'unknown'
    },
    symptoms: cleanText(payload?.symptoms, 2500),
    notes: cleanText(payload?.notes, 5000),
    cam: {
      brand: cleanText(cam.brand, 80),
      partNumber: cleanText(cam.partNumber, 80),
      durationIntake: cleanText(cam.durationIntake, 30),
      durationExhaust: cleanText(cam.durationExhaust, 30),
      liftIntake: cleanText(cam.liftIntake, 30),
      liftExhaust: cleanText(cam.liftExhaust, 30),
      lsa: cleanText(cam.lsa, 30),
      icl: cleanText(cam.icl, 30)
    },
    updatedAt: new Date().toISOString(),
    completedAt: new Date().toISOString()
  };
}
function buildFullAiPlan(active, intake) {
  const mods = new Set((intake?.modifications || []).map(item => item.toLowerCase()));
  const goal = String(intake?.tuneGoal || '').toLowerCase();
  const hasCam = mods.has('aftermarket camshaft') || goal.includes('camshaft');
  const ghostCam = goal.includes('ghost-cam') || goal.includes('ghost cam');
  const hasBoost = ['turbo','supercharger','forced induction'].some(item => mods.has(item) || String(intake?.aspiration || '').toLowerCase().includes(item));
  const hasTransmission = Boolean(intake?.transmission);
  const projectLogs = listFilesSafe(path.join(active.folder, 'Logs'), ['.csv']);
  const steps = [
    { id: 'intake', title: 'Confirm vehicle build and goal', type: 'review', reason: 'The AI plan must match the exact hardware and intended use.', complete: true },
    { id: 'identify', title: 'Identify PCM/TCM and operating system', type: 'controller', reason: 'Definition, segment, checksum, and flash support depend on exact controller identity.', complete: Boolean(active.controller && active.os) },
    { id: 'read', title: 'Read and protect the original calibration', type: 'flash', reason: 'A verified stock recovery file must exist before any tune changes.', complete: Boolean(active.bin) },
    { id: 'baseline', title: 'Run baseline diagnostics and log', type: 'diagnostics', reason: 'Mechanical, sensor, fuel-delivery, and wiring problems should be fixed before tuning.', complete: projectLogs.length > 0, evidence: projectLogs[0]?.name || null },
    { id: 'fuel-system', title: 'Validate injectors and fuel-system data', type: 'calibration', reason: 'Incorrect injector data can corrupt idle, transient, and load fueling.', complete: false }
  ];
  if (hasCam || ghostCam) steps.push(
    { id: 'cam-idle', title: 'Build camshaft idle-airflow strategy', type: 'calibration', reason: 'Cam overlap changes airflow demand, vacuum, idle spark authority, and startup behavior.', complete: false },
    { id: 'cam-diagnostics', title: 'Review cam-related diagnostics and airflow limits', type: 'calibration', reason: 'Only hardware-related diagnostics should be adjusted, never used to hide mechanical faults.', complete: false }
  );
  if (hasBoost) steps.push({ id: 'boost-safety', title: 'Validate boost, fuel pressure, MAP range, and enrichment safety', type: 'safety', reason: 'Forced-induction tuning requires verified fuel supply and conservative load protection.', complete: false });
  steps.push(
    { id: 'airflow', title: 'Calibrate MAF and/or VE airflow model', type: 'calibration', reason: 'The PCM must correctly calculate cylinder airmass before spark and fueling optimization.', complete: false },
    { id: 'fueling', title: 'Calibrate commanded fueling and power enrichment', type: 'calibration', reason: 'Target fueling must match fuel type, load, hardware, and measured wideband data.', complete: false },
    { id: 'spark', title: 'Optimize spark with knock and temperature safeguards', type: 'calibration', reason: 'Timing changes require repeatable logs and must preserve knock protection.', complete: false }
  );
  if (hasTransmission) {
    const knownDrivetrain = [intake.gearRatio && `gear ${intake.gearRatio}`, intake.tireSize && `tires ${intake.tireSize}`, intake.converterStall && `converter ${intake.converterStall}`].filter(Boolean);
    steps.push({ id: 'transmission', title: 'Review shift, torque-management, and converter behavior', type: 'transmission', reason: knownDrivetrain.length ? `The ${intake.transmission} calibration will use the confirmed ${knownDrivetrain.join(', ')} and intended use.` : `The ${intake.transmission} calibration can begin without guessing gear ratio, tire size, or converter stall. Add those details later if speedometer, shift scheduling, or converter behavior requires them.`, complete: false });
  }
  steps.push(
    { id: 'validate', title: 'Validate changes, checksums, and compatibility', type: 'validation', reason: 'Every proposed change must be reviewable and tied to the original BIN.', complete: false },
    { id: 'revision', title: 'Create a named AI tune revision', type: 'revision', reason: 'Full AI always creates a new revision and never overwrites the original.', complete: false },
    { id: 'flash', title: 'Prepare controlled flash confirmation', type: 'flash', reason: 'The user must confirm controller, file, voltage, interface, backup, and recovery status.', complete: false, locked: true },
    { id: 'verify', title: 'Run post-flash checks and follow-up log', type: 'diagnostics', reason: 'The AI should verify results and revise from measured data instead of guessing.', complete: false, locked: true }
  );
  return {
    id: `${Date.now()}-ai-plan`,
    projectId: active.id,
    projectName: active.name,
    goal: intake.tuneGoal || 'Custom tune',
    mode: 'full-ai-approval-gated-calibration-cycles',
    generatedAt: new Date().toISOString(),
    optionalDetails: {
      known: [['gearRatio', intake.gearRatio], ['tireSize', intake.tireSize], ['converterStall', intake.converterStall], ['desiredIdle', intake.desiredIdle]].filter(([, value]) => Boolean(value)).map(([key]) => key),
      unknown: [['gearRatio', intake.gearRatio], ['tireSize', intake.tireSize], ['converterStall', intake.converterStall], ['desiredIdle', intake.desiredIdle]].filter(([, value]) => !value).map(([key]) => key),
      policy: 'Unknown optional values remain blank. TunIQ does not silently assume stock specifications.'
    },
    warnings: [
      'This development build creates the structured plan but does not autonomously alter or flash a controller.',
      'Mechanical faults, missing injector data, or unsafe logs must block automatic calibration changes.',
      'Controller writing always requires explicit user confirmation.'
    ],
    steps
  };
}
function loadAiBundle(active = getActiveProject()) {
  if (!active) return { intake: null, plan: null };
  return { intake: readJson(aiIntakeFile(active), null), plan: readJson(aiPlanFile(active), null) };
}

function tuneLibraryRoot() { const folder = path.join(dataRoot(), 'TuneLibrary'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function tuneLibraryFilesRoot() { const folder = path.join(tuneLibraryRoot(), 'Files'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function tuneLibraryFile() { return path.join(tuneLibraryRoot(), 'library.json'); }
function listTuneLibrary() { const value = readJson(tuneLibraryFile(), []); return Array.isArray(value) ? value : []; }
function latestTuneSource(active) {
  const revisions = listFilesSafe(path.join(active.folder, 'Revisions'), ['.bin']);
  return revisions[0]?.path || (active.bin && fs.existsSync(active.bin) ? active.bin : null);
}
function safeTuneName(value) { return cleanText(value, 120).replace(/[<>:"/\\|?*]/g, '-'); }
function saveTuneToLibrary(payload) {
  const active = requireActive();
  const source = latestTuneSource(active);
  if (!source) throw new Error('Import an original BIN or export a revision before saving a tune to the library.');
  const name = safeTuneName(payload?.name || `${active.name} Tune`);
  if (!name) throw new Error('Tune name is required.');
  const id = `${Date.now()}-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`;
  const destination = path.join(tuneLibraryFilesRoot(), `${id}${path.extname(source).toLowerCase() || '.bin'}`);
  fs.copyFileSync(source, destination);
  const ai = loadAiBundle(active).intake;
  const entry = {
    id, name,
    description: cleanText(payload?.description, 3000),
    engine: cleanText(payload?.engine || ai?.engine, 120),
    transmission: cleanText(payload?.transmission || ai?.transmission, 120),
    controller: cleanText(payload?.controller || active.controller, 80),
    os: cleanText(payload?.os || active.os, 80),
    fuel: cleanText(payload?.fuel || ai?.fuel, 80),
    tuneGoal: cleanText(payload?.tuneGoal || ai?.tuneGoal, 100),
    modifications: cleanList(payload?.modifications || ai?.modifications, 60),
    tags: cleanList(payload?.tags, 30),
    favorite: false,
    sourceProjectId: active.id,
    sourceProjectName: active.name,
    sourceFile: destination,
    sourceFileName: path.basename(destination),
    sourceSha256: sha256(destination),
    sourceWasRevision: path.dirname(source) === path.join(active.folder, 'Revisions'),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  const items = listTuneLibrary(); items.unshift(entry); writeJson(tuneLibraryFile(), items);
  appendActivity('tune-library-saved', { id, name, projectId: active.id, sourceFileName: entry.sourceFileName });
  return entry;
}
function getTuneEntry(id) { return listTuneLibrary().find(item => item.id === id) || null; }
function tuneCompatibility(entry, active) {
  const problems = [];
  if (entry.controller && !active.controller) problems.push('Identify the active project controller before importing this tune');
  else if (entry.controller && active.controller && entry.controller.toLowerCase() !== active.controller.toLowerCase()) problems.push(`Controller mismatch: ${entry.controller} vs ${active.controller}`);
  if (entry.os && !active.os) problems.push('Detect the active project operating system before importing this tune');
  else if (entry.os && active.os && entry.os.toLowerCase() !== active.os.toLowerCase()) problems.push(`Operating-system mismatch: ${entry.os} vs ${active.os}`);
  return { compatible: problems.length === 0, problems, status: problems.length ? 'incompatible' : (entry.controller && active.controller ? 'compatible' : 'review') };
}

function communityRoot() { const folder = path.join(dataRoot(), 'Community'); fs.mkdirSync(folder, { recursive: true }); return folder; }
function communityPostsFile() { return path.join(communityRoot(), 'posts.json'); }
function defaultCommunityPosts() {
  const at = new Date().toISOString();
  return [
    { id: 'official-welcome', official: true, category: 'Guide', title: 'How to create a useful troubleshooting post', engine: 'Any', transmission: 'Any', controller: 'Any', body: 'Attach the controller, operating system, DTCs, exact symptoms, modifications, and a log from the conditions where the problem occurs.', author: 'TunIQ', createdAt: at, tags: ['posting','diagnostics'] },
    { id: 'official-p01-cam', official: true, category: 'Guide', title: 'P01/P59 camshaft tune intake checklist', engine: 'Gen III LS', transmission: 'Any', controller: 'P01 / P59', body: 'Record cam specifications, injector data, intake and exhaust setup, transmission, converter, gear ratio, tire size, fuel, desired idle, and a baseline log before changing airflow tables.', author: 'TunIQ', createdAt: at, tags: ['cam','idle','p01','p59'] },
    { id: 'official-tune-safety', official: true, category: 'Community Tunes', title: 'Why community tunes are imported as revisions', engine: 'Any', transmission: 'Any', controller: 'Any', body: 'TunIQ checks controller and OS compatibility, preserves the protected original, and imports a tune as a new revision. Community files never replace the stock read.', author: 'TunIQ', createdAt: at, tags: ['safety','compatibility'] }
  ];
}
function listCommunityPosts() {
  let posts = readJson(communityPostsFile(), null);
  if (!Array.isArray(posts)) { posts = defaultCommunityPosts(); writeJson(communityPostsFile(), posts); }
  return posts;
}


const garageManager = new GarageManager({
  dataRoot,
  projectsRoot,
  readJson,
  writeJson,
  appendActivity
});

const tuneWorkspaceManager = new TuneWorkspaceManager({
  legacyWorkspaceFile: () => path.join(dataRoot(), 'Calibration', 'workspace.json'),
  legacyHistoryFile: () => path.join(dataRoot(), 'Calibration', 'history.json'),
  appendActivity
});

const tuneEngineManager = new TuneEngineManager({ appendActivity });
const autonomousTuneManager = new AutonomousTuneManager({ appendActivity });
const closedLoopTuneManager = new ClosedLoopTuneManager({ appendActivity });

const obdManager = new ObdManager({
  dataRoot: dataRoot,
  getActiveProject,
  appendActivity,
  logStartup
});

const p01LabManager = new P01LabManager({
  dataRoot,
  appendActivity
});

const p01Manager = new P01CommissioningManager({
  getActiveProject,
  getCalibrationWorkspace: () => loadCalibration(),
  getFlashStatus: () => flashManager?.status?.() || {},
  appendActivity
});

const p01EvidenceManager = new P01EvidenceManager({
  dataRoot,
  getActiveProject,
  appendActivity
});

const hardwareSessionGuard = new HardwareSessionGuard({ dataRoot });
const projectSafetyVault = new ProjectSafetyVault({ dataRoot, getActiveProject, retention: 8 });

const flashManager = new FlashManager({
  dataRoot,
  getActiveProject,
  getToolPath: key => scanTools(false)?.[key] || null,
  getDeviceStatus: () => obdManager.getStatus(),
  releasePort: details => obdManager.releaseForExternalTool(details),
  probePortLock: details => obdManager.probePortLock(details),
  findAlternatePorts: port => obdManager.findRecoveryPorts(port),
  abortBridgeRequests: reason => obdManager.abortBridgeRequests(reason),
  inspectExclusiveSession: details => hardwareSessionGuard.inspect(details),
  createSafetySnapshot: (reason, options) => projectSafetyVault.create(reason, options),
  registerOwnedProcess: (pid, executable, sessionId) => hardwareSessionGuard.registerOwnedProcess(pid, executable, sessionId),
  releaseOwnedProcess: pid => hardwareSessionGuard.releaseOwnedProcess(pid),
  appendActivity,
  emit: (channel, payload) => {
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(channel, payload);
  },
  onReadComplete: async (file, info, session) => {
    const active = requireActive();
    const destination = path.resolve(file).startsWith(path.resolve(path.join(active.folder, 'Originals')) + path.sep)
      ? file : copyProjectFile(file, path.join(active.folder, 'Originals'));
    const readRecord = p01Manager.recordRead(destination, info, session);
    const verified = Boolean(readRecord?.status?.dualReadVerified && readRecord.canonicalPath);
    const binInfo = binInfoFor(destination, info);
    if (verified) {
      const protectedPath = readRecord.canonicalPath;
      const protectedInfo = binInfoFor(protectedPath, info);
      if (active.binInfo?.sha256 && active.binInfo.sha256 !== protectedInfo.sha256) tuneWorkspaceManager.invalidate(active, 'A newly verified protected original replaced the previous BIN fingerprint.');
      const updated = updateActiveFiles({ bin: protectedPath, binInfo: protectedInfo });
      applyAutomaticOperatingSystem(updated);
    }
    appendActivity('pcm-read-imported', { projectId: active.id, projectName: active.name, ...binInfo, dualReadVerified: verified, pairStatus: readRecord?.pairStatus || null });
    return { ...binInfo, protectedOriginalInstalled: verified };
  },
  onIdentifyComplete: async (identity, session) => {
    const active = requireActive();
    const patch = {};
    if (identity.controller) patch.controller = identity.controller.toUpperCase();
    if (identity.os) { patch.os = identity.os; patch.osSource = 'PCM Hammer Read Properties'; }
    if (Object.keys(patch).length) updateActiveFiles(patch);
    if (active.vehicleId) {
      const linkedVehicle = garageManager.list().find(item => item.id === active.vehicleId);
      if (linkedVehicle) garageManager.save({ ...linkedVehicle, controller: identity.controller || linkedVehicle.controller, os: identity.os || linkedVehicle.os, hardwareId: identity.hardwareId || linkedVehicle.hardwareId, serviceNumber: identity.serviceNumber || linkedVehicle.serviceNumber });
    }
    p01Manager.recordIdentity(identity, session);
    const file = path.join(projectReportsRoot(active), `controller-identity-${Date.now()}.json`);
    writeJson(file, { type: 'controller-identity', projectId: active.id, projectName: active.name, ...identity, at: new Date().toISOString() });
    appendActivity('controller-identified', { projectId: active.id, projectName: active.name, ...identity });
  },
  onSessionComplete: async session => {
    p01Manager.recordFlashSession(session);
    if (p01AutoManager) await handleP01AutoFlashComplete(session);
  }
});

p01AutoManager = new P01AutoManager({ getActiveProject, appendActivity });
hardwareSessionDoctor = new HardwareSessionDoctor({
  appVersion: APP_VERSION,
  dataRoot,
  getActiveProject,
  getFlashStatus: () => flashManager.status(),
  getP01AutoState: () => p01AutoManager?.load?.() || null,
  getP01Status: active => {
    const auto = p01AutoManager?.load?.(active) || null;
    return p01Manager.status(active, auto?.revision?.path || null);
  },
  appendActivity
});

const betaManager = new BetaManager({
  appVersion: APP_VERSION,
  dataRoot,
  getActiveProject,
  getSettings: () => readJson(settingsFile(), {}),
  getDeviceStatus: () => obdManager.getStatus(),
  getWorkspaceSummary: () => getWorkspaceSummary(),
  getFlashStatus: () => flashManager.status(),
  getActivity: () => { const value = readJson(activityFile(), []); return Array.isArray(value) ? value : []; },
  appendActivity
});

const updateManager = new UpdateManager({
  getPreferences: () => betaManager.preferences(),
  isPackaged: () => app.isPackaged,
  emit: payload => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('update:status', payload); }
});

function activeChecksumDefinitions(active) {
  if (!active?.xdf || !fs.existsSync(active.xdf)) return [];
  try { return parseXdf(active.xdf).checksums || []; } catch { return []; }
}
function latestExternalChecksumReport(active, targetSha256 = '') {
  const files = listFilesSafe(projectChecksumsRoot(active), ['.json']);
  for (const file of files) {
    const report = readJson(file.path, null);
    if (report?.type !== 'universal-patcher-report') continue;
    if (!targetSha256 || report.targetFileSha256 === targetSha256) return { ...report, file: file.path };
  }
  return null;
}
function analyzeProjectBin(targetFile = null) {
  const active = requireActive();
  if (!active.bin || !fs.existsSync(active.bin)) throw new Error('Import or read a protected original BIN first.');
  const target = targetFile && fs.existsSync(targetFile) ? targetFile : latestRevisionFile(active) || active.bin;
  const definitions = activeChecksumDefinitions(active);
  const analysis = analyzeBin(target, { referenceFile: path.resolve(target) === path.resolve(active.bin) ? null : active.bin, checksumDefinitions: definitions });
  const external = latestExternalChecksumReport(active, analysis.sha256);
  const compatible = !analysis.comparison || analysis.comparison.compatibleLayout;
  const checksumStatus = analysis.nativeChecksumStatus === 'valid' ? 'valid' : external?.report?.valid ? 'valid-external' : analysis.nativeChecksumStatus;
  const report = {
    type: 'revision-validation', version: APP_VERSION, projectId: active.id, projectName: active.name,
    controller: active.controller || '', os: active.os || '', targetFile: target, targetFileName: path.basename(target),
    targetFileSha256: analysis.sha256, originalFile: active.bin, originalSha256: active.binInfo?.sha256 || sha256(active.bin),
    compatible, checksumStatus, analysis, externalReport: external || null,
    warnings: [
      ...(compatible ? [] : ['BIN size or segment layout does not match the protected original.']),
      ...(checksumStatus === 'not-defined' ? ['No supported checksum definition exists in the XDF. Import a Universal Patcher report before writing.'] : []),
      ...(checksumStatus === 'invalid' ? ['One or more explicit XDF checksums are invalid.'] : [])
    ],
    validatedAt: new Date().toISOString()
  };
  const file = path.join(projectReportsRoot(active), `validation-${Date.now()}.json`);
  writeJson(file, report);
  appendActivity('bin-validation-complete', { projectId: active.id, projectName: active.name, file: path.basename(target), compatible, checksumStatus, changedBytes: analysis.comparison?.changedBytes || 0 });
  p01Manager.recordValidation(report);
  return { ...report, file };
}
function requireValidatedRevision(input) {
  const active = requireActive();
  const resolved = path.resolve(input || latestRevisionFile(active) || '');
  const revisionRoot = path.resolve(path.join(active.folder, 'Revisions'));
  if (!resolved || !fs.existsSync(resolved) || !resolved.startsWith(revisionRoot + path.sep)) throw new Error('Select a revision BIN from the active project Revisions folder.');
  const reports = listFilesSafe(projectReportsRoot(active), ['.json']).map(item => readJson(item.path, null)).filter(Boolean);
  const report = reports.find(item => item.type === 'revision-validation' && item.targetFileSha256 === sha256(resolved));
  if (!report || report.compatible === false || !['valid','valid-external','valid-stock-clone'].includes(report.checksumStatus)) {
    throw new Error('Analyze this exact revision and obtain a valid native or Universal Patcher checksum result before writing.');
  }
  return { active, input: resolved, report };
}

function emitP01Auto(state = p01AutoManager?.load?.()) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('p01-auto:progress', p01AutoSnapshot(state));
}
function p01AutoSnapshot(state = p01AutoManager?.load?.()) {
  const active = getActiveProject();
  const revision = state?.revision?.path && fs.existsSync(state.revision.path) ? state.revision.path : null;
  let p01 = null;
  try { p01 = active ? p01Manager.status(active, revision) : null; } catch {}
  const canResume = Boolean(p01AutoManager?.canResume?.(state));
  const stopDetails = state?.portRecovery || state?.stop?.details || null;
  const flash = flashManager.status();
  let sessionDoctor = null;
  try { sessionDoctor = hardwareSessionDoctor?.build?.() || null; } catch {}
  return { ...(state || {}), canResume, runtimeBusy: Boolean(p01AutoBusy), stopDetails, p01, flash, sessionDoctor, activeProject: active ? { id: active.id, name: active.name, controller: active.controller, os: active.os } : null };
}
function p01OperationForPhase(phase = '') {
  if (/read-properties/i.test(phase)) return 'readProperties';
  if (/read-[12]|assisted-read$/i.test(phase)) return 'read';
  if (/test-write/i.test(phase)) return 'testWrite';
  if (/waiting-write|ready-to-write/i.test(phase)) return 'writeCalibration';
  return null;
}
function scheduleP01Auto(delay = 120) {
  clearTimeout(p01AutoTimer);
  p01AutoTimer = setTimeout(() => runP01AutoStep().catch(error => {
    const failed = p01AutoManager?.fail?.(error);
    emitP01Auto(failed);
  }), delay);
}
function p01AutoFlashPayload(state, extra = {}) {
  return {
    device: state.device || flashManager.status().device || '',
    voltage: Number.isFinite(Number(state.voltage)) ? Number(state.voltage) : undefined,
    benchPowerConfirmed: Boolean(state.benchPowerConfirmed),
    ...extra
  };
}
function reconcileP01AutoEvidence(state) {
  if (!state || state.status !== 'running') return state;
  let repair = null;
  try { repair = p01Manager.repairVerifiedReadPair('1.8 continuity ledger reconciliation'); } catch {}
  let p01 = repair?.status;
  try { if (!p01) p01 = p01Manager.status(requireActive()); } catch { return state; }
  return p01AutoManager.reconcileEvidence(p01, { repairedReadPair: Boolean(repair?.repaired) });
}

function reconcileActiveCommissioningWorkspace({ advanceAutomation = false, reason = 'workspace reconciliation' } = {}) {
  const active = requireActive();
  let p01 = null;
  try { p01Manager.repairVerifiedReadPair('1.8 continuity reconciliation'); } catch {}
  try { p01 = p01Manager.status(active); } catch {}
  if (!p01?.dualReadVerified || !p01?.identity?.os) {
    return { reconciled: false, finalized: false, active, workspace: null, p01: p01 || p01Manager.status(active), auto: p01AutoManager.load(active) };
  }
  const commissioningPath = Boolean(!active.xdf || !fs.existsSync(active.xdf) || isCommissioningOnlyXdf(active.xdf));
  if (!commissioningPath) {
    return { reconciled: false, finalized: false, active, workspace: null, p01, auto: p01AutoManager.load(active) };
  }
  return finalizeP01CommissioningSoftwareState({ advanceAutomation, reason });
}

function installP01AutoXdf(source) {
  const active = requireActive();
  if (!source || !fs.existsSync(source) || path.extname(source).toLowerCase() !== '.xdf') throw new Error('Select an existing .xdf definition file.');
  const destination = copyProjectFile(source, path.join(active.folder, 'Definitions'));
  const parsed = parseXdf(destination);
  if (!parsed.tables.length) throw new Error('The selected XDF does not contain readable tables or constants.');
  const commissioningOnly = isCommissioningOnlyXdf(destination);
  const info = { path: destination, name: path.basename(destination), tableCount: parsed.tables.length, title: parsed.title, warnings: parsed.warnings || [], sha256: sha256(destination), commissioningOnly, writableTables: commissioningOnly ? 0 : parsed.tables.length };
  if (active.xdf && fs.existsSync(active.xdf) && sha256(active.xdf) !== info.sha256) tuneWorkspaceManager.invalidate(active, 'The XDF definition fingerprint changed.');
  const updated = updateActiveFiles({ xdf: destination, xdfInfo: info });
  applyAutomaticOperatingSystem(updated);
  appendActivity('p01-auto-xdf-installed', { projectId: active.id, os: active.os || '', name: info.name, tableCount: info.tableCount });
  return { destination, parsed, info };
}
function p01AutoXdfFolders(active) {
  return [
    path.join(active.folder, 'Definitions'),
    path.join(dataRoot(), 'Definitions'),
    path.join(dataRoot(), 'Compatibility'),
    path.join(app.getPath('downloads')),
    path.join(app.getPath('documents'), 'TunIQ')
  ];
}

function definitionSearchRoots(active, deep = false) {
  const tools = scanTools(false);
  const roots = [
    active ? path.join(active.folder, 'Definitions') : null,
    active ? path.join(active.folder, 'Compatibility') : null,
    path.join(dataRoot(), 'Definitions'),
    path.join(dataRoot(), 'Compatibility'),
    tools.tunerPro ? path.dirname(tools.tunerPro) : null,
    tools.universalPatcher ? path.dirname(tools.universalPatcher) : null
  ];
  if (deep) roots.push(app.getPath('downloads'), app.getPath('desktop'), path.join(app.getPath('documents'), 'TunIQ'));
  return [...new Set(roots.filter(Boolean).map(root => path.resolve(root)))];
}
function definitionJobsRoot(active) {
  return path.join(active.folder, 'Compatibility', 'Definition-Jobs');
}
function latestDefinitionJob(active) {
  const root = definitionJobsRoot(active);
  if (!fs.existsSync(root)) return null;
  try {
    return fs.readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && fs.existsSync(path.join(root, entry.name, 'definition-job.json')))
      .map(entry => ({ folder: path.join(root, entry.name), mtime: fs.statSync(path.join(root, entry.name)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime)[0] || null;
  } catch { return null; }
}
function definitionCenterState(active, deep = false) {
  if (!active) return { active: false, os: '', status: 'no-project', message: 'Create or activate a project first.', xdfs: [], universalXml: [] };
  const tools = scanTools(false);
  const p01 = p01Manager?.status?.(active) || null;
  const osId = String(p01?.identity?.os || active.os || '');
  const controllerId = String(p01?.identity?.controller || active.controller || '');
  const scan = osId ? scanDefinitionSources({ os: osId, roots: definitionSearchRoots(active, deep), parseXdf, universalPatcherExe: tools.universalPatcher, controller: controllerId }) : { os: '', scannedFiles: 0, xdfs: [], universalXml: [], universalPatcher: universalPatcherLayout(tools.universalPatcher) };
  const job = latestDefinitionJob(active);
  let jobStatus = null;
  if (job) {
    try { jobStatus = inspectDefinitionJob(job.folder, { parseXdf, os: osId, binSize: active.binInfo?.size || 524288, controller: controllerId }); }
    catch (error) { jobStatus = { folder: job.folder, error: error.message, accepted: [], rejected: [] }; }
  }
  const bound = active.xdf && fs.existsSync(active.xdf) ? xdfInfoFor(active.xdf, active.xdfInfo) : null;
  let status = 'missing-definition';
  let message = osId ? `No exact definition for OS ${osId} is bound yet.` : 'Read controller properties before resolving a definition.';
  if (bound && !bound.error && osCandidatesFromText(`${bound.name} ${bound.title}`).includes(osId)) { status = bound.commissioningOnly ? 'commissioning-only-bound' : 'bound'; message = bound.commissioningOnly ? `P01 hardware setup can finish with ${bound.name}; tuning and controller writing stay locked until a writable exact-OS definition is installed.` : `${bound.name} is bound to OS ${osId}.`; }
  else if (scan.xdfs.length === 1) { status = 'exact-xdf-found'; message = `One exact OS ${osId} XDF is ready to bind automatically.`; }
  else if (scan.xdfs.length > 1) { status = 'multiple-xdfs'; message = `${scan.xdfs.length} exact OS ${osId} XDF files were found; TunIQ will not choose between ambiguous sources.`; }
  else if (scan.universalXml.length === 1) { status = 'up-xml-found'; message = `Universal Patcher contains an exact OS ${osId} table definition that TunIQ can convert safely.`; }
  else if (scan.universalXml.length > 1) { status = 'multiple-up-xml'; message = `${scan.universalXml.length} exact Universal Patcher definitions were found; choose one source.`; }
  else if (!scan.universalPatcher.complete) { status = 'universal-patcher-incomplete'; message = scan.universalPatcher.issues?.[0] || 'Install or select a complete Universal Patcher folder.'; }
  else if (jobStatus?.accepted?.length) { status = 'job-output-ready'; message = 'A managed definition job produced an exact output ready to import.'; }
  else if (job) { status = 'job-waiting'; message = `Managed definition job is waiting for exact OS ${osId} output.`; }
  return { active: true, os: osId, status, message, bound, ...scan, job: job ? { folder: job.folder, ...(jobStatus || {}) } : null, tools };
}
function installGeneratedDefinition(sourceXml, active, osId) {
  const destination = path.join(active.folder, 'Definitions', `TunIQ-UP-OS-${osId}.xdf`);
  const generated = buildXdfFromUniversalTunerXml(sourceXml, destination, { os: osId, binSize: active.binInfo?.size || 524288, controller: p01Manager.status(active)?.identity?.controller || active.controller || '' });
  return installP01AutoXdf(generated.path);
}

function installCommissioningDefinition(active, osId) {
  if (!active?.bin || !fs.existsSync(active.bin)) throw new Error('The verified protected original is required before creating the commissioning-only definition.');
  const destination = path.join(active.folder, 'Definitions', `TunIQ-Commissioning-Only-OS-${osId}.xdf`);
  const generated = buildCommissioningOnlyXdf(destination, {
    os: osId,
    binSize: active.binInfo?.size || fs.statSync(active.bin).size,
    controller: p01Manager.status(active)?.identity?.controller || active.controller || 'P01',
    originalSha256: active.binInfo?.sha256 || sha256(active.bin)
  });
  const installed = installP01AutoXdf(generated.path);
  appendActivity('commissioning-only-definition-bound', { projectId: active.id, os: String(osId), xdf: path.basename(installed.destination), writableTables: 0 });
  return installed;
}


function finalizeP01CommissioningSoftwareState({ advanceAutomation = true, reason = 'P01 Test Write Runtime Recovery' } = {}) {
  let active = requireActive();
  if (String(active.controller || '').toUpperCase() !== 'P01') throw new Error('The active project is not configured as P01.');
  try { p01Manager.repairVerifiedReadPair('1.8 continuity finalizer disk audit'); } catch {}
  let commissioningState = p01Manager.load(active);
  const identity = commissioningState.identity || {};
  const osId = String(identity.os || active.os || '');
  if (!osId) throw new Error('The P01 operating system is missing from saved Read Properties evidence.');

  const protectedResult = ensureProtectedOriginal({
    active,
    state: commissioningState,
    originalsFolder: path.join(active.folder, 'Originals')
  });
  if (!active.bin || path.resolve(active.bin).toLowerCase() !== path.resolve(protectedResult.installed.path).toLowerCase()
      || active.binInfo?.sha256 !== protectedResult.installed.sha256) {
    active = updateActiveFiles({
      bin: protectedResult.installed.path,
      binInfo: protectedResult.installed,
      controller: 'P01',
      os: osId,
      osSource: active.osSource || 'PCM Hammer Read Properties'
    });
  }

  const currentDefinitionValid = Boolean(active.xdf && fs.existsSync(active.xdf) && isCommissioningOnlyXdf(active.xdf)
    && osCandidatesFromText(`${path.basename(active.xdf)} ${active.xdfInfo?.title || ''}`).includes(osId));
  if (!currentDefinitionValid) installCommissioningDefinition(active, osId);
  active = requireActive();
  // Refresh definition metadata from the actual generated file. Old beta manifests and
  // stale Calibration workspaces are never allowed to describe this read-only XDF.
  const parsedCommissioningXdf = parseXdf(active.xdf);
  active = updateActiveFiles({
    xdfInfo: {
      path: active.xdf,
      name: path.basename(active.xdf),
      title: parsedCommissioningXdf.title || `TunIQ Commissioning Only OS ${osId}`,
      tableCount: parsedCommissioningXdf.tables.length,
      warnings: parsedCommissioningXdf.warnings || [],
      sha256: sha256(active.xdf),
      commissioningOnly: true,
      writableTables: 0
    }
  });

  const confirmed = p01Manager.confirmCommissioningDefinitionFromDisk();
  const definition = confirmed.definition;
  const clone = createOrReuseStockClone({
    originalFile: active.bin,
    revisionsFolder: path.join(active.folder, 'Revisions'),
    projectName: active.name
  });
  const validation = {
    type: 'revision-validation', version: APP_VERSION, projectId: active.id, projectName: active.name,
    controller: 'P01', os: osId, targetFile: clone.revision.path, targetFileName: clone.revision.name,
    targetFileSha256: clone.revision.sha256, originalFile: clone.original.path, originalSha256: clone.original.sha256,
    compatible: true, checksumStatus: 'valid-stock-clone', commissioningOnly: true,
    analysis: { sha256: clone.revision.sha256, size: clone.revision.size, comparison: { changedBytes: 0, compatibleLayout: true } },
    warnings: ['Unchanged verified stock clone for P01 setup and Test Write only. No tuning addresses or controller write are authorized.'],
    validatedAt: new Date().toISOString()
  };
  const validationFile = path.join(projectReportsRoot(active), `validation-${clone.revision.sha256.slice(0, 16)}-commissioning-stock-clone.json`);
  writeJson(validationFile, validation);
  p01Manager.recordValidation(validation);

  const audit = buildFinalizerAudit({
    active, identity, pair: protectedResult.pair, original: clone.original, definition, clone
  });
  audit.reason = reason;
  audit.validationFile = validationFile;
  audit.revision = clone.revision;
  const auditFile = path.join(projectReportsRoot(active), `p01-finalizer-audit-${clone.revision.sha256.slice(0, 16)}.json`);
  writeJson(auditFile, audit);
  if (!audit.passed) throw new Error(`P01 Test Write Runtime Recovery audit failed: ${audit.failures.join(', ')}`);

  const current = p01AutoManager.load(active);
  const now = new Date().toISOString();
  const completedSteps = {
    ...(current.completedSteps || {}),
    'read-properties': current.completedSteps?.['read-properties'] || { at: now, evidence: { identity, source: 'saved-p01-evidence' } },
    'read-1': current.completedSteps?.['read-1'] || { at: now, evidence: { sha256: protectedResult.pair.sha256, source: protectedResult.pair.first.path } },
    'read-2': current.completedSteps?.['read-2'] || { at: now, evidence: { sha256: protectedResult.pair.sha256, source: protectedResult.pair.second.path } },
    definition: current.completedSteps?.definition || { at: now, evidence: { os: osId, xdf: path.basename(active.xdf), commissioningOnly: true, source: 'p01-finalizer' } },
    'create-revision': { at: now, evidence: { revisionSha256: clone.revision.sha256, changedBytes: 0, auditFile } }
  };
  const patch = {
    status: advanceAutomation ? 'running' : 'paused',
    phase: advanceAutomation ? 'test-write' : 'stopped-finalizer-ready',
    nextStep: 'test-write',
    resumePhase: advanceAutomation ? null : 'test-write',
    progress: 87,
    blocker: advanceAutomation ? null : 'Software setup is fully reconciled. Resume Failed Step will run PCM Hammer Test Write.',
    stop: advanceAutomation ? null : { code: 'finalizer-ready', message: reason, at: now, priorPhase: current.phase },
    commissioningOnly: true,
    selectedXdf: active.xdf,
    definitionSource: 'commissioning-only-finalizer',
    revision: clone.revision,
    validation: { checksumStatus: validation.checksumStatus, compatible: true, file: validationFile },
    finalizerAudit: { passed: true, file: auditFile, at: now },
    completedSteps,
    lastCompletedStep: 'create-revision'
  };
  const auto = p01AutoManager.patch(patch, {
    level: 'success',
    text: advanceAutomation
      ? 'P01 Test Write Runtime Recovery rebuilt every software prerequisite directly from disk. Starting PCM Hammer Test Write now.'
      : 'P01 Test Write Runtime Recovery rebuilt every software prerequisite directly from disk. Test Write is the only remaining step.'
  });
  appendActivity('p01-setup-finalizer-passed', { projectId: active.id, os: osId, revisionSha256: clone.revision.sha256, auditFile, advanceAutomation });
  return { reconciled: true, finalized: true, active: requireActive(), p01: p01Manager.status(requireActive(), clone.revision.path), auto, audit, auditFile };
}

function installExactDefinitionFile(source, active, osId) {
  if (!source || !fs.existsSync(source)) throw new Error('The selected definition source does not exist.');
  const extension = path.extname(source).toLowerCase();
  if (extension === '.xml') return installGeneratedDefinition(source, active, osId);
  if (extension !== '.xdf') throw new Error('Definition Center accepts exact-OS .xdf files or Universal Patcher Tuner XML files.');
  const parsed = parseXdf(source);
  const declared = osCandidatesFromText(`${path.basename(source)} ${parsed.title || ''}`);
  if (!declared.includes(String(osId))) throw new Error(`The selected XDF does not explicitly declare OS ${osId}.`);
  if (!parsed.tables.length) throw new Error('The selected XDF does not contain readable tables or constants.');
  return installP01AutoXdf(source);
}
function resolveDefinitionForActive({ deep = true } = {}) {
  const active = requireActive();
  const p01 = p01Manager.status(active);
  const osId = String(p01.identity?.os || active.os || '');
  if (!osId) throw new Error('Read controller properties before resolving a calibration definition.');
  const center = definitionCenterState(active, deep);
  if (center.bound && !center.bound.error && !center.bound.commissioningOnly && osCandidatesFromText(`${center.bound.name} ${center.bound.title}`).includes(osId)) return { resolved: true, source: 'already-bound', center: definitionCenterState(getActiveProject(), false) };
  if (center.bound?.commissioningOnly && !center.xdfs.length && !center.universalXml.length) return { resolved: true, limited: true, source: 'commissioning-only', center: definitionCenterState(getActiveProject(), false) };
  if (center.xdfs.length === 1) {
    const installed = installExactDefinitionFile(center.xdfs[0].path, active, osId);
    appendActivity('definition-auto-bound', { projectId: active.id, os: osId, source: 'xdf', file: center.xdfs[0].name });
    return { resolved: true, source: 'xdf', installed, center: definitionCenterState(getActiveProject(), false) };
  }
  if (!center.xdfs.length && center.universalXml.length === 1) {
    const installed = installGeneratedDefinition(center.universalXml[0].path, active, osId);
    appendActivity('definition-generated-bound', { projectId: active.id, os: osId, source: 'universal-patcher-xml', file: center.universalXml[0].name });
    return { resolved: true, source: 'universal-patcher-xml', installed, center: definitionCenterState(getActiveProject(), false) };
  }
  if (center.job?.accepted?.length === 1) {
    const candidate = center.job.accepted[0];
    const installed = installExactDefinitionFile(candidate.path, active, osId);
    appendActivity('definition-job-output-bound', { projectId: active.id, os: osId, source: candidate.kind, file: candidate.name });
    return { resolved: true, source: 'managed-job', installed, center: definitionCenterState(getActiveProject(), false) };
  }
  const job = ensureDefinitionJob(active, p01);
  const installed = installCommissioningDefinition(active, osId);
  appendActivity('definition-commissioning-fallback', { projectId: active.id, os: osId, reason: center.status, job: job.folder });
  return { resolved: true, limited: true, source: 'commissioning-only', installed, job, center: definitionCenterState(getActiveProject(), false) };
}
function ensureDefinitionJob(active, state = null) {
  const existing = latestDefinitionJob(active);
  if (existing) return existing;
  const tools = scanTools(false);
  const p01 = state || p01Manager.status(active);
  return createDefinitionJob({
    projectFolder: active.folder, projectId: active.id, projectName: active.name,
    os: p01.identity?.os || active.os, bin: active.bin, binSha256: active.binInfo?.sha256, tools
  });
}


function tunerProJobsRoot(active) { return path.join(active.folder, 'Compatibility', 'TunerPro'); }
function latestTunerProJob(active) {
  const root = tunerProJobsRoot(active);
  if (!fs.existsSync(root)) return null;
  try {
    return fs.readdirSync(root, { withFileTypes: true })
      .filter(entry => entry.isDirectory() && fs.existsSync(path.join(root, entry.name, 'roundtrip.json')))
      .map(entry => ({ folder: path.join(root, entry.name), mtime: fs.statSync(path.join(root, entry.name)).mtimeMs }))
      .sort((a, b) => b.mtime - a.mtime)[0] || null;
  } catch { return null; }
}
function inspectTunerProRoundtrip(active) {
  const latest = latestTunerProJob(active);
  if (!latest) return null;
  const manifest = readJson(path.join(latest.folder, 'roundtrip.json'), null);
  if (!manifest) return null;
  const candidates = listFilesSafe(latest.folder, ['.bin']).map(item => {
    try {
      const hash = sha256(item.path);
      const comparison = compareFiles(manifest.sourceBin, item.path);
      return { ...item, sha256: hash, comparison, changed: hash !== manifest.sourceSha256 && comparison.changedBytes > 0 };
    } catch (error) { return { ...item, error: error.message, changed: false }; }
  });
  const readyBins = candidates.filter(item => item.changed && item.comparison?.compatibleLayout);
  return { folder: latest.folder, manifest, candidates, readyBins, status: readyBins.length === 1 ? 'ready-to-import' : readyBins.length > 1 ? 'multiple-outputs' : 'waiting-for-changes' };
}
function importTunerProRoundtrip(active) {
  const job = inspectTunerProRoundtrip(active);
  if (!job) throw new Error('No managed TunerPro roundtrip exists for this project.');
  if (job.readyBins.length !== 1) throw new Error(job.readyBins.length ? 'More than one changed compatible TunerPro BIN was found. Keep only the intended working BIN in the roundtrip folder.' : 'TunerPro has not saved a compatible changed BIN in the managed roundtrip yet.');
  const source = job.readyBins[0].path;
  const destination = path.join(active.folder, 'Revisions', `TunerPro-${Date.now()}-${path.basename(source)}`);
  fs.copyFileSync(source, destination);
  const validation = analyzeProjectBin(destination);
  appendActivity('tunerpro-output-imported', { projectId: active.id, source: path.basename(source), revision: path.basename(destination), changedBytes: job.readyBins[0].comparison.changedBytes, checksumStatus: validation.checksumStatus });
  return { revision: { path: destination, name: path.basename(destination), sha256: sha256(destination) }, validation, job: inspectTunerProRoundtrip(active) };
}

function universalPatcherJobsRoot(active) { return path.join(active.folder, 'Compatibility', 'Universal-Patcher'); }
function latestUniversalPatcherJob(active) {
  const root = universalPatcherJobsRoot(active);
  if (!fs.existsSync(root)) return null;
  try {
    return fs.readdirSync(root, { withFileTypes: true }).filter(entry => entry.isDirectory() && fs.existsSync(path.join(root, entry.name, 'job.json')))
      .map(entry => ({ folder: path.join(root, entry.name), mtime: fs.statSync(path.join(root, entry.name)).mtimeMs })).sort((a,b)=>b.mtime-a.mtime)[0] || null;
  } catch { return null; }
}
function createUniversalPatcherValidationJob(active, targetFile) {
  const target = targetFile && fs.existsSync(targetFile) ? path.resolve(targetFile) : latestRevisionFile(active) || active.bin;
  if (!target || !fs.existsSync(target)) throw new Error('Select or create a BIN revision before running Universal Patcher validation.');
  const folder = path.join(universalPatcherJobsRoot(active), `${Date.now()}-${path.basename(target, path.extname(target))}`);
  const input = path.join(folder, 'Input'); const output = path.join(folder, 'Output'); const reports = path.join(folder, 'Reports');
  for (const value of [input, output, reports]) fs.mkdirSync(value, { recursive: true });
  const working = path.join(input, path.basename(target)); fs.copyFileSync(target, working);
  const manifest = { schemaVersion:1, createdAt:new Date().toISOString(), projectId:active.id, projectName:active.name, controller:active.controller||'', os:active.os||'', sourceFile:target, sourceSha256:sha256(target), workingFile:working, output, reports, status:'awaiting-universal-patcher' };
  writeJson(path.join(folder, 'job.json'), manifest);
  return { folder, input, output, reports, manifest };
}
function inspectUniversalPatcherJob(active) {
  const latest = latestUniversalPatcherJob(active); if (!latest) return null;
  const manifest = readJson(path.join(latest.folder, 'job.json'), null); if (!manifest) return null;
  const files = [...listFilesSafe(manifest.output), ...listFilesSafe(manifest.reports), ...listFilesSafe(manifest.input)].filter(item => item.path !== manifest.workingFile || fileShaSafe(item.path) !== manifest.sourceSha256);
  const binOutputs = files.filter(item => item.extension === '.bin').map(item => {
    try { const comparison = compareFiles(manifest.sourceFile, item.path); return { ...item, sha256: sha256(item.path), comparison, changed: comparison.changedBytes > 0 }; }
    catch (error) { return { ...item, error: error.message, changed:false }; }
  });
  const reportOutputs = files.filter(item => ['.txt','.log','.json','.xml','.html'].includes(item.extension)).map(item => {
    try { return { ...item, parsed: parseUniversalPatcherReport(item.path) }; } catch (error) { return { ...item, error:error.message }; }
  });
  return { folder: latest.folder, manifest, binOutputs, reportOutputs, readyBins: binOutputs.filter(item => item.changed && item.comparison?.compatibleLayout), validReports: reportOutputs.filter(item => item.parsed?.valid) };
}
function buildAndSaveGoalProposal(active, request, confirmations, parameterMap = null) {
  const workspace = loadCalibration();
  const proposal = buildGoalProposal({
    request, workspace, activeProject: active, confirmations: confirmations || {}, parameterMap,
    ruleFolders: [path.join(dataRoot(), 'Compatibility', 'Rules'), path.join(app.getAppPath(), 'src', 'rules')]
  });
  return saveGoalRequest(active, proposal);
}
function applyP01AutoGoal(active, proposal) {
  const approvedIds = (proposal.proposals || []).filter(item => !item.blocked).map(item => item.id);
  if (!approvedIds.length) throw new Error('The commissioned action sheet contains no unblocked changes to apply.');
  p01Manager.assertGoalProposalMapped(proposal, approvedIds);
  const workspace = loadCalibration();
  const result = applyGoalApproved(workspace, proposal, approvedIds);
  validateCalibrationWorkspace(result.workspace);
  saveCalibrationWorkspace(result.workspace);
  const revision = exportCalibrationWorkspace(result.workspace, { suffix: 'P01-Guided-Automatic-AI', autoCorrectChecksums: true });
  const execution = {
    id: `${Date.now()}-p01-auto-execution`, projectId: active.id, projectName: active.name, proposalId: proposal.id,
    requestText: proposal.requestText, approvedIds, applied: result.applied, revision,
    status: 'automatic-revision-created-awaiting-validation-and-test-write', createdAt: new Date().toISOString()
  };
  writeJson(path.join(projectGoalRequestsRoot(active), `${execution.id}.json`), execution);
  appendActivity('p01-auto-revision-created', { projectId: active.id, revision: revision.name, appliedCells: result.applied.length });
  return { revision, execution, applied: result.applied };
}
async function startP01AutoOperation(operation, state, waitingPhase, progress, message, extra = {}) {
  const payload = p01AutoFlashPayload(state, extra);
  const waiting = p01AutoManager.advance(waitingPhase, progress, message);
  emitP01Auto(waiting);
  try {
    await flashManager.start(operation, payload);
    return true;
  } catch (error) {
    const code = error?.code || 'pcmhammer-start-failed';
    flashManager.clearTransientRecoveryState(`P01 ${operation} stopped: ${code}`);
    // Beta.17 never leaves the guided workflow to run normal PCM Hammer. The integrated CLI runner owns the COM lease,
    // discovers a safe command profile, captures output, and imports evidence inside TunIQ.
    const paused = p01AutoManager.pause(code, error?.message || String(error), {
      resumePhase: waitingPhase.replace(/^waiting-/, ''),
      details: error?.details || null,
      portRecovery: { code, device: payload.device || '', attempts: error?.details?.attempts || [], technicalDetails: error?.details || null, assistedFallback: false }
    });
    emitP01Auto(paused);
    try { hardwareSessionDoctor?.saveLatest?.(); } catch {}
    return false;
  }
}

async function handleP01AutoFlashComplete(session) {
  if (!p01AutoManager) return;
  const state = p01AutoManager.load();
  const expected = {
    'waiting-read-properties': 'readProperties', 'assisted-readProperties': 'readProperties',
    'waiting-read-1': 'read', 'assisted-read': 'read', 'waiting-read-2': 'read',
    'waiting-test-write': 'testWrite', 'assisted-testWrite': 'testWrite', 'waiting-write': 'writeCalibration'
  }[state.phase];
  if (!expected || expected !== session.operation) return;
  if (!['complete', 'complete-unverified'].includes(session.state)) {
    // Beta.26 continuity lock: if an unnecessary/restarted read fails after a verified pair
    // already exists, do not regress the workflow or ask for another read. Continue from
    // the durable evidence on disk.
    if (session.operation === 'read') {
      try {
        const repair = p01Manager.repairVerifiedReadPair('failed extra read continuity recovery');
        const p01 = repair?.status || p01Manager.status(requireActive());
        if (p01.dualReadVerified) {
          const recovered = p01AutoManager.patch({
            status: 'running', phase: 'definition', nextStep: 'definition', resumePhase: null, progress: 48, blocker: null, stop: null,
            completedSteps: { ...(state.completedSteps || {}),
              'read-1': state.completedSteps?.['read-1'] || { at: new Date().toISOString(), evidence: { sha256: p01.readPair?.first?.sha256, source: 'continuity-lock' } },
              'read-2': state.completedSteps?.['read-2'] || { at: new Date().toISOString(), evidence: { sha256: p01.canonicalReadSha256, source: 'continuity-lock' } } },
            lastCompletedStep: 'read-2'
          }, { level: 'warning', text: 'The restarted extra read failed, but the previously verified matching read pair is still intact. TunIQ preserved it and continued without repeating the read.' });
          emitP01Auto(recovered); scheduleP01Auto(); return;
        }
      } catch {}
    }
    const code = session.stopCode || session.result?.stopCode || 'pcmhammer-operation-failed';
    const message = session.error || `${session.operation} stopped (${code}). Correct the stated cause, then resume this exact step.`;
    const paused = p01AutoManager.pause(code, message, {
      resumePhase: p01AutoManager.waitingResumePhase(state.phase),
      portRecovery: {
        code,
        device: session.device || state.device || '',
        attempts: (session.deviceAttempts || []).map(item => ({
          port: item.device || '', source: item.source || '', exitCode: item.exitCode,
          openFailure: Boolean(item.openFailure), openTimeout: Boolean(item.openTimeout),
          accessBlocked: Boolean(item.accessBlocked), stdoutLog: item.stdoutLog || '', stderrLog: item.stderrLog || ''
        })),
        candidates: (session.deviceCandidates || []).map(item => ({ port: item.port, source: item.source || '', outgoing: Boolean(item.outgoing), bluetooth: Boolean(item.bluetooth), recoveryScore: Number(item.recoveryScore || 0) })),
        technicalDetails: session.technicalDetails || null,
        assistedFallback: false
      }
    });
    emitP01Auto(paused);
    try { hardwareSessionDoctor?.saveLatest?.(); } catch {}
    return;
  }
  if (session.operation === 'readProperties') {
    const p01 = p01Manager.status(requireActive());
    if (!p01.identity?.os || !p01.identity?.hardwareId || !p01.identity?.serviceNumber || String(p01.identity?.controller || '').toUpperCase() !== 'P01') {
      const paused = p01AutoManager.pause('properties-incomplete', 'Read Properties did not provide complete P01, OSID, Hardware ID, and service-number evidence. Save/import the complete PCM Hammer Results log, then resume Read Properties.', { resumePhase: 'read-properties' });
      emitP01Auto(paused); try { hardwareSessionDoctor?.saveLatest?.(); } catch {} return;
    }
    const next = p01AutoManager.completeStep('read-properties', 'read-1', 18, `Read Properties confirmed P01 OS ${p01.identity.os}, HW ${p01.identity.hardwareId}, service ${p01.identity.serviceNumber}.`, { identity: p01.identity, sessionId: session.id });
    emitP01Auto(next); scheduleP01Auto(); return;
  }
  if (session.operation === 'read') {
    const p01 = p01Manager.status(requireActive());
    const attempts = Number(state.readAttempts || 0) + 1;
    p01AutoManager.patch({ readAttempts: attempts });
    if (p01.readMismatch) {
      const paused = p01AutoManager.pause('read-hash-mismatch', p01.readResolution || 'The two complete reads have different SHA-256 hashes. Both were preserved. Correct power/connection problems and start a fresh two-read pair.', { resumePhase: 'read-1' });
      emitP01Auto(paused); try { hardwareSessionDoctor?.saveLatest?.(); } catch {} return;
    }
    if (p01.dualReadVerified) {
      const next = p01AutoManager.completeStep('read-2', 'definition', 48, 'Two independent complete 524,288-byte reads match. The verified original is now protected.', { sha256: p01.canonicalReadSha256, sessionId: session.id });
      emitP01Auto(next); scheduleP01Auto(); return;
    }
    const next = p01AutoManager.completeStep('read-1', 'read-2', 31, 'First complete 524,288-byte read accepted. Starting the independent matching read.', { sha256: p01.readPair?.first?.sha256, sessionId: session.id });
    emitP01Auto(next); scheduleP01Auto(); return;
  }
  if (session.operation === 'testWrite') {
    const revision = state.revision?.path;
    const p01 = p01Manager.status(requireActive(), revision);
    const commissioningOnly = Boolean(state.commissioningOnly || p01.definition?.commissioningOnly);
    if (!session.testWritePassed || (commissioningOnly ? !p01.testWrite : !p01.readyForWrite)) {
      const paused = p01AutoManager.pause('test-write-unproven', `Test Write did not produce complete proof for the exact revision. ${(p01.writeBlockers || []).join(' ')}`, { resumePhase: 'test-write' });
      emitP01Auto(paused); try { hardwareSessionDoctor?.saveLatest?.(); } catch {} return;
    }
    if (commissioningOnly) {
      const completed = p01AutoManager.patch({ status: 'complete', phase: 'commissioning-complete', nextStep: null, progress: 100, blocker: null, stop: null, commissioningOnly: true,
        completedSteps: { ...(state.completedSteps || {}), 'test-write': { at: new Date().toISOString(), evidence: { sessionId: session.id, revisionSha256: p01.selectedRevision?.sha256, commissioningOnly: true } } }, lastCompletedStep: 'test-write' },
      { level: 'success', text: 'P01 hardware setup is complete through a successful Test Write of the unchanged verified stock clone. Tuning and PCM write stay locked until a trustworthy writable exact-OS definition is installed.' });
      appendActivity('p01-guided-commissioning-complete', { projectId: completed.projectId, revision: completed.revision?.name, commissioningOnly: true });
      emitP01Auto(completed);
      try { hardwareSessionDoctor?.saveLatest?.(); } catch {}
      return;
    }
    const ready = p01AutoManager.patch({ status: 'ready', phase: 'ready-to-write', nextStep: null, progress: 100, blocker: null, stop: null,
      completedSteps: { ...(state.completedSteps || {}), 'test-write': { at: new Date().toISOString(), evidence: { sessionId: session.id, revisionSha256: p01.selectedRevision?.sha256 } } }, lastCompletedStep: 'test-write' },
    { level: 'success', text: 'Guided setup is complete through Test Write. A deliberate final Calibration Write confirmation is still required.' });
    appendActivity('p01-guided-ready-to-write', { projectId: ready.projectId, revision: ready.revision?.name });
    emitP01Auto(ready);
    try { hardwareSessionDoctor?.saveLatest?.(); } catch {}
    return;
  }
  if (session.operation === 'writeCalibration') {
    const completed = p01AutoManager.patch({ status: session.state === 'complete' && session.verified ? 'complete' : 'warning', phase: 'write-complete', nextStep: null, progress: 100, writeSessionId: session.id }, { level: session.verified ? 'success' : 'warning', text: session.verified ? 'Calibration Write completed and PCM Hammer reported verification success.' : 'Calibration Write ended without explicit verification proof. Read Properties and read back before treating hardware as verified.' });
    emitP01Auto(completed);
  }
}

async function runP01AutoStep() {
  if (!p01AutoManager || p01AutoBusy) return;
  let state = p01AutoManager.load();
  if (state.status !== 'running' || flashManager.status().session) return;
  state = reconcileP01AutoEvidence(state);
  if (state.status !== 'running' || flashManager.status().session) return;
  p01AutoBusy = true;
  try {
    const active = requireActive();
    if (String(active.controller || '').toUpperCase() !== 'P01') throw new Error('The active project is not configured as P01.');
    if (state.phase === 'preflight') {
      if (!betaManager.agreementAccepted()) return emitP01Auto(p01AutoManager.pause('needs-beta-agreement', 'Accept the Public Beta Agreement before TunIQ controls a PCM interface.', { resumePhase: 'preflight' }));
      if (!state.exactXdfAuthorization || !state.autoMapAuthorized || !state.autoRevisionAuthorized || !state.testWriteAuthorized) {
        return emitP01Auto(p01AutoManager.pause('needs-authorization', 'Guided Automatic P01 Setup requires explicit permission to bind only an exact-OS clean XDF, commission unambiguous mapped cells, create a revision, and run Test Write.', { resumePhase: 'preflight' }));
      }
      if (!Number.isFinite(Number(state.voltage)) && !state.benchPowerConfirmed && !Number.isFinite(Number(obdManager.getStatus()?.connection?.voltage))) {
        return emitP01Auto(p01AutoManager.pause('needs-power-proof', 'Enter live voltage or confirm a regulated bench supply before Test Write.', { resumePhase: 'preflight' }));
      }
      let flash = flashManager.status();
      if (flash.configured && (!flash.backend?.integrationReady || flash.integrationMode === 'unprobed')) {
        await flashManager.probe({});
        flash = flashManager.status();
      }
      if (!flash.configured || !flash.integrated) return emitP01Auto(p01AutoManager.pause('pcmhammer-cli-unavailable', 'The integrated PCM Hammer CLI runner is not ready. Select pcmhammer-cli.exe in Tool Connections, probe it once, then resume preflight.', { resumePhase: 'preflight' }));
      const parsed = parseTuneRequest(state.request);
      if (!parsed.recognized) throw new Error('The requested tune did not contain a supported ghost-cam, RPM-limit, or speed-limiter action.');
      const next = p01AutoManager.completeStep('preflight', 'read-properties', 8, 'Preflight passed. TunIQ will run PCM Hammer Read Properties; no command named “identify” is required.', { backend: flash.backend, integrationMode: flash.integrationMode, integrated: flash.integrated });
      emitP01Auto(next); scheduleP01Auto(); return;
    }
    if (state.phase === 'read-properties') {
      await startP01AutoOperation('readProperties', state, 'waiting-read-properties', 10, 'PCM Hammer is reading controller properties.'); return;
    }
    if (state.phase === 'read-1') {
      await startP01AutoOperation('read', state, 'waiting-read-1', 20, 'PCM Hammer is running full read 1 of 2.'); return;
    }
    if (state.phase === 'read-2') {
      await startP01AutoOperation('read', state, 'waiting-read-2', 33, 'PCM Hammer is running full read 2 of 2.'); return;
    }
    if (state.phase === 'definition') {
      const p01 = p01Manager.status(active);
      if (!active.xdf || !fs.existsSync(active.xdf) || isCommissioningOnlyXdf(active.xdf)) {
        const finalized = finalizeP01CommissioningSoftwareState({ advanceAutomation: true, reason: 'Guided Setup reached commissioning definition finalization' });
        emitP01Auto(finalized.auto); scheduleP01Auto(); return;
      }
      if (!p01.dualReadVerified || !p01.identity?.os) throw new Error('Two-read verification or OS identity was lost before definition binding.');
      let source = state.selectedXdf && fs.existsSync(state.selectedXdf) ? state.selectedXdf : null;
      if (!source && active.xdf && fs.existsSync(active.xdf)) {
        const declared = osCandidatesFromText(`${path.basename(active.xdf)} ${active.xdfInfo?.title || ''}`);
        if (declared.includes(String(p01.identity.os))) source = active.xdf;
      }
      if (!source) {
        const center = definitionCenterState(active, true);
        const candidates = center.xdfs || [];
        const unambiguous = candidates.length === 1 || (candidates[0] && (!candidates[1] || candidates[0].score >= candidates[1].score + 12));
        if (unambiguous) {
          source = candidates[0].path;
          p01AutoManager.patch({ selectedXdf: source, xdfCandidates: candidates.slice(0, 12), definitionSource: 'exact-xdf' }, { text: `Selected exact-OS definition ${candidates[0].name}.` });
        } else if (!candidates.length && center.universalXml?.length === 1) {
          const installed = installGeneratedDefinition(center.universalXml[0].path, active, String(p01.identity.os));
          source = installed.destination;
          p01AutoManager.patch({ selectedXdf: source, definitionSource: 'universal-patcher-xml', definitionProvenance: `${source}.provenance.json` }, { text: `Generated an exact-OS XDF from explicit Universal Patcher table addresses.` });
        } else if (candidates.length || center.universalXml?.length > 1) {
          const job = ensureDefinitionJob(active, p01);
          const text = candidates.length
            ? `TunIQ found ${candidates.length} exact-OS XDF candidates but cannot safely choose between them. Open Definition Center and select the trusted source.`
            : `TunIQ found multiple exact Universal Patcher definition sources. Open Definition Center and select one source.`;
          return emitP01Auto(p01AutoManager.pause('needs-definition-source', text, { resumePhase: 'definition', xdfCandidates: candidates.slice(0, 12), definitionCenter: center, definitionJob: job.folder }));
        } else {
          const job = ensureDefinitionJob(active, p01);
          const installed = installCommissioningDefinition(active, String(p01.identity.os));
          source = installed.destination;
          p01AutoManager.patch({ selectedXdf: source, definitionSource: 'commissioning-only', definitionJob: job.folder, commissioningOnly: true }, { level: 'warning', text: `No trustworthy writable definition for OS ${p01.identity.os} is available. TunIQ bound a read-only commissioning definition so hardware setup and Test Write can finish without guessed calibration addresses.` });
        }
      }
      if (path.resolve(source) !== path.resolve(active.xdf || '')) installP01AutoXdf(source);
      const workspace = loadActiveXdfWorkspace();
      if (workspace.mappingSummary?.warnings?.length) return emitP01Auto(p01AutoManager.pause('xdf-warnings', `The exact-OS XDF loaded with ${workspace.mappingSummary.warnings.length} warning(s). Guided setup stopped instead of hiding an address or parser problem.`, { resumePhase: 'definition', xdfWarnings: workspace.mappingSummary.warnings.slice(0, 40) }));
      const commissioningFallback = Boolean(workspace.mappingSummary?.commissioningOnly || isCommissioningOnlyXdf(source));
      const confirmedStatus = commissioningFallback
        ? p01Manager.reconcileBoundCommissioningDefinition()
        : p01Manager.confirmDefinition({ typedOs: String(p01.identity.os), acknowledged: true });
      if (commissioningFallback) appendActivity('commissioning-definition-auto-rebound', {
        projectId: requireActive().id, os: String(p01.identity.os), xdf: path.basename(source), version: APP_VERSION
      });
      const commissioningOnly = Boolean(confirmedStatus?.definition?.commissioningOnly || workspace.mappingSummary?.commissioningOnly || isCommissioningOnlyXdf(source));
      const next = commissioningOnly
        ? p01AutoManager.completeStep('definition', 'create-revision', 73, `OS ${p01.identity.os} is bound for read-only hardware commissioning. TunIQ will create an unchanged verified stock clone and run Test Write; tuning and PCM write remain locked.`, { xdf: path.basename(source), commissioningOnly: true })
        : p01AutoManager.completeStep('definition', 'goal-map', 61, `OS ${p01.identity.os} XDF loaded cleanly and was fingerprint-bound to the verified original.`, { xdf: path.basename(source), commissioningOnly: false });
      emitP01Auto(next); scheduleP01Auto(); return;
    }
    if (state.phase === 'goal-map') {
      p01Manager.assertAiReady();
      const draft = buildAndSaveGoalProposal(active, state.request, state.confirmations, null);
      const selection = selectGoalMapCandidates(draft);
      if (!selection.safeToAutoMap) return emitP01Auto(p01AutoManager.pause('needs-map-review', `TunIQ could not isolate every requested calibration parameter without ambiguity: ${selection.blockers.join(' ')}`, { resumePhase: 'goal-map', draftProposalId: draft.id, mapSelection: selection }));
      p01Manager.confirmGoalMap(draft, selection.actionIds, selection.proposalIds);
      const map = p01Manager.status(active).parameterMap;
      const commissioned = buildAndSaveGoalProposal(active, state.request, state.confirmations, map);
      const blocked = (commissioned.actions || []).filter(action => action.status === 'blocked');
      if (blocked.length) return emitP01Auto(p01AutoManager.pause('goal-blocked', blocked.map(action => `${action.label}: ${(action.requirements || []).join(' ')}`).join(' '), { resumePhase: 'goal-map', goalProposalId: commissioned.id, mapSelection: selection }));
      p01AutoManager.patch({ draftProposalId: draft.id, goalProposalId: commissioned.id, mapSelection: selection });
      const next = p01AutoManager.completeStep('goal-map', 'create-revision', 73, `Commissioned ${selection.proposalIds.length} exact cells and rebuilt the action sheet from the bound map.`, { proposalId: commissioned.id, cellCount: selection.proposalIds.length });
      emitP01Auto(next); scheduleP01Auto(); return;
    }
    if (state.phase === 'create-revision') {
      if (state.commissioningOnly || isCommissioningOnlyXdf(active.xdf)) {
        const finalized = finalizeP01CommissioningSoftwareState({ advanceAutomation: true, reason: 'Guided Setup repaired commissioning stock-clone state' });
        emitP01Auto(finalized.auto); scheduleP01Auto(); return;
      }
      const proposal = getGoalRequest(active, state.goalProposalId);
      if (!proposal) throw new Error('The commissioned action sheet could not be reloaded.');
      const result = applyP01AutoGoal(active, proposal);
      const validation = analyzeProjectBin(result.revision.path);
      const patch = { revision: result.revision, validation: { checksumStatus: validation.checksumStatus, compatible: validation.compatible, file: validation.file }, appliedCells: result.applied.length };
      if (!validation.compatible || !['valid', 'valid-external'].includes(validation.checksumStatus)) {
        return emitP01Auto(p01AutoManager.pause('needs-checksum', `Revision ${result.revision.name} was created, but checksum validation is ${validation.checksumStatus}. Import a Universal Patcher report for this exact SHA-256, then resume Test Write.`, { ...patch, resumePhase: 'test-write' }));
      }
      p01AutoManager.patch(patch);
      const next = p01AutoManager.completeStep('create-revision', 'test-write', 87, `Created and validated ${result.revision.name}. Test Write is next.`, { revision: result.revision, validation: patch.validation });
      emitP01Auto(next); scheduleP01Auto(); return;
    }
    if (state.phase === 'test-write') {
      const revision = state.revision?.path;
      if (!revision || !fs.existsSync(revision)) throw new Error('The automatic revision is missing.');
      p01Manager.assertOperationReady('testWrite', revision);
      await startP01AutoOperation('testWrite', state, 'waiting-test-write', 91, 'PCM Hammer Test Write is running. No flash write is authorized by this step.', { input: revision, checksumApproved: true }); return;
    }
  } catch (error) {
    const recoverable = error instanceof FlashStopError || error?.code;
    emitP01Auto(recoverable ? p01AutoManager.pause(error.code || 'workflow-stopped', error.message, { resumePhase: state.phase, details: error?.details || null }) : p01AutoManager.fail(error));
  } finally { p01AutoBusy = false; }
}


app.disableHardwareAcceleration();
app.commandLine.appendSwitch('disable-gpu');
app.commandLine.appendSwitch('disable-gpu-compositing');
logStartup('process:start', `version=${APP_VERSION} platform=${process.platform} arch=${process.arch}`);
app.whenReady().then(() => {
  logStartup('app:ready');
  ensureDataFolders();
  logStartup('folders:ready', dataRoot());
  hardwareSessionGuard.cleanupOwnedOrphans().then(result => logStartup('hardware-guard:orphan-cleanup', JSON.stringify({ cleaned: result.cleaned.length, stale: result.stale.length }))).catch(error => logStartup('hardware-guard:cleanup-skipped', error.message));
  const migration = migrateLegacyData();
  logStartup('migration:checked', JSON.stringify(migration));
  createWindow();
  flashManager.scanAssisted().catch(() => {});
  try { reconcileActiveCommissioningWorkspace({ advanceAutomation: false, reason: '1.8 startup continuity reconciliation' }); }
  catch (error) { logStartup('startup:commissioning-reconcile-skipped', error.message); }
  const recoveredP01Auto = p01AutoManager.load();
  if (recoveredP01Auto.status === 'running') scheduleP01Auto(400);
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
}).catch(error => {
  logCrash('startup-failure', error);
  try { dialog.showErrorBox('TunIQ could not start', `${error?.message || error}\n\nCrash log: ${path.join(dataRoot(), 'Logs', 'desktop-crash.log')}`); } catch {}
  app.quit();
});
app.on('before-quit', event => {
  const flashSession = flashManager.status().session;
  const criticalWrite = flashSession && ['writeCalibration','writeFull','recovery'].includes(flashSession.operation) && !['complete','complete-unverified','failed','cancelled'].includes(flashSession.state);
  if (criticalWrite) {
    event.preventDefault();
    logStartup('quit-blocked-active-flash', `${flashSession.operation} ${flashSession.phase || ''}`);
    try {
      if (mainWindow && !mainWindow.isDestroyed()) { mainWindow.show(); mainWindow.focus(); mainWindow.webContents.send('flash:progress', { ...flashSession, phase: 'App close blocked while PCM write is active' }); }
      dialog.showMessageBox(mainWindow, { type: 'warning', title: 'PCM write is still active', message: 'TunIQ will stay open until the PCM Hammer write or recovery operation finishes.', detail: 'Do not disconnect power, the interface, or the computer during erase, write, or verification.', buttons: ['Keep TunIQ Open'] }).catch(() => {});
    } catch {}
    return;
  }
  app.isQuitting = true; flashManager.cancel().catch(() => {}); obdManager.disconnect().catch(() => {}); logStartup('app:before-quit');
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('app:get-bootstrap', async () => ({
  version: APP_VERSION,
  dataRoot: dataRoot(),
  profile: readJson(profileFile(), null),
  settings: (() => { const settings = readJson(settingsFile(), { aiMode: null, units: 'US', detailLevel: 'beginner' }) || {}; return { ...settings, uiPreferences: normalizeUiPreferences(settings.uiPreferences) }; })(),
  tools: scanTools(false),
  vehicles: listVehicles(),
  activity: (() => { const v = readJson(activityFile(), []); return Array.isArray(v) ? v : []; })(),
  activeProject: getActiveProject(),
  ai: loadAiBundle(getActiveProject()),
  tuneLibrary: listTuneLibrary(),
  communityPosts: listCommunityPosts(),
  device: obdManager.getStatus(),
  liveLogs: obdManager.listLogs(),
  p01Evidence: p01EvidenceManager.list(),
  sensorProfiles: SENSOR_PROFILES,
  flash: flashManager.status(),
  validation: getActiveProject() ? latestValidationReport(getActiveProject()) : null,
  aiProposals: getActiveProject() ? listProposals(getActiveProject()) : [],
  beta: betaManager.state(),
  updates: updateManager.configure(),
  migration: readJson(path.join(dataRoot(), 'Settings', 'appdata-migration.json'), null)
}));
ipcMain.handle('profile:save', async (_event, payload) => {
  const profile = { name: String(payload.name || '').trim(), email: String(payload.email || '').trim(), createdAt: new Date().toISOString() };
  const previousSettings = readJson(settingsFile(), {});
  const settings = { aiMode: payload.aiMode, units: payload.units || 'US', detailLevel: previousSettings.detailLevel || 'beginner', uiPreferences: normalizeUiPreferences(previousSettings.uiPreferences), updatedAt: new Date().toISOString() };
  if (!profile.name || !profile.email || !['guided','manual','full-ai'].includes(settings.aiMode)) throw new Error('Name, email, and AI mode are required.');
  writeJson(profileFile(), profile);
  writeJson(settingsFile(), settings);
  return { profile, settings };
});
ipcMain.handle('settings:set-ai-mode', async (_event, aiMode) => {
  if (!['guided','manual','full-ai'].includes(aiMode)) throw new Error('Invalid AI mode.');
  const settings = { ...readJson(settingsFile(), {}), aiMode, updatedAt: new Date().toISOString() };
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('settings:set-detail-level', async (_event, detailLevel) => {
  if (!['beginner','advanced'].includes(detailLevel)) throw new Error('Invalid interface detail level.');
  const settings = { ...readJson(settingsFile(), {}), detailLevel, updatedAt: new Date().toISOString() };
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('settings:set-ui-preferences', async (_event, patch) => {
  const settings = mergeUiPreferences(readJson(settingsFile(), {}), patch);
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('bridge:scan-tools', async () => scanTools(true));
ipcMain.handle('bridge:verify-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool.');
  const tools = scanTools(false);
  const toolPath = tools[key];
  return { valid: isExecutableFile(toolPath), path: toolPath || null };
});
ipcMain.handle('bridge:choose-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool selection.');
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Windows programs', extensions: ['exe'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const selected = result.filePaths[0];
  if (!isExecutableFile(selected)) throw new Error('Select a valid Windows .exe file.');
  const tools = scanTools(false);
  tools[key] = path.resolve(selected);
  writeJson(toolsFile(), tools);
  return tools[key];
});
ipcMain.handle('bridge:launch-tool', async (_event, key) => {
  if (!TOOL_DEFINITIONS[key]) throw new Error('Unknown tool.');
  let tools = scanTools(false);
  let exe = tools[key];
  if (!isExecutableFile(exe)) {
    tools = scanTools(true);
    exe = tools[key];
  }
  if (!isExecutableFile(exe)) {
    tools[key] = null;
    writeJson(toolsFile(), tools);
    throw new Error('The saved tool path no longer exists. Click Scan This PC or Browse to select the program again.');
  }
  const active = getActiveProject();
  const cwd = active?.folder && fs.existsSync(active.folder) ? active.folder : path.dirname(exe);
  const args = [];
  if (key === 'tunerPro' && active?.bin && fs.existsSync(active.bin)) {
    args.push(active.bin);
    if (active.xdf && fs.existsSync(active.xdf)) args.push(active.xdf);
  }
  let child;
  await new Promise((resolve, reject) => {
    child = spawn(exe, args, { detached: true, stdio: 'ignore', cwd, windowsHide: false });
    child.once('spawn', resolve);
    child.once('error', reject);
  }).catch(error => {
    throw new Error(`Windows could not launch ${path.basename(exe)}: ${error.message}`);
  });
  child.unref();
  appendActivity('tool-launched', { key, exe, args, cwd, activeProjectId: active?.id || null, activeProjectName: active?.name || null });
  return { launched: true, activeProject: active, exe, args };
});

ipcMain.handle('definition:scan', async (_event, payload = {}) => definitionCenterState(requireActive(), Boolean(payload.deep)));
ipcMain.handle('definition:resolve', async (_event, payload = {}) => resolveDefinitionForActive({ deep: payload.deep !== false }));
ipcMain.handle('definition:create-job', async () => {
  const active = requireActive();
  const job = ensureDefinitionJob(active);
  appendActivity('definition-job-created', { projectId: active.id, folder: job.folder, os: active.os || p01Manager.status(active).identity?.os || '' });
  return { job, center: definitionCenterState(active, false) };
});
ipcMain.handle('definition:inspect-job', async () => {
  const active = requireActive();
  const job = latestDefinitionJob(active);
  if (!job) return { job: null, center: definitionCenterState(active, false) };
  const p01 = p01Manager.status(active);
  return { job: inspectDefinitionJob(job.folder, { parseXdf, os: p01.identity?.os || active.os, binSize: active.binInfo?.size || 524288, controller: p01.identity?.controller || active.controller || '' }), center: definitionCenterState(active, false) };
});
ipcMain.handle('definition:open-job', async () => {
  const active = requireActive();
  const job = ensureDefinitionJob(active);
  const error = await shell.openPath(job.folder);
  if (error) throw new Error(error);
  return job.folder;
});
ipcMain.handle('definition:import-sources', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Definition sources', extensions: ['xdf', 'xml'] }, { name: 'All files', extensions: ['*'] }]
  });
  if (result.canceled || !result.filePaths.length) return { imported: [], center: definitionCenterState(active, false) };
  const destinationFolder = path.join(dataRoot(), 'Definitions', 'Imported');
  fs.mkdirSync(destinationFolder, { recursive: true });
  const imported = result.filePaths.map(source => copyProjectFile(source, destinationFolder));
  appendActivity('definition-sources-imported', { projectId: active.id, files: imported.map(file => path.basename(file)) });
  return { imported, center: definitionCenterState(active, true) };
});
ipcMain.handle('definition:bind-candidate', async (_event, source) => {
  const active = requireActive();
  const osId = String(p01Manager.status(active).identity?.os || active.os || '');
  const center = definitionCenterState(active, true);
  const allowed = [...center.xdfs, ...center.universalXml, ...(center.job?.accepted || [])].map(item => path.resolve(item.path));
  const resolved = path.resolve(String(source || ''));
  if (!allowed.includes(resolved)) throw new Error('The selected source is not an exact-OS candidate from Definition Center.');
  const installed = installExactDefinitionFile(resolved, active, osId);
  appendActivity('definition-candidate-bound', { projectId: active.id, os: osId, source: path.basename(resolved) });
  return { installed, center: definitionCenterState(getActiveProject(), false) };
});
ipcMain.handle('definition:launch-universal-patcher', async () => {
  const active = requireActive();
  const tools = scanTools(false);
  const layout = universalPatcherLayout(tools.universalPatcher);
  if (!layout.complete) throw new Error(layout.issues.join(' '));
  const job = ensureDefinitionJob(active);
  const target = job.manifest?.bin || active.bin;
  let child;
  await new Promise((resolve, reject) => {
    child = spawn(layout.exe, [target], { detached: true, stdio: 'ignore', cwd: layout.root, windowsHide: false });
    child.once('spawn', resolve); child.once('error', reject);
  });
  child.unref();
  appendActivity('universal-patcher-managed-job-launched', { projectId: active.id, exe: layout.exe, target, job: job.folder });
  return { launched: true, exe: layout.exe, target, job, center: definitionCenterState(active, false) };
});
ipcMain.handle('definition:launch-tunerpro', async () => {
  const active = requireActive();
  const tools = scanTools(false);
  if (!isExecutableFile(tools.tunerPro)) throw new Error('Configure TunerPro in Tool Setup first. TunIQ can tune natively without it, but TunerPro compatibility review requires tunerpro.exe.');
  if (!active.bin || !active.xdf || !fs.existsSync(active.bin) || !fs.existsSync(active.xdf)) throw new Error('Bind the exact XDF before starting a TunerPro compatibility roundtrip.');
  const folder = path.join(active.folder, 'Compatibility', 'TunerPro', `${Date.now()}-roundtrip`);
  fs.mkdirSync(folder, { recursive: true });
  const sourceBin = latestRevisionFile(active) || active.bin;
  const binCopy = path.join(folder, path.basename(sourceBin));
  const xdfCopy = path.join(folder, path.basename(active.xdf));
  fs.copyFileSync(sourceBin, binCopy); fs.copyFileSync(active.xdf, xdfCopy);
  const manifest = { schemaVersion: 1, createdAt: new Date().toISOString(), projectId: active.id, projectName: active.name, controller: active.controller || '', os: active.os, originalProtected: active.bin, sourceBin, workingBin: binCopy, xdf: xdfCopy, sourceSha256: sha256(sourceBin), xdfSha256: sha256(xdfCopy), status: 'managed-roundtrip', instructions: 'Edit and save the working BIN only. TunIQ imports changes as a new revision and never overwrites the protected original.' };
  writeJson(path.join(folder, 'roundtrip.json'), manifest);
  let child;
  await new Promise((resolve, reject) => {
    child = spawn(tools.tunerPro, [binCopy, xdfCopy], { detached: true, stdio: 'ignore', cwd: folder, windowsHide: false });
    child.once('spawn', resolve); child.once('error', reject);
  });
  child.unref();
  appendActivity('tunerpro-roundtrip-launched', { projectId: active.id, folder, bin: path.basename(binCopy), xdf: path.basename(xdfCopy) });
  return { launched: true, folder, manifest, status: inspectTunerProRoundtrip(active) };
});
ipcMain.handle('definition:inspect-tunerpro', async () => inspectTunerProRoundtrip(requireActive()));
ipcMain.handle('definition:import-tunerpro', async () => importTunerProRoundtrip(requireActive()));


ipcMain.handle('patch:launch-universal-managed', async (_event, payload = {}) => {
  const active = requireActive();
  const tools = scanTools(false); const layout = universalPatcherLayout(tools.universalPatcher);
  if (!layout.complete) throw new Error(layout.issues.join(' '));
  const job = createUniversalPatcherValidationJob(active, payload.targetFile);
  let child;
  await new Promise((resolve, reject) => {
    child = spawn(layout.exe, [job.manifest.workingFile], { detached:true, stdio:'ignore', cwd:layout.root, windowsHide:false });
    child.once('spawn', resolve); child.once('error', reject);
  });
  child.unref();
  appendActivity('universal-patcher-validation-launched', { projectId:active.id, job:job.folder, target:path.basename(job.manifest.sourceFile) });
  return { launched:true, job, status:inspectUniversalPatcherJob(active) };
});
ipcMain.handle('patch:inspect-universal-managed', async () => inspectUniversalPatcherJob(requireActive()));
ipcMain.handle('patch:import-universal-managed', async () => {
  const active = requireActive(); const job = inspectUniversalPatcherJob(active);
  if (!job) throw new Error('No managed Universal Patcher validation job exists.');
  if (job.readyBins.length !== 1) throw new Error(job.readyBins.length ? 'More than one compatible changed BIN was found. Keep only the intended output in the managed job Output folder.' : 'No compatible changed BIN has appeared in the managed Universal Patcher job yet.');
  const source = job.readyBins[0].path;
  const destination = path.join(active.folder, 'Revisions', `UP-${Date.now()}-${path.basename(source)}`);
  fs.copyFileSync(source, destination);
  if (job.validReports.length === 1) {
    const parsed = job.validReports[0].parsed;
    const report = { type:'universal-patcher-report', version:APP_VERSION, projectId:active.id, projectName:active.name, targetFile:destination, targetFileSha256:sha256(destination), report:{ ...parsed, name:path.basename(job.validReports[0].path) }, importedAt:new Date().toISOString(), managedJob:job.folder };
    writeJson(path.join(projectChecksumsRoot(active), `universal-${Date.now()}.json`), report);
  }
  const validation = analyzeProjectBin(destination);
  appendActivity('universal-patcher-output-imported', { projectId:active.id, source:path.basename(source), revision:path.basename(destination), checksumStatus:validation.checksumStatus });
  return { revision:{ path:destination, name:path.basename(destination), sha256:sha256(destination) }, validation, job:inspectUniversalPatcherJob(active) };
});

ipcMain.handle('workspace:get-summary', async () => {
  try {
    const raw = getWorkspaceSummary();
    const safe = safeIpcResult(raw);
    if (safe.ipcWarnings?.length) logStartup('workspace-summary:ipc-sanitized', safe.ipcWarnings.join(' | '));
    return safe;
  } catch (error) {
    logCrash('workspace-summary-failure', error);
    return safeIpcResult({
      generatedAt: new Date().toISOString(),
      activeProject: getActiveProject(),
      tools: scanTools(false),
      files: {}, folders: {}, activity: [], calibration: null, calibrationHistory: [],
      tunePath: { steps: [], completed: 0, total: 0, progress: 0 },
      error: { name: error?.name || 'Error', code: error?.code || 'workspace-summary-failed', message: error?.message || String(error) }
    }, { fallback: true });
  }
});
ipcMain.handle('workspace:reconcile', async () => {
  try {
    const result = reconcileActiveCommissioningWorkspace({ advanceAutomation: false, reason: 'manual workspace refresh' });
    emitP01Auto(result.auto);
    return safeIpcResult({ ...result, summary: getWorkspaceSummary() });
  } catch (error) {
    logCrash('workspace-reconcile-failure', error);
    throw error;
  }
});

ipcMain.handle('workspace:open-subfolder', async (_event, key) => {
  const active = requireActive();
  const allowed = {
    project: active.folder,
    originals: path.join(active.folder, 'Originals'),
    definitions: path.join(active.folder, 'Definitions'),
    revisions: path.join(active.folder, 'Revisions'),
    logs: path.join(active.folder, 'Logs'),
    backups: path.join(active.folder, 'Backups'),
    reports: path.join(active.folder, 'Reports'),
    checksums: path.join(active.folder, 'Checksums')
  };
  const folder = allowed[key];
  if (!folder) throw new Error('Unknown project folder.');
  fs.mkdirSync(folder, { recursive: true });
  const error = await shell.openPath(folder);
  if (error) throw new Error(error);
  return folder;
});
ipcMain.handle('workspace:plan-action', async (_event, payload) => {
  const active = requireActive();
  const action = String(payload?.action || 'unknown');
  const allowed = new Set(['identify-controller', 'read-original', 'analyze-bin']);
  if (!allowed.has(action)) throw new Error('Unsupported workspace action.');
  const tools = scanTools(false);
  if ((action === 'identify-controller' || action === 'read-original') && !active.controller) throw new Error('Enter the project controller before preparing a PCM operation.');
  if ((action === 'identify-controller' || action === 'read-original') && !isExecutableFile(tools.pcmHammer)) throw new Error('Configure PCM Hammer in Tool Setup before preparing this operation.');
  if (action === 'analyze-bin' && (!active.bin || !fs.existsSync(active.bin))) throw new Error('Import the protected original BIN before running analysis.');
  const details = {
    action,
    projectId: active.id,
    projectName: active.name,
    controller: active.controller || null,
    os: active.os || null,
    bin: active.binInfo?.name || null,
    at: new Date().toISOString()
  };
  appendActivity('workspace-action-prepared', details);
  return details;
});


ipcMain.handle('ai:get-intake', async () => loadAiBundle(requireActive()));
ipcMain.handle('ai:save-intake', async (_event, payload) => {
  const active = requireActive();
  const intake = normalizeAiIntake(payload, active);
  if (!intake.engine) throw new Error('Enter the engine before building a Full AI plan.');
  if (!intake.transmission) throw new Error('Enter the transmission or choose Manual / No transmission control.');
  if (!intake.tuneGoal) throw new Error('Choose what you want the tune to accomplish.');
  const camNeeded = intake.modifications.map(item => item.toLowerCase()).includes('aftermarket camshaft') || intake.tuneGoal.toLowerCase().includes('camshaft');
  if (camNeeded && !(intake.cam.durationIntake && intake.cam.durationExhaust && intake.cam.lsa)) {
    throw new Error('A camshaft tune needs at least intake duration, exhaust duration, and LSA.');
  }
  writeJson(aiIntakeFile(active), intake);
  appendActivity('ai-intake-saved', { projectId: active.id, projectName: active.name, goal: intake.tuneGoal, engine: intake.engine, transmission: intake.transmission });
  return intake;
});
ipcMain.handle('ai:generate-plan', async (_event, payload) => {
  const active = requireActive();
  const intake = normalizeAiIntake(payload, active);
  if (!intake.engine || !intake.transmission || !intake.tuneGoal) throw new Error('Engine, transmission, and tune goal are required.');
  const camNeeded = intake.modifications.map(item => item.toLowerCase()).includes('aftermarket camshaft') || intake.tuneGoal.toLowerCase().includes('camshaft');
  if (camNeeded && !(intake.cam.durationIntake && intake.cam.durationExhaust && intake.cam.lsa)) throw new Error('Enter the cam duration and LSA before generating this plan.');
  const plan = buildFullAiPlan(active, intake);
  writeJson(aiIntakeFile(active), intake);
  writeJson(aiPlanFile(active), plan);
  appendActivity('ai-plan-generated', { projectId: active.id, projectName: active.name, planId: plan.id, goal: plan.goal, steps: plan.steps.length });
  return { intake, plan };
});


ipcMain.handle('tune-engine:status', async () => {
  const active = getActiveProject();
  if (!active) return { active: false, plan: null, proposals: [], audit: [] };
  let workspace = null;
  try { workspace = loadCalibration(); } catch {}
  return tuneEngineManager.status(active, workspace);
});
ipcMain.handle('tune-engine:build-plan', async (_event, payload = {}) => {
  const active = requireActive();
  const existing = loadAiBundle(active).intake || {};
  const intake = normalizeAiIntake({ ...existing, ...(payload.intake || {}) }, active);
  if (!intake.engine || !intake.transmission || !intake.tuneGoal) throw new Error('Complete the engine, transmission, and tune goal before building the Unified Tune Engine plan.');
  const workspace = loadCalibration();
  tuneWorkspaceManager.assertBinding(workspace, active, { requireXdf: true });
  writeJson(aiIntakeFile(active), intake);
  const plan = tuneEngineManager.createPlan(active, intake, workspace, payload.targets || {});
  return { plan, intake, status: tuneEngineManager.status(active, workspace) };
});
ipcMain.handle('tune-engine:build-stage', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  const plan = tuneEngineManager.loadPlan(active);
  if (!plan) throw new Error('Build the Unified Tune Engine plan first.');
  const proposal = buildStageProposal({ plan, stageId: payload.stageId, workspace, activeProject: active, csvPath: payload.csvPath || null });
  const saved = tuneEngineManager.saveProposal(active, proposal);
  appendActivity('tune-engine-stage-proposal-created', { projectId: active.id, planId: plan.id, stageId: proposal.stageId, proposedCells: proposal.summary.proposedCells, blocked: proposal.blocked });
  return saved;
});
ipcMain.handle('tune-engine:apply-stage', async (_event, payload = {}) => {
  const active = requireActive();
  const plan = tuneEngineManager.loadPlan(active);
  if (!plan) throw new Error('Build the Unified Tune Engine plan first.');
  const proposal = tuneEngineManager.getProposal(active, payload.proposalId);
  if (!proposal) throw new Error('The selected Tune Engine stage proposal was not found.');
  const workspace = loadCalibration();
  tuneWorkspaceManager.createSnapshot(active, workspace, { name: `Before ${proposal.stageTitle}`, note: `Automatic safety snapshot before Tune Engine stage ${proposal.stageId}.` }, validateCalibrationWorkspace);
  const result = applyStageProposal(workspace, proposal, payload.approvedIds || []);
  validateCalibrationWorkspace(result.workspace);
  saveCalibrationWorkspace(result.workspace);
  const revision = exportCalibrationWorkspace(result.workspace, { suffix: `TuneEngine-${proposal.stageId}`, autoCorrectChecksums: true });
  const snapshot = tuneWorkspaceManager.createSnapshot(active, result.workspace, { name: `${proposal.stageTitle} Applied`, note: `${result.applied.length} approved Tune Engine cell(s); revision ${revision.name}.` }, validateCalibrationWorkspace);
  const updatedPlan = tuneEngineManager.recordApplied(active, plan, proposal, result.applied, revision);
  return { applied: result.applied, workspace: result.workspace, revision, snapshot, plan: updatedPlan, status: tuneEngineManager.status(active, result.workspace) };
});
ipcMain.handle('tune-engine:create-handoff', async (_event, payload = {}) => {
  const active = requireActive();
  const plan = tuneEngineManager.loadPlan(active);
  if (!plan) throw new Error('Build the Unified Tune Engine plan first.');
  const workspace = loadCalibration();
  let revision = null;
  if (payload.revisionPath && fs.existsSync(payload.revisionPath)) revision = { path: payload.revisionPath };
  else {
    const latest = listFilesSafe(path.join(active.folder, 'Revisions'), ['.bin'])[0];
    if (latest?.path) revision = { path: latest.path };
  }
  return tuneEngineManager.createHandoff(active, plan, workspace, revision);
});
ipcMain.handle('tune-engine:reset', async () => tuneEngineManager.reset(requireActive()));
ipcMain.handle('tune-engine:open-handoff', async (_event, folder) => {
  const active = requireActive();
  const root = path.resolve(path.join(active.folder, 'Handoff'));
  const target = path.resolve(folder || root);
  if (target !== root && !target.startsWith(`${root}${path.sep}`)) throw new Error('Blocked handoff path outside the active project.');
  const error = await shell.openPath(target);
  if (error) throw new Error(error);
  return target;
});



function latestAutonomousLog(payload = {}) {
  if (payload?.targets?.selectedLog && fs.existsSync(payload.targets.selectedLog)) return payload.targets.selectedLog;
  if (payload?.selectedLog && fs.existsSync(payload.selectedLog)) return payload.selectedLog;
  const latest = obdManager.listLogs().find(item => item.exists && item.csvPath && fs.existsSync(item.csvPath));
  return latest?.csvPath || null;
}
function autonomousTuneCallbacks(active) {
  return {
    validateWorkspace: validateCalibrationWorkspace,
    saveWorkspace: workspace => saveCalibrationWorkspace(workspace),
    createSnapshot: (workspace, payload) => tuneWorkspaceManager.createSnapshot(active, workspace, payload, validateCalibrationWorkspace),
    exportRevision: (workspace, options = {}) => exportCalibrationWorkspace(workspace, { suffix: options.suffix || 'Autonomous-Tune', autoCorrectChecksums: true }),
    createHandoff: (plan, workspace, revision) => tuneEngineManager.createHandoff(active, plan, workspace, revision)
  };
}
ipcMain.handle('autonomous-tune:status', async () => {
  const active = getActiveProject();
  if (!active) return { active: false, run: null, audit: [] };
  let workspace = null;
  try { workspace = loadCalibration(); } catch {}
  return autonomousTuneManager.status(active, workspace);
});
ipcMain.handle('autonomous-tune:start', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  tuneWorkspaceManager.assertBinding(workspace, active, { requireXdf: true });
  const existing = loadAiBundle(active).intake || {};
  const intake = normalizeAiIntake({ ...existing, ...(payload.intake || {}) }, active);
  if (!intake.engine || !intake.transmission || !intake.tuneGoal) throw new Error('Complete the engine, transmission, and tune goal before starting Autonomous Tune.');
  const selectedLog = latestAutonomousLog(payload);
  const rawTargets = { ...(payload.targets || {}), selectedLog };
  const authorization = payload.authorization || {};
  const targets = deriveAutonomousTargets(intake, rawTargets, authorization);
  writeJson(aiIntakeFile(active), intake);
  const result = await executeAutonomousTune({
    manager: autonomousTuneManager,
    engineManager: tuneEngineManager,
    active,
    intake,
    workspace,
    targets,
    authorization,
    mode: payload.mode === 'log-cycle' ? 'log-cycle' : 'complete',
    callbacks: autonomousTuneCallbacks(active)
  });
  return { ...result, status: autonomousTuneManager.status(active, result.workspace || workspace), tuneEngine: tuneEngineManager.status(active, result.workspace || workspace) };
});
ipcMain.handle('autonomous-tune:resume', async () => {
  const active = requireActive();
  const workspace = loadCalibration();
  const run = autonomousTuneManager.load(active);
  if (!run) throw new Error('No autonomous tune run exists to resume.');
  const result = await executeAutonomousTune({
    manager: autonomousTuneManager,
    engineManager: tuneEngineManager,
    active,
    intake: run.intake,
    workspace,
    targets: run.targets,
    authorization: run.authorization,
    mode: run.mode,
    resume: true,
    callbacks: autonomousTuneCallbacks(active)
  });
  return { ...result, status: autonomousTuneManager.status(active, result.workspace || workspace), tuneEngine: tuneEngineManager.status(active, result.workspace || workspace) };
});
ipcMain.handle('autonomous-tune:run-log-cycle', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  const existing = loadAiBundle(active).intake || {};
  const intake = normalizeAiIntake({ ...existing, ...(payload.intake || {}) }, active);
  const selectedLog = latestAutonomousLog(payload);
  if (!selectedLog) throw new Error('Import or record a completed log before running an autonomous correction cycle.');
  const authorization = payload.authorization || {};
  const targets = deriveAutonomousTargets(intake, { ...(payload.targets || {}), selectedLog }, authorization);
  const result = await executeAutonomousTune({
    manager: autonomousTuneManager,
    engineManager: tuneEngineManager,
    active,
    intake,
    workspace,
    targets,
    authorization,
    mode: 'log-cycle',
    callbacks: autonomousTuneCallbacks(active)
  });
  return { ...result, status: autonomousTuneManager.status(active, result.workspace || workspace), tuneEngine: tuneEngineManager.status(active, result.workspace || workspace) };
});
ipcMain.handle('autonomous-tune:reset', async () => autonomousTuneManager.reset(requireActive()));

function closedLoopCallbacks(active) {
  return {
    createSnapshot: (workspace, payload) => tuneWorkspaceManager.createSnapshot(active, workspace, payload, validateCalibrationWorkspace),
    restoreSnapshot: snapshotId => tuneWorkspaceManager.restore(active, snapshotId, validateCalibrationWorkspace),
    exportRevision: (workspace, options = {}) => exportCalibrationWorkspace(workspace, { suffix: options.suffix || 'ClosedLoop', autoCorrectChecksums: true }),
    runCorrection: async csvPath => {
      const currentWorkspace = loadCalibration();
      const baseRun = autonomousTuneManager.load(active);
      if (!baseRun) throw new Error('Complete an Autonomous Tune run before starting closed-loop correction.');
      const result = await executeAutonomousTune({
        manager: autonomousTuneManager,
        engineManager: tuneEngineManager,
        active,
        intake: baseRun.intake,
        workspace: currentWorkspace,
        targets: { ...baseRun.targets, selectedLog: csvPath },
        authorization: baseRun.authorization,
        mode: 'log-cycle',
        callbacks: autonomousTuneCallbacks(active)
      });
      return result;
    }
  };
}
function emitClosedLoopUpdate(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send('closed-loop:updated', payload);
}
async function autoProcessClosedLoopLog(active, csvPath) {
  const session = closedLoopTuneManager.load(active);
  if (!session?.autoProcessNewLogs || !csvPath || !fs.existsSync(csvPath)) return null;
  if (getActiveProject()?.id !== active.id) {
    appendActivity('closed-loop-auto-process-deferred', { projectId: active.id, csvPath, reason: 'active-project-changed' });
    return null;
  }
  try {
    let workspace = loadCalibration();
    let result;
    if (session.phase === 'awaiting-validation-log') result = await analyzeClosedLoopValidation({ manager: closedLoopTuneManager, active, workspace, csvPath, callbacks: closedLoopCallbacks(active) });
    else result = { ...closedLoopTuneManager.analyze(active, workspace, csvPath, { role: 'automatic-log-ingest' }), workspace };
    workspace = result.workspace || workspace;
    let currentSession = result.session;
    if (currentSession?.status === 'ready-for-correction' && currentSession.autoRunCorrections) {
      result = await executeClosedLoopCorrection({ manager: closedLoopTuneManager, active, workspace, csvPath, callbacks: closedLoopCallbacks(active) });
      workspace = result.workspace || workspace;
      currentSession = result.session;
    }
    const payload = { ok: true, projectId: active.id, csvPath, result, status: closedLoopTuneManager.status(active, workspace, autonomousTuneManager.load(active)) };
    emitClosedLoopUpdate(payload);
    return payload;
  } catch (error) {
    appendActivity('closed-loop-auto-process-stopped', { projectId: active.id, csvPath, error: error.message });
    const payload = { ok: false, projectId: active.id, csvPath, error: error.message, status: closedLoopTuneManager.status(active, (() => { try { return loadCalibration(); } catch { return null; } })(), autonomousTuneManager.load(active)) };
    emitClosedLoopUpdate(payload);
    return payload;
  }
}
ipcMain.handle('closed-loop:status', async () => {
  const active = getActiveProject();
  if (!active) return { active: false, session: null, evaluations: [], audit: [], readiness: null };
  let workspace = null;
  try { workspace = loadCalibration(); } catch {}
  return closedLoopTuneManager.status(active, workspace, autonomousTuneManager.load(active));
});
ipcMain.handle('closed-loop:start', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  tuneWorkspaceManager.assertBinding(workspace, active, { requireXdf: true });
  const autonomousRun = autonomousTuneManager.load(active);
  if (!autonomousRun) throw new Error('Complete an Autonomous Tune run before starting closed-loop validation.');
  const stable = tuneWorkspaceManager.createSnapshot(active, workspace, { name: 'Closed-Loop Baseline Recovery', note: 'Protected rollback point before adaptive closed-loop correction cycles.' }, validateCalibrationWorkspace);
  const session = closedLoopTuneManager.start(active, workspace, autonomousRun, { ...(payload || {}), lastStableSnapshotId: stable.id });
  return closedLoopTuneManager.status(active, workspace, autonomousRun);
});
ipcMain.handle('closed-loop:analyze-latest', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  const selectedLog = latestAutonomousLog(payload);
  if (!selectedLog) throw new Error('Import or record a completed validation log first.');
  const session = closedLoopTuneManager.load(active);
  if (!session) throw new Error('Start Closed-Loop Tuning first.');
  const result = session.phase === 'awaiting-validation-log'
    ? await analyzeClosedLoopValidation({ manager: closedLoopTuneManager, active, workspace, csvPath: selectedLog, callbacks: closedLoopCallbacks(active) })
    : { ...closedLoopTuneManager.analyze(active, workspace, selectedLog, { role: 'baseline' }), workspace };
  return { ...result, status: closedLoopTuneManager.status(active, result.workspace || workspace, autonomousTuneManager.load(active)) };
});
ipcMain.handle('closed-loop:run-cycle', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  const selectedLog = latestAutonomousLog(payload);
  if (!selectedLog) throw new Error('Import or record a completed log before running a closed-loop correction.');
  const result = await executeClosedLoopCorrection({ manager: closedLoopTuneManager, active, workspace, csvPath: selectedLog, callbacks: closedLoopCallbacks(active) });
  return { ...result, status: closedLoopTuneManager.status(active, result.workspace || workspace, autonomousTuneManager.load(active)), tuneEngine: tuneEngineManager.status(active, result.workspace || workspace), autonomousTune: autonomousTuneManager.status(active, result.workspace || workspace) };
});
ipcMain.handle('closed-loop:rollback', async (_event, payload = {}) => {
  const active = requireActive();
  const workspace = loadCalibration();
  const session = closedLoopTuneManager.load(active);
  if (!session) throw new Error('No Closed-Loop Tuning session exists.');
  const snapshotId = payload.snapshotId || session.rollbackSnapshotId || session.lastStableSnapshotId;
  if (!snapshotId) throw new Error('No closed-loop rollback snapshot is available.');
  const restored = tuneWorkspaceManager.restore(active, snapshotId, validateCalibrationWorkspace);
  const revision = exportCalibrationWorkspace(restored, { suffix: 'ClosedLoop-Manual-Rollback', autoCorrectChecksums: true });
  const updated = closedLoopTuneManager.markRollback(active, restored, { snapshotId, revision, reason: payload.reason || 'Manual closed-loop rollback requested.' });
  return { session: updated, workspace: restored, revision, status: closedLoopTuneManager.status(active, restored, autonomousTuneManager.load(active)) };
});
ipcMain.handle('closed-loop:export-report', async () => {
  const active = requireActive();
  const workspace = loadCalibration();
  return closedLoopTuneManager.exportReport(active, workspace, autonomousTuneManager.load(active));
});
ipcMain.handle('closed-loop:reset', async () => closedLoopTuneManager.reset(requireActive()));

ipcMain.handle('tune-library:list', async () => listTuneLibrary());
ipcMain.handle('tune-library:save-active', async (_event, payload) => saveTuneToLibrary(payload));
ipcMain.handle('tune-library:favorite', async (_event, id) => {
  const items = listTuneLibrary();
  const entry = items.find(item => item.id === id);
  if (!entry) throw new Error('Tune not found.');
  entry.favorite = !entry.favorite; entry.updatedAt = new Date().toISOString(); writeJson(tuneLibraryFile(), items); return entry;
});
ipcMain.handle('tune-library:delete', async (_event, id) => {
  const items = listTuneLibrary(); const entry = items.find(item => item.id === id); if (!entry) return true;
  removeFileQuietly(entry.sourceFile); writeJson(tuneLibraryFile(), items.filter(item => item.id !== id));
  appendActivity('tune-library-deleted', { id, name: entry.name }); return true;
});
ipcMain.handle('tune-library:apply', async (_event, id) => {
  const active = requireActive(); const entry = getTuneEntry(id); if (!entry) throw new Error('Tune not found.');
  if (!entry.sourceFile || !fs.existsSync(entry.sourceFile)) throw new Error('The tune file is missing from the local library.');
  const compatibility = tuneCompatibility(entry, active);
  if (!compatibility.compatible) throw new Error(`This tune cannot be imported: ${compatibility.problems.join('; ')}`);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = path.join(active.folder, 'Revisions', `Library-${safeTuneName(entry.name)}-${stamp}.bin`);
  fs.mkdirSync(path.dirname(output), { recursive: true }); fs.copyFileSync(entry.sourceFile, output);
  const result = { name: path.basename(output), path: output, size: fs.statSync(output).size, sha256: sha256(output), compatibility };
  appendActivity('tune-library-imported', { tuneId: entry.id, tuneName: entry.name, projectId: active.id, projectName: active.name, output: result.name });
  return result;
});
ipcMain.handle('tune-library:export', async (_event, id) => {
  const entry = getTuneEntry(id); if (!entry) throw new Error('Tune not found.');
  if (!entry.sourceFile || !fs.existsSync(entry.sourceFile)) throw new Error('The tune file is missing.');
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath: `${safeTuneName(entry.name)}.tuniqtune`, filters: [{ name: 'TunIQ Tune Package', extensions: ['tuniqtune'] }] });
  if (result.canceled || !result.filePath) return null;
  const packageData = { format: 'TunIQTunePackage', version: 1, exportedAt: new Date().toISOString(), tune: { ...entry, sourceFile: null }, binBase64: fs.readFileSync(entry.sourceFile).toString('base64') };
  writeJson(result.filePath, packageData); return result.filePath;
});
ipcMain.handle('tune-library:import', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'TunIQ Tune Package', extensions: ['tuniqtune'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const raw = readJson(result.filePaths[0], null);
  if (raw?.format !== 'TunIQTunePackage' || raw?.version !== 1 || !raw?.tune || !raw?.binBase64) throw new Error('This is not a supported TunIQ tune package.');
  const buffer = Buffer.from(raw.binBase64, 'base64');
  if (!buffer.length || buffer.length > 16 * 1024 * 1024) throw new Error('Tune package BIN size is invalid.');
  const name = safeTuneName(raw.tune.name || 'Imported Tune'); const id = `${Date.now()}-imported-${name.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`;
  const destination = path.join(tuneLibraryFilesRoot(), `${id}.bin`); fs.writeFileSync(destination, buffer);
  const entry = { ...raw.tune, id, name, sourceFile: destination, sourceFileName: path.basename(destination), sourceSha256: sha256(destination), favorite: false, importedAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  const items = listTuneLibrary(); items.unshift(entry); writeJson(tuneLibraryFile(), items);
  appendActivity('tune-package-imported', { id, name }); return entry;
});

ipcMain.handle('community:list', async () => listCommunityPosts());
ipcMain.handle('community:create-post', async (_event, payload) => {
  const title = cleanText(payload?.title, 180); const body = cleanText(payload?.body, 8000); if (!title || !body) throw new Error('Post title and details are required.');
  const active = getActiveProject(); const profile = readJson(profileFile(), {});
  const post = { id: `${Date.now()}-post`, official: false, category: cleanText(payload?.category, 60) || 'Problems & Help', title, engine: cleanText(payload?.engine, 120) || 'Unspecified', transmission: cleanText(payload?.transmission, 120) || 'Unspecified', controller: cleanText(payload?.controller || active?.controller, 80) || 'Unspecified', body, author: cleanText(profile.name, 100) || 'Local User', tags: cleanList(payload?.tags, 30), projectContext: payload?.attachProject && active ? { projectId: active.id, projectName: active.name, vehicle: active.vehicle, controller: active.controller, os: active.os, bin: active.binInfo?.name || null, xdf: active.xdfInfo?.name || null } : null, createdAt: new Date().toISOString() };
  const posts = listCommunityPosts(); posts.unshift(post); writeJson(communityPostsFile(), posts);
  appendActivity('community-post-created', { id: post.id, title: post.title, category: post.category, projectId: active?.id || null }); return post;
});
ipcMain.handle('community:delete-post', async (_event, id) => {
  const posts = listCommunityPosts(); const post = posts.find(item => item.id === id); if (!post || post.official) throw new Error('Official posts cannot be deleted.');
  writeJson(communityPostsFile(), posts.filter(item => item.id !== id)); return true;
});

ipcMain.handle('device:list', async () => obdManager.listDevices());
ipcMain.handle('device:status', async () => obdManager.getStatus());
ipcMain.handle('device:doctor-status', async () => obdManager.getConnectionDoctorStatus());
ipcMain.handle('device:doctor-run', async (_event, payload) => obdManager.runConnectionDoctor(payload));
ipcMain.handle('lab:p01-status', async () => p01LabManager.status());
ipcMain.handle('lab:p01-run', async () => p01LabManager.runAll());
ipcMain.handle('device:connect', async (_event, payload) => obdManager.connect(payload));
ipcMain.handle('device:disconnect', async () => obdManager.disconnect());
ipcMain.handle('device:sample', async () => obdManager.sample());
ipcMain.handle('logger:start', async (_event, payload) => obdManager.startLog(payload));
ipcMain.handle('logger:mark', async (_event, label) => obdManager.markLog(label));
ipcMain.handle('logger:stop', async () => { const result = await obdManager.stopLog(); const active = getActiveProject(); const csvPath = result?.csvPath || result?.path || null; if (active && csvPath) autoProcessClosedLoopLog(active, csvPath); return result; });
ipcMain.handle('logger:list', async () => obdManager.listLogs());
ipcMain.handle('logger:analyze', async (_event, csvPath) => obdManager.analyzeLog(csvPath));
ipcMain.handle('logger:profiles', async () => SENSOR_PROFILES);
ipcMain.handle('logger:obdlink-guide', async (_event, profile = 'baseline') => ({
  profile,
  recommendedFields: recommendedFields(profile),
  instructions: [
    'In the OBDLink mobile app, enable CSV logging and select the PIDs needed for the test.',
    'For the fastest exported data, use Trigger on PID frame.',
    'After the drive, open Logs → Files → Share and save or send the CSV file.',
    'Import the CSV here. TunIQ removes VIN/GPS/location columns and maps recognized sensor names.'
  ]
}));
ipcMain.handle('logger:import-obdlink', async (_event, payload = {}) => {
  const active = requireActive();
  let sourceFile = String(payload.sourceFile || '');
  if (!sourceFile) {
    const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [
      { name: 'OBDLink / TunIQ Phone Logs', extensions: ['csv','txt','log','tuniqlog','json'] },
      { name: 'All Files', extensions: ['*'] }
    ] });
    if (result.canceled || !result.filePaths[0]) return null;
    sourceFile = result.filePaths[0];
  }
  const imported = importPhoneLog({ sourceFile, activeProject: active, profile: payload.profile || 'baseline', name: payload.name || '' });
  const analysis = obdManager.analyzeLog(imported.csvPath);
  appendActivity('obdlink-phone-log-imported', { projectId: active.id, projectName: active.name, source: path.basename(sourceFile), samples: imported.samples, quality: imported.importQuality?.status, privateColumnsRemoved: imported.privateColumnsRemoved?.length || 0 });
  const closedLoopQueued = Boolean(closedLoopTuneManager.load(active)?.autoProcessNewLogs);
  if (closedLoopQueued) autoProcessClosedLoopLog(active, imported.csvPath);
  return { ...imported, analysis, closedLoopQueued };
});

ipcMain.handle('p01-evidence:list', async () => p01EvidenceManager.list());
ipcMain.handle('p01-evidence:import', async (_event, payload = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [
    { name: 'P01 Evidence Files', extensions: ['csv','txt','log','json','tuniqlog','xdf','bin'] },
    { name: 'All Files', extensions: ['*'] }
  ] });
  if (result.canceled || !result.filePaths[0]) return null;
  return p01EvidenceManager.importFile(result.filePaths[0], payload || {});
});
ipcMain.handle('p01-evidence:delete', async (_event, id) => p01EvidenceManager.deleteImport(String(id || '')));
ipcMain.handle('p01-evidence:open-source', async (_event, sourceId) => {
  const source = p01EvidenceManager.findSource(String(sourceId || ''));
  if (!source?.sourceUrl) throw new Error('No public source URL is registered for this evidence item.');
  await shell.openExternal(source.sourceUrl);
  return true;
});

ipcMain.handle('pid:get-library', async () => obdManager.getPidLibrary());
ipcMain.handle('pid:save-library', async (_event, payload) => obdManager.savePidLibrary(payload));
ipcMain.handle('pid:import-library', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'TunIQ PID Profile', extensions: ['json'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const payload = readJson(result.filePaths[0], null);
  if (!payload?.profiles || !Array.isArray(payload.profiles)) throw new Error('The selected file is not a TunIQ PID profile library.');
  return obdManager.savePidLibrary(payload);
});

ipcMain.handle('flash:status', async () => flashManager.status());
ipcMain.handle('flash:probe', async (_event, payload) => flashManager.probe(payload || {}));
ipcMain.handle('flash:set-gui-executable', async (_event, executable) => flashManager.saveGuiExecutable(executable));
ipcMain.handle('flash:save-device', async (_event, device) => flashManager.saveDevice(device));
ipcMain.handle('flash:save-templates', async (_event, templates) => flashManager.saveTemplates(templates || {}));
ipcMain.handle('flash:start', async (_event, payload) => {
  const requestedOperation = String(payload?.operation || '');
  const operation = requestedOperation === 'identify' ? 'readProperties' : requestedOperation;
  if (!['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].includes(operation)) throw new Error('Unsupported PCM Hammer operation.');
  const options = { ...(payload || {}), operation };
  const activeForSupport = getActiveProject();
  const deviceForSupport = obdManager.getStatus()?.connection || {};
  let validated = null;
  let p01Proof = null;
  if (['testWrite','writeCalibration','writeFull','recovery'].includes(operation)) {
    validated = requireValidatedRevision(payload?.input);
    options.input = validated.input;
    options.checksumApproved = true;
    if (operation !== 'recovery') p01Proof = p01Manager.assertOperationReady(operation, validated.input);
  }
  try {
    betaManager.assertFlashAllowed(operation, { controller: activeForSupport?.controller, os: activeForSupport?.os, adapter: deviceForSupport.adapter, port: deviceForSupport.port });
  } catch (error) {
    const commissionedP01 = p01Proof?.applicable && ((operation === 'testWrite' && p01Proof.readyForTestWrite) || (operation === 'writeCalibration' && p01Proof.readyForWrite));
    if (!commissionedP01) throw error;
    appendActivity('p01-commissioned-beta-override', { projectId: activeForSupport?.id, projectName: activeForSupport?.name, operation, revision: validated ? path.basename(validated.input) : null });
  }
  return flashManager.start(operation, options);
});
ipcMain.handle('flash:cancel', async () => flashManager.cancel());
ipcMain.handle('flash:assisted-start', async (_event, payload = {}) => flashManager.launchAssisted(payload.operation || 'readProperties', payload, payload.reason || null));
ipcMain.handle('flash:assisted-scan', async () => flashManager.scanAssisted());
ipcMain.handle('flash:assisted-import', async (_event, payload = {}) => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile', 'multiSelections'], filters: [
    { name: 'PCM Hammer evidence', extensions: ['bin','txt','log'] }, { name: 'All files', extensions: ['*'] }
  ] });
  if (result.canceled || !result.filePaths.length) return null;
  return flashManager.importAssistedEvidence(result.filePaths, payload);
});
ipcMain.handle('p01-auto:status', async () => p01AutoSnapshot());
ipcMain.handle('p01-auto:start', async (_event, payload = {}) => {
  // Beta.26: Start means Continue whenever this project already has P01 evidence. It must
  // never clear the completion ledger, restart Read 1, or discard a verified pair.
  let existing = p01AutoManager.load();
  let repair = null;
  try { repair = p01Manager.repairVerifiedReadPair('Start button continuity recovery'); } catch {}
  let p01 = null;
  try { p01 = repair?.status || p01Manager.status(requireActive()); } catch {}
  const hasDurableEvidence = Boolean(
    existing.status !== 'idle' || existing.id ||
    p01?.identity?.os || p01?.readPair?.first || p01?.dualReadVerified || p01?.testWrite
  );
  let state;
  if (hasDurableEvidence) {
    clearTimeout(p01AutoTimer);
    p01AutoBusy = false;
    flashManager.clearTransientRecoveryState('Guided P01 Start treated as Continue');
    const patch = {
      status: 'running', blocker: null, stop: null,
      request: String(payload.request || existing.request || 'Finish verified P01 commissioning setup'),
      confirmations: { ...(existing.confirmations || {}), ...(payload.confirmations || {}) },
      device: String(payload.device || existing.device || flashManager.status().device || ''),
      voltage: Number.isFinite(Number(payload.voltage)) ? Number(payload.voltage) : existing.voltage,
      benchPowerConfirmed: Object.prototype.hasOwnProperty.call(payload, 'benchPowerConfirmed') ? Boolean(payload.benchPowerConfirmed) : Boolean(existing.benchPowerConfirmed),
      exactXdfAuthorization: Object.prototype.hasOwnProperty.call(payload, 'exactXdfAuthorization') ? Boolean(payload.exactXdfAuthorization) : Boolean(existing.exactXdfAuthorization),
      autoMapAuthorized: Object.prototype.hasOwnProperty.call(payload, 'autoMapAuthorized') ? Boolean(payload.autoMapAuthorized) : Boolean(existing.autoMapAuthorized),
      autoRevisionAuthorized: Object.prototype.hasOwnProperty.call(payload, 'autoRevisionAuthorized') ? Boolean(payload.autoRevisionAuthorized) : Boolean(existing.autoRevisionAuthorized),
      testWriteAuthorized: Object.prototype.hasOwnProperty.call(payload, 'testWriteAuthorized') ? Boolean(payload.testWriteAuthorized) : Boolean(existing.testWriteAuthorized)
    };
    state = p01AutoManager.patch(patch, { level: 'info', text: 'Start was treated as Continue. Existing P01 identity, matching reads, definition, revision, and Test Write progress were preserved.' });
    state = reconcileP01AutoEvidence(state);
    try {
      const reconciled = reconcileActiveCommissioningWorkspace({ advanceAutomation: true, reason: 'Start button continuity finalization' });
      state = reconciled.auto || state;
    } catch {}
    if (state.status !== 'running') state = p01AutoManager.resume();
  } else {
    state = p01AutoManager.begin(payload);
  }
  if (payload.device) flashManager.saveDevice(payload.device);
  emitP01Auto(state); scheduleP01Auto(); return p01AutoSnapshot(state);
});
ipcMain.handle('p01-auto:resume', async (_event, payload = {}) => {
  clearTimeout(p01AutoTimer);
  p01AutoBusy = false;
  flashManager.clearTransientRecoveryState('Guided P01 Resume requested');
  let current = p01AutoManager.load();
  try {
    const reconciliation = reconcileActiveCommissioningWorkspace({ advanceAutomation: true, reason: 'Resume Failed Step requested' });
    current = reconciliation.auto || current;
    if (reconciliation.reconciled && current.status === 'running' && current.phase === 'create-revision') {
      emitP01Auto(current); scheduleP01Auto(); return p01AutoSnapshot(current);
    }
  } catch (error) {
    logStartup('p01-auto:resume-reconcile-skipped', error.message);
  }
  if (['ready-to-write','write-complete'].includes(current.phase)) return p01AutoSnapshot(current);
  if (!p01AutoManager.canResume(current) && current.status === 'running' && /^waiting-/.test(String(current.phase || '')) && !flashManager.status().session) {
    current = p01AutoManager.recover('stale waiting step had no active PCM Hammer session');
  }
  const patch = {};
  if (payload.selectedXdf) patch.selectedXdf = String(payload.selectedXdf);
  if (payload.device) { patch.device = String(payload.device); flashManager.saveDevice(payload.device); }
  if (Object.prototype.hasOwnProperty.call(payload, 'voltage')) patch.voltage = Number.isFinite(Number(payload.voltage)) ? Number(payload.voltage) : null;
  if (Object.prototype.hasOwnProperty.call(payload, 'benchPowerConfirmed')) patch.benchPowerConfirmed = Boolean(payload.benchPowerConfirmed);
  if (payload.confirmations) patch.confirmations = { ...(current.confirmations || {}), ...payload.confirmations };
  for (const key of ['exactXdfAuthorization','autoMapAuthorized','autoRevisionAuthorized','testWriteAuthorized']) if (Object.prototype.hasOwnProperty.call(payload, key)) patch[key] = Boolean(payload[key]);
  if (current.stop?.code === 'read-hash-mismatch') p01Manager.beginFreshReadPair('resume after SHA-256 mismatch');
  if (current.stop?.code === 'needs-checksum' || current.phase === 'stopped-needs-checksum') {
    if (!current.revision?.path || !fs.existsSync(current.revision.path)) throw new Error('The guided revision is missing.');
    const validation = analyzeProjectBin(current.revision.path);
    if (!validation.compatible || !['valid','valid-external'].includes(validation.checksumStatus)) throw new Error(`Checksum validation is still ${validation.checksumStatus}.`);
    patch.phase = 'test-write'; patch.validation = { checksumStatus: validation.checksumStatus, compatible: validation.compatible, file: validation.file };
  }
  const state = p01AutoManager.resume(patch);
  emitP01Auto(state); scheduleP01Auto(); return p01AutoSnapshot(state);
});
ipcMain.handle('p01-auto:recover', async () => {
  clearTimeout(p01AutoTimer);
  p01AutoBusy = false;
  const cleared = flashManager.clearTransientRecoveryState('Manual COM recovery');
  const state = p01AutoManager.recover(`manual recovery; ${cleared.bridge?.aborted || 0} bridge request(s) terminated`);
  emitP01Auto(state); return p01AutoSnapshot(state);
});
ipcMain.handle('p01-auto:assisted-bypass', async () => {
  clearTimeout(p01AutoTimer);
  p01AutoBusy = false;
  flashManager.clearTransientRecoveryState('Integrated PCM Hammer retry');
  const current = p01AutoManager.load();
  const phase = current.resumePhase || current.nextStep || p01AutoManager.waitingResumePhase(current.phase);
  const state = p01AutoManager.resume({ phase });
  emitP01Auto(state); scheduleP01Auto(); return p01AutoSnapshot(state);
});

ipcMain.handle('p01-auto:cancel', async () => {
  clearTimeout(p01AutoTimer);
  p01AutoBusy = false;
  flashManager.clearTransientRecoveryState('Guided P01 Stop Automation');
  if (flashManager.status().session) await flashManager.cancel();
  const state = p01AutoManager.cancel(); emitP01Auto(state); return p01AutoSnapshot(state);
});
ipcMain.handle('p01-auto:choose-xdf', async () => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Exact P01 XDF', extensions: ['xdf'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const state = p01AutoManager.resume({ selectedXdf: result.filePaths[0], phase: 'definition' });
  emitP01Auto(state); scheduleP01Auto(); return p01AutoSnapshot(state);
});
ipcMain.handle('p01-auto:write', async (_event, payload = {}) => {
  const state = p01AutoManager.load();
  if (state.phase !== 'ready-to-write' || !state.revision?.path) throw new Error('Finish Guided Automatic P01 Setup and Test Write before authorizing Calibration Write.');
  const active = requireActive();
  const expected = `WRITE ${active.name}`;
  if (String(payload.confirmation || '').trim() !== expected) throw new Error(`Type exactly “${expected}” to authorize Calibration Write.`);
  const validated = requireValidatedRevision(state.revision.path);
  p01Manager.assertOperationReady('writeCalibration', validated.input);
  const next = p01AutoManager.patch({ status: 'running', phase: 'waiting-write', progress: 100 }, { level: 'warning', text: 'Final Calibration Write was deliberately authorized. Maintain stable power and do not disconnect the interface.' });
  await flashManager.start('writeCalibration', p01AutoFlashPayload({ ...state, ...payload }, { input: validated.input, checksumApproved: true, confirmation: expected }));
  emitP01Auto(next); return p01AutoSnapshot(next);
});
ipcMain.handle('p01:status', async (_event, input) => p01Manager.status(requireActive(), input || null));
ipcMain.handle('p01:reset', async () => p01Manager.reset());
ipcMain.handle('p01:import-identity-proof', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'PCM Hammer Read Properties', extensions: ['txt','log'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  const stat = fs.statSync(source);
  if (stat.size > 2 * 1024 * 1024) throw new Error('Read Properties proof must be smaller than 2 MB.');
  const text = fs.readFileSync(source, 'utf8');
  const identity = parseIdentityText(text);
  const missing = ['controller','os','hardwareId','serviceNumber'].filter(key => !identity[key]);
  if (missing.length) throw new Error(`The selected proof is missing: ${missing.join(', ')}.`);
  if (String(identity.controller).toUpperCase() !== 'P01') throw new Error(`The proof reports ${identity.controller || 'an unknown controller'}, not P01.`);
  const patch = { controller: 'P01', os: identity.os, osSource: 'Imported PCM Hammer Read Properties' };
  updateActiveFiles(patch);
  const status = p01Manager.recordIdentity(identity, { id: `manual-properties-${Date.now()}`, source, proofSource: source, device: 'Imported PCM Hammer Read Properties' });
  const destination = path.join(projectReportsRoot(active), `read-properties-${Date.now()}.txt`);
  fs.copyFileSync(source, destination);
  appendActivity('p01-read-properties-imported', { projectId: active.id, projectName: active.name, os: identity.os, hardwareId: identity.hardwareId, serviceNumber: identity.serviceNumber, source: path.basename(source) });
  return status;
});
ipcMain.handle('p01:import-reads', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile','multiSelections'], filters: [{ name: 'P01 BIN Reads', extensions: ['bin'] }] });
  if (result.canceled || !result.filePaths.length) return null;
  if (result.filePaths.length !== 2) throw new Error('Choose exactly two independent full P01 reads. TunIQ does not use a third-read majority.');
  let latest = null;
  for (let index = 0; index < result.filePaths.length; index += 1) {
    const source = result.filePaths[index];
    const stat = fs.statSync(source);
    if (stat.size !== 512 * 1024) throw new Error(`${path.basename(source)} is ${stat.size} bytes. A P01 full read must be exactly 524,288 bytes.`);
    const stamp = `${Date.now()}-${index + 1}`;
    const destination = path.join(active.folder, 'Originals', `P01-Read-${stamp}-${path.basename(source)}`);
    fs.copyFileSync(source, destination);
    latest = p01Manager.recordRead(destination, binInfoFor(destination), { id: `manual-read-${stamp}`, source, proofSource: source, device: 'Imported PCM Hammer full read' });
  }
  const status = p01Manager.status(active);
  if (status.dualReadVerified && status.canonicalReadSha256) {
    const canonical = (status.reads || []).find(item => item.sha256 === status.canonicalReadSha256)?.path;
    if (canonical && fs.existsSync(canonical)) {
      const updated = updateActiveFiles({ bin: canonical, binInfo: binInfoFor(canonical) });
      applyAutomaticOperatingSystem(updated);
    }
  }
  appendActivity('p01-full-reads-imported', { projectId: active.id, projectName: active.name, count: result.filePaths.length, dualReadVerified: status.dualReadVerified, mismatch: status.readMismatch });
  return p01Manager.status(requireActive());
});
ipcMain.handle('p01:confirm-definition', async (_event, payload = {}) => p01Manager.confirmDefinition(payload));
ipcMain.handle('p01:confirm-goal-map', async (_event, payload = {}) => {
  const active = requireActive();
  const proposal = getGoalRequest(active, payload.proposalId);
  if (!proposal) throw new Error('Build the Full AI action sheet before confirming parameters.');
  return p01Manager.confirmGoalMap(proposal, payload.actionIds || [], payload.proposalIds || []);
});
ipcMain.handle('p01:import-testwrite-proof', async (_event, input) => {
  requireActive();
  if (!input || !fs.existsSync(input)) throw new Error('Select the exact revision used for Test Write first.');
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'PCM Hammer Test Write Result', extensions: ['txt','log'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  if (fs.statSync(source).size > 5 * 1024 * 1024) throw new Error('Test Write proof must be smaller than 5 MB.');
  return p01Manager.recordManualTestWrite(input, fs.readFileSync(source, 'utf8'), source);
});

ipcMain.handle('checksum:analyze', async (_event, targetFile) => analyzeProjectBin(targetFile));
ipcMain.handle('checksum:compare', async (_event, targetFile) => {
  const active = requireActive(); const target = targetFile && fs.existsSync(targetFile) ? targetFile : latestRevisionFile(active);
  if (!target) throw new Error('Export a revision BIN before comparing it with the original.');
  return compareFiles(active.bin, target);
});
ipcMain.handle('checksum:import-universal-report', async (_event, targetFile) => {
  const active = requireActive();
  const target = targetFile && fs.existsSync(targetFile) ? targetFile : latestRevisionFile(active) || active.bin;
  if (!target || !fs.existsSync(target)) throw new Error('Choose the exact BIN that Universal Patcher analyzed.');
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Universal Patcher Report', extensions: ['json','txt','log','xml','html'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const parsed = parseUniversalPatcherReport(result.filePaths[0]);
  const saved = { type: 'universal-patcher-report', projectId: active.id, projectName: active.name, importedAt: new Date().toISOString(), sourceFile: result.filePaths[0], targetFile: target, targetFileName: path.basename(target), targetFileSha256: sha256(target), report: parsed };
  const file = path.join(projectChecksumsRoot(active), `universal-patcher-${Date.now()}.json`); writeJson(file, saved);
  appendActivity('universal-patcher-report-imported', { projectId: active.id, projectName: active.name, target: path.basename(target), targetSha256: saved.targetFileSha256, valid: parsed.valid, errors: parsed.errors, warnings: parsed.warnings, source: parsed.name });
  return { ...saved, file };
});
ipcMain.handle('checksum:correct-explicit', async (_event, targetFile) => {
  const active = requireActive(); const target = targetFile && fs.existsSync(targetFile) ? targetFile : latestRevisionFile(active);
  if (!target) throw new Error('Export a revision before correcting explicit XDF checksums.');
  const definitions = activeChecksumDefinitions(active);
  if (!definitions.length) throw new Error('The active XDF does not contain a checksum definition that TunIQ can correct. Use Universal Patcher and import its report.');
  const corrected = correctDefinitions(fs.readFileSync(target), definitions);
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = path.join(active.folder, 'Revisions', `${path.basename(target, '.bin')}-Checksum-${stamp}.bin`);
  fs.writeFileSync(output, corrected.buffer);
  const analysis = analyzeProjectBin(output);
  appendActivity('checksums-corrected', { projectId: active.id, projectName: active.name, output: path.basename(output), count: corrected.results.length });
  return { output, name: path.basename(output), corrections: corrected.results, analysis };
});

ipcMain.handle('patch:preview-bin', async () => {
  const active = requireActive();
  if (!active.bin || !fs.existsSync(active.bin)) throw new Error('Import or read the protected original BIN first.');
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Patched BIN', extensions: ['bin'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const sourceFile = result.filePaths[0];
  const stat = fs.statSync(sourceFile);
  if (!stat.isFile() || stat.size <= 0 || stat.size > 64 * 1024 * 1024) throw new Error('The selected patched BIN is empty or outside the supported 64 MB safety limit.');
  const comparison = compareFiles(active.bin, sourceFile);
  const analysis = analyzeBin(sourceFile, { referenceFile: active.bin, checksumDefinitions: activeChecksumDefinitions(active) });
  const preview = { sourceFile, sourceFileName: path.basename(sourceFile), sourceFileSha256: analysis.sha256, comparison, analysis, compatible: comparison.compatibleLayout, previewedAt: new Date().toISOString() };
  const file = path.join(projectReportsRoot(active), `patch-preview-${Date.now()}.json`); writeJson(file, { type: 'patch-preview', projectId: active.id, projectName: active.name, ...preview });
  appendActivity('patched-bin-previewed', { projectId: active.id, projectName: active.name, source: preview.sourceFileName, compatible: preview.compatible, changedBytes: comparison.changedBytes });
  return { ...preview, reportFile: file };
});

ipcMain.handle('patch:import-bin', async (_event, payload) => {
  const active = requireActive();
  const sourceFile = String(payload?.sourceFile || '');
  const expectedSha256 = String(payload?.sourceFileSha256 || '');
  if (!sourceFile || !fs.existsSync(sourceFile)) throw new Error('Preview a patched BIN before importing it.');
  if (path.extname(sourceFile).toLowerCase() !== '.bin') throw new Error('Only .bin patched files can be imported.');
  if (expectedSha256 && sha256(sourceFile) !== expectedSha256) throw new Error('The patched BIN changed after preview. Preview it again before importing.');
  const comparison = compareFiles(active.bin, sourceFile);
  if (!comparison.compatibleLayout) throw new Error('Patched BIN size/layout does not match the protected original. It was not imported.');
  if (!comparison.changedBytes) throw new Error('The patched BIN is identical to the protected original.');
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = path.join(active.folder, 'Revisions', `${path.basename(active.bin, '.bin')}-Imported-Patch-${stamp}.bin`);
  fs.copyFileSync(sourceFile, output);
  const validation = analyzeProjectBin(output);
  appendActivity('patched-bin-imported', { projectId: active.id, projectName: active.name, output: path.basename(output), source: path.basename(sourceFile), changedBytes: comparison.changedBytes, checksumStatus: validation.checksumStatus });
  return { output, name: path.basename(output), comparison, validation };
});

ipcMain.handle('ai-goal:parse', async (_event, text) => parseTuneRequest(text));
ipcMain.handle('ai-goal:list', async () => listGoalRequests(requireActive()));
ipcMain.handle('ai-goal:build', async (_event, payload = {}) => {
  const active = requireActive(); p01Manager.assertAiReady(); const workspace = loadCalibration();
  const p01Status = p01Manager.status(active);
  const proposal = buildGoalProposal({
    request: payload.request || '', workspace, activeProject: active, confirmations: payload.confirmations || {}, parameterMap: p01Status.parameterMap || null,
    ruleFolders: [path.join(dataRoot(), 'Compatibility', 'Rules'), path.join(app.getAppPath(), 'src', 'rules')]
  });
  const saved = saveGoalRequest(active, proposal);
  appendActivity('ai-goal-request-built', { projectId: active.id, projectName: active.name, proposalId: proposal.id, actions: proposal.summary.actions, readyActions: proposal.summary.readyActions, blockedActions: proposal.summary.blockedActions, proposedCells: proposal.summary.proposedCells });
  return saved;
});
ipcMain.handle('ai-goal:apply', async (_event, payload = {}) => {
  const active = requireActive(); p01Manager.assertAiReady(); const proposal = getGoalRequest(active, payload.proposalId); if (!proposal) throw new Error('Tune-request action sheet not found.');
  p01Manager.assertGoalProposalMapped(proposal, payload.approvedIds || []);
  const workspace = loadCalibration(); const result = applyGoalApproved(workspace, proposal, payload.approvedIds || []);
  validateCalibrationWorkspace(result.workspace); saveCalibrationWorkspace(result.workspace);
  const revision = exportCalibrationWorkspace(result.workspace, { suffix: 'AI-Requested-Goals', autoCorrectChecksums: true });
  const execution = { id: `${Date.now()}-goal-execution`, projectId: active.id, projectName: active.name, proposalId: proposal.id, requestText: proposal.requestText, approvedIds: payload.approvedIds || [], applied: result.applied, revision, status: 'revision-created-awaiting-validation-and-flash', createdAt: new Date().toISOString() };
  const executionFile = path.join(projectGoalRequestsRoot(active), `${execution.id}.json`); writeJson(executionFile, execution);
  appendActivity('ai-goal-request-applied', { projectId: active.id, projectName: active.name, proposalId: proposal.id, appliedCells: result.applied.length, revision: revision.name });
  return { applied: result.applied, workspace: result.workspace, revision, execution: { ...execution, file: executionFile } };
});

ipcMain.handle('ai-proposal:list', async () => listProposals(requireActive()));
ipcMain.handle('ai-proposal:generate', async (_event, csvPath) => {
  const active = requireActive(); p01Manager.assertAiReady(); const workspace = loadCalibration();
  const analysis = obdManager.analyzeLog(csvPath);
  const cycles = listAiCycles(active);
  const proposal = generateProposal({ csvPath, workspace, activeProject: active, analysis });
  proposal.iteration = cycles.length + 1;
  proposal.previousCycle = cycles[0]?.id || null;
  proposal.previousRevision = cycles[0]?.revision?.name || null;
  const saved = saveProposal(active, proposal);
  appendActivity('ai-calibration-proposal-generated', { projectId: active.id, projectName: active.name, proposalId: proposal.id, sourceLog: proposal.sourceLogName, proposedCells: proposal.summary.proposedCells, blocked: proposal.blocked });
  return saved;
});
ipcMain.handle('ai-proposal:apply', async (_event, payload) => {
  const active = requireActive(); p01Manager.assertAiReady(); const proposal = getProposal(active, payload?.proposalId); if (!proposal) throw new Error('AI proposal not found.');
  const workspace = loadCalibration(); const result = applyApproved(workspace, proposal, payload?.approvedIds || []);
  validateCalibrationWorkspace(result.workspace); saveCalibrationWorkspace(result.workspace);
  const revision = exportCalibrationWorkspace(result.workspace, { suffix: `AI-Cycle-${proposal.iteration || 1}`, autoCorrectChecksums: true });
  const cycle = { id: `${Date.now()}-cycle`, iteration: proposal.iteration || (listAiCycles(active).length + 1), projectId: active.id, projectName: active.name, proposalId: proposal.id, sourceLog: proposal.sourceLog, sourceLogName: proposal.sourceLogName, approvedIds: payload?.approvedIds || [], applied: result.applied, revision, status: 'awaiting-follow-up-log', createdAt: new Date().toISOString() };
  const cycleFile = path.join(projectAiCyclesRoot(active), `${cycle.id}.json`); writeJson(cycleFile, cycle);
  appendActivity('ai-calibration-proposal-applied', { projectId: active.id, projectName: active.name, proposalId: proposal.id, iteration: cycle.iteration, appliedCells: result.applied.length, revision: revision.name });
  return { applied: result.applied, workspace: result.workspace, revision, cycle: { ...cycle, file: cycleFile } };
});

ipcMain.handle('system:open-data-folder', async () => shell.openPath(dataRoot()));

ipcMain.handle('vehicle:list', async () => garageManager.listWithUsage());
ipcMain.handle('vehicle:save', async (_event, payload) => garageManager.save(payload || {}));
ipcMain.handle('vehicle:favorite', async (_event, id) => garageManager.favorite(id));
ipcMain.handle('vehicle:duplicate', async (_event, id) => garageManager.duplicate(id));
ipcMain.handle('vehicle:delete', async (_event, id) => garageManager.delete(id));
ipcMain.handle('vehicle:choose-photo', async (_event, id) => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Vehicle Photos', extensions: ['jpg', 'jpeg', 'png', 'webp'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  return garageManager.importPhoto(id, result.filePaths[0]);
});
ipcMain.handle('vehicle:remove-photo', async (_event, id) => garageManager.removePhoto(id));
ipcMain.handle('project:set-active', async (_event, id) => {
  if (obdManager.getStatus().logging) throw new Error('Stop the active live log before switching projects.');
  const base = projectsRoot();
  const projects = fs.existsSync(base)
    ? fs.readdirSync(base, { withFileTypes: true })
      .filter(entry => entry.isDirectory())
      .map(entry => ({ manifest: readJson(projectManifestFile(path.join(base, entry.name)), null), folder: path.join(base, entry.name) }))
      .filter(entry => entry.manifest)
    : [];
  const found = projects.find(entry => entry.manifest.id === id);
  if (!found) throw new Error('Project not found.');
  const active = hydrateProjectRecord(found.manifest, found.folder, new Date().toISOString());
  if (!active) throw new Error('The project folder is missing or damaged.');
  persistProjectState(active);
  appendActivity('project-activated', { id: active.id, name: active.name });
  return active;
});
ipcMain.handle('activity:list', async () => {
  const activity = readJson(activityFile(), []);
  return Array.isArray(activity) ? activity : [];
});

ipcMain.handle('project:create', async (_event, payload) => {
  if (obdManager.getStatus().logging) throw new Error('Stop the active live log before creating and activating another project.');
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const id = `${Date.now()}-${safeName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`;
  const folder = path.join(projectsRoot(), id);
  for (const subfolder of ['Originals', 'Definitions', 'Revisions', 'Logs', 'Backups', 'AI', 'Reports', 'Checksums']) {
    fs.mkdirSync(path.join(folder, subfolder), { recursive: true });
  }
  const vehicleFields = projectVehicleFields(payload || {}, garageManager.list());
  const selectedVehicle = vehicleFields.vehicleId ? garageManager.list().find(item => item.id === vehicleFields.vehicleId) : null;
  const manifest = {
    id,
    name: safeName,
    ...vehicleFields,
    controller: String(payload.controller || selectedVehicle?.controller || '').trim(),
    os: String(payload.os || selectedVehicle?.os || '').trim(),
    osSource: String(payload.os || '').trim() ? 'manual' : (selectedVehicle?.os ? 'Garage vehicle profile' : ''),
    notes: payload.notes || '',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    revisions: [],
    bin: null,
    binInfo: null,
    xdf: null,
    xdfInfo: null
  };
  writeJson(projectManifestFile(folder), manifest);
  const active = hydrateProjectRecord(manifest, folder, new Date().toISOString());
  persistProjectState(active);
  appendActivity('project-created', { id, name: safeName, vehicle: manifest.vehicle, controller: manifest.controller });
  return { ...manifest, active };
});
ipcMain.handle('project:update', async (_event, payload) => {
  const id = String(payload?.id || '').trim();
  if (!id) throw new Error('Choose a project to edit first.');
  const base = projectsRoot();
  const entry = fs.existsSync(base)
    ? fs.readdirSync(base, { withFileTypes: true })
      .filter(item => item.isDirectory())
      .map(item => ({ folder: path.join(base, item.name), manifest: readJson(projectManifestFile(path.join(base, item.name)), null) }))
      .find(item => item.manifest?.id === id)
    : null;
  if (!entry) throw new Error('The project could not be found. It may have been moved or removed.');
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const vehicleFields = projectVehicleFields(payload || {}, garageManager.list());
  const selectedVehicle = vehicleFields.vehicleId ? garageManager.list().find(item => item.id === vehicleFields.vehicleId) : null;
  const manifest = {
    ...entry.manifest,
    name: safeName,
    ...vehicleFields,
    controller: String(payload.controller || selectedVehicle?.controller || '').trim(),
    os: String(payload.os || selectedVehicle?.os || '').trim(),
    osSource: String(payload.os || '').trim() ? 'manual' : (selectedVehicle?.os ? 'Garage vehicle profile' : ''),
    notes: String(payload.notes || '').trim(),
    updatedAt: new Date().toISOString()
  };
  writeJson(projectManifestFile(entry.folder), manifest);
  const current = getActiveProject();
  let active = null;
  if (current?.id === id) {
    active = hydrateProjectRecord(manifest, entry.folder, current.selectedAt);
    persistProjectState(active);
  }
  appendActivity('project-updated', { id, name: manifest.name, vehicle: manifest.vehicle, controller: manifest.controller, os: manifest.os });
  return { ...manifest, active };
});
ipcMain.handle('project:list', async () => {
  const base = projectsRoot();
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base, { withFileTypes: true })
    .filter(entry => entry.isDirectory())
    .map(entry => {
      const folder = path.join(base, entry.name);
      const file = projectManifestFile(folder);
      const manifest = readJson(file, null);
      if (!manifest) return null;
      const vehicleFields = projectVehicleFields(manifest, garageManager.list());
      const migrated = { ...manifest, ...vehicleFields };
      if (JSON.stringify(manifest) !== JSON.stringify(migrated)) writeJson(file, migrated);
      return migrated;
    })
    .filter(Boolean)
    .sort((a, b) => String(b.updatedAt || b.createdAt || '').localeCompare(String(a.updatedAt || a.createdAt || '')));
});
ipcMain.handle('hardware-session:status', async () => hardwareSessionDoctor?.saveLatest?.() || null);
ipcMain.handle('hardware-session:refresh', async () => hardwareSessionDoctor?.saveLatest?.() || null);
ipcMain.handle('hardware-session:export', async () => {
  const active = requireActive();
  const safeProject = String(active.name || 'Project').replace(/[<>:"/\|?*]+/g, '-');
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: path.join(app.getPath('documents'), `TunIQ-${safeProject}-Hardware-Session-${Date.now()}.json`),
    filters: [{ name: 'TunIQ Hardware Session Report', extensions: ['json','txt'] }]
  });
  if (result.canceled || !result.filePath) return null;
  const report = hardwareSessionDoctor.build();
  hardwareSessionDoctor.export(result.filePath, report);
  return { file: result.filePath, report };
});
ipcMain.handle('hardware-session:open-log', async () => {
  const report = hardwareSessionDoctor.build();
  const file = hardwareSessionDoctor.latestLog(report);
  if (!file || !fs.existsSync(file)) throw new Error('No PCM Hammer session log is available yet. Run or retry the hardware step first.');
  shell.showItemInFolder(file);
  return file;
});
ipcMain.handle('hardware-session:open-reports', async () => {
  const active = requireActive();
  const folder = path.join(active.folder, 'Reports');
  fs.mkdirSync(folder, { recursive: true });
  const error = await shell.openPath(folder);
  if (error) throw new Error(error);
  return folder;
});
ipcMain.handle('hardware-session:open-snapshot', async () => {
  const report = hardwareSessionDoctor.build();
  const folder = report?.safetySnapshot?.path || projectSafetyVault.latest()?.path || '';
  if (!folder || !fs.existsSync(folder)) throw new Error('No verified project safety snapshot is available yet. Start or retry Test Write to create one.');
  const error = await shell.openPath(folder);
  if (error) throw new Error(error);
  return folder;
});

ipcMain.handle('diagnostics:export', async (_event, payload = {}) => {
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath: path.join(app.getPath('documents'), `TunIQ-Diagnostic-${Date.now()}.tuniqreport`), filters: [{ name: 'TunIQ Diagnostic Report', extensions: ['tuniqreport'] }] });
  if (result.canceled || !result.filePath) return null;
  betaManager.exportDiagnostic(result.filePath, payload || {});
  appendActivity('diagnostic-report-exported', { file: path.basename(result.filePath) });
  return result.filePath;
});

ipcMain.handle('beta:get-state', async () => betaManager.state());
ipcMain.handle('beta:accept-agreement', async (_event, accepted) => betaManager.acceptAgreement(Boolean(accepted)));
ipcMain.handle('beta:save-preferences', async (_event, payload) => { const state = betaManager.savePreferences(payload || {}); updateManager.configure(); return state; });
ipcMain.handle('beta:save-outcome', async (_event, payload) => betaManager.saveOutcome(payload || {}));
ipcMain.handle('beta:export-queue', async () => {
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath: path.join(app.getPath('documents'), `TunIQ-Improvement-${Date.now()}.tuniqfeedback`), filters: [{ name: 'TunIQ Improvement Package', extensions: ['tuniqfeedback'] }] });
  if (result.canceled || !result.filePath) return null;
  betaManager.exportQueue(result.filePath); return result.filePath;
});
ipcMain.handle('beta:submit-queue', async () => betaManager.submitQueue());
ipcMain.handle('beta:clear-queue', async () => betaManager.clearQueue());
ipcMain.handle('beta:clear-outcomes', async () => betaManager.clearOutcomes());
ipcMain.handle('beta:open-document', async (_event, name) => {
  const allowed = { privacy: 'PRIVACY.md', agreement: 'BETA_AGREEMENT.md', checklist: 'PUBLIC_RELEASE_CHECKLIST.md', license: 'LICENSE_SELECTION_REQUIRED.md' };
  const file = allowed[name]; if (!file) throw new Error('Unknown TunIQ document.');
  const target = path.join(app.getAppPath(), file); if (!fs.existsSync(target)) throw new Error(`${file} is missing from this build.`);
  const error = await shell.openPath(target); if (error) throw new Error(error); return target;
});

ipcMain.handle('update:status', async () => updateManager.configure());
ipcMain.handle('update:check', async () => updateManager.check());
ipcMain.handle('update:download', async () => updateManager.download());
ipcMain.handle('update:install', async () => updateManager.install());

ipcMain.handle('system:open-external', async (_event, url) => {
  const allowed = ['https://github.com/PcmHammer/PcmHammer/releases','https://github.com/LegacyNsfw/PcmHacks/releases','https://www.tunerpro.net/downloadApp.htm','https://universalpatcher.net/download/'];
  if (!allowed.includes(url)) throw new Error('Blocked unapproved external URL.');
  await shell.openExternal(url);
  return true;
});


function defaultCalibrationWorkspace(active = null) {
  const makeGrid = (rows, cols, fn) => Array.from({ length: rows }, (_, r) => Array.from({ length: cols }, (_, c) => Number(fn(r, c).toFixed(2))));
  return {
    schemaVersion: 2,
    projectId: active?.id || '',
    activeTable: 'spark',
    tables: {
      spark: { name: 'High-Octane Spark', unit: '°', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['0.20','0.32','0.44','0.56','0.68','0.80','0.92','1.04'], min: -10, max: 50, values: makeGrid(8,8,(r,c)=>12+r*1.75-c*.65) },
      ve: { name: 'VE Main', unit: '%', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['20','30','40','50','60','70','80','90'], min: 20, max: 125, values: makeGrid(8,8,(r,c)=>42+r*3.1+c*4.2) },
      idle: { name: 'Idle Airflow', unit: 'g/s', rowHeaders: ['-20','0','20','40','60','80','100','120'], colHeaders: ['P/N','Drive'], min: 0, max: 30, values: makeGrid(8,2,(r,c)=>15-r*1.25+c*1.2) },
      fans: { name: 'Fan Temperatures', unit: '°F', rowHeaders: ['Fan 1 On','Fan 1 Off','Fan 2 On','Fan 2 Off'], colHeaders: ['Value'], min: 100, max: 240, values: [[205],[198],[215],[208]] },
      fuel: { name: 'Power Enrichment EQ', unit: 'EQ', rowHeaders: ['2000','2400','2800','3200','3600','4000'], colHeaders: ['40','50','60','70','80','90','100'], min: 0.7, max: 1.6, values: makeGrid(6,7,(r,c)=>1.0+Math.max(0,c-2)*.035+r*.006) },
      transmission: { name: 'WOT Shift RPM', unit: 'RPM', rowHeaders: ['1-2','2-3','3-4'], colHeaders: ['Normal','Performance'], min: 1000, max: 7500, values: [[5400,5600],[5350,5550],[5250,5450]] },
      limits: { name: 'Engine & Speed Limits', unit: '', rowHeaders: ['Rev limiter fuel cut','Rev limiter resume','Speed limiter'], colHeaders: ['Value'], min: 0, max: 8000, values: [[5800],[5700],[130]] }
    },
    stock: null,
    modified: {},
    updatedAt: new Date().toISOString()
  };
}
function validateCalibrationWorkspace(payload) {
  if (!payload || typeof payload !== 'object' || !payload.tables || typeof payload.tables !== 'object') throw new Error('Invalid calibration workspace.');
  const entries = Object.entries(payload.tables);
  if (!entries.length || entries.length > 800) throw new Error('Calibration workspace table count is outside the supported range.');
  let cells = 0;
  for (const [key, table] of entries) {
    if (!table || !Array.isArray(table.values) || !table.values.length) throw new Error(`Calibration item ${key} has no value grid.`);
    if (table.values.length > 256) throw new Error(`Calibration item ${key} exceeds the supported 256-row display limit.`);
    const columns = Array.isArray(table.values[0]) ? table.values[0].length : 0;
    if (!columns || columns > 256) throw new Error(`Calibration item ${key} has an unsupported column count.`);
    for (const row of table.values) {
      if (!Array.isArray(row) || row.length !== columns) throw new Error(`Calibration item ${key} contains a non-rectangular value grid.`);
      cells += row.length;
      if (cells > 200000) throw new Error('Calibration workspace is too large to save safely.');
      for (const value of row) if (!Number.isFinite(Number(value))) throw new Error(`Calibration item ${key} contains a non-numeric value.`);
    }
    if (Array.isArray(table.rowHeaders) && table.rowHeaders.length !== table.values.length) throw new Error(`Calibration item ${key} row labels do not match its value grid.`);
    if (Array.isArray(table.colHeaders) && table.colHeaders.length !== columns) throw new Error(`Calibration item ${key} column labels do not match its value grid.`);
  }
  const serialized = JSON.stringify(payload);
  if (Buffer.byteLength(serialized, 'utf8') > 24 * 1024 * 1024) throw new Error('Calibration workspace is too large to save safely.');
  return serialized;
}
function loadCalibration() {
  const active = requireActive();
  const workspace = tuneWorkspaceManager.load(active, project => {
    const fresh = defaultCalibrationWorkspace(project);
    fresh.stock = JSON.parse(JSON.stringify(fresh.tables));
    return fresh;
  }, validateCalibrationWorkspace);
  return workspace;
}
function saveCalibrationWorkspace(payload) {
  const active = requireActive();
  return tuneWorkspaceManager.save(active, payload, validateCalibrationWorkspace);
}

ipcMain.handle('calibration:load', async () => loadCalibration());
ipcMain.handle('calibration:save', async (_event, payload) => saveCalibrationWorkspace(payload));
ipcMain.handle('calibration:revision', async (_event, payload) => {
  const active = requireActive();
  const workspace = loadCalibration();
  return tuneWorkspaceManager.createSnapshot(active, workspace, payload || {}, validateCalibrationWorkspace);
});
ipcMain.handle('calibration:history', async () => tuneWorkspaceManager.history(requireActive()));
ipcMain.handle('calibration:compare-snapshot', async (_event, id) => tuneWorkspaceManager.compare(requireActive(), loadCalibration(), id));
ipcMain.handle('calibration:restore-snapshot', async (_event, id) => tuneWorkspaceManager.restore(requireActive(), id, validateCalibrationWorkspace));
ipcMain.handle('calibration:reset', async () => {
  const active = requireActive();
  const workspace = defaultCalibrationWorkspace(active);
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  return tuneWorkspaceManager.save(active, workspace, validateCalibrationWorkspace);
});

function sha256(file) {
  return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
}

ipcMain.handle('project:import-bin', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'Calibration BIN', extensions: ['bin'] }, { name: 'All files', extensions: ['*'] }]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  const destination = copyProjectFile(source, path.join(active.folder, 'Originals'));
  const info = binInfoFor(destination);
  if (active.binInfo?.sha256 && active.binInfo.sha256 !== info.sha256) tuneWorkspaceManager.invalidate(active, 'The protected original BIN fingerprint changed.');
  const updated = updateActiveFiles({ bin: destination, binInfo: info });
  const { active: detectedActive, detection } = applyAutomaticOperatingSystem(updated);
  appendActivity('bin-imported', { ...info, projectId: active.id, detectedOs: detection.detected ? detection.os : null });
  return { ...info, detectedOs: detection.detected ? detection.os : null, osSource: detection.source || null, active: detectedActive };
});

ipcMain.handle('project:import-xdf', async () => {
  const active = requireActive();
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'TunerPro Definition', extensions: ['xdf'] }, { name: 'All files', extensions: ['*'] }]
  });
  if (result.canceled || !result.filePaths[0]) return null;
  const source = result.filePaths[0];
  const destination = copyProjectFile(source, path.join(active.folder, 'Definitions'));
  const parsed = parseXdf(destination);
  if (!parsed.tables.length) throw new Error('The selected XDF does not contain readable tables or constants.');
  const commissioningOnly = isCommissioningOnlyXdf(destination);
  const info = { path: destination, name: path.basename(destination), tableCount: parsed.tables.length, title: parsed.title, warnings: parsed.warnings || [], sha256: sha256(destination), commissioningOnly, writableTables: commissioningOnly ? 0 : parsed.tables.length };
  if (active.xdf && fs.existsSync(active.xdf) && sha256(active.xdf) !== info.sha256) tuneWorkspaceManager.invalidate(active, 'The XDF definition fingerprint changed.');
  const updated = updateActiveFiles({ xdf: destination, xdfInfo: info });
  const { active: detectedActive, detection } = applyAutomaticOperatingSystem(updated);
  appendActivity('xdf-imported', { name: info.name, tables: info.tableCount, projectId: active.id, detectedOs: detection.detected ? detection.os : null });
  return { ...info, detectedOs: detection.detected ? detection.os : null, osSource: detection.source || null, active: detectedActive };
});

ipcMain.handle('project:detect-os', async () => {
  const active = requireActive();
  const detection = detectProjectOperatingSystem(active);
  if (!detection.detected) return { ...detection, active };
  const updated = { ...active, os: detection.os, osSource: detection.source };
  persistProjectState(updated);
  appendActivity('os-detected', { projectId: updated.id, projectName: updated.name, os: detection.os, source: detection.source, requested: true });
  return { ...detection, active: updated };
});

ipcMain.handle('project:files', async () => {
  const active = getActiveProject();
  if (!active) return { active: null, bin: null, xdf: null };
  return { active, bin: active.binInfo || null, xdf: active.xdfInfo || null };
});

function loadActiveXdfWorkspace() {
  let active = requireActive();
  if (!active.bin || !fs.existsSync(active.bin) || !active.xdf || !fs.existsSync(active.xdf)) {
    throw new Error('Import both an original BIN and its matching XDF first.');
  }
  // Always fingerprint the bytes on disk. A stale binInfo cache from an older beta must
  // never make an automatically generated commissioning definition look unbound.
  const actualBinInfo = binInfoFor(active.bin);
  const actualXdfSha256 = sha256(active.xdf);
  if (!active.binInfo || active.binInfo.sha256 !== actualBinInfo.sha256 || active.binInfo.size !== actualBinInfo.size
      || !active.xdfInfo || active.xdfInfo.sha256 !== actualXdfSha256) {
    active = updateActiveFiles({
      binInfo: actualBinInfo,
      xdfInfo: { ...(active.xdfInfo || {}), path: active.xdf, name: path.basename(active.xdf), sha256: actualXdfSha256 }
    });
    appendActivity('project-file-fingerprints-refreshed', { projectId: active.id, binSha256: actualBinInfo.sha256, xdfSha256: actualXdfSha256 });
  }
  const parsed = parseXdf(active.xdf);
  const commissioningOnly = isCommissioningOnlyXdf(active.xdf);
  const bin = fs.readFileSync(active.bin);
  const xdfOs = osCandidatesFromText(`${parsed.title || ''} ${path.basename(active.xdf)}`)[0] || '';
  if (active.os && xdfOs && String(active.os) !== String(xdfOs)) throw new Error(`XDF operating system ${xdfOs} does not match active project OS ${active.os}.`);
  if (!active.os && xdfOs) updateActiveFiles({ os: xdfOs, osSource: 'XDF mapping validation' });
  const tables = {};
  let totalCells = 0;
  let skipped = 0;
  const addressWarnings = [];
  for (const definition of parsed.tables) {
    if (definition.unsupportedReason && !commissioningOnly) { skipped += 1; continue; }
    const cells = Math.max(1, Number(definition.rows) || 1) * Math.max(1, Number(definition.cols) || 1);
    if (Object.keys(tables).length >= 800 || totalCells + cells > 200000) {
      skipped += 1;
      continue;
    }
    const bytes = Math.max(1, Number(definition.elementBits || 8) / 8);
    const finalAddress = Number(definition.address || 0) + Math.max(0, Number(definition.rows || 1) - 1) * Number(definition.rowStride || bytes) + Math.max(0, Number(definition.cols || 1) - 1) * Number(definition.colStride || bytes) + bytes;
    if (!Number.isFinite(finalAddress) || Number(definition.address) < 0 || finalAddress > bin.length) {
      skipped += 1; addressWarnings.push(`${definition.name}: address range exceeds the ${bin.length}-byte BIN`); continue;
    }
    let key = String(definition.id).replace(/[^a-zA-Z0-9_-]/g, '_') || `item_${Object.keys(tables).length}`;
    while (tables[key]) key = `${key}_${Object.keys(tables).length}`;
    tables[key] = hydrate(commissioningOnly ? { ...definition, unsupportedReason: 'Commissioning-only definition is read-only and cannot modify calibration data.' } : definition, bin);
    totalCells += cells;
  }
  if (!Object.keys(tables).length) throw new Error('The XDF did not contain any safely loadable tables or constants.');
  const workspace = {
    mode: 'xdf',
    projectId: active.id,
    binding: tuneWorkspaceManager.binding(active),
    sourceBin: active.bin,
    sourceBinSha256: sha256(active.bin),
    sourceXdf: active.xdf,
    sourceXdfSha256: sha256(active.xdf),
    title: parsed.title,
    activeTable: Object.keys(tables)[0],
    tables,
    stock: JSON.parse(JSON.stringify(tables)),
    modified: {},
    mappingSummary: { loaded: Object.keys(tables).length, writableTables: commissioningOnly ? 0 : Object.keys(tables).length, commissioningOnly, skipped, totalCells, warnings: [...(parsed.warnings || []), ...addressWarnings], categories: parsed.categories || [], checksumDefinitions: commissioningOnly ? [] : (parsed.checksums || []), checksumCount: commissioningOnly ? 0 : (parsed.checksums || []).length, parserVersion: 'enhanced-xdf-v2' },
    updatedAt: new Date().toISOString()
  };
  validateCalibrationWorkspace(workspace);
  const savedWorkspace = tuneWorkspaceManager.save(active, workspace, validateCalibrationWorkspace);
  appendActivity('xdf-mapping-loaded', { ...workspace.mappingSummary, projectId: active.id, sourceBinSha256: savedWorkspace.sourceBinSha256, sourceXdfSha256: savedWorkspace.sourceXdfSha256 });
  return savedWorkspace;

}
ipcMain.handle('calibration:load-xdf', async () => loadActiveXdfWorkspace());

function exportCalibrationWorkspace(payload, options = {}) {
  const active = requireActive();
  const workspace = payload?.tables ? payload : loadCalibration();
  validateCalibrationWorkspace(workspace);
  if (!active.bin || !fs.existsSync(active.bin)) throw new Error('No original BIN is attached to the active project.');
  tuneWorkspaceManager.assertBinding(workspace, active, { requireXdf: true });
  if (workspace.projectId !== active.id || path.resolve(workspace.sourceBin || '') !== path.resolve(active.bin) || path.resolve(workspace.sourceXdf || '') !== path.resolve(active.xdf || '')) {
    throw new Error('This calibration workspace does not match the active project BIN/XDF pair. Reload the mapping before exporting.');
  }
  const originalHash = sha256(active.bin);
  if (workspace.sourceBinSha256 && workspace.sourceBinSha256 !== originalHash) throw new Error('The protected original BIN changed after the workspace was loaded. Reload the BIN and XDF before exporting.');
  if (workspace.sourceXdfSha256 && workspace.sourceXdfSha256 !== sha256(active.xdf)) throw new Error('The XDF changed after the workspace was loaded. Reload the BIN and XDF before exporting.');
  let buffer = Buffer.from(fs.readFileSync(active.bin));
  const modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
  for (const [tableKey, table] of Object.entries(workspace.tables)) {
    if (table.address == null) continue;
    const changedCells = new Set(Object.keys(modified).filter(key => key.startsWith(`${tableKey}:`)).map(key => key.slice(tableKey.length + 1)));
    if (changedCells.size) applyTable(buffer, table, changedCells);
  }
  const definitions = activeChecksumDefinitions(active);
  let checksumCorrections = [];
  if (options.autoCorrectChecksums && definitions.length) {
    const corrected = correctDefinitions(buffer, definitions); buffer = corrected.buffer; checksumCorrections = corrected.results;
  }
  fs.mkdirSync(path.join(active.folder, 'Revisions'), { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const suffix = String(options.suffix || 'TunIQ').replace(/[^a-zA-Z0-9_-]+/g, '-');
  const output = path.join(active.folder, 'Revisions', `${path.basename(active.bin, '.bin')}-${suffix}-${stamp}.bin`);
  fs.writeFileSync(output, buffer);
  const analysis = analyzeBin(output, { referenceFile: active.bin, checksumDefinitions: definitions });
  const external = latestExternalChecksumReport(active, analysis.sha256);
  const checksumStatus = analysis.nativeChecksumStatus === 'valid' ? 'valid' : external?.report?.valid ? 'valid-external' : analysis.nativeChecksumStatus;
  const validation = {
    type: 'revision-validation', version: APP_VERSION, projectId: active.id, projectName: active.name,
    targetFile: output, targetFileName: path.basename(output), targetFileSha256: analysis.sha256,
    originalFile: active.bin, originalSha256: originalHash, compatible: Boolean(analysis.comparison?.compatibleLayout), checksumStatus,
    analysis, checksumCorrections, externalReport: external || null, validatedAt: new Date().toISOString()
  };
  const reportFile = path.join(projectReportsRoot(active), `validation-${Date.now()}.json`); writeJson(reportFile, validation);
  const info = { path: output, name: path.basename(output), size: buffer.length, sha256: sha256(output), originalSha256: originalHash, modifiedCells: Object.keys(modified).length, checksumStatus, compatible: validation.compatible, checksumCorrections, changedBytes: analysis.comparison?.changedBytes || 0, reportFile, at: new Date().toISOString() };
  appendActivity('bin-exported', { ...info, projectId: active.id });
  return info;
}

ipcMain.handle('calibration:export-bin', async (_event, payload) => exportCalibrationWorkspace(payload, { autoCorrectChecksums: true }));

ipcMain.handle('project:open-folder', async () => {
  const active = requireActive();
  const error = await shell.openPath(active.folder);
  if (error) throw new Error(error);
  return active.folder;
});

