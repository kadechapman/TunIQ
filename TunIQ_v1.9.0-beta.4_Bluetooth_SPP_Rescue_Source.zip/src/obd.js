const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const { ConnectionDoctor } = require('./connection-doctor');
const { bridgeError, rankAlternatePorts } = require('./com-recovery');

const SENSOR_PROFILES = {
  baseline: { name: 'Full Baseline', description: 'General drivability, temperatures, voltage, load, and fuel trims.', sensors: ['rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load'] },
  fuelTrims: { name: 'Fuel Trim Review', description: 'Idle and cruise correction patterns before MAF or VE changes.', sensors: ['rpm','speed','ect','tps','map','maf','stft1','ltft1','voltage','load'] },
  camIdle: { name: 'Cam Idle Diagnosis', description: 'Idle stability, airflow/load, trims, spark, and temperature.', sensors: ['rpm','speed','ect','tps','map','maf','stft1','ltft1','spark','voltage','load'] },
  mafVe: { name: 'MAF / VE Review', description: 'Airflow and fuel correction across RPM and load.', sensors: ['rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','load'] },
  power: { name: 'Power & Knock Review', description: 'High-load data foundation. Wideband AFR and enhanced knock PIDs are required for final decisions.', sensors: ['rpm','speed','ect','iat','tps','map','maf','spark','voltage','load'] },
  transmission: { name: 'Transmission Driveability', description: 'Standard OBD data plus future enhanced transmission PIDs.', sensors: ['rpm','speed','ect','tps','map','spark','voltage','load'] }
};

function cleanText(value, max = 200) { return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function safeFileName(value) { return cleanText(value, 100).replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'Live-Log'; }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function csvValue(value) { const text = value == null ? '' : String(value); return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text; }
function mean(values) { const valid = values.filter(Number.isFinite); return valid.length ? valid.reduce((a,b)=>a+b,0) / valid.length : null; }
function stddev(values) { const valid = values.filter(Number.isFinite); if (valid.length < 2) return 0; const avg = mean(valid); return Math.sqrt(valid.reduce((sum,v)=>sum + Math.pow(v-avg,2),0) / valid.length); }
function round(value, digits = 2) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }

function parseVoltage(raw) {
  if (Number.isFinite(Number(raw)) && String(raw).trim() !== '') return Number(raw);
  const match = String(raw || '').match(/(-?\d+(?:\.\d+)?)\s*V/i);
  return match ? Number(match[1]) : null;
}
function normalizeAdapterText(raw) {
  return String(raw || '').replace(/[>\r\n]+/g, ' ').replace(/\s+/g, ' ').replace(/^(ATI|AT@1|STDI)\s*/i, '').trim();
}
function extractPidBytes(raw, pid) {
  const target = String(pid).toUpperCase();
  const text = String(raw || '').toUpperCase().replace(/SEARCHING\.\.\./g, ' ');
  const pairs = text.match(/[0-9A-F]{2}/g) || [];
  for (let index = 0; index < pairs.length - 2; index += 1) {
    if (pairs[index] === '41' && pairs[index + 1] === target) return pairs.slice(index + 2).map(v => parseInt(v, 16));
  }
  return [];
}
function parseVin(raw) {
  const lines = String(raw || '').toUpperCase().split(/\r?\n/);
  const bytes = [];
  for (const line of lines) {
    const pairs = line.match(/[0-9A-F]{2}/g) || [];
    const start = pairs.findIndex((value, index) => value === '49' && pairs[index + 1] === '02');
    if (start >= 0) {
      const payload = pairs.slice(start + 3);
      for (const pair of payload) {
        const code = parseInt(pair, 16);
        if (code >= 32 && code <= 126) bytes.push(code);
      }
    }
  }
  const vin = Buffer.from(bytes).toString('ascii').replace(/[^A-HJ-NPR-Z0-9]/g, '');
  return vin.length >= 11 ? vin.slice(0, 17) : '';
}
function parsePidSample(responses = {}) {
  const get = command => extractPidBytes(responses[command], command.slice(2));
  const rpmBytes = get('010C');
  const speedBytes = get('010D');
  const ectBytes = get('0105');
  const iatBytes = get('010F');
  const tpsBytes = get('0111');
  const mapBytes = get('010B');
  const mafBytes = get('0110');
  const stftBytes = get('0106');
  const ltftBytes = get('0107');
  const sparkBytes = get('010E');
  const loadBytes = get('0104');
  const fuelBytes = get('0123');
  return {
    timestamp: new Date().toISOString(),
    rpm: rpmBytes.length >= 2 ? round(((rpmBytes[0] * 256) + rpmBytes[1]) / 4, 0) : null,
    speed: speedBytes.length ? round(speedBytes[0] * 0.621371, 1) : null,
    ect: ectBytes.length ? round((ectBytes[0] - 40) * 9 / 5 + 32, 1) : null,
    iat: iatBytes.length ? round((iatBytes[0] - 40) * 9 / 5 + 32, 1) : null,
    tps: tpsBytes.length ? round(tpsBytes[0] * 100 / 255, 1) : null,
    map: mapBytes.length ? mapBytes[0] : null,
    maf: mafBytes.length >= 2 ? round(((mafBytes[0] * 256) + mafBytes[1]) / 100, 2) : null,
    stft1: stftBytes.length ? round((stftBytes[0] - 128) * 100 / 128, 2) : null,
    ltft1: ltftBytes.length ? round((ltftBytes[0] - 128) * 100 / 128, 2) : null,
    spark: sparkBytes.length ? round(sparkBytes[0] / 2 - 64, 1) : null,
    load: loadBytes.length ? round(loadBytes[0] * 100 / 255, 1) : null,
    fuelPressure: fuelBytes.length >= 2 ? round(((fuelBytes[0] * 256) + fuelBytes[1]) * 10 / 6.89476, 1) : null,
    voltage: parseVoltage(responses.ATRV),
    protocol: normalizeAdapterText(responses.ATDP),
    knockRetard: null,
    source: 'vehicle'
  };
}


const STANDARD_COMMANDS = ['010C','010D','0105','010F','0111','010B','0110','0106','0107','010E','0104','0123'];
const ENHANCED_COLUMNS = ['commandedEqRatio','widebandAfr','misfireTotal','mafFrequency','injectorDuty','desiredIdle','commandedGear','actualGear','inputShaftSpeed','outputShaftSpeed','transSlip','shiftTime','tccSlip','torqueManagement'];
const DEFAULT_PID_LIBRARY = {
  version: 1,
  profiles: [{
    id: 'standard-obd2', name: 'Standard OBD-II', controller: '*', source: 'TunIQ',
    description: 'SAE Mode 01 channels available through most ELM/STN adapters.', channels: []
  }]
};

function formulaIsSafe(formula) {
  return typeof formula === 'string' && formula.length <= 240 && /^[A-Ha-h0-9+\-*/()., _%]+$/.test(formula) && !/(constructor|prototype|global|process|require|this)/i.test(formula);
}
function evaluatePidFormula(formula, bytes) {
  if (!formulaIsSafe(formula)) return null;
  const names = ['A','B','C','D','E','F','G','H'];
  const values = names.map((_, index) => Number(bytes[index] || 0));
  try {
    const expression = formula.replace(/\b(abs|min|max|round|floor|ceil|pow)\b/gi, match => `Math.${match.toLowerCase()}`);
    const value = Function(...names, `"use strict"; return (${expression});`)(...values);
    return Number.isFinite(Number(value)) ? Number(value) : null;
  } catch { return null; }
}
function parseCustomPidChannels(responses, channels = []) {
  const values = {};
  for (const channel of channels) {
    const command = String(channel.command || '').toUpperCase().replace(/\s+/g, '');
    if (!command || !responses[command]) continue;
    const pid = command.length >= 4 ? command.slice(-2) : command;
    const bytes = extractPidBytes(responses[command], pid);
    const value = evaluatePidFormula(String(channel.formula || 'A'), bytes);
    if (value != null) values[channel.key] = round(value, Number.isFinite(Number(channel.digits)) ? Number(channel.digits) : 2);
  }
  return values;
}

class PersistentSerialSession {
  constructor(script, port, baud, logStartup = () => {}) {
    this.script = script; this.port = port; this.baud = baud; this.logStartup = logStartup;
    this.child = null; this.pending = new Map(); this.buffer = ''; this.sequence = 0; this.ready = null;
  }
  start(timeout = 12000) {
    if (process.platform !== 'win32') return Promise.reject(new Error('Persistent serial sessions are only available on Windows.'));
    return new Promise((resolve, reject) => {
      const child = spawn('powershell.exe', ['-NoProfile','-ExecutionPolicy','Bypass','-File',this.script,'-PortName',this.port,'-Baud',String(this.baud)], { windowsHide: true });
      this.child = child;
      const timer = setTimeout(() => { this.close(); reject(new Error('The persistent OBD session timed out while opening the COM port.')); }, timeout);
      const settle = result => { clearTimeout(timer); if (result.success) { this.ready = result; resolve(result); } else { this.close(); reject(new Error(result.error || 'Could not open persistent OBD session.')); } };
      child.stdout.on('data', chunk => this.onData(chunk, settle));
      child.stderr.on('data', chunk => this.logStartup('obd-session-stderr', chunk.toString().trim()));
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => {
        for (const item of this.pending.values()) item.reject(new Error(`Persistent OBD session closed (${code}).`));
        this.pending.clear(); this.child = null;
      });
    });
  }
  onData(chunk, readyCallback) {
    this.buffer += chunk.toString();
    let newline;
    while ((newline = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, newline).trim(); this.buffer = this.buffer.slice(newline + 1);
      if (!line) continue;
      let message; try { message = JSON.parse(line); } catch { continue; }
      if (message.id === 'ready' && !this.ready) { readyCallback(message); continue; }
      const pending = this.pending.get(String(message.id));
      if (!pending) continue;
      clearTimeout(pending.timer); this.pending.delete(String(message.id));
      if (message.success) pending.resolve(message); else pending.reject(new Error(message.error || 'OBD session request failed.'));
    }
  }
  request(action, payload = {}, timeout = 12000) {
    if (!this.child?.stdin?.writable) return Promise.reject(new Error('The persistent OBD session is not connected.'));
    const id = String(++this.sequence);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => { this.pending.delete(id); reject(new Error(`Persistent OBD ${action} request timed out.`)); }, timeout);
      this.pending.set(id, { resolve, reject, timer });
      this.child.stdin.write(`${JSON.stringify({ id, action, ...payload })}\n`);
    });
  }
  async close() {
    const child = this.child; this.child = null;
    if (!child) return;
    try { if (child.stdin?.writable) child.stdin.write(`${JSON.stringify({ id: 'close', action: 'close' })}\n`); } catch {}
    setTimeout(() => { try { child.kill(); } catch {} }, 500);
  }
}

function parseCsvLine(line) {
  const values = [];
  let current = '';
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { current += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) { values.push(current); current = ''; }
    else current += char;
  }
  values.push(current);
  return values;
}

class ObdManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.appendActivity = options.appendActivity || (() => {});
    this.logStartup = options.logStartup || (() => {});
    this.bridgeScript = path.join(__dirname, 'obd-bridge.ps1');
    this.sessionScript = path.join(__dirname, 'obd-session.ps1');
    this.connection = null;
    this.serialSession = null;
    this.logger = null;
    this.demoTick = 0;
    this.platform = options.platform || process.platform;
    this.bridgeRunner = options.bridgeRunner || null;
    this.bridgeChildren = new Map();
    this.bridgeRequestSequence = 0;
    this.connectionDoctor = new ConnectionDoctor({
      dataRoot: this.dataRoot,
      listDevices: () => this.listDevices(),
      releasePort: details => this.releaseForExternalTool(details),
      probePortLock: details => this.probePortLock(details),
      probeAdapter: ({ port, baud }) => this.runBridge('Probe', { port, baud, timeout: 17000 }),
      getPreferred: () => this.getConfig(),
      savePreferred: value => this.saveConfig(value),
      normalizeProbe: (value, candidate) => this.normalizeProbeResult(value, candidate),
      appendActivity: this.appendActivity
    });
  }

  devicesRoot() { return ensureDir(path.join(this.dataRoot(), 'Devices')); }
  configFile() { return path.join(this.devicesRoot(), 'adapter.json'); }
  pidProfilesFile() { return path.join(this.devicesRoot(), 'pid-profiles.json'); }
  getPidLibrary() { const value = readJson(this.pidProfilesFile(), DEFAULT_PID_LIBRARY); return value && Array.isArray(value.profiles) ? value : DEFAULT_PID_LIBRARY; }
  savePidLibrary(value) {
    if (!value || !Array.isArray(value.profiles)) throw new Error('PID library must contain a profiles array.');
    const profiles = value.profiles.slice(0, 100).map(profile => ({
      id: cleanText(profile.id || `profile-${Date.now()}`, 100), name: cleanText(profile.name || 'Custom PID Profile', 160), controller: cleanText(profile.controller || '*', 80),
      channels: (Array.isArray(profile.channels) ? profile.channels : []).slice(0, 250).map(channel => ({ key: cleanText(channel.key, 80), name: cleanText(channel.name || channel.key, 140), command: cleanText(channel.command, 80).replace(/[^A-Fa-f0-9 ]/g, ''), formula: cleanText(channel.formula, 300), unit: cleanText(channel.unit, 40), min: Number.isFinite(Number(channel.min)) ? Number(channel.min) : null, max: Number.isFinite(Number(channel.max)) ? Number(channel.max) : null })).filter(channel => channel.key && channel.command && channel.formula)
    }));
    const safe = { version: 1, profiles }; writeJson(this.pidProfilesFile(), safe); return safe;
  }
  activePidChannels() {
    const active = this.getActiveProject(); const controller = String(active?.controller || '').toLowerCase();
    return this.getPidLibrary().profiles.filter(profile => profile.controller === '*' || controller.includes(String(profile.controller || '').toLowerCase())).flatMap(profile => Array.isArray(profile.channels) ? profile.channels : []).filter(channel => channel && channel.key && channel.command && channel.formula);
  }
  getConfig() { return readJson(this.configFile(), { port: '', baud: 0, adapter: '', autoConnect: true }); }
  saveConfig(config) { const value = { ...this.getConfig(), ...config, updatedAt: new Date().toISOString() }; writeJson(this.configFile(), value); return value; }
  getStatus() {
    return {
      connected: Boolean(this.connection),
      connection: this.connection ? { ...this.connection } : null,
      preferred: this.getConfig(),
      logging: this.logger ? { ...this.logger, stream: undefined } : null,
      profiles: SENSOR_PROFILES,
      persistent: Boolean(this.serialSession),
      enhancedPidChannels: this.activePidChannels().length
    };
  }

  terminateBridgeChild(child) {
    if (!child) return;
    try { child.kill(); } catch {}
    if (this.platform === 'win32' && child.pid) {
      try { spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true, stdio: 'ignore' }); } catch {}
    }
  }

  abortBridgeRequests(reason = 'manual recovery') {
    const active = [...this.bridgeChildren.entries()];
    for (const [, request] of active) {
      if (typeof request?.abort === 'function') request.abort(reason);
      else this.terminateBridgeChild(request?.child || request);
    }
    this.bridgeChildren.clear();
    if (active.length) this.logStartup('obd-bridge-abort', `${active.length} request(s) cleared: ${reason}`);
    return { aborted: active.length, reason };
  }

  runBridge(action, { port = '', baud = 0, timeout = 12000, targetName = '', aggressive = false } = {}) {
    if (this.bridgeRunner) {
      return Promise.resolve().then(() => this.bridgeRunner(action, { port, baud, timeout, targetName, aggressive })).catch(error => {
        const details = bridgeError(error, action, port);
        throw Object.assign(new Error(details.message), details);
      });
    }
    if (this.platform !== 'win32') return Promise.reject(Object.assign(new Error('Physical serial adapters are available on the Windows build. Use the virtual adapter to test this development build.'), { code: 'windows-required', action, port }));
    return new Promise((resolve, reject) => {
      const requestId = `${Date.now()}-${++this.bridgeRequestSequence}-${action}`;
      const args = ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', this.bridgeScript, '-Action', action, '-PortName', String(port), '-Baud', String(baud || 0), '-TargetName', String(targetName || ''), ...(aggressive ? ['-Aggressive'] : [])];
      const child = spawn('powershell.exe', args, { windowsHide: true });
      let stdout = '';
      let stderr = '';
      let settled = false;
      let timer = null;
      const finish = (callback, value) => {
        if (settled) return;
        settled = true;
        if (timer) clearTimeout(timer);
        this.bridgeChildren.delete(requestId);
        callback(value);
      };
      const abort = reason => {
        if (settled) return;
        this.terminateBridgeChild(child);
        const error = Object.assign(new Error(`The ${action.toLowerCase()} request on ${port || 'the selected COM port'} was cleared: ${reason}.`), { code: 'bridge-aborted', action, port, recoverable: true });
        finish(reject, error);
      };
      this.bridgeChildren.set(requestId, { child, abort, action, port, startedAt: new Date().toISOString() });
      timer = setTimeout(() => {
        this.terminateBridgeChild(child);
        const details = bridgeError(new Error(`The ${action.toLowerCase()} request timed out on ${port || 'the selected COM port'}.`), action, port);
        finish(reject, Object.assign(new Error(details.message), details));
      }, Math.max(1000, Number(timeout) || 12000));
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => {
        const details = bridgeError(error, action, port);
        finish(reject, Object.assign(new Error(details.message), details));
      });
      child.on('close', () => {
        if (settled) return;
        const lines = stdout.trim().split(/\r?\n/).filter(Boolean);
        let result = null;
        for (let i = lines.length - 1; i >= 0; i -= 1) {
          try { result = JSON.parse(lines[i]); break; } catch {}
        }
        if (!result) {
          const details = bridgeError(new Error(stderr.trim() || `No response from the Windows serial bridge during ${action}.`), action, port);
          return finish(reject, Object.assign(new Error(details.message), details));
        }
        if (!result.success) {
          const raw = cleanText(result.error || stderr || 'Adapter request failed.', 1000);
          const friendly = /access.*denied|unauthorized|in use|cannot open/i.test(raw)
            ? `The COM port ${port || ''} is already in use or Windows denied access. Close scanner software, then retry.`.trim()
            : raw;
          const details = bridgeError(Object.assign(new Error(friendly), { code: result.code }), action, port);
          return finish(reject, Object.assign(new Error(details.message), details));
        }
        finish(resolve, result);
      });
    });
  }

  async listDevices() {
    let physical = [];
    if (this.platform === 'win32') {
      try {
        const result = await this.runBridge('List', { timeout: 9000 });
        physical = Array.isArray(result.devices) ? result.devices : result.devices ? [result.devices] : [];
      } catch (error) {
        this.logStartup('device-scan-warning', error.message);
      }
    }
    const saved = this.getConfig();
    const normalized = physical.map(item => {
      const name = cleanText(item.name || `Serial Port (${item.port})`, 180);
      const search = `${name} ${item.manufacturer || ''} ${item.deviceId || ''} ${item.service || ''} ${item.parentId || ''} ${item.containerId || ''} ${item.location || ''} ${item.busDescription || ''}`.toLowerCase();
      const bluetooth = Boolean(item.bluetooth) || /bluetooth|bthenum|bthmodem|bthport|spp/.test(search);
      const outgoing = Boolean(item.outgoing) || /outgoing|client/.test(search);
      const incoming = Boolean(item.incoming) || /incoming|server/.test(search);
      const savedAdapterMatch = String(saved.port || '').toUpperCase() === String(item.port || '').toUpperCase() && /obdlink|scantool|stn11|stn21/i.test(`${saved.adapter || ''} ${saved.description || ''} ${saved.firmware || ''}`);
      return {
        id: item.port,
        port: item.port,
        name,
        manufacturer: cleanText(item.manufacturer, 100),
        hardwareId: cleanText(item.deviceId, 240),
        status: cleanText(item.status || 'Unknown', 40),
        service: cleanText(item.service, 100),
        parentId: cleanText(item.parentId, 260),
        containerId: cleanText(item.containerId, 260),
        pairKey: cleanText(item.pairKey || item.containerId || item.parentId, 260),
        location: cleanText(item.location, 180),
        transport: bluetooth ? 'Bluetooth Serial' : 'USB / Serial',
        bluetooth,
        outgoing,
        incoming,
        recognized: savedAdapterMatch || /obdlink|scantool|elm327|stn11|stn21|obdx|j2534/.test(search),
        recommended: savedAdapterMatch || /obdlink|stn11|stn21/.test(search)
      };
    });
    normalized.sort((a,b) => Number(b.recommended) - Number(a.recommended) || a.port.localeCompare(b.port, undefined, { numeric: true }));
    normalized.push({ id: 'virtual-demo', port: 'virtual-demo', name: 'TunIQ Virtual OBD-II Adapter', manufacturer: 'TunIQ', hardwareId: 'VIRTUAL', status: 'Ready', transport: 'Simulation', recognized: true, recommended: false, demo: true });
    return normalized;
  }

  normalizeProbeResult(result = {}, candidate = {}) {
    const observedProtocol = normalizeAdapterText(result.protocol);
    return {
      port: cleanText(result.port || candidate.port, 30),
      baud: Number(result.baud || 0),
      adapter: normalizeAdapterText(result.adapter) || 'ELM/STN-compatible adapter',
      description: normalizeAdapterText(result.description),
      firmware: normalizeAdapterText(result.deviceId || result.firmware),
      protocol: observedProtocol || 'Automatic protocol detection',
      protocolObserved: Boolean(observedProtocol),
      voltage: parseVoltage(result.voltageRaw ?? result.voltage),
      vin: parseVin(result.vinRaw) || cleanText(result.vin, 17),
      transport: cleanText(candidate.transport || result.transport || 'Bluetooth / Serial', 80)
    };
  }

  runConnectionDoctor(payload = {}) { return this.connectionDoctor.run(payload); }
  getConnectionDoctorStatus() { return this.connectionDoctor.status(); }

  async connect(payload = {}) {
    const port = cleanText(payload.port || this.getConfig().port, 30);
    if (!port) throw new Error('Select a Bluetooth or USB serial port first. Pair the OBDLink MX+ in Windows Bluetooth settings before scanning.');
    if (port === 'virtual-demo') {
      this.connection = {
        port,
        baud: 0,
        adapter: 'TunIQ Virtual OBD-II Adapter',
        description: 'Safe simulated data source',
        firmware: '1.6 dev simulator',
        protocol: 'ISO 15765-4 CAN (11-bit / 500 kbaud)',
        voltage: 13.9,
        vin: '1TUNIQ15DEV000001',
        transport: 'Simulation',
        capabilities: ['Diagnostics', 'Live logging', 'AI log review', 'Project log storage'],
        connectedAt: new Date().toISOString(),
        demo: true
      };
      this.saveConfig({ port, baud: 0, adapter: this.connection.adapter, transport: 'Simulation' });
      this.appendActivity('device-connected', { port, adapter: this.connection.adapter, demo: true });
      return this.getStatus();
    }
    const requestedBaud = Number(payload.baud || this.getConfig().baud || 0);
    const result = await this.runBridge('Probe', { port, baud: requestedBaud, timeout: 17000 });
    const normalized = this.normalizeProbeResult(result, { port, transport: 'Bluetooth / Serial' });
    const { adapter, description, firmware: deviceId, protocol, voltage, vin } = normalized;
    const isObdLink = /obdlink|stn/i.test(`${adapter} ${description} ${deviceId}`);
    this.connection = {
      ...normalized,
      port,
      baud: Number(result.baud || requestedBaud || normalized.baud || 115200),
      transport: normalized.transport || 'Bluetooth / Serial',
      capabilities: ['Diagnostics', 'Live logging', 'AI log review', 'Project log storage', ...(isObdLink ? ['OBDLink/STN command set detected'] : [])],
      connectedAt: new Date().toISOString(),
      demo: false
    };
    try {
      this.serialSession = new PersistentSerialSession(this.sessionScript, port, this.connection.baud, this.logStartup);
      await this.serialSession.start();
      this.connection.persistent = true;
      this.connection.capabilities.push('Persistent high-speed serial session');
    } catch (error) {
      this.serialSession = null;
      this.connection.persistent = false;
      this.connection.sessionWarning = error.message;
      this.logStartup('obd-persistent-session-fallback', error.message);
    }
    this.saveConfig({ port, baud: this.connection.baud, adapter, description, firmware: deviceId, protocol, vin, transport: this.connection.transport });
    this.appendActivity('device-connected', { port, baud: this.connection.baud, adapter, protocol, vin: vin || null });
    return this.getStatus();
  }

  async releaseForExternalTool({ port = '' } = {}) {
    const requested = cleanText(port || this.connection?.port || this.getConfig().port, 30);
    const previous = this.connection;
    if (previous && (!requested || previous.port === requested)) {
      await this.disconnect();
      await new Promise(resolve => setTimeout(resolve, 250));
      this.appendActivity('com-port-released-for-pcmhammer', { port: previous.port, adapter: previous.adapter });
      return { released: true, port: previous.port, owner: 'TunIQ OBD session' };
    }
    if (this.serialSession) {
      try { await this.serialSession.close(); } catch {}
      this.serialSession = null;
      await new Promise(resolve => setTimeout(resolve, 250));
      return { released: true, port: requested, owner: 'TunIQ serial session' };
    }
    return { released: false, port: requested, owner: null };
  }

  async identifyAdapterPort({ port = '', baud = 0, timeout = 12000 } = {}) {
    const requested = cleanText(port || this.getConfig().port, 30);
    if (!requested || requested === 'virtual-demo') return { available: false, locked: false, identified: false, recognized: false, supported: false, port: requested, code: 'adapter-not-detected', message: 'Select a physical OBDLink COM port.' };
    if (this.connection?.port === requested || (this.serialSession && this.connection?.port === requested)) {
      return { available: false, locked: true, identified: false, recognized: false, supported: true, owner: 'TunIQ', port: requested, code: 'adapter-locked', message: `${requested} is still open in TunIQ.` };
    }
    if (this.platform !== 'win32') return { available: false, locked: false, identified: false, recognized: false, supported: false, port: requested, code: 'windows-required', message: 'Physical adapter verification is only available on Windows.' };
    try {
      const result = await this.runBridge('Identify', { port: requested, baud: Number(baud || 0), timeout: Math.max(6000, Number(timeout || 12000)) });
      const identity = `${result.adapter || ''} ${result.description || ''} ${result.deviceId || ''} ${result.identity || ''}`.replace(/\s+/g, ' ').trim();
      const recognized = Boolean(result.recognized) || /obdlink|stn\d+|scantool|obdx|allpro|avt|elm327/i.test(identity);
      return {
        available: true,
        locked: false,
        identified: Boolean(result.identified !== false && identity),
        recognized,
        supported: true,
        port: requested,
        baud: Number(result.baud || baud || 0),
        adapter: normalizeAdapterText(result.adapter),
        description: normalizeAdapterText(result.description),
        deviceId: normalizeAdapterText(result.deviceId),
        identity: cleanText(identity, 600),
        code: recognized ? null : 'adapter-identity-unverified',
        message: recognized ? 'Adapter identity verified.' : 'A serial device answered, but its OBDLink/STN identity was not verified.'
      };
    } catch (error) {
      const details = bridgeError(error, 'Identify', requested);
      return {
        available: false,
        locked: details.code === 'adapter-locked',
        identified: false,
        recognized: false,
        supported: true,
        timedOut: details.timedOut,
        port: requested,
        code: details.code === 'bridge-timeout' ? 'adapter-open-timeout' : details.code,
        message: details.message
      };
    }
  }

  async probePortLock({ port = '', baud = 0, timeout = 3500 } = {}) {
    const requested = cleanText(port || this.getConfig().port, 30);
    if (!requested || requested === 'virtual-demo') return { available: true, locked: false, supported: false, port: requested };
    if (this.connection?.port === requested || (this.serialSession && this.connection?.port === requested)) {
      return { available: false, locked: true, supported: true, owner: 'TunIQ', port: requested, code: 'adapter-locked', message: `${requested} is still open in TunIQ.` };
    }
    if (this.platform !== 'win32') return { available: true, locked: false, supported: false, port: requested };
    try {
      const result = await this.runBridge('LockProbe', { port: requested, baud: Number(baud || this.getConfig().baud || 115200), timeout });
      return { available: Boolean(result.available), locked: Boolean(result.locked), supported: true, timedOut: false, port: requested, code: result.locked ? 'adapter-locked' : null, message: cleanText(result.error, 1000) };
    } catch (error) {
      const details = bridgeError(error, 'LockProbe', requested);
      return { available: null, locked: details.code === 'adapter-locked', supported: true, timedOut: details.timedOut, port: requested, code: details.code, message: details.message };
    }
  }

  async findRecoveryPorts(currentPort = '') {
    const devices = await this.listDevices();
    return rankAlternatePorts(devices, currentPort).slice(0, 6);
  }

  async repairBluetoothSerial({ aggressive = false, targetName = 'OBDLink' } = {}) {
    const before = await this.listDevices().catch(() => []);
    try { await this.disconnect(); } catch {}
    const cleared = this.abortBridgeRequests('Bluetooth SPP repair');
    const result = await this.runBridge('BluetoothRepair', { targetName, aggressive: Boolean(aggressive), timeout: aggressive ? 55000 : 35000 });
    await new Promise(resolve => setTimeout(resolve, 1200));
    const after = await this.listDevices().catch(() => []);
    const beforePorts = [...new Set((before || []).filter(item => !item.demo).map(item => String(item.port || '').toUpperCase()).filter(Boolean))];
    const afterPorts = [...new Set((after || []).filter(item => !item.demo).map(item => String(item.port || '').toUpperCase()).filter(Boolean))];
    const newPorts = afterPorts.filter(port => !beforePorts.includes(port));
    const report = {
      attempted: true,
      repaired: Boolean(result?.repaired || newPorts.length),
      aggressive: Boolean(aggressive),
      requiresElevation: Boolean(result?.requiresElevation),
      targetName: cleanText(targetName || 'OBDLink', 120),
      beforePorts, afterPorts, newPorts,
      services: Array.isArray(result?.services) ? result.services : [],
      native: Array.isArray(result?.native) ? result.native : result?.native ? [result.native] : [],
      nativeError: cleanText(result?.nativeError || '', 1000),
      restartResults: Array.isArray(result?.restartResults) ? result.restartResults : [],
      bridgeCleared: Number(cleared?.aborted || 0),
      at: new Date().toISOString()
    };
    try { writeJson(path.join(this.devicesRoot(), 'bluetooth-spp-repair-latest.json'), report); } catch {}
    this.appendActivity('bluetooth-spp-repair', { repaired: report.repaired, aggressive: report.aggressive, requiresElevation: report.requiresElevation, newPorts: report.newPorts });
    return report;
  }

  async disconnect() {
    const previous = this.connection;
    if (this.serialSession) { try { await this.serialSession.close(); } catch {} this.serialSession = null; }
    this.connection = null;
    if (this.logger) await this.stopLog('Adapter disconnected');
    if (previous) this.appendActivity('device-disconnected', { port: previous.port, adapter: previous.adapter });
    return this.getStatus();
  }

  virtualSample() {
    this.demoTick += 0.17;
    const t = this.demoTick;
    const throttleWave = Math.max(0, Math.sin(t * 0.55));
    const rpm = 760 + throttleWave * 3000 + Math.sin(t * 2.1) * 35;
    const speed = throttleWave > 0.18 ? throttleWave * 67 : 0;
    const leanWindow = Math.sin(t * 0.34) > 0.72;
    return {
      timestamp: new Date().toISOString(),
      rpm: round(rpm, 0),
      speed: round(speed, 1),
      ect: round(Math.min(203, 72 + t * 2.4), 1),
      iat: round(82 + Math.sin(t / 3) * 8, 1),
      tps: round(throttleWave * 78, 1),
      map: round(35 + throttleWave * 62, 1),
      maf: round(5.1 + throttleWave * 118, 2),
      stft1: round((leanWindow ? 8.5 : 0.8) + Math.sin(t * 1.5) * 2.6, 2),
      ltft1: round(leanWindow ? 5.8 : 2.1, 2),
      spark: round(18 + (1 - throttleWave) * 14 + Math.sin(t) * 2, 1),
      load: round(18 + throttleWave * 76, 1),
      fuelPressure: null,
      voltage: round(13.8 + Math.sin(t / 2) * 0.18, 2),
      protocol: this.connection?.protocol || 'SIMULATED CAN',
      knockRetard: Math.random() > 0.97 ? round(Math.random() * 2.4, 1) : 0,
      commandedEqRatio: throttleWave > 0.7 ? 0.86 : 1.0,
      widebandAfr: round(throttleWave > 0.7 ? 12.6 + Math.sin(t)*0.18 : 14.68 + Math.sin(t)*0.25, 2),
      misfireTotal: Math.random() > 0.985 ? 1 : 0,
      mafFrequency: round(2200 + throttleWave * 7800, 0),
      injectorDuty: round(4 + throttleWave * 72, 1),
      desiredIdle: 750,
      commandedGear: speed > 50 ? 4 : speed > 28 ? 3 : speed > 8 ? 2 : 1,
      actualGear: speed > 50 ? 4 : speed > 28 ? 3 : speed > 8 ? 2 : 1,
      inputShaftSpeed: round(rpm * 0.96, 0),
      outputShaftSpeed: round(speed * 32, 0),
      transSlip: round(throttleWave > 0.2 ? Math.abs(Math.sin(t*2))*18 : 4, 1),
      shiftTime: null,
      tccSlip: round(speed > 45 ? Math.abs(Math.sin(t))*12 : 120, 1),
      torqueManagement: throttleWave > 0.7 ? 1 : 0,
      source: 'virtual'
    };
  }

  async sample() {
    if (!this.connection) throw new Error('Connect a vehicle interface in Device Manager first.');
    let sample;
    if (this.connection.demo) sample = this.virtualSample();
    else {
      const customChannels = this.activePidChannels();
      const commands = [...new Set([...STANDARD_COMMANDS, ...customChannels.map(channel => String(channel.command).toUpperCase().replace(/\s+/g, ''))])];
      const result = this.serialSession
        ? await this.serialSession.request('sample', { commands, timeoutMs: 850, includeVoltage: true, includeProtocol: this.demoTick++ % 20 === 0 }, Math.max(12000, commands.length * 1200))
        : await this.runBridge('Sample', { port: this.connection.port, baud: this.connection.baud, timeout: 20000 });
      sample = { ...parsePidSample(result.responses || {}), ...parseCustomPidChannels(result.responses || {}, customChannels) };
      if (sample.protocol) this.connection.protocol = sample.protocol;
      if (Number.isFinite(sample.voltage)) this.connection.voltage = sample.voltage;
      this.connection.lastSampleMs = Date.now();
    }
    if (this.logger) this.appendSample(sample);
    return { sample, status: this.getStatus() };
  }

  startLog(payload = {}) {
    if (!this.connection) throw new Error('Connect a vehicle interface before recording a log.');
    if (this.logger) throw new Error('A log is already recording. Stop it before starting another.');
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project before recording. Logs must stay associated with a vehicle and calibration revision.');
    const profileKey = SENSOR_PROFILES[payload.profile] ? payload.profile : 'baseline';
    const profile = SENSOR_PROFILES[profileKey];
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const baseName = safeFileName(payload.name || `${profile.name}-${active.name}`);
    const logsFolder = ensureDir(path.join(active.folder, 'Logs'));
    const csvPath = path.join(logsFolder, `${baseName}-${stamp}.csv`);
    const metaPath = csvPath.replace(/\.csv$/i, '.meta.json');
    const columns = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard',...ENHANCED_COLUMNS,'marker'];
    fs.writeFileSync(csvPath, `${columns.join(',')}\n`, 'utf8');
    this.logger = {
      id: `${Date.now()}-log`,
      projectId: active.id,
      projectName: active.name,
      vehicle: active.vehicle || '',
      controller: active.controller || '',
      os: active.os || '',
      bin: active.binInfo?.name || '',
      profileKey,
      profileName: profile.name,
      sensors: profile.sensors,
      csvPath,
      metaPath,
      startedAt: new Date().toISOString(),
      samples: 0,
      pendingMarker: '',
      adapter: this.connection.adapter,
      port: this.connection.port,
      protocol: this.connection.protocol
    };
    writeJson(metaPath, { ...this.logger, status: 'recording' });
    this.appendActivity('live-log-started', { projectId: active.id, projectName: active.name, profile: profile.name, name: path.basename(csvPath), adapter: this.connection.adapter });
    return { ...this.logger };
  }

  appendSample(sample) {
    if (!this.logger) return;
    const columns = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard',...ENHANCED_COLUMNS];
    const marker = this.logger.pendingMarker || '';
    this.logger.pendingMarker = '';
    const values = columns.map(key => csvValue(sample[key]));
    values.push(csvValue(marker));
    fs.appendFileSync(this.logger.csvPath, `${values.join(',')}\n`, 'utf8');
    this.logger.samples += 1;
    this.logger.lastSampleAt = sample.timestamp;
    if (this.logger.samples % 10 === 0) writeJson(this.logger.metaPath, { ...this.logger, status: 'recording' });
  }

  markLog(label) {
    if (!this.logger) throw new Error('Start recording before adding an event marker.');
    this.logger.pendingMarker = cleanText(label || 'Driver marker', 160);
    return { marker: this.logger.pendingMarker, at: new Date().toISOString() };
  }

  async stopLog(reason = 'User stopped recording') {
    if (!this.logger) return null;
    const session = this.logger;
    this.logger = null;
    const stoppedAt = new Date().toISOString();
    const metadata = { ...session, status: 'complete', stoppedAt, stopReason: reason, durationSeconds: Math.max(0, (Date.parse(stoppedAt) - Date.parse(session.startedAt)) / 1000) };
    writeJson(session.metaPath, metadata);
    const analysis = this.analyzeCsv(session.csvPath, metadata);
    const analysisPath = session.csvPath.replace(/\.csv$/i, '.analysis.json');
    writeJson(analysisPath, analysis);
    this.appendActivity('live-log-stopped', { projectId: session.projectId, projectName: session.projectName, name: path.basename(session.csvPath), samples: session.samples, durationSeconds: metadata.durationSeconds, findings: analysis.findings.length });
    return { ...metadata, analysis, analysisPath };
  }

  listLogs() {
    const active = this.getActiveProject();
    if (!active) return [];
    const folder = path.join(active.folder, 'Logs');
    if (!fs.existsSync(folder)) return [];
    const entries = fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && entry.name.endsWith('.meta.json'))
      .map(entry => {
        const metaPath = path.join(folder, entry.name);
        const metadata = readJson(metaPath, {});
        const csvPath = metadata.csvPath || metaPath.replace(/\.meta\.json$/i, '.csv');
        const analysisPath = csvPath.replace(/\.csv$/i, '.analysis.json');
        return {
          ...metadata,
          metaPath,
          csvPath,
          name: path.basename(csvPath),
          exists: fs.existsSync(csvPath),
          analysis: readJson(analysisPath, null)
        };
      })
      .sort((a,b) => String(b.startedAt || '').localeCompare(String(a.startedAt || '')));
    return entries.slice(0, 100);
  }

  analyzeLog(csvPath) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Select the project that owns this log first.');
    const resolved = path.resolve(csvPath || '');
    const logsRoot = path.resolve(path.join(active.folder, 'Logs'));
    if (!resolved.startsWith(logsRoot + path.sep) || !fs.existsSync(resolved)) throw new Error('The requested log is not inside the active project Logs folder.');
    const meta = readJson(resolved.replace(/\.csv$/i, '.meta.json'), {});
    const analysis = this.analyzeCsv(resolved, meta);
    writeJson(resolved.replace(/\.csv$/i, '.analysis.json'), analysis);
    return analysis;
  }

  analyzeCsv(csvPath, metadata = {}) {
    const text = fs.readFileSync(csvPath, 'utf8');
    const lines = text.split(/\r?\n/).filter(Boolean);
    if (lines.length < 2) return { generatedAt: new Date().toISOString(), log: path.basename(csvPath), sampleCount: 0, confidence: 'insufficient', findings: [{ severity: 'info', title: 'Not enough data', detail: 'Record at least 20–30 seconds in the problem area before asking the AI to recommend changes.', action: 'Repeat the log with the engine fully warmed and mark the exact event.' }] };
    const headers = parseCsvLine(lines[0]);
    const rows = lines.slice(1).map(line => {
      const values = parseCsvLine(line); const row = {};
      headers.forEach((header,index) => { const raw = values[index] ?? ''; row[header] = header === 'timestamp' || header === 'marker' ? raw : (raw === '' ? null : Number(raw)); });
      return row;
    });
    const findings = [];
    const trims = rows.map(row => Number.isFinite(row.stft1) && Number.isFinite(row.ltft1) ? row.stft1 + row.ltft1 : null).filter(Number.isFinite);
    const trimAvg = mean(trims);
    if (Number.isFinite(trimAvg) && trimAvg > 8) findings.push({ severity: trimAvg > 14 ? 'high' : 'warning', title: 'Repeatable positive fuel correction', detail: `Average combined Bank 1 correction was +${round(trimAvg,1)}%. The PCM is adding fuel in the logged areas.`, action: 'Check vacuum and exhaust leaks, fuel pressure, injector data, and MAF contamination before changing airflow tables. Then isolate the RPM/load region where the correction repeats.' });
    else if (Number.isFinite(trimAvg) && trimAvg < -8) findings.push({ severity: trimAvg < -14 ? 'high' : 'warning', title: 'Repeatable negative fuel correction', detail: `Average combined Bank 1 correction was ${round(trimAvg,1)}%. The PCM is removing fuel in the logged areas.`, action: 'Verify injector characterization, fuel pressure, purge flow, and MAF scaling before reducing VE or MAF values.' });
    else if (Number.isFinite(trimAvg)) findings.push({ severity: 'ok', title: 'Fuel correction is near target', detail: `Average combined Bank 1 correction was ${round(trimAvg,1)}%.`, action: 'Review separate idle, cruise, and acceleration segments before deciding that no changes are needed.' });

    const runningVoltage = rows.filter(row => Number(row.rpm) > 450).map(row => row.voltage).filter(Number.isFinite);
    const voltageAvg = mean(runningVoltage); const voltageMin = runningVoltage.length ? Math.min(...runningVoltage) : null;
    if (Number.isFinite(voltageAvg) && (voltageAvg < 13 || voltageMin < 12.4)) findings.push({ severity: 'high', title: 'Charging voltage needs attention', detail: `Running voltage averaged ${round(voltageAvg,2)} V and reached ${round(voltageMin,2)} V.`, action: 'Repair charging or connection issues before flashing or trusting sensor behavior.' });

    const ect = rows.map(row => row.ect).filter(Number.isFinite); const ectMax = ect.length ? Math.max(...ect) : null;
    if (Number.isFinite(ectMax) && ectMax > 230) findings.push({ severity: 'high', title: 'High coolant temperature recorded', detail: `Coolant temperature reached ${round(ectMax,1)} °F.`, action: 'Verify coolant level, fan operation, thermostat, airflow, and sensor accuracy before adding timing or leaning the calibration.' });

    const idleRows = rows.filter(row => Number(row.rpm) > 450 && Number(row.speed || 0) <= 1 && Number(row.tps || 0) <= 3);
    const idleDeviation = stddev(idleRows.map(row => row.rpm).filter(Number.isFinite));
    if (idleRows.length >= 10 && idleDeviation > 110) findings.push({ severity: 'warning', title: 'Idle speed is unstable', detail: `Idle RPM standard deviation was ${round(idleDeviation,0)} RPM across ${idleRows.length} samples.`, action: 'Check for mechanical problems first, then review desired idle, base running airflow, startup airflow, and idle spark together.' });

    const highThrottle = rows.filter(row => Number(row.tps) >= 70).length;
    if (highThrottle > 0) findings.push({ severity: 'info', title: 'High-load section detected', detail: `${highThrottle} high-throttle samples were recorded. Standard OBD data does not include a trustworthy wideband AFR or controller-specific knock channel by default.`, action: 'Do not make final power-enrichment or spark changes until a wideband and enhanced controller PIDs are logged.' });

    const knockValues = rows.map(row => row.knockRetard).filter(Number.isFinite); const knockMax = knockValues.length ? Math.max(...knockValues) : null;
    if (Number.isFinite(knockMax) && knockMax >= 3) findings.push({ severity: knockMax >= 6 ? 'high' : 'warning', title: 'Enhanced knock-retard activity', detail: `Knock retard reached ${round(knockMax,1)}° in the recorded data.`, action: 'Compare RPM, load, commanded spark, AFR, temperature, and whether the event repeats before changing spark. Do not disable knock protection.' });

    const misfires = rows.map(row => row.misfireTotal).filter(Number.isFinite); const misfireRise = misfires.length > 1 ? Math.max(...misfires) - Math.min(...misfires) : null;
    if (Number.isFinite(misfireRise) && misfireRise > 5) findings.push({ severity: misfireRise > 25 ? 'high' : 'warning', title: 'Misfire count increased', detail: `The enhanced misfire total increased by ${round(misfireRise,0)} during the log.`, action: 'Inspect ignition, plugs, coils, injector operation, compression, and the exact cylinders/events before tuning around it.' });

    const duty = rows.map(row => row.injectorDuty).filter(Number.isFinite); const dutyMax = duty.length ? Math.max(...duty) : null;
    if (Number.isFinite(dutyMax) && dutyMax > 85) findings.push({ severity: dutyMax > 95 ? 'high' : 'warning', title: 'Injector duty cycle is high', detail: `Injector duty reached ${round(dutyMax,1)}%.`, action: 'Verify fuel pressure, injector flow/characterization, commanded lambda, and available injector headroom before increasing load or boost.' });

    const afrRows = rows.filter(row => Number.isFinite(row.widebandAfr) && Number.isFinite(row.commandedEqRatio) && row.commandedEqRatio > 0.01);
    if (afrRows.length >= 10) {
      const afrErrors = afrRows.map(row => row.widebandAfr - (14.7 / row.commandedEqRatio)); const afrError = mean(afrErrors);
      if (Number.isFinite(afrError) && Math.abs(afrError) > 0.5) findings.push({ severity: Math.abs(afrError) > 1.2 ? 'high' : 'warning', title: 'Measured AFR differs from commanded', detail: `Wideband AFR averaged ${afrError > 0 ? '+' : ''}${round(afrError,2)} AFR from the commanded target across ${afrRows.length} samples.`, action: 'Verify wideband calibration and delay, fuel pressure, injector data, and isolate the repeatable MAF/VE region before applying an airflow correction.' });
    }

    const desiredIdleRows = rows.filter(row => Number.isFinite(row.desiredIdle) && Number.isFinite(row.rpm) && Number(row.speed || 0) <= 1 && Number(row.tps || 0) <= 3);
    if (desiredIdleRows.length >= 15) { const idleError = mean(desiredIdleRows.map(row => row.rpm - row.desiredIdle)); if (Math.abs(idleError) > 75) findings.push({ severity: 'warning', title: 'Actual idle does not follow desired idle', detail: `Actual idle averaged ${idleError > 0 ? '+' : ''}${round(idleError,0)} RPM from desired.`, action: 'Review mechanical airflow, throttle cleanliness, base running airflow, startup airflow, idle spark, and load changes together.' }); }

    const slipRows = rows.map(row => row.transSlip).filter(Number.isFinite); const slipHigh = slipRows.filter(value => Math.abs(value) > 250);
    if (slipHigh.length >= 8) findings.push({ severity: 'warning', title: 'Transmission slip region detected', detail: `${slipHigh.length} samples exceeded 250 RPM of input/output-derived slip.`, action: 'Confirm commanded gear, shift state, TCC state, fluid condition, and sensor scaling before changing pressure or shift timing.' });
    const tccRows = rows.map(row => row.tccSlip).filter(Number.isFinite); const tccHigh = tccRows.filter(value => Math.abs(value) > 150);
    if (tccHigh.length >= 8) findings.push({ severity: 'warning', title: 'TCC slip may be excessive', detail: `${tccHigh.length} samples exceeded 150 RPM TCC slip.`, action: 'Confirm the converter clutch was commanded on, then inspect fluid, converter condition, apply pressure, and calibration.' });

    const markers = rows.filter(row => row.marker).map(row => ({ at: row.timestamp, label: row.marker }));
    if (!findings.length) findings.push({ severity: 'info', title: 'No strong repeatable fault found', detail: 'The available standard PIDs did not show a clear calibration pattern.', action: 'Record a longer log in the exact problem area and add an event marker when it happens.' });
    return {
      generatedAt: new Date().toISOString(),
      log: path.basename(csvPath),
      projectId: metadata.projectId || null,
      profile: metadata.profileName || '',
      sampleCount: rows.length,
      durationSeconds: metadata.durationSeconds || null,
      confidence: rows.length >= 120 ? 'good' : rows.length >= 30 ? 'limited' : 'insufficient',
      summary: { averageCombinedTrim: round(trimAvg,2), averageRunningVoltage: round(voltageAvg,2), minimumRunningVoltage: round(voltageMin,2), maxCoolantF: round(ectMax,1), idleRpmDeviation: round(idleDeviation,1), highThrottleSamples: highThrottle, maxKnockRetard: round(knockMax,1), injectorDutyMax: round(dutyMax,1), misfireIncrease: round(misfireRise,0), markers },
      findings
    };
  }
}

module.exports = { ObdManager, SENSOR_PROFILES, parsePidSample, parseVin, parseCustomPidChannels, evaluatePidFormula, ENHANCED_COLUMNS };
