const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { IntelligentConnectionManager } = require('../src/intelligent-connection-manager');

async function runBluetoothSppRescueSimulations({ quiet = false } = {}) {
  const reports = [];
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-spp-rescue-'));
  let repaired = false;
  const manager = new IntelligentConnectionManager({
    dataRoot: () => temp,
    listDevices: async () => repaired
      ? [{ port: 'COM5', name: 'Standard Serial over Bluetooth link (COM5)', bluetooth: true, outgoing: true, recognized: true, containerId: 'obdlink-container' }]
      : [{ port: 'COM3', name: 'Standard Serial over Bluetooth link (COM3)', bluetooth: true, incoming: true, containerId: 'obdlink-container' }],
    identifyPort: async ({ port }) => port === 'COM5'
      ? { available: true, identified: true, recognized: true, adapter: 'OBDLink MX+', identity: 'OBDLink MX+ STN1155' }
      : { available: false, identified: false, recognized: false, code: 'adapter-open-failed' },
    repairBluetooth: async () => { repaired = true; return { attempted: true, repaired: true, newPorts: ['COM5'] }; }
  });
  const result = await manager.preflight({ selectedPort: 'COM3' });
  assert.equal(result.ready, true);
  assert.equal(result.port, 'COM5');
  assert.equal(result.state, 'adapter-verified-after-bluetooth-repair');
  assert.deepEqual(result.repairAttempt.newPorts, ['COM5']);
  reports.push({ scenario: 'soft-repair-creates-outgoing-port', passed: true });

  let repairs = 0;
  const bounded = new IntelligentConnectionManager({
    dataRoot: () => fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-spp-bounded-')),
    listDevices: async () => [{ port: 'COM3', name: 'Bluetooth Serial (COM3)', bluetooth: true, incoming: true }],
    identifyPort: async () => ({ available: false, identified: false, recognized: false, code: 'adapter-open-timeout', timedOut: true }),
    repairBluetooth: async () => { repairs += 1; return { attempted: true, repaired: false, requiresElevation: false }; }
  });
  const stopped = await bounded.preflight({ selectedPort: 'COM3' });
  assert.equal(stopped.ready, false);
  assert.equal(stopped.state, 'bluetooth-spp-unavailable');
  assert.equal(repairs, 1);
  assert.equal(stopped.repair.automaticRepairAttempted, true);
  reports.push({ scenario: 'repair-is-bounded-to-one-attempt', passed: true });

  const noAuto = new IntelligentConnectionManager({
    dataRoot: () => fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-spp-no-auto-')),
    listDevices: async () => [{ port: 'COM4', name: 'OBDLink MX+ (COM4)', bluetooth: true, outgoing: true, recognized: true }],
    identifyPort: async () => ({ available: false, identified: false, recognized: false, code: 'adapter-open-failed' }),
    repairBluetooth: async () => { throw new Error('must not run'); }
  });
  const noRepair = await noAuto.preflight({ selectedPort: 'COM4', allowRepair: false });
  assert.equal(noRepair.ready, false);
  assert.equal(noRepair.state, 'ports-unavailable');
  reports.push({ scenario: 'manual-validation-can-disable-auto-repair', passed: true });

  const ps = fs.readFileSync(path.join(__dirname, '..', 'src', 'obd-bridge.ps1'), 'utf8');
  assert(ps.includes('BluetoothSetServiceState'));
  assert(ps.includes('00001101-0000-1000-8000-00805F9B34FB'));
  assert(ps.includes("'BluetoothRepair'"));
  reports.push({ scenario: 'windows-spp-service-enable-contract', passed: true });

  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
  assert(main.includes("p01-auto:bluetooth-repair"));
  assert(main.includes("system:open-bluetooth-com-setup"));
  assert(renderer.includes('Repair Bluetooth Port'));
  reports.push({ scenario: 'repair-ui-and-exact-step-resume-contract', passed: true });

  if (!quiet) console.log(`Bluetooth SPP Rescue simulations passed (${reports.length}/${reports.length}).`);
  return reports;
}

if (require.main === module) runBluetoothSppRescueSimulations().catch(error => { console.error(error); process.exit(1); });
module.exports = { runBluetoothSppRescueSimulations };
