# TunIQ v1.7.0-beta.26 — P01 Continuity Lock

Beta.26 prevents accidental Guided P01 Setup restarts from discarding verified work. Start acts as Continue, matching reads are recovered from disk, and a verified pair cannot be replaced by a later unnecessary read.

See `P01_CONTINUITY_LOCK.md` and `TEST_REPORT_v1.7.0-beta.26.md`.
