# TunIQ v1.0

Extract the ZIP and double-click `OPEN_TUNIQ_WINDOWS.bat`, or open `TunIQ_Open_Me.html`.

Guided, Manual, and Full AI modes now work from the header and Settings. Startup intentionally takes about 1–2 seconds, and AI responses show a contextual 1–3 second thinking state.

PCM writing, flashing, automatic tune editing, and recovery automation are not implemented.
