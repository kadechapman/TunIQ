param(
  [ValidateSet('List','Probe','Sample','LockProbe')]
  [string]$Action = 'List',
  [string]$PortName = '',
  [int]$Baud = 0
)

$ErrorActionPreference = 'Stop'

function Write-JsonResult($Value) {
  [Console]::Out.WriteLine(($Value | ConvertTo-Json -Compress -Depth 8))
}

function Get-SerialDevices {
  $items = @()
  try {
    $entities = Get-CimInstance Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match '\(COM\d+\)' }
    foreach ($entity in $entities) {
      $match = [regex]::Match([string]$entity.Name, '\((COM\d+)\)')
      if ($match.Success) {
        $items += [pscustomobject]@{
          port = $match.Groups[1].Value
          name = [string]$entity.Name
          manufacturer = [string]$entity.Manufacturer
          deviceId = [string]$entity.DeviceID
          status = [string]$entity.Status
        }
      }
    }
  } catch {
    try {
      $entities = Get-WmiObject Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match '\(COM\d+\)' }
      foreach ($entity in $entities) {
        $match = [regex]::Match([string]$entity.Name, '\((COM\d+)\)')
        if ($match.Success) {
          $items += [pscustomobject]@{
            port = $match.Groups[1].Value
            name = [string]$entity.Name
            manufacturer = [string]$entity.Manufacturer
            deviceId = [string]$entity.DeviceID
            status = [string]$entity.Status
          }
        }
      }
    } catch {}
  }

  try {
    $registry = Get-ItemProperty 'HKLM:\HARDWARE\DEVICEMAP\SERIALCOMM' -ErrorAction Stop
    foreach ($property in $registry.PSObject.Properties) {
      if ($property.Name -notmatch '^PS' -and [string]$property.Value -match '^COM\d+$') {
        $port = [string]$property.Value
        if (-not ($items | Where-Object { $_.port -eq $port })) {
          $items += [pscustomobject]@{
            port = $port
            name = "Serial Port ($port)"
            manufacturer = ''
            deviceId = [string]$property.Name
            status = 'Unknown'
          }
        }
      }
    }
  } catch {}

  return @($items | Sort-Object port -Unique)
}

function Open-SerialPort([string]$Name, [int]$Speed) {
  $port = New-Object System.IO.Ports.SerialPort
  $port.PortName = $Name
  $port.BaudRate = $Speed
  $port.Parity = [System.IO.Ports.Parity]::None
  $port.DataBits = 8
  $port.StopBits = [System.IO.Ports.StopBits]::One
  $port.Handshake = [System.IO.Ports.Handshake]::None
  $port.ReadTimeout = 350
  $port.WriteTimeout = 1200
  $port.NewLine = "`r"
  $port.Encoding = [System.Text.Encoding]::ASCII
  $port.DtrEnable = $false
  $port.RtsEnable = $false
  $port.Open()
  Start-Sleep -Milliseconds 220
  return $port
}

function Send-ObdCommand($Port, [string]$Command, [int]$TimeoutMs = 1800) {
  try { $Port.DiscardInBuffer() } catch {}
  $Port.Write("$Command`r")
  $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
  $text = ''
  while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 35
    try { $text += $Port.ReadExisting() } catch {}
    if ($text.Contains('>')) { break }
  }
  return $text.Trim()
}

function Initialize-Adapter($Port, [bool]$Reset) {
  $raw = @{}
  if ($Reset) {
    $raw.ATZ = Send-ObdCommand $Port 'ATZ' 2800
    Start-Sleep -Milliseconds 180
  }
  $raw.ATE0 = Send-ObdCommand $Port 'ATE0' 1000
  $raw.ATL0 = Send-ObdCommand $Port 'ATL0' 1000
  $raw.ATS0 = Send-ObdCommand $Port 'ATS0' 1000
  $raw.ATH0 = Send-ObdCommand $Port 'ATH0' 1000
  if ($Reset) { $raw.ATSP0 = Send-ObdCommand $Port 'ATSP0' 1200 }
  return $raw
}

function Probe-Adapter([string]$Name, [int]$RequestedBaud) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  $rates = if ($RequestedBaud -gt 0) { @($RequestedBaud) } else { @(115200, 38400, 9600) }
  $lastError = ''
  foreach ($rate in $rates) {
    $port = $null
    try {
      $port = Open-SerialPort $Name $rate
      $init = Initialize-Adapter $port $true
      $ati = Send-ObdCommand $port 'ATI' 1400
      if ([string]::IsNullOrWhiteSpace($ati) -or $ati -match 'UNABLE TO CONNECT') { throw "No adapter response at $rate baud." }
      $description = Send-ObdCommand $port 'AT@1' 1200
      $deviceId = Send-ObdCommand $port 'STDI' 1200
      $voltage = Send-ObdCommand $port 'ATRV' 1200
      $protocol = Send-ObdCommand $port 'ATDP' 1200
      $vin = Send-ObdCommand $port '0902' 3000
      return [pscustomobject]@{
        success = $true
        port = $Name
        baud = $rate
        adapter = $ati
        description = $description
        deviceId = $deviceId
        voltageRaw = $voltage
        protocol = $protocol
        vinRaw = $vin
        init = $init
      }
    } catch {
      $lastError = $_.Exception.Message
    } finally {
      if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
      if ($port) { try { $port.Dispose() } catch {} }
    }
  }
  throw "Could not communicate with $Name. $lastError"
}


function Test-PortLock([string]$Name, [int]$Speed) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  if ($Speed -le 0) { $Speed = 115200 }
  $port = $null
  try {
    $port = Open-SerialPort $Name $Speed
    return [pscustomobject]@{ success = $true; available = $true; locked = $false; port = $Name; baud = $Speed }
  } catch {
    $message = $_.Exception.Message
    return [pscustomobject]@{ success = $true; available = $false; locked = $true; port = $Name; baud = $Speed; error = $message }
  } finally {
    if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
    if ($port) { try { $port.Dispose() } catch {} }
  }
}

function Read-Sample([string]$Name, [int]$Speed) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  if ($Speed -le 0) { $Speed = 115200 }
  $port = $null
  try {
    $port = Open-SerialPort $Name $Speed
    $null = Initialize-Adapter $port $false
    $commands = @('010C','010D','0105','010F','0111','010B','0110','0106','0107','010E','0104','0123')
    $responses = @{}
    foreach ($command in $commands) {
      $responses[$command] = Send-ObdCommand $port $command 1500
    }
    $responses['ATRV'] = Send-ObdCommand $port 'ATRV' 1000
    $responses['ATDP'] = Send-ObdCommand $port 'ATDP' 1000
    return [pscustomobject]@{
      success = $true
      port = $Name
      baud = $Speed
      responses = $responses
    }
  } finally {
    if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
    if ($port) { try { $port.Dispose() } catch {} }
  }
}

try {
  switch ($Action) {
    'List' { Write-JsonResult ([pscustomobject]@{ success = $true; devices = @(Get-SerialDevices) }) }
    'Probe' { Write-JsonResult (Probe-Adapter $PortName $Baud) }
    'Sample' { Write-JsonResult (Read-Sample $PortName $Baud) }
    'LockProbe' { Write-JsonResult (Test-PortLock $PortName $Baud) }
  }
} catch {
  Write-JsonResult ([pscustomobject]@{ success = $false; error = $_.Exception.Message; action = $Action; port = $PortName })
  exit 1
}
