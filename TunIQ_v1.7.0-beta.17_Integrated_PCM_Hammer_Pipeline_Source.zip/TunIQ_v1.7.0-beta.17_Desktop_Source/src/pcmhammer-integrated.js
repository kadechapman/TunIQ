const fs = require('fs');
const path = require('path');

const INTEGRATED_PROFILES = Object.freeze([
  {
    id: 'official-2x-long-port', label: 'PCM Hammer 2.x long options (--port)',
    templates: {
      readProperties: ['read-properties', '--port', '{device}'],
      read: ['read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-device', label: 'PCM Hammer 2.x long options (--device)',
    templates: {
      readProperties: ['read-properties', '--device', '{device}'],
      read: ['read-full', '--device', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--device', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--device', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--device', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--device', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-interface', label: 'PCM Hammer 2.x long options (--interface)',
    templates: {
      readProperties: ['read-properties', '--interface', '{device}'],
      read: ['read-full', '--interface', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--interface', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--interface', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--interface', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--interface', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-short', label: 'PCM Hammer 2.x short options',
    templates: {
      readProperties: ['read-properties', '-p', '{device}'],
      read: ['read-full', '-p', '{device}', '-o', '{output}'],
      testWrite: ['test-write', '-p', '{device}', '-i', '{input}'],
      writeCalibration: ['write-calibration', '-p', '{device}', '-i', '{input}'],
      writeFull: ['write-full', '-p', '{device}', '-i', '{input}'],
      recovery: ['recovery', '-p', '{device}', '-i', '{input}']
    }
  },
  {
    id: 'official-2x-flags', label: 'PCM Hammer 2.x operation flags',
    templates: {
      readProperties: ['--read-properties', '--port', '{device}'],
      read: ['--read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['--test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['--write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['--write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['--recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-positional', label: 'PCM Hammer 2.x positional arguments',
    templates: {
      readProperties: ['read-properties', '{device}'],
      read: ['read-full', '{device}', '{output}'],
      testWrite: ['test-write', '{device}', '{input}'],
      writeCalibration: ['write-calibration', '{device}', '{input}'],
      writeFull: ['write-full', '{device}', '{input}'],
      recovery: ['recovery', '{device}', '{input}']
    }
  }
]);

function profileById(id) { return INTEGRATED_PROFILES.find(profile => profile.id === id) || null; }
function isRecognizedPcmHammerExecutable(executable = '', backend = null) {
  const name = path.basename(String(executable || '')).toLowerCase();
  return /pcm\s*hammer|pcmhammer/.test(String(backend?.product || '')) || /pcmhammer.*(?:cli|console)|(?:cli|console).*pcmhammer/.test(name);
}
function isSyntaxFailure(text = '', exitCode = null) {
  const source = String(text || '');
  if (/(?:unknown|invalid|unrecognized|unsupported)\s+(?:command|option|argument|verb)|no\s+such\s+(?:command|option)|unexpected\s+(?:argument|option)|required\s+(?:option|argument).*missing|usage\s*:/i.test(source)) return true;
  return Number(exitCode) !== 0 && /(?:help|usage|command line|arguments?|options?)/i.test(source) && !hasCommunicationActivity(source);
}
function hasCommunicationActivity(text = '') {
  return /(?:opening|opened|connecting|connected|initializ|adapter|interface|serial|voltage|vin\s*:|osid\s*:|hardware\s+id|service\s+(?:no|number)|controller\s*:|reading\s+(?:block|pcm)|kernel|unlock|security|erase|writ(?:e|ing)|program|verif)/i.test(String(text || ''));
}
function outputWasCreated(file) {
  try { return Boolean(file && fs.statSync(file).isFile() && fs.statSync(file).size > 0); } catch { return false; }
}
function safeToRetryProfile({ operation, text, exitCode, output }) {
  if (!['readProperties', 'read'].includes(String(operation || ''))) return false;
  if (!isSyntaxFailure(text, exitCode)) return false;
  if (hasCommunicationActivity(text)) return false;
  if (outputWasCreated(output)) return false;
  return true;
}
function profilesForOperation(operation, cachedProfileId = '', customTemplate = null) {
  if (customTemplate) return [{ id: 'configured-template', label: 'Configured command template', templates: { [operation]: customTemplate } }];
  const cached = profileById(cachedProfileId);
  if (cached?.templates?.[operation]) return [cached];
  return INTEGRATED_PROFILES.filter(profile => profile.templates?.[operation]);
}
function profileCapabilities(profileId) {
  const profile = profileById(profileId);
  return Object.fromEntries(['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].map(operation => [operation, Boolean(profile?.templates?.[operation])]));
}

module.exports = {
  INTEGRATED_PROFILES,
  profileById,
  profilesForOperation,
  profileCapabilities,
  isRecognizedPcmHammerExecutable,
  isSyntaxFailure,
  hasCommunicationActivity,
  safeToRetryProfile,
  outputWasCreated
};
