const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');
const {
  P01_BIN_SIZE, OPERATIONS, normalizeOperation, tokenizeTemplate, expandTemplate, parseProgress,
  parseIdentityText, parseBackendIdentity, inferTemplates, classifyPcmHammerResult,
  validateP01ReadFile, assistedInstructions, sha256File, clean
} = require('./pcmhammer');
const {
  profilesForOperation, profileCapabilities, isRecognizedPcmHammerExecutable,
  safeToRetryProfile, hasCommunicationActivity
} = require('./pcmhammer-integrated');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function safeName(value) { return String(value || 'PCM').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'PCM'; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function uniqueFiles(files = []) { return [...new Set(files.filter(Boolean).map(file => path.resolve(String(file))))]; }
function fileFingerprint(file) {
  try { const stat = fs.statSync(file); return `${path.resolve(file)}:${stat.size}:${stat.mtimeMs}`; } catch { return path.resolve(String(file)); }
}

class FlashStopError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'FlashStopError'; this.code = code; this.details = details; }
}

class FlashManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.getToolPath = options.getToolPath;
    this.getDeviceStatus = options.getDeviceStatus || (() => ({}));
    this.releasePort = options.releasePort || (async () => ({ released: false }));
    this.probePortLock = options.probePortLock || (async () => ({ available: true, locked: false, supported: false }));
    this.findAlternatePorts = options.findAlternatePorts || (async () => []);
    this.abortBridgeRequests = options.abortBridgeRequests || (() => ({ aborted: 0 }));
    this.appendActivity = options.appendActivity || (() => {});
    this.emit = options.emit || (() => {});
    this.onReadComplete = options.onReadComplete || (() => {});
    this.onIdentifyComplete = options.onIdentifyComplete || (() => {});
    this.onSessionComplete = options.onSessionComplete || (() => {});
    this.session = null;
    this.history = null;
    this.assistedWatchers = new Map();
    this.portOwner = { owner: 'idle', port: '', operation: '', leaseId: '', since: null };
  }

  configFile() { return path.join(this.dataRoot(), 'Tools', 'pcmhammer-cli.json'); }
  sessionsRoot() { return ensureDir(path.join(this.dataRoot(), 'Logs', 'Flash')); }
  historyFile() { return path.join(this.sessionsRoot(), 'history.json'); }
  assistedStateFile(active = this.getActiveProject()) { return active?.folder ? path.join(active.folder, 'Reports', 'p01-assisted-pcmhammer.json') : null; }
  assistedFolder(active = this.getActiveProject()) { return active?.folder ? ensureDir(path.join(active.folder, 'Imports', 'PCM-Hammer-Assisted')) : null; }
  getHistory() { if (!Array.isArray(this.history)) this.history = readJson(this.historyFile(), []); return Array.isArray(this.history) ? this.history : []; }
  recordHistory(session) {
    const summary = { ...session, child: undefined, log: Array.isArray(session.log) ? session.log.slice(-120) : [] };
    const history = this.getHistory(); history.unshift(summary); if (history.length > 150) history.length = 150;
    this.history = history; writeJson(this.historyFile(), history); return summary;
  }
  getConfig() {
    const fallback = {
      executable: '', prefixArgs: [], device: '', mode: 'auto', probedAt: null, helpText: '',
      integratedProfileId: '', integrationMode: 'unprobed', profileAttempts: [],
      templates: { readProperties: null, read: null, testWrite: null, writeCalibration: null, writeFull: null, recovery: null }
    };
    const config = readJson(this.configFile(), fallback) || fallback;
    if (!config.templates?.readProperties && config.templates?.identify) config.templates.readProperties = config.templates.identify;
    delete config.templates?.identify;
    return { ...fallback, ...config, templates: { ...fallback.templates, ...(config.templates || {}) } };
  }
  saveConfig(patch = {}) {
    const current = this.getConfig();
    const next = { ...current, ...patch, templates: { ...current.templates, ...(patch.templates || {}) }, updatedAt: new Date().toISOString() };
    delete next.templates.identify;
    writeJson(this.configFile(), next);
    return next;
  }

  resolveExecutable() {
    const config = this.getConfig();
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const candidates = [];
    if (config.executable) candidates.push(config.executable);
    if (toolPath) {
      const folder = path.extname(toolPath) ? path.dirname(toolPath) : toolPath;
      candidates.push(toolPath);
      for (const name of ['PcmHammerCLI.exe', 'PCM Hammer CLI.exe', 'pcmhammer-cli.exe', 'PcmHammer.Console.exe', 'PcmHammerCLI']) candidates.push(path.join(folder, name));
    }
    for (const candidate of candidates) {
      try {
        if (fs.statSync(candidate).isFile() && /(?:cli|console)/i.test(path.basename(candidate))) return { executable: candidate, prefixArgs: Array.isArray(config.prefixArgs) ? config.prefixArgs : [] };
      } catch {}
    }
    return null;
  }
  resolveGuiExecutable() {
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const config = this.getConfig();
    const candidates = [];
    const addFolder = folder => {
      if (!folder) return;
      for (const name of ['PcmHammer.exe', 'PCM Hammer.exe', 'pcmhammer.exe']) candidates.push(path.join(folder, name));
    };
    if (config.guiExecutable) candidates.push(config.guiExecutable);
    for (const source of [toolPath, config.executable]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      if (!/(?:cli|console)/i.test(path.basename(source))) candidates.push(source);
      addFolder(folder);
      addFolder(path.dirname(folder)); // Portable releases commonly place Cli\ beside PcmHammer.exe.
      addFolder(path.join(folder, '..', 'PcmHammer'));
      addFolder(path.join(folder, '..', 'GUI'));
    }
    for (const candidate of [...new Set(candidates.map(item => path.resolve(item)))]) {
      try { if (fs.statSync(candidate).isFile() && !/(?:cli|console)/i.test(path.basename(candidate))) return candidate; } catch {}
    }
    return null;
  }

  saveGuiExecutable(executable) {
    if (!executable) return this.saveConfig({ guiExecutable: null });
    const resolved = path.resolve(String(executable));
    if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile() || /(?:cli|console)/i.test(path.basename(resolved))) {
      throw new FlashStopError('gui-invalid', 'Select the normal PcmHammer.exe application, not a CLI or console executable.');
    }
    return this.saveConfig({ guiExecutable: resolved });
  }

  async runCapture(executable, args, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const child = spawn(executable, args, { windowsHide: true, cwd: path.dirname(executable) });
      let stdout = ''; let stderr = ''; let finished = false;
      const done = value => { if (finished) return; finished = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => { try { child.kill(); } catch {} reject(new Error('PCM Hammer CLI probe timed out.')); }, timeout);
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => done({ code, stdout, stderr, text: `${stdout}\n${stderr}`.trim() }));
    });
  }

  async probe(payload = {}) {
    if (payload.executable) this.saveConfig({ executable: payload.executable, prefixArgs: payload.prefixArgs || [] });
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer 2.x CLI was not found. Configure the pcmhammer-cli executable in Tool Connections.');
    let helpResult = null;
    const probeAttempts = [];
    for (const attempt of [['--help'], ['-h'], ['help'], []]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt]);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text?.length > 20) { helpResult = result; break; }
      } catch (error) { probeAttempts.push({ args: attempt, error: clean(error.message, 500) }); }
    }
    let versionText = '';
    for (const attempt of [['--version'], ['-v'], ['version']]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt], 8000);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text) { versionText = result.text; break; }
      } catch (error) { probeAttempts.push({ args: attempt, error: clean(error.message, 500) }); }
    }
    const combined = `${versionText}\n${helpResult?.text || ''}`;
    const parsedBackend = parseBackendIdentity(combined, resolved.executable);
    const recognizedExecutable = isRecognizedPcmHammerExecutable(resolved.executable, parsedBackend);
    const backend = {
      ...parsedBackend,
      product: parsedBackend.product || (recognizedExecutable ? 'PCM Hammer' : ''),
      recognizedExecutable,
      sha256: sha256File(resolved.executable),
      executable: resolved.executable
    };
    const inferred = inferTemplates(helpResult?.text || '');
    const existing = this.getConfig();
    const templates = {};
    for (const operation of Object.keys(OPERATIONS)) templates[operation] = inferred[operation] || existing.templates?.[operation] || null;
    const helpCapabilities = Object.fromEntries(Object.entries(templates).map(([key, value]) => [key, Boolean(value)]));
    const cachedCapabilities = profileCapabilities(existing.integratedProfileId);
    const runtimeDiscovery = recognizedExecutable && !Object.values(helpCapabilities).some(Boolean) && !Object.values(cachedCapabilities).some(Boolean);
    const capabilities = Object.fromEntries(Object.keys(OPERATIONS).map(operation => [
      operation,
      Boolean(helpCapabilities[operation] || cachedCapabilities[operation] || (runtimeDiscovery && ['readProperties','read'].includes(operation)))
    ]));
    const integrationMode = Object.values(helpCapabilities).some(Boolean) ? 'help-driven'
      : Object.values(cachedCapabilities).some(Boolean) ? 'cached-profile'
        : runtimeDiscovery ? 'runtime-profile-discovery' : 'unsupported';
    const official = Boolean(parsedBackend.official || existing.backend?.verifiedByOperation);
    const stop = !recognizedExecutable ? { code: 'unsupported-cli', message: 'The selected executable is not recognized as PCM Hammer CLI.' } : null;
    const config = this.saveConfig({
      executable: resolved.executable,
      prefixArgs: resolved.prefixArgs,
      helpText: (helpResult?.text || '').slice(0, 50000),
      versionText: versionText.slice(0, 5000),
      backend: { ...backend, official, integrationReady: integrationMode !== 'unsupported' },
      templates,
      integrationMode,
      profileAttempts: probeAttempts.slice(-12),
      probedAt: new Date().toISOString(),
      lastProbeStop: stop
    });
    return {
      executable: resolved.executable,
      backend: config.backend,
      capabilities,
      templates: config.templates,
      help: (helpResult?.text || '').slice(0, 16000),
      probedAt: config.probedAt,
      assistedAvailable: Boolean(this.resolveGuiExecutable()),
      mode: integrationMode,
      integratedProfileId: config.integratedProfileId || '',
      stop
    };
  }

  status() {
    const resolved = this.resolveExecutable();
    const config = this.getConfig();
    const active = this.getActiveProject();
    const assisted = active ? readJson(this.assistedStateFile(active), null) : null;
    return {
      configured: Boolean(resolved), executable: resolved?.executable || null,
      backend: config.backend || null,
      capabilities: Object.fromEntries(Object.keys(OPERATIONS).map(operation => [operation, Boolean(config.templates?.[operation] || profileCapabilities(config.integratedProfileId)[operation] || (config.integrationMode === 'runtime-profile-discovery' && ['readProperties','read'].includes(operation)))])),
      templates: config.templates || {}, session: this.session ? { ...this.session, child: undefined } : null,
      device: config.device || '', probedAt: config.probedAt || null, history: this.getHistory().slice(0, 30),
      integrationMode: config.integrationMode || 'unprobed', integratedProfileId: config.integratedProfileId || '',
      portOwner: { ...this.portOwner }, integrated: Boolean(resolved && config.integrationMode !== 'unsupported'),
      assistedAvailable: Boolean(this.resolveGuiExecutable()), assisted
    };
  }

  saveDevice(device) { return this.saveConfig({ device: clean(device, 200) }); }
  saveTemplates(templates) {
    const normalized = {};
    for (const operation of Object.keys(OPERATIONS)) {
      const template = templates?.[operation] ?? (operation === 'readProperties' ? templates?.identify : null);
      if (template == null || String(Array.isArray(template) ? template.join(' ') : template).trim() === '') { normalized[operation] = null; continue; }
      const text = String(Array.isArray(template) ? template.join(' ') : template);
      if (OPERATIONS[operation].io === 'input' && !text.includes('{input}')) throw new Error(`${operation} command template must include {input}.`);
      if (OPERATIONS[operation].io === 'output' && !text.includes('{output}')) throw new Error(`${operation} command template must include {output}.`);
      normalized[operation] = tokenizeTemplate(template);
    }
    return this.saveConfig({ templates: normalized });
  }

  preflight(operation, payload = {}) {
    const normalizedOperation = normalizeOperation(operation);
    if (!OPERATIONS[normalizedOperation]) throw new FlashStopError('unsupported-operation', `Unsupported PCM Hammer operation: ${operation}.`);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const config = this.getConfig();
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer CLI is unavailable. Guided Automatic P01 Setup can switch to the normal PCM Hammer app and import its evidence.');
    const template = config.templates?.[normalizedOperation] || null;
    const recognized = isRecognizedPcmHammerExecutable(resolved.executable, config.backend);
    if (!recognized) throw new FlashStopError('unsupported-cli', 'The configured executable is not recognized as PCM Hammer CLI.');
    const candidateProfiles = profilesForOperation(normalizedOperation, config.integratedProfileId, template);
    if (!candidateProfiles.length) throw new FlashStopError('integrated-profile-unresolved', `TunIQ could not resolve a PCM Hammer command profile for ${OPERATIONS[normalizedOperation].label}. Run integrated Read Properties or a full read first so TunIQ can safely discover and cache the installed CLI syntax.`);
    if (!template && !config.integratedProfileId && !['readProperties','read'].includes(normalizedOperation)) throw new FlashStopError('integrated-profile-unresolved', `The PCM Hammer CLI syntax has not been proven yet. Run integrated Read Properties or a full read before ${OPERATIONS[normalizedOperation].label}.`);
    if (this.session) throw new FlashStopError('operation-running', 'Another PCM Hammer operation is already running.');
    const deviceStatus = this.getDeviceStatus() || {};
    const voltage = Number(payload.voltage ?? deviceStatus.connection?.voltage);
    const selectedDevice = payload.device || config.device || deviceStatus.connection?.port || '';
    const values = {
      device: selectedDevice, port: selectedDevice, project: active.folder, controller: active.controller || '',
      input: payload.input || '', output: payload.output || ''
    };
    const writeOperation = ['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (writeOperation) {
      if (!values.input || !fs.existsSync(values.input)) throw new FlashStopError('input-missing', 'Select an existing revision BIN before Test Write or writing.');
      if (!active.bin || !fs.existsSync(active.bin)) throw new FlashStopError('original-missing', 'A protected verified original BIN is required before any write-related operation.');
      const sourceSize = fs.statSync(values.input).size;
      const originalSize = fs.statSync(active.bin).size;
      if (sourceSize !== originalSize) throw new FlashStopError('input-size-mismatch', `Revision size (${sourceSize}) does not match the protected original (${originalSize}).`);
      if (!Number.isFinite(voltage) && !payload.benchPowerConfirmed) throw new FlashStopError('power-proof-missing', 'Live voltage is unavailable. Enter voltage or confirm a regulated bench supply.');
      if (Number.isFinite(voltage) && voltage < 12.2) throw new FlashStopError('voltage-low', `Voltage is too low for a controlled ${OPERATIONS[normalizedOperation].label} (${voltage.toFixed(2)} V).`);
      if (normalizedOperation !== 'testWrite') {
        const expected = ['writeFull', 'recovery'].includes(normalizedOperation) ? `FULL WRITE ${active.name}` : `WRITE ${active.name}`;
        if (String(payload.confirmation || '').trim() !== expected) throw new FlashStopError('confirmation-missing', `Type exactly “${expected}” to authorize this operation.`);
        if (!payload.checksumApproved) throw new FlashStopError('checksum-not-approved', 'Checksum and compatibility validation must pass before writing.');
      }
    }
    if (normalizedOperation === 'read') {
      const output = values.output || path.join(active.folder, 'Originals', `${safeName(active.name)}-P01-Full-Read-${new Date().toISOString().replace(/[:.]/g, '-')}.bin`);
      ensureDir(path.dirname(output)); values.output = output;
    }
    return { operation: normalizedOperation, active, config, resolved, template, candidateProfiles, values, voltage: Number.isFinite(voltage) ? voltage : null };
  }

  setPortOwner(owner, details = {}) {
    this.portOwner = {
      owner,
      port: clean(details.port || this.portOwner.port, 40),
      operation: clean(details.operation || '', 80),
      leaseId: clean(details.leaseId || '', 120),
      since: owner === 'idle' ? null : new Date().toISOString()
    };
    this.emit('flash:port-owner', { ...this.portOwner });
    return this.portOwner;
  }

  async preparePort(preflight) {
    const selectedPort = preflight.values.device;
    const leaseId = `${Date.now()}-${preflight.operation}-${selectedPort || 'auto'}`;
    if (!selectedPort) {
      this.setPortOwner('pcmhammer', { port: '', operation: preflight.operation, leaseId });
      return { port: '', released: false, mode: 'direct-handoff', lockProbeSkipped: true, leaseId, attempts: [] };
    }
    // Beta.17 uses a direct lease instead of opening the port a second time with a separate lock probe.
    // TunIQ closes its own bridge, waits for Windows to release the handle, then PCM Hammer is the only process allowed to open it.
    const release = await this.releasePort({ port: selectedPort, operation: preflight.operation, leaseId, owner: 'pcmhammer' });
    this.abortBridgeRequests(`PCM Hammer direct lease ${leaseId}`);
    await sleep(300);
    this.setPortOwner('pcmhammer', { port: selectedPort, operation: preflight.operation, leaseId });
    return {
      port: selectedPort,
      released: Boolean(release?.released),
      release,
      mode: 'direct-handoff',
      lockProbeSkipped: true,
      leaseId,
      attempts: [{ port: selectedPort, source: 'selected', release, lockProbe: { skipped: true, reason: 'direct PCM Hammer lease' }, at: new Date().toISOString() }]
    };
  }

  clearTransientRecoveryState(reason = 'workflow recovery') {
    const bridge = this.abortBridgeRequests(reason) || { aborted: 0 };
    if (this.session && !['writeCalibration','writeFull','recovery'].includes(this.session.operation)) {
      try { this.session.child?.kill(); } catch {}
      this.session = null;
    }
    if (!this.session) this.setPortOwner('idle', { port: this.portOwner.port });
    return { bridge, activeSession: Boolean(this.session) };
  }

  async start(operation, payload = {}) {
    const preflight = this.preflight(operation, payload);
    const portLease = await this.preparePort(preflight);
    const profiles = preflight.candidateProfiles || [];
    const session = {
      id: `${Date.now()}-${preflight.operation}`, operation: preflight.operation,
      projectId: preflight.active.id, projectName: preflight.active.name,
      executable: preflight.resolved.executable, backendSha256: preflight.config?.backend?.sha256 || '', backendVersion: preflight.config?.backend?.version || '',
      args: [], input: preflight.values.input || null, output: preflight.values.output || null,
      device: preflight.values.device || null, voltage: preflight.voltage, portLease,
      integrated: true, integrationMode: preflight.config.integrationMode || 'runtime-profile-discovery',
      profileAttempts: [], startedAt: new Date().toISOString(), state: 'running', progress: 0,
      phase: `Starting integrated PCM Hammer ${OPERATIONS[preflight.operation].label}`, log: []
    };
    const sessionLog = path.join(this.sessionsRoot(), `${session.id}.log`);
    session.sessionLog = sessionLog;
    this.session = session;
    const emit = () => this.emit('flash:progress', { ...session, child: undefined });
    const append = (stream, chunk) => {
      const text = chunk.toString(); fs.appendFileSync(sessionLog, text, 'utf8');
      for (const line of text.split(/\r?\n/).filter(Boolean)) {
        const entry = { at: new Date().toISOString(), stream, text: clean(line, 3000) };
        session.log.push(entry); if (session.log.length > 1200) session.log.shift();
        session.progress = parseProgress(entry.text, session.progress);
        if (/read\s+propert|OSID|Hardware ID|Service No/i.test(entry.text)) session.phase = 'Reading controller properties inside TunIQ';
        else if (/read|block/i.test(entry.text)) session.phase = 'Reading PCM inside TunIQ';
        else if (/erase/i.test(entry.text)) session.phase = 'Erasing flash';
        else if (/write|program/i.test(entry.text)) session.phase = 'Writing flash';
        else if (/verif/i.test(entry.text)) session.phase = 'Verifying';
        const voltage = entry.text.match(/(?:battery\s+)?voltage(?:\s+is)?\s*:\s*(\d+(?:\.\d+)?)/i)?.[1];
        if (voltage) session.voltage = Number(voltage);
      }
      emit();
    };

    const finalize = async (code, attemptText, profile) => {
      if (session.finalized) return;
      session.exitCode = code; session.finishedAt = new Date().toISOString();
      session.result = classifyPcmHammerResult(session.operation, attemptText, code);
      session.identity = parseIdentityText(attemptText);
      if (Number.isFinite(session.identity.voltage)) session.voltage = session.identity.voltage;
      session.stopCode = session.result.stopCode;
      session.state = session.cancelRequested ? 'cancelled' : session.result.success ? 'complete' : 'failed';
      session.progress = session.result.success ? 100 : session.progress;
      session.testWritePassed = Boolean(session.result.testWritePassed);
      session.verified = Boolean(session.result.verificationPassed || session.result.testWritePassed);
      const allProfilesRejectedBeforeCommunication = session.profileAttempts.length >= profiles.length
        && session.profileAttempts.length > 0
        && session.profileAttempts.every(item => item.syntaxFailure && !item.communicationStarted);
      if (allProfilesRejectedBeforeCommunication) {
        session.state = 'failed';
        session.stopCode = 'integrated-cli-profile-unresolved';
        session.error = `TunIQ tried every safe PCM Hammer 2.x command profile for ${OPERATIONS[session.operation].label}, but this CLI build did not accept any of them. No PCM communication began and no output was accepted.`;
      }
      if (session.state === 'complete' && profile?.id && profile.id !== 'configured-template') {
        const existingBackend = this.getConfig().backend || {};
        const config = this.saveConfig({
          integratedProfileId: profile.id,
          integrationMode: 'verified-profile',
          templates: profile.templates,
          backend: { ...existingBackend, product: 'PCM Hammer', official: true, verifiedByOperation: true, integrationReady: true, verifiedAt: new Date().toISOString() },
          profileAttempts: session.profileAttempts.slice(-20)
        });
        session.integratedProfileId = profile.id;
        session.backendVersion = config.backend?.version || session.backendVersion;
      }
      if (session.operation === 'read' && !allProfilesRejectedBeforeCommunication) {
        const validation = validateP01ReadFile(session.output, session.result);
        session.outputValidation = validation;
        if (!validation.valid) {
          const communicationStops = new Set(['adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'pcmhammer-failed']);
          const classifiedStop = session.result?.stopCode;
          session.state = 'failed';
          session.stopCode = communicationStops.has(classifiedStop) ? classifiedStop : validation.code;
          session.error = communicationStops.has(classifiedStop)
            ? `PCM Hammer stopped before a complete read (${classifiedStop}). ${validation.message}`
            : validation.message;
          if (session.output && fs.existsSync(session.output)) {
            const rejected = `${session.output}.rejected-${Date.now()}`;
            try { fs.renameSync(session.output, rejected); session.rejectedOutput = rejected; } catch {}
          }
        } else {
          session.outputInfo = validation;
          try { await this.onReadComplete(session.output, session.outputInfo, session); }
          catch (error) { session.state = 'failed'; session.stopCode = 'read-import-failed'; session.importWarning = error.message; }
        }
      }
      const identityUseful = session.operation === 'readProperties'
        ? Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.controller)
        : Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.vin);
      if (identityUseful) {
        try { await this.onIdentifyComplete(session.identity, session); }
        catch (error) { session.identityWarning = error.message; if (session.operation === 'readProperties') { session.state = 'failed'; session.stopCode = 'identity-import-failed'; } }
      }
      if (session.operation === 'readProperties' && !identityUseful && !allProfilesRejectedBeforeCommunication) {
        session.state = 'failed';
        const specificStops = new Set(['adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'partial-read', 'pcmhammer-failed']);
        if (!specificStops.has(session.result?.stopCode)) {
          session.stopCode = 'properties-incomplete';
          session.error = 'Read Properties finished without OSID, Hardware ID, service number, or controller evidence.';
        } else {
          session.stopCode = session.result.stopCode;
          session.error = `PCM Hammer stopped before Read Properties completed (${session.result.stopCode}).`;
        }
      }
      if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && code === 0 && !session.verified) {
        session.state = 'complete-unverified'; session.stopCode = 'verification-not-proven';
        session.verificationWarning = 'PCM Hammer exited, but TunIQ did not parse an explicit verification-pass result. Re-read properties and read back before treating the hardware as verified.';
      }
      this.appendActivity(`flash-${session.operation}-${session.state}`, {
        projectId: session.projectId, projectName: session.projectName,
        input: session.input ? path.basename(session.input) : null,
        output: session.output ? path.basename(session.output) : null,
        exitCode: code, stopCode: session.stopCode, sessionLog,
        integratedProfileId: session.integratedProfileId || profile?.id || '', portLeaseId: portLease.leaseId
      });
      try { await this.onSessionComplete({ ...session, child: undefined }); }
      catch (error) { session.sessionCompletionWarning = error.message; }
      session.finalized = true;
      this.recordHistory(session);
      this.setPortOwner('idle', { port: session.device });
      emit();
      this.session = null;
    };

    const launchProfile = index => {
      const profile = profiles[index];
      if (!profile?.templates?.[preflight.operation]) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('integrated-profile-unresolved', `No integrated PCM Hammer command profile exists for ${OPERATIONS[preflight.operation].label}.`);
      }
      const template = profile.templates[preflight.operation];
      const args = [...preflight.resolved.prefixArgs, ...expandTemplate(template, preflight.values)];
      session.args = args;
      session.currentProfileId = profile.id;
      session.currentProfileLabel = profile.label;
      session.profileIndex = index;
      session.phase = profiles.length > 1 ? `Discovering PCM Hammer command profile ${index + 1} of ${profiles.length}` : `Running integrated PCM Hammer ${OPERATIONS[preflight.operation].label}`;
      const attemptStart = session.log.length;
      let child;
      try { child = spawn(preflight.resolved.executable, args, { windowsHide: true, cwd: preflight.active.folder }); }
      catch (error) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('cli-launch-failed', `PCM Hammer CLI could not start: ${error.message}`);
      }
      session.child = child;
      child.stdout?.on('data', chunk => append('stdout', chunk));
      child.stderr?.on('data', chunk => append('stderr', chunk));
      child.on('error', async error => {
        session.state = 'failed'; session.error = error.message;
        session.stopCode = /denied|busy|in use/i.test(error.message) ? 'adapter-locked' : 'cli-process-error';
        session.finishedAt = new Date().toISOString();
        this.setPortOwner('idle', { port: session.device });
        try { await this.onSessionComplete({ ...session, child: undefined }); } catch {}
        session.finalized = true; this.recordHistory(session); emit(); this.session = null;
      });
      child.on('close', async code => {
        if (session.finalized) return;
        const attemptEntries = session.log.slice(attemptStart);
        const attemptText = attemptEntries.map(item => item.text).join('\n');
        const retryable = safeToRetryProfile({ operation: session.operation, text: attemptText, exitCode: code, output: session.output });
        session.profileAttempts.push({
          profileId: profile.id, label: profile.label, args,
          exitCode: code, syntaxFailure: retryable,
          communicationStarted: hasCommunicationActivity(attemptText),
          at: new Date().toISOString(), excerpt: clean(attemptText, 1200)
        });
        if (!session.cancelRequested && retryable && index + 1 < profiles.length) {
          append('integration', `Command profile ${profile.id} was rejected before any PCM communication. Retrying safely with ${profiles[index + 1].id}.\n`);
          await sleep(80);
          launchProfile(index + 1);
          return;
        }
        await finalize(code, attemptText, profile);
      });
      emit();
    };

    this.appendActivity(`flash-${session.operation}-started`, {
      projectId: session.projectId, projectName: session.projectName,
      device: session.device, voltage: session.voltage,
      releasedTunIQPort: portLease.released, directPortLease: true, portLeaseId: portLease.leaseId
    });
    launchProfile(0);
    emit();
    return { ...session, child: undefined };
  }

  async cancel() {
    if (!this.session?.child) return this.status();
    const session = this.session;
    if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && /eras|writ|program|verif/i.test(session.phase || '')) {
      session.cancelBlocked = true; session.phase = 'Cancellation blocked during critical flash phase';
      session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'TunIQ will not terminate PCM Hammer during erase/write/verify. Maintain power and allow it to finish.' });
      this.emit('flash:progress', { ...session, child: undefined }); return this.status();
    }
    session.cancelRequested = true; session.phase = 'Safe cancellation requested';
    try {
      if (process.platform === 'win32' && session.child.pid) spawn('taskkill.exe', ['/PID', String(session.child.pid), '/T', '/F'], { windowsHide: true });
      else session.child.kill('SIGTERM');
    } catch {}
    return this.status();
  }

  prepareAssisted(operation, payload = {}, reason = null) {
    const normalizedOperation = normalizeOperation(operation);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const folder = this.assistedFolder(active);
    const state = {
      type: 'pcmhammer-assisted-operation', version: 1, projectId: active.id, projectName: active.name,
      operation: normalizedOperation, status: 'waiting-for-evidence', folder,
      input: payload.input || null, device: payload.device || this.getConfig().device || this.getDeviceStatus()?.connection?.port || '',
      reason: reason ? clean(reason.message || reason, 2000) : 'CLI automation is unavailable for this step.',
      instructions: assistedInstructions(normalizedOperation, folder),
      knownFiles: fs.readdirSync(folder).map(name => fileFingerprint(path.join(folder, name))),
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    writeJson(this.assistedStateFile(active), state);
    return state;
  }

  async launchAssisted(operation, payload = {}, reason = null) {
    const state = this.prepareAssisted(operation, payload, reason);
    const gui = this.resolveGuiExecutable();
    if (state.device) {
      await this.releasePort({ port: state.device, operation: state.operation });
      await sleep(100);
      const lock = await this.probePortLock({ port: state.device, operation: state.operation });
      if (lock?.locked || lock?.available === false) {
        state.status = 'blocked'; state.stopCode = 'adapter-locked'; state.stopMessage = `${state.device} is still locked. Close the program using it before opening PCM Hammer.`;
        writeJson(this.assistedStateFile(), state); return state;
      }
    }
    if (gui) {
      try { const child = spawn(gui, [], { detached: true, windowsHide: false, cwd: path.dirname(gui), stdio: 'ignore' }); child.unref(); state.guiExecutable = gui; state.guiLaunchedAt = new Date().toISOString(); }
      catch (error) { state.launchWarning = error.message; }
    } else state.launchWarning = 'The normal PcmHammer.exe was not found. Open it manually.';
    state.updatedAt = new Date().toISOString(); writeJson(this.assistedStateFile(), state);
    this.watchAssisted(state);
    this.appendActivity('pcmhammer-assisted-started', { projectId: state.projectId, operation: state.operation, folder: state.folder, reason: state.reason });
    return state;
  }

  watchAssisted(state) {
    if (!state?.folder || this.assistedWatchers.has(state.projectId)) return;
    let timer = null;
    try {
      const watcher = fs.watch(state.folder, () => {
        clearTimeout(timer); timer = setTimeout(() => this.scanAssisted().catch(() => {}), 350);
      });
      watcher.on('error', () => {});
      this.assistedWatchers.set(state.projectId, watcher);
    } catch {}
  }
  stopAssistedWatcher(projectId) {
    const watcher = this.assistedWatchers.get(projectId); if (watcher) { try { watcher.close(); } catch {} this.assistedWatchers.delete(projectId); }
  }

  async importAssistedEvidence(files = [], payload = {}) {
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const state = readJson(this.assistedStateFile(active), null) || this.prepareAssisted(payload.operation || 'readProperties', payload);
    const candidates = uniqueFiles(files).filter(file => fs.existsSync(file) && fs.statSync(file).isFile());
    if (!candidates.length) return { ...state, imported: [] };
    const imported = []; const logs = [];
    for (const file of candidates) {
      const ext = path.extname(file).toLowerCase();
      if (ext === '.bin') {
        const validation = validateP01ReadFile(file, { success: true });
        if (!validation.valid) { imported.push({ file, type: 'read', accepted: false, code: validation.code, message: validation.message }); continue; }
        const session = { id: `${Date.now()}-assisted-read`, operation: 'read', state: 'complete', device: state.device, proofSource: 'PCM Hammer WinForms assisted full read', result: { success: true }, assisted: true };
        try { await this.onReadComplete(file, validation, session); await this.onSessionComplete(session); imported.push({ file, type: 'read', accepted: true, sha256: validation.sha256, size: validation.size }); }
        catch (error) { imported.push({ file, type: 'read', accepted: false, code: 'read-import-failed', message: error.message }); }
      } else if (['.txt', '.log'].includes(ext)) logs.push({ file, text: fs.readFileSync(file, 'utf8') });
    }
    for (const log of logs) {
      const identity = parseIdentityText(log.text);
      const usefulIdentity = identity.os || identity.hardwareId || identity.serviceNumber || identity.controller;
      if (usefulIdentity) {
        const session = { id: `${Date.now()}-assisted-properties`, operation: 'readProperties', state: 'complete', device: state.device, proofSource: log.file, source: 'PCM Hammer WinForms Read Properties', assisted: true };
        try { await this.onIdentifyComplete(identity, session); await this.onSessionComplete(session); imported.push({ file: log.file, type: 'read-properties', accepted: true, identity }); }
        catch (error) { imported.push({ file: log.file, type: 'read-properties', accepted: false, code: 'identity-import-failed', message: error.message }); }
      }
      const testResult = classifyPcmHammerResult('testWrite', log.text, 0);
      if (testResult.testWritePassed && state.input && fs.existsSync(state.input)) {
        const session = { id: `${Date.now()}-assisted-test-write`, operation: 'testWrite', input: state.input, state: 'complete', testWritePassed: true, verified: true, device: state.device, proofSource: log.file, sessionLog: log.file, result: testResult, assisted: true };
        try { await this.onSessionComplete(session); imported.push({ file: log.file, type: 'test-write', accepted: true, input: state.input }); }
        catch (error) { imported.push({ file: log.file, type: 'test-write', accepted: false, code: 'test-write-import-failed', message: error.message }); }
      }
    }
    const accepted = imported.filter(item => item.accepted);
    state.imported = [...(state.imported || []), ...accepted.map(item => ({ ...item, importedAt: new Date().toISOString() }))].slice(-50);
    state.knownFiles = [...new Set([...(state.knownFiles || []), ...candidates.map(fileFingerprint)])];
    state.updatedAt = new Date().toISOString();
    if (accepted.length) state.status = 'evidence-imported';
    writeJson(this.assistedStateFile(active), state);
    return { ...state, imported };
  }

  async scanAssisted() {
    const active = this.getActiveProject();
    if (!active) return null;
    const state = readJson(this.assistedStateFile(active), null);
    if (!state?.folder || !fs.existsSync(state.folder)) return state;
    const known = new Set(state.knownFiles || []);
    const files = fs.readdirSync(state.folder).map(name => path.join(state.folder, name)).filter(file => {
      try { return fs.statSync(file).isFile() && !known.has(fileFingerprint(file)); } catch { return false; }
    });
    if (!files.length) { this.watchAssisted(state); return { ...state, imported: [] }; }
    return this.importAssistedEvidence(files, { operation: state.operation, input: state.input });
  }
}

module.exports = {
  FlashManager, FlashStopError, inferTemplates, expandTemplate, parseProgress, parseIdentityText,
  parseBackendIdentity, classifyPcmHammerResult, validateP01ReadFile, normalizeOperation, P01_BIN_SIZE
};
