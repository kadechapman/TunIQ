const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { classifyPcmHammerResult } = require('./pcmhammer');

const P01_BIN_SIZE = 512 * 1024;
const COMMISSIONING_VERSION = 3;

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function clean(value, max = 200) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max); }
function normalizeController(value) { return clean(value, 40).toUpperCase().replace(/\s+/g, ''); }
function osCandidates(text) { return [...new Set((String(text || '').match(/\b\d{7,9}\b/g) || []))]; }
function identityFingerprint(identity = {}) {
  return crypto.createHash('sha256').update(JSON.stringify({
    controller: normalizeController(identity.controller),
    os: clean(identity.os, 20),
    hardwareId: clean(identity.hardwareId, 80),
    serviceNumber: clean(identity.serviceNumber, 40)
  })).digest('hex');
}
function fileInfo(file) {
  if (!file || !fs.existsSync(file)) return null;
  const stat = fs.statSync(file);
  if (!stat.isFile()) return null;
  return { path: file, name: path.basename(file), size: stat.size, sha256: sha256(file), modifiedAt: stat.mtime.toISOString() };
}
function uniqueReads(reads = []) {
  const seen = new Set();
  return reads.filter(item => {
    const key = `${item.sessionId || item.path || item.id}:${item.sha256}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}
function bestReadGroup(reads = []) {
  const groups = new Map();
  for (const read of reads) {
    const list = groups.get(read.sha256) || [];
    list.push(read); groups.set(read.sha256, list);
  }
  return [...groups.entries()].sort((a, b) => b[1].length - a[1].length || String(a[0]).localeCompare(String(b[0])))[0] || [null, []];
}

class P01CommissioningManager {
  constructor(options) {
    this.getActiveProject = options.getActiveProject;
    this.getCalibrationWorkspace = options.getCalibrationWorkspace || (() => null);
    this.getFlashStatus = options.getFlashStatus || (() => null);
    this.appendActivity = options.appendActivity || (() => {});
  }

  file(active = this.getActiveProject()) {
    if (!active?.folder) return null;
    return path.join(active.folder, 'Reports', 'p01-commissioning.json');
  }

  load(active = this.getActiveProject()) {
    const file = this.file(active);
    const existing = file ? readJson(file, null) : null;
    if (existing && existing.projectId === active?.id) {
      return { version: COMMISSIONING_VERSION, reads: [], validations: [], testWrites: [], writes: [], readPair: null, ...existing };
    }
    return {
      type: 'p01-commissioning', version: COMMISSIONING_VERSION, projectId: active?.id || null,
      projectName: active?.name || '', identity: null, reads: [], validations: [], testWrites: [], writes: [], readPair: null,
      definitionConfirmation: null, goalMap: null,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
  }

  save(state, active = this.getActiveProject()) {
    if (!active?.folder) throw new Error('Create or activate a project first.');
    const next = { ...state, version: COMMISSIONING_VERSION, projectId: active.id, projectName: active.name, updatedAt: new Date().toISOString() };
    writeJson(this.file(active), next);
    return next;
  }

  isP01(active = this.getActiveProject(), state = this.load(active)) {
    return normalizeController(active?.controller || state?.identity?.controller) === 'P01';
  }

  recordIdentity(identity = {}, session = null) {
    const active = this.getActiveProject();
    if (!active) return null;
    const normalized = {
      controller: normalizeController(identity.controller), os: clean(identity.os, 20),
      hardwareId: clean(identity.hardwareId, 80), serviceNumber: clean(identity.serviceNumber, 40), vin: clean(identity.vin, 24), voltage: Number.isFinite(Number(identity.voltage)) ? Number(identity.voltage) : null,
      description: clean(identity.description, 200),
      fingerprint: identityFingerprint(identity), identifiedAt: new Date().toISOString(),
      device: clean(session?.device, 120), sessionId: session?.id || null,
      proofSource: clean(session?.proofSource || session?.source || 'PCM Hammer', 300)
    };
    const state = this.load(active);
    const previousFingerprint = state.identity?.fingerprint;
    state.identity = normalized;
    if (previousFingerprint && previousFingerprint !== normalized.fingerprint) {
      state.reads = [];
      state.validations = [];
      state.testWrites = [];
      state.definitionConfirmation = null;
      state.goalMap = null;
      delete state.canonicalReadSha256;
      delete state.canonicalReadPath;
      delete state.dualReadVerifiedAt;
      state.readPair = null;
      state.readMismatch = false;
      state.identityChangedWarning = 'Controller identity changed. Previous read, definition, parameter-map, validation, and Test Write evidence was cleared.';
    }
    this.save(state, active);
    this.appendActivity('p01-identity-recorded', { projectId: active.id, controller: normalized.controller, os: normalized.os, hardwareId: normalized.hardwareId, serviceNumber: normalized.serviceNumber });
    return this.status(active);
  }

  beginFreshReadPair(reason = 'retry') {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const generation = Number(state.readPair?.generation || 0) + 1;
    state.readPair = { generation, status: 'awaiting-first', first: null, second: null, startedAt: new Date().toISOString(), reason: clean(reason, 300) };
    state.readMismatch = false;
    state.readResolution = 'Waiting for the first complete read in a new two-read verification pair.';
    delete state.canonicalReadSha256;
    delete state.canonicalReadPath;
    delete state.dualReadVerifiedAt;
    this.save(state, active);
    return this.status(active);
  }

  recordRead(file, info = {}, session = null) {
    const active = this.getActiveProject();
    if (!active) return null;
    const state = this.load(active);
    if (!this.isP01(active, state)) return null;
    if (!state.identity?.fingerprint || normalizeController(state.identity?.controller) !== 'P01') {
      throw new Error('Read Properties must identify this controller as P01 before a full read can be accepted.');
    }
    const actual = fileInfo(file);
    if (!actual) throw new Error('The completed PCM read file could not be found.');
    if (actual.size !== P01_BIN_SIZE) throw new Error(`Rejected PCM read: expected exactly ${P01_BIN_SIZE} bytes but received ${actual.size} bytes.`);
    const sessionId = clean(session?.id || info.sessionId || `${actual.name}-${actual.modifiedAt}`, 200);
    const record = {
      id: `${Date.now()}-read-${Math.random().toString(16).slice(2, 8)}`, ...actual, validP01Size: true,
      identityFingerprint: state.identity.fingerprint, controller: state.identity.controller,
      os: state.identity.os || clean(active.os, 20), device: clean(session?.device, 120), sessionId,
      proofSource: clean(session?.proofSource || session?.source || info.proofSource || 'PCM Hammer full read', 300), readAt: new Date().toISOString()
    };
    state.reads = uniqueReads([record, ...(Array.isArray(state.reads) ? state.reads : [])]).slice(0, 20);
    let pair = state.readPair;
    if (!pair || !['awaiting-first', 'awaiting-second'].includes(pair.status)) {
      pair = { generation: Number(pair?.generation || 0) + 1, status: 'awaiting-first', first: null, second: null, startedAt: new Date().toISOString() };
    }
    let acceptedAsOriginal = false;
    if (pair.status === 'awaiting-first' || !pair.first) {
      pair.first = record;
      pair.second = null;
      pair.status = 'awaiting-second';
      state.readMismatch = false;
      state.readResolution = 'First complete 524,288-byte read recorded. A second independent full read is required.';
      delete state.canonicalReadSha256;
      delete state.canonicalReadPath;
      delete state.dualReadVerifiedAt;
    } else {
      if (pair.first.sessionId === record.sessionId) throw new Error('The second verification read must come from a separate PCM Hammer session.');
      pair.second = record;
      pair.completedAt = new Date().toISOString();
      if (pair.first.sha256 === record.sha256) {
        pair.status = 'verified';
        state.canonicalReadSha256 = record.sha256;
        state.canonicalReadPath = pair.first.path;
        state.dualReadVerifiedAt = pair.completedAt;
        state.readMismatch = false;
        state.readResolution = 'Two independent complete 524,288-byte reads have matching SHA-256 hashes.';
        acceptedAsOriginal = true;
      } else {
        pair.status = 'mismatch';
        state.readMismatch = true;
        state.readResolution = `Read mismatch: ${pair.first.sha256.slice(0, 16)}… does not match ${record.sha256.slice(0, 16)}…. Both files were preserved; start a fresh two-read pair after correcting power/connection issues.`;
        delete state.canonicalReadSha256;
        delete state.canonicalReadPath;
        delete state.dualReadVerifiedAt;
      }
    }
    state.readPair = pair;
    this.save(state, active);
    this.appendActivity('p01-read-recorded', { projectId: active.id, file: record.name, size: record.size, sha256: record.sha256, pairGeneration: pair.generation, pairStatus: pair.status, mismatch: state.readMismatch });
    return { status: this.status(active), canonicalPath: state.canonicalReadPath || null, acceptedAsOriginal, pairStatus: pair.status };
  }

  confirmDefinition({ typedOs = '', acknowledged = false } = {}) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const definition = this.definition(active, state, true);
    const expected = String(state.identity?.os || active.os || '');
    if (!expected) throw new Error('Identify the P01 operating system first.');
    if (String(typedOs).trim() !== expected) throw new Error(`Type the exact identified OS ${expected} to bind this XDF.`);
    if (!acknowledged) throw new Error('Confirm that this XDF was obtained for the exact identified operating system.');
    if (!definition.file || !definition.sha256) throw new Error('Import and load an XDF before confirming it.');
    if (!definition.mappingLoaded) throw new Error('Load the protected original and XDF in Calibration before confirming the definition.');
    if (definition.warnings?.length) throw new Error(`Resolve XDF mapping warnings before confirmation:\n• ${definition.warnings.slice(0, 8).join('\n• ')}`);
    state.definitionConfirmation = { os: expected, xdfSha256: definition.sha256, sourceBinSha256: state.canonicalReadSha256, confirmedAt: new Date().toISOString(), method: 'typed-os-and-clean-mapping' };
    state.goalMap = null;
    this.save(state, active);
    this.appendActivity('p01-definition-confirmed', { projectId: active.id, os: expected, xdfSha256: definition.sha256 });
    return this.status(active);
  }

  confirmGoalMap(proposal, actionIds = [], proposalIds = []) {
    const active = this.getActiveProject();
    if (!active || !proposal) throw new Error('Build an AI action sheet first.');
    const state = this.load(active);
    const definition = this.definition(active, state);
    if (!definition.confirmedExact) throw new Error('Confirm the exact-OS XDF before commissioning AI parameters.');
    const selected = new Set((actionIds || []).map(String));
    const selectedProposals = new Set((proposalIds || []).map(String));
    if (!selected.size) throw new Error('Choose at least one action to commission.');
    const actions = {};
    for (const action of proposal.actions || []) {
      if (!selected.has(String(action.id))) continue;
      const actionProposals = (action.proposals || []).filter(item => !selectedProposals.size || selectedProposals.has(String(item.id)));
      const cells = actionProposals.map(item => {
        const text = `${item.id} ${item.tableName} ${item.rowLabel} ${item.colLabel}`;
        let role = /restore|resume/i.test(text) ? 'restore' : 'target';
        if (action.type === 'ghost-cam') {
          if (/spark/i.test(text)) role = 'idle-spark';
          else if (/airflow|air flow|running air/i.test(text)) role = 'idle-airflow';
          else if (/desired.*idle|idle.*speed|idle.*rpm/i.test(text)) role = 'idle-speed';
        }
        return { tableKey: item.tableKey, row: Number(item.row), col: Number(item.col), role,
          tableName: item.tableName, rowLabel: item.rowLabel, colLabel: item.colLabel, currentAtConfirmation: item.current };
      });
      if (!cells.length) throw new Error(`${action.label} has no exact mapped cells to commission.`);
      actions[action.type] = { actionId: action.id, label: action.label, cells, confirmedAt: new Date().toISOString() };
    }
    if (!Object.keys(actions).length) throw new Error('The selected actions did not contain commissionable exact cells.');
    state.goalMap = {
      os: String(state.identity?.os || active.os || ''), xdfSha256: definition.sha256, sourceBinSha256: state.canonicalReadSha256,
      actions: { ...(state.goalMap?.actions || {}), ...actions }, confirmedAt: new Date().toISOString(), sourceProposalId: proposal.id
    };
    this.save(state, active);
    this.appendActivity('p01-ai-parameter-map-confirmed', { projectId: active.id, os: state.goalMap.os, actionTypes: Object.keys(actions) });
    return this.status(active);
  }

  parameterMap(active = this.getActiveProject(), state = this.load(active)) {
    const definition = this.definition(active, state);
    const map = state.goalMap;
    if (!map || map.os !== String(state.identity?.os || active?.os || '') || map.xdfSha256 !== definition.sha256 || map.sourceBinSha256 !== state.canonicalReadSha256) return null;
    return map;
  }

  assertGoalProposalMapped(proposal, approvedIds = []) {
    const active = this.getActiveProject();
    if (!this.isP01(active)) return true;
    const status = this.assertAiReady();
    const map = status.parameterMap;
    if (!map) throw new Error('Confirm the P01 AI parameter map for this exact OS/XDF before applying requested changes.');
    const approved = new Set((approvedIds || []).map(String));
    const approvedItems = (proposal?.proposals || []).filter(item => approved.has(String(item.id)));
    if (!approvedItems.length) throw new Error('Approve at least one exact requested change.');
    for (const item of approvedItems) {
      const mapped = map.actions?.[item.actionType]?.cells || [];
      if (!mapped.some(cell => cell.tableKey === item.tableKey && Number(cell.row) === Number(item.row) && Number(cell.col) === Number(item.col))) {
        throw new Error(`${item.tableName} · ${item.rowLabel}/${item.colLabel} is not in the commissioned P01 parameter map. Rebuild and confirm the map first.`);
      }
    }
    return true;
  }

  recordValidation(report) {
    const active = this.getActiveProject();
    if (!active || !report) return null;
    const state = this.load(active);
    state.validations = [{
      targetFile: report.targetFile, targetFileName: report.targetFileName, targetFileSha256: report.targetFileSha256,
      compatible: report.compatible !== false, checksumStatus: report.checksumStatus, validatedAt: report.validatedAt || new Date().toISOString()
    }, ...(Array.isArray(state.validations) ? state.validations : []).filter(item => item.targetFileSha256 !== report.targetFileSha256)].slice(0, 30);
    this.save(state, active);
    return this.status(active);
  }

  recordManualTestWrite(input, proofText = '', source = '') {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const info = fileInfo(input);
    if (!info || info.size !== P01_BIN_SIZE) throw new Error('Select the exact 512 KB P01 revision used for Test Write.');
    const text = String(proofText || '');
    const result = classifyPcmHammerResult('testWrite', text, 0);
    if (!result.success || !result.testWritePassed) throw new Error(`The selected log does not prove a successful PCM Hammer Test Write (${result.stopCode || 'result-not-proven'}).`);
    state.testWrites = [{ ...info, identityFingerprint: state.identity?.fingerprint || '', device: 'Imported PCM Hammer proof', completedAt: new Date().toISOString(), sessionId: `manual-${Date.now()}`, proofSource: clean(source, 300) }, ...(state.testWrites || []).filter(item => item.sha256 !== info.sha256)].slice(0, 20);
    this.save(state, active);
    this.appendActivity('p01-testwrite-proof-imported', { projectId: active.id, revision: info.name, sha256: info.sha256, source: clean(source, 300) });
    return this.status(active, input);
  }

  recordFlashSession(session) {
    const active = this.getActiveProject();
    if (!active || !session || !this.isP01(active)) return null;
    const state = this.load(active);
    if (session.operation === 'testWrite' && session.input && session.state === 'complete' && session.testWritePassed === true && session.result?.success !== false) {
      const info = fileInfo(session.input);
      if (info) state.testWrites = [{ ...info, identityFingerprint: state.identity?.fingerprint || '', device: clean(session.device, 120), voltage: session.voltage ?? null, completedAt: session.finishedAt || new Date().toISOString(), sessionId: session.id, backendSha256: session.backendSha256 || '' }, ...(state.testWrites || []).filter(item => item.sha256 !== info.sha256)].slice(0, 20);
    }
    if (['writeCalibration','writeFull'].includes(session.operation)) {
      const info = fileInfo(session.input);
      state.writes = [{ operation: session.operation, state: session.state, verified: Boolean(session.verified), ...(info || {}), identityFingerprint: state.identity?.fingerprint || '', completedAt: session.finishedAt || new Date().toISOString(), sessionId: session.id }, ...(state.writes || [])].slice(0, 20);
    }
    this.save(state, active);
    return this.status(active);
  }

  definition(active, state, ignoreConfirmation = false) {
    const xdfInfo = active?.xdfInfo || {};
    const metadataText = `${xdfInfo.title || ''} ${xdfInfo.description || ''}`;
    const nameText = `${xdfInfo.name || ''}`;
    const declaredMetadata = osCandidates(metadataText);
    const declaredName = osCandidates(nameText);
    const declared = [...new Set([...declaredMetadata, ...declaredName])];
    const projectOs = clean(state?.identity?.os || active?.os, 20);
    const metadataExact = Boolean(projectOs && declaredMetadata.includes(projectOs));
    const filenameExact = Boolean(projectOs && declaredName.includes(projectOs));
    let xdfHash = '';
    try { if (active?.xdf && fs.existsSync(active.xdf)) xdfHash = sha256(active.xdf); } catch {}
    let workspace = null;
    try { workspace = this.getCalibrationWorkspace(); } catch {}
    const mappingLoaded = Boolean(workspace?.mode === 'xdf' && workspace.projectId === active?.id && workspace.sourceXdfSha256 === xdfHash && workspace.sourceBinSha256 === state.canonicalReadSha256);
    const warnings = [...(xdfInfo.warnings || workspace?.mappingSummary?.warnings || [])].filter(Boolean);
    const confirmation = state.definitionConfirmation;
    const confirmedExact = !ignoreConfirmation && Boolean(confirmation && confirmation.os === projectOs && confirmation.xdfSha256 === xdfHash && confirmation.sourceBinSha256 === state.canonicalReadSha256 && mappingLoaded && warnings.length === 0);
    return {
      file: active?.xdf || null, name: xdfInfo.name || '', title: xdfInfo.title || '', sha256: xdfHash,
      declaredOs: declared, metadataExact, filenameExact, projectOs, exactOs: metadataExact || filenameExact, confirmedExact, confirmation: confirmation || null, mappingLoaded,
      tableCount: Number(xdfInfo.tableCount || workspace?.mappingSummary?.loaded || 0), warnings
    };
  }

  status(active = this.getActiveProject(), input = null) {
    if (!active) return { applicable: false, readyForAi: false, readyForWrite: false, blockers: ['Create or activate a project first.'], steps: [] };
    const state = this.load(active);
    const applicable = this.isP01(active, state);
    if (!applicable) return { applicable: false, projectId: active.id, controller: active.controller || '', readyForAi: true, readyForWrite: true, blockers: [], steps: [] };
    const identity = state.identity || {};
    const pair = state.readPair || null;
    const pairReads = [pair?.first, pair?.second].filter(Boolean);
    const validReads = pairReads.filter(item => item.validP01Size && item.size === P01_BIN_SIZE && item.identityFingerprint === identity.fingerprint);
    const dualRead = Boolean(pair?.status === 'verified' && validReads.length === 2 && validReads[0].sha256 === validReads[1].sha256 && state.canonicalReadSha256 === validReads[0].sha256);
    const original = fileInfo(active.bin);
    const originalMatches = Boolean(original && state.canonicalReadSha256 && original.sha256 === state.canonicalReadSha256 && original.size === P01_BIN_SIZE);
    const definition = this.definition(active, state);
    const selected = fileInfo(input);
    const validation = selected ? (state.validations || []).find(item => item.targetFileSha256 === selected.sha256 && item.compatible && ['valid','valid-external'].includes(item.checksumStatus)) : null;
    const testWrite = selected ? (state.testWrites || []).find(item => item.sha256 === selected.sha256 && item.identityFingerprint === identity.fingerprint) : null;
    const parameterMap = this.parameterMap(active, state);
    const flash = this.getFlashStatus?.() || {};
    const backend = flash.backend || {};
    const backendReady = Boolean((flash.configured && backend.official && Number(backend.major || 0) >= 2) || flash.assistedAvailable);
    const blockers = [];
    if (normalizeController(identity.controller) !== 'P01') blockers.push('Run PCM Hammer Read Properties and confirm it reports P01.');
    if (!identity.os) blockers.push('PCM Hammer Read Properties did not report an operating-system number.');
    if (!identity.hardwareId) blockers.push('PCM Hammer Read Properties did not report a hardware ID.');
    if (!identity.serviceNumber) blockers.push('PCM Hammer Read Properties did not report a service number. Import the Read Properties log if the CLI omitted it.');
    if (active.os && identity.os && String(active.os) !== String(identity.os)) blockers.push(`Project OS ${active.os} does not match identified PCM OS ${identity.os}.`);
    if (!dualRead) blockers.push(state.readMismatch ? 'The two complete P01 reads do not match. Correct the connection or power issue, then start a fresh two-read verification pair.' : 'Complete two independent 524,288-byte P01 reads with matching SHA-256 hashes.');
    if (!originalMatches) blockers.push('The protected original must be the verified matching P01 read.');
    if (!definition.exactOs) blockers.push(definition.declaredOs.length ? `The XDF declares OS ${definition.declaredOs.join(', ')}, not identified OS ${identity.os || active.os || 'unknown'}.` : 'The XDF metadata or filename must declare the exact identified OS.');
    if (!definition.mappingLoaded) blockers.push('Load the verified original and exact-OS XDF in Calibration after dual-read verification.');
    if (!definition.confirmedExact) blockers.push('Confirm the exact OS/XDF binding after reviewing a clean mapping with no address warnings.');
    const aiBlockers = [...blockers];
    const writeBlockers = [...blockers];
    if (!backendReady) writeBlockers.push('Configure the official PCM Hammer 2.x CLI or use Assisted PCM Hammer before Test Write or Calibration Write.');
    if (selected) {
      if (selected.size !== P01_BIN_SIZE) writeBlockers.push(`Selected revision is ${selected.size} bytes; a P01 image must be ${P01_BIN_SIZE} bytes.`);
      if (!validation) writeBlockers.push('Analyze this exact revision and obtain a valid checksum/layout report.');
      if (!testWrite) writeBlockers.push('Run a successful Test Write on this exact revision and PCM identity.');
    } else writeBlockers.push('Select the exact revision that will be tested or written.');
    const steps = [
      { id: 'identity', title: 'Read P01 properties', complete: normalizeController(identity.controller) === 'P01' && Boolean(identity.os) && Boolean(identity.hardwareId) && Boolean(identity.serviceNumber), detail: identity.os ? `P01 · OS ${identity.os} · HW ${identity.hardwareId || 'missing'} · Service ${identity.serviceNumber || 'missing'}` : 'Use Read Properties or import its saved Results log.' },
      { id: 'read1', title: 'Complete first full read', complete: validReads.length >= 1, detail: validReads[0]?.sha256 ? `${validReads[0].name} · ${validReads[0].sha256.slice(0, 16)}…` : 'A P01 full read must be exactly 512 KB.' },
      { id: 'read2', title: 'Complete second matching read', complete: dualRead, error: Boolean(state.readMismatch), detail: dualRead ? 'Two independent complete reads match exactly.' : state.readMismatch ? 'Mismatch stopped the workflow. Start a fresh pair after correcting the cause.' : 'Read the PCM again without changing power or connection.' },
      { id: 'backend', title: 'Verify PCM Hammer path', complete: backendReady, detail: backendReady ? `${backend.product || 'PCM Hammer'} ${backend.version || '2.x'} · ${String(backend.sha256 || '').slice(0, 12)}…` : 'Use the official PCM Hammer 2.x CLI or Assisted PCM Hammer.' },
      { id: 'definition', title: 'Bind exact OS definition', complete: definition.confirmedExact, detail: definition.confirmedExact ? `${definition.name} is bound to OS ${definition.projectOs}.` : definition.mappingLoaded ? 'Review the mapping and type the identified OS to confirm it.' : 'Use an XDF for the exact OS and load it in Calibration.' },
      { id: 'validation', title: 'Validate selected revision', complete: Boolean(validation), detail: validation ? `${selected.name} · ${validation.checksumStatus}` : 'Create a revision, then analyze that exact file.' },
      { id: 'testwrite', title: 'Pass Test Write', complete: Boolean(testWrite), detail: testWrite ? `Passed for ${selected.name}` : 'Test Write must pass on the exact revision before Calibration Write.' }
    ];
    return {
      applicable: true, projectId: active.id, projectName: active.name, expectedBinSize: P01_BIN_SIZE,
      identity, reads: state.reads || [], readPair: pair, dualReadVerified: dualRead, readMismatch: Boolean(state.readMismatch), readResolution: state.readResolution || '', canonicalReadSha256: state.canonicalReadSha256 || '',
      original, originalMatches, definition, parameterMap, backend, backendReady, selectedRevision: selected, validation: validation || null, testWrite: testWrite || null,
      readyForAi: aiBlockers.length === 0, readyForTestWrite: writeBlockers.filter(item => !item.startsWith('Run a successful Test Write')).length === 0,
      readyForWrite: writeBlockers.length === 0, blockers, aiBlockers, writeBlockers, steps, stateFile: this.file(active)
    };
  }

  assertAiReady() {
    const active = this.getActiveProject();
    if (!this.isP01(active)) return this.status(active);
    const status = this.status(active);
    if (!status.readyForAi) throw new Error(`P01 commissioning is incomplete:\n• ${status.aiBlockers.join('\n• ')}`);
    return status;
  }

  assertOperationReady(operation, input) {
    const active = this.getActiveProject();
    if (!this.isP01(active) || !['testWrite','writeCalibration','writeFull'].includes(operation)) return this.status(active, input);
    const status = this.status(active, input);
    const blockers = operation === 'testWrite' ? status.writeBlockers.filter(item => !item.startsWith('Run a successful Test Write')) : status.writeBlockers;
    if (blockers.length) throw new Error(`P01 ${operation === 'testWrite' ? 'Test Write' : 'write'} is locked:\n• ${blockers.join('\n• ')}`);
    return status;
  }

  reset() {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const file = this.file(active);
    if (file && fs.existsSync(file)) fs.renameSync(file, `${file}.${Date.now()}.reset.json`);
    this.appendActivity('p01-commissioning-reset', { projectId: active.id, projectName: active.name });
    return this.status(active);
  }
}

module.exports = { P01CommissioningManager, P01_BIN_SIZE, identityFingerprint, osCandidates, fileInfo };
