# TunIQ v1.7.0-beta.17 — Integrated PCM Hammer Pipeline

TunIQ beta.17 removes the normal PCM Hammer window from the Guided Automatic P01 workflow. Read Properties, both full reads, Test Write, and controlled writes now run through one internal TunIQ coordinator.

## Main changes

- TunIQ closes its own OBD bridge and grants PCM Hammer one direct COM-port lease.
- No separate lock-probe process opens the adapter before PCM Hammer.
- PCM Hammer stdout, stderr, progress, voltage, identity, read results, Test Write proof, and write verification stay inside TunIQ.
- Blank or incomplete CLI help output no longer forces an assisted workflow.
- TunIQ safely discovers the installed PCM Hammer 2.x CLI argument profile during non-destructive Read Properties or full-read operations and caches the proven profile.
- Command-profile retries stop immediately if PCM communication begins or an output file is created.
- Two independent 524,288-byte P01 reads are imported automatically and still must have matching SHA-256 hashes.
- Old beta.15/beta.16 assisted states migrate to an integrated resumable step.
- Normal PCM Hammer and manual evidence import remain available only as advanced emergency tools; Guided Setup does not require them.
- TunIQ's internal checksum, workspace, AI tuning, revision, and Flash Center systems remain project-scoped.

## Run from source

1. Extract the source ZIP.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Reopen the existing Customline P01 project.
4. Press **Retry Integrated PCM Hammer** or **Resume Failed Step**.
5. Keep stable vehicle or bench power during reads, Test Write, and any explicitly authorized write.

The final PCM write still requires explicit confirmation. Real Windows hardware validation remains required.
