#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const scenario = process.env.PCMHAMMER_MOCK_SCENARIO || 'success';
const profile = process.env.PCMHAMMER_MOCK_PROFILE || 'long-port';
const helpMode = process.env.PCMHAMMER_MOCK_HELP_MODE || 'normal';
const readByte = Number(process.env.PCMHAMMER_MOCK_READ_BYTE || 0x5a) & 0xff;
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));

function option(...names) {
  for (const name of names) {
    const index = args.indexOf(name);
    if (index >= 0 && args[index + 1]) return args[index + 1];
  }
  return '';
}
function commandInfo() {
  const first = args[0] || '';
  const flagMap = {
    '--read-properties': 'read-properties', '--read-full': 'read-full', '--test-write': 'test-write',
    '--write-calibration': 'write-calibration', '--write-full': 'write-full', '--recovery': 'recovery'
  };
  return { command: flagMap[first] || first, flagStyle: Boolean(flagMap[first]) };
}
function expectedPortOption() {
  return ({ 'long-port': '--port', 'long-device': '--device', 'long-interface': '--interface', short: '-p', flags: '--port', positional: '', 'reject-all': '--never' })[profile] ?? '--port';
}
function syntaxAccepted(command, flagStyle) {
  if (profile === 'flags' && !flagStyle) return false;
  if (profile !== 'flags' && flagStyle) return false;
  const portOpt = expectedPortOption();
  if (profile === 'positional') return Boolean(args[1]) && !args[1].startsWith('-');
  return args.includes(portOpt);
}
function getOutput(command) {
  if (profile === 'positional') return command === 'read-full' ? args[2] || '' : '';
  return option('--output', '-o', '--file', '-f');
}
function getInput(command) {
  if (profile === 'positional') return ['test-write','write-calibration','write-full','recovery'].includes(command) ? args[2] || '' : '';
  return option('--input', '-i');
}
async function lines(values) { for (const value of values) { console.log(value); await delay(4); } }
function help() {
  if (helpMode === 'blank') return;
  if (helpMode === 'error') { console.error('Help unavailable.'); process.exitCode = 2; return; }
  console.log(`PCM Hammer CLI\nVersion: 2.0.0\nUsage:\n  read-properties --port <port>\n  read-full --port <port> --output <file>\n  test-write --port <port> --input <file>\n  write-calibration --port <port> --input <file>\n  write-full --port <port> --input <file>\n  recovery --port <port> --input <file>`);
}

(async () => {
  const { command, flagStyle } = commandInfo();
  if (['--help','-h','help'].includes(command) || !command) return help();
  if (['--version','-v','version'].includes(command)) {
    if (helpMode !== 'blank') console.log('PCM Hammer CLI Version: 2.0.0');
    return;
  }
  if (!syntaxAccepted(command, flagStyle)) {
    const expected = expectedPortOption() || 'positional port';
    console.error(`Unrecognized option or command line form. Expected ${expected}.`);
    process.exitCode = 64;
    return;
  }
  const port = expectedPortOption() ? option(expectedPortOption()) : args[1];
  if (!port) { console.error('Required port argument missing. Usage: PCM Hammer CLI operation port'); process.exitCode = 64; return; }
  if (scenario === 'locked') { console.error(`Access to the port ${port} is denied because another program is using it.`); process.exitCode = 2; return; }
  if (scenario === 'disconnect') { console.error('Adapter was disconnected. Lost communication with device.'); process.exitCode = 3; return; }

  if (command === 'read-properties') {
    await lines(['PCM Hammer','Version: 2.0.0',`Opening serial port ${port}`,'Voltage: 13.4V','VIN: 1GCEC14T01Z123456','OSID: 12212156','Description: P01 Gen III LS PCM, Service No 12200411','Hardware ID: 9386530','Controller: P01','Read Properties completed successfully.']);
    return;
  }
  if (command === 'read-full') {
    const output = getOutput(command);
    if (!output) { console.error('Operation failed: output file missing. Usage: read-full with output.'); process.exitCode = 64; return; }
    fs.mkdirSync(path.dirname(path.resolve(output)), { recursive: true });
    if (scenario === 'block-fail') {
      await lines([`Opening serial port ${port}`,'Reading block 1 of 8','Block 2 failed: timeout','Block 2 failed: timeout','Block 2 failed: timeout','Read operation failed.']);
      process.exitCode = 5; return;
    }
    const size = scenario === 'partial' ? 131072 : 524288;
    fs.writeFileSync(output, Buffer.alloc(size, readByte));
    if (scenario === 'partial') { await lines([`Opening serial port ${port}`,`Saved partial image: ${size} bytes`,'Read operation failed before completion.']); process.exitCode = 6; return; }
    await lines([`Opening serial port ${port}`,'Reading block 1 of 8 (12%)','Reading block 4 of 8 (50%)','Reading block 8 of 8 (100%)',`Saved BIN file: ${output}`,'Read Entire PCM completed successfully.']);
    return;
  }
  if (command === 'test-write') {
    const input = getInput(command);
    if (!input) { console.error('Required input argument missing. Usage: test-write with input.'); process.exitCode = 64; return; }
    if (scenario === 'test-unproven') { console.log('Test Write exited.'); return; }
    await lines([`Opening serial port ${port}`,'Testing erase and write access','Verification passed','Test Write completed successfully. No changes were written.']);
    return;
  }
  if (['write-calibration','write-full','recovery'].includes(command)) {
    const input = getInput(command);
    if (!input) { console.error('Required input argument missing. Usage: write operation with input.'); process.exitCode = 64; return; }
    await lines([`Opening serial port ${port}`,'Erasing flash 20%','Writing flash 65%','Verification passed','Operation completed successfully.']);
    return;
  }
  console.error(`Unknown command: ${command}`); process.exitCode = 7;
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
