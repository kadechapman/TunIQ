const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { normalizeUiPreferences, mergeUiPreferences, rankQuickActions } = require('../src/qol');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-qol-sim-'));
const settingsFile = path.join(root, 'Settings', 'settings.json');
function save(value) { fs.mkdirSync(path.dirname(settingsFile), { recursive: true }); fs.writeFileSync(settingsFile, JSON.stringify(value, null, 2)); }
function load() { return JSON.parse(fs.readFileSync(settingsFile, 'utf8')); }

function scenarioRestartRestore() {
  let settings = { aiMode: 'guided', detailLevel: 'beginner' };
  settings = mergeUiPreferences(settings, { lastPage: 'devices', recentPages: ['devices','dashboard'], sidebarCollapsed: true, tunePathCollapsed: true, scrollPositions: { devices: 864 } });
  save(settings);
  const restarted = load();
  const ui = normalizeUiPreferences(restarted.uiPreferences);
  assert.equal(ui.lastPage, 'devices');
  assert.equal(ui.sidebarCollapsed, true);
  assert.equal(ui.tunePathCollapsed, true);
  assert.equal(ui.scrollPositions.devices, 864);
  return { scenario: 'restart-restore', passed: true, restoredPage: ui.lastPage, restoredScroll: ui.scrollPositions.devices };
}

function scenarioRapidNavigation() {
  let settings = { uiPreferences: normalizeUiPreferences({}) };
  const pages = ['dashboard','workflow','files','devices','scanner','devices'];
  for (let i = 0; i < pages.length; i++) {
    const current = normalizeUiPreferences(settings.uiPreferences);
    const page = pages[i];
    const recent = [page, ...current.recentPages.filter(item => item !== page)].slice(0, 8);
    const scrollPositions = { ...current.scrollPositions, [page]: i * 125 };
    settings = mergeUiPreferences(settings, { lastPage: page, recentPages: recent, scrollPositions });
  }
  const ui = normalizeUiPreferences(settings.uiPreferences);
  assert.equal(ui.lastPage, 'devices');
  assert.deepEqual(ui.recentPages.slice(0, 5), ['devices','scanner','files','workflow','dashboard']);
  assert.equal(ui.scrollPositions.scanner, 500);
  return { scenario: 'rapid-navigation', passed: true, recentPages: ui.recentPages, trackedPages: Object.keys(ui.scrollPositions).length };
}

function scenarioCorruptionAndSearch() {
  const ui = normalizeUiPreferences({ lastPage: '../../flash', recentPages: new Array(30).fill('flash'), scrollPositions: { flash: 99999999, '<script>': 20 }, reduceMotion: 'true' });
  assert.equal(ui.lastPage, 'dashboard');
  assert.equal(ui.recentPages.length, 2);
  assert.equal(ui.scrollPositions.flash, 1000000);
  assert.equal(ui.reduceMotion, false);
  assert.equal(Object.prototype.hasOwnProperty.call(ui.scrollPositions, '<script>'), false);
  const actions = [
    { id: 'project-tahoe', title: 'Tahoe Street Tune', subtitle: 'Switch project · P01', keywords: 'project vehicle 12212156', priority: 95 },
    { id: 'connection-doctor', title: 'Run Connection Doctor', subtitle: 'OBDLink COM port diagnosis', keywords: 'mx bluetooth adapter', priority: 145 },
    { id: 'device-page', title: 'Device Manager', subtitle: 'Tuning', keywords: 'page devices', priority: 60 }
  ];
  assert.equal(rankQuickActions(actions, 'tahoe p01')[0].id, 'project-tahoe');
  assert.equal(rankQuickActions(actions, 'mx com')[0].id, 'connection-doctor');
  return { scenario: 'corruption-and-search', passed: true, sanitizedPage: ui.lastPage, topProjectResult: 'project-tahoe', topDoctorResult: 'connection-doctor' };
}

try {
  const report = { version: '1.7.0-beta.17', softwareSimulationOnly: true, realHardwareVerified: false, scenarios: [scenarioRestartRestore(), scenarioRapidNavigation(), scenarioCorruptionAndSearch()] };
  report.passed = report.scenarios.every(item => item.passed);
  console.log(JSON.stringify(report, null, 2));
} finally {
  fs.rmSync(root, { recursive: true, force: true });
}
