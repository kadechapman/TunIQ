const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { FlashManager } = require('../src/flash');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { P01AutoManager } = require('../src/p01-auto');

const scenario = process.argv[2];
const valid = new Set(['clean-success','lock-disconnect-resume','read-failure-recovery']);
if (!valid.has(scenario)) { console.error(`Usage: node ${path.basename(__filename)} <${[...valid].join('|')}>`); process.exit(2); }
const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-${scenario}-`));
const resultsRoot = path.join(__dirname, '..', 'test-results'); fs.mkdirSync(resultsRoot, { recursive: true });
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) { const start=Date.now(); while(Date.now()-start<timeout){const value=predicate();if(value)return value;await sleep(20)} throw new Error('Timed out waiting for simulated PCM Hammer process.'); }
function folders(project) { for (const sub of ['Originals','Definitions','Revisions','Reports','Imports']) fs.mkdirSync(path.join(project,sub),{recursive:true}); }
function nodeCli() { const exe=path.join(root,'PcmHammerCLI'); try{fs.symlinkSync(process.execPath,exe)}catch{} return {exe,mock:path.join(__dirname,'mock-pcmhammer-cli.js')}; }
function saveSummary(summary) { const file=path.join(resultsRoot,`${scenario}.json`); fs.writeFileSync(file,JSON.stringify(summary,null,2)); console.log(JSON.stringify(summary,null,2)); return file; }

function harness(name='P01 Recovery Bench') {
  const folder=path.join(root,'project'); folders(folder);
  const active={id:`sim-${scenario}`,name,folder,controller:'P01',os:'',bin:null,binInfo:null,xdf:null,xdfInfo:null};
  let workspace=null; const sessions=[]; const events=[]; const port={locked:false,owner:null};
  const p01=new P01CommissioningManager({getActiveProject:()=>active,getCalibrationWorkspace:()=>workspace,getFlashStatus:()=>flash.status(),appendActivity:(type,payload)=>events.push({type,payload})});
  const {exe,mock}=nodeCli();
  const flash=new FlashManager({
    dataRoot:()=>path.join(root,'data'),getActiveProject:()=>active,getToolPath:()=>'',getDeviceStatus:()=>({connection:{port:'COM4',voltage:13.6}}),
    releasePort:async({port:portName})=>({released:true,port:portName,owner:'TunIQ simulation'}),
    probePortLock:async({port:portName})=>({available:!port.locked,locked:port.locked,port:portName,owner:port.owner}),
    appendActivity:(type,payload)=>events.push({type,payload}),emit:()=>{},
    onIdentifyComplete:async(identity,session)=>{ active.os=identity.os||active.os; if(identity.controller)active.controller=identity.controller; p01.recordIdentity(identity,session); },
    onReadComplete:async(file,info,session)=>{ const result=p01.recordRead(file,info,session); if(result.status.dualReadVerified){active.bin=result.canonicalPath;active.binInfo={name:path.basename(active.bin),size:P01_BIN_SIZE,sha256:sha(active.bin)}} },
    onSessionComplete:async session=>{ sessions.push(session); p01.recordFlashSession(session); }
  });
  return {folder,active,p01,flash,sessions,events,port,exe,mock,setWorkspace:value=>{workspace=value}};
}
async function configure(h) { process.env.PCMHAMMER_MOCK_SCENARIO='success'; await h.flash.probe({executable:h.exe,prefixArgs:[h.mock]}); h.flash.saveDevice('COM4'); }
async function run(h,operation,payload={}) { await h.flash.start(operation,payload); await waitFor(()=>!h.flash.session); return h.sessions[h.sessions.length-1]; }
function finishDefinitionAndRevision(h) {
  const xdf=path.join(h.folder,'Definitions','P01_OS_12212156.xdf');
  fs.writeFileSync(xdf,'<XDFHEADER><deftitle>P01 OS 12212156 verified definition</deftitle></XDFHEADER>');
  h.active.xdf=xdf; h.active.xdfInfo={name:path.basename(xdf),title:'P01 OS 12212156 verified definition',tableCount:1,warnings:[]};
  h.setWorkspace({mode:'xdf',projectId:h.active.id,sourceBinSha256:sha(h.active.bin),sourceXdfSha256:sha(xdf),mappingSummary:{loaded:1,warnings:[]},tables:{limit:{name:'Engine Speed Limit',rowHeaders:['Fuel Cut RPM'],colHeaders:['Value'],values:[[5600]]}}});
  h.p01.confirmDefinition({typedOs:'12212156',acknowledged:true});
  const revision=path.join(h.folder,'Revisions','guided-revision.bin'); fs.copyFileSync(h.active.bin,revision); const fd=fs.openSync(revision,'r+'); const byte=Buffer.from([0x7f]); fs.writeSync(fd,byte,0,1,128); fs.closeSync(fd);
  h.p01.recordValidation({targetFile:revision,targetFileName:path.basename(revision),targetFileSha256:sha(revision),compatible:true,checksumStatus:'valid'});
  return revision;
}

async function cleanSuccess() {
  const h=harness(); await configure(h);
  const properties=await run(h,'readProperties'); assert.equal(properties.state,'complete');
  process.env.PCMHAMMER_MOCK_READ_BYTE='61';
  const read1=await run(h,'read'); assert.equal(read1.outputValidation.size,P01_BIN_SIZE); assert.equal(h.p01.status(h.active).dualReadVerified,false);
  const read2=await run(h,'read'); assert.equal(read2.outputValidation.sha256,read1.outputValidation.sha256); assert.equal(h.p01.status(h.active).dualReadVerified,true);
  const revision=finishDefinitionAndRevision(h); assert.equal(h.p01.assertOperationReady('testWrite',revision).readyForTestWrite,true);
  const testWrite=await run(h,'testWrite',{input:revision,voltage:13.6}); assert.equal(testWrite.testWritePassed,true); assert.equal(h.p01.status(h.active,revision).readyForWrite,true);
  return saveSummary({scenario,status:'passed',softwareSimulationOnly:true,properties:{controller:h.p01.status(h.active).identity.controller,osid:h.active.os,hardwareId:h.p01.status(h.active).identity.hardwareId,serviceNumber:h.p01.status(h.active).identity.serviceNumber,voltage:h.p01.status(h.active).identity.voltage},reads:{count:2,size:P01_BIN_SIZE,sha256:h.p01.status(h.active).canonicalReadSha256,matching:true},testWrite:{passed:true,revision:path.basename(revision),sha256:sha(revision)},realHardwareVerified:false});
}

async function lockDisconnectResume() {
  const h=harness(); await configure(h);
  let auto=new P01AutoManager({getActiveProject:()=>h.active,appendActivity:()=>{},processInstanceId:'sim-process-a'});
  auto.begin({request:'rev limiter 6000 rpm',voltage:13.6,exactXdfAuthorization:true,autoMapAuthorized:true,autoRevisionAuthorized:true,testWriteAuthorized:true});
  auto.completeStep('preflight','read-properties',8,'preflight complete');
  process.env.PCMHAMMER_MOCK_SCENARIO='locked';
  const locked=await run(h,'readProperties'); assert.equal(locked.stopCode,'adapter-locked');
  let state=auto.pause('adapter-locked','PCM Hammer reported COM4 is locked by another program.',{resumePhase:'read-properties'}); assert.equal(state.resumePhase,'read-properties');
  process.env.PCMHAMMER_MOCK_SCENARIO='success'; state=auto.resume(); assert.equal(state.phase,'read-properties');
  await run(h,'readProperties'); auto.completeStep('read-properties','read-1',18,'properties complete');
  auto.advance('waiting-read-1',20,'read started'); process.env.PCMHAMMER_MOCK_SCENARIO='disconnect';
  const disconnected=await run(h,'read'); assert.equal(disconnected.stopCode,'adapter-disconnected');
  state=auto.pause(disconnected.stopCode,'Adapter disconnected during full read.',{resumePhase:'read-1'}); assert.equal(state.nextStep,'read-1');
  auto.resume({phase:'read-1'}); auto.advance('waiting-read-1',20,'retry started before app restart');
  auto=new P01AutoManager({getActiveProject:()=>h.active,appendActivity:()=>{},processInstanceId:'sim-process-b'});
  state=auto.load(); assert.equal(state.status,'paused'); assert.equal(state.stop.code,'app-restarted-during-step'); assert.equal(state.resumePhase,'read-1');
  state=auto.resume(); assert.equal(state.phase,'read-1');
  process.env.PCMHAMMER_MOCK_SCENARIO='success'; process.env.PCMHAMMER_MOCK_READ_BYTE='71';
  await run(h,'read'); auto.completeStep('read-1','read-2',31,'first read complete');
  await run(h,'read'); auto.completeStep('read-2','definition',48,'second read complete');
  assert.equal(h.p01.status(h.active).dualReadVerified,true);
  return saveSummary({scenario,status:'passed',softwareSimulationOnly:true,stops:['adapter-locked','adapter-disconnected','app-restarted-during-step'],resumePhase:'read-1',completedSteps:Object.keys(auto.load().completedSteps),dualReadRecovered:true,realHardwareVerified:false});
}

async function readFailureRecovery() {
  const h=harness(); await configure(h); await run(h,'readProperties');
  process.env.PCMHAMMER_MOCK_SCENARIO='partial';
  const partial=await run(h,'read'); assert.equal(partial.state,'failed'); assert.equal(partial.stopCode,'read-size-partial'); assert(partial.rejectedOutput&&fs.existsSync(partial.rejectedOutput)); assert.equal(h.p01.status(h.active).reads.length,0);
  process.env.PCMHAMMER_MOCK_SCENARIO='success'; process.env.PCMHAMMER_MOCK_READ_BYTE='11'; await run(h,'read');
  process.env.PCMHAMMER_MOCK_READ_BYTE='22'; await run(h,'read'); let status=h.p01.status(h.active); assert.equal(status.readMismatch,true); assert.equal(status.dualReadVerified,false); assert(!h.active.bin);
  h.p01.beginFreshReadPair('simulation mismatch recovery');
  process.env.PCMHAMMER_MOCK_SCENARIO='block-fail';
  const block1=await run(h,'read'); const block2=await run(h,'read'); assert.equal(block1.stopCode,'repeated-block-read-failures'); assert.equal(block2.stopCode,'repeated-block-read-failures'); assert.equal(h.p01.status(h.active).readPair.status,'awaiting-first');
  process.env.PCMHAMMER_MOCK_SCENARIO='success'; process.env.PCMHAMMER_MOCK_READ_BYTE='33'; await run(h,'read'); await run(h,'read'); status=h.p01.status(h.active); assert.equal(status.dualReadVerified,true); assert.equal(status.readPair.first.size,P01_BIN_SIZE); assert.equal(status.readPair.second.size,P01_BIN_SIZE);
  return saveSummary({scenario,status:'passed',softwareSimulationOnly:true,rejectedPartial:{stopCode:partial.stopCode,size:partial.outputValidation.size,quarantined:true},mismatchStopped:true,repeatedBlockFailureStops:[block1.stopCode,block2.stopCode],recoveryReads:{count:2,size:P01_BIN_SIZE,matching:true,sha256:status.canonicalReadSha256},invalidReadsAccepted:0,realHardwareVerified:false});
}

(async()=>{try{if(scenario==='clean-success')await cleanSuccess();else if(scenario==='lock-disconnect-resume')await lockDisconnectResume();else await readFailureRecovery();}finally{fs.rmSync(root,{recursive:true,force:true});}})().catch(error=>{console.error(error.stack||error);process.exit(1)});
