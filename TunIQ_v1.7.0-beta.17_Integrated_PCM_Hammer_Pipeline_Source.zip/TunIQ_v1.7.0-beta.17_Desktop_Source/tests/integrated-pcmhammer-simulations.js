#!/usr/bin/env node
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { FlashManager } = require('../src/flash');
const { P01AutoManager } = require('../src/p01-auto');
const { P01_BIN_SIZE } = require('../src/p01-commissioning');

const requested = process.argv[2] || 'all';
const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta17-integrated-'));
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) { const started = Date.now(); while (Date.now() - started < timeout) { if (predicate()) return; await delay(20); } throw new Error('Timed out waiting for integrated PCM Hammer simulation.'); }
function hash(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function fixture(name) {
  const root = path.join(tempRoot, name); const folder = path.join(root, 'project');
  for (const sub of ['Originals','Revisions','Reports']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const original = path.join(folder, 'Originals', 'stock.bin'); const revision = path.join(folder, 'Revisions', 'revision.bin');
  fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x41)); fs.writeFileSync(revision, Buffer.alloc(P01_BIN_SIZE, 0x42));
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js'); const executable = path.join(root, 'pcmhammer-cli');
  try { fs.symlinkSync(process.execPath, executable); } catch {}
  return { root, folder, original, revision, mock, executable, active: { id: name, name, folder, controller: 'P01', bin: original } };
}
function managerFor(f, hooks = {}) {
  return new FlashManager({
    dataRoot: () => path.join(f.root, 'data'), getActiveProject: () => f.active, getToolPath: () => '',
    getDeviceStatus: () => ({ connection: { port: 'COM3', voltage: 13.7 } }),
    releasePort: async payload => { hooks.ownership?.push({ type: 'release', ...payload }); return { released: true }; },
    probePortLock: async payload => { hooks.ownership?.push({ type: 'probe', ...payload }); return { available: true }; },
    abortBridgeRequests: reason => { hooks.ownership?.push({ type: 'abort', reason }); return { aborted: 1 }; },
    appendActivity: () => {}, emit: () => {}, onIdentifyComplete: hooks.onIdentity || (async () => {}),
    onReadComplete: hooks.onRead || (async () => {}), onSessionComplete: hooks.onComplete || (async () => {})
  });
}
async function configure(manager, f, profile = 'long-device', scenario = 'success') {
  process.env.PCMHAMMER_MOCK_HELP_MODE = 'blank'; process.env.PCMHAMMER_MOCK_PROFILE = profile; process.env.PCMHAMMER_MOCK_SCENARIO = scenario;
  await manager.probe({ executable: f.executable, prefixArgs: [f.mock] }); manager.saveDevice('COM3');
}
async function profileDiscovery() {
  const f = fixture('profile-discovery'); const ownership = []; let identity = null;
  const manager = managerFor(f, { ownership, onIdentity: async value => { identity = value; } });
  await configure(manager, f, 'long-device');
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const result = manager.getHistory()[0];
  assert.equal(result.state, 'complete'); assert.equal(result.integratedProfileId, 'official-2x-long-device');
  assert(result.profileAttempts.length >= 2); assert.equal(identity.controller, 'P01'); assert.equal(identity.os, '12212156');
  assert(!ownership.some(item => item.type === 'probe')); assert.equal(manager.status().portOwner.owner, 'idle');
  return { scenario: 'profile-discovery', passed: true, profile: result.integratedProfileId, attempts: result.profileAttempts.length, portOwner: manager.status().portOwner.owner };
}
async function completeInternalPipeline() {
  const f = fixture('complete-internal-pipeline'); const reads = []; const completed = [];
  const manager = managerFor(f, { onRead: async (file, info) => reads.push({ file, info }), onComplete: async session => completed.push(session) });
  await configure(manager, f, 'long-device');
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const read1 = path.join(f.folder, 'Originals', 'read-1.bin'); const read2 = path.join(f.folder, 'Originals', 'read-2.bin');
  process.env.PCMHAMMER_MOCK_READ_BYTE = '77';
  await manager.start('read', { output: read1 }); await waitFor(() => !manager.session);
  await manager.start('read', { output: read2 }); await waitFor(() => !manager.session);
  assert.equal(fs.statSync(read1).size, P01_BIN_SIZE); assert.equal(hash(read1), hash(read2)); assert.equal(reads.length, 2);
  await manager.start('testWrite', { input: f.revision, voltage: 13.7 }); await waitFor(() => !manager.session);
  assert.equal(completed.at(-1).testWritePassed, true);
  await manager.start('writeCalibration', { input: f.revision, confirmation: `WRITE ${f.active.name}`, checksumApproved: true, voltage: 13.7 }); await waitFor(() => !manager.session);
  const write = manager.getHistory().find(item => item.operation === 'writeCalibration'); assert.equal(write.state, 'complete'); assert.equal(write.verified, true);
  return { scenario: 'complete-internal-pipeline', passed: true, reads: reads.map(item => ({ size: item.info.size, sha256: item.info.sha256 })), testWrite: true, controlledWrite: write.verified };
}
async function safeFailureAndMigration() {
  const f = fixture('safe-failure-and-migration'); const manager = managerFor(f);
  await configure(manager, f, 'reject-all');
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const unresolved = manager.getHistory()[0]; assert.equal(unresolved.stopCode, 'integrated-cli-profile-unresolved'); assert(unresolved.profileAttempts.every(item => item.syntaxFailure && !item.communicationStarted));
  const autoFolder = path.join(f.root, 'old-state'); fs.mkdirSync(path.join(autoFolder, 'Reports'), { recursive: true });
  const active = { id: 'old-state', name: 'Customline', folder: autoFolder };
  const auto = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'beta17-sim' });
  fs.writeFileSync(auto.file(active), JSON.stringify({ ...auto.blank(active), version: 3, status: 'paused', phase: 'assisted-read', nextStep: 'read-1', resumePhase: 'read-1' }, null, 2));
  const migrated = auto.load(active); assert.equal(migrated.phase, 'stopped-integrated-migration'); assert(auto.canResume(migrated));
  const resumed = auto.resume(); assert.equal(resumed.phase, 'read-1');
  return { scenario: 'safe-failure-and-migration', passed: true, stopCode: unresolved.stopCode, attempts: unresolved.profileAttempts.length, migratedPhase: migrated.phase, resumedPhase: resumed.phase };
}

const scenarios = { 'profile-discovery': profileDiscovery, 'complete-internal-pipeline': completeInternalPipeline, 'safe-failure-and-migration': safeFailureAndMigration };
(async () => {
  try {
    const names = requested === 'all' ? Object.keys(scenarios) : [requested]; const reports = [];
    for (const name of names) { if (!scenarios[name]) throw new Error(`Unknown scenario: ${name}`); reports.push(await scenarios[name]()); console.log(`✓ beta.17 integrated PCM Hammer simulation: ${name}`); }
    const out = path.join(__dirname, '..', 'test-results'); fs.mkdirSync(out, { recursive: true }); fs.writeFileSync(path.join(out, 'integrated-pcmhammer-simulations.json'), JSON.stringify({ generatedAt: new Date().toISOString(), reports }, null, 2));
    console.log(JSON.stringify(reports, null, 2));
  } finally {
    delete process.env.PCMHAMMER_MOCK_HELP_MODE; delete process.env.PCMHAMMER_MOCK_PROFILE; delete process.env.PCMHAMMER_MOCK_SCENARIO; delete process.env.PCMHAMMER_MOCK_READ_BYTE;
    fs.rmSync(tempRoot, { recursive: true, force: true });
  }
})().catch(error => { console.error(error.stack || error); process.exit(1); });
