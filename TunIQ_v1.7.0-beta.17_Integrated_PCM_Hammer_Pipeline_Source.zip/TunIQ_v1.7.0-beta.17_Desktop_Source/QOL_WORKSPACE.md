# TunIQ Workspace Quality of Life

## Shortcuts

- `Ctrl+K`: Open Quick Switch
- `Ctrl+B`: Collapse or expand the sidebar
- `Alt+Left`: Previous TunIQ page
- `Alt+Right`: Next TunIQ page
- `Escape`: Close Quick Switch
- `Up` / `Down` / `Enter`: Navigate and run a Quick Switch result

## Restored workspace state

TunIQ stores UI preferences inside `AppData\TunIQ\Settings\settings.json`. It remembers the last page, recent pages, per-page scroll positions, sidebar state, Tune Path state, compact density, and reduced-motion preference.

The UI preference writer validates booleans, page identifiers, history limits, and scroll bounds before saving.
