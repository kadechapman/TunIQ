# TunIQ v1.7.0-beta.18 — Startup Recovery Hotfix

Beta.18 fixes the beta.17 startup crash reported from the Windows source build while preserving the fully integrated PCM Hammer pipeline.

## Fixed startup failure

The Guided P01 renderer no longer references an undefined variable while restoring a paused or migrated PCM Hammer state. The exact `renderP01Auto → refreshWorkspace → init` failure path is covered by an executable regression test.

## Resilient workspace rendering

Major workspace sections now render through an isolation boundary. If one card fails, TunIQ logs and skips that card instead of replacing the entire application with a fatal startup-error screen.

## Integrated P01 workflow retained

Read Properties, two independent full reads, exact-size/hash verification, exact-OS XDF binding, revision creation, Test Write, and the separately confirmed controlled write remain coordinated inside TunIQ.

## Run on Windows

Use `INSTALL_AND_RUN_WINDOWS.bat` for the first run or dependency repair. Use `START_TUNIQ_WINDOWS.bat` after dependencies are installed.

## Validation boundary

Beta.18 is source- and simulation-tested. A physical OBDLink MX+, Windows Bluetooth COM port, vehicle, P01 PCM, Test Write, and live calibration write are not claimed as verified by the build environment.
