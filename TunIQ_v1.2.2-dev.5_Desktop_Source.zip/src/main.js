const { app, BrowserWindow, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { spawn } = require('child_process');

const APP_VERSION = '1.2.2-dev.5';
let mainWindow;

function dataRoot() {
  return path.join(app.getPath('appData'), 'TunIQ');
}
function legacyDataRoot() {
  return path.join(app.getPath('documents'), 'TunIQ');
}
function copyMissing(source, destination) {
  if (!fs.existsSync(source)) return;
  fs.mkdirSync(destination, { recursive: true });
  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) copyMissing(from, to);
    else if (!fs.existsSync(to)) fs.copyFileSync(from, to);
  }
}
function migrateLegacyData() {
  const marker = path.join(dataRoot(), 'Settings', 'appdata-migration.json');
  if (fs.existsSync(marker)) return readJson(marker, { migrated: false });
  const legacy = legacyDataRoot();
  let result = { migrated: false, source: legacy, destination: dataRoot(), at: new Date().toISOString() };
  try {
    if (fs.existsSync(legacy) && path.resolve(legacy) !== path.resolve(dataRoot())) {
      copyMissing(legacy, dataRoot());
      result.migrated = true;
    }
  } catch (error) { result.error = error.message; }
  writeJson(marker, result);
  return result;
}
function ensureDataFolders() {
  const folders = ['Profile','Vehicles','Projects','Logs','AI','Settings','Backups','Tools','Calibration'];
  fs.mkdirSync(dataRoot(), { recursive: true });
  for (const folder of folders) fs.mkdirSync(path.join(dataRoot(), folder), { recursive: true });
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function writeJson(file, value) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8');
}
function profileFile() { return path.join(dataRoot(), 'Profile', 'profile.json'); }
function settingsFile() { return path.join(dataRoot(), 'Settings', 'settings.json'); }
function toolsFile() { return path.join(dataRoot(), 'Tools', 'paths.json'); }
function vehiclesFile() { return path.join(dataRoot(), 'Vehicles', 'vehicles.json'); }
function activityFile() { return path.join(dataRoot(), 'Logs', 'activity.json'); }
function activeProjectFile() { return path.join(dataRoot(), 'Settings', 'active-project.json'); }
function appendActivity(type, details = {}) {
  const raw = readJson(activityFile(), []);
  const items = Array.isArray(raw) ? raw : [];
  items.unshift({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, type, details, at: new Date().toISOString() });
  writeJson(activityFile(), items.slice(0, 250));
}
function listVehicles() { const value = readJson(vehiclesFile(), []); return Array.isArray(value) ? value : []; }
function normalizeVehicle(payload, existing = {}) {
  const name = String(payload.name || '').trim();
  if (!name) throw new Error('Vehicle name is required.');
  return { ...existing, id: existing.id || `${Date.now()}-${name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'')}`, name, year: String(payload.year || '').trim(), make: String(payload.make || '').trim(), model: String(payload.model || '').trim(), engine: String(payload.engine || '').trim(), controller: String(payload.controller || '').trim(), vin: String(payload.vin || '').trim(), notes: String(payload.notes || '').trim(), updatedAt: new Date().toISOString(), createdAt: existing.createdAt || new Date().toISOString() };
}

function logCrash(label, error) {
  try {
    ensureDataFolders();
    const line = `[${new Date().toISOString()}] ${label}\n${error?.stack || error || 'Unknown error'}\n\n`;
    fs.appendFileSync(path.join(dataRoot(), 'Logs', 'desktop-crash.log'), line, 'utf8');
  } catch {}
}
process.on('uncaughtException', err => logCrash('uncaughtException', err));
process.on('unhandledRejection', err => logCrash('unhandledRejection', err));

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 700,
    backgroundColor: '#111714',
    show: false,
    title: `TunIQ ${APP_VERSION}`,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false
    }
  });
  mainWindow.webContents.on('render-process-gone', (_e, details) => { logCrash('render-process-gone', JSON.stringify(details)); });
  mainWindow.webContents.on('did-fail-load', (_e, code, desc, url) => { logCrash('did-fail-load', `${code} ${desc} ${url}`); });
  mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html')).catch(err => logCrash('loadFile', err));
  mainWindow.once('ready-to-show', () => mainWindow.show());
}

function findExecutable(candidates) {
  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return null;
}
function scanTools() {
  const configured = readJson(toolsFile(), {});
  const pf = process.env.ProgramFiles || 'C:\\Program Files';
  const pfx86 = process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)';
  const local = process.env.LOCALAPPDATA || '';
  const desktop = app.getPath('desktop');
  const downloads = app.getPath('downloads');
  const results = {
    pcmHammer: findExecutable([configured.pcmHammer, path.join(pf, 'PCM Hammer', 'PcmHammer.exe'), path.join(pfx86, 'PCM Hammer', 'PcmHammer.exe'), path.join(desktop, 'PCM Hammer', 'PcmHammer.exe'), path.join(downloads, 'PCM Hammer', 'PcmHammer.exe')]),
    tunerPro: findExecutable([configured.tunerPro, path.join(pf, 'TunerPro', 'TunerPro.exe'), path.join(pfx86, 'TunerPro', 'TunerPro.exe'), path.join(desktop, 'TunerPro', 'TunerPro.exe'), path.join(downloads, 'TunerPro', 'TunerPro.exe')]),
    universalPatcher: findExecutable([configured.universalPatcher, path.join(pf, 'Universal Patcher', 'UniversalPatcher.exe'), path.join(local, 'UniversalPatcher', 'UniversalPatcher.exe'), path.join(desktop, 'UniversalPatcher', 'UniversalPatcher.exe'), path.join(downloads, 'UniversalPatcher', 'UniversalPatcher.exe')])
  };
  writeJson(toolsFile(), { ...configured, ...results });
  return results;
}

app.disableHardwareAcceleration();
app.whenReady().then(() => {
  ensureDataFolders();
  migrateLegacyData();
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('app:get-bootstrap', async () => ({
  version: APP_VERSION,
  dataRoot: dataRoot(),
  profile: readJson(profileFile(), null),
  settings: readJson(settingsFile(), { aiMode: null, units: 'US' }),
  tools: readJson(toolsFile(), {}),
  vehicles: listVehicles(),
  activity: (() => { const v = readJson(activityFile(), []); return Array.isArray(v) ? v : []; })(),
  activeProject: readJson(activeProjectFile(), null),
  migration: readJson(path.join(dataRoot(), 'Settings', 'appdata-migration.json'), null)
}));
ipcMain.handle('profile:save', async (_event, payload) => {
  const profile = { name: String(payload.name || '').trim(), email: String(payload.email || '').trim(), createdAt: new Date().toISOString() };
  const settings = { aiMode: payload.aiMode, units: payload.units || 'US', updatedAt: new Date().toISOString() };
  if (!profile.name || !profile.email || !['guided','manual','full-ai'].includes(settings.aiMode)) throw new Error('Name, email, and AI mode are required.');
  writeJson(profileFile(), profile);
  writeJson(settingsFile(), settings);
  return { profile, settings };
});
ipcMain.handle('settings:set-ai-mode', async (_event, aiMode) => {
  if (!['guided','manual','full-ai'].includes(aiMode)) throw new Error('Invalid AI mode.');
  const settings = { ...readJson(settingsFile(), {}), aiMode, updatedAt: new Date().toISOString() };
  writeJson(settingsFile(), settings);
  return settings;
});
ipcMain.handle('bridge:scan-tools', async () => scanTools());
ipcMain.handle('bridge:choose-tool', async (_event, key) => {
  const result = await dialog.showOpenDialog(mainWindow, { properties: ['openFile'], filters: [{ name: 'Windows programs', extensions: ['exe'] }, { name: 'All files', extensions: ['*'] }] });
  if (result.canceled || !result.filePaths[0]) return null;
  const tools = readJson(toolsFile(), {});
  tools[key] = result.filePaths[0];
  writeJson(toolsFile(), tools);
  return tools[key];
});
ipcMain.handle('bridge:launch-tool', async (_event, key) => {
  const tools = readJson(toolsFile(), {});
  const exe = tools[key];
  if (!exe || !fs.existsSync(exe)) throw new Error('Tool path is not configured or no longer exists.');
  const active = readJson(activeProjectFile(), null);
  const cwd = active?.folder && fs.existsSync(active.folder) ? active.folder : path.dirname(exe);
  const child = spawn(exe, [], { detached: true, stdio: 'ignore', cwd });
  child.unref();
  appendActivity('tool-launched', { key, exe, activeProjectId: active?.id || null, activeProjectName: active?.name || null });
  return { launched: true, activeProject: active };
});
ipcMain.handle('system:open-data-folder', async () => shell.openPath(dataRoot()));

ipcMain.handle('vehicle:list', async () => listVehicles());
ipcMain.handle('vehicle:save', async (_event, payload) => {
  const vehicles = listVehicles();
  const index = payload.id ? vehicles.findIndex(v => v.id === payload.id) : -1;
  const vehicle = normalizeVehicle(payload, index >= 0 ? vehicles[index] : {});
  if (index >= 0) vehicles[index] = vehicle; else vehicles.unshift(vehicle);
  writeJson(vehiclesFile(), vehicles);
  appendActivity(index >= 0 ? 'vehicle-updated' : 'vehicle-created', { id: vehicle.id, name: vehicle.name });
  return vehicle;
});
ipcMain.handle('vehicle:delete', async (_event, id) => {
  const vehicles = listVehicles();
  const found = vehicles.find(v => v.id === id);
  writeJson(vehiclesFile(), vehicles.filter(v => v.id !== id));
  if (found) appendActivity('vehicle-deleted', { id: found.id, name: found.name });
  return true;
});
ipcMain.handle('project:set-active', async (_event, id) => {
  const base = path.join(dataRoot(), 'Projects');
  const projects = fs.existsSync(base) ? fs.readdirSync(base, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => ({ manifest: readJson(path.join(base, x.name, 'project.json'), null), folder: path.join(base, x.name) })).filter(x => x.manifest) : [];
  const found = projects.find(x => x.manifest.id === id);
  if (!found) throw new Error('Project not found.');
  const active = { id: found.manifest.id, name: found.manifest.name, folder: found.folder, vehicle: found.manifest.vehicle, controller: found.manifest.controller, os: found.manifest.os, selectedAt: new Date().toISOString() };
  writeJson(activeProjectFile(), active);
  appendActivity('project-activated', active);
  return active;
});
ipcMain.handle('activity:list', async () => readJson(activityFile(), []));

ipcMain.handle('project:create', async (_event, payload) => {
  const safeName = String(payload.name || '').trim().replace(/[<>:"/\\|?*]/g, '-');
  if (!safeName) throw new Error('Project name is required.');
  const id = `${Date.now()}-${safeName.toLowerCase().replace(/\s+/g,'-')}`;
  const folder = path.join(dataRoot(), 'Projects', id);
  fs.mkdirSync(path.join(folder, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(folder, 'Revisions'), { recursive: true });
  const manifest = { id, name: safeName, vehicle: payload.vehicle || '', controller: payload.controller || '', os: payload.os || '', notes: payload.notes || '', createdAt: new Date().toISOString(), revisions: [] };
  writeJson(path.join(folder, 'project.json'), manifest);
  const active = { id, name: safeName, folder, vehicle: manifest.vehicle, controller: manifest.controller, os: manifest.os, selectedAt: new Date().toISOString() };
  writeJson(activeProjectFile(), active);
  appendActivity('project-created', { id, name: safeName, vehicle: manifest.vehicle, controller: manifest.controller });
  return { ...manifest, active };
});
ipcMain.handle('project:list', async () => {
  const base = path.join(dataRoot(), 'Projects');
  if (!fs.existsSync(base)) return [];
  return fs.readdirSync(base, { withFileTypes: true }).filter(x => x.isDirectory()).map(x => readJson(path.join(base, x.name, 'project.json'), null)).filter(Boolean).sort((a,b) => b.createdAt.localeCompare(a.createdAt));
});
ipcMain.handle('diagnostics:export', async () => {
  const report = { version: APP_VERSION, platform: process.platform, arch: process.arch, os: os.release(), dataRoot: dataRoot(), profileExists: fs.existsSync(profileFile()), settings: readJson(settingsFile(), {}), tools: scanTools(), generatedAt: new Date().toISOString() };
  const out = path.join(dataRoot(), 'Logs', `diagnostics-${Date.now()}.json`);
  writeJson(out, report);
  return out;
});

ipcMain.handle('system:open-external', async (_event, url) => {
  const allowed = ['https://github.com/LegacyNsfw/PcmHacks/releases','https://www.tunerpro.net/downloadApp.htm','https://universalpatcher.net/download/'];
  if (!allowed.includes(url)) throw new Error('Blocked unapproved external URL.');
  await shell.openExternal(url);
  return true;
});


function calibrationFile() { return path.join(dataRoot(), 'Calibration', 'workspace.json'); }
function calibrationHistoryFile() { return path.join(dataRoot(), 'Calibration', 'history.json'); }
function defaultCalibrationWorkspace() {
  const makeGrid = (rows, cols, fn) => Array.from({ length: rows }, (_, r) => Array.from({ length: cols }, (_, c) => Number(fn(r, c).toFixed(2))));
  return {
    activeTable: 'spark',
    tables: {
      spark: { name: 'High-Octane Spark', unit: '°', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['0.20','0.32','0.44','0.56','0.68','0.80','0.92','1.04'], min: -10, max: 50, values: makeGrid(8,8,(r,c)=>12+r*1.75-c*.65) },
      ve: { name: 'VE Main', unit: '%', rowHeaders: ['800','1200','1600','2000','2400','2800','3200','3600'], colHeaders: ['20','30','40','50','60','70','80','90'], min: 20, max: 125, values: makeGrid(8,8,(r,c)=>42+r*3.1+c*4.2) },
      idle: { name: 'Idle Airflow', unit: 'g/s', rowHeaders: ['-20','0','20','40','60','80','100','120'], colHeaders: ['P/N','Drive'], min: 0, max: 30, values: makeGrid(8,2,(r,c)=>15-r*1.25+c*1.2) },
      fans: { name: 'Fan Temperatures', unit: '°F', rowHeaders: ['Fan 1 On','Fan 1 Off','Fan 2 On','Fan 2 Off'], colHeaders: ['Value'], min: 100, max: 240, values: [[205],[198],[215],[208]] },
      fuel: { name: 'Power Enrichment EQ', unit: 'EQ', rowHeaders: ['2000','2400','2800','3200','3600','4000'], colHeaders: ['40','50','60','70','80','90','100'], min: 0.7, max: 1.6, values: makeGrid(6,7,(r,c)=>1.0+Math.max(0,c-2)*.035+r*.006) },
      transmission: { name: 'WOT Shift RPM', unit: 'RPM', rowHeaders: ['1-2','2-3','3-4'], colHeaders: ['Normal','Performance'], min: 1000, max: 7500, values: [[5400,5600],[5350,5550],[5250,5450]] },
      limits: { name: 'Engine & Speed Limits', unit: '', rowHeaders: ['Rev limiter fuel cut','Rev limiter resume','Speed limiter'], colHeaders: ['Value'], min: 0, max: 8000, values: [[5800],[5700],[130]] }
    },
    stock: null,
    modified: {},
    updatedAt: new Date().toISOString()
  };
}
function loadCalibration() {
  const existing = readJson(calibrationFile(), null);
  if (existing?.tables) return existing;
  const workspace = defaultCalibrationWorkspace();
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  writeJson(calibrationFile(), workspace);
  return workspace;
}
ipcMain.handle('calibration:load', async () => loadCalibration());
ipcMain.handle('calibration:save', async (_event, payload) => {
  if (!payload || typeof payload !== 'object' || !payload.tables) throw new Error('Invalid calibration workspace.');
  payload.updatedAt = new Date().toISOString();
  writeJson(calibrationFile(), payload);
  return payload;
});
ipcMain.handle('calibration:revision', async (_event, payload) => {
  const workspace = loadCalibration();
  const history = readJson(calibrationHistoryFile(), []);
  const revision = { id: `${Date.now()}`, name: String(payload?.name || `Revision ${history.length + 1}`), note: String(payload?.note || ''), at: new Date().toISOString(), activeProject: readJson(activeProjectFile(), null), workspace };
  history.unshift(revision);
  writeJson(calibrationHistoryFile(), history.slice(0, 100));
  appendActivity('calibration-revision', { id: revision.id, name: revision.name, project: revision.activeProject?.name || null });
  return revision;
});
ipcMain.handle('calibration:history', async () => readJson(calibrationHistoryFile(), []));
ipcMain.handle('calibration:reset', async () => {
  const workspace = defaultCalibrationWorkspace();
  workspace.stock = JSON.parse(JSON.stringify(workspace.tables));
  writeJson(calibrationFile(), workspace);
  return workspace;
});
