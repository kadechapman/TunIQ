# TunIQ v1.2.2-dev.5

Built directly on the v1.2.2-dev.4 crash-fix source.

## What works
- Add, edit, and delete persistent vehicles
- Create projects and set the active project
- Project-aware external tool launching and activity history
- Persistent Calibration Lab tables with undo/redo, multi-cell math, stock-change highlighting, validation, and revision snapshots
- Application data stored in `%APPDATA%\TunIQ`
- Automatic one-time migration from the older `Documents\TunIQ` folder without deleting the original

## Current integration limitation
TunIQ tracks project-aware handoff and activity. It does not yet read every click or live value inside external programs. Calibration Lab tables are a local editor workspace and are not yet mapped to real BIN addresses.

## Windows
1. Extract the ZIP fully to a local folder.
2. Double-click `INSTALL_AND_RUN_WINDOWS.bat` the first time.
3. Use `START_TUNIQ_WINDOWS.bat` afterward.
