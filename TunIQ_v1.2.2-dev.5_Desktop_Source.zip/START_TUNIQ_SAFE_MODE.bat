@echo off
setlocal
cd /d "%~dp0"
echo Starting TunIQ v1.2.2-dev.5 in safe mode...
set ELECTRON_ENABLE_LOGGING=1
set ELECTRON_DISABLE_GPU=1
call npm start
if errorlevel 1 (
  echo.
  echo TunIQ closed with an error. Crash log location:
  echo %%APPDATA%%\TunIQ\Logs\desktop-crash.log
  pause
)
endlocal
