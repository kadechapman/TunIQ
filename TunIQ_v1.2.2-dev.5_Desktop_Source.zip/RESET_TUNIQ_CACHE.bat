@echo off
setlocal
set CACHE=%APPDATA%\tuniq-desktop
if exist "%CACHE%" (
  echo Removing Electron cache only. Your vehicles and projects in %%APPDATA%%\TunIQ will not be deleted.
  rmdir /s /q "%CACHE%"
)
echo Cache reset complete.
pause
endlocal
