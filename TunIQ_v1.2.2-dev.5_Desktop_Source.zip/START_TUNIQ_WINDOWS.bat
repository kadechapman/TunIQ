@echo off
cd /d "%~dp0"
if not exist node_modules\electron\dist\electron.exe (
  call INSTALL_AND_RUN_WINDOWS.bat
  exit /b %errorlevel%
)
call npm start
