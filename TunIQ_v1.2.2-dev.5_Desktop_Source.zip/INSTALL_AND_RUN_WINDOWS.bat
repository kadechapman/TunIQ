@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install the current LTS version, then run this file again.
  pause
  exit /b 1
)
if not exist node_modules\electron\dist\electron.exe (
  echo Installing the Electron desktop runtime...
  call npm install
  if errorlevel 1 (
    echo Installation failed. Check the internet connection and the npm error above.
    pause
    exit /b 1
  )
)
call npm start
