# TunIQ v0.8 — Cumulative Master

This release contains the implemented TunIQ features from all earlier cumulative versions and adds the Wave 8 read-only tune-file foundation.

## Open it

1. Extract the ZIP completely.
2. On Windows, double-click `OPEN_TUNIQ_WINDOWS.bat`.
3. On any computer, open `TunIQ_Open_Me.html`.

The normal offline app does not require Node.js.

## New in v0.8

- Read-only local file manager
- SHA-256 file fingerprints
- Raw byte comparison
- Changed-region visualization
- Backup/file record register
- Exportable metadata report

## Important boundary

This version does not know whether an arbitrary file is safe for a specific PCM. It does not contain production calibration definitions, checksum correction, PCM Hammer control, controller reading/writing, flashing, or automatic tuning.
