@echo off
title TunIQ Local Bridge v0.6
cd /d "%~dp0.."
node bridge\agent.mjs
pause
