# TunIQ Local Bridge v0.6

This is a local health/inventory foundation. It exposes only a status endpoint on `127.0.0.1:8788`. Controller reads, writes, flashing, PCM Hammer launching, and calibration commands are not implemented.

Run on Windows with Node.js installed by double-clicking `start-bridge-windows.bat`. Then open TunIQ and use **Bridge → Check local agent**.
