@echo off
setlocal
title Opening TunIQ
cd /d "%~dp0"
if not exist "TunIQ_Open_Me.html" (
  echo TunIQ_Open_Me.html was not found.
  echo Make sure you extracted the complete ZIP before opening TunIQ.
  pause
  exit /b 1
)
start "TunIQ" "%~dp0TunIQ_Open_Me.html"
exit /b 0
