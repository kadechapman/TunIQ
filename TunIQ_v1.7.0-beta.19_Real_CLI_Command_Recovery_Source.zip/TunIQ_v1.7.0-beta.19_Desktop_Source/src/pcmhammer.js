const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const P01_BIN_SIZE = 524288;
const OPERATIONS = Object.freeze({
  readProperties: {
    aliases: ['read-properties', 'readproperties', 'properties', 'read-property', 'readproperty', 'get-properties', 'getproperties'],
    flagAliases: ['--get-properties', '--read-properties', '--readproperties', '--properties'],
    io: null,
    label: 'Read Properties'
  },
  read: {
    aliases: ['read', 'read-full', 'readfull', 'read-entire', 'readentire', 'read-entire-pcm', 'readcontents'],
    flagAliases: ['--read', '--read-full', '--read-entire', '--read-entire-pcm'],
    io: 'output',
    label: 'Read Entire PCM'
  },
  testWrite: {
    aliases: ['test-write', 'testwrite', 'test'],
    flagAliases: ['--test-write', '--testwrite'],
    io: 'input',
    label: 'Test Write'
  },
  writeCalibration: {
    aliases: ['write-calibration', 'writecalibration', 'write-cal', 'writecal', 'write-segment'],
    flagAliases: ['--write-calibration', '--writecalibration', '--write-cal'],
    io: 'input',
    label: 'Write Calibration'
  },
  writeFull: {
    aliases: ['write-full', 'writefull', 'write-entire', 'writeentire', 'write-os-calibration', 'write'],
    flagAliases: ['--write-full', '--write-entire', '--write'],
    io: 'input',
    label: 'Write Full PCM'
  },
  recovery: {
    aliases: ['recovery', 'recover', 'recovery-write', 'write-recovery'],
    flagAliases: ['--recovery', '--recover', '--recovery-write'],
    io: 'input',
    label: 'Recovery Write'
  }
});

function clean(value, max = 2000) {
  return String(value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, max);
}
function sha256File(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function normalizeOperation(operation) {
  const value = String(operation || '').trim();
  if (value === 'identify' || value === 'properties') return 'readProperties';
  return value;
}
function tokenizeTemplate(template) {
  if (Array.isArray(template)) return template.map(String);
  const text = String(template || '').trim();
  if (!text) return [];
  const tokens = [];
  let current = ''; let quote = '';
  for (const char of text) {
    if (quote) {
      if (char === quote) quote = '';
      else current += char;
    } else if (char === '"' || char === "'") quote = char;
    else if (/\s/.test(char)) { if (current) { tokens.push(current); current = ''; } }
    else current += char;
  }
  if (current) tokens.push(current);
  return tokens;
}
function expandTemplate(template, values = {}) {
  return tokenizeTemplate(template)
    .map(token => token.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => values[key] == null ? '' : String(values[key])))
    .filter(Boolean);
}
function parseProgress(line, current = 0) {
  const text = String(line || '');
  const percent = text.match(/(?:^|\s)(100|[0-9]{1,2})(?:\.\d+)?\s*%/);
  if (percent) return Math.max(current, Number(percent[1]));
  const fraction = text.match(/\b(?:block\s*)?(\d+)\s*(?:\/|of)\s*(\d+)\b/i);
  if (fraction && Number(fraction[2]) > 0) return Math.max(current, Math.min(100, Number(fraction[1]) * 100 / Number(fraction[2])));
  if (/completed successfully|operation complete|verification passed|test write.*pass/i.test(text)) return 100;
  return current;
}
function firstMatch(source, patterns) {
  for (const pattern of patterns) {
    const match = source.match(pattern);
    if (match?.[1]) return clean(match[1], 100);
  }
  return '';
}
function controllerFromDescription(description, source) {
  const explicit = firstMatch(source, [/(?:controller|pcm|ecm)\s*(?:type|family)?\s*[:=#-]\s*(P\d{2}|E\d{2}|BLACK\s*BOX)/i]);
  if (explicit) return explicit.toUpperCase().replace(/\s+/g, ' ');
  const labeledControllerLines = String(source || '')
    .split(/\r?\n/)
    .filter(line => /(?:controller|pcm|ecm|module)\s*(?:type|family)?\s*[:=#-]/i.test(line))
    .join('\n');
  const known = `${description}\n${labeledControllerLines}`.match(/\b(P01|P04(?:_EARLY)?|P05B?|P08|P10|P11|P12B?|P59|E38|E54)\b/i)?.[1];
  if (known) return known.toUpperCase();
  if (/vortec\s+black\s+box|4\s*(?:plug|connector)|5\s*(?:plug|connector)/i.test(description)) return 'BLACK BOX';
  return '';
}
function parseIdentityText(text) {
  const source = String(text || '').replace(/\r/g, '');
  const description = firstMatch(source, [/^\s*(?:\[[^\]]+\]\s*)?Description\s*:\s*(.+)$/im]);
  const voltageRaw = firstMatch(source, [
    /^\s*(?:\[[^\]]+\]\s*)?Battery\s+Voltage\s+(?:is\s*)?:\s*([0-9]+(?:\.[0-9]+)?)/im,
    /^\s*(?:\[[^\]]+\]\s*)?Voltage\s*:\s*([0-9]+(?:\.[0-9]+)?)(?:\s*V)?\s*$/im
  ]);
  const serviceNumber = firstMatch(source, [
    /\bService\s*(?:No\.?|Number|#)\s*[:=#-]?\s*([A-Z0-9._-]{4,40})\b/i,
    /\bServiceNo\s*[:=#-]?\s*([A-Z0-9._-]{4,40})\b/i
  ]);
  const identity = {
    vin: firstMatch(source, [/\bVIN\s*[:=]\s*([A-HJ-NPR-Z0-9]{17})\b/i]),
    os: firstMatch(source, [/\bOSID\s*[:=#-]?\s*(\d{7,9})\b/i, /\bOperating\s+System(?:\s+ID)?\s*[:=#-]?\s*(\d{7,9})\b/i]),
    hardwareId: firstMatch(source, [/\bHardware\s*(?:ID|No\.?|Number|#)?\s*[:=#-]?\s*([A-Z0-9._-]{4,40})\b/i, /\bHWID\s*[:=#-]?\s*([A-Z0-9._-]{4,40})\b/i]),
    serviceNumber,
    description,
    controller: '',
    voltage: voltageRaw ? Number(voltageRaw) : null
  };
  identity.controller = controllerFromDescription(description, source);
  return identity;
}
function parseBackendIdentity(text, executable = '') {
  const source = String(text || '');
  const version = source.match(/(?:PCM\s*Hammer[^\n0-9]{0,30}|Version\s*[:=]?\s*)(\d+\.\d+(?:\.\d+)?(?:[-+a-z0-9.]*)?)/i)?.[1]
    || source.match(/\b(2\.\d+(?:\.\d+)?)\b/)?.[1] || '';
  const major = Number(version.match(/^(\d+)/)?.[1] || 0);
  const product = /pcm\s*hammer/i.test(source) || /pcmhammer/i.test(executable) ? 'PCM Hammer' : '';
  return { product, version, major, official: product === 'PCM Hammer' && major >= 2 };
}
function containsToken(help, token) {
  const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return new RegExp(`(^|[\\s,|])${escaped}(?=$|[\\s,|=<\\[])`, 'im').test(help);
}
function findUsageLine(help, aliases) {
  const lines = String(help || '').split(/\r?\n/);
  const ordered = [...aliases].sort((a, b) => Number(b.startsWith('--')) - Number(a.startsWith('--')) || b.length - a.length);
  const startsWithToken = (line, token) => {
    const escaped = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    return new RegExp(`^\\s*${escaped}(?=$|\\s|[<\\[])`, 'i').test(line);
  };
  return lines.find(line => ordered.some(alias => startsWithToken(line, alias)))
    || lines.find(line => ordered.some(alias => containsToken(line, alias))) || '';
}
function optionFromHelp(help, candidates) {
  return candidates.find(option => new RegExp(`(?:^|\\s)${option.replace(/-/g, '\\-')}(?=$|\\s|[=<\\[])`, 'im').test(help)) || null;
}
function operationToken(help, profile, line = '') {
  for (const alias of profile.flagAliases) if (containsToken(line || help, alias)) return alias;
  for (const alias of profile.aliases) if (containsToken(line || help, alias)) return alias;
  for (const alias of profile.flagAliases) if (containsToken(help, alias)) return alias;
  for (const alias of profile.aliases) if (containsToken(help, alias)) return alias;
  return null;
}
function placeholderPosition(line, io) {
  if (!line) return Number.MAX_SAFE_INTEGER - 10;
  const pattern = io === 'input'
    ? /(?:<|\[)(?:input|file|bin|image|calibration)(?:>|\])/i
    : /(?:<|\[)(?:output|file|bin|image)(?:>|\])/i;
  const match = pattern.exec(line);
  return match ? match.index : Number.MAX_SAFE_INTEGER - 10;
}
function inferTemplateForOperation(helpText, operation) {
  const profile = OPERATIONS[operation];
  if (!profile) return null;
  const help = String(helpText || '');
  const line = findUsageLine(help, [...profile.flagAliases, ...profile.aliases]);
  const token = operationToken(help, profile, line);
  if (!token) return null;
  const lineDeviceOption = optionFromHelp(line, ['--device', '--interface', '--port', '-d', '-p']);
  const globalDeviceOption = lineDeviceOption || optionFromHelp(help, ['--device', '--interface', '--port', '-d', '-p']);
  const inputOption = profile.io === 'input' ? optionFromHelp(line, ['--input', '--file', '--bin', '-i', '-f']) : null;
  const outputOption = profile.io === 'output' ? optionFromHelp(line, ['--output', '--file', '--bin', '-o', '-f']) : null;
  const pieces = [];
  if (profile.io === 'input') {
    const pos = inputOption ? line.toLowerCase().indexOf(inputOption.toLowerCase()) : placeholderPosition(line, 'input');
    pieces.push({ pos, args: inputOption ? [inputOption, '{input}'] : ['{input}'] });
  }
  if (profile.io === 'output') {
    const pos = outputOption ? line.toLowerCase().indexOf(outputOption.toLowerCase()) : placeholderPosition(line, 'output');
    pieces.push({ pos, args: outputOption ? [outputOption, '{output}'] : ['{output}'] });
  }
  if (globalDeviceOption) {
    const pos = lineDeviceOption ? line.toLowerCase().indexOf(lineDeviceOption.toLowerCase()) : Number.MAX_SAFE_INTEGER;
    pieces.push({ pos, args: [globalDeviceOption, '{device}'] });
  }
  pieces.sort((a, b) => a.pos - b.pos);
  return [token, ...pieces.flatMap(item => item.args)];
}
function inferTemplates(helpText) {
  const result = {};
  for (const operation of Object.keys(OPERATIONS)) result[operation] = inferTemplateForOperation(helpText, operation);
  return result;
}
function classifyPcmHammerResult(operation, text, exitCode = null) {
  const source = String(text || '');
  const normalizedOperation = normalizeOperation(operation);
  const lock = /(?:access\s+(?:to\s+the\s+port\s+)?is\s+denied|port\s+.*(?:busy|in use|locked)|unauthorizedaccessexception|cannot\s+open\s+(?:serial\s+)?port|another\s+(?:program|process).*using|resource\s+busy)/i.test(source);
  const disconnect = /(?:device\s+(?:was\s+)?disconnected|adapter\s+(?:was\s+)?disconnected|port\s+.*(?:does not exist|not found)|lost\s+(?:communication|connection)|no\s+device|unable\s+to\s+connect|connection\s+closed|i\/o\s+operation.*aborted)/i.test(source);
  const blockFailures = (source.match(/(?:failed|failure|error|timeout).*?block|block.*?(?:failed|failure|error|timeout)/gi) || []).length;
  const partial = /(?:partial|incomplete|short)\s+(?:read|image)|read\s+(?:stopped|aborted|failed).*before|expected\s+\d+.*(?:got|received)\s+\d+/i.test(source);
  const explicitFailure = /\b(?:operation|read|write|test\s*write|verification)\s+(?:has\s+)?(?:failed|aborted)\b|\bfatal\b|\bunhandled exception\b/i.test(source);
  const testWritePassed = normalizedOperation === 'testWrite' && /(?:test\s*write[^\n]{0,80}(?:passed|successful|completed)|verification[^\n]{0,80}(?:passed|successful)|no\s+changes\s+were\s+written)/i.test(source);
  const readCompleted = normalizedOperation === 'read' && /(?:read\s+(?:entire\s+pcm|contents|operation)?[^\n]{0,80}(?:complete|completed|successful)|saved\s+(?:image|bin|file)|verification[^\n]{0,60}(?:passed|successful))/i.test(source);
  const propertiesCompleted = normalizedOperation === 'readProperties' && Boolean(parseIdentityText(source).os || parseIdentityText(source).hardwareId || parseIdentityText(source).serviceNumber);
  const verificationPassed = /verification[^\n]{0,80}(?:passed|successful|complete)|verified\s+(?:successfully|ok)/i.test(source);
  const successByOperation = normalizedOperation === 'testWrite' ? testWritePassed
    : normalizedOperation === 'read' ? readCompleted
      : normalizedOperation === 'readProperties' ? propertiesCompleted
        : verificationPassed;
  const okExit = exitCode == null || Number(exitCode) === 0;
  const failed = !okExit || lock || disconnect || partial || explicitFailure || blockFailures >= 3;
  return {
    operation: normalizedOperation,
    okExit,
    success: okExit && successByOperation && !failed,
    lock,
    disconnect,
    partial,
    blockFailures,
    explicitFailure,
    testWritePassed,
    readCompleted,
    propertiesCompleted,
    verificationPassed,
    stopCode: lock ? 'adapter-locked' : disconnect ? 'adapter-disconnected' : blockFailures >= 3 ? 'repeated-block-read-failures' : partial ? 'partial-read' : (!okExit || explicitFailure) ? 'pcmhammer-failed' : successByOperation ? null : 'result-not-proven'
  };
}
function validateP01ReadFile(file, result = null) {
  if (!file || !fs.existsSync(file)) return { valid: false, code: 'read-file-missing', message: 'PCM Hammer did not produce a BIN file.' };
  const stat = fs.statSync(file);
  if (!stat.isFile()) return { valid: false, code: 'read-file-invalid', message: 'The PCM read output is not a regular file.' };
  if (stat.size !== P01_BIN_SIZE) return { valid: false, code: stat.size < P01_BIN_SIZE ? 'read-size-partial' : 'read-size-incorrect', message: `Rejected PCM read: expected exactly ${P01_BIN_SIZE} bytes but received ${stat.size} bytes.`, size: stat.size };
  if (result && !result.success) return { valid: false, code: result.stopCode || 'read-result-failed', message: `PCM Hammer did not prove a successful full read (${result.stopCode || 'unknown result'}).`, size: stat.size };
  return { valid: true, path: file, name: path.basename(file), size: stat.size, sha256: sha256File(file), modifiedAt: stat.mtime.toISOString() };
}
function assistedInstructions(operation, folder) {
  const op = normalizeOperation(operation);
  const save = folder ? `Save or copy the result into: ${folder}` : 'Save the result, then import it into TunIQ.';
  const map = {
    readProperties: ['Open the normal PCM Hammer Windows app.', 'Select the correct interface and COM port.', 'Click Read Properties.', `${save} as a .txt or .log file.`],
    read: ['Open the normal PCM Hammer Windows app.', 'Select the correct interface and COM port.', 'Choose Tools → Read Entire PCM.', `${save} as a .bin file. TunIQ accepts only exactly 524,288 bytes.`],
    testWrite: ['Open the normal PCM Hammer Windows app.', 'Select the exact TunIQ revision.', 'Click Test Write.', `${save} as a .txt or .log file. TunIQ requires an explicit passed result.`],
    writeCalibration: ['Open the normal PCM Hammer Windows app.', 'Select the exact TunIQ revision.', 'Choose Write Calibration only after TunIQ reports Ready to Write.', 'Keep stable power and save the Results log afterward.'],
    writeFull: ['Use PCM Hammer full write only when the separate full-write safety gate is satisfied.', 'Keep stable power and save the Results log afterward.'],
    recovery: ['Use PCM Hammer Recovery only for a confirmed recovery case.', 'Keep stable power and save the Results log afterward.']
  };
  return map[op] || ['Open PCM Hammer and complete the requested operation.', save];
}

module.exports = {
  P01_BIN_SIZE, OPERATIONS, normalizeOperation, tokenizeTemplate, expandTemplate, parseProgress,
  parseIdentityText, parseBackendIdentity, inferTemplates, classifyPcmHammerResult,
  validateP01ReadFile, assistedInstructions, sha256File, clean
};
