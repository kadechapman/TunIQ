# TunIQ v1.7.0-beta.19 — Real CLI Command Recovery

Beta.19 fixes the real PCM Hammer command mismatch found in a beta.18 diagnostic report and repairs existing P01 commissioning progress instead of repeating already proven steps.

## Real PCM Hammer 2.0 commands

TunIQ now recognizes the installed CLI's advertised syntax:

```text
--get-properties --device COM3
--read <file> --device COM3
--test-write <file> --device COM3
```

A CLI usage banner is treated as a command-syntax rejection, not as vehicle communication. TunIQ can safely move to the next non-destructive command profile only when no PCM communication or output file began.

## Existing project recovery

On startup or Resume, TunIQ revalidates saved P01 identity and read evidence. When two distinct saved files are still exactly 524,288 bytes and have the same SHA-256, the missing verified pair and completed-step ledger can be reconstructed. Guided Setup continues at the first incomplete step, such as exact-XDF binding, instead of rerunning Read Properties.

## Better failure evidence

Stopped PCM Hammer operations retain their executable, arguments, reconstructed command, COM port, exit code, stdout, and stderr. Use **Copy Technical Details** directly from Guided P01 Setup when a real hardware operation stops.

## Windows

Extract into a new folder and run `INSTALL_AND_RUN_WINDOWS.bat`. Existing projects remain in TunIQ AppData.

## Safety boundary

The observed CLI exposes an entire-PCM `--write` operation but not a distinct calibration-only command. TunIQ does not silently replace Calibration Write with Full Write. Physical OBDLink, vehicle, PCM, Test Write, and write verification remain user-hardware validation steps.
