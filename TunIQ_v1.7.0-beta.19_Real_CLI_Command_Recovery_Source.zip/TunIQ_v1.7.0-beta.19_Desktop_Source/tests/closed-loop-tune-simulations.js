const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const {
  ClosedLoopTuneManager,
  evaluateLog,
  buildProjectReadiness,
  executeClosedLoopCorrection,
  analyzeClosedLoopValidation
} = require('../src/closed-loop-tune');
const { projectFixture, workspaceFixture, targets, intake } = require('./tune-engine-simulations');

function sha(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function autonomousRun(active, workspace) {
  return {
    id: 'autonomous-base', status: 'ready-for-flash-confirmation', projectId: active.id, binding: JSON.parse(JSON.stringify(workspace.binding)),
    intake: intake(), targets: targets(null), authorization: { allowAutomaticCalibration: true, allowHighRiskMappedChanges: true, finalFlashSeparate: true, confirmedFacts: {} },
    finalRevision: { name: 'Autonomous-Base.bin', path: path.join(active.folder, 'Revisions', 'Autonomous-Base.bin'), sha256: 'base' }, handoff: { folder: path.join(active.folder, 'Handoff', 'base') }
  };
}
function writeValidationLog(file, options = {}) {
  const headers = ['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','stft2','ltft1','ltft2','spark','voltage','load','fuelPressure','knockRetard','commandedEqRatio','widebandAfr','misfireTotal','mafFrequency','injectorDuty','desiredIdle','commandedGear','actualGear','shiftTime','tccSlip','marker'];
  const rows = [headers.join(',')];
  const total = 420;
  for (let index = 0; index < total; index += 1) {
    let zone = 'idle';
    if (index >= 80 && index < 240) zone = 'cruise';
    else if (index >= 240 && index < 330) zone = 'accel';
    else if (index >= 330) zone = 'wot';
    const idle = zone === 'idle', cruise = zone === 'cruise', accel = zone === 'accel', wot = zone === 'wot';
    const rpm = idle ? (options.good ? 750 + ((index % 5) - 2) * 8 : 680 + ((index % 7) - 3) * 18) : cruise ? 1800 : accel ? 2800 + (index % 50) * 20 : 4200;
    const speed = idle ? 0 : cruise ? 45 : accel ? 55 : 75;
    const tps = idle ? 8 : cruise ? 24 : accel ? 58 : 88;
    const load = idle ? 0.24 : cruise ? 0.42 : accel ? 0.68 : 0.9;
    const trim = options.good ? 1.8 : 7.5;
    const targetAfr = 12.6;
    const afr = wot ? targetAfr + (options.good ? 0.18 : 0.9) : 14.7;
    const knock = wot ? (options.good ? 0.4 : 3.2) : 0;
    const voltage = options.unsafe ? 10.9 : 13.8;
    const ect = options.unsafe ? 246 : 192;
    const misfire = options.unsafe && index > 300 ? 150 : 0;
    const gear = idle ? 0 : cruise ? 4 : accel ? (index < 285 ? 2 : 3) : 3;
    const shiftTime = accel && index === 285 ? 0.45 : '';
    rows.push([
      new Date(1700000000000 + index * 100).toISOString(), rpm, speed, ect, 88, tps, Math.round(load * 100), wot ? 70 : cruise ? 28 : 12,
      trim, trim, trim * 0.7, trim * 0.7, wot ? 20 : 24, voltage, load, 58, knock, wot ? 14.7 / targetAfr : 1,
      afr, misfire, wot ? 6500 : 3500, wot ? 78 : 35, 750, gear, gear, shiftTime, cruise ? 20 : 5, zone
    ].join(','));
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${rows.join('\n')}\n`);
  return file;
}
function callbacks(active, workspace) {
  let current = JSON.parse(JSON.stringify(workspace));
  let snapshots = 0, revisions = 0, restored = null;
  return {
    api: {
      createSnapshot(value, payload) { snapshots += 1; return { id: `snapshot-${snapshots}`, name: payload.name }; },
      restoreSnapshot(snapshotId) { restored = snapshotId; current = JSON.parse(JSON.stringify(workspace)); return current; },
      exportRevision(value, options = {}) { revisions += 1; const file = path.join(active.folder, 'Revisions', `${options.suffix || 'ClosedLoop'}-${revisions}.bin`); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, Buffer.alloc(524288, 0x70 + revisions)); return { path: file, name: path.basename(file), sha256: sha(file), checksumStatus: 'valid', compatible: true }; },
      async runCorrection(csvPath) {
        current = JSON.parse(JSON.stringify(current));
        current.modified = { ...(current.modified || {}), [`closed-loop:${revisions}`]: true };
        const revision = this.exportRevision(current, { suffix: 'ClosedLoop-Correction' });
        return { workspace: current, revision, handoff: { folder: path.join(active.folder, 'Handoff', 'closed-loop') }, state: { id: `auto-cycle-${revisions}`, status: 'ready-for-flash-confirmation', totalAppliedCells: 12, stageResults: [{ stageId: 'airflow', appliedCells: 6 }, { stageId: 'fueling', appliedCells: 6 }], finalRevision: revision } };
      }
    },
    get restored() { return restored; },
    get workspace() { return current; }
  };
}

async function cleanClosedLoop(root) {
  const active = projectFixture(root, 'closed-loop-clean');
  const workspace = workspaceFixture(active);
  const base = autonomousRun(active, workspace);
  const baseline = writeValidationLog(path.join(active.folder, 'Logs', 'baseline.csv'), { good: false });
  const validation = writeValidationLog(path.join(active.folder, 'Logs', 'validation.csv'), { good: true });
  const manager = new ClosedLoopTuneManager({ appendActivity: () => {} });
  const svc = callbacks(active, workspace);
  const session = manager.start(active, workspace, base, { maxCycles: 5, targets: targets(baseline), lastStableSnapshotId: 'snapshot-base' });
  assert.equal(session.status, 'waiting-for-log');
  const first = manager.analyze(active, workspace, baseline, { role: 'baseline' });
  assert.equal(first.session.status, 'ready-for-correction');
  assert(first.evaluation.confidence.score >= 70);
  const correction = await executeClosedLoopCorrection({ manager, active, workspace, csvPath: baseline, callbacks: svc.api });
  assert.equal(correction.corrected, true);
  assert.equal(correction.session.status, 'waiting-for-validation-log');
  assert.equal(correction.session.cycleCount, 1);
  const validated = await analyzeClosedLoopValidation({ manager, active, workspace: correction.workspace, csvPath: validation, callbacks: svc.api });
  assert.equal(validated.validated, true);
  assert.equal(validated.session.status, 'converged');
  assert(validated.evaluation.comparison.improvementPercent > 20);
  assert.equal(manager.status(active, validated.workspace, base).readiness.score, 100);
}

async function automaticRollback(root) {
  const active = projectFixture(root, 'closed-loop-rollback');
  const workspace = workspaceFixture(active);
  const base = autonomousRun(active, workspace);
  const baseline = writeValidationLog(path.join(active.folder, 'Logs', 'baseline.csv'), { good: false });
  const unsafe = writeValidationLog(path.join(active.folder, 'Logs', 'unsafe.csv'), { good: false, unsafe: true });
  const manager = new ClosedLoopTuneManager({ appendActivity: () => {} });
  const svc = callbacks(active, workspace);
  manager.start(active, workspace, base, { targets: targets(baseline), lastStableSnapshotId: 'snapshot-base' });
  manager.analyze(active, workspace, baseline, { role: 'baseline' });
  const correction = await executeClosedLoopCorrection({ manager, active, workspace, csvPath: baseline, callbacks: svc.api });
  const result = await analyzeClosedLoopValidation({ manager, active, workspace: correction.workspace, csvPath: unsafe, callbacks: svc.api });
  assert.equal(result.rolledBack, true);
  assert.equal(result.session.status, 'rolled-back');
  assert.equal(svc.restored, correction.session.rollbackSnapshotId);
  assert(result.revision?.name.includes('Rollback'));
}

async function persistenceAndGuards(root) {
  const active = projectFixture(root, 'closed-loop-guards');
  const workspace = workspaceFixture(active);
  const base = autonomousRun(active, workspace);
  const baseline = writeValidationLog(path.join(active.folder, 'Logs', 'baseline.csv'), { good: false });
  const manager = new ClosedLoopTuneManager({ appendActivity: () => {} });
  manager.start(active, workspace, base, { maxCycles: 2, targets: targets(baseline), lastStableSnapshotId: 'snapshot-base' });
  const first = manager.analyze(active, workspace, baseline, { role: 'baseline' });
  assert.throws(() => manager.analyze(active, workspace, baseline, { role: 'baseline' }), /already evaluated/i);
  const restarted = new ClosedLoopTuneManager({ appendActivity: () => {} });
  assert.equal(restarted.load(active).latestEvaluationId, first.evaluation.id);
  const evaluation = evaluateLog(baseline, { targets: targets(baseline) });
  assert(evaluation.coverage.stageConfidence.airflow.score >= 70);
  const readiness = buildProjectReadiness({ workspace, autonomousRun: base, session: restarted.load(active), evaluation });
  assert(readiness.score >= 70);
  const report = restarted.exportReport(active, workspace, base);
  assert(fs.existsSync(report.path));
  const changed = JSON.parse(JSON.stringify(workspace)); changed.binding.binSha256 = 'changed';
  assert.throws(() => restarted.analyze(active, changed, writeValidationLog(path.join(active.folder, 'Logs', 'changed.csv'), { good: true })), /fingerprint changed/i);
}

async function runAll() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-closed-loop-sim-'));
  try {
    await cleanClosedLoop(path.join(root, 'one'));
    await automaticRollback(path.join(root, 'two'));
    await persistenceAndGuards(path.join(root, 'three'));
    console.log('✓ Closed-Loop simulation 1: baseline, automatic correction, validation, and convergence');
    console.log('✓ Closed-Loop simulation 2: unsafe post-correction log and automatic rollback');
    console.log('✓ Closed-Loop simulation 3: duplicate-log guard, restart persistence, readiness, report, and fingerprint stop');
    console.log('All TunIQ beta.19 Closed-Loop Autonomous Tuning simulations passed.');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

if (require.main === module) runAll().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runAll, writeValidationLog, autonomousRun, callbacks };
