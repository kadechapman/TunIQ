> Current build: **TunIQ v1.9.0-beta.5 — OBDLink Re-pair & Direct PCM Hammer Handoff

# TunIQ v1.9.0-beta.1 — Multi-P01 Quick Service

TunIQ is a Windows automotive tuning workspace that keeps vehicles, PCM projects, protected originals, definitions, revisions, logs, diagnostics, and external tuning tools together.

## What changed

- Adds a dedicated second-P01 quick-service workflow.
- Creates or activates a separate project so the unfinished Customline evidence is never reused.
- Builds an exact VATS-disable and electric-fan 210°F on / 190°F off change plan.
- Requires an exact writable OS-matched XDF and a commissioned cell map.
- Supports clearly labeled Fahrenheit or Celsius fan cells, including automatic engineering-unit conversion.
- Creates a new revision only. It does not Test Write or write the PCM automatically.
- Preserves the Tool Finder, public-beta reporting, Intelligent Connection Manager, Session Guard, Safety Vault, and P01 evidence recovery.

## Safety boundary

TunIQ does not guess VATS raw values, fan addresses, units, or unsupported definitions. A read-only commissioning definition cannot be used for these calibration changes. Keep each physical PCM in its own project, verify two matching reads, preserve the original, validate the revision, complete Test Write, and make any real write a separate deliberate action.

See `P01_QUICK_SERVICE.md`, `RELEASE_NOTES_v1.9.0-beta.1.md`, and `TunIQ_v1.9.0-beta.1_TEST_REPORT.md`.


## v1.9.0-beta.5 connection recovery

When Windows exposes Bluetooth COM ports that TunIQ cannot open, the P01 workflow can open Windows pairing, verify a manually selected COM port, or authorize one read-only PCM Hammer Read Properties attempt on that exact port. A successful PCM Hammer result proves the port for the remaining reads and Test Write. Real PCM writes still require the normal verified connection path.
