const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { parseXdf, hydrate, applyTable } = require('../src/xdf');
const checksum = require('../src/checksum');
const { generateProposal, applyApproved } = require('../src/ai-tune');
const { FlashManager, parseIdentityText, classifyPcmHammerResult, validateP01ReadFile } = require('../src/flash');
const { ObdManager } = require('../src/obd');
const { ConnectionDoctor, classifyConnectionError, rankAdapterCandidates } = require('../src/connection-doctor');
const { P01LabManager } = require('../src/p01-lab');
const { normalizeUiPreferences, mergeUiPreferences, rankQuickActions } = require('../src/qol');
const { GarageManager, validateVin, projectVehicleFields, VEHICLE_SCHEMA_VERSION } = require('../src/garage');
const { TuneWorkspaceManager, sameBinding } = require('../src/tune-workspace');
const { TuneEngineManager, buildCoverageMap, buildTunePlan, buildStageProposal, applyStageProposal } = require('../src/tune-engine');
const { AutonomousTuneManager, deriveAutonomousTargets, executeAutonomousTune } = require('../src/autonomous-tune');
const { ClosedLoopTuneManager, evaluateLog, executeClosedLoopCorrection, analyzeClosedLoopValidation } = require('../src/closed-loop-tune');
const { authorization: autonomousAuthorization, services: autonomousServices } = require('./autonomous-tune-simulations');
const { writeValidationLog, autonomousRun: closedLoopAutonomousRun, callbacks: closedLoopCallbacks } = require('./closed-loop-tune-simulations');
const { projectFixture: tuneProjectFixture, workspaceFixture: tuneWorkspaceFixture, writeLog: writeTuneEngineLog, targets: tuneEngineTargets, intake: tuneEngineIntake } = require('./tune-engine-simulations');
const { BetaManager } = require('../src/beta');
const { parseCsvText, importPhoneLog, detectLogSource, parseDurationSeconds } = require('../src/log-import');
const { P01EvidenceManager, PUBLIC_EVIDENCE_REGISTRY } = require('../src/p01-evidence');
const { parseTuneRequest, buildGoalProposal, applyGoalApproved } = require('../src/goal-executor');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { P01AutoManager, discoverExactXdfs, selectGoalMapCandidates } = require('../src/p01-auto');
const zlib = require('zlib');
const { toIpcSafe, safeIpcResult } = require('../src/ipc-safe');
const { bridgeError, normalizeP01RecoveryState, rankAlternatePorts } = require('../src/com-recovery');
const { profilesForOperation, safeToRetryProfile, hasCommunicationActivity } = require('../src/pcmhammer-integrated');
const { runStartupRecoverySimulations } = require('./startup-recovery-simulations');
const { runRealCliCommandRecoverySimulations } = require('./real-cli-command-recovery-simulations');
const { runIntegratedDefinitionPipelineSimulations } = require('./integrated-definition-pipeline-simulations');
const { runP01SetupCompletionSimulations } = require('./p01-setup-completion-simulations');
const { runWorkspaceStateReconciliationSimulations } = require('./workspace-state-reconciliation-simulations');
const { runP01FinalizerSimulations } = require('./p01-finalizer-simulations');
const { runP01FinalCompletionHarness } = require('./p01-final-completion-harness');
const { runP01TestWriteRuntimeRecoverySimulations } = require('./p01-test-write-runtime-recovery-simulations');
const { runP01ContinuityLockSimulations } = require('./p01-continuity-lock-simulations');
const { runReleasePromotionSimulations } = require('./release-promotion-simulations');
const { runQolNavigationSimulations } = require('./qol-navigation-simulations');
const { runHardwareSessionDoctorSimulations } = require('./hardware-session-doctor-simulations');
const { runExclusiveSessionSafetyVaultSimulations } = require('./exclusive-session-safety-vault-simulations');
const { scanDefinitionSources, buildXdfFromUniversalTunerXml, createDefinitionJob } = require('../src/definition-pipeline');

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-tests-'));
const pass = name => console.log(`✓ ${name}`);
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 6000) { const start = Date.now(); while (Date.now() - start < timeout) { const value = predicate(); if (value) return value; await sleep(20); } throw new Error('Timed out waiting for asynchronous test condition.'); }

function testXdfAndChecksums() {
  const folder = path.join(tempRoot, 'xdf'); fs.mkdirSync(folder, { recursive: true });
  const binFile = path.join(folder, 'test.bin'); const xdfFile = path.join(folder, 'test.xdf');
  const bin = Buffer.alloc(512, 0);
  bin.writeUInt16LE(100, 0x10);
  bin.writeUInt8(0b10101100, 0x20);
  bin.writeFloatLE(1.5, 0x30);
  [10,20,30,40].forEach((value,index) => bin.writeUInt8(value, 0x40 + [0,2,4,6][index]));
  fs.writeFileSync(binFile, bin);
  fs.writeFileSync(xdfFile, `<?xml version="1.0"?>
<XDFHEADER><deftitle>Test OS 12212156</deftitle><baseoffset>0</baseoffset></XDFHEADER>
<CATEGORY index="1" name="Fuel"/>
<XDFCONSTANT uniqueid="scaled" title="Scaled Constant"><CATEGORYMEM index="1"/><EMBEDDEDDATA mmedaddress="0x10" mmedelementsizebits="16" lsbfirst="1"/><MATH equation="X*0.5" units="unit"/></XDFCONSTANT>
<XDFCONSTANT uniqueid="flag" title="Masked Flag"><EMBEDDEDDATA mmedaddress="0x20" mmedelementsizebits="8" bitmask="0x0C"/><MATH equation="X"/></XDFCONSTANT>
<XDFCONSTANT uniqueid="float" title="Float Constant"><EMBEDDEDDATA mmedaddress="0x30" mmedelementsizebits="32" float="1"/><MATH equation="X"/></XDFCONSTANT>
<XDFTABLE uniqueid="stride" title="Stride Table"><XDFAXIS id="x"><indexcount>2</indexcount><LABEL index="0" value="A"/><LABEL index="1" value="B"/></XDFAXIS><XDFAXIS id="y"><indexcount>2</indexcount><LABEL index="0" value="1000"/><LABEL index="1" value="2000"/></XDFAXIS><XDFAXIS id="z"><EMBEDDEDDATA mmedaddress="0x40" mmedelementsizebits="8" mmedrowcount="2" mmedcolcount="2" mmedmajorstridebits="32" mmedminorstridebits="16"/><MATH equation="X" units="%"/></XDFAXIS></XDFTABLE>
<XDFCHECKSUM id="sum" title="Sum 8" algorithm="sum8"><EMBEDDEDDATA mmedaddress="0xF0" mmedelementsizebits="8"/><RANGE start="0x00" end="0xF0"/></XDFCHECKSUM>`);
  const parsed = parseXdf(xdfFile);
  assert.equal(parsed.tables.length, 4);
  assert.equal(parsed.categories['1'], 'Fuel');
  assert.equal(parsed.checksums.length, 1);
  const byId = Object.fromEntries(parsed.tables.map(item => [item.id, item]));
  assert.equal(hydrate(byId.scaled, bin).values[0][0], 50);
  assert.equal(hydrate(byId.flag, bin).values[0][0], 3);
  assert(Math.abs(hydrate(byId.float, bin).values[0][0] - 1.5) < 1e-6);
  assert.deepEqual(hydrate(byId.stride, bin).values, [[10,20],[30,40]]);
  const edited = Buffer.from(bin);
  const flag = hydrate(byId.flag, edited); flag.values[0][0] = 1; applyTable(edited, flag, new Set(['0:0']));
  assert.equal(edited.readUInt8(0x20), 0b10100100, 'bit-mask write must preserve unrelated bits');
  const float = hydrate(byId.float, edited); float.values[0][0] = 2.25; applyTable(edited, float, new Set(['0:0']));
  assert(Math.abs(edited.readFloatLE(0x30) - 2.25) < 1e-6);
  const corrected = checksum.correctDefinitions(edited, parsed.checksums);
  assert.equal(checksum.verifyDefinitions(corrected.buffer, parsed.checksums)[0].valid, true);
  pass('enhanced XDF parse/hydrate/write and explicit checksum correction');
}

function testChecksumReportsAndDiff() {
  const folder = path.join(tempRoot, 'reports'); fs.mkdirSync(folder, { recursive: true });
  const good = path.join(folder, 'good.txt'), unknown = path.join(folder, 'unknown.txt');
  fs.writeFileSync(good, 'Checksum 1: valid\nSegment layout: passed\n');
  fs.writeFileSync(unknown, 'Checksum 1: unknown or unsupported\n');
  assert.equal(checksum.parseUniversalPatcherReport(good).valid, true);
  assert.equal(checksum.parseUniversalPatcherReport(unknown).valid, false);
  const a = Buffer.alloc(128, 0), b = Buffer.from(a); b[5] = 1; b[6] = 2; b[50] = 3;
  const diff = checksum.diffBuffers(a,b); assert.equal(diff.changedBytes,3); assert.equal(diff.ranges.length,2);
  pass('Universal Patcher report gating and byte-range comparison');
}

function writeAiCsv(file) {
  const headers=['timestamp','rpm','speed','ect','iat','tps','map','maf','stft1','ltft1','spark','voltage','load','fuelPressure','knockRetard','commandedEqRatio','widebandAfr','misfireTotal','mafFrequency','injectorDuty','desiredIdle','commandedGear','actualGear','inputShaftSpeed','outputShaftSpeed','transSlip','shiftTime','tccSlip','torqueManagement','marker'];
  const rows=[headers.join(',')];
  for(let i=0;i<90;i++) rows.push([new Date(Date.now()+i*100).toISOString(),1500,35,190,85,25,40,20,3.2,2.4,24,13.9,35,'',0,1,14.7,0,4000,28,750,3,3,1450,1200,20,'',10,0,''].join(','));
  fs.writeFileSync(file, rows.join('\n')+'\n');
}
function testAiExecution() {
  const csv=path.join(tempRoot,'ai.csv'); writeAiCsv(csv);
  const workspace={mode:'xdf',projectId:'p1',tables:{maf:{name:'MAF Calibration',description:'MAF frequency',rowHeaders:['Value'],colHeaders:['2000','4000','6000'],values:[[10,20,30]]},ve:{name:'Main VE',rowHeaders:['1000','1500'],colHeaders:['30','40'],values:[[60,65],[70,75]]},idle:{name:'Base Running Airflow',rowHeaders:['160','190','220'],colHeaders:['P/N'],values:[[4],[5],[6]]}},stock:null,modified:{}};
  workspace.stock=JSON.parse(JSON.stringify(workspace.tables));
  const proposal=generateProposal({csvPath:csv,workspace,activeProject:{id:'p1',name:'Test'},analysis:{findings:[]}});
  assert.equal(proposal.blocked,false); assert(proposal.proposals.length>=2,'expected MAF/VE proposals');
  const picked=proposal.proposals[0]; const applied=applyApproved(JSON.parse(JSON.stringify(workspace)),proposal,[picked.id]);
  assert.equal(applied.applied.length,1); assert.notEqual(applied.workspace.tables[picked.tableKey].values[picked.row][picked.col],picked.current);
  assert.equal(applied.workspace.modified[`${picked.tableKey}:${picked.row}:${picked.col}`],true);
  pass('AI log-to-exact-cell proposal and explicit approval execution');
}

async function testFlashManager() {
  const folder=path.join(tempRoot,'flash-project'); fs.mkdirSync(path.join(folder,'Originals'),{recursive:true}); fs.mkdirSync(path.join(folder,'Revisions'),{recursive:true});
  const original=path.join(folder,'Originals','stock.bin'), revision=path.join(folder,'Revisions','rev.bin'); fs.writeFileSync(original,Buffer.alloc(P01_BIN_SIZE,1)); fs.writeFileSync(revision,Buffer.alloc(P01_BIN_SIZE,2));
  const data=path.join(tempRoot,'flash-data'); const events=[]; const order=[]; let identity=null; let readInfo=null; let complete=null;
  const active={id:'pflash',name:'Bench PCM',folder,controller:'P01',bin:original};
  const manager=new FlashManager({dataRoot:()=>data,getActiveProject:()=>active,getToolPath:()=>'',getDeviceStatus:()=>({connection:{port:'COM4',voltage:13.5}}),releasePort:async({port})=>{order.push(`release:${port}`);return{released:true}},probePortLock:async({port})=>{order.push(`probe:${port}`);return{available:true,locked:false}},appendActivity:(type,payload)=>events.push({type,payload}),emit:()=>{},onIdentifyComplete:async value=>{identity=value},onReadComplete:async(file,info)=>{readInfo={file,info}},onSessionComplete:async session=>{complete=session}});
  const mock=path.join(__dirname,'mock-pcmhammer-cli.js');
  const mockExe=path.join(tempRoot,'PcmHammerCLI'); try{fs.symlinkSync(process.execPath,mockExe)}catch{}
  const mockKernels=path.join(tempRoot,'Kernels'); fs.mkdirSync(mockKernels,{recursive:true}); fs.writeFileSync(path.join(mockKernels,'Kernel-P01.bin'),Buffer.alloc(64,1)); fs.writeFileSync(path.join(mockKernels,'Loader-P01.bin'),Buffer.alloc(64,2));
  process.env.PCMHAMMER_MOCK_SCENARIO='success'; process.env.PCMHAMMER_MOCK_READ_BYTE='90';
  const probe=await manager.probe({executable:mockExe,prefixArgs:[mock]});
  assert(probe.capabilities.readProperties&&probe.capabilities.read&&probe.capabilities.testWrite&&probe.capabilities.writeCalibration);
  assert.equal(Object.prototype.hasOwnProperty.call(probe.capabilities,'identify'),false,'CLI capability detection must not require a command named identify');
  manager.saveDevice('COM4');
  await manager.start('readProperties',{}); await waitFor(()=>!manager.session); assert.equal(identity.controller,'P01'); assert.equal(identity.os,'12212156'); assert.equal(identity.hardwareId,'9386530'); assert.equal(identity.serviceNumber,'12200411'); assert.equal(identity.voltage,13.4);
  await manager.start('read',{}); await waitFor(()=>!manager.session); assert(readInfo&&fs.existsSync(readInfo.file)); assert.equal(readInfo.info.size,P01_BIN_SIZE); assert.deepEqual(order.slice(0,2),['release:COM4','release:COM4']); assert(!order.some(item=>item.startsWith('probe:')),'integrated pipeline must not perform a second lock-probe open'); assert.equal(manager.status().portOwner.owner,'idle');
  await manager.start('testWrite',{input:revision,voltage:13.5}); await waitFor(()=>!manager.session); assert.equal(complete.testWritePassed,true); assert.equal(complete.state,'complete');
  await manager.start('writeCalibration',{input:revision,confirmation:'WRITE Bench PCM',checksumApproved:true,voltage:13.5}); await waitFor(()=>!manager.session); const write=manager.getHistory().find(item=>item.operation==='writeCalibration'); assert.equal(write.state,'complete'); assert.equal(write.verified,true);
  const locked=new FlashManager({dataRoot:()=>path.join(tempRoot,'flash-locked'),getActiveProject:()=>active,getToolPath:()=>'',getDeviceStatus:()=>({connection:{port:'COM4',voltage:13.5}}),releasePort:async()=>({released:true}),appendActivity:()=>{},emit:()=>{}});
  await locked.probe({executable:mockExe,prefixArgs:[mock]}); locked.saveDevice('COM4');
  process.env.PCMHAMMER_MOCK_SCENARIO='locked';
  await locked.start('readProperties',{}); await waitFor(()=>!locked.session);
  const lockedResult=locked.getHistory().find(item=>item.operation==='readProperties'); assert.equal(lockedResult.stopCode,'adapter-locked'); assert.equal(locked.status().portOwner.owner,'idle');
  process.env.PCMHAMMER_MOCK_SCENARIO='success';
  const realText='PCM Hammer\nVersion: 2.0.0\nVoltage: 12.1V\nVIN: 1GCEC14T01Z123456\nOSID: 16265175\nDescription: P01 Gen III PCM, Service No 16263494\nHardware ID: 872434777\nController: P01';
  const parsed=parseIdentityText(realText); assert.deepEqual({os:parsed.os,hardwareId:parsed.hardwareId,serviceNumber:parsed.serviceNumber,controller:parsed.controller,voltage:parsed.voltage},{os:'16265175',hardwareId:'872434777',serviceNumber:'16263494',controller:'P01',voltage:12.1});
  assert.equal(classifyPcmHammerResult('testWrite','Test Write completed successfully. No changes were written.',0).success,true);
  pass('PCM Hammer 2.0 integrated commands, direct COM lease, result parsing, strict read, Test Write, and verified write gating');
}

async function testVirtualLogger() {
  const data=path.join(tempRoot,'obd-data'), project=path.join(tempRoot,'obd-project'); fs.mkdirSync(project,{recursive:true});
  const active={id:'pobd',name:'Virtual Vehicle',folder:project,vehicle:'Test',controller:'P01',os:'12212156',binInfo:{name:'stock.bin'}};
  const manager=new ObdManager({dataRoot:()=>data,getActiveProject:()=>active,appendActivity:()=>{},logStartup:()=>{}});
  await manager.connect({port:'virtual-demo'}); assert(manager.getStatus().connected);
  const session=manager.startLog({profile:'baseline',name:'Integration'}); manager.markLog('start test');
  for(let i=0;i<70;i++) await manager.sample();
  const stopped=await manager.stopLog(); assert(stopped.samples===70); assert(fs.existsSync(session.csvPath)); assert(stopped.analysis.sampleCount===70); assert(fs.readFileSync(session.csvPath,'utf8').includes('commandedEqRatio'));
  await manager.disconnect();
  pass('persistent log schema, virtual enhanced PIDs, markers, CSV, and AI analysis');
}


function testPublicBetaFoundation() {
  const data = path.join(tempRoot, 'beta-data'); fs.mkdirSync(data, { recursive: true });
  const csv = path.join(tempRoot, 'beta-log.csv');
  fs.writeFileSync(csv, 'timestamp,rpm,vin,email,marker,latitude\n2026-07-18T00:00:00Z,800,1GNEK13Z32R123456,test@example.com,Driver test,29.4\n');
  let settings = { detailLevel: 'beginner' };
  const active = { id: 'pbeta', name: 'Personal Truck', vehicle: 'Truck', controller: 'P01', os: '12212156', vin: '1GNEK13Z32R123456', notes: 'email test@example.com' };
  const manager = new BetaManager({ appVersion: '1.7.0-beta.23', dataRoot: () => data, getActiveProject: () => active, getSettings: () => settings, getDeviceStatus: () => ({ connection: { adapter: 'OBDLink MX+', port: 'COM7', vin: active.vin } }), getWorkspaceSummary: () => ({ activeProject: active }), getFlashStatus: () => ({ configured: true }), getActivity: () => [], appendActivity: () => {} });
  assert.equal(manager.state().agreementAccepted, false);
  manager.acceptAgreement(true);
  assert.equal(manager.state().agreementAccepted, true);
  assert.equal(manager.state().support.flashing.status, 'experimental');
  assert.throws(() => manager.assertFlashAllowed('writeCalibration', { controller: 'P01' }), /Experimental/);
  manager.savePreferences({ improvementOptIn: true, shareSanitizedLogs: true, allowExperimentalHardware: true });
  settings = { detailLevel: 'advanced' };
  assert.equal(manager.assertFlashAllowed('writeCalibration', { controller: 'P01' }).status, 'experimental');
  const saved = manager.saveOutcome({ csvPath: csv, rating: 'Improved', newDtcs: 'None', notes: 'Owner test@example.com VIN 1GNEK13Z32R123456', consentToImprove: true });
  assert.equal(saved.state.queueCount, 1);
  const queueText = JSON.stringify(manager.queue());
  assert(!queueText.includes('test@example.com'));
  assert(!queueText.includes('1GNEK13Z32R123456'));
  assert(!queueText.includes('latitude'));
  const reportFile = path.join(tempRoot, 'report.tuniqreport'); manager.exportDiagnostic(reportFile, { description: 'VIN 1GNEK13Z32R123456 test@example.com' });
  const report = JSON.parse(zlib.gunzipSync(fs.readFileSync(reportFile)).toString('utf8'));
  const reportText = JSON.stringify(report);
  assert(!reportText.includes('test@example.com'));
  assert(!reportText.includes('1GNEK13Z32R123456'));
  assert(!reportText.includes('raw BIN'));
  pass('public beta agreement, compatibility gates, opt-in queue, redaction, and diagnostic package');
}


function testObdLinkPhoneImport() {
  const csv = path.join(tempRoot, 'obdlink-phone.csv');
  const rows = ['Time (sec),Engine RPM (rpm),Vehicle speed (km/h),Engine coolant temperature (deg C),Throttle position (%),Manifold absolute pressure (kPa),Mass air flow rate (g/s),Short term fuel trim Bank 1 (%),Long term fuel trim Bank 1 (%),Control module voltage (V),VIN,Latitude,Longitude'];
  for (let i = 0; i < 40; i++) rows.push(`${i * 0.5},${800 + i * 20},${80},${90},${10},${40},${12},${2},${3},${13.8},1GNEK13Z32R123456,29.4,-98.9`);
  fs.writeFileSync(csv, rows.join('\n') + '\n');
  const parsed = parseCsvText(fs.readFileSync(csv, 'utf8'), { profile: 'baseline' });
  assert.equal(parsed.rows.length, 40);
  assert(Math.abs(parsed.rows[0].speed - 49.70968) < 0.01);
  assert.equal(parsed.rows[0].ect, 194);
  assert(parsed.privateRemoved.some(value => /VIN/i.test(value)));
  assert(parsed.privateRemoved.some(value => /Latitude/i.test(value)));
  const folder = path.join(tempRoot, 'phone-project'); fs.mkdirSync(folder, { recursive: true });
  const imported = importPhoneLog({ sourceFile: csv, activeProject: { id: 'phone', name: 'Phone Truck', folder, vehicle: 'Truck', controller: 'P01', os: '12212156' }, profile: 'baseline' });
  assert(fs.existsSync(imported.csvPath));
  assert(fs.existsSync(imported.metaPath));
  assert.equal(imported.samples, 40);
  const normalized = fs.readFileSync(imported.csvPath, 'utf8');
  assert(!normalized.includes('1GNEK13Z32R123456'));
  assert(!normalized.includes('Latitude'));
  pass('OBDLink mobile CSV mapping, unit conversion, privacy removal, and project import');
}

function testNaturalLanguageGoalExecutor() {
  const parsed = parseTuneRequest('Give it a ghost cam tune, raise max rev to 6000 RPM, and raise max speed to 190 MPH');
  assert.equal(parsed.intents.length, 3);
  const workspace = { mode: 'xdf', projectId: 'pgoal', modified: {}, tables: {
    limits: { name: 'Engine & Speed Limits', unit: '', rowHeaders: ['Rev limiter fuel cut','Rev limiter resume','Speed limiter'], colHeaders: ['Value'], values: [[5800],[5700],[130]] }
  } };
  const proposal = buildGoalProposal({ request: parsed, workspace, activeProject: { id: 'pgoal', name: 'Goal Truck', controller: 'P01', os: '12212156' }, confirmations: { valvetrainVerified: true, tireRatingMph: 200, drivelineVerified: true, brakesVerified: true, closedCourse: true, ghostCamRisksAccepted: true }, ruleFolders: [] });
  assert.equal(proposal.summary.actions, 3);
  assert.equal(proposal.summary.readyActions, 2);
  assert.equal(proposal.summary.blockedActions, 1);
  const revCut = proposal.proposals.find(item => item.actionType === 'rev-limit' && /fuel cut/i.test(item.rowLabel));
  const revResume = proposal.proposals.find(item => item.actionType === 'rev-limit' && /resume/i.test(item.rowLabel));
  const speed = proposal.proposals.find(item => item.actionType === 'speed-limit');
  assert.equal(revCut.proposed, 6000);
  assert.equal(revResume.proposed, 5800);
  assert.equal(speed.proposed, 190);
  const applied = applyGoalApproved(JSON.parse(JSON.stringify(workspace)), proposal, [revCut.id, speed.id]);
  assert.equal(applied.workspace.tables.limits.values[0][0], 6000);
  assert.equal(applied.workspace.tables.limits.values[2][0], 190);
  assert.equal(applied.workspace.tables.limits.values[1][0], 5700, 'unapproved resume cell must remain unchanged');
  const blocked = buildGoalProposal({ request: 'set max speed to 190 mph', workspace, activeProject: { id: 'pgoal', name: 'Goal Truck', controller: 'P01', os: '12212156' }, confirmations: {}, ruleFolders: [] });
  assert.equal(blocked.actions[0].status, 'blocked');
  assert(blocked.actions[0].requirements.length >= 4);
  pass('natural-language goal parsing, exact limiter cells, approvals, and high-risk safety gates');
}


function testP01Commissioning() {
  const folder = path.join(tempRoot, 'p01-commissioning');
  for (const sub of ['Originals','Definitions','Revisions','Reports']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const first = path.join(folder, 'Originals', 'read-one.bin');
  const second = path.join(folder, 'Originals', 'read-two.bin');
  const revision = path.join(folder, 'Revisions', 'safe-revision.bin');
  const xdf = path.join(folder, 'Definitions', 'P01_OS_12212156.xdf');
  fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x31));
  fs.copyFileSync(first, second);
  fs.writeFileSync(revision, Buffer.alloc(P01_BIN_SIZE, 0x32));
  fs.writeFileSync(xdf, '<XDFHEADER><deftitle>P01 12212156 verified definition</deftitle></XDFHEADER>');
  const sha = file => require('crypto').createHash('sha256').update(fs.readFileSync(file)).digest('hex');
  const active = {
    id: 'p01-proof', name: 'P01 Bench', folder, controller: 'P01', os: '12212156',
    bin: first, binInfo: { name: path.basename(first), size: P01_BIN_SIZE, sha256: sha(first) },
    xdf, xdfInfo: { name: path.basename(xdf), title: 'P01 12212156 verified definition', tableCount: 3, warnings: [] }
  };
  let workspace = null;
  const manager = new P01CommissioningManager({ getActiveProject: () => active, getCalibrationWorkspace: () => workspace, getFlashStatus: () => ({ configured: true, backend: { official: true, product: 'PCM Hammer', version: '2.0.0', major: 2, sha256: 'mock-backend' } }), appendActivity: () => {} });
  manager.recordIdentity({ controller: 'P01', os: '12212156', hardwareId: '9386530', serviceNumber: '12200411', vin: '1GCEC14T01Z123456' });
  manager.recordRead(first, {}, { id: 'read-a', device: 'MOCK' });
  let status = manager.status(active, revision);
  assert.equal(status.dualReadVerified, false);
  manager.recordRead(second, {}, { id: 'read-b', device: 'MOCK' });
  workspace = { mode: 'xdf', projectId: active.id, sourceBinSha256: sha(first), sourceXdfSha256: sha(xdf), mappingSummary: { loaded: 3, warnings: [] }, tables: { limits: { name: 'Limiter Parameters', rowHeaders: ['Fuel Cut RPM','Fuel Resume RPM','Vehicle Speed Limiter MPH'], colHeaders: ['Value'], values: [[5600],[5400],[98]] } } };
  status = manager.status(active, revision);
  assert.equal(status.dualReadVerified, true);
  assert.equal(status.readyForAi, false, 'definition must be explicitly confirmed');
  manager.confirmDefinition({ typedOs: '12212156', acknowledged: true });
  status = manager.status(active, revision);
  assert.equal(status.readyForAi, true);
  const candidate = buildGoalProposal({ request: 'set rev limiter to 6000 rpm and speed limiter to 120 mph', workspace, activeProject: active, confirmations: { valvetrainVerified: true }, ruleFolders: [] });
  manager.confirmGoalMap(candidate, candidate.actions.map(item => item.id));
  status = manager.status(active, revision);
  assert(status.parameterMap?.actions?.['rev-limit']);
  const commissioned = buildGoalProposal({ request: 'set rev limiter to 6000 rpm and speed limiter to 120 mph', workspace, activeProject: active, confirmations: { valvetrainVerified: true }, ruleFolders: [], parameterMap: status.parameterMap });
  const approved = commissioned.proposals.filter(item => !item.blocked).map(item => item.id);
  assert(commissioned.proposals.every(item => item.confidence === 'commissioned-os-map'));
  assert.equal(manager.assertGoalProposalMapped(commissioned, approved), true);
  assert.equal(status.readyForTestWrite, false, 'revision still needs exact validation');
  manager.recordValidation({ targetFile: revision, targetFileName: path.basename(revision), targetFileSha256: sha(revision), compatible: true, checksumStatus: 'valid', validatedAt: new Date().toISOString() });
  status = manager.assertOperationReady('testWrite', revision);
  assert.equal(status.readyForTestWrite, true);
  manager.recordFlashSession({ id: 'tw-1', operation: 'testWrite', state: 'complete', verified: true, testWritePassed: true, input: revision, device: 'MOCK', voltage: 13.5, finishedAt: new Date().toISOString() });
  status = manager.assertOperationReady('writeCalibration', revision);
  assert.equal(status.readyForWrite, true);
  const mismatchFolder = path.join(tempRoot, 'p01-mismatch');
  for (const sub of ['Originals','Reports']) fs.mkdirSync(path.join(mismatchFolder, sub), { recursive: true });
  const m1 = path.join(mismatchFolder, 'Originals', 'one.bin'), m2 = path.join(mismatchFolder, 'Originals', 'two.bin');
  fs.writeFileSync(m1, Buffer.alloc(P01_BIN_SIZE, 1)); fs.writeFileSync(m2, Buffer.alloc(P01_BIN_SIZE, 2));
  const mismatchActive = { id: 'p01-mismatch', name: 'Mismatch', folder: mismatchFolder, controller: 'P01', os: '12212156', bin: m1 };
  const mismatch = new P01CommissioningManager({ getActiveProject: () => mismatchActive, getCalibrationWorkspace: () => null, getFlashStatus: () => ({ configured: true, backend: { official: true, major: 2, version: '2.0.0' } }), appendActivity: () => {} });
  mismatch.recordIdentity({ controller: 'P01', os: '12212156', hardwareId: '9386530', serviceNumber: '12200411', vin: '1GCEC14T01Z123456' });
  mismatch.recordRead(m1, {}, { id: 'read-a' }); mismatch.recordRead(m2, {}, { id: 'read-b' });
  const mismatchStatus = mismatch.status(mismatchActive);
  assert.equal(mismatchStatus.dualReadVerified, false);
  assert.equal(mismatchStatus.readMismatch, true);
  assert.throws(() => mismatch.assertAiReady(), /reads? (?:do not|match)|two full P01 reads|No two P01 reads match/i);
  const m3 = path.join(mismatchFolder, 'Originals', 'three.bin'); fs.copyFileSync(m1, m3);
  mismatch.recordRead(m3, {}, { id: 'read-c' });
  const unresolved = mismatch.status(mismatchActive);
  assert.equal(unresolved.dualReadVerified, false, 'a third read must not create a hidden two-of-three majority');
  assert.equal(unresolved.readPair.status, 'awaiting-second');
  const partial = path.join(mismatchFolder, 'Originals', 'partial.bin'); fs.writeFileSync(partial, Buffer.alloc(100));
  assert.throws(() => mismatch.recordRead(partial, {}, { id: 'partial' }), /expected exactly 524288 bytes/);
  pass('P01 identity, exactly two matching 524,288-byte reads, exact-OS XDF binding, validation, and explicit Test Write proof');
}


function testP01EvidenceIntegration() {
  const publicLogs = PUBLIC_EVIDENCE_REGISTRY.filter(item => item.type === 'live-log');
  assert.equal(publicLogs.length, 5, 'registry must contain five distinct public log sessions');
  assert.equal(publicLogs.filter(item => item.confidence === 'explicit-p01').length, 3);
  assert.equal(publicLogs.filter(item => item.confidence === 'family-unverified').length, 2);
  assert(PUBLIC_EVIDENCE_REGISTRY.some(item => item.os === '12225074' && item.type === 'definition'));
  assert(PUBLIC_EVIDENCE_REGISTRY.some(item => item.id === 'tool-universal-patcher'));

  const loggerText = [
    'PCM Logger 018',
    'Profile: Fuel Trims',
    'Clock Time, Elapsed Time, Engine Speed, Short Term Fuel Trim Bank 1, Short Term Fuel Trim Bank 2, Long Term Fuel Trim Bank 1, Long Term Fuel Trim Bank 2, Fueling Mode, Battery Voltage',
    ...Array.from({length: 30}, (_, index) => `17:00:${String(index).padStart(2,'0')}, 00:00:${String(index).padStart(2,'0')}.000, ${800 + index}, ${index % 4}, ${index % 3}, 2, 3, Closed Loop, 13.8`)
  ].join('\n');
  const logger = parseCsvText(loggerText, { profile: 'fuelTrims' });
  assert.equal(logger.source.format, 'pcm-logger');
  assert.equal(logger.preambleLinesSkipped, 2);
  assert.equal(logger.rows.length, 30);
  assert.equal(logger.rows[0].stft2, 0);
  assert.equal(logger.rows[0].ltft2, 3);
  assert(parseDurationSeconds('00:01:02.500') === 62.5);

  const torqueText = [
    'Device Time,Engine RPM (rpm),Vehicle speed (km/h),Long Term Fuel Trim Bank 1 (%),Long Term Fuel Trim Bank 2 (%),EGR Voltage (V),VIN,Latitude,Longitude',
    ...Array.from({length: 25}, (_, index) => `${index},${900+index},80,2,3,2.5,1GNEK13Z32R123456,29.4,-98.9`)
  ].join('\n');
  const torque = parseCsvText(torqueText, { profile: 'fuelTrims' });
  assert.equal(torque.source.format, 'torque');
  assert.equal(torque.rows[0].ltft2, 3);
  assert.equal(torque.rows[0].widebandVoltage, 2.5);
  assert(torque.privateRemoved.some(value => /VIN/i.test(value)));
  assert(torque.privateRemoved.some(value => /Latitude/i.test(value)));

  const evidenceRoot = path.join(tempRoot, 'p01-evidence');
  const sourceCsv = path.join(evidenceRoot, '1123.csv');
  fs.mkdirSync(evidenceRoot, { recursive: true });
  fs.writeFileSync(sourceCsv, torqueText);
  const active = { id: 'evidence-p01', name: 'P01 Evidence', folder: evidenceRoot, controller: 'P01', os: '12225074' };
  const manager = new P01EvidenceManager({ dataRoot: () => evidenceRoot, getActiveProject: () => active, appendActivity: () => {} });
  const imported = manager.importFile(sourceCsv, { sourceId: 'log-p01-12225074-1123', profile: 'fuelTrims' });
  assert.equal(imported.controller, 'P01');
  assert.equal(imported.os, '12225074');
  assert.equal(imported.trainingEligible, false);
  assert(imported.trainingBlockers.some(value => /before\/after/i.test(value)));
  assert(fs.existsSync(imported.normalizedPath));
  const sanitized = fs.readFileSync(imported.normalizedPath, 'utf8');
  assert(!sanitized.includes('1GNEK13Z32R123456'));
  const duplicate = manager.importFile(sourceCsv, { sourceId: 'log-p01-12225074-1123' });
  assert.equal(duplicate.duplicate, true);
  const listed = manager.list();
  assert.equal(listed.summary.publicLogSessions, 5);
  assert.equal(listed.summary.importedItems, 1);
  pass('P01 public evidence registry, PCM Logger/Torque parsing, privacy stripping, OS compatibility, and fingerprint deduplication');
}


function testP01OneClickCommissioning() {
  const folder = path.join(tempRoot, 'p01-auto');
  for (const sub of ['Definitions','Reports']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const active = { id: 'p01-auto', name: 'Guided Bench', folder, controller: 'P01', os: '12212156' };
  const manager = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'process-a' });
  let state = manager.begin({ request: 'ghost cam, rev limiter 6000 rpm, speed limiter 190 mph', voltage: 13.5, exactXdfAuthorization: true, autoMapAuthorized: true, autoRevisionAuthorized: true, testWriteAuthorized: true, confirmations: { ghostCamRisksAccepted: true, valvetrainVerified: true, tireRatingMph: 200, drivelineVerified: true, brakesVerified: true, closedCourse: true } });
  assert.equal(state.phase, 'preflight');
  state = manager.completeStep('preflight', 'read-properties', 8, 'preflight complete');
  assert.equal(manager.load().completedSteps.preflight.evidence instanceof Object, true);
  state = manager.advance('waiting-read-1', 20, 'read started');
  const restarted = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'process-b' });
  state = restarted.load();
  assert.equal(state.status, 'paused');
  assert.equal(state.stop.code, 'app-restarted-during-step');
  assert.equal(state.resumePhase, 'read-1');
  state = restarted.resume();
  assert.equal(state.phase, 'read-1');
  state = restarted.pause('needs-xdf', 'definition needed', { resumePhase: 'definition' });
  assert.equal(state.status, 'paused');
  state = restarted.resume();
  assert.equal(state.phase, 'definition');

  const exact = path.join(folder, 'Definitions', 'P01_12212156_verified.xdf');
  const wrong = path.join(folder, 'Definitions', 'P01_12202088_wrong.xdf');
  const xdfBody = osid => `<?xml version="1.0"?><XDFHEADER><deftitle>P01 OS ${osid}</deftitle></XDFHEADER><XDFCONSTANT uniqueid="rpm" title="Engine Speed Limit"><EMBEDDEDDATA mmedaddress="0x10" mmedelementsizebits="16"/><MATH equation="X" units="RPM"/></XDFCONSTANT><XDFCHECKSUM id="sum" title="Sum 8" algorithm="sum8"><EMBEDDEDDATA mmedaddress="0x20" mmedelementsizebits="8"/><RANGE start="0x00" end="0x20"/></XDFCHECKSUM>`;
  fs.writeFileSync(exact, xdfBody('12212156'));
  fs.writeFileSync(wrong, xdfBody('12202088'));
  const discovered = discoverExactXdfs({ os: '12212156', folders: [path.join(folder, 'Definitions')], parseXdf });
  assert.equal(discovered.length, 1);
  assert.equal(discovered[0].name, path.basename(exact));
  assert.equal(discovered[0].checksumCount, 1);

  const workspace = { mode: 'xdf', projectId: active.id, modified: {}, tables: {
    rev: { name: 'Engine Speed Limit', rowHeaders: ['Fuel Cut RPM','Fuel Restore RPM'], colHeaders: ['Value'], values: [[5600],[5400]] },
    speed: { name: 'Vehicle Speed Limiter', rowHeaders: ['Maximum Vehicle Speed'], colHeaders: ['Value'], values: [[120]] },
    spark: { name: 'Idle Spark Advance', rowHeaders: ['176 F Park','194 F Drive'], colHeaders: ['Value'], values: [[15],[11]] },
    air: { name: 'Base Running Airflow Idle', rowHeaders: ['176 F','194 F'], colHeaders: ['Park Neutral'], values: [[5],[4.8]] },
    idle: { name: 'Desired Idle Speed RPM', rowHeaders: ['176 F','194 F'], colHeaders: ['Park Neutral'], values: [[650],[650]] }
  } };
  const proposal = buildGoalProposal({ request: 'ghost cam, rev limiter 6000 rpm, speed limiter 190 mph', workspace, activeProject: active, confirmations: { ghostCamRisksAccepted: true, valvetrainVerified: true, tireRatingMph: 200, drivelineVerified: true, brakesVerified: true, closedCourse: true }, ruleFolders: [] });
  const selection = selectGoalMapCandidates(proposal);
  assert.equal(selection.safeToAutoMap, true);
  assert(selection.actionIds.includes('ghost-cam'));
  assert(selection.actionIds.some(id => id.startsWith('rev-')));
  assert(selection.actionIds.some(id => id.startsWith('speed-')));
  assert(selection.proposalIds.length >= 9);
  pass('Guided P01 exact-step ledger, app restart/resume, exact-OS XDF discovery, and strict unambiguous goal mapping');
}

async function testConnectionDoctorAndOfflineLab() {
  const doctorRoot = path.join(tempRoot, 'connection-doctor'); fs.mkdirSync(doctorRoot, { recursive: true });
  let saved = null;
  const devices = [
    { port: 'COM7', name: 'Standard Serial over Bluetooth link (COM7) Incoming', manufacturer: 'Microsoft', hardwareId: 'BTHENUM\\INCOMING', transport: 'Bluetooth Serial', recognized: false, recommended: false },
    { port: 'COM4', name: 'OBDLink MX+ (COM4) Outgoing', manufacturer: 'ScanTool.net', hardwareId: 'BTHENUM\\OBDLINK_STN', transport: 'Bluetooth Serial', recognized: true, recommended: true }
  ];
  const ranked = rankAdapterCandidates(devices, '');
  assert.equal(ranked[0].port, 'COM4');
  assert.equal(classifyConnectionError('Access to COM4 is denied because it is in use.').code, 'adapter-locked');
  assert.equal(classifyConnectionError('The specified port does not exist.').code, 'stale-com-port');

  const doctor = new ConnectionDoctor({
    dataRoot: () => doctorRoot,
    listDevices: async () => devices,
    releasePort: async () => ({ released: false }),
    probePortLock: async ({ port }) => port === 'COM7' ? ({ available: false, locked: true, message: 'Access denied: port is in use.' }) : ({ available: true, locked: false }),
    probeAdapter: async ({ port, baud }) => {
      assert.equal(port, 'COM4');
      if (baud === 115200) throw new Error('No adapter response at 115200 baud.');
      if (baud !== 38400) throw new Error(`Unexpected baud ${baud}`);
      return { port, baud, adapter: 'OBDLink MX+', description: 'OBDLink MX+', deviceId: 'STN2255 v5.6.19', voltageRaw: '13.4V', protocol: 'AUTO, ISO 15765-4 (CAN 11/500)', vinRaw: '49 02 01 31 47 4E 45 4B 31 33 5A 33 32 52 31 32 33 34 35 36' };
    },
    getPreferred: () => ({ port: '', baud: 0 }),
    savePreferred: value => { saved = value; return value; },
    normalizeProbe: value => ({ port: value.port, baud: value.baud, adapter: value.adapter, description: value.description, firmware: value.deviceId, voltage: 13.4, protocol: value.protocol, vin: '1GNEK13Z32R123456', transport: 'Bluetooth Serial' }),
    appendActivity: () => {}
  });
  const report = await doctor.run({ tryAlternates: true });
  assert.equal(report.status, 'ready');
  assert.equal(report.recommendedConnection.port, 'COM4');
  assert.equal(report.recommendedConnection.baud, 38400);
  assert.equal(saved.port, 'COM4');
  assert(report.attempts.some(item => item.port === 'COM4' && item.baud === 115200 && item.status === 'failed'));
  assert(report.attempts.some(item => item.port === 'COM4' && item.baud === 38400 && item.status === 'passed'));
  assert(fs.existsSync(report.reportFile));
  assert.equal(doctor.status().latest.recommendedConnection.port, 'COM4');

  const lockedDoctor = new ConnectionDoctor({
    dataRoot: () => path.join(doctorRoot, 'locked'), listDevices: async () => [devices[1]], releasePort: async () => ({ released: false }),
    probePortLock: async () => ({ available: false, locked: true, message: 'The port is being used by another process.' }), probeAdapter: async () => { throw new Error('must not probe locked port'); },
    getPreferred: () => ({ port: 'COM4', baud: 115200 }), savePreferred: value => value, normalizeProbe: value => value
  });
  const lockedReport = await lockedDoctor.run({ port: 'COM4', tryAlternates: false });
  assert.equal(lockedReport.status, 'blocked');
  assert(lockedReport.issues.some(item => item.code === 'adapter-locked'));

  const noPortDoctor = new ConnectionDoctor({
    dataRoot: () => path.join(doctorRoot, 'none'), listDevices: async () => [], releasePort: async () => ({}), probePortLock: async () => ({}), probeAdapter: async () => ({}),
    getPreferred: () => ({}), savePreferred: value => value, normalizeProbe: value => value
  });
  const noPort = await noPortDoctor.run();
  assert.equal(noPort.status, 'blocked');
  assert(noPort.issues.some(item => item.code === 'no-serial-port'));

  const labRoot = path.join(tempRoot, 'offline-lab');
  const lab = new P01LabManager({ dataRoot: () => labRoot, appendActivity: () => {} });
  const labReport = lab.runAll();
  assert.equal(labReport.passed, true);
  assert.equal(labReport.scenarios.length, 3);
  assert(labReport.scenarios.every(item => item.passed));
  assert(labReport.scenarios.find(item => item.scenario === 'read-integrity-recovery').steps.some(item => item.id === 'partial-read'));
  assert(fs.existsSync(labReport.reportFile));
  assert.equal(lab.status().passed, true);
  pass('Connection Doctor ranking, lock/baud recovery, durable reports, and offline P01 recovery lab');
}


function testQualityOfLifeFoundation() {
  const normalized = normalizeUiPreferences({ sidebarCollapsed: true, compactDensity: 'yes', lastPage: '../flash', recentPages: ['flash','flash','devices','BAD PAGE'], scrollPositions: { flash: 420.6, devices: -10, '../bad': 50 } });
  assert.equal(normalized.sidebarCollapsed, true);
  assert.equal(normalized.compactDensity, false);
  assert.equal(normalized.lastPage, 'dashboard');
  assert.deepEqual(normalized.recentPages.slice(0,3), ['dashboard','flash','devices']);
  assert.equal(normalized.scrollPositions.flash, 421);
  assert.equal(normalized.scrollPositions.devices, 0);
  assert.equal(Object.prototype.hasOwnProperty.call(normalized.scrollPositions, '../bad'), false);

  const merged = mergeUiPreferences({ aiMode: 'guided', uiPreferences: { lastPage: 'garage', reduceMotion: false } }, { reduceMotion: true, tunePathCollapsed: true });
  assert.equal(merged.aiMode, 'guided');
  assert.equal(merged.uiPreferences.lastPage, 'garage');
  assert.equal(merged.uiPreferences.reduceMotion, true);
  assert.equal(merged.uiPreferences.tunePathCollapsed, true);

  const actions = [
    { id: 'flash', title: 'Flash Center', subtitle: 'PCM Hammer write and recovery', group: 'Pages', priority: 20 },
    { id: 'doctor', title: 'Run Connection Doctor', subtitle: 'OBDLink COM port diagnosis', group: 'Actions', priority: 100 },
    { id: 'garage', title: 'Garage', subtitle: 'Vehicle profiles', group: 'Pages', priority: 10 }
  ];
  assert.equal(rankQuickActions(actions, 'connection obd')[0].id, 'doctor');
  assert.equal(rankQuickActions(actions, 'flash')[0].id, 'flash');
  assert.equal(rankQuickActions(actions, '').length, 3);
  pass('quality-of-life preference validation, merge persistence, and Quick Switch ranking');
}


function testGarageProjectFoundation() {
  const root = path.join(tempRoot, 'garage-foundation');
  const data = path.join(root, 'data');
  const projects = path.join(data, 'Projects');
  fs.mkdirSync(path.join(data, 'Vehicles'), { recursive: true });
  fs.mkdirSync(projects, { recursive: true });
  const activities = [];
  const manager = new GarageManager({ dataRoot: () => data, projectsRoot: () => projects, appendActivity: (type, details) => activities.push({ type, details }) });
  fs.writeFileSync(path.join(data, 'Vehicles', 'vehicles.json'), JSON.stringify([{ id: 'legacy-invalid-vin', name: 'Legacy Import', vin: '1234', updatedAt: '2026-01-01T00:00:00.000Z' }], null, 2));
  const migratedLegacy = manager.list().find(item => item.id === 'legacy-invalid-vin');
  assert.equal(migratedLegacy.vinStatus.status, 'invalid-format');
  assert.equal(migratedLegacy.updatedAt, '2026-01-01T00:00:00.000Z');

  const validVin = validateVin('1M8GDM9AXKP042788');
  assert.equal(validVin.validFormat, true);
  assert.equal(validVin.checkDigitValid, true);
  assert(validVin.yearCandidates.includes(1989));
  const badVin = validateVin('1M8GDM9A1KP042788');
  assert.equal(badVin.validFormat, true);
  assert.equal(badVin.checkDigitValid, false);
  assert.throws(() => manager.save({ name: 'Broken VIN', vin: 'I234' }), /17 characters/);

  const vehicle = manager.save({
    name: 'Tahoe Street Truck', year: '2002', make: 'Chevrolet', model: 'Tahoe', trim: 'LT',
    engine: '5.3 LM7', transmission: '4L60E', drivetrain: '4WD', fuel: '93 octane', controller: 'P01', os: '12212156',
    hardwareId: '9386530', serviceNumber: '12200411', vin: '1M8GDM9AXKP042788', mileage: '182000', tireSize: '295/75R18', rearGear: '3.73',
    modifications: 'camshaft, long-tube headers\n3200 stall', maintenance: '2026-07-01 | 182000 | Oil and filter\n2026-07-10 | 182120 | Replaced freeze plug'
  });
  assert.equal(vehicle.schemaVersion, VEHICLE_SCHEMA_VERSION);
  assert.deepEqual(vehicle.modifications, ['camshaft', 'long-tube headers', '3200 stall']);
  assert.equal(vehicle.maintenance.length, 2);

  const projectFolder = path.join(projects, 'legacy-project'); fs.mkdirSync(projectFolder, { recursive: true });
  fs.writeFileSync(path.join(projectFolder, 'project.json'), JSON.stringify({ id: 'legacy-project', name: 'Tahoe Tune', vehicle: 'Tahoe Street Truck', controller: 'P01' }, null, 2));
  const renamed = manager.save({ ...vehicle, name: 'Tahoe P01 Street Truck' });
  const migratedProject = JSON.parse(fs.readFileSync(path.join(projectFolder, 'project.json'), 'utf8'));
  assert.equal(migratedProject.vehicleId, renamed.id);
  assert.equal(migratedProject.vehicle, renamed.name);
  assert.equal(migratedProject.vehicleSnapshot.transmission, '4L60E');
  assert.equal(manager.listWithUsage()[0].projectCount, 1);
  assert.throws(() => manager.delete(renamed.id), /Reassign those projects/);
  assert.throws(() => manager.save({ name: 'Duplicate VIN', vin: renamed.vin }), /already assigned/);

  const linked = projectVehicleFields({ vehicleId: renamed.id }, manager.list());
  assert.equal(linked.vehicleId, renamed.id);
  assert.equal(linked.vehicleSnapshot.hardwareId, '9386530');
  const copied = manager.duplicate(renamed.id);
  assert.equal(copied.vin, '');
  assert.equal(copied.favorite, false);
  const favorited = manager.favorite(copied.id);
  assert.equal(favorited.favorite, true);
  assert(activities.some(item => item.type === 'vehicle-updated'));
  pass('Garage v2 migration, VIN validation, rich profiles, durable project links, favorites, duplication, and deletion protection');
}


function testProjectScopedTuneWorkspace() {
  const root = path.join(tempRoot, 'project-scoped-workspaces');
  fs.mkdirSync(root, { recursive: true });
  const manager = new TuneWorkspaceManager({ appendActivity: () => {} });
  const validate = value => { assert(value?.tables?.spark?.values); return true; };
  const makeProject = id => {
    const folder = path.join(root, id); fs.mkdirSync(folder, { recursive: true });
    const bin = path.join(folder, 'original.bin'), xdf = path.join(folder, 'definition.xdf');
    fs.writeFileSync(bin, Buffer.alloc(32, id.charCodeAt(0))); fs.writeFileSync(xdf, `<XDFHEADER><deftitle>${id}</deftitle></XDFHEADER>`);
    return { id, name: id, folder, bin, binInfo: { sha256: require('crypto').createHash('sha256').update(fs.readFileSync(bin)).digest('hex') }, xdf, controller: 'P01', os: '12212156' };
  };
  const makeWorkspace = (active, value) => manager.bind({ mode: 'xdf', projectId: active.id, activeTable: 'spark', modified: {}, tables: { spark: { name: 'Spark', rowHeaders: ['1000'], colHeaders: ['0.5'], values: [[value]] } }, stock: { spark: { name: 'Spark', rowHeaders: ['1000'], colHeaders: ['0.5'], values: [[10]] } } }, active);
  const first = makeProject('first'), second = makeProject('second');
  const firstWorkspace = makeWorkspace(first, 10), secondWorkspace = makeWorkspace(second, 20);
  manager.save(first, firstWorkspace, validate); manager.save(second, secondWorkspace, validate);
  const snapshot = manager.createSnapshot(first, firstWorkspace, { name: 'Known good' }, validate);
  const changed = makeWorkspace(first, 14); changed.modified['spark:0:0'] = true; manager.save(first, changed, validate);
  const comparison = manager.compare(first, changed, snapshot.id);
  assert.equal(comparison.changedCells, 1); assert.equal(comparison.details[0].delta, 4);
  assert.equal(manager.restore(first, snapshot.id, validate).tables.spark.values[0][0], 10);
  assert.equal(manager.load(second, () => secondWorkspace, validate).tables.spark.values[0][0], 20);
  assert.equal(manager.history(first).length, 1); assert.equal(manager.history(second).length, 0);
  assert.equal(sameBinding(firstWorkspace.binding, manager.binding(first)), true);
  fs.writeFileSync(first.bin, Buffer.alloc(32, 0x7f)); first.binInfo.sha256 = require('crypto').createHash('sha256').update(fs.readFileSync(first.bin)).digest('hex');
  assert.throws(() => manager.restore(first, snapshot.id, validate), error => error.code === 'snapshot-binding-mismatch');
  const fresh = manager.load(first, () => ({ mode: 'practice', projectId: first.id, activeTable: 'spark', modified: {}, tables: { spark: { name: 'Practice', values: [[1]] } }, stock: { spark: { name: 'Practice', values: [[1]] } } }), validate);
  assert.equal(fresh.mode, 'practice');
  pass('project-scoped calibration isolation, snapshots, compare/restore, backup binding, and fingerprint mismatch recovery');
}


function testUnifiedTuneEngineFoundation() {
  const root = path.join(tempRoot, 'unified-tune-engine');
  const active = tuneProjectFixture(root, 'suite-project');
  const workspace = tuneWorkspaceFixture(active);
  const log = path.join(active.folder, 'Logs', 'baseline.csv');
  writeTuneEngineLog(log, { knock: true });
  const plan = buildTunePlan({ activeProject: active, intake: tuneEngineIntake(), workspace, targets: tuneEngineTargets(log) });
  assert(plan.readiness.score >= 85, `unexpected readiness ${plan.readiness.score}`);
  assert.equal(plan.nextStageId, 'baseline');
  assert.equal(plan.stages.find(item => item.id === 'drivability').status, 'ready');
  const coverage = buildCoverageMap(workspace);
  for (const role of ['desired-idle','fan-temperature','rev-limit','speed-limit','maf','ve','power-enrichment','high-spark','shift-rpm']) {
    assert.equal(coverage.roles[role].available, true, `${role} should be mapped`);
  }
  const manager = new TuneEngineManager({ appendActivity: () => {} });
  manager.savePlan(active, plan);
  const proposal = buildStageProposal({ plan, stageId: 'drivability', workspace, activeProject: active, csvPath: log });
  assert.equal(proposal.blocked, false);
  assert(proposal.proposals.length >= 8);
  const saved = manager.saveProposal(active, proposal);
  const applied = applyStageProposal(JSON.parse(JSON.stringify(workspace)), saved, saved.proposals.map(item => item.id));
  assert(applied.applied.length >= 8);
  assert.equal(applied.workspace.tables.idle.values[0][0], 750);
  assert.equal(applied.workspace.tables.limits.values[0][0], 6000);
  assert.equal(applied.workspace.tables.limits.values[2][0], 120);
  const updatedPlan = manager.recordApplied(active, plan, saved, applied.applied, null);
  assert.equal(updatedPlan.stages.find(item => item.id === 'drivability').status, 'complete');
  assert.equal(manager.status(active, workspace).stale, false);
  const spark = buildStageProposal({ plan: updatedPlan, stageId: 'spark', workspace, activeProject: active, csvPath: log });
  assert.equal(spark.blocked, false);
  assert(spark.proposals.every(item => item.proposed <= item.current), 'automatic spark changes must never add timing');
  const malicious = { ...spark, proposals: [{ id: 'unsafe-spark', role: 'high-spark', tableKey: 'spark', tableName: 'High Octane Spark', row: 0, col: 0, current: 20, proposed: 22 }] };
  assert.throws(() => applyStageProposal(JSON.parse(JSON.stringify(workspace)), malicious, ['unsafe-spark']), /spark increase/i);
  pass('Unified Tune Engine coverage, staged proposals, project persistence, exact-cell apply, and spark-increase safety boundary');
}


async function testAutonomousTuneAgentFoundation() {
  const root = path.join(tempRoot, 'autonomous-tune-agent');
  const active = tuneProjectFixture(root, 'autonomous-suite');
  const workspace = tuneWorkspaceFixture(active);
  const log = path.join(active.folder, 'Logs', 'baseline.csv');
  writeTuneEngineLog(log, { knock: true });
  const manager = new AutonomousTuneManager({ appendActivity: () => {} });
  const engine = new TuneEngineManager({ appendActivity: () => {} });
  const services = autonomousServices(active, workspace);
  const derived = deriveAutonomousTargets(tuneEngineIntake(), tuneEngineTargets(log), autonomousAuthorization());
  const result = await executeAutonomousTune({ manager, engineManager: engine, active, intake: tuneEngineIntake(), workspace, targets: derived, authorization: autonomousAuthorization(), callbacks: services.callbacks });
  assert.equal(result.state.status, 'ready-for-flash-confirmation');
  assert(result.state.totalAppliedCells >= 20);
  assert(result.state.completedStages.includes('fueling'));
  assert(result.state.completedStages.includes('spark'));
  assert(result.state.finalRevision?.name);
  assert.equal(result.state.authorization.finalFlashSeparate, true);
  assert.equal(manager.status(active, result.workspace).stale, false);
  pass('Autonomous Tune Agent complete mapped tune, automatic application, revision packaging, persistence, and separate flash boundary');
}

async function testClosedLoopAutonomousFoundation() {
  const root = path.join(tempRoot, 'closed-loop-autonomous');
  const active = tuneProjectFixture(root, 'closed-loop-suite');
  const workspace = tuneWorkspaceFixture(active);
  const base = closedLoopAutonomousRun(active, workspace);
  const baseline = writeValidationLog(path.join(active.folder, 'Logs', 'baseline.csv'), { good: false });
  const validation = writeValidationLog(path.join(active.folder, 'Logs', 'validation.csv'), { good: true });
  const manager = new ClosedLoopTuneManager({ appendActivity: () => {} });
  const services = closedLoopCallbacks(active, workspace);
  manager.start(active, workspace, base, { maxCycles: 5, targets: tuneEngineTargets(baseline), lastStableSnapshotId: 'snapshot-base' });
  const evaluation = manager.analyze(active, workspace, baseline, { role: 'baseline' });
  assert.equal(evaluation.session.status, 'ready-for-correction');
  assert(evaluation.evaluation.confidence.score >= 70);
  assert(evaluateLog(baseline, { targets: tuneEngineTargets(baseline) }).coverage.stageConfidence.fueling.score >= 70);
  const correction = await executeClosedLoopCorrection({ manager, active, workspace, csvPath: baseline, callbacks: services.api });
  assert.equal(correction.corrected, true);
  assert.equal(correction.session.status, 'waiting-for-validation-log');
  const result = await analyzeClosedLoopValidation({ manager, active, workspace: correction.workspace, csvPath: validation, callbacks: services.api });
  assert.equal(result.validated, true);
  assert.equal(result.session.status, 'converged');
  assert(manager.status(active, result.workspace, base).readiness.score >= 95);
  pass('Closed-Loop Autonomous Tune log confidence, correction cycle, convergence, rollback-point, and project-readiness foundation');
}


function testHardwareValidationHotfix() {
  const circular = { project: 'Customline', value: 7n, error: Object.assign(new Error('workspace failed'), { code: 'workspace-test' }), binary: Buffer.from('P01'), native: { child: { pid: 123 } } };
  circular.self = circular;
  const sanitized = safeIpcResult(circular);
  assert.equal(sanitized.value, '7');
  assert.equal(sanitized.error.code, 'workspace-test');
  assert.equal(sanitized.binary.size, 3);
  assert.equal(sanitized.native.child, undefined);
  assert(String(sanitized.self).startsWith('[Circular:'));
  assert(sanitized.ipcWarnings.length >= 3);

  const data = path.join(tempRoot, 'beta15-portable');
  const cliDir = path.join(data, 'PCMHammer_2.0.0_Portable', 'PCMHammer', 'Cli');
  fs.mkdirSync(cliDir, { recursive: true });
  const cli = path.join(cliDir, 'pcmhammer-cli.exe');
  const gui = path.join(path.dirname(cliDir), 'PcmHammer.exe');
  fs.writeFileSync(cli, 'mock'); fs.writeFileSync(gui, 'mock');
  const active = { id: 'p01', name: 'Customline', folder: path.join(data, 'project') }; fs.mkdirSync(active.folder, { recursive: true });
  const manager = new FlashManager({ dataRoot: () => data, getActiveProject: () => active, getToolPath: () => cli });
  assert.equal(manager.resolveExecutable().executable, cli);
  assert.equal(manager.resolveGuiExecutable(), gui);
  const customGui = path.join(data, 'PcmHammer-normal.exe'); fs.writeFileSync(customGui, 'mock');
  manager.saveGuiExecutable(customGui);
  assert.equal(manager.resolveGuiExecutable(), customGui);
  pass('beta.15 IPC serialization fallback, real diagnostic-state resilience, and portable PCM Hammer assisted detection');
}


async function testComRecoveryAndResumeFix() {
  const details = bridgeError(new Error('The lockprobe request timed out.'), 'LockProbe', 'COM4');
  assert.equal(details.code, 'lock-probe-timeout');
  assert.equal(details.port, 'COM4');
  assert.equal(details.recoverable, true);

  const ranked = rankAlternatePorts([
    { port: 'COM4', name: 'Standard Serial over Bluetooth link (COM4)', transport: 'Bluetooth Serial' },
    { port: 'COM5', name: 'OBDLink MX+ Outgoing (COM5)', transport: 'Bluetooth Serial', recognized: true, recommended: true },
    { port: 'COM6', name: 'OBDLink MX+ Incoming (COM6)', transport: 'Bluetooth Serial', recognized: true, recommended: true }
  ], 'COM4');
  assert.equal(ranked[0].port, 'COM5');
  assert(ranked[0].recoveryScore > ranked[1].recoveryScore);

  const normalized = normalizeP01RecoveryState({ status: 'running', phase: 'stopped-lock-probe-timeout', nextStep: 'read-properties', stop: { code: 'lock-probe-timeout', priorPhase: 'waiting-read-properties' } });
  assert.equal(normalized.status, 'paused');
  assert.equal(normalized.resumePhase, 'read-properties');

  const obdData = path.join(tempRoot, 'beta16-obd'); fs.mkdirSync(obdData, { recursive: true });
  const obd = new ObdManager({
    dataRoot: () => obdData,
    getActiveProject: () => null,
    platform: 'win32',
    bridgeRunner: async action => { if (action === 'LockProbe') throw new Error('The lockprobe request timed out.'); return { success: true, devices: [] }; }
  });
  const lock = await obd.probePortLock({ port: 'COM4', baud: 115200 });
  assert.equal(lock.code, 'lock-probe-timeout');
  assert.equal(lock.timedOut, true);
  assert.equal(lock.available, null);
  let abortReason = '';
  obd.bridgeChildren.set('stale-request', { abort: reason => { abortReason = reason; } });
  const abortResult = obd.abortBridgeRequests('resume requested');
  assert.equal(abortResult.aborted, 1);
  assert.equal(abortReason, 'resume requested');

  const flashData = path.join(tempRoot, 'beta16-flash'); fs.mkdirSync(flashData, { recursive: true });
  const active = { id: 'p16', name: 'Customline', folder: path.join(flashData, 'project'), controller: 'P01' }; fs.mkdirSync(active.folder, { recursive: true });
  const directEvents = [];
  const flash = new FlashManager({
    dataRoot: () => flashData,
    getActiveProject: () => active,
    getToolPath: () => null,
    releasePort: async ({ port, owner }) => { directEvents.push(`release:${port}:${owner}`); return { released: true, port }; },
    probePortLock: async ({ port }) => { directEvents.push(`probe:${port}`); return { available: true, locked: false, port }; },
    abortBridgeRequests: reason => { directEvents.push(`abort:${reason}`); return { aborted: 1 }; }
  });
  const lease = await flash.preparePort({ operation: 'readProperties', values: { device: 'COM4', port: 'COM4' } });
  assert.equal(lease.port, 'COM4');
  assert.equal(lease.mode, 'direct-handoff');
  assert.equal(lease.lockProbeSkipped, true);
  assert(directEvents.some(item=>item==='release:COM4:pcmhammer'));
  assert(!directEvents.some(item=>item.startsWith('probe:')));

  const project = path.join(tempRoot, 'beta16-p01'); fs.mkdirSync(path.join(project, 'Reports'), { recursive: true });
  const activeP01 = { id: 'p16-state', name: 'Customline', folder: project, controller: 'P01' };
  const auto = new P01AutoManager({ getActiveProject: () => activeP01, appendActivity: () => {}, processInstanceId: 'beta16' });
  fs.writeFileSync(auto.file(activeP01), JSON.stringify({ ...auto.blank(activeP01), status: 'running', phase: 'stopped-lock-probe-timeout', nextStep: 'read-properties', resumePhase: 'read-properties', stop: { code: 'lock-probe-timeout', priorPhase: 'waiting-read-properties' } }, null, 2));
  const loaded = auto.load(activeP01);
  assert.equal(loaded.status, 'paused');
  assert.equal(auto.canResume(loaded), true);
  const resumed = auto.resume();
  assert.equal(resumed.status, 'running');
  assert.equal(resumed.phase, 'read-properties');
  pass('beta.16 recovery compatibility plus beta.17 direct COM lease and guaranteed P01 Resume state');
}


async function testIntegratedPcmHammerPipeline() {
  const root = path.join(tempRoot, 'beta17-integrated');
  const projectFolder = path.join(root, 'project');
  for (const sub of ['Originals','Revisions','Reports']) fs.mkdirSync(path.join(projectFolder, sub), { recursive: true });
  const original = path.join(projectFolder, 'Originals', 'original.bin');
  const revision = path.join(projectFolder, 'Revisions', 'revision.bin');
  fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x21));
  fs.writeFileSync(revision, Buffer.alloc(P01_BIN_SIZE, 0x22));
  const active = { id: 'p17', name: 'Integrated P01', folder: projectFolder, controller: 'P01', bin: original };
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const mockExe = path.join(root, 'pcmhammer-cli'); fs.mkdirSync(root, { recursive: true }); try { fs.symlinkSync(process.execPath, mockExe); } catch {}
  const recoveryKernels = path.join(root, 'Kernels'); fs.mkdirSync(recoveryKernels, { recursive: true }); fs.writeFileSync(path.join(recoveryKernels, 'Kernel-P01.bin'), Buffer.alloc(64,1)); fs.writeFileSync(path.join(recoveryKernels, 'Loader-P01.bin'), Buffer.alloc(64,2));
  const ownership = []; const identities = []; const reads = []; const sessions = [];
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data'), getActiveProject: () => active, getToolPath: () => '',
    getDeviceStatus: () => ({ connection: { port: 'COM3', voltage: 13.6 } }),
    releasePort: async payload => { ownership.push({ type: 'release', ...payload }); return { released: true }; },
    probePortLock: async payload => { ownership.push({ type: 'probe', ...payload }); return { available: true }; },
    abortBridgeRequests: reason => { ownership.push({ type: 'abort', reason }); return { aborted: 1 }; },
    appendActivity: () => {}, emit: () => {},
    onIdentifyComplete: async identity => identities.push(identity),
    onReadComplete: async (file, info) => reads.push({ file, info }),
    onSessionComplete: async session => sessions.push(session)
  });
  process.env.PCMHAMMER_MOCK_HELP_MODE = 'blank';
  process.env.PCMHAMMER_MOCK_PROFILE = 'long-device';
  process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  process.env.PCMHAMMER_MOCK_READ_BYTE = '99';
  const probe = await manager.probe({ executable: mockExe, prefixArgs: [mock] });
  assert.equal(probe.mode, 'runtime-profile-discovery');
  assert.equal(probe.capabilities.readProperties, true);
  manager.saveDevice('COM3');
  await manager.start('readProperties', {}); await waitFor(() => !manager.session);
  const properties = manager.getHistory().find(item => item.operation === 'readProperties');
  assert.equal(properties.state, 'complete');
  assert.equal(properties.integratedProfileId, 'official-2x-long-device');
  assert(properties.profileAttempts.length >= 2, 'runtime profile discovery should reject at least one safe syntax before success');
  assert.equal(identities.at(-1).os, '12212156');
  assert.equal(manager.getConfig().integratedProfileId, 'official-2x-long-device');
  assert(!ownership.some(item => item.type === 'probe'), 'integrated runner must not race PCM Hammer with a second serial open');

  const first = path.join(projectFolder, 'Originals', 'integrated-read-1.bin');
  const second = path.join(projectFolder, 'Originals', 'integrated-read-2.bin');
  await manager.start('read', { output: first }); await waitFor(() => !manager.session);
  await manager.start('read', { output: second }); await waitFor(() => !manager.session);
  assert.equal(reads.length, 2); assert.equal(reads[0].info.size, P01_BIN_SIZE); assert.equal(reads[0].info.sha256, reads[1].info.sha256);
  await manager.start('testWrite', { input: revision, voltage: 13.6 }); await waitFor(() => !manager.session);
  assert.equal(sessions.at(-1).testWritePassed, true);
  assert.equal(manager.status().portOwner.owner, 'idle');

  assert.equal(safeToRetryProfile({ operation: 'read', text: 'Unrecognized option: --port', exitCode: 64, output: path.join(root, 'missing.bin') }), true);
  assert.equal(safeToRetryProfile({ operation: 'testWrite', text: 'Unrecognized option: --port', exitCode: 64 }), false);
  assert.equal(safeToRetryProfile({ operation: 'read', text: 'Opening serial port COM3\nUnrecognized option', exitCode: 64 }), false);
  assert.equal(hasCommunicationActivity('Opening serial port COM3'), true);
  assert(profilesForOperation('readProperties').length >= 6);

  const stateFolder = path.join(root, 'migration'); fs.mkdirSync(path.join(stateFolder, 'Reports'), { recursive: true });
  const migrationActive = { id: 'migrate17', name: 'Customline', folder: stateFolder };
  const auto = new P01AutoManager({ getActiveProject: () => migrationActive, appendActivity: () => {}, processInstanceId: 'beta17' });
  fs.writeFileSync(auto.file(migrationActive), JSON.stringify({ ...auto.blank(migrationActive), version: 3, status: 'paused', phase: 'assisted-readProperties', nextStep: 'read-properties', resumePhase: 'read-properties' }, null, 2));
  const migrated = auto.load(migrationActive);
  assert.equal(migrated.phase, 'stopped-integrated-migration'); assert.equal(migrated.status, 'paused'); assert.equal(auto.canResume(migrated), true);
  const resumed = auto.resume(); assert.equal(resumed.phase, 'read-properties');
  delete process.env.PCMHAMMER_MOCK_HELP_MODE; delete process.env.PCMHAMMER_MOCK_PROFILE; delete process.env.PCMHAMMER_MOCK_SCENARIO; delete process.env.PCMHAMMER_MOCK_READ_BYTE;
  pass('beta.17 runtime CLI profile discovery, direct COM ownership, internal properties/reads/Test Write, and assisted-state migration');
}


function testStartupRecoveryHotfix() {
  const report = runStartupRecoverySimulations();
  assert.equal(report.scenarios.length, 3);
  assert(report.scenarios.every(item => item.passed));
  pass('beta.18 Guided P01 startup crash regression and renderer isolation boundary');
}


async function testRealCliCommandRecovery() {
  const report = await runRealCliCommandRecoverySimulations('all', { quiet: true });
  assert.equal(report.reports.length, 3);
  assert(report.reports.every(item => item.passed));
  const pipeline = report.reports.find(item => item.scenario === 'exact-observed-cli-pipeline');
  const migration = report.reports.find(item => item.scenario === 'diagnostic-config-migration');
  const ledger = report.reports.find(item => item.scenario === 'saved-evidence-ledger-repair');
  assert(pipeline.readProperties.includes('--get-properties'));
  assert(pipeline.readProperties.includes('--device'));
  assert.equal(pipeline.writeCalibration, false, 'full write must not be silently substituted for calibration write');
  assert.equal(migration.commandSchemaVersion, 2);
  assert.equal(migration.usageOnly, true);
  assert.equal(migration.communicationStarted, false);
  assert.equal(ledger.phase, 'definition');
  pass('beta.23 observed PCM Hammer CLI syntax recovery, saved command migration, and completed P01 evidence reconciliation');
}


async function testIntegratedDefinitionPipeline() {
  const report = await runIntegratedDefinitionPipelineSimulations('all', { quiet: true });
  assert.equal(report.reports.length, 3);
  assert(report.reports.every(item => item.passed));
  const exact = report.reports.find(item => item.scenario === 'exact-local-xdf');
  const generated = report.reports.find(item => item.scenario === 'universal-patcher-xml-conversion');
  const safeStop = report.reports.find(item => item.scenario === 'safe-missing-definition-stop');
  assert.equal(exact.tableCount, 1);
  assert.equal(generated.tableCount, 2);
  assert.equal(safeStop.guessedDefinitionGenerated, false);
  pass('beta.23 exact-XDF discovery, Universal Patcher XML conversion, managed definition jobs, and no-guessed-address safety');
}

async function testP01SetupCompletion() {
  const result = await runP01SetupCompletionSimulations({ quiet: true });
  assert.equal(result.reports.length, 4);
  assert(result.reports.every(item => item.passed));
  pass('beta.23 read-only exact-OS fallback, unchanged stock clone validation, stale-fingerprint auto-binding, Test Write completion, and tuning/write lock');
}

function testAutomaticCommissioningDefinitionBinding() {
  const tuneWorkspaceSource = fs.readFileSync(path.join(__dirname,'../src/tune-workspace.js'),'utf8');
  const mainSource = fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8');
  assert(tuneWorkspaceSource.includes("fileSha256(active.bin)"),'workspace binding must hash protected BIN bytes directly');
  assert(!tuneWorkspaceSource.includes("active.binInfo?.sha256 || fileSha256(active.bin)"),'stale binInfo fallback returned to workspace binding');
  assert(mainSource.includes("sourceBinSha256: sha256(active.bin)"),'XDF workspace must bind to the actual protected BIN hash');
  assert(mainSource.includes("commissioning-definition-auto-rebound"),'automatic commissioning definition rebound recovery missing');
  assert(mainSource.includes("project-file-fingerprints-refreshed"),'project fingerprint refresh migration missing');
  pass('automatic commissioning definition binding and stale beta.21 fingerprint recovery');
}


async function testWorkspaceStateReconciliationHotfix() {
  const result = await runWorkspaceStateReconciliationSimulations({ quiet: true });
  assert.equal(result.reports.length, 3);
  assert(result.reports.every(item => item.passed));
  const mainSource = fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8');
  const preloadSource = fs.readFileSync(path.join(__dirname,'../src/preload.js'),'utf8');
  const rendererSource = fs.readFileSync(path.join(__dirname,'../src/renderer/app.js'),'utf8');
  assert(mainSource.includes("ipcMain.handle('workspace:reconcile'"),'backend workspace reconciliation IPC is missing');
  assert(mainSource.includes('reconcileActiveCommissioningWorkspace({ advanceAutomation: true'),'Resume must reconcile the bound commissioning workspace before evaluating legacy failed state');
  assert(preloadSource.includes("reconcileWorkspace: () => ipcRenderer.invoke('workspace:reconcile')"),'preload workspace reconciliation bridge is missing');
  assert(rendererSource.includes('window.tuniq.reconcileWorkspace()'),'Refresh must perform backend reconciliation rather than only repainting cached state');
  pass('beta.23 bound-workspace reconciliation, working Refresh, stale hash repair, and failed-step advance to stock clone');
}

function testP01SetupFinalizer() {
  const result = runP01FinalizerSimulations();
  assert.equal(result.passed, true);
  assert.equal(result.scenarios.length, 4);
  const mainSource = fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8');
  const p01Source = fs.readFileSync(path.join(__dirname,'../src/p01-commissioning.js'),'utf8');
  assert(mainSource.includes('finalizeP01CommissioningSoftwareState'),'P01 Setup Finalizer orchestration missing');
  assert(mainSource.includes("phase: advanceAutomation ? 'test-write'"),'Finalizer must bypass the 48% workspace step and advance to Test Write');
  assert(p01Source.includes('confirmCommissioningDefinitionFromDisk'),'disk-only commissioning definition binding missing');
  assert(p01Source.includes('diskBoundCommissioningMapping'),'commissioning setup must not depend on Calibration renderer cache');
  pass('beta.24 disk-first P01 Setup Finalizer, deterministic stock clone, stale-original repair, and corrupt-read hard stop');
}

async function testP01FinalCompletionHarness() {
  const result = await runP01FinalCompletionHarness();
  assert.equal(result.passed, true);
  assert.equal(result.reports.length, 3);
  assert(result.reports.every(item => item.passed));
  assert.equal(result.reports.find(item=>item.scenario==='complete-from-48-percent').testWrite, true);
  assert.equal(result.reports.find(item=>item.scenario==='test-write-disconnect-retry').retryPassed, true);
  pass('beta.24 complete 48%-to-Test-Write harness, disconnect retry, and deterministic restart recovery');
}

async function testP01TestWriteRuntimeRecovery() {
  const reports = await runP01TestWriteRuntimeRecoverySimulations();
  runP01ContinuityLockSimulations();
  assert.equal(reports.length, 5);
  assert(reports.every(item => item.passed));
  assert.equal(reports.find(item => item.scenario === 'timeout-switches-to-outgoing-port')?.testWrite, true);
  assert.equal(reports.find(item => item.scenario === 'timeout-stops-with-exact-cause')?.stopCode, 'adapter-open-timeout');
  assert.equal(reports.find(item => item.scenario === 'generic-bluetooth-sibling-real-open-failure-text')?.finalDevice, 'COM4');
  assert((reports.find(item => item.scenario === 'runtime-rescan-discovers-late-com4')?.scans || 0) >= 2);
  assert.equal(reports.find(item => item.scenario === 'missing-kernels-stops-before-launch')?.stopCode, 'kernel-files-missing');
  pass('1.8.1 PCM Hammer kernel discovery, broad open-failure detection, generic Bluetooth sibling recovery, runtime COM rescan, bounded retry, and exact Test Write diagnostics');
}

function testHardwareSessionDoctor() {
  const result = runHardwareSessionDoctorSimulations({ quiet: true });
  assert.equal(result.passed, true);
  assert.equal(result.scenarios.length, 7);
  assert(result.scenarios.every(item => item.passed));
  pass('v1.8.2 Hardware Session Doctor, stopped-state UX, remembered COM routing, and diagnostic export');
}

function testStaticContracts() {
  const html=fs.readFileSync(path.join(__dirname,'../src/renderer/index.html'),'utf8'); const app=fs.readFileSync(path.join(__dirname,'../src/renderer/app.js'),'utf8'); const preload=fs.readFileSync(path.join(__dirname,'../src/preload.js'),'utf8'); const main=fs.readFileSync(path.join(__dirname,'../src/main.js'),'utf8'); const flashSource=fs.readFileSync(path.join(__dirname,'../src/flash.js'),'utf8');
  const ids=new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]));
  const used=[...app.matchAll(/\$\('#([^']+)'\)/g)].map(match=>match[1]);
  const missing=[...new Set(used.filter(id=>!ids.has(id)))].filter(id=>!['editActiveProject','filesGoWorkflow','filesLoadLab','garageAdd'].includes(id));
  assert.deepEqual(missing,[],`missing DOM IDs: ${missing.join(', ')}`);
  for(const match of preload.matchAll(/ipcRenderer\.invoke\('([^']+)'/g)) assert(main.includes(`ipcMain.handle('${match[1]}'`),`missing IPC handler ${match[1]}`);
  const webApp=fs.readFileSync(path.join(__dirname,'../web/app.js'),'utf8'); const webHtml=fs.readFileSync(path.join(__dirname,'../web/index.html'),'utf8');
  assert(webApp.includes('const esc='),'web importer must escape CSV-controlled preview content');
  assert(webApp.includes('50*1024*1024'),'web importer must enforce a bounded beta file size');
  assert(webHtml.includes('Everything is processed in this browser'),'web importer privacy notice missing');
  for(const required of ['definitionCenter','definitionScan','definitionResolve','definitionImport','definitionUniversal','definitionTunerPro','definitionCheckTunerPro','definitionImportTunerPro','definitionOpenJob','p01AutoRecover','p01AutoAssistedBypass','p01AutoCopyDetails','closedLoopState','closedLoopStart','closedLoopAnalyze','closedLoopRun','closedLoopRollback','closedLoopReport','closedLoopTimeline','closedLoopReadiness','autonomousTuneState','autonomousTuneStart','autonomousTuneResume','autonomousTuneCycle','autonomousAuthorizeCalibration','autonomousAuthorizeHighRisk','quickSwitcher','headerProjectSwitcher','sidebarToggle','qolRestorePage','toastStack','recentWorkList','garageSearch','garageFavoritesOnly','vehicleTransmission','vehicleModifications','vehicleMaintenance','snapshotTimeline','calSnapshotCompare','tuneEnginePanel','tuneEngineBuild','tuneEngineStages','tuneEngineProposal','tuneEngineApply','tuneEngineHandoff','tuneTargetIdle','tuneTargetAfr','tuneConfirmWideband']) assert(ids.has(required),`workspace DOM contract missing ${required}`);
  assert(app.includes("key.toLowerCase()==='b'"),'sidebar keyboard shortcut missing');
  assert(app.includes('scrollPositions'),'per-page scroll restoration contract missing');
  assert(app.includes('data-project-vehicle'),'Garage create-project action missing');
  assert(preload.includes("vehicle:choose-photo"),'Garage photo IPC contract missing');
  assert(preload.includes("calibration:compare-snapshot"),'calibration snapshot compare IPC missing');
  assert(main.includes('TuneWorkspaceManager'),'project-scoped workspace manager missing');
  assert(preload.includes("tune-engine:build-plan"),'Unified Tune Engine preload contract missing');
  assert(main.includes("tune-engine:apply-stage"),'Unified Tune Engine apply IPC missing');
  assert(app.includes('buildTuneEngineStage'),'Unified Tune Engine renderer workflow missing');
  assert(preload.includes("autonomous-tune:start"),'Autonomous Tune preload contract missing');
  assert(main.includes("autonomous-tune:resume"),'Autonomous Tune resume IPC missing');
  assert(app.includes('runAutonomousTune'),'Autonomous Tune renderer workflow missing');
  assert(preload.includes("p01-auto:recover"),'P01 COM recovery preload contract missing');
  assert(main.includes("p01-auto:assisted-bypass"),'P01 integrated retry compatibility IPC missing');
  assert(flashSource.includes('direct PCM Hammer lease'),'integrated PCM Hammer direct COM lease missing');
  assert(flashSource.includes('resolveKernelDirectory'),'PCM Hammer kernel directory discovery missing');
  assert(flashSource.includes('discoverCliDevices'),'PCM Hammer --list-devices recovery missing');
  assert(flashSource.includes('same-port-retry'),'bounded same-port recovery missing');
  assert(app.includes('Integrated PCM Hammer retry started inside TunIQ'),'integrated retry renderer missing');
  assert(app.includes("String(auto.stop?.code||'')"),'Guided P01 renderer must read recovery code from the active automation state');
  assert(!app.includes("String(s.stop?.code||'')"),'undefined beta.17 renderer variable returned');
  assert(app.includes('function renderSafely'),'renderer isolation boundary missing');
  assert(html.includes('Fully integrated PCM Hammer pipeline'),'integrated P01 workflow label missing');
  assert(preload.includes("closed-loop:run-cycle"),'Closed-Loop Tune preload contract missing');
  assert(main.includes("closed-loop:analyze-latest"),'Closed-Loop Tune validation IPC missing');
  assert(app.includes('runClosedLoopAction'),'Closed-Loop Tune renderer workflow missing');
  const pcmSource=fs.readFileSync(path.join(__dirname,'../src/pcmhammer.js'),'utf8');
  const integratedSource=fs.readFileSync(path.join(__dirname,'../src/pcmhammer-integrated.js'),'utf8');
  const flashSource181=fs.readFileSync(path.join(__dirname,'../src/flash.js'),'utf8');
  const comRecoverySource=fs.readFileSync(path.join(__dirname,'../src/com-recovery.js'),'utf8');
  const bridgeSource=fs.readFileSync(path.join(__dirname,'../src/obd-bridge.ps1'),'utf8');
  const p01Source=fs.readFileSync(path.join(__dirname,'../src/p01-commissioning.js'),'utf8');
  const p01AutoSource=fs.readFileSync(path.join(__dirname,'../src/p01-auto.js'),'utf8');
  assert(pcmSource.includes("'--get-properties'"),'observed PCM Hammer --get-properties syntax missing');
  assert(pcmSource.includes("'--device'"),'observed PCM Hammer --device syntax missing');
  assert(pcmSource.includes('adapter-open-timeout'),'specific PCM Hammer serial open timeout classification missing');
  assert(pcmSource.includes('adapter-open-failed'),'generic PCM Hammer port-open failure classification missing');
  assert(pcmSource.includes('kernel-files-missing'),'specific PCM Hammer kernel failure classification missing');
  assert(integratedSource.includes('looksLikeCliUsageOnly'),'CLI usage-only classifier missing');
  assert(integratedSource.includes('isPortOpenFailure'),'broad PCM Hammer port-open failure detector missing');
  assert(flashSource181.includes('refreshSessionDeviceCandidates'),'runtime COM inventory rescan missing');
  assert(flashSource181.includes('.stdout.log')&&flashSource181.includes('.stderr.log'),'per-attempt PCM Hammer stream logs missing');
  assert(comRecoverySource.includes('generic Bluetooth sibling'),'generic Bluetooth COM sibling ranking contract missing');
  assert(bridgeSource.includes('[System.IO.Ports.SerialPort]::GetPortNames()'),'Windows serial inventory fallback missing');
  assert(bridgeSource.includes('DEVPKEY_Device_ContainerId')&&bridgeSource.includes('pairKey'),'Bluetooth PnP pair metadata collection missing');
  assert(p01Source.includes('repairVerifiedReadPair'),'saved P01 read-pair repair missing');
  assert(p01AutoSource.includes('reconcileEvidence'),'Guided P01 completed-evidence reconciliation missing');
  assert(app.includes('copyP01TechnicalDetails'),'Copy technical details action missing');
  assert(preload.includes("definition:resolve"),'Definition Center resolve IPC missing');
  assert(main.includes("definition:launch-universal-patcher"),'managed Universal Patcher definition job IPC missing');
  assert(main.includes("definition:launch-tunerpro"),'managed TunerPro roundtrip IPC missing');
  assert(preload.includes("definition:inspect-tunerpro"),'managed TunerPro inspection preload IPC missing');
  assert(main.includes("definition:inspect-tunerpro"),'managed TunerPro inspection IPC missing');
  assert(preload.includes("definition:import-tunerpro"),'managed TunerPro import preload IPC missing');
  assert(main.includes("definition:import-tunerpro"),'managed TunerPro import IPC missing');
  assert(main.includes("patch:launch-universal-managed"),'managed Universal Patcher validation IPC missing');
  assert(preload.includes("patch:import-universal-managed"),'managed Universal Patcher import preload IPC missing');
  const definitionSource=fs.readFileSync(path.join(__dirname,'../src/definition-pipeline.js'),'utf8');
  assert(definitionSource.includes('buildXdfFromUniversalTunerXml'),'Universal Patcher XML-to-XDF converter missing');
  assert(definitionSource.includes('TunIQ will not generate guessed table addresses'),'no-guessed-address job safety boundary missing');
  assert(definitionSource.includes('buildCommissioningOnlyXdf'),'P01 commissioning-only definition builder missing');
  assert(main.includes('valid-stock-clone'),'unchanged stock-clone validation path missing');
  assert(main.includes('p01-guided-commissioning-complete'),'commissioning-only completion state missing');
  pass('renderer DOM, integrated PCM Hammer, web importer, Garage v2, project workspace, and Unified Tune Engine IPC contracts');
}

(async()=>{
  try { testXdfAndChecksums(); testChecksumReportsAndDiff(); testAiExecution(); await testFlashManager(); await testVirtualLogger(); await testConnectionDoctorAndOfflineLab(); testQualityOfLifeFoundation(); testGarageProjectFoundation(); testProjectScopedTuneWorkspace(); testUnifiedTuneEngineFoundation(); await testAutonomousTuneAgentFoundation(); await testClosedLoopAutonomousFoundation(); testPublicBetaFoundation(); testObdLinkPhoneImport(); testNaturalLanguageGoalExecutor(); testP01Commissioning(); testP01EvidenceIntegration(); testP01OneClickCommissioning(); testHardwareValidationHotfix(); await testComRecoveryAndResumeFix(); await testIntegratedPcmHammerPipeline(); testStartupRecoveryHotfix(); await testRealCliCommandRecovery(); await testIntegratedDefinitionPipeline(); await testP01SetupCompletion(); testAutomaticCommissioningDefinitionBinding(); await testWorkspaceStateReconciliationHotfix(); testP01SetupFinalizer(); await testP01FinalCompletionHarness(); await testP01TestWriteRuntimeRecovery(); runReleasePromotionSimulations(); runQolNavigationSimulations(); testHardwareSessionDoctor(); await runExclusiveSessionSafetyVaultSimulations({ quiet: true }); pass('Exclusive Hardware Session Guard and Project Safety Vault'); testStaticContracts(); console.log('\nAll TunIQ 1.8.6 PCM Hammer Clean Session Reset automated tests passed (36 groups).'); }
  finally { fs.rmSync(tempRoot,{recursive:true,force:true}); }
})().catch(error=>{console.error('\nTEST FAILURE\n',error.stack||error);process.exit(1)});
