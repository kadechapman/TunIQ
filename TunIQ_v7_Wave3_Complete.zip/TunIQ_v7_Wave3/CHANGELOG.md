# Changelog

## v7.3.0 — Wave 3
- Added persistent multi-vehicle Smart Garage.
- Added vehicle-aware AI conversations and history.
- Added build goals, inventory, compatibility screening, task management, and cost tracking.
- Added searchable tuning/diagnostic knowledge base.
- Improved CSV log analysis with fuel-trim support.
- Added local data export/import.
- Added optional OpenAI Responses API backend.
- Preserved strict read-only/no-flash boundaries.
