# TunIQ v7 — Wave 3: AI Brain

Wave 3 turns the earlier interface into a local-first automotive project assistant with persistent vehicle memory, multiple vehicles, build goals, parts inventory, task/cost tracking, conversation history, CSV log screening, a built-in knowledge base, data backup/restore, and an optional real AI backend.

## Fast preview

Open `index.html`. Most features work directly in the browser and save to local storage. The offline AI is intentionally limited.

## Run the connected AI locally

1. Install Node.js 20 or newer.
2. Open a terminal inside this folder.
3. Run `npm install`.
4. Set `OPENAI_API_KEY` in your terminal or environment. Do not put the key in browser JavaScript.
5. Optionally set `OPENAI_MODEL`.
6. Run `npm start`.
7. Open `http://localhost:8787`.

The backend uses the OpenAI Responses API and sends the active vehicle/build context with recent conversation history. User data remains in the browser unless a user sends a message to the connected AI.

## What works

- Responsive desktop/mobile app
- Multiple locally saved vehicle profiles
- Persistent build goals, parts, tasks, costs, and chat history
- Guided, quick, and advanced answer modes
- Offline safety-first automotive question handling
- Optional server-side OpenAI connection
- CSV log screening and graphing
- Knowledge articles
- Export/import of local TunIQ data
- GitHub Pages-compatible static interface (offline AI only)

## What does not work yet

Wave 3 does not communicate with an OBD adapter, control PCM Hammer, identify a real PCM, read/write BIN files, edit calibration tables, calculate checksums, flash controllers, or automatically tune a vehicle. Live Data and Tune Studio are simulations/educational views.

A browser hosted on GitHub Pages cannot safely contain an OpenAI API key. A hosted AI version requires a separate secure backend.
