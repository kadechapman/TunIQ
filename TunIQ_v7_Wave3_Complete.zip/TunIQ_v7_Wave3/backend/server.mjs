import http from 'node:http';
import {readFile, stat} from 'node:fs/promises';
import {extname, join, normalize} from 'node:path';
import OpenAI from 'openai';

const PORT=Number(process.env.PORT||8787);
const ROOT=normalize(join(import.meta.dirname,'..'));
const API_KEY=process.env.OPENAI_API_KEY||'';
const MODEL=process.env.OPENAI_MODEL||'gpt-5-mini';
const client=API_KEY?new OpenAI({apiKey:API_KEY}):null;
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml','.json':'application/json; charset=utf-8','.csv':'text/csv; charset=utf-8','.webmanifest':'application/manifest+json'};
const send=(res,status,body,type='application/json; charset=utf-8')=>{res.writeHead(status,{'content-type':type,'cache-control':'no-store','access-control-allow-origin':'*'});res.end(body)};
const json=(res,status,obj)=>send(res,status,JSON.stringify(obj),types['.json']);
async function body(req){let s='';for await(const c of req){s+=c;if(s.length>1_000_000)throw new Error('Request too large')}return JSON.parse(s||'{}')}
function systemPrompt(context){return `You are TunIQ, a safety-first automotive diagnostic, build-planning, and tuning education assistant.
Use the supplied vehicle/build context. Clearly distinguish verified facts, assumptions, estimates, diagnostic steps, and calibration advice.
Never claim you connected to a vehicle, read a PCM, wrote a tune, tested a change, or verified a part unless the context proves it.
Do not provide exact calibration table changes when the PCM/OS, logs, fuel, injector data, and mechanical condition are insufficient.
For flashing topics, require exact controller/OS compatibility, a verified original backup, supported interface, stable regulated power, file validation, and a recovery plan.
Prioritize mechanical diagnosis before tuning. Ask targeted follow-up questions when necessary.
Keep answers beginner-friendly when answerStyle is guided; be concise for quick; include deeper technical context for advanced.
Vehicle/build context JSON:
${JSON.stringify(context,null,2)}`}
async function chat(req,res){if(!client)return json(res,503,{error:'AI_NOT_CONFIGURED',message:'Set OPENAI_API_KEY on the server.'});const data=await body(req);if(typeof data.message!=='string'||!data.message.trim())return json(res,400,{error:'A message is required.'});const history=Array.isArray(data.history)?data.history.slice(-12).map(m=>({role:m.role==='assistant'?'assistant':'user',content:String(m.content||'')})):[];try{const response=await client.responses.create({model:MODEL,instructions:systemPrompt(data.context||{}),input:[...history,{role:'user',content:data.message}],max_output_tokens:1200});return json(res,200,{answer:response.output_text,model:MODEL})}catch(err){console.error(err);return json(res,500,{error:'AI_REQUEST_FAILED',message:err?.message||'Unknown error'})}}
async function staticFile(req,res){let pathname=new URL(req.url,'http://localhost').pathname;if(pathname==='/')pathname='/index.html';const file=normalize(join(ROOT,pathname));if(!file.startsWith(ROOT))return send(res,403,'Forbidden','text/plain');try{const info=await stat(file);if(!info.isFile())throw 0;send(res,200,await readFile(file),types[extname(file)]||'application/octet-stream')}catch{send(res,404,'Not found','text/plain')}}
const server=http.createServer(async(req,res)=>{try{if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'});return res.end()}if(req.url==='/api/health')return json(res,200,{ok:true,wave:3,aiConfigured:Boolean(client),model:client?MODEL:null});if(req.url==='/api/chat'&&req.method==='POST')return chat(req,res);return staticFile(req,res)}catch(err){console.error(err);json(res,500,{error:'SERVER_ERROR'})}});
server.listen(PORT,()=>console.log(`TunIQ Wave 3 running at http://localhost:${PORT}`));
