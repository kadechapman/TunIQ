# TunIQ v1.7.0-beta.14 Test Report

## Release

- Version: `1.7.0-beta.14`
- Name: Closed-Loop Autonomous Tuning
- Build type: tested source release
- Verification type: software, generated-log, mock-process, file-system, and recovery simulation
- Physical hardware verification: **not performed**

## Major behavior verified

Beta.14 extends the beta.13 Autonomous Tune Agent with an adaptive validation loop:

- Start only after a complete project-scoped Autonomous Tune base run
- Bind the session to the exact project, BIN SHA-256, and XDF SHA-256
- Create a protected rollback snapshot at session start and before each correction cycle
- Normalize and fingerprint each new validation log
- Reject duplicate log fingerprints so one drive cannot be reused as both correction and validation evidence
- Score log row count, duration, sampling rate, available channels, and operating-zone coverage
- Score idle, cruise, acceleration, high-load/WOT, and transmission-shift coverage separately
- Calculate stage confidence for drivability, airflow, fueling, spark, and transmission work
- Evaluate voltage, coolant temperature, intake-air temperature, knock retard, wideband error, misfires, injector duty, trims, and available fuel-pressure evidence
- Automatically run the next mapped correction cycle when confidence is sufficient
- Require a fresh post-correction log before declaring convergence
- Compare composite calibration error between drives
- Mark a tune converged when confidence, safety, trim, wideband, knock, and idle thresholds are satisfied
- Automatically restore the rollback snapshot and export a rollback revision after a critical or materially regressed validation result
- Persist sessions, evaluations, cycles, audit events, readiness, and reports per project
- Auto-process newly completed desktop logs and imported OBDLink phone logs after the user explicitly starts a closed-loop session
- Keep final PCM writing separate and confirmation-gated in Flash Center

## Automated suite

`npm test` passed **19 of 19 test groups**:

1. XDF parsing, hydration, writeback, and checksum correction
2. Universal Patcher report gating and byte comparison
3. AI exact-cell proposal execution
4. PCM Hammer 2.0 command/output, COM lock, read, Test Write, and write gating
5. Persistent logging and AI analysis
6. Connection Doctor and offline recovery lab
7. Quality-of-life persistence and Quick Switch
8. Garage/project durability
9. Project-scoped calibration workspaces and snapshots
10. Unified Tune Engine coverage and safety envelopes
11. Autonomous Tune Agent complete automatic tune execution
12. Closed-Loop Tune confidence, correction, convergence, rollback point, and readiness
13. Public-beta privacy and diagnostic packaging
14. OBDLink mobile log import
15. Natural-language goal execution
16. P01 identity and dual-read verification
17. P01 evidence integration
18. Guided P01 exact-step recovery ledger
19. Renderer, preload, IPC, event, and DOM contracts

## Focused simulations

**27 of 27 scenarios passed**:

- Closed-Loop Autonomous Tuning: 3
- Autonomous Tune Agent: 3
- Unified Tune Engine: 3
- Garage/project lifecycle: 3
- Workspace isolation/recovery: 3
- Quality-of-life restart/navigation: 3
- Connection Doctor: 3
- Offline P01 Recovery Lab: 3
- P01 hardware-recovery emulation: 3

## Closed-loop scenarios

### 1. Baseline → correction → validation → convergence

Passed. A generated baseline log was fingerprinted and scored, an automatic correction cycle created a new revision, and a different improved validation log met the convergence thresholds. The session reached `converged` and project readiness reached the release-candidate threshold in simulation.

### 2. Unsafe validation and automatic rollback

Passed. A post-correction log containing simulated low voltage, excessive coolant temperature, misfire growth, and unsafe evidence triggered the safety stop. TunIQ restored the saved rollback snapshot and exported a rollback revision.

### 3. Persistence and data-integrity guards

Passed. The test verified duplicate-log rejection, session recovery after manager restart, validation-report export, readiness scoring, and a hard stop after the BIN fingerprint changed.

## Retained recovery verification

The P01 recovery simulations continued to reject:

- Partial reads
- Incorrectly sized reads
- Mismatched dual reads
- Repeated block-read failures
- Locked adapters
- Adapter disconnects
- Interrupted application sessions

The successful P01 simulation continued to require two complete matching 524,288-byte reads and Test Write evidence.

## Verification boundary

This report does **not** claim verification with a physical OBDLink MX+, Windows Bluetooth serial stack, vehicle, wideband, dyno, road test, bench harness, PCM, or live controller write. Generated logs exercise the decision logic but cannot prove that a calibration is safe for a specific real engine. Final PCM writing remains a separate explicit operation.

## Sealed archive verification

The final source ZIP was extracted into a separate clean directory after packaging.

- ZIP integrity: passed
- Source manifest entries: **137 of 137 matched**
- Extracted `npm run check`: passed
- Extracted automated suite: **19 of 19 groups passed**
- Extracted Closed-Loop simulations: **3 of 3 passed**
- Extracted complete retained recovery-lab chain: passed
- Focused simulation total represented by the recovery-lab chain: **27 of 27 passed**
