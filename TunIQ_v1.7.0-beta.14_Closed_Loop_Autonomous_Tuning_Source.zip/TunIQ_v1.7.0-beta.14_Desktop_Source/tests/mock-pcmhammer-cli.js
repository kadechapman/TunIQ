#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const args = process.argv.slice(2);
const command = args[0] || '';
const scenario = process.env.PCMHAMMER_MOCK_SCENARIO || 'success';
const readByte = Number(process.env.PCMHAMMER_MOCK_READ_BYTE || 0x5a) & 0xff;
const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
function option(...names) {
  for (const name of names) {
    const index = args.indexOf(name);
    if (index >= 0 && args[index + 1]) return args[index + 1];
  }
  return '';
}
function positional() { return args.slice(1).find(value => !value.startsWith('-') && !/^COM\d+$/i.test(value)) || ''; }
async function lines(values) { for (const value of values) { console.log(value); await delay(4); } }
function help() {
  console.log(`PCM Hammer CLI\nVersion: 2.0.0\nUsage:\n  read-properties --port <port>\n  read-full --port <port> --output <file>\n  test-write --port <port> --input <file>\n  write-calibration --port <port> --input <file>\n  write-full --port <port> --input <file>\n  recovery --port <port> --input <file>`);
}
(async () => {
  if (['--help','-h','help'].includes(command) || !command) return help();
  if (['--version','-v','version'].includes(command)) return console.log('PCM Hammer CLI Version: 2.0.0');
  if (scenario === 'locked') { console.error('Access to the port COM4 is denied because another program is using it.'); process.exitCode = 2; return; }
  if (scenario === 'disconnect') { console.error('Adapter was disconnected. Lost communication with device.'); process.exitCode = 3; return; }
  if (command === 'read-properties') {
    await lines(['PCM Hammer','Version: 2.0.0','Voltage: 13.4V','VIN: 1GCEC14T01Z123456','OSID: 12212156','Description: P01 Gen III LS PCM, Service No 12200411','Hardware ID: 9386530','Controller: P01','Read Properties completed successfully.']);
    return;
  }
  if (command === 'read-full') {
    const output = option('--output','-o','--file','-f') || positional();
    if (!output) { console.error('Operation failed: output file missing.'); process.exitCode = 4; return; }
    fs.mkdirSync(path.dirname(path.resolve(output)), { recursive: true });
    if (scenario === 'block-fail') {
      await lines(['Reading block 1 of 8','Block 2 failed: timeout','Block 2 failed: timeout','Block 2 failed: timeout','Read operation failed.']);
      process.exitCode = 5; return;
    }
    const size = scenario === 'partial' ? 131072 : 524288;
    fs.writeFileSync(output, Buffer.alloc(size, readByte));
    if (scenario === 'partial') { await lines([`Saved partial image: ${size} bytes`,'Read operation failed before completion.']); process.exitCode = 6; return; }
    await lines(['Reading block 1 of 8 (12%)','Reading block 4 of 8 (50%)','Reading block 8 of 8 (100%)',`Saved BIN file: ${output}`,'Read Entire PCM completed successfully.']);
    return;
  }
  if (command === 'test-write') {
    if (scenario === 'test-unproven') { console.log('Test Write exited.'); return; }
    await lines(['Testing erase and write access','Verification passed','Test Write completed successfully. No changes were written.']);
    return;
  }
  if (['write-calibration','write-full','recovery'].includes(command)) {
    await lines(['Erasing flash 20%','Writing flash 65%','Verification passed','Operation completed successfully.']);
    return;
  }
  console.error(`Unknown command: ${command}`); process.exitCode = 7;
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
