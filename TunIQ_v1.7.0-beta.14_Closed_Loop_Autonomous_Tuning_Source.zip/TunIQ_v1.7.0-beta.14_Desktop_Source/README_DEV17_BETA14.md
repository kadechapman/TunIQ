# TunIQ v1.7.0-beta.14 Developer Notes

## Release theme

Closed-Loop Autonomous Tuning: automatic log confidence, adaptive correction cycles, convergence validation, regression rollback, and project readiness reporting.

## New source

- `src/closed-loop-tune.js`
- `tests/closed-loop-tune-simulations.js`
- `CLOSED_LOOP_AUTONOMOUS_TUNING.md`

## Main-process IPC

- `closed-loop:status`
- `closed-loop:start`
- `closed-loop:analyze-latest`
- `closed-loop:run-cycle`
- `closed-loop:rollback`
- `closed-loop:export-report`
- `closed-loop:reset`

## Persistence

Each project stores its session under `AI/ClosedLoopTune`, including state, audit records, normalized-log evaluation records, a validation report, and archived sessions.

## Important invariants

- A complete Autonomous Tune base run is required before the closed-loop session starts.
- Session, workspace, and autonomous-run BIN/XDF fingerprints must match.
- Duplicate normalized log fingerprints are rejected.
- A new validation drive is required after each correction cycle.
- Critical or materially regressed validation results can restore the saved rollback snapshot.
- Final controller writing remains separate and confirmation-gated.
