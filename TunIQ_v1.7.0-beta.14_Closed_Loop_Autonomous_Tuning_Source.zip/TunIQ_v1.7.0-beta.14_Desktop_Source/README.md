# TunIQ v1.7.0-beta.14 — Closed-Loop Autonomous Tuning

Beta.14 turns the autonomous tune agent into an adaptive validation loop. TunIQ can score fresh logs, measure operating-zone coverage and tune confidence, run mapped correction cycles, compare before/after error, declare convergence, or automatically restore a rollback snapshot when a validation drive becomes unsafe or materially worse.


TunIQ is a project-scoped desktop automotive tuning workspace. Beta.13 turns Full AI into an autonomous calibration executor for supported, exactly mapped tables.

## Beta.13 highlights

- One-button complete supported tune generation
- Automatic mapped-cell application without per-cell approvals
- Conservative target derivation from the build profile
- Automatic recovery snapshots and project saves after every stage
- Automatic checksum-corrected revision exports
- Exact-step restart and resume
- Latest-log correction cycles
- Final handoff package prepared for Flash Center
- Manual Expert Mode retained for users who want to inspect or select cells themselves

Final controller writing remains a separate confirmed operation. See `AUTONOMOUS_TUNE_AGENT.md` for the execution and safety boundary.

## Run from source

1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Run `npm start`.

Use `npm run check`, `npm test`, and `npm run test:recovery-labs` for verification.
