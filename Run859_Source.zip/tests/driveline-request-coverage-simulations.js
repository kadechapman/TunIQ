'use strict';
const assert = require('node:assert/strict');
const { parseTuneRequest } = require('../src/goal-executor');
const { reviewP01Request } = require('../src/p01-request-review');
const project = { id: 'fixture', controller: 'P01', os: '12587603' };
const cases = [
  ['Change rear axle gear ratio to 3.73', 'rear-axle-ratio-review'],
  ['Set my differential gears to 4.10', 'rear-axle-ratio-review'],
  ['Correct tire size to 275/40R20', 'tire-size-review'],
  ['Calibrate for 33 inch tires', 'tire-size-review'],
  ['Give it a ghost cam and set rear axle ratio 3.73 and tires 275/40R20', 'rear-axle-ratio-review'],
];
for (const [request, expected] of cases) {
  const parsed = parseTuneRequest(request);
  assert(parsed.recognized, request);
  assert(parsed.unresolvedRequests.some(x => x.type === expected), request);
  const review = reviewP01Request({ request, activeProject: project });
  assert(review.unresolvedRequests.some(x => x.type === expected), request);
  assert(review.missingSafetyFacts.length > 0, request);
}
for (const request of ['Set speed limiter to 120 MPH', 'My tires are rated 150 MPH', 'Inspect axle bearings', 'The tire pressure is 32 PSI']) {
  assert(!parseTuneRequest(request).unresolvedRequests.some(x => ['rear-axle-ratio-review', 'tire-size-review'].includes(x.type)), request);
}
console.log('Driveline request recognition: 9/9 fixtures passed; all calibration actions remain blocked pending exact OS mapping.');
