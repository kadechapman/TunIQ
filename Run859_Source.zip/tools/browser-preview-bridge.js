/* Hardware-disconnected browser preview. This is NOT an Electron preload. */
(() => {
  'use strict';
  const settings = { aiMode: 'guided', detailLevel: 'beginner', uiPreferences: {} };
  // Each read returns an isolated blocked flash snapshot. A shared object let
  // callers forge a successful flash status in later UI summaries.
  const emptyFlash = () => ({ status: 'blocked', history: [] });
  const allowedPrefs = new Set(['sidebarCollapsed', 'tunePathCollapsed', 'compactDensity',
    'reduceMotion', 'restoreLastPage']);
  const pageName = v => typeof v === 'string' && /^[a-z][a-z0-9-]{0,39}$/.test(v);
  // Returned snapshots must not expose the mutable preference arrays/maps.
  // Otherwise callers can bypass updatePrefs validation through getBootstrap().
  function snapshotSettings() {
    const prefs = settings.uiPreferences;
    return { ...settings, uiPreferences: { ...prefs,
      ...(Array.isArray(prefs.recentPages) ? { recentPages: [...prefs.recentPages] } : {}),
      ...(prefs.scrollPositions ? { scrollPositions: { ...prefs.scrollPositions } } : {})
    } };
  }
  function updatePrefs(patch) {
    if (!patch || typeof patch !== 'object' || Array.isArray(patch) ||
        ![Object.prototype, null].includes(Object.getPrototypeOf(patch)) ||
        Object.keys(patch).length > 8) throw new Error('invalid-preview-preferences');
    const next = {};
    for (const [key, value] of Object.entries(patch)) {
      if (allowedPrefs.has(key) && typeof value === 'boolean') next[key] = value;
      else if (key === 'lastPage' && pageName(value)) next[key] = value;
      else if (key === 'recentPages' && Array.isArray(value) && value.length <= 8 && value.every(pageName))
        next[key] = [...value];
      else if (key === 'scrollPositions' && value && typeof value === 'object' &&
          !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)) &&
          Object.keys(value).length <= 80 && Object.entries(value).every(([page, pos]) =>
            pageName(page) && Number.isSafeInteger(pos) && pos >= 0 && pos <= 10000000))
        next[key] = { ...value };
      else throw new Error('invalid-preview-preferences');
    }
    Object.assign(settings.uiPreferences, next);
    return snapshotSettings();
  }
  const api = Object.freeze({
    getBootstrap: async () => ({
      version: '1.9.0-beta.108 (BROWSER UI DEMO)',
      profile: { name: 'Offline UI Preview' },
      settings: snapshotSettings(),
      vehicles: [], activity: [], projects: [], tools: {},
      device: { connected: false, logging: null },
      beta: { agreementAccepted: true, matrix: [], preferences: {} },
      updates: { state: 'not-configured' }, flash: emptyFlash(),
      liveLogs: [], tuneLibrary: [], communityPosts: []
    }),
    getKnowledgeState: async () => ({}),
    listProjects: async () => [],
    // Empty, inert tune library for navigation; never access calibration files.
    listTuneLibrary: async () => [],
    getProjectFiles: async () => ({ active: null }),
    getWorkspaceSummary: async () => ({
      activeProject: null, tools: {}, device: { connected: false },
      liveLogs: [], aiProposals: [], calibrationHistory: [], flash: emptyFlash(),
      beta: { agreementAccepted: true, matrix: [], preferences: {} },
      updates: { state: 'not-configured' }
    }),
    setUiPreferences: async patch => updatePrefs(patch)
  });
  Object.defineProperty(window, 'tuniq', { value: api, writable: false, configurable: false });
  // This demo has no IPC, network API, Node.js, local storage or device integration.
  // Block non-navigation UI controls so their production labels cannot imply functionality.
  // Match the clicked button itself. An unsafe action nested in a container
  // with a navigation attribute must never inherit the container's allowlist.
  const safeButton = button => typeof button.matches === 'function' && button.matches(
    '.app-sidebar button[data-page], #sidebarToggle, #navBack, #navForward, ' +
    '[data-context-page], [data-jump], [data-recent-page], #quickSwitcherButton, ' +
    '#openQuickSwitcher, [data-quick-index]');
  document.addEventListener('click', event => {
    const button = event.target.closest('button');
    if (button && !safeButton(button)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }, true);
  document.addEventListener('submit', event => {
    event.preventDefault(); event.stopImmediatePropagation();
  }, true);
})();
