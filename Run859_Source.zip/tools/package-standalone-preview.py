#!/usr/bin/env python3
"""Package/verify the hardware-free Win64 browser preview, never Electron.

Build-host tooling only; Python is not required by the delivered Windows EXE.
"""
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

EXE = 'TunIQ_Standalone_Offline_Preview.exe'
HTML = 'TunIQ_Offline_Preview.html'
PROOF = 'static-verification.json'
README = 'READ_ME_FIRST.txt'
ZIP = 'TunIQ_Standalone_Offline_Preview.zip'
README_BYTES = ("TunIQ STANDALONE OFFLINE UI PREVIEW (NO ECU)\n"
    "This is a cross-compiled Windows x64 launcher for a local browser-only UI preview.\n"
    "It is NOT Electron, NOT the full TunIQ application, and NOT verified to run on Windows.\n"
    "No OBD, COM, ECU read, Test Write, write, or flash is available.\n"
    "Do not use it for vehicle calibration. Do not treat this as a public release.\n"
    "Run the EXE on Windows only after local security review, or open the HTML directly.\n").encode('utf-8')
ROOT = Path(__file__).resolve().parent.parent
VERIFY = ROOT / 'tools' / 'verify-windows-standalone-embed.js'
NAMES = (EXE, HTML, PROOF, README)
MAX = {EXE: 8 * 1024 * 1024, HTML: 2 * 1024 * 1024, PROOF: 8192, README: 8192}


def safe_bytes(path, limit):
    st = path.lstat()
    if not path.is_file() or path.is_symlink() or st.st_nlink != 1 or not 0 < st.st_size <= limit:
        raise ValueError('unsafe-package-source-file: ' + path.name)
    data = path.read_bytes()
    after = path.lstat()
    if len(data) != st.st_size or (st.st_ino, st.st_mtime_ns, st.st_ctime_ns) != (after.st_ino, after.st_mtime_ns, after.st_ctime_ns):
        raise ValueError('package-source-changed: ' + path.name)
    return data


def checked_payload(directory):
    exe = safe_bytes(directory / EXE, MAX[EXE]); html = safe_bytes(directory / HTML, MAX[HTML]); proof = safe_bytes(directory / PROOF, MAX[PROOF])
    process = subprocess.run(['node', str(VERIFY), str(directory / EXE), str(directory / HTML)],
        capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        raise ValueError('standalone-static-verification-failed: ' + process.stderr.strip())
    actual = json.loads(process.stdout)
    if json.loads(proof) != actual or actual.get('hardwareAvailable') is not False or actual.get('nativeWindowsRuntimeVerified') is not False or actual.get('fullApplicationVerified') is not False:
        raise ValueError('stale-or-unsafe-static-proof')
    return {EXE: exe, HTML: html, PROOF: proof, README: README_BYTES}



def canonical_zip_bytes(payload):
    """Produce the only accepted ZIP layout; reject unreviewed metadata/overlays."""
    output = io.BytesIO()
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name in NAMES:
            info = zipfile.ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, payload[name], compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return output.getvalue()


def verify(directory):
    directory = Path(directory).resolve()
    expected = checked_payload(directory)
    archive = directory / ZIP
    if archive.is_symlink() or not archive.is_file() or archive.stat().st_size > 12 * 1024 * 1024:
        raise ValueError('unsafe-standalone-zip')
    with zipfile.ZipFile(archive, 'r') as z:
        entries = z.infolist()
        if len(entries) != len(NAMES) or [x.filename for x in entries] != list(NAMES):
            raise ValueError('unexpected-or-duplicate-zip-entries')
        for info in entries:
            # Reject symlinks and special files even when their payload bytes and
            # SHA-256 match. Other ZIP extractors may honor Unix file modes.
            if (info.create_system != 3 or (info.external_attr >> 16) & 0o170000 != 0o100000 or
                info.flag_bits & 0x1 or info.is_dir() or
                info.file_size != len(expected[info.filename]) or info.file_size > MAX[info.filename]):
                raise ValueError('unsafe-zip-entry: ' + info.filename)
            if z.read(info) != expected[info.filename]:
                raise ValueError('zip-byte-mismatch: ' + info.filename)
    # Matching entries and a freshly updated checksum cannot establish that
    # the ZIP has no appended comment, extra fields, alternate local headers,
    # or other unreviewed bytes. Require byte-for-byte canonical packaging.
    archive_bytes = archive.read_bytes()
    if archive_bytes != canonical_zip_bytes(expected):
        raise ValueError('noncanonical-standalone-zip')
    digest = hashlib.sha256(archive_bytes).hexdigest()
    checksum = directory / (ZIP + '.sha256')
    if checksum.is_symlink() or checksum.read_text('ascii') != f'{digest}  {ZIP}\n':
        raise ValueError('zip-checksum-mismatch')
    return {'zipSha256': digest, 'entries': list(NAMES), 'byteParityVerified': True,
        'nativeWindowsRuntimeVerified': False, 'electronRuntimeVerified': False, 'hardwareAvailable': False}


def create(directory):
    directory = Path(directory).resolve()
    payload = checked_payload(directory)
    target = directory / ZIP
    checksum = directory / (ZIP + '.sha256')
    if target.exists() or checksum.exists():
        raise ValueError('refusing-to-overwrite-standalone-package')
    with tempfile.NamedTemporaryFile(dir=directory, prefix='.preview-', suffix='.zip', delete=False) as f:
        temporary = Path(f.name)
    try:
        temporary.write_bytes(canonical_zip_bytes(payload))
        temporary.rename(target)
        checksum.write_text(f'{hashlib.sha256(target.read_bytes()).hexdigest()}  {ZIP}\n', encoding='ascii')
        return verify(directory)
    finally:
        temporary.unlink(missing_ok=True)


if __name__ == '__main__':
    try:
        if len(sys.argv) != 3 or sys.argv[1] not in ('create', 'verify'):
            raise ValueError('usage: package-standalone-preview.py create|verify OUTPUT_DIRECTORY')
        print(json.dumps((create if sys.argv[1] == 'create' else verify)(sys.argv[2]), sort_keys=True))
    except Exception as exc:
        print('Standalone package rejected: ' + str(exc), file=sys.stderr)
        sys.exit(2)
