'use strict';
// Hardware-free preview bridge. The production preload exports many device,
// calibration, and flash operations; it must never be packaged in this preview.
// Only the seven IPC channels implemented by readonly-preview-main.js are exposed.
// Missing operations are deliberately absent, not silently redirected to ECU
// code or mocked as successful writes. This is NOT a full application bridge.
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('tuniq', Object.freeze({
  getBootstrap: () => ipcRenderer.invoke('app:get-bootstrap'),
  getKnowledgeState: () => ipcRenderer.invoke('knowledge:state'),
  listProjects: () => ipcRenderer.invoke('project:list'),
  listTuneLibrary: () => ipcRenderer.invoke('tune-library:list'),
  getProjectFiles: () => ipcRenderer.invoke('project:files'),
  getWorkspaceSummary: () => ipcRenderer.invoke('workspace:get-summary'),
  setUiPreferences: patch => ipcRenderer.invoke('settings:set-ui-preferences', patch)
}));
