#!/usr/bin/env node
'use strict';
// Offline triage only. Never promotes source checks to Windows runtime proof.
const path = require('node:path');
const { inspectWindowsDependencyLock } = require('./windows-dependency-preflight');
const { inspectReadOnlyAdmission } = require('./dev-readonly-admission-preflight');
const { inspectWindowsSourceLayout } = require('./windows-source-path-preflight');
const { triage } = require('./source-integrity-triage');
function inspectWindowsDevReadiness(root = path.resolve(__dirname, '..')) {
  // Exceptions are untrusted: never copy arbitrary error messages into reports.
  const preflightFailure = (prefix, error) => {
    const code = error && typeof error.code === 'string' && /^[A-Z][A-Z0-9_]{0,63}$/.test(error.code)
      ? error.code : 'UNKNOWN';
    return `${prefix}:${code}`;
  };
  let dependencies;
  try { dependencies = inspectWindowsDependencyLock(root); }
  catch (error) { dependencies = { lockfileReady: false, blockers: [preflightFailure('preflight-error', error)] }; }
  let readonly;
  try { readonly = inspectReadOnlyAdmission(root); }
  catch (error) { readonly = { safe: false, blockers: [preflightFailure('readonly-preflight-error', error)] }; }
  let sourceLayout;
  try { sourceLayout = inspectWindowsSourceLayout(root); }
  catch (error) { sourceLayout = { windowsSourcePathsSafe: false, blockers: [preflightFailure('preflight-error', error)] }; }
  // A failed preflight must always produce a blocker, even if a future
  // checker returns an empty or malformed blocker list.
  // A checker claiming success while also reporting blockers is contradictory.
  // Treat malformed blocker collections as unverified rather than trusting flags.
  const validBlockers = result => Array.isArray(result?.blockers) &&
    result.blockers.every(value => typeof value === 'string' && value.trim().length > 0 &&
      !/[\x00-\x1f\x7f]/.test(value) && value.length <= 512) &&
    new Set(result.blockers).size === result.blockers.length;
  const passed = (result, flag) => result?.[flag] === true &&
    validBlockers(result) && result.blockers.length === 0;
  // Never serialize arbitrary objects or blank strings as diagnostic blockers.
  const reasons = (result, ok, fallback) => ok ? [] :
    (validBlockers(result) && result.blockers.length ? result.blockers : [fallback]);
  // A successful flag cannot override contradictory integrity diagnostics.
  const mismatchPaths = Array.isArray(sourceLayout?.contentMismatches)
    ? sourceLayout.contentMismatches.map(item => item?.path) : [];
  const mismatchPathsValid = mismatchPaths.every(value => typeof value === 'string' &&
    value.length > 0 && value.length <= 512 && !/[\x00-\x1f\x7f:]/.test(value) && !value.includes('\\') && !value.startsWith('/') &&
    !value.split('/').some(part => part === '' || part === '.' || part === '..')) &&
    new Set(mismatchPaths).size === mismatchPaths.length;
  const mismatchEvidenceConsistent = mismatchPathsValid && Number.isSafeInteger(sourceLayout?.contentMismatchCount) &&
    sourceLayout.contentMismatchCount >= 0 &&
    Array.isArray(sourceLayout?.contentMismatches) &&
    sourceLayout.contentMismatchCount === sourceLayout.contentMismatches.length;
  const sourceEvidenceClean = mismatchEvidenceConsistent && Number.isSafeInteger(sourceLayout?.fileCount) && sourceLayout.fileCount > 0 &&
    Array.isArray(sourceLayout?.issues) && sourceLayout.issues.length === 0 &&
    sourceLayout?.contentMismatchCount === 0 &&
    Array.isArray(sourceLayout?.contentMismatches) && sourceLayout.contentMismatches.length === 0 &&
    Array.isArray(sourceLayout?.unsafeSourcePaths) && sourceLayout.unsafeSourcePaths.length === 0;
  // Reuse the stricter integrity-evidence validator so a future preflight
  // cannot promote malformed Windows path aliases or duplicate audit records.
  let sourceTriage;
  let sourceTriageFailed = false;
  try { sourceTriage = triage(root, () => sourceLayout); }
  catch (error) {
    sourceTriageFailed = true;
    sourceTriage = { manifestVerified: false };
  }
  // A broken integrity validator is not evidence of a safe checkout.
  const sourceOk = passed(sourceLayout, 'windowsSourcePathsSafe') &&
    sourceEvidenceClean && sourceTriage?.manifestVerified === true;
  const dependencyOk = passed(dependencies, 'lockfileReady');
  const readonlyOk = passed(readonly, 'safe');
  const blockers = [
    ...reasons(sourceLayout, sourceOk, 'unverified').map(value => `source-integrity:${value}`),
    ...(sourceTriageFailed ? ['source-integrity:triage-validator-error'] : []),
    ...reasons(dependencies, dependencyOk, 'unverified').map(value => `dependency:${value}`),
    ...reasons(readonly, readonlyOk, 'unverified').map(value => `readonly:${value}`),
    'native-windows-electron-runtime-not-tested',
    'full-application-runtime-not-tested'
  ];
  // Diagnostic payloads are untrusted preflight output. Never echo terminal
  // controls, unbounded strings, or unsafe paths into readiness artifacts.
  const safeDiagnosticPath = value => typeof value === 'string' && value.length > 0 &&
    value.length <= 512 && !/[\x00-\x1f\x7f:]/.test(value) &&
    !value.includes('\\') && !value.startsWith('/') &&
    !value.split('/').some(part => part === '' || part === '.' || part === '..');
  const diagnosticPaths = values => Array.isArray(values)
    ? values.filter(safeDiagnosticPath).slice(0, 20) : [];
  return {
    schemaVersion: 1,
    auditKind: 'offline-windows-dev-readiness',
    sourceOnly: true,
    dependenciesReady: dependencyOk,
    sourceIntegrityPassed: sourceOk,
    // Diagnostic-only evidence; never used to promote readiness.
    sourceIntegrityEvidence: {
      mismatchEvidenceConsistent,
      contentMismatchCount: Number.isSafeInteger(sourceLayout?.contentMismatchCount) && sourceLayout.contentMismatchCount >= 0
        ? sourceLayout.contentMismatchCount : null,
      mismatchedPaths: Array.isArray(sourceLayout?.contentMismatches)
        ? diagnosticPaths(sourceLayout.contentMismatches.map(item => item?.path)) : [],
      missingOrUnsafePaths: Array.isArray(sourceLayout?.unsafeSourcePaths)
        ? diagnosticPaths(sourceLayout.unsafeSourcePaths) : []
    },
    readonlyAdmissionPassed: readonlyOk,
    nativeWindowsRuntimeVerified: false,
    fullApplicationVerified: false,
    readyForUserTesting: false,
    readyForPublicRelease: false,
    blockers
  };
}
if (require.main === module) {
  const result = inspectWindowsDevReadiness();
  console.log(JSON.stringify(result, null, 2));
  if (result.blockers.length) process.exitCode = 2;
}
module.exports = { inspectWindowsDevReadiness };
