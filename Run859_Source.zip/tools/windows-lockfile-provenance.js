#!/usr/bin/env node
'use strict';
// Hardware-free, offline evidence binding for the Windows operator workflow.
// --capture stores hashes after npm metadata preflight; --verify checks that
// npm ci did not alter package.json, package-lock.json, the saved candidate,
// or the reviewed application source through dependency lifecycle scripts.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { criticalSourceFingerprint } = require('./launch-snapshot');
const MAX_PACKAGE_BYTES = 1024 * 1024;
const MAX_LOCK_BYTES = 8 * 1024 * 1024;
const MAX_REPORT_BYTES = 16 * 1024;
const HEX = /^[a-f0-9]{64}$/;
const REPORT_FIELDS = [
  'kind', 'schemaVersion', 'packageJsonSha256', 'lockfileSha256',
  'candidateSha256', 'criticalSourceSha256', 'criticalSourceFileCount',
  'nativeInstallVerified', 'fullTunIQVerified',
  'physicalHardwareVerified'
].sort();

function regularBytes(file, maxBytes) {
  const before = fs.lstatSync(file);
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1 ||
      !Number.isSafeInteger(before.size) || before.size > maxBytes) {
    throw new Error('Unsafe or oversized dependency evidence file.');
  }
  const flags = fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0);
  const fd = fs.openSync(file, flags);
  try {
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.dev !== before.dev || opened.ino !== before.ino ||
        opened.size !== before.size || opened.nlink !== 1) {
      throw new Error('Dependency evidence changed while opening.');
    }
    const bytes = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, null);
      if (!count) throw new Error('Truncated dependency evidence.');
      offset += count;
    }
    if (fs.readSync(fd, Buffer.alloc(1), 0, 1, null)) {
      throw new Error('Dependency evidence grew during read.');
    }
    const after = fs.fstatSync(fd);
    const current = fs.lstatSync(file);
    for (const stat of [after, current]) {
      if (!stat.isFile() || stat.nlink !== 1 || stat.dev !== before.dev ||
          stat.ino !== before.ino || stat.size !== before.size ||
          stat.mtimeMs !== before.mtimeMs || stat.ctimeMs !== before.ctimeMs) {
        throw new Error('Dependency evidence changed during read.');
      }
    }
    return bytes;
  } finally { fs.closeSync(fd); }
}
function digest(file, maxBytes) {
  return crypto.createHash('sha256').update(regularBytes(file, maxBytes)).digest('hex');
}
function provenance(candidate) {
  // The candidate is an independent copy retained with this run's npm logs.
  // Passing the working lockfile as its own candidate provides no separate
  // provenance evidence, even when the bytes and SHA-256 values match.
  if (fs.realpathSync(candidate) === fs.realpathSync(path.resolve('package-lock.json'))) {
    throw new Error('Candidate must be independent of the working lockfile.');
  }
  // npm ci may run package lifecycle scripts. Dependency manifest and lockfile
  // hashes alone cannot detect source-code mutation during installation. Bind
  // the pre-install snapshot to application code, tools, tests and policies;
  // node_modules and generated diagnostics are intentionally excluded.
  const critical = criticalSourceFingerprint(process.cwd());
  return {
    packageJsonSha256: digest(path.resolve('package.json'), MAX_PACKAGE_BYTES),
    lockfileSha256: digest(path.resolve('package-lock.json'), MAX_LOCK_BYTES),
    candidateSha256: digest(candidate, MAX_LOCK_BYTES),
    criticalSourceSha256: critical.sha256,
    criticalSourceFileCount: critical.fileCount
  };
}
function execute(mode, candidate, report) {
  if (!['--capture', '--verify'].includes(mode) || !candidate || !report) {
    throw new Error('Usage: node windows-lockfile-provenance.js --capture|--verify <candidate> <report>');
  }
  const hashes = provenance(candidate);
  if (hashes.lockfileSha256 !== hashes.candidateSha256) {
    throw new Error('Candidate does not match validated working lockfile.');
  }
  if (mode === '--capture') {
    const data = {
      kind: 'tuniq-windows-lockfile-provenance', schemaVersion: 2,
      ...hashes, nativeInstallVerified: false, fullTunIQVerified: false,
      physicalHardwareVerified: false
    };
    // Exclusive creation: a second run must not overwrite prior evidence.
    fs.writeFileSync(report, JSON.stringify(data, null, 2) + '\n', {flag:'wx', mode:0o600});
    return;
  }
  const data = JSON.parse(regularBytes(report, MAX_REPORT_BYTES).toString('utf8'));
  if (!data || data.kind !== 'tuniq-windows-lockfile-provenance' || data.schemaVersion !== 2 ||
      data.nativeInstallVerified !== false || data.fullTunIQVerified !== false ||
      data.physicalHardwareVerified !== false ||
      JSON.stringify(Object.keys(data).sort()) !== JSON.stringify(REPORT_FIELDS) ||
      !HEX.test(data.packageJsonSha256) || !HEX.test(data.lockfileSha256) ||
      !HEX.test(data.candidateSha256) || !HEX.test(data.criticalSourceSha256) ||
      !Number.isSafeInteger(data.criticalSourceFileCount) || data.criticalSourceFileCount < 2 ||
      Object.keys(hashes).some(key => data[key] !== hashes[key])) {
    throw new Error('Dependency provenance does not match captured evidence.');
  }
}
if (require.main === module) {
  try {
    if (process.argv.length !== 5) throw new Error('Expected mode, candidate and report.');
    execute(process.argv[2], path.resolve(process.argv[3]), path.resolve(process.argv[4]));
    console.log(`Dependency and critical-source provenance ${process.argv[2] === '--capture' ? 'captured' : 'verified'} (offline metadata only; Windows runtime unverified).`);
  } catch (error) {
    console.error(`Dependency provenance NOT VERIFIED: ${error.message}`);
    process.exitCode = 1;
  }
}
module.exports = { execute };
