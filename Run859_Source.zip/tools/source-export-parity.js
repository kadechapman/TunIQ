#!/usr/bin/env node
'use strict';
// Offline source export admission: compare every extracted file to the exact
// committed Git tree, never to a possibly modified working directory.
// This verifies source/export parity only, NOT an Electron runtime or ECU.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const MAX_FILES = 20000;
const MAX_ISSUES = 32;
function git(repo, args) {
  const p = spawnSync('git', ['-C', repo, ...args], {
    encoding: null, windowsHide: true, maxBuffer: 16 * 1024 * 1024
  });
  if (p.error || p.status !== 0) throw new Error(`Git source lookup failed (${args[0]}).`);
  return p.stdout;
}
function inspectSourceExport(repoPath, exportPath, ref = 'HEAD') {
  const repo = path.resolve(repoPath), root = path.resolve(exportPath);
  const issues = [];
  const add = (code, file) => { if (issues.length < MAX_ISSUES) issues.push({ code, path: file }); };
  const rootStat = fs.lstatSync(root);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('Export root must be a real directory.');
  const objectFormat = git(repo, ['rev-parse', '--show-object-format']).toString('utf8').trim();
  if (!['sha1', 'sha256'].includes(objectFormat)) throw new Error('Unsupported Git object hash format.');
  const commit = git(repo, ['rev-parse', '--verify', `${ref}^{commit}`]).toString('utf8').trim();
  if (!/^[0-9a-f]{40}$|^[0-9a-f]{64}$/.test(commit)) throw new Error('Invalid Git commit.');
  const tree = git(repo, ['ls-tree', '-rz', '--full-tree', commit]);
  const expected = new Map();
  for (const entry of tree.toString('utf8').split('\0')) {
    if (!entry) continue;
    const match = /^(\d{6}) blob ([a-f0-9]+)\t(.+)$/.exec(entry);
    if (!match) throw new Error('Git tree contains an unsupported entry.');
    if (expected.has(match[3]) || expected.size >= MAX_FILES) throw new Error('Invalid or oversized Git tree.');
    expected.set(match[3], { mode: match[1], hash: match[2] });
  }
  const seen = new Set();
  let matchedFiles = 0;
  function walk(dir, prefix = '') {
    for (const item of fs.readdirSync(dir, { withFileTypes: true })) {
      const relative = prefix ? `${prefix}/${item.name}` : item.name;
      const full = path.join(dir, item.name);
      const stat = fs.lstatSync(full);
      if (stat.isSymbolicLink() || (!stat.isDirectory() && !stat.isFile())) {
        add('unsafe-entry', relative); continue;
      }
      if (stat.isDirectory()) { walk(full, relative); continue; }
      seen.add(relative);
      if (seen.size > MAX_FILES) throw new Error('Export contains too many files.');
      const record = expected.get(relative);
      if (!record) { add('extra-file', relative); continue; }
      if (record.mode !== '100644' && record.mode !== '100755') {
        add('unsupported-git-mode', relative); continue;
      }
      const content = fs.readFileSync(full);
      const header = Buffer.from(`blob ${content.length}\0`, 'utf8');
      const hash = crypto.createHash(objectFormat).update(header).update(content).digest('hex');
      if (hash !== record.hash) add('content-mismatch', relative);
      else matchedFiles++;
    }
  }
  walk(root);
  for (const name of expected.keys()) if (!seen.has(name)) add('missing-file', name);
  return {
    kind: 'tuniq-source-export-git-parity', schemaVersion: 1,
    commit, objectFormat, expectedFiles: expected.size, seenFiles: seen.size,
    matchedFiles, passed: issues.length === 0 && seen.size === expected.size,
    issues, windowsRuntimeVerified: false, fullTunIQVerified: false,
    hardwareUsed: false
  };
}
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 2 || args.length > 3) {
    console.error('Usage: node tools/source-export-parity.js <git-repo> <extracted-export-directory> [commit]');
    process.exitCode = 2;
  } else {
    try {
      const result = inspectSourceExport(...args);
      console.log(JSON.stringify(result, null, 2));
      if (!result.passed) process.exitCode = 1;
    } catch (error) {
      console.error(`Source export NOT VERIFIED: ${error.message}`);
      process.exitCode = 2;
    }
  }
}
module.exports = { inspectSourceExport };
