#!/usr/bin/env node
'use strict';
// Offline integrity check for the PACKAGED, hardware-free Windows preview.
// A valid PE header/hash does NOT prove Electron started or full TunIQ works.
const fs = require('node:fs');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const MIN_SIZE = 1024 * 1024;
const MAX_SIZE = 1024 * 1024 * 1024;
const KIND = 'tuniq-offline-preview-windows-pe-integrity';
function regularFile(file, maxSize = MAX_SIZE) {
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
      !Number.isSafeInteger(stat.size) || stat.size > maxSize) {
    throw new Error('unsafe-or-oversized-file');
  }
  return stat;
}
function inspectPe(file) {
  const stat = regularFile(file);
  if (stat.size < MIN_SIZE) throw new Error('packaged-executable-too-small');
  const fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const opened = fs.fstatSync(fd);
    if (opened.dev !== stat.dev || opened.ino !== stat.ino ||
        opened.size !== stat.size || opened.nlink !== 1 ||
        opened.mtimeMs !== stat.mtimeMs || opened.ctimeMs !== stat.ctimeMs) {
      throw new Error('file-changed-during-open');
    }
    const header = Buffer.alloc(4096);
    if (fs.readSync(fd, header, 0, header.length, 0) !== header.length ||
        header.toString('ascii', 0, 2) !== 'MZ') throw new Error('missing-dos-header');
    const pe = header.readUInt32LE(0x3c);
    if (pe < 0x40 || pe > header.length - 128 ||
        !header.subarray(pe, pe + 4).equals(Buffer.from([0x50, 0x45, 0, 0]))) {
      throw new Error('missing-pe-header');
    }
    if (header.readUInt16LE(pe + 4) !== 0x8664 ||
        !(header.readUInt16LE(pe + 22) & 0x0002) ||
        header.readUInt16LE(pe + 20) < 70 ||
        header.readUInt16LE(pe + 24) !== 0x20b ||
        header.readUInt16LE(pe + 24 + 68) !== 2) {
      throw new Error('not-amd64-windows-gui-executable');
    }
    // A PE signature and a 2MB file are insufficient: a synthetic placeholder
    // with no sections or entry point is not a credible Windows executable.
    // This is a bounded structural check, NOT a Windows loader/runtime test.
    const sectionCount = header.readUInt16LE(pe + 6);
    const optionalSize = header.readUInt16LE(pe + 20);
    const optional = pe + 24;
    const entryPointRva = header.readUInt32LE(optional + 16);
    const imageSize = header.readUInt32LE(optional + 56);
    const headersSize = header.readUInt32LE(optional + 60);
    const sectionTableEnd = optional + optionalSize + sectionCount * 40;
    if (sectionCount < 1 || sectionCount > 96 ||
        entryPointRva === 0 || imageSize === 0 || entryPointRva >= imageSize ||
        headersSize === 0 || headersSize > imageSize || headersSize > stat.size ||
        sectionTableEnd > headersSize || sectionTableEnd > header.length) {
      throw new Error('invalid-pe-layout');
    }
    const hash = crypto.createHash('sha256');
    const chunk = Buffer.alloc(1024 * 1024);
    let position = 0;
    while (position < stat.size) {
      const count = fs.readSync(fd, chunk, 0, Math.min(chunk.length, stat.size - position), position);
      if (count <= 0) throw new Error('truncated-executable');
      hash.update(chunk.subarray(0, count));
      position += count;
    }
    const after = fs.fstatSync(fd);
    if (after.size !== stat.size || after.mtimeMs !== opened.mtimeMs ||
        after.dev !== opened.dev || after.ino !== opened.ino ||
        after.ctimeMs !== opened.ctimeMs || after.nlink !== 1) {
      throw new Error('executable-changed-during-hash');
    }
    return { schemaVersion: 1, kind: KIND, sizeBytes: stat.size,
      sha256: hash.digest('hex'), machine: 'amd64', subsystem: 'windows-gui',
      nativeStartupVerified: false, fullTunIQVerified: false };
  } finally { fs.closeSync(fd); }
}
function writeEvidence(executable, destination) {
  const proof = inspectPe(executable);
  fs.writeFileSync(destination, JSON.stringify(proof, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  return proof;
}
function readBoundedProof(evidenceFile) {
  // The PE proof is a separate release-admission input. Never check its
  // pathname with lstat and then reopen that pathname for an unchecked read.
  const stat = regularFile(evidenceFile, 4096);
  if (stat.size < 20) throw new Error('empty-integrity-evidence');
  const fd = fs.openSync(evidenceFile, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const sameFile = current => current.isFile() && !current.isSymbolicLink() &&
      current.nlink === 1 && current.dev === stat.dev && current.ino === stat.ino &&
      current.size === stat.size && current.mtimeMs === stat.mtimeMs &&
      current.ctimeMs === stat.ctimeMs;
    if (!sameFile(fs.fstatSync(fd))) throw new Error('pe-proof-changed');
    const bytes = Buffer.alloc(stat.size); // bounded to 4096 bytes
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, offset);
      if (count <= 0) throw new Error('pe-proof-truncated');
      offset += count;
    }
    if (!sameFile(fs.fstatSync(fd)) || !sameFile(fs.lstatSync(evidenceFile))) {
      throw new Error('pe-proof-changed');
    }
    return JSON.parse(bytes.toString('utf8'));
  } finally { fs.closeSync(fd); }
}
function verifyEvidence(executable, evidenceFile) {
  const recorded = readBoundedProof(evidenceFile);
  assert.deepStrictEqual(recorded, inspectPe(executable), 'packaged executable integrity mismatch');
  return true;
}
if (require.main === module) {
  try {
    const [mode, executable, evidenceFile, ...extra] = process.argv.slice(2);
    if (extra.length || !['--write', '--verify'].includes(mode) || !executable || !evidenceFile) {
      throw new Error('usage: --write|--verify EXECUTABLE EVIDENCE_JSON');
    }
    if (mode === '--write') writeEvidence(executable, evidenceFile);
    else verifyEvidence(executable, evidenceFile);
    console.log('Packaged Windows PE integrity verified (NOT runtime or full-app verification).');
  } catch (error) {
    console.error(`Windows PE integrity NOT VERIFIED: ${error.code || error.message}`);
    process.exitCode = 2;
  }
}
module.exports = { inspectPe, writeEvidence, verifyEvidence };
