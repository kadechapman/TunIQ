#!/usr/bin/env python3
"""Optional real Chromium smoke of the inert single-file browser preview.

Requires the third-party Python `playwright` package and an installed Chromium.
This is not Electron, Windows runtime verification, or any ECU operation.
By default the HTML is injected into about:blank for restrictive sandboxes.
Use --file-navigation to verify opening the actual local HTML artifact. A synthetic fetch is CSP-blocked; all browser network routes are denied.
"""
import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import sys

PAGES = ('dashboard', 'garage', 'workflow', 'flash', 'scanner',
         'fullai', 'tunes', 'bridge', 'settings')
API = ('getBootstrap', 'getKnowledgeState', 'listProjects', 'listTuneLibrary',
       'getProjectFiles', 'getWorkspaceSummary', 'setUiPreferences')


def require(condition, message):
    if not condition:
        raise AssertionError(message)


async def handle_preview_route(route, file_uri, main_frame, unexpected_requests):
    request = route.request
    if (file_uri and request.is_navigation_request() and
            request.frame == main_frame and request.url == file_uri):
        await route.continue_()
    else:
        unexpected_requests.append(request.url)
        await route.abort()


async def inspect(html, browser_path=None, screenshot=None, file_uri=None):
    from playwright.async_api import async_playwright
    errors = []
    async with async_playwright() as playwright:
        launch = {'headless': True}
        # Only root-run Linux containers need this Chromium sandbox exception.
        # Never disable the browser sandbox by default on Windows or macOS.
        if sys.platform.startswith('linux') and hasattr(os, 'geteuid') and os.geteuid() == 0:
            launch['args'] = ['--no-sandbox']
        if browser_path:
            launch['executable_path'] = browser_path
        browser = await playwright.chromium.launch(**launch)
        try:
            page = await browser.new_page(viewport={'width': 1365, 'height': 900})
            page.on('pageerror', lambda err: errors.append(str(err)))
            page.on('console', lambda msg: errors.append(msg.text) if msg.type == 'error' else None)
            unexpected_requests = []

            async def deny_request(route):
                # Only the exact main-frame file document is permitted. All
                # subresources and network requests remain blocked.
                await handle_preview_route(route, file_uri, page.main_frame, unexpected_requests)

            # Network attempts are blocked even if the CSP is accidentally weakened.
            await page.route('**/*', deny_request)
            # Do not open a network endpoint or interact with physical hardware.
            if file_uri:
                await page.goto(file_uri, wait_until='domcontentloaded', timeout=15000)
                require(page.url == file_uri, 'Local HTML file navigation changed destination')
            else:
                await page.set_content(html, wait_until='domcontentloaded', timeout=15000)
            await page.wait_for_function("document.querySelector('#dashboard.active') !== null", timeout=10000)
            require(await page.title() == 'TunIQ', 'Unexpected browser title')
            bridge = await page.evaluate('''async () => ({
              methods: Object.keys(window.tuniq || {}).sort(),
              boot: await window.tuniq.getBootstrap(),
              summary: await window.tuniq.getWorkspaceSummary(),
              hasNode: typeof window.require !== 'undefined' || typeof window.process !== 'undefined'
            })''')
            require(bridge['methods'] == sorted(API), 'Unexpected or missing preview bridge methods')
            require(bridge['hasNode'] is False, 'Node API unexpectedly exposed in browser')
            require(bridge['boot']['device']['connected'] is False, 'Device unexpectedly connected')
            require(bridge['boot']['flash']['status'] == 'blocked', 'Flash not blocked in bootstrap')
            require(bridge['summary']['flash']['status'] == 'blocked', 'Flash not blocked in summary')
            # Test actual DOM event interception, not just presence of a warning string.
            blocked = await page.evaluate('''() => {
              const button = document.createElement('button');
              button.textContent = 'Synthetic forbidden action';
              document.body.appendChild(button);
              const clickAllowed = button.dispatchEvent(new MouseEvent('click', { bubbles:true, cancelable:true }));
              button.remove();
              const form = document.createElement('form');
              document.body.appendChild(form);
              const submitAllowed = form.dispatchEvent(new Event('submit', { bubbles:true, cancelable:true }));
              form.remove();
              return { clickAllowed, submitAllowed };
            }''')
            require(blocked == {'clickAllowed': False, 'submitAllowed': False},
                    'Unsafe button or form submission was not intercepted')
            visited = []
            for section in PAGES:
                await page.locator(f'.app-sidebar button[data-page="{section}"]').click(timeout=5000)
                active = await page.locator('section.page.active').evaluate_all('(nodes) => nodes.map(n => n.id)')
                selected = await page.locator('.app-sidebar button[data-page].active').evaluate_all(
                    '(nodes) => nodes.map(n => n.getAttribute("data-page"))')
                banner = page.locator('#offline-dev-banner')
                require(active == [section], f'Navigation mismatch: {section} -> {active}')
                require(selected == [section], f'Sidebar mismatch: {section} -> {selected}')
                require(await banner.is_visible(), f'No visible hardware warning on {section}')
                require('ALL ECU OPERATIONS DISABLED' in await banner.inner_text(),
                        f'Wrong hardware warning on {section}')
                visited.append(section)
            require(not errors, f'Chromium JavaScript errors: {errors[:3]}')
            require(not unexpected_requests, f'Unexpected browser network requests: {unexpected_requests[:3]}')

            # An isolated second page verifies actual CSP enforcement. The previous
            # smoke passed a preview with script-src 'unsafe-inline', even though
            # it would execute injected JavaScript. Do not rely on a CSP string.
            probe = await browser.new_page()
            probe_requests = []
            probe_page_errors = []

            async def deny_probe_request(route):
                probe_requests.append(route.request.url)
                await route.abort()

            try:
                await probe.route('**/*', deny_probe_request)
                probe.on('pageerror', lambda err: probe_page_errors.append(str(err)))
                await probe.set_content(html, wait_until='domcontentloaded', timeout=15000)
                csp_result = await probe.evaluate('''async () => {
                  window.__tuniq_csp_injection_executed = false;
                  const injected = document.createElement('script');
                  injected.textContent = 'window.__tuniq_csp_injection_executed = true';
                  document.body.appendChild(injected);
                  const fetchResult = await fetch('https://example.invalid/tuniq-csp-probe')
                    .then(() => 'allowed', () => 'blocked');
                  injected.remove();
                  return { injectedScriptRan: window.__tuniq_csp_injection_executed,
                    networkFetch: fetchResult };
                }''')
                require(csp_result == {'injectedScriptRan': False, 'networkFetch': 'blocked'},
                        f'Runtime CSP failed closed check: {csp_result}')
                require(not probe_requests, f'CSP allowed a network request: {probe_requests[:3]}')
                require(not probe_page_errors, f'CSP probe JavaScript errors: {probe_page_errors[:3]}')
            finally:
                await probe.close()
            if screenshot:
                await page.screenshot(path=str(screenshot), full_page=False)
            return {
                'passed': True, 'browser': browser.version,
                'pagesVisited': visited, 'pageCount': len(visited),
                'blockedButtonClick': True, 'blockedFormSubmit': True,
                'previewBridgeMethods': bridge['methods'],
                'pageErrors': errors, 'runtimeCspInlineScriptBlocked': True,
                'runtimeCspFetchBlocked': True, 'outgoingBrowserRequests': 0,
                'runtime': 'Linux/host Chromium HTML DOM',
                'htmlLoadedWith': 'Playwright file:// navigation' if file_uri else 'Playwright page.set_content (not file navigation)',
                'nativeWindowsElectronVerified': False,
                'nativeWindowsLauncherVerified': False,
                'fullTunIQVerified': False, 'hardwareUsed': False,
                'ecuReadWriteFlashPerformed': False
            }
        finally:
            await browser.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('html', type=Path)
    parser.add_argument('--evidence', type=Path)
    parser.add_argument('--screenshot', type=Path)
    parser.add_argument('--chromium', default=os.environ.get('TUNIQ_CHROMIUM_PATH'))
    parser.add_argument('--file-navigation', action='store_true',
                        help='Navigate Chromium directly to the local HTML artifact')
    args = parser.parse_args()
    try:
        raw = args.html.read_bytes()
        require(10000 <= len(raw) <= 2 * 1024 * 1024, 'Unexpected preview size')
        html = raw.decode('utf-8')
        require('ALL ECU OPERATIONS DISABLED' in html, 'Hardware warning missing')
        require("connect-src 'none'" in html, 'No-network CSP missing')
        require('BROWSER UI DEMO' in html, 'Not a browser-only preview')
        result = asyncio.run(inspect(html, args.chromium, args.screenshot,
                                     args.html.resolve().as_uri() if args.file_navigation else None))
        result['htmlSha256'] = hashlib.sha256(raw).hexdigest()
        result['htmlBytes'] = len(raw)
        if args.evidence:
            if args.evidence.exists():
                raise FileExistsError('Refusing to overwrite existing evidence')
            args.evidence.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, indent=2))
    except Exception as exc:
        print(f'CHROMIUM PREVIEW SMOKE NOT VERIFIED: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
