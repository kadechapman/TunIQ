'use strict';
// Standalone, intentionally non-ECU-capable Electron main process.
// This is packaged in a strict allowlist WITHOUT src/main.js, flash, OBD, or
// PCM Hammer modules. All non-bootstrap IPC calls are rejected by Electron.
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const { fileURLToPath, pathToFileURL } = require('node:url');

const RENDERER_DIR = path.join(__dirname, 'src', 'renderer');
const ASSETS = new Set(['index.html', 'styles.css', 'engine-catalog.js', 'app.js']);
const CHANNELS = Object.freeze(['app:get-bootstrap', 'knowledge:state', 'project:list',
  'project:files', 'workspace:get-summary', 'settings:set-ui-preferences', 'tune-library:list']);
// Do not share a mutable nested history array between bootstrap responses.
// Offline previews must never inherit caller-forged flash history or status.
function blockedFlashSnapshot() {
  return { status: 'blocked', history: [] };
}
// Renderer navigation saves UI preferences after a click. Without this inert
// handler, every preview navigation generates a rejected IPC call and an error
// toast. Keep only a small, validated in-memory preference object: no disk,
// profile, project, hardware, calibration, or flash operations are available.
const PREVIEW_BOOL_PREFS = new Set(['sidebarCollapsed', 'tunePathCollapsed',
  'compactDensity', 'reduceMotion', 'restoreLastPage']);
let previewUiPreferences = {};
function previewSettings() {
  return { aiMode: 'guided', detailLevel: 'beginner',
    uiPreferences: { ...previewUiPreferences,
      recentPages: [...(previewUiPreferences.recentPages || [])],
      scrollPositions: { ...(previewUiPreferences.scrollPositions || {}) } } };
}
function updatePreviewPreferences(patch) {
  if (!patch || typeof patch !== 'object' || Array.isArray(patch) ||
      ![Object.prototype, null].includes(Object.getPrototypeOf(patch)) ||
      Object.keys(patch).length > 8) throw new Error('invalid-preview-preferences');
  const validated = {};
  const pageName = value => typeof value === 'string' && /^[a-z][a-z0-9-]{0,39}$/.test(value);
  for (const [key, value] of Object.entries(patch)) {
    if (PREVIEW_BOOL_PREFS.has(key) && typeof value === 'boolean') validated[key] = value;
    else if (key === 'lastPage' && pageName(value)) validated[key] = value;
    else if (key === 'recentPages' && Array.isArray(value) && value.length <= 8 &&
        value.every(pageName)) validated[key] = [...value];
    else if (key === 'scrollPositions' && value && typeof value === 'object' &&
        !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value)) &&
        Object.keys(value).length <= 80 && Object.entries(value).every(([name, offset]) =>
          pageName(name) && Number.isSafeInteger(offset) && offset >= 0 && offset <= 10000000)) {
      validated[key] = { ...value };
    } else throw new Error('invalid-preview-preferences');
  }
  previewUiPreferences = { ...previewUiPreferences, ...validated };
  return previewSettings();
}
function reply(channel, payload) {
  switch (channel) {
    case 'app:get-bootstrap': return {
      version: '1.9.0-beta.108 (OFFLINE PREVIEW)',
      profile: { name: 'Offline UI Preview', email: 'preview@local.invalid' },
      settings: previewSettings(),
      vehicles: [], activity: [], projects: [], tools: {},
      device: { connected: false, logging: null },
      beta: { agreementAccepted: true, matrix: [], preferences: {} },
      updates: { state: 'not-configured' }, flash: blockedFlashSnapshot(),
      liveLogs: [], tuneLibrary: [], communityPosts: []
    };
    case 'settings:set-ui-preferences': return updatePreviewPreferences(payload);
    case 'knowledge:state': return {};
    case 'project:list': return [];
    case 'tune-library:list': return []; // inert read-only preview; no calibration files
    case 'project:files': return { active: null };
    case 'workspace:get-summary': return {
      activeProject: null, tools: {}, device: { connected: false },
      liveLogs: [], aiProposals: [], calibrationHistory: [], flash: blockedFlashSnapshot(),
      beta: { agreementAccepted: true, matrix: [], preferences: {} },
      updates: { state: 'not-configured' }
    };
    default: throw new Error('offline-preview-ipc-denied');
  }
}
function admittedUrl(urlString, root = RENDERER_DIR) {
  try {
    const url = new URL(urlString);
    if (url.protocol !== 'file:' || url.search || url.hash) return false;
    const requested = fileURLToPath(url);
    const name = path.relative(root, requested);
    if (!ASSETS.has(name) || path.isAbsolute(name)) return false;
    const stat = fs.lstatSync(requested);
    return stat.isFile() && !stat.isSymbolicLink() && stat.nlink === 1 &&
      fs.realpathSync(requested) === path.join(fs.realpathSync(root), name);
  } catch { return false; }
}
// Only the reviewed HTML document may be a top-level navigation target.
// Stylesheets/scripts are permitted as subresources by admittedUrl, but
// navigating the main window to one of them is not an approved UI state.
function admittedMainFrameNavigation(urlString, root = RENDERER_DIR) {
  return urlString === pathToFileURL(path.join(root, 'index.html')).href &&
    admittedUrl(urlString, root);
}
// A preload bridge can be reached from an unexpected frame if the renderer
// changes. The preview must serve IPC only to its one reviewed top-level
// file document, never to a subframe, another window, or a navigated URL.
// This is defense in depth; it does not authorize ECU-capable channels.
function admitPreviewIpcEvent(event, contents, root = RENDERER_DIR) {
  if (!event || !contents || typeof contents.isDestroyed !== 'function' ||
      contents.isDestroyed() || event.sender !== contents ||
      !contents.mainFrame || event.senderFrame !== contents.mainFrame ||
      typeof event.senderFrame?.url !== 'string') return false;
  // Revalidate the actual document file as well as its frame identity.
  // A hardlinked/replaced index can keep the same URL after initial load;
  // the resource allowlist already refuses that file, so IPC must too.
  return admittedMainFrameNavigation(event.senderFrame.url, root);
}
// A GUI-subsystem packaged Windows executable may have no usable stdout.
// Produce a one-shot, nonce-bound smoke result in the build's disposable temp
// directory; never mistake a process exit code alone for renderer proof.
function writeSmokeEvidence(result, destination, nonce) {
  if (typeof nonce !== 'string' || !/^[a-f0-9]{32}$/.test(nonce) ||
      typeof destination !== 'string' || !path.isAbsolute(destination)) {
    throw new Error('invalid-smoke-evidence-arguments');
  }
  const tempRoot = fs.realpathSync(os.tmpdir());
  const dir = path.dirname(destination);
  if (!/^TunIQ-preview-[a-f0-9]{32}$/.test(path.basename(dir)) ||
      fs.realpathSync(dir) !== path.join(tempRoot, path.basename(dir)) ||
      path.basename(destination) !== `smoke-${nonce}.json`) {
    throw new Error('smoke-evidence-outside-disposable-directory');
  }
  const evidence = { schemaVersion: 1, kind: 'tuniq-offline-preview-smoke', nonce,
    passed: result.passed === true, reason: result.reason,
    hardwareAvailable: false, writeHandlersRegistered: false };
  fs.writeFileSync(destination, JSON.stringify(evidence, null, 2) + '\n',
    { flag: 'wx', mode: 0o600 });
  return evidence;
}
// A visible splash-free dashboard alone does not prove that the preview's
// basic navigation works. This is an inert renderer-only route round-trip;
// it must not call device, calibration, write, or flash IPC.
function assessPreviewNavigation(proof) {
  // Cover all nine sidebar pages, including the hardware-disabled Tune Center,
  // Live Data, AI Studio and Tools pages. Check active-page exclusivity and the exact
  // selected sidebar item. These are inert navigation checks, not ECU tests.
  const route = ['garage', 'workflow', 'flash', 'scanner', 'fullai', 'tunes', 'bridge', 'settings', 'dashboard'];
  return Boolean(proof && typeof proof === 'object' && !Array.isArray(proof) &&
    proof.handlersBound === true && Array.isArray(proof.steps) &&
    proof.steps.length === route.length && proof.steps.every((step, index) =>
      step && step.page === route[index] && step.sectionActive === true &&
      step.sidebarActive === true && step.pageVisible === true && step.warningVisible === true &&
      step.writeControlsDisabled === true && step.activePageCount === 1 &&
      step.activeSidebarCount === 1 && step.selectedSectionId === route[index] &&
      step.selectedSidebarPage === route[index]));
}
// The renderer debounces preference persistence by 180ms. An immediate
// navigation proof can approve a preview before a rejected IPC call raises an
// error toast. Give asynchronous UI work time to settle, then independently
// inspect the visible result. This is a smoke heuristic, not full UI testing.
const NAV_SETTLE_MS = 600;
function assessPreviewSettledState(doc) {
  // A selected Dashboard can remain in the DOM after an async renderer crash,
  // splash regression, or removal of the mandatory no-ECU warning. Do not
  // certify a native Windows preview merely from CSS active-page markers.
  if (!doc || typeof doc.querySelector !== 'function' ||
      typeof doc.querySelectorAll !== 'function' ||
      typeof doc.defaultView?.getComputedStyle !== 'function') return false;
  try {
    const app = doc.querySelector('#app');
    const splash = doc.querySelector('#splash');
    const warning = doc.querySelector('#offline-dev-banner');
    const dashboard = doc.querySelector('#dashboard.active');
    if (!app || !splash || !warning || !dashboard ||
        !warning.textContent.includes('ALL ECU OPERATIONS DISABLED')) return false;
    const appStyle = doc.defaultView.getComputedStyle(app);
    const splashStyle = doc.defaultView.getComputedStyle(splash);
    const warningStyle = doc.defaultView.getComputedStyle(warning);
    const dashboardStyle = doc.defaultView.getComputedStyle(dashboard);
    const warningRect = warning.getBoundingClientRect();
    const dashboardRect = dashboard.getBoundingClientRect();
    // Opacity, geometry, and display alone do not prove a warning is painted.
    // CSS clipping/masking, filter:opacity(0), or content-visibility:hidden
    // can hide the required text without changing its bounding rectangle.
    // Fail closed on non-default paint-suppression styles in the warning's
    // ancestry; this remains a heuristic, not an occlusion/screenshot audit.
    const paintUnsuppressed = style => style &&
      (style.clipPath == null || style.clipPath === 'none') &&
      (style.webkitClipPath == null || style.webkitClipPath === 'none') &&
      (style.filter == null || style.filter === 'none') &&
      (style.maskImage == null || style.maskImage === 'none') &&
      (style.webkitMaskImage == null || style.webkitMaskImage === 'none') &&
      style.contentVisibility !== 'hidden';
    // Opacity is NOT inherited in computed styles. A banner reporting
    // opacity:1 can be fully invisible inside an opacity:0 body/wrapper.
    // Verify the ancestor chain as well as the banner itself before a
    // native preview can claim that its no-ECU warning is visible.
    // Bound traversal to fail closed on unexpected/cyclic fixture trees.
    // The app can be hidden by its own wrapper even when the mandatory
    // no-ECU warning (a sibling under body) remains visible. A navigation
    // smoke must prove both the dashboard and warning have visible ancestors.
    function ancestorsVisible(element) {
      let ancestor = element.parentElement;
      const seenAncestors = new Set();
      while (ancestor) {
        if (seenAncestors.size >= 64 || seenAncestors.has(ancestor)) return false;
        seenAncestors.add(ancestor);
        const style = doc.defaultView.getComputedStyle(ancestor);
        if (!paintUnsuppressed(style) || style.display === 'none' ||
            style.visibility !== 'visible' || style.opacity !== '1') return false;
        ancestor = ancestor.parentElement;
      }
      return true;
    }
    const warningAncestorVisible = ancestorsVisible(warning);
    const appAncestorVisible = ancestorsVisible(app);
    const dashboardAncestorVisible = ancestorsVisible(dashboard);
    const viewportWidth = doc.defaultView.innerWidth;
    const viewportHeight = doc.defaultView.innerHeight;
    // A fully opaque banner can still be translated completely offscreen.
    // Require at least half its width and height inside the viewport, rather
    // than accepting nonzero dimensions of an invisible offscreen element.
    // This is a limited visibility heuristic, not a screenshot or UI audit.
    const warningInViewport = Number.isFinite(viewportWidth) && viewportWidth > 0 &&
      Number.isFinite(viewportHeight) && viewportHeight > 0 &&
      ['left', 'right', 'top', 'bottom', 'width', 'height'].every(key =>
        Number.isFinite(warningRect[key])) &&
      Math.max(0, Math.min(warningRect.right, viewportWidth) -
        Math.max(0, warningRect.left)) >= warningRect.width / 2 &&
      Math.max(0, Math.min(warningRect.bottom, viewportHeight) -
        Math.max(0, warningRect.top)) >= warningRect.height / 2;
    // Run232: an active Dashboard marker does not prove the selected page is
    // painted. A hidden, fully transparent, clipped, or offscreen Dashboard
    // previously passed because the surrounding app and no-ECU banner were
    // visible. Require a meaningful portion of the actual selected section
    // inside the viewport; long scrollable pages need not fit completely.
    const dashboardInViewport = Number.isFinite(viewportWidth) && viewportWidth > 0 &&
      Number.isFinite(viewportHeight) && viewportHeight > 0 &&
      ['left', 'right', 'top', 'bottom', 'width', 'height'].every(key =>
        Number.isFinite(dashboardRect[key])) &&
      dashboardRect.width >= 128 && dashboardRect.height >= 128 &&
      Math.max(0, Math.min(dashboardRect.right, viewportWidth) -
        Math.max(0, dashboardRect.left)) >= 64 &&
      Math.max(0, Math.min(dashboardRect.bottom, viewportHeight) -
        Math.max(0, dashboardRect.top)) >= 64;
    // A banner that exists and has dimensions can still be effectively
    // invisible through opacity: 0 (or a nearly transparent override). The
    // no-ECU warning must be fully opaque in the actual native renderer.
    return appStyle.display !== 'none' && appStyle.visibility === 'visible' &&
      appStyle.opacity === '1' && paintUnsuppressed(appStyle) &&
      appAncestorVisible && app.getBoundingClientRect().width > 0 &&
      app.getBoundingClientRect().height > 0 && splashStyle.display === 'none' &&
      warningStyle.display !== 'none' && warningStyle.visibility === 'visible' &&
      warningStyle.opacity === '1' && paintUnsuppressed(warningStyle) &&
      warningAncestorVisible && warningRect.width > 0 &&
      warningRect.height > 0 && warningInViewport &&
      dashboardStyle.display !== 'none' && dashboardStyle.visibility === 'visible' &&
      dashboardStyle.opacity === '1' && paintUnsuppressed(dashboardStyle) &&
      dashboardAncestorVisible && dashboardInViewport &&
      // Recheck after debounced renderer activity. An async handler must not
      // re-enable Test Write, calibration/full write, or recovery controls.
      ['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery']
        .every(id => doc.getElementById?.(id)?.disabled === true) &&
      !doc.querySelector('#toastStack .app-toast.error') &&
      doc.querySelectorAll('.page.active').length === 1 &&
      doc.querySelectorAll('.app-sidebar button.active').length === 1 &&
      Boolean(doc.querySelector('.app-sidebar button[data-page="dashboard"].active'));
  } catch { return false; }
}
// Test the actual sidebar event path, not a direct showPage() call that
// could pass while the user's navigation buttons do nothing. This function
// is intentionally self-contained so the identical logic can run inside
// Electron's renderer and in a hardware-free DOM fixture.
function runPreviewNavigationRoundTrip(doc) {
  // Self-contained: this exact function body is serialized into Electron.
  const route = ['garage', 'workflow', 'flash', 'scanner', 'fullai', 'tunes', 'bridge', 'settings', 'dashboard'];
  if (!doc || typeof doc.querySelector !== 'function' ||
      typeof doc.querySelectorAll !== 'function' ||
      typeof doc.getElementById !== 'function') return { handlersBound: false, steps: [] };
  const buttons = route.map(page => doc.querySelector(`.app-sidebar button[data-page="${page}"]`));
  const handlersBound = buttons.every(button => typeof button?.onclick === 'function' &&
    typeof button?.click === 'function');
  if (!handlersBound) return { handlersBound: false, steps: [] };
  // A route marker can be active even when its page is hidden by CSS or
  // positioned entirely outside the window. Verify each clicked page before
  // advancing; checking only the final Dashboard cannot catch that defect.
  // Keep this helper self-contained: Electron serializes the whole function.
  function visiblePage(page, isWarning = false) {
    const view = doc.defaultView;
    if (!page || !view || typeof view.getComputedStyle !== 'function' ||
        typeof page.getBoundingClientRect !== 'function' ||
        !Number.isFinite(view.innerWidth) || view.innerWidth <= 0 ||
        !Number.isFinite(view.innerHeight) || view.innerHeight <= 0) return false;
    const seen = new Set();
    for (let element = page; element; element = element.parentElement) {
      if (seen.size >= 64 || seen.has(element)) return false;
      seen.add(element);
      const style = view.getComputedStyle(element);
      if (!style || style.display === 'none' || style.visibility !== 'visible' ||
          style.opacity !== '1' ||
          (style.clipPath && style.clipPath !== 'none') ||
          (style.webkitClipPath && style.webkitClipPath !== 'none') ||
          (style.filter && style.filter !== 'none') ||
          (style.maskImage && style.maskImage !== 'none') ||
          (style.webkitMaskImage && style.webkitMaskImage !== 'none') ||
          style.contentVisibility === 'hidden') return false;
    }
    const rect = page.getBoundingClientRect();
    if (!rect || !['left','right','top','bottom','width','height'].every(key =>
        Number.isFinite(rect[key])) || rect.width < (isWarning ? 128 : 64) ||
        rect.height < (isWarning ? 16 : 64)) return false;
    // The warning is a fixed-height banner. Unlike a scrollable page, it
    // must be mostly inside the viewport on EVERY route, not just Dashboard.
    const requiredWidth = isWarning ? rect.width / 2 : 32;
    const requiredHeight = isWarning ? rect.height / 2 : 32;
    return Math.max(0, Math.min(rect.right, view.innerWidth) - Math.max(0, rect.left)) >= requiredWidth &&
      Math.max(0, Math.min(rect.bottom, view.innerHeight) - Math.max(0, rect.top)) >= requiredHeight;
  }
  const steps = [];
  for (let index = 0; index < route.length; index++) {
    const page = route[index];
    const button = buttons[index];
    button.click(); // actual renderer event path; never call showPage directly
    const activePages = Array.from(doc.querySelectorAll('.page.active'));
    const activeSidebar = Array.from(doc.querySelectorAll('.app-sidebar button.active'));
    const warning = doc.querySelector('#offline-dev-banner');
    steps.push({ page,
      sectionActive: doc.getElementById(page)?.classList.contains('active') === true,
      sidebarActive: button.classList.contains('active') === true,
      pageVisible: visiblePage(doc.getElementById(page)),
      warningVisible: Boolean(warning && typeof warning.textContent === 'string' &&
        warning.textContent.includes('ALL ECU OPERATIONS DISABLED') &&
        visiblePage(warning, true)),
      // The staged/packaged Electron smoke must prove these controls remain
      // disabled on EVERY route, not just rely on missing hardware IPC.
      writeControlsDisabled: ['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery']
        .every(id => doc.getElementById(id)?.disabled === true),
      activePageCount: activePages.length,
      activeSidebarCount: activeSidebar.length,
      selectedSectionId: activePages.length === 1 ? activePages[0].id : null,
      selectedSidebarPage: activeSidebar.length === 1 ? activeSidebar[0].dataset.page : null });
  }
  return { handlersBound, steps };
}
function run() {
  // Electron is loaded ONLY when this dedicated preview process is launched.
  const { app, BrowserWindow, ipcMain, session } = require('electron');
  const { attachRendererNavigationGuard } = require('./src/renderer-navigation-guard');
  app.disableHardwareAcceleration();
  app.commandLine.appendSwitch('disable-gpu');
  let window;
  let finished = false;
  const smoke = process.argv.includes('--smoke');
  let denied = false;
  let sawConsoleError = false;
  function finish(passed, reason) {
    if (finished) return;
    finished = true;
    console.log(JSON.stringify({ kind: 'tuniq-offline-preview-smoke', passed,
      reason, hardwareAvailable: false, writeHandlersRegistered: false }));
    let evidenceSaved = true;
    if (smoke && process.env.TUNIQ_PREVIEW_SMOKE_REPORT) {
      try {
        writeSmokeEvidence({ passed, reason }, process.env.TUNIQ_PREVIEW_SMOKE_REPORT,
          process.env.TUNIQ_PREVIEW_SMOKE_NONCE);
      } catch (error) {
        evidenceSaved = false;
        console.error(`Smoke evidence failed: ${error.message}`);
      }
    }
    try { if (window && !window.isDestroyed()) window.destroy(); } catch {}
    app.exit(passed && evidenceSaved ? 0 : 2);
  }
  app.whenReady().then(async () => {
    for (const channel of CHANNELS) ipcMain.handle(channel, (event, payload) => {
      if (!admitPreviewIpcEvent(event, window?.webContents)) {
        denied = true;
        throw new Error('offline-preview-ipc-origin-denied');
      }
      return reply(channel, payload);
    });
    // Never grant permissions, network, or access to unreviewed local assets.
    const isolated = session.fromPartition(`tuniq-offline-preview-${process.pid}`);
    isolated.setPermissionRequestHandler((_wc, _permission, cb) => cb(false));
    isolated.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (details, cb) => {
      const ok = admittedUrl(details.url);
      if (!ok) denied = true;
      cb({ cancel: !ok });
    });
    window = new BrowserWindow({ width: 1260, height: 850, show: !smoke,
      title: 'TunIQ — OFFLINE UI PREVIEW — NO ECU ACCESS',
      webPreferences: {
        session: isolated,
        preload: path.join(__dirname, 'src', 'preload.js'),
        contextIsolation: true, nodeIntegration: false, sandbox: true,
        webSecurity: true, devTools: false
      }
    });
    window.setMenuBarVisibility(false);
    window.webContents.on('page-title-updated', event => event.preventDefault());
    window.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    window.webContents.on('will-navigate', (event, url) => {
      if (!admittedMainFrameNavigation(url)) {
        denied = true;
        event.preventDefault();
      }
    });
    attachRendererNavigationGuard(window.webContents);
    window.webContents.on('console-message', (_event, details) => {
      if (details?.level === 'error' || details?.level === 2) sawConsoleError = true;
    });
    if (smoke) {
      window.webContents.once('did-finish-load', async () => {
        const deadline = Date.now() + 12000;
        while (!finished && Date.now() < deadline) {
          if (denied || sawConsoleError) return finish(false, 'unexpected-renderer-activity');
          let check;
          try { check = await window.webContents.executeJavaScript(`({
            started: Boolean(document.querySelector('#app') && document.querySelector('#splash')),
            appVisible: Boolean(document.querySelector('#app') &&
              getComputedStyle(document.querySelector('#app')).display !== 'none' &&
              document.querySelector('#app').getBoundingClientRect().width > 0),
            splashHidden: Boolean(document.querySelector('#splash') &&
              getComputedStyle(document.querySelector('#splash')).display === 'none'),
            error: document.body.textContent.includes('Startup error:')
          })`); } catch { return finish(false, 'renderer-inspection-failed'); }
          if (check.error) return finish(false, 'renderer-startup-error');
          if (check.started && check.appVisible && check.splashHidden) {
            // A sidebar click may disable write controls that were enabled
            // on the initial Dashboard. Inspect the ready, unclicked screen
            // before navigating, then inspect again after async activity.
            // Both checks are renderer-only: no ECU or hardware access.
            let initialSafety;
            try {
              initialSafety = await window.webContents.executeJavaScript(
                `(${assessPreviewSettledState.toString()})(document)`);
            } catch { return finish(false, 'preview-initial-safety-inspection-failed'); }
            if (!initialSafety) return finish(false, 'preview-initial-safety-failed');
            if (denied || sawConsoleError) return finish(false, 'unexpected-renderer-activity');
            let navigation;
            try {
              navigation = await window.webContents.executeJavaScript(
                `(${runPreviewNavigationRoundTrip.toString()})(document)`);
            } catch { return finish(false, 'preview-navigation-inspection-failed'); }
            if (!assessPreviewNavigation(navigation)) return finish(false, 'preview-navigation-failed');
            // The real renderer saves UI preferences on a debounced timer.
            // Wait for the IPC promise and any resulting error toast before
            // accepting the smoke, rather than approving on click alone.
            await new Promise(resolve => setTimeout(resolve, NAV_SETTLE_MS));
            if (denied || sawConsoleError) return finish(false, 'unexpected-renderer-activity');
            let settled;
            try {
              settled = await window.webContents.executeJavaScript(
                `(${assessPreviewSettledState.toString()})(document)`);
            } catch { return finish(false, 'preview-navigation-post-click-error'); }
            if (!settled) return finish(false, 'preview-navigation-post-click-error');
            if (denied || sawConsoleError) return finish(false, 'unexpected-renderer-activity');
            return finish(true, 'offline-renderer-ready');
          }
          await new Promise(resolve => setTimeout(resolve, 250));
        }
        return finish(false, 'renderer-timeout');
      });
      window.webContents.on('did-fail-load', (_event, code) => finish(false, `load-failed-${code}`));
      setTimeout(() => finish(false, 'process-timeout'), 18000).unref();
    }
    await window.loadFile(path.join(RENDERER_DIR, 'index.html'));
  }).catch(() => finish(false, 'electron-bootstrap-failed'));
  app.on('window-all-closed', () => app.quit());
}
if (require.main === module) run();
module.exports = { ASSETS, CHANNELS, reply, admittedUrl, admittedMainFrameNavigation, admitPreviewIpcEvent, writeSmokeEvidence, assessPreviewNavigation, runPreviewNavigationRoundTrip, assessPreviewSettledState, NAV_SETTLE_MS };
