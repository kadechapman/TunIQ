#!/usr/bin/env node
'use strict';
// Isolated renderer-only Electron smoke test. Never imports src/main.js,
// FlashManager, OBD modules, or registers hardware IPC handlers.
// Requires an installed Electron runtime and a graphical desktop session.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { fileURLToPath } = require('node:url');

const EXPECTED_CSP = "script-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'; form-action 'none'";
const EXPECTED_SCRIPTS = ['engine-catalog.js', 'app.js'];
// Native smoke must exercise all nine primary sidebar routes, not merely
// prove that a dashboard was painted. These are hardware-free UI clicks.
const PRIMARY_NAV_PAGES = Object.freeze([
  'dashboard', 'garage', 'workflow', 'flash', 'scanner',
  'fullai', 'tunes', 'bridge', 'settings'
]);
// Fail closed: only the four known renderer assets may be fetched.
// A future asset must be reviewed and explicitly admitted here.
const ALLOWED_RENDERER_ASSETS = new Set(['index.html', 'styles.css', ...EXPECTED_SCRIPTS]);
const TIMEOUT_MS = 20000;
const UI_READY_WAIT_MS = 8000;
const UI_POLL_MS = 200;

// Hardware-isolated startup fixture: only the five read-only bootstrap
// requests required to paint an empty workspace are handled. No production
// main-process import, device discovery, serial IPC, writes, or filesystem
// mutation is ever registered in this renderer-only process.
const ISOLATED_BOOTSTRAP_CHANNELS = Object.freeze([
  'app:get-bootstrap', 'knowledge:state', 'project:list',
  'project:files', 'workspace:get-summary'
]);
function isolatedBootstrapReply(channel) {
  switch (channel) {
    case 'app:get-bootstrap':
      return { version: '1.9.0-beta.108', profile: { name: 'Offline startup fixture' },
        settings: { aiMode: 'recommend', uiPreferences: {} },
        vehicles: [], activity: [], projects: [], tools: {},
        device: { connected: false, logging: null },
        beta: { agreementAccepted: true, matrix: [], preferences: {} },
        updates: { state: 'not-configured' },
        flash: { status: 'blocked', history: [] },
        liveLogs: [], tuneLibrary: [], communityPosts: [] };
    case 'knowledge:state': return {};
    case 'project:list': return [];
    case 'project:files': return { active: null };
    case 'workspace:get-summary':
      return { activeProject: null, tools: {}, device: { connected: false },
        liveLogs: [], aiProposals: [], calibrationHistory: [],
        flash: { status: 'blocked', history: [] },
        beta: { agreementAccepted: true, matrix: [], preferences: {} },
        updates: { state: 'not-configured' } };
    default: throw new Error('isolated-ipc-denied');
  }
}
function registerIsolatedBootstrapHandlers(ipcMain) {
  for (const channel of ISOLATED_BOOTSTRAP_CHANNELS) {
    ipcMain.handle(channel, () => isolatedBootstrapReply(channel));
  }
}

// Electron has emitted both (event, level, message, ...) and (event, details)
// console-message signatures. Treat only actual error-level messages as fatal;
// warnings and informational messages do not prove a failed startup.
function isRendererConsoleError(levelOrDetails) {
  const level = levelOrDetails && typeof levelOrDetails === 'object'
    ? levelOrDetails.level : levelOrDetails;
  return level === 'error' || level === 2;
}

// A computed display value on #app alone is not visibility proof: an
// ancestor may be hidden, fully transparent, or have no rendered geometry.
// Keep this pure so the exact predicate can run in Electron and offline tests.
function isRendererElementPainted(element, styleFor) {
  if (!element || typeof element.getClientRects !== 'function') return false;
  // A DOMRectList may contain a zero-area rectangle: merely having a layout
  // box does not prove the main application can be painted on screen.
  const rects = element.getClientRects();
  if (!rects || !Array.from(rects).some(rect =>
    Number.isFinite(rect.width) && Number.isFinite(rect.height) &&
    rect.width > 0 && rect.height > 0)) return false;
  for (let node = element; node && node.nodeType === 1; node = node.parentElement) {
    const style = styleFor(node);
    if (!style || style.display === 'none' || style.visibility !== 'visible' ||
        style.contentVisibility === 'hidden' ||
        !Number.isFinite(Number(style.opacity)) || Number(style.opacity) <= 0) return false;
  }
  return true;
}

// Pure validation: source/fixture tests cannot fabricate Windows runtime proof.
// The actual evidence is gathered by clicking each primary sidebar button in
// an isolated Electron renderer with no ECU-capable IPC handlers registered.
function validPrimaryNavigationProof(proof) {
  if (!proof || typeof proof !== 'object' || Array.isArray(proof) ||
      !Array.isArray(proof.pages) || proof.pages.length !== PRIMARY_NAV_PAGES.length ||
      proof.restoredDashboard !== true) return false;
  return proof.pages.every((entry, index) => entry && typeof entry === 'object' &&
    !Array.isArray(entry) && entry.page === PRIMARY_NAV_PAGES[index] &&
    entry.active === true && entry.sidebarSelected === true &&
    entry.singleActive === true && entry.painted === true &&
    entry.safetyWarningVisible === (entry.page === 'flash' ? true : null) &&
    entry.writeControlsDisabled === (entry.page === 'flash' ? true : null)) &&
    proof.restoredDashboardPainted === true &&
    proof.restoredWriteControlsDisabled === true;
}

// Serialized into Electron's renderer context. It uses real click handlers,
// visible DOM geometry, and an explicit uncommissioned flash safety badge.
// No direct showPage() invocation, calibration change, IPC write, or ECU call.
function inspectPrimaryNavigation(pages, painted) {
  const results = [];
  for (const page of pages) {
    const button = document.querySelector(`.app-sidebar button[data-page="${page}"]`);
    if (button && typeof button.onclick === 'function') button.click();
    const section = document.getElementById(page);
    const warning = page === 'flash' ? document.getElementById('flashSafetyBadge') : null;
    results.push({
      page,
      active: section?.classList.contains('active') === true,
      sidebarSelected: button?.classList.contains('active') === true,
      singleActive: document.querySelectorAll('section.page.active').length === 1,
      painted: painted(section, getComputedStyle),
      safetyWarningVisible: page === 'flash'
        ? Boolean(warning && painted(warning, getComputedStyle) &&
          warning.textContent.trim() === 'CAPABILITY CHECK REQUIRED') : null,
      // The uncommissioned offline fixture must not expose actionable ECU
      // Test Write, calibration write, full write, or recovery controls.
      writeControlsDisabled: page === 'flash'
        ? ['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery']
          .every(id => document.getElementById(id)?.disabled === true) : null
    });
  }
  const dashboardButton = document.querySelector('.app-sidebar button[data-page="dashboard"]');
  if (dashboardButton && typeof dashboardButton.onclick === 'function') dashboardButton.click();
  // Navigation can mutate shared state after Flash Center was inspected.
  // Recheck all ECU-affecting controls after returning to the dashboard;
  // a route that re-enables them must fail the isolated smoke.
  const writeIds = ['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery'];
  const restoredDashboard = document.querySelector('section.page.active');
  return {
    pages: results,
    restoredDashboard: restoredDashboard?.id === 'dashboard' &&
      dashboardButton?.classList.contains('active') === true,
    restoredDashboardPainted: painted(restoredDashboard, getComputedStyle),
    restoredWriteControlsDisabled: writeIds.every(id => document.getElementById(id)?.disabled === true)
  };
}

function assessRendererSnapshot(snapshot) {
  const blockers = [];
  if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot)) {
    return { passed: false, blockers: ['invalid-renderer-snapshot'] };
  }
  if (snapshot.readyState !== 'complete') blockers.push('document-not-loaded');
  if (snapshot.title !== 'TunIQ') blockers.push('unexpected-document-title');
  if (snapshot.csp !== EXPECTED_CSP) blockers.push('missing-or-weakened-csp');
  if (!snapshot.bridgeAvailable) blockers.push('preload-bridge-unavailable');
  // Script tags alone do not prove execution. Check independent, inert UI effects.
  if (snapshot.engineCatalogExecuted !== true) blockers.push('engine-catalog-not-executed');
  if (snapshot.appHandlersBound !== true) blockers.push('app-script-not-executed');
  if (snapshot.startupErrorVisible !== false) blockers.push('renderer-startup-error-or-unknown');
  if (snapshot.consoleErrorObserved !== false) blockers.push('renderer-console-error-or-unknown');
  // Blocking a request prevents the fetch, but does not prove the renderer
  // never attempted an unexpected local file or network access.
  if (snapshot.deniedRequestObserved !== false) blockers.push('renderer-disallowed-resource-request');
  if (!snapshot.rendererDomPresent) blockers.push('renderer-dom-missing');
  if (!validPrimaryNavigationProof(snapshot.navigationProof)) blockers.push('primary-navigation-unverified');
  // The renderer can execute its scripts and bind handlers while bootstrap IPC
  // is still pending. A hidden application behind an active splash is NOT a
  // successful startup, even if the DOM and CSP look correct.
  if (snapshot.appVisible !== true) blockers.push('application-not-visible');
  if (snapshot.splashHidden !== true) blockers.push('splash-not-dismissed');
  if (!snapshot.stylesheetLoaded) blockers.push('stylesheet-not-loaded');
  if (!Array.isArray(snapshot.scripts) || snapshot.scripts.length !== EXPECTED_SCRIPTS.length ||
      snapshot.scripts.some((name, index) => name !== EXPECTED_SCRIPTS[index])) {
    blockers.push('unexpected-renderer-scripts');
  }
  return { passed: blockers.length === 0, blockers };
}

// Allow only real files inside the local renderer directory. In particular,
// a renderer-controlled request must not reach remote services or sibling files.
function isAllowedRendererRequest(requestUrl, rendererRoot) {
  try {
    const url = new URL(requestUrl);
    if (url.protocol !== 'file:' || url.search || url.hash) return false;
    const root = fs.realpathSync(rendererRoot);
    const requestedPath = fileURLToPath(url);
    // Check the requested filename BEFORE resolving it. Otherwise an unlisted
    // symlink to app.js is admitted merely because its target is allowlisted.
    const requestedRelative = path.relative(root, requestedPath);
    if (!ALLOWED_RENDERER_ASSETS.has(requestedRelative) || path.isAbsolute(requestedRelative)) return false;
    const stat = fs.lstatSync(requestedPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) return false;
    const target = fs.realpathSync(requestedPath);
    return target === path.join(root, requestedRelative);
  } catch { return false; }
}

// Native runtime evidence is written only by the Electron process after the
// renderer inspection completes. A unique nonce prevents accepting stale logs.
function writeRendererEvidence(proof, filename, nonce) {
  // Never accept a caller-supplied success boolean as proof of navigation.
  // Error exits may have a null snapshot, but must carry explicit blockers.
  if (!proof || typeof proof !== 'object' || Array.isArray(proof) ||
      !Object.prototype.hasOwnProperty.call(proof, 'snapshot') ||
      !Array.isArray(proof.blockers) ||
      proof.blockers.some(blocker => typeof blocker !== 'string' || !blocker)) {
    throw new Error('A renderer snapshot and explicit blockers are required for evidence.');
  }
  if (typeof filename !== 'string' || !path.isAbsolute(filename) ||
      !/^[a-f0-9]{32}$/.test(nonce || '')) {
    throw new Error('Invalid isolated renderer evidence destination or nonce.');
  }
  const assessment = assessRendererSnapshot(proof.snapshot);
  const navigationVerified = validPrimaryNavigationProof(proof.snapshot?.navigationProof);
  // A pure Node fixture must never emit a passing artifact that claims
  // native Electron execution. This remains a process-local smoke, not
  // cryptographic attestation or a complete application / hardware test.
  const actualElectronRuntime = typeof process.versions.electron === 'string' &&
    process.type === 'browser';
  const passed = actualElectronRuntime && assessment.passed &&
    proof.blockers.length === 0 && navigationVerified;
  const evidence = {
    schemaVersion: 1, kind: 'tuniq-isolated-renderer-runtime-smoke', nonce,
    passed, actualElectronRuntime,
    nativeWindowsElectronVerified: passed && process.platform === 'win32',
    rendererSnapshotValidated: assessment.passed,
    primaryNavigationVerified: navigationVerified,
    observedPrimaryPageCount: navigationVerified ? PRIMARY_NAV_PAGES.length : 0,
    runtimeBlockerCount: proof.blockers.length,
    snapshotBlockerCount: assessment.blockers.length,
    fullTunIQVerified: false, hardwareUsed: false, ecuWriteOrFlashPerformed: false
  };
  fs.writeFileSync(filename, JSON.stringify(evidence, null, 2) + '\n',
    { flag: 'wx', mode: 0o600 });
  return evidence;
}

function runElectronSmoke() {
  const { app, BrowserWindow, session, ipcMain } = require('electron');
  const { attachRendererNavigationGuard } = require('../src/renderer-navigation-guard');
  const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-renderer-smoke-'));
  app.setPath('userData', profile);
  app.disableHardwareAcceleration();
  app.commandLine.appendSwitch('disable-gpu');
  let finished = false;
  let window = null;
  let consoleErrorObserved = false;
  let deniedRequestObserved = false;
  const finish = (blockers, snapshot = null) => {
    if (finished) return;
    finished = true;
    clearTimeout(deadline);
    // Denied requests remain a failure even if the UI happened to load.
    // Do not log request URLs: they may contain sensitive local paths.
    if (deniedRequestObserved && !blockers.includes('renderer-disallowed-resource-request')) {
      blockers.push('renderer-disallowed-resource-request');
    }
    const passed = blockers.length === 0;
    console.log(JSON.stringify({ mode: 'isolated-electron-renderer-only', passed, blockers,
      snapshot, actualElectronRuntime: true, fullApplicationStartupVerified: false,
      physicalHardwareVerified: false, ecuWriteOrFlashPerformed: false }, null, 2));
    let evidenceSaved = true;
    if (process.env.TUNIQ_RENDERER_SMOKE_REPORT) {
      try {
        writeRendererEvidence({ snapshot, blockers }, process.env.TUNIQ_RENDERER_SMOKE_REPORT,
          process.env.TUNIQ_RENDERER_SMOKE_NONCE);
      } catch (error) {
        evidenceSaved = false;
        console.error('Isolated renderer evidence could not be persisted.');
      }
    }
    try { if (window && !window.isDestroyed()) window.destroy(); } catch {}
    // Electron may still hold a Windows profile lock; cleanup is best-effort.
    try { fs.rmSync(profile, { recursive: true, force: true }); } catch {}
    app.exit(passed && evidenceSaved ? 0 : 2);
  };
  const deadline = setTimeout(() => finish(['electron-renderer-timeout']), TIMEOUT_MS);
  app.whenReady().then(async () => {
    if (finished) return;
    registerIsolatedBootstrapHandlers(ipcMain);
    const isolatedSession = session.fromPartition(`tuniq-smoke-${process.pid}`);
    // Deny remote URLs and local files outside the renderer asset directory.
    // No network or hardware IPC is available to this isolated process.
    const rendererRoot = path.join(__dirname, '..', 'src', 'renderer');
    isolatedSession.webRequest.onBeforeRequest({ urls: ['<all_urls>'] }, (details, callback) => {
      const allowed = isAllowedRendererRequest(details.url, rendererRoot);
      if (!allowed) deniedRequestObserved = true;
      callback({ cancel: !allowed });
    });
    window = new BrowserWindow({ show: false, width: 1024, height: 768,
      webPreferences: { session: isolatedSession,
        preload: path.join(__dirname, '..', 'src', 'preload.js'),
        contextIsolation: true, nodeIntegration: false, sandbox: true } });
    attachRendererNavigationGuard(window.webContents);
    // A page can have a complete DOM while its scripts report an uncaught
    // error. Observe errors from the start of navigation, not just the final
    // DOM snapshot. Do not include potentially sensitive console text in logs.
    window.webContents.on('console-message', (_event, levelOrDetails) => {
      if (isRendererConsoleError(levelOrDetails)) consoleErrorObserved = true;
    });
    window.webContents.on('preload-error', () => finish(['preload-error']));
    window.webContents.on('render-process-gone', () => finish(['render-process-gone']));
    window.webContents.on('did-fail-load', (_event, code, description, _url, isMainFrame) => {
      if (isMainFrame !== false) finish([`renderer-load-failed:${code}:${description}`]);
    });
    window.webContents.once('did-finish-load', async () => {
      if (finished) return;
      try {
        // Wait a bounded time for the actual application to leave its splash.
        // A fixed post-load delay could falsely pass an indefinitely pending
        // bootstrap IPC call because handlers and DOM were already present.
        // This renderer-only process intentionally has no hardware IPC handlers.
        const started = Date.now();
        let snapshot;
        do {
          if (finished) return;
          // Evaluate the same audited predicate used by offline tests. A
          // hidden ancestor or zero-size app must never satisfy startup.
          snapshot = await window.webContents.executeJavaScript(`({
            readyState: document.readyState,
            title: document.title,
            csp: document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.getAttribute('content') || null,
            bridgeAvailable: typeof window.tuniq?.getBootstrap === 'function',
            engineCatalogExecuted: Array.isArray(window.TunIQEngineCatalog?.catalog) &&
              typeof window.TunIQEngineCatalog?.findEngineSelection === 'function',
            appHandlersBound: typeof document.querySelector('#sidebarToggle')?.onclick === 'function',
            startupErrorVisible: document.body.textContent?.includes('Startup error:') === true,
            rendererDomPresent: Boolean(document.querySelector('#app') && document.querySelector('#splash')),
            appVisible: (${isRendererElementPainted.toString()})(document.querySelector('#app'), getComputedStyle),
            splashHidden: Boolean(document.querySelector('#splash') &&
              !(${isRendererElementPainted.toString()})(document.querySelector('#splash'), getComputedStyle)),
            stylesheetLoaded: Array.from(document.styleSheets).some(sheet => sheet.href?.endsWith('/styles.css')),
            scripts: Array.from(document.querySelectorAll('script[src]')).map(script => script.getAttribute('src'))
          })`);
          snapshot.consoleErrorObserved = consoleErrorObserved;
          snapshot.deniedRequestObserved = deniedRequestObserved;
          if ((snapshot.appVisible && snapshot.splashHidden) ||
              snapshot.startupErrorVisible || consoleErrorObserved) break;
          if (Date.now() - started >= UI_READY_WAIT_MS) break;
          await new Promise(resolve => setTimeout(resolve, UI_POLL_MS));
        } while (!finished);
        if (finished) return;
        // Only after a visible, loaded dashboard: exercise real sidebar
        // handlers and require nine painted pages plus the flash safety badge.
        if (snapshot.appVisible && snapshot.splashHidden && !snapshot.startupErrorVisible &&
            !consoleErrorObserved) {
          snapshot.navigationProof = await window.webContents.executeJavaScript(
            `(${inspectPrimaryNavigation.toString()})(${JSON.stringify(PRIMARY_NAV_PAGES)}, ${isRendererElementPainted.toString()})`);
          snapshot.consoleErrorObserved = consoleErrorObserved;
          snapshot.deniedRequestObserved = deniedRequestObserved;
        }
        const assessment = assessRendererSnapshot(snapshot);
        finish(assessment.blockers, snapshot);
      } catch (error) { finish([`renderer-inspection-failed:${error.message}`]); }
    });
    await window.loadFile(path.join(__dirname, '..', 'src', 'renderer', 'index.html'));
  }).catch(error => finish([`electron-startup-failed:${error.message}`]));
}

if (require.main === module) runElectronSmoke();
module.exports = { writeRendererEvidence, assessRendererSnapshot, isRendererElementPainted, isAllowedRendererRequest, isRendererConsoleError, isolatedBootstrapReply, registerIsolatedBootstrapHandlers, ISOLATED_BOOTSTRAP_CHANNELS, EXPECTED_CSP, EXPECTED_SCRIPTS, ALLOWED_RENDERER_ASSETS, PRIMARY_NAV_PAGES, validPrimaryNavigationProof, inspectPrimaryNavigation, TIMEOUT_MS };
