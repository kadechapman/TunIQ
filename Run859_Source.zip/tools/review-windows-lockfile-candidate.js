#!/usr/bin/env node
'use strict';
// Review a Windows CI lockfile candidate against THIS exact Git checkout.
// Read-only: never installs packages, promotes the lockfile, launches Electron,
// connects to hardware, or makes a release-readiness assertion.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { inspectWindowsDependencyLock, MAX_LOCK_BYTES } = require('./windows-dependency-preflight');
const HEX64 = /^[a-f0-9]{64}$/;
const SHA1 = /^[a-f0-9]{40}$/;
const PROOF_FIELDS = [
  'candidateSha256', 'electronRuntimeVerified', 'fullTunIQVerified',
  'kind', 'metadataPreflightPassed', 'nativeInstallVerified',
  'nodeVersion', 'npmVersion', 'physicalHardwareVerified',
  'schemaVersion', 'sourceCommit', 'sourcePackageSha256'
].sort();
function readRegular(file, maxBytes) {
  // Bind the read to the same inode/device that was validated. A path-based
  // readFileSync between lstat calls can follow a swapped symlink or another
  // inode before the path is restored; timestamps alone do not prove which
  // bytes were read. O_NOFOLLOW is available on Unix; fstat + lstat is also
  // required for Windows, where the flag may not be supported.
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
      !Number.isSafeInteger(stat.size) || stat.size < 1 || stat.size > maxBytes) {
    throw new Error('Unsafe or oversized review input.');
  }
  let fd;
  try {
    fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const same = current => current.isFile() && current.nlink === 1 &&
      current.dev === stat.dev && current.ino === stat.ino &&
      current.size === stat.size && current.mtimeMs === stat.mtimeMs &&
      current.ctimeMs === stat.ctimeMs;
    if (!same(fs.fstatSync(fd))) throw new Error('Review input changed before open.');
    const bytes = Buffer.alloc(stat.size);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, null);
      if (count <= 0) throw new Error('Review input truncated during read.');
      offset += count;
    }
    if (fs.readSync(fd, Buffer.alloc(1), 0, 1, null) !== 0 ||
        !same(fs.fstatSync(fd)) || !same(fs.lstatSync(file))) {
      throw new Error('Review input changed during read.');
    }
    return bytes;
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
  }
}
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function reviewCandidate(sourceDir, artifactDir) {
  // Resolve actual filesystem targets before trusting a review directory.
  // A candidate inside the checkout (including through a symlink/junction)
  // can be untracked and still pass git diff HEAD. Keep review artifacts
  // outside the source tree, as required by the generation operator.
  const source = fs.realpathSync(sourceDir);
  const artifact = fs.realpathSync(artifactDir);
  const relative = path.relative(source, artifact);
  if (relative === '' || (relative !== '..' && !relative.startsWith('..' + path.sep) &&
      !path.isAbsolute(relative))) {
    throw new Error('Review artifact must resolve outside the source checkout.');
  }
  const sourcePackage = readRegular(path.join(source, 'package.json'), 1024 * 1024);
  const candidate = readRegular(path.join(artifact, 'package-lock.candidate.json'), MAX_LOCK_BYTES);
  const proofBytes = readRegular(path.join(artifact, 'candidate-provenance.json'), 16 * 1024);
  let proof;
  try { proof = JSON.parse(proofBytes.toString('utf8')); }
  catch { throw new Error('Candidate provenance is not valid JSON.'); }
  if (!proof || typeof proof !== 'object' || Array.isArray(proof) ||
      JSON.stringify(Object.keys(proof).sort()) !== JSON.stringify(PROOF_FIELDS) ||
      proof.kind !== 'tuniq-windows-lockfile-candidate' || proof.schemaVersion !== 1 ||
      proof.metadataPreflightPassed !== true || proof.nativeInstallVerified !== false ||
      proof.electronRuntimeVerified !== false || proof.fullTunIQVerified !== false ||
      proof.physicalHardwareVerified !== false ||
      !SHA1.test(proof.sourceCommit) || !HEX64.test(proof.sourcePackageSha256) ||
      !HEX64.test(proof.candidateSha256) ||
      !/^v\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(proof.nodeVersion) ||
      !/^\d+\.\d+\.\d+(?:[-+][\w.-]+)?$/.test(proof.npmVersion)) {
    throw new Error('Candidate provenance schema or unverified-status fields are invalid.');
  }
  const head = spawnSync('git', ['-C', source, 'rev-parse', '--verify', 'HEAD^{commit}'],
    { encoding: 'utf8', timeout: 10000, windowsHide: true });
  if (head.error || head.status !== 0 || !SHA1.test(head.stdout.trim()) ||
      head.stdout.trim() !== proof.sourceCommit) {
    throw new Error('Candidate was not generated from this exact source commit.');
  }
  // The commit SHA can match while the working-tree package.json has
  // uncommitted edits. A provenance record could be regenerated to match
  // those edits, so bind the manifest bytes to the actual committed blob.
  const committedPackage = spawnSync('git', ['-C', source, 'cat-file', 'blob', 'HEAD:package.json'],
    { timeout: 10000, windowsHide: true, maxBuffer: 1024 * 1024 + 4096 });
  if (committedPackage.error || committedPackage.status !== 0 ||
      !Buffer.isBuffer(committedPackage.stdout) ||
      !sourcePackage.equals(committedPackage.stdout)) {
    throw new Error('On-disk dependency manifest does not match the source commit.');
  }
  // The named commit must describe every tracked review input, not just
  // package.json. Otherwise altered workflow/preflight policy files could be
  // used to bless a candidate while provenance still names a clean commit.
  // Compare HEAD with both index and worktree; untracked CI output is allowed.
  const trackedDiff = spawnSync('git', ['-C', source, 'diff', '--quiet',
    '--no-ext-diff', 'HEAD', '--'],
    { timeout: 10000, windowsHide: true });
  if (trackedDiff.error || trackedDiff.status !== 0) {
    throw new Error('Tracked source files differ from the claimed source commit.');
  }
  if (sha(sourcePackage) !== proof.sourcePackageSha256 ||
      sha(candidate) !== proof.candidateSha256) {
    throw new Error('Candidate dependency manifest or lockfile digest mismatch.');
  }
  // Metadata preflight requires package-lock.json, but the reviewed candidate
  // must NEVER be copied into the source checkout. Use a disposable directory.
  const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-lock-review-'));
  try {
    fs.writeFileSync(path.join(scratch, 'package.json'), sourcePackage, {flag:'wx'});
    fs.writeFileSync(path.join(scratch, 'package-lock.json'), candidate, {flag:'wx'});
    const audit = inspectWindowsDependencyLock(scratch);
    if (!audit.lockfileReady) throw new Error(`Candidate metadata preflight failed: ${audit.blockers.join(', ')}`);
  } finally { fs.rmSync(scratch, { recursive: true, force: true }); }
  return {
    kind: 'tuniq-lockfile-candidate-review', schemaVersion: 1,
    passed: true, sourceCommit: proof.sourceCommit,
    sourcePackageSha256: proof.sourcePackageSha256,
    candidateSha256: proof.candidateSha256,
    metadataPreflightPassed: true, nativeInstallVerified: false,
    electronRuntimeVerified: false, fullTunIQVerified: false,
    physicalHardwareVerified: false,
    nextStep: 'Manual dependency review, then a clean native Windows npm ci and Electron test. Do not automatically promote this candidate.'
  };
}
if (require.main === module) {
  if (process.argv.length !== 3) {
    console.error('Usage: node tools/review-windows-lockfile-candidate.js <extracted-candidate-artifact-directory>');
    process.exitCode = 2;
  } else {
    try { console.log(JSON.stringify(reviewCandidate(path.resolve(__dirname, '..'), process.argv[2]), null, 2)); }
    catch (error) { console.error(`Lockfile candidate NOT VERIFIED: ${error.message}`); process.exitCode = 1; }
  }
}
module.exports = { reviewCandidate };
