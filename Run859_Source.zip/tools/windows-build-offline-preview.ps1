# Optional interactive launch is strictly AFTER native packaged and delivered
# smoke, PE integrity, and complete delivered-tree verification. Default is
# build-only for CI; this never starts the production ECU-capable main.js.
param([switch]$LaunchAfterVerifiedBuild)
# Windows-only. Produces an ISOLATED, OFFLINE UI PREVIEW after actual smoke tests.
# Does NOT package src/main.js or enable real device, write or flash IPC.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
function Step([string]$Title, [string]$Command, [string[]]$Args) {
  $script:currentStep = $Title
  Write-Host "[TunIQ offline preview] $Title"
  & $Command @Args
  if ($LASTEXITCODE -ne 0) { throw "$Title failed with exit code $LASTEXITCODE. No build approval." }
}
if ($env:OS -ne 'Windows_NT') { throw 'Requires Windows.' }
$src = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
# Persist useful diagnostics even if dependency resolution or Windows startup fails.
# Review logs for local usernames/paths before sharing. Never log environment secrets.
$diagnostics = Join-Path $src ('dev-build-output\Run97-Diagnostics-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $diagnostics -Force | Out-Null
Write-Host "[TunIQ] Diagnostic output: $diagnostics"
# Capture npm debug logs in this same run-specific folder, including failures
# before Electron can start. Review raw logs for private paths before sharing.
$npmLogArg = '--logs-dir=' + $diagnostics
$transcriptStarted = $false
# This status file is intentionally limited to a reviewed step label and outcome;
# raw npm diagnostics stay in the transcript and are not copied into JSON.
$script:currentStep = 'windows-preflight'
$script:buildSucceeded = $false
$script:deliveredPreviewDirectory = $null
$script:interactiveLaunchProcessAlive = $false
$script:interactiveLaunchWindowVisible = $false
try {
  Start-Transcript -LiteralPath (Join-Path $diagnostics 'windows-build-transcript.txt') -ErrorAction Stop | Out-Null
  $transcriptStarted = $true
  Write-Host '[TunIQ] Hardware-free UI preview only; no ECU connection or writes.'
  if (!(Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'Node.js 20+ with npm.cmd is required.' }
if (!(Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Node.js 20+ is required.' }
if ([int]((& node.exe -p 'process.versions.node.split(".")[0]').Trim()) -lt 20) { throw 'Requires Node.js 20+.' }
# Do not use or mutate the original working tree for dependency installation.
$work = Join-Path $env:TEMP ('TunIQ-preview-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work | Out-Null
$excluded = @('.git','node_modules','dist','release','dev-build-output','private-hardware-evidence')
if (Get-ChildItem -LiteralPath $src -Force -Recurse -Attributes ReparsePoint -ErrorAction Stop | Select-Object -First 1) {
  throw 'Source contains a reparse point. Refusing unsafe preview copy.'
}
foreach ($entry in Get-ChildItem -LiteralPath $src -Force) {
  if ($excluded -contains $entry.Name) { continue }
  Copy-Item -LiteralPath $entry.FullName -Destination $work -Recurse -Force
}
Push-Location $work
try {
  Step 'Offline source integrity and syntax' 'npm.cmd' @('run','check')
  Step 'Source path safety' 'npm.cmd' @('run','check:windows-source-paths')
  Step 'Production write-denial safety' 'npm.cmd' @('run','check:dev-readonly-admission')
  Step 'Offline Electron contract' 'npm.cmd' @('run','check:electron-startup-contract')
  Step 'Verify npm lockfile writer behavior (offline fixture)' 'node.exe' @('tests/windows-lockfile-generation-simulations.js')
  # Capture the reviewed source manifest BEFORE npm lock resolution. npm's
  # package-lock-only mode must not silently rewrite the dependency manifest;
  # a later provenance capture would otherwise bless the modified input.
  $manifestHashBefore = (Get-FileHash -LiteralPath (Join-Path $work 'package.json') -Algorithm SHA256).Hash
  if (!(Test-Path -LiteralPath 'package-lock.json' -PathType Leaf)) {
    # Fail quickly on unavailable registry instead of waiting through npm's default retries.
    # npm --save=false suppresses writing package-lock.json even when
    # --package-lock-only exits successfully. Force both flags true so the
    # real dependency graph is persisted; the source tree is only a temp copy.
    Step 'Resolve genuine npm lock graph without running scripts' 'npm.cmd' @('install','--package-lock-only','--package-lock=true','--save=true','--ignore-scripts','--no-audit','--no-fund','--fetch-retries=0','--fetch-timeout=15000',$npmLogArg)
    if (!(Test-Path -LiteralPath 'package-lock.json' -PathType Leaf)) {
      throw 'npm returned success but did not write package-lock.json. Check npm save/package-lock settings; no build approval.'
    }
  }
  $manifestHashAfter = (Get-FileHash -LiteralPath (Join-Path $work 'package.json') -Algorithm SHA256).Hash
  if ($manifestHashAfter -ne $manifestHashBefore) {
    throw 'package.json changed during npm lockfile resolution. No build approval.'
  }
  Step 'Review lock graph constraints' 'node.exe' @('tools/windows-dependency-preflight.js','--require-lock')
  # Preserve the genuine npm-generated lockfile in this run's unique
  # diagnostics folder BEFORE npm ci. An earlier run never blocks this one.
  $candidate = Join-Path $diagnostics 'package-lock.candidate.json'
  Copy-Item -LiteralPath 'package-lock.json' -Destination $candidate -ErrorAction Stop
  Write-Host "[TunIQ] Review the candidate lockfile: $candidate"
  # The candidate is an independent diagnostic copy. Bind it to the exact
  # package.json and lockfile before npm ci, then reject post-install edits.
  # This is offline metadata provenance, not native Electron or ECU proof.
  $provenanceReport = Join-Path $diagnostics 'lockfile-provenance.json'
  Step 'Capture preview dependency provenance' 'node.exe' @('tools/windows-lockfile-provenance.js','--capture',$candidate,$provenanceReport)
  Step 'Install locked Electron dependencies' 'npm.cmd' @('ci','--no-audit','--no-fund','--fetch-retries=0','--fetch-timeout=30000',$npmLogArg)
  Step 'Verify preview dependency provenance after npm ci' 'node.exe' @('tools/windows-lockfile-provenance.js','--verify',$candidate,$provenanceReport)
  # The source-only launch snapshot deliberately fingerprints package-lock.json.
  # npm ci needs that genuine lockfile, but the offline source suite must run
  # against the original, lockfile-free snapshot. A direct `npm test` here would
  # see a newly generated lockfile and fail the source snapshot check despite a
  # successful install. Preserve the installed/verified graph in $work and run
  # the full suite in a separate clean, hardware-free source copy instead.
  $suiteSource = Join-Path $env:TEMP ('TunIQ-offline-suite-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $suiteSource -ErrorAction Stop | Out-Null
  $suiteExcluded = @('node_modules','package-lock.json','dist','release',
    'dev-build-output','offline-preview-package')
  foreach ($entry in Get-ChildItem -LiteralPath $work -Force) {
    if ($suiteExcluded -contains $entry.Name) { continue }
    Copy-Item -LiteralPath $entry.FullName -Destination $suiteSource -Recurse -Force -ErrorAction Stop
  }
  if (Get-ChildItem -LiteralPath $suiteSource -Force -Recurse -Attributes ReparsePoint -ErrorAction Stop | Select-Object -First 1) {
    throw 'Offline suite copy contains a reparse point. No test approval.'
  }
  Push-Location $suiteSource
  try {
    Step 'Complete offline simulated suite' 'npm.cmd' @('test')
  } finally { Pop-Location }
  # Execute the real Electron renderer check with a hard timeout, native
  # stdout/stderr capture and a fresh nonce-bound proof. A successful exit
  # without a renderer proof cannot authorize subsequent preview packaging.
  $rendererNonce = [guid]::NewGuid().ToString('N')
  $rendererReport = Join-Path $work ("renderer-smoke-$rendererNonce.json")
  $oldRendererReport = $env:TUNIQ_RENDERER_SMOKE_REPORT
  $oldRendererNonce = $env:TUNIQ_RENDERER_SMOKE_NONCE
  try {
    $env:TUNIQ_RENDERER_SMOKE_REPORT = $rendererReport
    $env:TUNIQ_RENDERER_SMOKE_NONCE = $rendererNonce
    $script:currentStep = 'Real hardware-isolated renderer runtime'
    Write-Host '[TunIQ offline preview] Real hardware-isolated renderer runtime'
    $electron = Join-Path $work 'node_modules\electron\dist\electron.exe'
    if (!(Test-Path -LiteralPath $electron -PathType Leaf)) { throw 'Installed Electron executable missing.' }
    $rendererScript = Join-Path $work 'tools\electron-renderer-runtime-smoke.js'
    $rendererArgs = '"' + $rendererScript.Replace('"', '') + '"'
    $rendererProcess = Start-Process -FilePath $electron -ArgumentList $rendererArgs -WorkingDirectory $work -PassThru `
      -RedirectStandardOutput (Join-Path $diagnostics 'renderer-runtime.stdout.log') `
      -RedirectStandardError (Join-Path $diagnostics 'renderer-runtime.stderr.log')
    if (-not $rendererProcess.WaitForExit(45000)) {
      Stop-Process -Id $rendererProcess.Id -Force -ErrorAction SilentlyContinue
      throw 'Isolated renderer runtime timed out after 45 seconds.'
    }
    if ($rendererProcess.ExitCode -ne 0) { throw "Isolated renderer runtime failed (exit $($rendererProcess.ExitCode))." }
  } finally {
    if (Test-Path -LiteralPath $rendererReport -PathType Leaf) {
      Copy-Item -LiteralPath $rendererReport -Destination (Join-Path $diagnostics 'renderer-runtime-evidence.json') -ErrorAction Stop
    }
    $env:TUNIQ_RENDERER_SMOKE_REPORT = $oldRendererReport
    $env:TUNIQ_RENDERER_SMOKE_NONCE = $oldRendererNonce
  }
  if (!(Test-Path -LiteralPath $rendererReport -PathType Leaf)) { throw 'Isolated renderer runtime produced no evidence.' }
  $rendererProof = Get-Content -LiteralPath $rendererReport -Raw | ConvertFrom-Json
  if ($rendererProof.kind -ne 'tuniq-isolated-renderer-runtime-smoke' -or
      $rendererProof.schemaVersion -ne 1 -or $rendererProof.nonce -ne $rendererNonce -or
      $rendererProof.passed -ne $true -or $rendererProof.actualElectronRuntime -ne $true -or
      $rendererProof.nativeWindowsElectronVerified -ne $true -or
      $rendererProof.rendererSnapshotValidated -ne $true -or
      $rendererProof.primaryNavigationVerified -ne $true -or
      $rendererProof.observedPrimaryPageCount -ne 9 -or
      $rendererProof.runtimeBlockerCount -ne 0 -or $rendererProof.snapshotBlockerCount -ne 0 -or
      $rendererProof.fullTunIQVerified -ne $false -or $rendererProof.hardwareUsed -ne $false -or
      $rendererProof.ecuWriteOrFlashPerformed -ne $false) {
    throw 'Isolated renderer runtime evidence is incomplete, stale, or unsuccessful.'
  }
  # No production main.js, flash.js, OBD, serial, PCM Hammer, or updater is
  # copied to this staged package. All unhandled IPC methods are denied.
  $stage = Join-Path $work 'offline-preview-package'
  Step 'Stage strictly allowlisted, hardware-free Electron application' 'node.exe' @('tools/stage-readonly-preview.js','--output',$stage)
  Step 'Verify staged preview file hashes and allowlist' 'node.exe' @('tools/stage-readonly-preview.js','--verify',$stage)
  $electron = Join-Path $work 'node_modules\electron\dist\electron.exe'
  if (!(Test-Path -LiteralPath $electron -PathType Leaf)) { throw 'Installed Electron executable missing.' }
  # Require renderer-ready evidence for the unpackaged Electron smoke too;
  # a successful process exit without a renderer proof must not pass.
  $stageNonce = [guid]::NewGuid().ToString('N')
  $stageReport = Join-Path $work ("smoke-$stageNonce.json")
  $previousReport = $env:TUNIQ_PREVIEW_SMOKE_REPORT
  $previousNonce = $env:TUNIQ_PREVIEW_SMOKE_NONCE
  try {
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $stageReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $stageNonce
    # A hung Electron process must not block this script indefinitely.
    # Start-Process joins -ArgumentList entries; quote the project directory
    # because Windows user TEMP paths commonly contain spaces.
    $script:currentStep = 'Launch staged preview in real Electron (smoke mode)'
    Write-Host '[TunIQ offline preview] Launch staged preview in real Electron (smoke mode)'
    $stageArgs = '"' + $stage.Replace('"', '') + '" --smoke'
    # Capture native Electron diagnostics; PowerShell transcripts alone do not
    # reliably include stdout/stderr from GUI-subsystem child processes.
    $stageProcess = Start-Process -FilePath $electron -ArgumentList $stageArgs -WorkingDirectory $work -PassThru `
      -RedirectStandardOutput (Join-Path $diagnostics 'staged-electron.stdout.log') `
      -RedirectStandardError (Join-Path $diagnostics 'staged-electron.stderr.log')
    if (-not $stageProcess.WaitForExit(30000)) {
      Stop-Process -Id $stageProcess.Id -Force -ErrorAction SilentlyContinue
      throw 'Staged Electron smoke timed out after 30 seconds.'
    }
    if ($stageProcess.ExitCode -ne 0) { throw "Staged Electron smoke failed (exit $($stageProcess.ExitCode))." }
  } finally {
    # Preserve a failed or partial renderer report too, not only passing proof.
    # This is diagnostic evidence, never approval to continue packaging.
    if (Test-Path -LiteralPath $stageReport -PathType Leaf) {
      Copy-Item -LiteralPath $stageReport -Destination (Join-Path $diagnostics 'staged-smoke-evidence.json') -ErrorAction Stop
    }
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $previousReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $previousNonce
  }
  $script:currentStep = 'Validate staged Electron renderer evidence'
  if (!(Test-Path -LiteralPath $stageReport -PathType Leaf)) { throw 'Staged Electron smoke produced no renderer evidence.' }
  $stageProof = Get-Content -LiteralPath $stageReport -Raw | ConvertFrom-Json
  if ($stageProof.kind -ne 'tuniq-offline-preview-smoke' -or
      $stageProof.schemaVersion -ne 1 -or $stageProof.nonce -ne $stageNonce -or
      $stageProof.passed -ne $true -or $stageProof.reason -ne 'offline-renderer-ready' -or
      $stageProof.hardwareAvailable -ne $false -or $stageProof.writeHandlersRegistered -ne $false) {
    throw 'Staged Electron renderer evidence is incomplete, stale, or unsuccessful.'
  }
  $builder = Join-Path $work 'node_modules\.bin\electron-builder.cmd'
  if (!(Test-Path -LiteralPath $builder -PathType Leaf)) { throw 'Installed electron-builder executable missing.' }
  Step 'Reverify staged preview before packaging' 'node.exe' @('tools/stage-readonly-preview.js','--verify',$stage)
  # electron-builder v26 documents --dir as the unpacked-output switch.
  # Do not pass 'dir' as a positional Windows target: explicitly prevent NSIS
  # installer creation and keep the expected dist\win-unpacked layout.
  Step 'Package hardware-free preview only (NO installer)' $builder @('--projectDir',$stage,'--win','--dir','--x64','--publish','never')
  $exe = Join-Path $stage 'dist\win-unpacked\TunIQ Offline UI Preview.exe'
  if (!(Test-Path -LiteralPath $exe -PathType Leaf)) { throw 'Expected preview executable was not created.' }
  # A GUI executable may exit zero without its console output being captured.
  # Require a fresh, nonce-bound success artifact from the packaged process.
  $script:currentStep = 'Packaged Windows executable smoke'
  $nonce = [guid]::NewGuid().ToString('N')
  $smokeReport = Join-Path $work ("smoke-$nonce.json")
  $oldReport = $env:TUNIQ_PREVIEW_SMOKE_REPORT
  $oldNonce = $env:TUNIQ_PREVIEW_SMOKE_NONCE
  try {
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $smokeReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $nonce
    $result = Start-Process -FilePath $exe -ArgumentList @('--smoke') -PassThru `
      -RedirectStandardOutput (Join-Path $diagnostics 'packaged-electron.stdout.log') `
      -RedirectStandardError (Join-Path $diagnostics 'packaged-electron.stderr.log')
    if (-not $result.WaitForExit(30000)) {
      Stop-Process -Id $result.Id -Force -ErrorAction SilentlyContinue
      throw 'Packaged preview smoke timed out.'
    }
    if ($result.ExitCode -ne 0) { throw "Packaged preview smoke failed (exit $($result.ExitCode))." }
  } finally {
    if (Test-Path -LiteralPath $smokeReport -PathType Leaf) {
      Copy-Item -LiteralPath $smokeReport -Destination (Join-Path $diagnostics 'packaged-smoke-evidence.json') -ErrorAction Stop
    }
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $oldReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $oldNonce
  }
  if (!(Test-Path -LiteralPath $smokeReport -PathType Leaf)) { throw 'Packaged smoke produced no evidence file.' }
  $smokeProof = Get-Content -LiteralPath $smokeReport -Raw | ConvertFrom-Json
  if ($smokeProof.kind -ne 'tuniq-offline-preview-smoke' -or
      $smokeProof.schemaVersion -ne 1 -or $smokeProof.nonce -ne $nonce -or
      $smokeProof.passed -ne $true -or $smokeProof.reason -ne 'offline-renderer-ready' -or
      $smokeProof.hardwareAvailable -ne $false -or $smokeProof.writeHandlersRegistered -ne $false) {
    throw 'Packaged smoke evidence is incomplete, stale, or unsuccessful.'
  }
  # Bind ALL resources of the smoke-tested packaged image, not just its EXE.
  # The delivered smoke exercises only a small UI path; a changed app.asar or
  # DLL during copy could otherwise pass and receive a fresh delivered manifest.
  Step 'Record smoke-tested packaged preview tree' 'node.exe' @('tools/windows-preview-tree-integrity.js','--write',
    (Join-Path $stage 'dist\win-unpacked'),
    (Join-Path $diagnostics 'packaged-preview-tree-integrity.json'))
  # Unique output per successful run: preserve older preview builds and allow
  # a corrected retry without manually deleting the previous executable.
  $output = Join-Path $src ('dev-build-output\Offline-UI-Preview-' + [guid]::NewGuid().ToString('N'))
  if (Test-Path -LiteralPath $output) { throw "Refusing to overwrite prior preview: $output" }
  New-Item -ItemType Directory -Path (Split-Path $output) -Force | Out-Null
  Copy-Item -LiteralPath (Join-Path $stage 'dist\win-unpacked') -Destination $output -Recurse
  # The executable shipped to the user is the copied output, not the temporary
  # package we smoke-tested above. Bind both images by SHA-256 and run the
  # delivered copy with its OWN fresh renderer proof before build approval.
  $script:currentStep = 'Verify delivered preview executable copy'
  $deliveredExe = Join-Path $output 'TunIQ Offline UI Preview.exe'
  if (!(Test-Path -LiteralPath $deliveredExe -PathType Leaf)) { throw 'Delivered preview executable missing.' }
  $packagedHash = (Get-FileHash -LiteralPath $exe -Algorithm SHA256 -ErrorAction Stop).Hash
  $deliveredHash = (Get-FileHash -LiteralPath $deliveredExe -Algorithm SHA256 -ErrorAction Stop).Hash
  if ($packagedHash -ne $deliveredHash) { throw 'Delivered executable differs from smoke-tested packaged executable.' }
  Step 'Verify delivered copy against packaged preview tree' 'node.exe' @('tools/windows-preview-tree-integrity.js','--verify',
    $output, (Join-Path $diagnostics 'packaged-preview-tree-integrity.json'))
  $script:currentStep = 'Delivered Windows executable smoke'
  $deliveredNonce = [guid]::NewGuid().ToString('N')
  $deliveredReport = Join-Path $work ("smoke-$deliveredNonce.json")
  $oldReport = $env:TUNIQ_PREVIEW_SMOKE_REPORT
  $oldNonce = $env:TUNIQ_PREVIEW_SMOKE_NONCE
  try {
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $deliveredReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $deliveredNonce
    $deliveredProcess = Start-Process -FilePath $deliveredExe -ArgumentList @('--smoke') `
      -WorkingDirectory $output -PassThru `
      -RedirectStandardOutput (Join-Path $diagnostics 'delivered-electron.stdout.log') `
      -RedirectStandardError (Join-Path $diagnostics 'delivered-electron.stderr.log')
    if (-not $deliveredProcess.WaitForExit(30000)) {
      Stop-Process -Id $deliveredProcess.Id -Force -ErrorAction SilentlyContinue
      throw 'Delivered preview smoke timed out after 30 seconds.'
    }
    if ($deliveredProcess.ExitCode -ne 0) { throw "Delivered preview smoke failed (exit $($deliveredProcess.ExitCode))." }
  } finally {
    if (Test-Path -LiteralPath $deliveredReport -PathType Leaf) {
      Copy-Item -LiteralPath $deliveredReport -Destination (Join-Path $diagnostics 'delivered-smoke-evidence.json') -ErrorAction Stop
    }
    $env:TUNIQ_PREVIEW_SMOKE_REPORT = $oldReport
    $env:TUNIQ_PREVIEW_SMOKE_NONCE = $oldNonce
  }
  if (!(Test-Path -LiteralPath $deliveredReport -PathType Leaf)) { throw 'Delivered preview smoke produced no evidence.' }
  $deliveredProof = Get-Content -LiteralPath $deliveredReport -Raw | ConvertFrom-Json
  if ($deliveredProof.kind -ne 'tuniq-offline-preview-smoke' -or
      $deliveredProof.schemaVersion -ne 1 -or $deliveredProof.nonce -ne $deliveredNonce -or
      $deliveredProof.nonce -eq $nonce -or $deliveredProof.nonce -eq $stageNonce -or
      $deliveredProof.nonce -eq $rendererNonce -or
      $deliveredProof.passed -ne $true -or $deliveredProof.reason -ne 'offline-renderer-ready' -or
      $deliveredProof.hardwareAvailable -ne $false -or $deliveredProof.writeHandlersRegistered -ne $false) {
    throw 'Delivered executable smoke evidence is incomplete, stale, or unsuccessful.'
  }
  # Validate the actual copied image is an AMD64 Windows GUI PE and record a
  # SHA-256 binding. This is additional artifact integrity, NOT startup proof.
  Step 'Record packaged Windows PE integrity' 'node.exe' @('tools/windows-pe-integrity.js','--write',
    (Join-Path $output 'TunIQ Offline UI Preview.exe'),
    (Join-Path $diagnostics 'packaged-executable-integrity.json'))
  # Hash the COMPLETE delivered folder after its native smoke. An intact EXE
  # alone is not sufficient if app.asar, Electron DLLs, or locales change.
  Step 'Record delivered preview tree integrity' 'node.exe' @('tools/windows-preview-tree-integrity.js','--write',
    $output, (Join-Path $diagnostics 'delivered-preview-tree-integrity.json'))
  # Bind the exact delivered output folder to this diagnostic run.
  # Record only a generated basename, never an absolute user path.
  $script:deliveredPreviewDirectory = Split-Path $output -Leaf
  Write-Host "[TunIQ] Windows UI preview smoke passed; executable: $output\TunIQ Offline UI Preview.exe"
  Write-Host '[TunIQ] This is a hardware-free PREVIEW ONLY. Full TunIQ is NOT READY FOR USER TESTING.'
  if ($LaunchAfterVerifiedBuild) {
    # The user-facing entry point must display an ACTUAL visible top-level
    # window from the exact smoke-tested delivered executable. Merely keeping
    # an Electron process alive is not sufficient: it can be blank/headless.
    # CI remains build-only; this interactive check runs only with the switch.
    # This is still not a full UI or ECU-functionality test.
    $script:currentStep = 'Open verified offline UI preview interactively'
    Write-Host '[TunIQ] Starting verified OFFLINE preview (NO ECU access).'
    $interactivePreview = Start-Process -FilePath $deliveredExe -WorkingDirectory $output -PassThru -ErrorAction Stop
    # Windows PowerShell 5.1 may decode BOM-less scripts as ANSI; construct
    # the Electron title's Unicode em dash without non-ASCII script literals.
    $dash = [char]0x2014
    $expectedTitle = "TunIQ $dash OFFLINE UI PREVIEW $dash NO ECU ACCESS"
    $windowSeen = $false
    $interactiveApproved = $false
    try {
      # Check actual HWND visibility, not only process liveness or a title.
      # Only Windows user32.dll is used; no hardware or network access.
      Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class TunIQOfflineWindowProbe {
  [DllImport("user32.dll", SetLastError = false)]
  public static extern bool IsWindowVisible(IntPtr handle);
}
'@ -ErrorAction Stop
      $deadline = (Get-Date).AddSeconds(15)
      while ((Get-Date) -lt $deadline) {
        Start-Sleep -Milliseconds 250
        $interactivePreview.Refresh()
        if ($interactivePreview.HasExited) {
          throw 'Verified offline preview exited before showing its window.'
        }
        $handle = $interactivePreview.MainWindowHandle
        if ($handle -ne [IntPtr]::Zero -and
            $interactivePreview.MainWindowTitle -ceq $expectedTitle -and
            [TunIQOfflineWindowProbe]::IsWindowVisible($handle)) {
          $windowSeen = $true
          break
        }
      }
      if (-not $windowSeen) {
        throw 'Offline preview process stayed alive but no matching visible window appeared within 15 seconds.'
      }
      # This file records a real Windows UI window check only when actually
      # executed. It is NOT a native renderer navigation or full app proof.
      [ordered]@{
        schemaVersion = 1
        kind = 'tuniq-offline-preview-visible-window'
        nonce = [guid]::NewGuid().ToString('N')
        diagnosticsRun = Split-Path $diagnostics -Leaf
        deliveredPreviewDirectory = Split-Path $output -Leaf
        deliveredExeSha256 = $deliveredHash.ToLowerInvariant()
        probeMethod = 'user32-IsWindowVisible-and-exact-title'
        passed = $true
        actualWindowsWindowCheck = $true
        exactExpectedTitle = $true
        visible = $true
        hardwareUsed = $false
        fullTunIQVerified = $false
      } | ConvertTo-Json -Depth 2 | Set-Content -LiteralPath (Join-Path $diagnostics 'interactive-window-evidence.json') -Encoding UTF8 -ErrorAction Stop
      $script:interactiveLaunchProcessAlive = $true
      $script:interactiveLaunchWindowVisible = $true
      $interactiveApproved = $true
      Write-Host '[TunIQ] Verified visible OFFLINE UI preview window. No ECU operations are available.'
    } finally {
      if (-not $interactiveApproved) {
        Stop-Process -Id $interactivePreview.Id -Force -ErrorAction SilentlyContinue
      }
    }
  }
  $script:buildSucceeded = $true
}
finally { Pop-Location }
} catch {
  Write-Host "[TunIQ] FAILED: $($_.Exception.Message)"
  Write-Host "[TunIQ] Diagnostics preserved: $diagnostics"
  throw
} finally {
  # A compact machine-readable outcome survives failures before npm installation.
  # Do not serialize environment variables, command output, or local user paths.
  $outcome = [ordered]@{
    schemaVersion = 1
    kind = 'tuniq-offline-preview-build-outcome'
    passed = $script:buildSucceeded
    lastStep = $script:currentStep
    windowsRuntimeVerified = $script:buildSucceeded
    fullTunIQVerified = $false
    hardwareUsed = $false
    diagnosticsRun = Split-Path $diagnostics -Leaf
    deliveredPreviewDirectory = $script:deliveredPreviewDirectory
    interactiveLaunchRequested = [bool]$LaunchAfterVerifiedBuild
    interactiveLaunchProcessAlive = $script:interactiveLaunchProcessAlive
    interactiveLaunchWindowVisible = $script:interactiveLaunchWindowVisible
  }
  try {
    $outcome | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $diagnostics 'build-outcome.json') -Encoding UTF8 -ErrorAction Stop
  } catch { Write-Warning 'Could not persist build-outcome.json; see transcript for details.' }
  if ($transcriptStarted) { Stop-Transcript | Out-Null }
  # Produce a safe, bounded classification even when npm or Electron failed.
  # Raw logs remain local; diagnosis.json contains only fixed codes and guidance.
  if (Get-Command node.exe -ErrorAction SilentlyContinue) {
    try {
      & node.exe (Join-Path $src 'tools/diagnose-windows-preview.js') $diagnostics --write
      if ($LASTEXITCODE -ne 0) { Write-Warning 'Windows preview diagnosis was unavailable; original build outcome remains authoritative.' }
    } catch { Write-Warning 'Windows preview diagnosis could not be generated; see the local transcript.' }
  }
}
