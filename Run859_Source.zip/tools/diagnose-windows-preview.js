#!/usr/bin/env node
'use strict';
// Read-only, offline triage of one Windows offline-preview attempt.
// Never emit raw npm/Electron logs, environment variables, local paths, or ECU data.
const fs = require('node:fs');
const path = require('node:path');
const MAX_LOG_BYTES = 128 * 1024;
const MAX_JSON_BYTES = 64 * 1024;
// Build-only and one-click interactive launch have distinct terminal steps.
const FINAL_PREVIEW_STEP = 'Record delivered preview tree integrity';
const FINAL_INTERACTIVE_STEP = 'Open verified offline UI preview interactively';
const ALLOWED_STEPS = new Set([
  'windows-preflight', 'Offline source integrity and syntax', 'Source path safety',
  'Production write-denial safety', 'Offline Electron contract',
  'Verify npm lockfile writer behavior (offline fixture)',
  'Resolve genuine npm lock graph without running scripts', 'Review lock graph constraints',
  'Capture preview dependency provenance', 'Install locked Electron dependencies',
  'Verify preview dependency provenance after npm ci', 'Complete offline simulated suite',
  'Real hardware-isolated renderer runtime',
  'Stage strictly allowlisted, hardware-free Electron application',
  'Launch staged preview in real Electron (smoke mode)',
  'Validate staged Electron renderer evidence',
  'Package hardware-free preview only (NO installer)',
  'Packaged Windows executable smoke',
  'Verify delivered preview executable copy', 'Delivered Windows executable smoke',
  'Record packaged Windows PE integrity', 'Record delivered preview tree integrity',
  'Record smoke-tested packaged preview tree', 'Verify delivered copy against packaged preview tree',
  'Verify staged preview file hashes and allowlist', 'Reverify staged preview before packaging',
  FINAL_INTERACTIVE_STEP
]);
function safeRead(directory, basename, limit = MAX_JSON_BYTES, tail = false) {
  const file = path.join(directory, basename);
  try {
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
        !Number.isSafeInteger(stat.size)) return null;
    if (!tail && stat.size > limit) return null;
    const fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    try {
      const opened = fs.fstatSync(fd);
      if (!opened.isFile() || opened.ino !== stat.ino || opened.dev !== stat.dev ||
          opened.size !== stat.size || opened.nlink !== 1) return null;
      const bytes = Math.min(stat.size, limit);
      const data = Buffer.alloc(bytes);
      let done = 0;
      while (done < bytes) {
        const n = fs.readSync(fd, data, done, bytes - done, (tail ? stat.size - bytes : 0) + done);
        if (!n) return null;
        done += n;
      }
      return data.toString('utf8');
    } finally { fs.closeSync(fd); }
  } catch { return null; }
}
// npm may write its failure only to a debug log, not the PowerShell
// transcript. Read at most eight bounded, regular log files from this one
// diagnostics directory. Never copy raw contents into diagnosis.json.
function readNpmDebugLogs(directory) {
  try {
    const names = fs.readdirSync(directory).filter(name =>
      /^\d{4}-\d{2}-\d{2}T\d{2}_\d{2}_\d{2}_\d{3}Z-debug-\d+\.log$/.test(name));
    return names.sort().slice(-8).map(name => safeRead(directory, name, 16 * 1024, true) || '').join('\n');
  } catch { return ''; }
}
function readJson(directory, basename) {
  const raw = safeRead(directory, basename);
  if (raw === null) return null;
  // Windows PowerShell 5.1 Set-Content -Encoding UTF8 writes a BOM.
  // Treat that one standard UTF-8 marker as encoding, not malformed evidence.
  try { return JSON.parse(raw.replace(/^\uFEFF/, '')); } catch { return null; }
}
function validProof(proof) {
  return !!proof && proof.kind === 'tuniq-offline-preview-smoke' &&
    proof.schemaVersion === 1 && /^[a-f0-9]{32}$/.test(proof.nonce || '') &&
    proof.passed === true && proof.reason === 'offline-renderer-ready' &&
    proof.hardwareAvailable === false && proof.writeHandlersRegistered === false;
}
// Build transcripts are cumulative. An earlier npm DNS error can remain in
// the log even when the *current* failure is a later Electron startup or PE
// integrity step. For these non-network stages the allowlisted lastStep is
// authoritative; otherwise an unrelated old error hides the actual blocker.
const NON_NETWORK_FAILURES = Object.freeze({
  'windows-preflight': ['windows-preflight-failed', 'Check Windows, Node.js 20+, source path safety and a writable TEMP directory; inspect the local Windows transcript.'],
  'Offline source integrity and syntax': ['source-check-failed', 'Inspect the local source syntax and snapshot check; use a fresh verified source archive.'],
  'Source path safety': ['source-path-preflight-failed', 'Inspect the source path safety report. Do not bypass path, symlink, or reparse-point restrictions.'],
  'Production write-denial safety': ['read-only-admission-failed', 'Inspect the read-only admission preflight. Do not enable ECU writes or hardware access to proceed.'],
  'Offline Electron contract': ['electron-contract-failed', 'Inspect the offline Electron startup contract checks; do not use the production Electron main process.'],
  'Verify npm lockfile writer behavior (offline fixture)': ['lockfile-fixture-failed', 'Review the npm lockfile writer regression. Do not proceed without a genuine verified lockfile.'],
  'Capture preview dependency provenance': ['dependency-provenance-capture-failed', 'Inspect the candidate lockfile and package manifest; rebuild in a clean disposable source copy. Do not bypass dependency integrity checks.'],
  'Verify preview dependency provenance after npm ci': ['dependency-provenance-verify-failed', 'npm ci did not preserve the captured package/lockfile evidence. Discard this preview and rebuild; do not bypass provenance verification.'],
  'Complete offline simulated suite': ['offline-suite-failed', 'Inspect the Windows transcript for the failed offline test group; do not approve the preview until the complete suite exits successfully.'],
  'Real hardware-isolated renderer runtime': ['isolated-renderer-runtime', 'Inspect renderer-runtime.stderr.log, renderer-runtime.stdout.log and renderer-runtime-evidence.json. Verify native Electron starts without hardware.'],
  'Stage strictly allowlisted, hardware-free Electron application': ['preview-staging-failed', 'Inspect the staging allowlist and local transcript. Do not package or execute production main.js as a workaround.'],
  'Launch staged preview in real Electron (smoke mode)': ['staged-electron-smoke', 'Inspect staged-electron.stderr.log and staged-smoke-evidence.json; confirm fresh native renderer proof.'],
  'Validate staged Electron renderer evidence': ['staged-electron-smoke', 'Inspect staged-smoke-evidence.json and native Electron logs. A zero exit without fresh proof cannot pass.'],
  'Package hardware-free preview only (NO installer)': ['preview-packaging-failed', 'Inspect electron-builder output and the allowlisted preview staging package; do not build the production installer.'],
  'Packaged Windows executable smoke': ['packaged-electron-smoke', 'Inspect packaged-electron.stderr.log and packaged-smoke-evidence.json; verify the packaged EXE actually starts.'],
  'Verify delivered preview executable copy': ['delivered-executable-mismatch', 'Compare SHA-256 of packaged and delivered EXEs; rebuild instead of distributing a modified copy.'],
  'Delivered Windows executable smoke': ['delivered-electron-smoke', 'Inspect delivered-electron.stderr.log and delivered-smoke-evidence.json; the copied EXE must start and produce fresh proof.'],
  'Record packaged Windows PE integrity': ['packaged-executable-integrity', 'Rebuild the preview and verify the delivered EXE against packaged-executable-integrity.json on Windows.'],
  'Record delivered preview tree integrity': ['delivered-tree-integrity', 'Rebuild and verify all delivered preview files, including resources/app.asar and Electron runtime files; never distribute a partially copied preview.'],
  'Record smoke-tested packaged preview tree': ['packaged-tree-integrity', 'Inspect the packaged Electron directory and rebuild; all packaged resources must be recorded after native smoke.'],
  'Verify delivered copy against packaged preview tree': ['packaged-delivered-tree-mismatch', 'The copied preview resources differ from the smoke-tested packaged resources. Rebuild; do not use the delivered preview.'],
  'Verify staged preview file hashes and allowlist': ['staged-preview-integrity', 'Rebuild the isolated stage and verify its source allowlist before launching Electron.'],
  'Reverify staged preview before packaging': ['staged-preview-integrity', 'Do not package a changed preview stage; rebuild and reverify its allowlist.'],
  [FINAL_INTERACTIVE_STEP]: ['interactive-window-failed', 'The offline Electron preview did not produce verified visible-window evidence. Inspect the local Windows transcript and retry the one-click launcher.']
});
function diagnose(directory) {
  if (!directory || !/^Run97-Diagnostics-[a-f0-9]{32}$/.test(path.basename(directory))) {
    throw new Error('Expected a single Run97-Diagnostics-<32 hex> directory.');
  }
  const stat = fs.lstatSync(directory);
  if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error('Unsafe diagnostics directory.');
  const outcome = readJson(directory, 'build-outcome.json');
  const renderer = readJson(directory, 'renderer-runtime-evidence.json');
  const staged = readJson(directory, 'staged-smoke-evidence.json');
  const packaged = readJson(directory, 'packaged-smoke-evidence.json');
  const delivered = readJson(directory, 'delivered-smoke-evidence.json');
  const peIntegrity = readJson(directory, 'packaged-executable-integrity.json');
  const treeIntegrity = readJson(directory, 'delivered-preview-tree-integrity.json');
  const packagedTreeIntegrity = readJson(directory, 'packaged-preview-tree-integrity.json');
  const interactive = readJson(directory, 'interactive-window-evidence.json');
  const step = ALLOWED_STEPS.has(outcome?.lastStep) ? outcome.lastStep : 'unknown';
  const logs = ['windows-build-transcript.txt', 'renderer-runtime.stderr.log', 'staged-electron.stderr.log',
    'packaged-electron.stderr.log', 'delivered-electron.stderr.log'].map(name => safeRead(directory, name, MAX_LOG_BYTES, true) || '').join('\n') + '\n' + readNpmDebugLogs(directory);
  const rendererProofValid = !!renderer && renderer.kind === 'tuniq-isolated-renderer-runtime-smoke' &&
    renderer.schemaVersion === 1 && /^[a-f0-9]{32}$/.test(renderer.nonce || '') &&
    renderer.passed === true && renderer.actualElectronRuntime === true &&
    // Run263: require the independently revalidated nine-page snapshot and
    // explicit native-Windows marker, not merely a caller's success flag.
    renderer.nativeWindowsElectronVerified === true &&
    renderer.rendererSnapshotValidated === true &&
    renderer.primaryNavigationVerified === true &&
    renderer.observedPrimaryPageCount === 9 &&
    renderer.runtimeBlockerCount === 0 && renderer.snapshotBlockerCount === 0 &&
    renderer.fullTunIQVerified === false && renderer.hardwareUsed === false &&
    renderer.ecuWriteOrFlashPerformed === false;
  const stageProofValid = validProof(staged);
  const packagedProofValid = validProof(packaged);
  const deliveredProofValid = validProof(delivered);
  const independentNonces = rendererProofValid && stageProofValid && packagedProofValid &&
    deliveredProofValid &&
    new Set([renderer.nonce, staged.nonce, packaged.nonce, delivered.nonce]).size === 4;
  // The one-click launcher finishes at a different terminal step than CI's
  // build-only path. Require its independent visible-window proof, tied to
  // the exact delivered EXE hash and this diagnostic run. This is metadata
  // triage only; independent review still re-hashes the actual Windows PE.
  const interactiveProofValid = !!interactive &&
    interactive.schemaVersion === 1 &&
    interactive.kind === 'tuniq-offline-preview-visible-window' &&
    /^[a-f0-9]{32}$/.test(interactive.nonce || '') &&
    interactive.diagnosticsRun === path.basename(directory) &&
    interactive.deliveredPreviewDirectory === outcome?.deliveredPreviewDirectory &&
    /^[a-f0-9]{64}$/.test(interactive.deliveredExeSha256 || '') &&
    interactive.deliveredExeSha256 === peIntegrity?.sha256 &&
    interactive.probeMethod === 'user32-IsWindowVisible-and-exact-title' &&
    interactive.passed === true && interactive.actualWindowsWindowCheck === true &&
    interactive.exactExpectedTitle === true && interactive.visible === true &&
    interactive.hardwareUsed === false && interactive.fullTunIQVerified === false;
  const buildOnlyComplete = step === FINAL_PREVIEW_STEP &&
    outcome?.interactiveLaunchRequested !== true &&
    outcome?.interactiveLaunchWindowVisible !== true;
  const interactiveComplete = step === FINAL_INTERACTIVE_STEP &&
    outcome?.interactiveLaunchRequested === true &&
    outcome?.interactiveLaunchProcessAlive === true &&
    outcome?.interactiveLaunchWindowVisible === true && interactiveProofValid;
  const claimedPass = (buildOnlyComplete || interactiveComplete) &&
    outcome?.kind === 'tuniq-offline-preview-build-outcome' &&
    outcome?.schemaVersion === 1 && outcome?.passed === true &&
    outcome?.windowsRuntimeVerified === true && outcome?.fullTunIQVerified === false &&
    outcome?.hardwareUsed === false;
  // Run106 requires packaged image integrity evidence as well as four real
  // startup proofs. This checks metadata shape only: the Windows CI gate must
  // still re-hash the actual executable with windows-pe-integrity.js --verify.
  const peIntegrityMetadataValid = !!peIntegrity &&
    peIntegrity.kind === 'tuniq-offline-preview-windows-pe-integrity' &&
    peIntegrity.schemaVersion === 1 && peIntegrity.machine === 'amd64' &&
    peIntegrity.subsystem === 'windows-gui' &&
    Number.isSafeInteger(peIntegrity.sizeBytes) &&
    peIntegrity.sizeBytes >= 1024 * 1024 && peIntegrity.sizeBytes <= 1024 * 1024 * 1024 &&
    typeof peIntegrity.sha256 === 'string' && /^[a-f0-9]{64}$/.test(peIntegrity.sha256) &&
    peIntegrity.nativeStartupVerified === false && peIntegrity.fullTunIQVerified === false;
  const treeIntegrityMetadataValid = !!treeIntegrity &&
    treeIntegrity.kind === 'tuniq-offline-preview-delivered-tree-integrity' &&
    treeIntegrity.schemaVersion === 1 && treeIntegrity.previewOnly === true &&
    treeIntegrity.fullTunIQVerified === false && treeIntegrity.hardwareUsed === false &&
    Number.isSafeInteger(treeIntegrity.fileCount) && treeIntegrity.fileCount >= 2 &&
    Number.isSafeInteger(treeIntegrity.totalBytes) && treeIntegrity.totalBytes > 0 &&
    Array.isArray(treeIntegrity.files) && treeIntegrity.files.length === treeIntegrity.fileCount;
  const packagedTreeIntegrityMetadataValid = !!packagedTreeIntegrity &&
    packagedTreeIntegrity.kind === 'tuniq-offline-preview-delivered-tree-integrity' &&
    packagedTreeIntegrity.schemaVersion === 1 && packagedTreeIntegrity.previewOnly === true &&
    packagedTreeIntegrity.fullTunIQVerified === false && packagedTreeIntegrity.hardwareUsed === false &&
    Number.isSafeInteger(packagedTreeIntegrity.fileCount) && packagedTreeIntegrity.fileCount >= 2 &&
    Number.isSafeInteger(packagedTreeIntegrity.totalBytes) && packagedTreeIntegrity.totalBytes > 0 &&
    Array.isArray(packagedTreeIntegrity.files) && packagedTreeIntegrity.files.length === packagedTreeIntegrity.fileCount &&
    JSON.stringify(packagedTreeIntegrity) === JSON.stringify(treeIntegrity);
  const evidenceComplete = !!(claimedPass && independentNonces && peIntegrityMetadataValid &&
    treeIntegrityMetadataValid && packagedTreeIntegrityMetadataValid);
  let code = 'unclassified';
  let action = 'Inspect the preserved Windows transcript and native Electron stderr logs locally; do not share logs without checking for private paths.';
  if (!outcome) {
    code = 'missing-or-invalid-outcome';
    action = 'Confirm Node.js 20+ is installed, then rerun the Windows build script and retain its diagnostics directory.';
  } else if (outcome.passed === true &&
             step !== FINAL_PREVIEW_STEP && step !== FINAL_INTERACTIVE_STEP) {
    code = 'premature-success-claim';
    action = 'Build outcome claims success before the delivered preview tree was recorded. Rebuild on Windows and retain complete native evidence.';
  } else if (outcome.passed === true && !evidenceComplete) {
    code = 'inconsistent-success-evidence';
    action = 'Do not use this preview. Rebuild; verify four distinct native smoke proofs, packaged PE integrity, and both packaged/delivered tree integrity JSON. Re-hash the executable on Windows.';
  } else if (evidenceComplete) {
    code = 'offline-preview-smoke-evidence-present';
    action = 'Independently re-hash the delivered EXE and compare the packaged/delivered resource trees on Windows and review native logs. Metadata alone is not executable verification or full TunIQ approval.';
  } else if (Object.hasOwn(NON_NETWORK_FAILURES, step)) {
    // Never let stale npm errors in the cumulative transcript override a
    // later, more precise native runtime or local validation failure.
    [code, action] = NON_NETWORK_FAILURES[step];
  } else if (step === 'Install locked Electron dependencies' &&
             /(?:github\.com\/electron\/electron|objects\.githubusercontent\.com|Failed to download Electron|Failed to find Electron)/i.test(logs) &&
             /(?:EAI_AGAIN|ENOTFOUND|EHOSTUNREACH|ETIMEDOUT|ECONNRESET|download|not found)/i.test(logs)) {
    // Electron's npm postinstall fetches a separate binary from GitHub.
    // A GitHub download failure is NOT proof that registry.npmjs.org DNS failed.
    code = 'electron-binary-download';
    action = 'Check GitHub Electron release asset access and any proxy/TLS policy; inspect the local npm ci log. Do not bypass integrity checks or substitute an unverified Electron binary.';
  } else if (/\b(?:EAI_AGAIN|ENOTFOUND|EHOSTUNREACH|getaddrinfo)\b/i.test(logs)) {
    code = 'npm-registry-dns';
    action = 'Check DNS and registry access with npm ping --registry=https://registry.npmjs.org/; rerun after connectivity is restored.';
  } else if (/\b(?:ETIMEDOUT|ECONNRESET|CERT_HAS_EXPIRED|SELF_SIGNED_CERT_IN_CHAIN)\b/i.test(logs)) {
    code = 'npm-network-or-tls';
    action = 'Check network, TLS interception, system clock, and npm registry access before retrying.';
  } else if (/\b(?:ERESOLVE|ELOCKVERIFY)\b/i.test(logs)) {
    code = 'npm-lock-resolution';
    action = 'Review the candidate package-lock file and dependency preflight; do not bypass npm ci or integrity checks.';
  } else if (step === 'Real hardware-isolated renderer runtime' ||
             /Isolated renderer runtime timed out|Isolated renderer runtime failed/i.test(logs)) {
    code = 'isolated-renderer-runtime';
    action = 'Inspect renderer-runtime.stderr.log, renderer-runtime.stdout.log and renderer-runtime-evidence.json. Verify Electron starts and the UI becomes visible without hardware.';
  } else if (/Staged Electron smoke timed out|Staged Electron smoke failed|renderer-timeout|unexpected-renderer-activity/i.test(logs)) {
    code = 'staged-electron-smoke';
    action = 'Inspect staged-electron.stderr.log and staged-smoke-evidence.json; verify renderer startup without ECU hardware.';
  } else if (/Packaged preview smoke timed out|Packaged preview smoke failed/i.test(logs)) {
    code = 'packaged-electron-smoke';
    action = 'Inspect packaged-electron.stderr.log and packaged-smoke-evidence.json; do not approve an unverified executable.';
  } else if (/Delivered preview smoke timed out|Delivered preview smoke failed/i.test(logs)) {
    code = 'delivered-electron-smoke';
    action = 'Inspect delivered-electron.stderr.log and delivered-smoke-evidence.json; the copied executable must start successfully before approval.';
  } else if (/renderer evidence|smoke produced no evidence/i.test(logs)) {
    code = 'renderer-evidence-missing';
    action = 'Check native Electron logs and renderer evidence. A zero process exit is not sufficient.';
  } else if (step === 'Verify delivered preview executable copy') {
    code = 'delivered-executable-mismatch';
    action = 'Compare SHA-256 of the packaged and copied executable on Windows. Rebuild instead of distributing a modified copy.';
  } else if (step === 'Delivered Windows executable smoke') {
    code = 'delivered-electron-smoke';
    action = 'Inspect delivered-electron.stderr.log and delivered-smoke-evidence.json. The final copied executable must launch and produce fresh renderer proof.';
  } else if (step === 'Record packaged Windows PE integrity') {
    code = 'packaged-executable-integrity';
    action = 'Inspect the packaged executable and Windows transcript. Rebuild the isolated preview, then run windows-pe-integrity.js --verify against the actual EXE and saved JSON; do not approve a missing or mismatched image.';
  } else if (step === 'Resolve genuine npm lock graph without running scripts') {
    code = 'npm-lockfile-generation-failed';
    action = 'Check npm registry access, the npm install exit status and whether package-lock.json was actually created. Never treat a successful exit without a lockfile as approval.';
  } else if (step === 'Review lock graph constraints') {
    code = 'npm-lockfile-preflight-rejected';
    action = 'Review the candidate package-lock.json with windows-dependency-preflight.js --require-lock. Do not bypass integrity or lock graph checks.';
  } else if (step === 'Install locked Electron dependencies') {
    code = 'npm-install-failed';
    action = 'Review the local npm ci failure and candidate lockfile; keep integrity verification enabled.';
  } else if (step.startsWith('Package hardware-free preview')) {
    code = 'preview-packaging-failed';
    action = 'Review electron-builder diagnostics and the allowlisted staging package.';
  } else if (step === 'Launch staged preview in real Electron (smoke mode)' ||
             step === 'Validate staged Electron renderer evidence') {
    // Start-Process and evidence-parsing exceptions can occur before any
    // Electron stderr or transcript signature is available. Use the reviewed
    // step label as a fallback instead of losing actionable diagnosis.
    code = 'staged-electron-smoke';
    action = 'Inspect staged-electron.stderr.log and staged-smoke-evidence.json; confirm the staged Electron process started and produced fresh renderer evidence.';
  } else if (step === 'Packaged Windows executable smoke') {
    code = 'packaged-electron-smoke';
    action = 'Inspect packaged-electron.stderr.log and packaged-smoke-evidence.json; confirm the packaged EXE started and produced fresh renderer evidence.';
  } else if (step === 'Stage strictly allowlisted, hardware-free Electron application') {
    code = 'preview-staging-failed';
    action = 'Inspect the Windows transcript and staging allowlist. Do not package or execute production main.js as a workaround.';
  } else if (step === 'Complete offline simulated suite') {
    code = 'offline-suite-failed';
    action = 'Inspect the Windows transcript for the failed offline test group; do not approve the preview until the complete suite exits successfully.';
  } else if (step === 'windows-preflight') {
    code = 'windows-preflight-failed';
    action = 'Confirm Windows, Node.js 20+, source path safety and a writable TEMP directory; inspect the local Windows transcript.';
  }
  return Object.freeze({
    schemaVersion: 1, kind: 'tuniq-windows-preview-diagnosis',
    failureCode: code, lastStep: step,
    recordedBuildPassed: claimedPass, rendererProofValid: rendererProofValid, stagedProofValid: stageProofValid,
    packagedProofValid: packagedProofValid, deliveredProofValid: deliveredProofValid,
    distinctSmokeNonces: !!independentNonces,
    peIntegrityMetadataValid: !!peIntegrityMetadataValid, treeIntegrityMetadataValid: !!treeIntegrityMetadataValid,
    packagedTreeIntegrityMetadataValid: !!packagedTreeIntegrityMetadataValid,
    offlinePreviewEvidenceComplete: evidenceComplete,
    fullTunIQVerified: false, hardwareUsed: false, readyForUserTesting: false,
    nextAction: action
  });
}
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 1 || args.length > 2 || (args[1] && args[1] !== '--write')) {
    console.error('Usage: node tools/diagnose-windows-preview.js <Run97-Diagnostics-dir> [--write]');
    process.exitCode = 2;
  } else {
    try {
      const result = diagnose(path.resolve(args[0]));
      const json = JSON.stringify(result, null, 2) + '\n';
      if (args[1] === '--write') {
        const file = path.join(path.resolve(args[0]), 'diagnosis.json');
        // Do not follow a preexisting symlink or overwrite an older diagnosis.
        fs.writeFileSync(file, json, { flag: 'wx', mode: 0o600 });
      }
      process.stdout.write(json);
    } catch (error) { console.error(`Diagnostics unavailable: ${error.message}`); process.exitCode = 2; }
  }
}
module.exports = { diagnose, validProof, safeRead, ALLOWED_STEPS };
