#!/usr/bin/env node
'use strict';
// Read-only evidence: never repairs or rebaselines source hashes.
const path = require('node:path');
const { inspectWindowsSourceLayout, auditWindowsPaths } = require('./windows-source-path-preflight');
function report(root = path.resolve(__dirname, '..'), inspect = inspectWindowsSourceLayout) {
  const inspected = inspect(root);
  // A missing or non-object preflight result is untrusted evidence, not a crash.
  const audit = inspected && typeof inspected === 'object' && !Array.isArray(inspected)
    ? inspected : {};
  const mismatches = Array.isArray(audit.contentMismatches) ? audit.contentMismatches : [];
  const count = Number.isSafeInteger(audit.contentMismatchCount) && audit.contentMismatchCount >= 0
    ? audit.contentMismatchCount : null;
  const validEntry = x => x !== null && typeof x === 'object' &&
    typeof x.path === 'string' && x.path.length > 0 &&
    Number.isSafeInteger(x.expectedSize) && x.expectedSize >= 0 &&
    Number.isSafeInteger(x.actualSize) && x.actualSize >= 0 &&
    [x.expectedSha256, x.actualSha256].every(h => typeof h === 'string' && /^[a-f0-9]{64}$/i.test(h)) &&
    x.expectedSha256.toLowerCase() !== x.actualSha256.toLowerCase();
  // Reject ambiguous or unsafe evidence paths before presenting a complete audit.
  const paths = mismatches.filter(validEntry).map(x => x.path);
  const pathsSafe = paths.length === mismatches.length && auditWindowsPaths(paths).safe;
  const complete = count !== null && count === mismatches.length && mismatches.every(validEntry) && pathsSafe;
  return {
    auditKind: 'read-only-source-manifest-drift', sourceOnly: true,
    manifestVerified: audit.windowsSourcePathsSafe === true && count === 0 && complete,
    totalMismatchCount: count, evidenceComplete: complete,
    // Deliberately never report hashes as independently trusted provenance.
    mismatches: mismatches.filter(validEntry).map(x => ({path: x.path, expectedSize: x.expectedSize, actualSize: x.actualSize,
      expectedSha256: x.expectedSha256, actualSha256: x.actualSha256})),
    blockers: [...(Array.isArray(audit.blockers) ? audit.blockers : ['unverified-preflight']),
      ...(!complete ? ['incomplete-or-malformed-mismatch-evidence'] : [])],
    nextAction: 'Compare each mismatch against authenticated upstream and rebuild the manifest only after source provenance review.'
  };
}
if (require.main === module) {
  const result = report(process.argv[2] ? path.resolve(process.argv[2]) : undefined);
  console.log(JSON.stringify(result, null, 2));
  if (!result.manifestVerified) process.exitCode = 2;
}
module.exports = { report };
