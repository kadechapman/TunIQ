#!/usr/bin/env node
'use strict';
// Prepare an Electron project with ONLY an offline renderer and five mocked
// bootstrap IPC channels. This staging operation does not install or run code.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const ROOT = path.resolve(__dirname, '..');
const SOURCE_FILES = Object.freeze([
  ['tools/readonly-preview-main.js', 'main.js'],
  ['src/renderer-navigation-guard.js', 'src/renderer-navigation-guard.js'],
  ['tools/readonly-preview-preload.js', 'src/preload.js'],
  ['src/renderer/index.html', 'src/renderer/index.html'],
  ['src/renderer/styles.css', 'src/renderer/styles.css'],
  ['src/renderer/engine-catalog.js', 'src/renderer/engine-catalog.js'],
  ['src/renderer/app.js', 'src/renderer/app.js']
]);
const PACKAGE_FILES = Object.freeze(['main.js', 'src/preload.js', 'src/renderer-navigation-guard.js',
  'src/renderer/index.html', 'src/renderer/styles.css',
  'src/renderer/engine-catalog.js', 'src/renderer/app.js']);
const BANNER = '\n<div id="offline-dev-banner" role="status">OFFLINE UI PREVIEW — ALL ECU OPERATIONS DISABLED — NOT FOR VEHICLE USE</div>\n';
const BANNER_CSS = `\n#offline-dev-banner { position: fixed; z-index: 2147483647; top: 0; left: 0; right: 0; padding: 7px 12px; background: #8b1029; color: white; font: bold 12px Arial, sans-serif; text-align: center; pointer-events: none; }\n`;
// A direct lstat on a leaf follows redirected parent directories. Check every
// existing path component before staging source or output. This is a static
// fail-closed check, not a race-free filesystem lease or Windows runtime proof.
function assertUnredirectedPath(full) {
  const absolute = path.resolve(full);
  const root = path.parse(absolute).root;
  let current = root;
  for (const part of absolute.slice(root.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    const stat = fs.lstatSync(current, { throwIfNoEntry: false });
    if (!stat) break; // A missing parent means no existing descendant.
    if (stat.isSymbolicLink()) throw new Error('Redirected preview path refused.');
  }
}
function safeSource(file) {
  const full = path.join(ROOT, file);
  assertUnredirectedPath(full);
  const stat = fs.lstatSync(full);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) {
    throw new Error(`Unsafe preview source: ${file}`);
  }
  return fs.readFileSync(full);
}
// The output must be disjoint from the source checkout. Checking only whether
// the output is an ancestor of ROOT also allows writes *inside* the checkout.
// path.relative handles path-component boundaries and Windows case folding.
function withinOrEqual(parent, candidate) {
  const relative = path.relative(parent, candidate);
  return relative === '' || (relative !== '..' &&
    !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative));
}
// Bind verification to the reviewed checkout, not just a manifest shipped in
// the same writable staging directory. A modified renderer plus a recomputed
// STAGING_SHA256.json must not pass the Windows packaging preflight.
function preparedPreviewSources() {
  return SOURCE_FILES.map(([source, target]) => {
    let bytes = safeSource(source);
    if (target === 'src/renderer/index.html') {
      const html = bytes.toString('utf8');
      if (!html.includes('</body>') || !html.includes('Content-Security-Policy')) throw new Error('Unexpected renderer HTML');
      bytes = Buffer.from(html.replace('</body>', `${BANNER}</body>`));
    }
    if (target === 'src/renderer/styles.css') bytes = Buffer.concat([bytes, Buffer.from(BANNER_CSS)]);
    return { target, bytes };
  });
}
// Keep the offline packaging contract in one place. Verification must bind
// every package.json field, not only selected fields: electron-builder accepts
// additional keys such as extraResources, extraFiles and hooks that could
// expand the packaged artifact beyond the reviewed, hardware-free allowlist.
function previewPackage() {
  return {
    name: 'tuniq-offline-ui-preview', version: '1.9.0-beta.108', private: true,
    license: 'UNLICENSED', main: 'main.js',
    devDependencies: { electron: '37.2.3' },
    build: {
      appId: 'com.tuniq.offline-ui-preview', productName: 'TunIQ Offline UI Preview',
      asar: true, electronVersion: '37.2.3',
      directories: { output: 'dist' }, files: PACKAGE_FILES
    }
  };
}
function previewPackageBytes() {
  return Buffer.from(JSON.stringify(previewPackage(), null, 2) + '\n');
}
function stage(destination) {
  const dir = path.resolve(destination || fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-offline-preview-')));
  if (withinOrEqual(ROOT, dir) || withinOrEqual(dir, ROOT)) {
    throw new Error('Refusing to stage inside or over source tree');
  }
  assertUnredirectedPath(dir);
  if (fs.existsSync(dir) && fs.readdirSync(dir).length) throw new Error('Preview destination must be empty');
  // Validate and transform every allowlisted source before touching the output.
  // Previously, malformed HTML or an unsafe later source left a partially
  // populated directory that could be mistaken for a usable preview package.
  // This is source preflight, not a guarantee against concurrent filesystem races.
  const prepared = preparedPreviewSources();
  // Build in a private sibling directory and publish only after every write
  // succeeds. A disk-full or permission error must not leave an apparently
  // usable, partially populated preview at the requested destination.
  const parent = path.dirname(dir);
  fs.mkdirSync(parent, { recursive: true });
  assertUnredirectedPath(parent);
  const existed = fs.existsSync(dir);
  const scratch = fs.mkdtempSync(path.join(parent, '.tuniq-preview-staging-'));
  try {
    assertUnredirectedPath(scratch);
    const manifest = [];
    for (const { target, bytes } of prepared) {
      const full = path.join(scratch, target);
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, bytes, { flag: 'wx' });
      manifest.push({ path: target, sha256: crypto.createHash('sha256').update(bytes).digest('hex') });
    }
    const pkgBytes = previewPackageBytes();
    fs.writeFileSync(path.join(scratch, 'package.json'), pkgBytes, { flag: 'wx' });
    manifest.push({ path: 'package.json', sha256: crypto.createHash('sha256').update(pkgBytes).digest('hex') });
    fs.writeFileSync(path.join(scratch, 'STAGING_SHA256.json'), JSON.stringify(manifest, null, 2) + '\n', { flag: 'wx' });
    // An existing empty output directory is supported, but never overwritten
    // while nonempty. The final rename is atomic on the same filesystem.
    // This does not claim race-free protection against concurrent attackers.
    assertUnredirectedPath(dir);
    if (existed) {
      if (!fs.lstatSync(dir).isDirectory() || fs.readdirSync(dir).length) {
        throw new Error('Preview destination must be empty');
      }
      fs.rmdirSync(dir);
    }
    try { fs.renameSync(scratch, dir); }
    catch (error) {
      if (existed && !fs.existsSync(dir)) fs.mkdirSync(dir);
      throw error;
    }
    return { stage: dir, files: SOURCE_FILES.length, hardwareCodeIncluded: false, productionMainIncluded: false };
  } finally {
    if (fs.existsSync(scratch)) fs.rmSync(scratch, { recursive: true, force: true });
  }
}
// Verify the staged package itself, not just the original source. This
// protects against accidental/tampered bytes after staging and before native
// Electron smoke or packaging. It does not prove Windows runtime behavior or
// prevent a concurrent filesystem race after verification.
function verifyStage(destination) {
  const dir = path.resolve(destination);
  assertUnredirectedPath(dir);
  const rootStat = fs.lstatSync(dir);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('unsafe-preview-stage-directory');
  const expected = [...SOURCE_FILES.map(([, target]) => target), 'package.json'];
  const allowed = new Set([...expected, 'STAGING_SHA256.json']);
  const actual = [];
  function walk(folder, prefix = '') {
    for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
      const relative = prefix ? `${prefix}/${entry.name}` : entry.name;
      const full = path.join(folder, entry.name);
      const stat = fs.lstatSync(full);
      if (stat.isSymbolicLink()) throw new Error('unapproved-redirected-preview-stage');
      if (stat.isDirectory()) {
        if (![...allowed].some(item => item.startsWith(relative + '/'))) {
          throw new Error('unapproved-preview-stage-directory');
        }
        walk(full, relative);
      } else if (stat.isFile() && stat.nlink === 1) actual.push(relative);
      else throw new Error('unapproved-preview-stage-entry');
    }
  }
  walk(dir);
  if (actual.length !== allowed.size || actual.some(item => !allowed.has(item))) {
    throw new Error('unapproved-preview-stage-files');
  }
  const manifestPath = path.join(dir, 'STAGING_SHA256.json');
  if (fs.statSync(manifestPath).size > 16384) throw new Error('invalid-preview-stage-manifest');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  if (!Array.isArray(manifest) || manifest.length !== expected.length ||
      new Set(manifest.map(item => item?.path)).size !== expected.length ||
      manifest.some(item => !expected.includes(item?.path) ||
        typeof item?.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(item.sha256))) {
    throw new Error('invalid-preview-stage-manifest');
  }
  for (const item of manifest) {
    const bytes = fs.readFileSync(path.join(dir, item.path));
    if (crypto.createHash('sha256').update(bytes).digest('hex') !== item.sha256) {
      throw new Error('preview-stage-integrity-hash-mismatch');
    }
  }
  // The manifest is stored alongside the files it attests. Verify the
  // renderer bytes independently against the reviewed source checkout (with
  // only the intentional preview banner transformations). This is a build-time
  // source binding, not a cryptographic signature or a runtime integrity seal.
  const manifestHashes = new Map(manifest.map(item => [item.path, item.sha256]));
  for (const { target, bytes } of preparedPreviewSources()) {
    if (crypto.createHash('sha256').update(bytes).digest('hex') !== manifestHashes.get(target)) {
      throw new Error('preview-stage-source-binding-mismatch');
    }
  }
  // A rehashed package manifest is not trusted: bind the entire build
  // configuration to the canonical, reviewed source contract. Partial field
  // checks previously admitted extraResources/extraFiles/packaging hooks.
  if (!fs.readFileSync(path.join(dir, 'package.json')).equals(previewPackageBytes())) {
    throw new Error('unsafe-preview-package-contract');
  }
  return { verified: true, files: expected.length, hardwareCodeIncluded: false,
    productionMainIncluded: false };
}
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length !== 2 || !['--output', '--verify'].includes(args[0]) || !args[1]) { console.error('Usage: node tools/stage-readonly-preview.js --output EMPTY_DIRECTORY | --verify STAGED_DIRECTORY'); process.exit(2); }
  try { console.log(JSON.stringify(args[0] === '--verify' ? verifyStage(args[1]) : stage(args[1]), null, 2)); } catch (err) { console.error(err.message); process.exitCode = 2; }
}
module.exports = { ROOT, SOURCE_FILES, safeSource, stage, verifyStage, assertUnredirectedPath };
