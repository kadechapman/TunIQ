#!/usr/bin/env node
'use strict';
// Offline structural verification of the dependency-free Win64 browser preview.
// It does not run Windows, Electron, TunIQ, or any ECU operation.
const fs = require('node:fs');
const crypto = require('node:crypto');
const path = require('node:path');
const EXPECTED_IMPORTS = Object.freeze({
  'KERNEL32.dll': ['CloseHandle', 'CreateFileW', 'DeleteFileW', 'ExitProcess',
    'GetDriveTypeW', 'GetFileInformationByHandle', 'GetFileType',
    'GetTempFileNameW', 'GetTempPathW', 'MoveFileW', 'WriteFile'],
  'SHELL32.dll': ['ShellExecuteW'],
  'USER32.dll': ['MessageBoxW']
});
function regularBytes(file, max) {
  const before = fs.lstatSync(file);
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1 ||
      before.size < 1 || before.size > max) throw new Error('unsafe-preview-file');
  const bytes = fs.readFileSync(file);
  const after = fs.lstatSync(file);
  if (bytes.length !== before.size || before.dev !== after.dev || before.ino !== after.ino ||
      before.size !== after.size || before.mtimeMs !== after.mtimeMs || before.ctimeMs !== after.ctimeMs ||
      after.nlink !== 1) throw new Error('preview-file-changed');
  return bytes;
}
function inspect(exe, html) {
  if (!Buffer.isBuffer(exe) || !Buffer.isBuffer(html) ||
      exe.length < 1024 || exe.length > 8 * 1024 * 1024 ||
      html.length < 1024 || html.length > 2 * 1024 * 1024) throw new Error('invalid-preview-input');
  const range = (offset, size) => {
    if (!Number.isSafeInteger(offset) || offset < 0 || offset + size > exe.length) throw new Error('invalid-pe-range');
    return offset;
  };
  const u16 = offset => exe.readUInt16LE(range(offset, 2));
  const u32 = offset => exe.readUInt32LE(range(offset, 4));
  const string = (offset, max = 128) => {
    range(offset, 1);
    const end = exe.indexOf(0, offset);
    if (end < 0 || end - offset > max || end === offset) throw new Error('invalid-import-string');
    return exe.toString('ascii', offset, end);
  };
  if (exe.toString('ascii', 0, 2) !== 'MZ') throw new Error('missing-mz');
  const pe = u32(0x3c);
  if (pe > 4096 || exe.toString('binary', range(pe, 4), pe + 4) !== 'PE\0\0' ||
      u16(pe + 4) !== 0x8664 || u16(pe + 24) !== 0x20b ||
      u16(pe + 24 + 68) !== 2 || !(u16(pe + 22) & 2)) throw new Error('invalid-win64-gui-pe');
  const sectionCount = u16(pe + 6), optionalSize = u16(pe + 20);
  if (sectionCount < 1 || sectionCount > 32 || optionalSize < 128) throw new Error('invalid-pe-sections');
  const sectionStart = pe + 24 + optionalSize;
  const headersEnd = u32(pe + 24 + 60); // PE32+ SizeOfHeaders
  if (headersEnd < sectionStart + sectionCount * 40 || headersEnd > exe.length) {
    throw new Error('invalid-pe-headers');
  }
  // The standalone preview is deliberately unsigned and has no appended
  // payload. The import allowlist and embedded HTML alone do not detect a
  // second-stage PE overlay or an unreviewed Authenticode certificate table.
  const securityDirectory = pe + 24 + 112 + 4 * 8;
  if (optionalSize < 160 || u32(securityDirectory) || u32(securityDirectory + 4)) {
    throw new Error('unexpected-pe-security-directory');
  }
  // A benign import allowlist is not sufficient if the PE also declares a
  // TLS callback, delayed import, CLR runtime, or other unreviewed loader
  // directory. Only the import, exception-unwind and IAT directories are
  // expected from this deliberately small, hardware-free launcher.
  if (optionalSize < 240 || u32(pe + 24 + 108) !== 16) {
    throw new Error('unexpected-pe-directory-layout');
  }
  const allowedDirectories = new Set([1, 3, 12]);
  for (let i = 0; i < 16; i++) {
    if (allowedDirectories.has(i)) continue;
    const directory = pe + 24 + 112 + i * 8;
    if (u32(directory) || u32(directory + 4)) {
      throw new Error('unexpected-pe-data-directory');
    }
  }
  const sections = [];
  const rawRanges = [];
  const entryPointRva = u32(pe + 24 + 16);
  let entryPointInExecutableSection = false;
  for (let i = 0; i < sectionCount; i++) {
    const s = range(sectionStart + i * 40, 40);
    const section = { virtual: u32(s + 12), virtualSize: u32(s + 8),
      size: u32(s + 16), raw: u32(s + 20) };
    const characteristics = u32(s + 36);
    const executable = !!(characteristics & 0x20000000);
    const writable = !!(characteristics & 0x80000000);
    if (executable && writable) throw new Error('writable-executable-pe-section');
    if (executable && section.size && entryPointRva >= section.virtual &&
        entryPointRva - section.virtual < Math.min(section.size, section.virtualSize)) {
      entryPointInExecutableSection = true;
    }
    if (section.size) {
      if (section.raw < headersEnd) throw new Error('invalid-pe-section-overlap');
      range(section.raw, section.size);
      rawRanges.push([section.raw, section.raw + section.size]);
    }
    sections.push(section);
  }
  if (!entryPointInExecutableSection) throw new Error('invalid-pe-entrypoint');
  rawRanges.sort((a, b) => a[0] - b[0]);
  for (let i = 1; i < rawRanges.length; i++) {
    if (rawRanges[i][0] < rawRanges[i - 1][1]) throw new Error('invalid-pe-section-overlap');
  }
  if (!rawRanges.length || rawRanges[rawRanges.length - 1][1] !== exe.length) {
    throw new Error('unexpected-pe-overlay');
  }
  function rvaOffset(rva, size = 1) {
    const section = sections.find(s => rva >= s.virtual && rva - s.virtual + size <= s.size);
    if (!section) throw new Error('unmapped-pe-rva');
    return range(section.raw + rva - section.virtual, size);
  }
  const importRva = u32(pe + 24 + 112 + 8); // PE32+ data directory #1 (imports)
  const importSize = u32(pe + 24 + 112 + 12);
  if (!importRva || importSize < 40 || importSize > 4096) throw new Error('invalid-import-directory');
  const imports = {};
  let terminated = false;
  for (let i = 0; i < 16; i++) {
    const entry = rvaOffset(importRva + i * 20, 20);
    const originalThunk = u32(entry), nameRva = u32(entry + 12), firstThunk = u32(entry + 16);
    if (!originalThunk && !nameRva && !firstThunk) { terminated = true; break; }
    if (!nameRva || !(originalThunk || firstThunk)) throw new Error('invalid-import-descriptor');
    const dll = string(rvaOffset(nameRva));
    if (imports[dll]) throw new Error('duplicate-import-dll');
    const names = [];
    let end = false;
    for (let j = 0; j < 64; j++) {
      const thunk = rvaOffset((originalThunk || firstThunk) + j * 8, 8);
      const namePtr = exe.readBigUInt64LE(thunk);
      if (namePtr === 0n) { end = true; break; }
      if (namePtr > 0xffffffffn) throw new Error('ordinal-or-invalid-import');
      names.push(string(rvaOffset(Number(namePtr), 3) + 2));
    }
    if (!end) throw new Error('unterminated-import-table');
    imports[dll] = names.sort();
  }
  if (!terminated || JSON.stringify(Object.keys(imports).sort()) !== JSON.stringify(Object.keys(EXPECTED_IMPORTS).sort()) ||
      Object.entries(EXPECTED_IMPORTS).some(([dll, names]) =>
        JSON.stringify(imports[dll]) !== JSON.stringify(names))) throw new Error('unreviewed-win64-imports');
  const at = exe.indexOf(html);
  if (at < 0 || exe.indexOf(html, at + 1) >= 0) throw new Error('embedded-html-not-exactly-once');
  if (!html.includes(Buffer.from('ALL ECU OPERATIONS DISABLED'))) throw new Error('missing-no-ecu-warning');
  return { kind: 'tuniq-standalone-win64-static-verification', schemaVersion: 1,
    executableSha256: crypto.createHash('sha256').update(exe).digest('hex'),
    embeddedHtmlSha256: crypto.createHash('sha256').update(html).digest('hex'),
    executableBytes: exe.length, embeddedHtmlBytes: html.length, embeddedOffset: at,
    imports, hardwareAvailable: false, electronRuntimeVerified: false,
    nativeWindowsRuntimeVerified: false, fullApplicationVerified: false };
}
function verifyFiles(executable, html) {
  return inspect(regularBytes(executable, 8 * 1024 * 1024), regularBytes(html, 2 * 1024 * 1024));
}
if (require.main === module) {
  try {
    if (process.argv.length !== 4) throw new Error('usage: verify-windows-standalone-embed.js EXE HTML');
    console.log(JSON.stringify(verifyFiles(path.resolve(process.argv[2]), path.resolve(process.argv[3])), null, 2));
  } catch (e) { console.error(`Standalone Win64 static verification failed: ${e.message}`); process.exitCode = 2; }
}
module.exports = { inspect, verifyFiles };
