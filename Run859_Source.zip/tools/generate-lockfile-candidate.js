#!/usr/bin/env node
'use strict';
// Operator-side alternative to GitHub Actions. Creates a review-only npm
// lockfile candidate in an isolated temp directory, never in the source tree.
// No npm ci, lifecycle scripts, Electron, application startup, or ECU access.
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { inspectWindowsDependencyLock, MAX_LOCK_BYTES } = require('./windows-dependency-preflight');
const { reviewCandidate } = require('./review-windows-lockfile-candidate');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const SHA1 = /^[a-f0-9]{40}$/;

function command(name, args, cwd, timeout = 120000) {
  const win = process.platform === 'win32';
  const result = spawnSync(name, args, {
    cwd, encoding: 'utf8', timeout, windowsHide: true,
    shell: win && name === 'npm.cmd', maxBuffer: 512 * 1024,
    env: { ...process.env, npm_config_update_notifier: 'false', npm_config_ignore_scripts: 'true' }
  });
  if (result.error || result.status !== 0) {
    throw new Error(`${name} failed (status ${result.status ?? 'none'}): ${
      result.error?.message || (result.stderr || '').trim().slice(-350) || 'no diagnostic'}`);
  }
  return (result.stdout || '').trim();
}

// A lexical path check alone is insufficient: an outside directory may be a
// symlink/junction into the source tree. Recheck after npm resolution as well.
function assertSafeOutput(source, output) {
  const parent = fs.realpathSync(path.dirname(output));
  const relative = path.relative(source, parent);
  if (relative === '' || (relative !== '..' && !relative.startsWith('..' + path.sep) &&
      !path.isAbsolute(relative))) {
    throw new Error('Review output parent resolves inside the source checkout.');
  }
  // existsSync returns false for dangling symlinks; lstat does not.
  if (fs.lstatSync(output, { throwIfNoEntry: false })) {
    throw new Error('Review output already exists; refusing to overwrite it.');
  }
}

function generateCandidate(sourceDir, outputDir, options = {}) {
  const source = fs.realpathSync(sourceDir);
  const output = path.resolve(outputDir);
  if (output === source || output.startsWith(source + path.sep)) {
    throw new Error('Review artifact must be outside the source checkout.');
  }
  assertSafeOutput(source, output);
  const packagePath = path.join(source, 'package.json');
  const packageStat = fs.lstatSync(packagePath);
  if (!packageStat.isFile() || packageStat.isSymbolicLink() || packageStat.nlink !== 1 ||
      packageStat.size < 1 || packageStat.size > 1024 * 1024) {
    throw new Error('Source package.json is not a safe regular file.');
  }
  const pkg = fs.readFileSync(packagePath);
  const commit = command('git', ['rev-parse', '--verify', 'HEAD^{commit}'], source, 10000);
  if (!SHA1.test(commit)) throw new Error('No verified Git source commit.');
  const committedPkg = spawnSync('git', ['cat-file', 'blob', 'HEAD:package.json'],
    { cwd: source, timeout: 10000, maxBuffer: 1024 * 1024 + 4096 });
  if (committedPkg.error || committedPkg.status !== 0 || !pkg.equals(committedPkg.stdout)) {
    throw new Error('Dependency manifest does not match the source commit.');
  }
  command('git', ['diff', '--quiet', '--no-ext-diff', 'HEAD', '--'], source, 10000);
  // existsSync follows links and returns false for dangling links. A source
  // checkout with an untracked dangling package-lock/shrinkwrap symlink must
  // not be certified as having no lockfile: reject the directory entry itself.
  // A source lockfile may appear *during* npm resolution as an untracked
  // entry. git diff HEAD does not detect it. Recheck after npm and again
  // after artifact review, so a stale candidate is never certified while a
  // competing lockfile/shrinkwrap is present in the source checkout.
  const assertNoSourceLockEntries = () => {
    const hasEntry = name =>
      fs.lstatSync(path.join(source, name), { throwIfNoEntry: false }) !== undefined;
    if (hasEntry('package-lock.json') || hasEntry('npm-shrinkwrap.json')) {
      throw new Error('Source has a lockfile or shrinkwrap entry; review it instead.');
    }
  };
  assertNoSourceLockEntries();
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  const npmVersion = command(npm, ['--version'], source, 10000);
  const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-lock-candidate-'));
  let created = false;
  try {
    fs.writeFileSync(path.join(scratch, 'package.json'), pkg, { flag: 'wx' });
    const args = ['install', '--package-lock-only', '--package-lock=true', '--save=true',
      '--ignore-scripts', '--no-audit', '--no-fund', '--fetch-retries=0', '--fetch-timeout=30000'];
    if (options.offline) args.push('--offline');
    command(npm, args, scratch, 120000);
    if (!pkg.equals(fs.readFileSync(path.join(scratch, 'package.json')))) {
      throw new Error('npm modified the reviewed dependency manifest.');
    }
    if (!pkg.equals(fs.readFileSync(packagePath))) {
      throw new Error('Original source dependency manifest changed during resolution.');
    }
    const lockPath = path.join(scratch, 'package-lock.json');
    const stat = fs.lstatSync(lockPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
        stat.size < 1 || stat.size > MAX_LOCK_BYTES) throw new Error('Invalid generated lockfile.');
    const audit = inspectWindowsDependencyLock(scratch);
    if (!audit.lockfileReady) {
      throw new Error(`Generated lockfile rejected by metadata preflight: ${audit.blockers.join(', ')}`);
    }
    const lock = fs.readFileSync(lockPath);
    // A new untracked lockfile is invisible to git diff HEAD. Reject it too.
    command('git', ['diff', '--quiet', '--no-ext-diff', 'HEAD', '--'], source, 10000);
    assertNoSourceLockEntries();
    assertSafeOutput(source, output);
    fs.mkdirSync(output); created = true;
    fs.writeFileSync(path.join(output, 'package-lock.candidate.json'), lock, { flag: 'wx' });
    const proof = {
      kind: 'tuniq-windows-lockfile-candidate', schemaVersion: 1,
      sourceCommit: commit, sourcePackageSha256: sha(pkg), candidateSha256: sha(lock),
      nodeVersion: process.version, npmVersion, metadataPreflightPassed: true,
      nativeInstallVerified: false, electronRuntimeVerified: false,
      fullTunIQVerified: false, physicalHardwareVerified: false
    };
    fs.writeFileSync(path.join(output, 'candidate-provenance.json'), JSON.stringify(proof, null, 2) + '\n', { flag: 'wx' });
    const reviewed = reviewCandidate(source, output);
    assertNoSourceLockEntries();
    return reviewed;
  } catch (error) {
    if (created) fs.rmSync(output, { recursive: true, force: true });
    throw error;
  } finally {
    fs.rmSync(scratch, { recursive: true, force: true });
  }
}
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 1 || args.length > 2 || args.some(x => x.startsWith('--') && x !== '--offline') ||
      (args.length === 2 && args[1] !== '--offline') || args[0] === '--offline') {
    console.error('Usage: node tools/generate-lockfile-candidate.js <new-output-directory> [--offline]');
    process.exitCode = 2;
  } else {
    try {
      const result = generateCandidate(path.resolve(__dirname, '..'), args[0], { offline: args[1] === '--offline' });
      console.log(JSON.stringify(result, null, 2));
    } catch (error) {
      console.error(`Lockfile candidate NOT VERIFIED: ${error.message}`);
      process.exitCode = 1;
    }
  }
}
module.exports = { generateCandidate };
