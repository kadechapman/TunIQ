#!/usr/bin/env node
'use strict';
// Offline source-layout audit for Windows checkout/packaging hazards.
// Reads source and manifest only; does not install, package, or access ECUs.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const MAX_MANIFEST_BYTES = 4 * 1024 * 1024;
const MAX_SOURCE_FILES = 10000;
const MAX_RELATIVE_UNITS = 240; // conservative; not a guarantee about checkout-root length
const MAX_ISSUES = 32;
const WINDOWS_FORBIDDEN = /[<>:"|?*\\\x00-\x1f\x7f]/;
const WINDOWS_DEVICE = /^(?:CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[1-9¹²³]|LPT[1-9¹²³])(?:\.|$)/i;

function auditWindowsPaths(paths) {
  const issues = [];
  const add = (code, sourcePath) => {
    if (issues.length < MAX_ISSUES) issues.push({ code, path: sourcePath });
  };
  if (!Array.isArray(paths) || paths.length > MAX_SOURCE_FILES) {
    return { safe: false, count: Array.isArray(paths) ? paths.length : 0,
      issues: [{ code: 'invalid-path-list', path: null }] };
  }
  const spellings = new Map();
  const files = new Set();
  for (const sourcePath of paths) {
    if (typeof sourcePath !== 'string' || !sourcePath || sourcePath.length > MAX_RELATIVE_UNITS ||
        sourcePath.startsWith('/') || sourcePath.includes('\\')) {
      add('invalid-relative-path', sourcePath);
      continue;
    }
    const parts = sourcePath.split('/');
    if (parts.some(part => !part || part === '.' || part === '..' ||
        part.length > 255 || /[. ]$/.test(part) || WINDOWS_FORBIDDEN.test(part) || WINDOWS_DEVICE.test(part))) {
      add('invalid-windows-component', sourcePath);
      continue;
    }
    for (let i = 0; i < parts.length; i++) {
      const spelled = parts.slice(0, i + 1).join('/');
      const normalized = spelled.toLowerCase();
      const previous = spellings.get(normalized);
      if (previous !== undefined && previous !== spelled) add('windows-case-collision', sourcePath);
      else spellings.set(normalized, spelled);
      if (i < parts.length - 1 && files.has(normalized)) add('file-directory-conflict', sourcePath);
    }
    const key = sourcePath.toLowerCase();
    if (files.has(key)) add('duplicate-source-path', sourcePath);
    files.add(key);
  }
  // A later file may conflict with an earlier directory, regardless of
  // enumeration order. Check prefixes in linear time, not all path pairs.
  for (const key of files) {
    const parts = key.split('/');
    for (let i = 1; i < parts.length; i++) {
      if (files.has(parts.slice(0, i).join('/'))) {
        add('file-directory-conflict', key);
        break;
      }
    }
  }
  return { safe: issues.length === 0, count: paths.length, issues };
}

// Older archives record optional test-results/*.log evidence that is not
// tracked in clean source checkouts. Exempt only *absent, direct-child logs*.
// existsSync() is insufficient here: it also returns false for a dangling
// symlink, which would incorrectly turn an unsafe path into an exemption.
function absentHistoricalLog(appPath, relative) {
  if (!/^test-results\/[^/]+\.log$/.test(relative)) return false;
  try {
    if (fs.lstatSync(path.join(appPath, relative), { throwIfNoEntry: false })) return false;
    const parent = fs.lstatSync(path.join(appPath, 'test-results'), { throwIfNoEntry: false });
    return !parent || (parent.isDirectory() && !parent.isSymbolicLink());
  } catch { return false; }
}

function inspectWindowsSourceLayout(appPath = path.resolve(__dirname, '..')) {
  const blockers = [];
  const contentMismatches = [];
  const unsafeSourcePaths = [];
  let contentMismatchCount = 0;
  const add = code => { if (!blockers.includes(code)) blockers.push(code); };
  let rows = [];
  const manifestPath = path.join(appPath, 'SOURCE_MANIFEST.json');
  try {
    const stat = fs.lstatSync(manifestPath);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
        stat.size > MAX_MANIFEST_BYTES) throw new Error('unsafe manifest');
    const bytes = fs.readFileSync(manifestPath);
    if (bytes.length !== stat.size) throw new Error('manifest changed');
    const digestPath = path.join(appPath, 'SOURCE_MANIFEST_SHA256.txt');
    const digestStat = fs.lstatSync(digestPath);
    if (!digestStat.isFile() || digestStat.isSymbolicLink() || digestStat.nlink !== 1 ||
        digestStat.size > 128) throw new Error('unsafe manifest digest');
    const recorded = fs.readFileSync(digestPath, 'utf8');
    const match = /^([a-f0-9]{64})  SOURCE_MANIFEST\.json\s*$/.exec(recorded);
    if (!match || crypto.createHash('sha256').update(bytes).digest('hex') !== match[1]) {
      add('manifest-digest-mismatch');
    }
    const parsed = JSON.parse(bytes.toString('utf8'));
    if (!parsed || !Array.isArray(parsed.files) || parsed.files.length > MAX_SOURCE_FILES) {
      throw new Error('invalid manifest structure');
    }
    rows = parsed.files;
  } catch { add('manifest-unavailable-or-invalid'); }
  const paths = rows.map(row => row && row.path);
  const audit = auditWindowsPaths(paths);
  for (const issue of audit.issues) add(issue.code);
  // Only traverse paths that have already passed Windows path validation.
  // lstat each component to reject symlinked/junction-like parents without
  // following them. This is a static preflight, not a race-free file lease.
  if (audit.safe) {
    for (const row of rows) {
      if (!row || !Number.isSafeInteger(row.size) || row.size < 0 ||
          typeof row.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(row.sha256)) {
        add('invalid-manifest-entry');
        break;
      }
      // Historical test-results/*.log files are intentionally not tracked
      // by Git. They may exist in a source ZIP but not a clean checkout;
      // their Windows names are still audited above. Never exempt code.
      if (absentHistoricalLog(appPath, row.path)) continue;
      const parts = row.path.split('/');
      let current = appPath;
      try {
        for (let i = 0; i < parts.length; i++) {
          current = path.join(current, parts[i]);
          const stat = fs.lstatSync(current);
          if (stat.isSymbolicLink() || (i < parts.length - 1 ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) {
            throw new Error('unsafe path component');
          }
          if (i === parts.length - 1) {
            // Hash one captured read: avoid rereading mutable files for evidence.
            const content = fs.readFileSync(current);
            const actualSha256 = crypto.createHash('sha256').update(content).digest('hex');
            if (content.length !== stat.size || stat.size !== row.size || actualSha256 !== row.sha256) {
              add('source-manifest-content-mismatch');
              contentMismatchCount++;
              if (contentMismatches.length < MAX_ISSUES) {
                contentMismatches.push({ path: row.path, expectedSize: row.size,
                  actualSize: content.length, expectedSha256: row.sha256, actualSha256 });
              }
            }
          }
        }
      } catch {
        add('source-path-missing-or-unsafe');
        if (unsafeSourcePaths.length < MAX_ISSUES) unsafeSourcePaths.push(row.path);
      }
    }
  }
  return {
    schemaVersion: 1, auditKind: 'offline-windows-source-layout',
    windowsSourcePathsSafe: blockers.length === 0, fileCount: rows.length,
    blockers, issues: audit.issues, unsafeSourcePaths, contentMismatchCount, contentMismatches,
    windowsBuildVerified: false, nativeInstallVerified: false, physicalHardwareVerified: false,
    note: 'Static source-manifest and Windows filename audit only; not proof of Windows checkout, NTFS semantics, npm ci, installer, or ECU hardware.'
  };
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length > 2 || args.some(arg => arg.startsWith('--') && !['--report', '--require-safe'].includes(arg)) ||
      (args.includes('--report') && args.includes('--require-safe'))) {
    console.error('Usage: node tools/windows-source-path-preflight.js [project-folder] [--report|--require-safe]');
    process.exitCode = 1;
  } else {
    const folder = args.find(arg => !arg.startsWith('--')) || path.resolve(__dirname, '..');
    const report = inspectWindowsSourceLayout(folder);
    console.log(JSON.stringify(report, null, 2));
    if (!args.includes('--report') && !report.windowsSourcePathsSafe) process.exitCode = 2;
  }
}
module.exports = { auditWindowsPaths, inspectWindowsSourceLayout };
