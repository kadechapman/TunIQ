#!/usr/bin/env node
'use strict';
// Zero-dependency, hardware-free browser demo. Not Electron or ECM tuning.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '..');
const files = [
  ['src/renderer/index.html', 'src/renderer/index.html'],
  ['src/renderer/styles.css', 'src/renderer/styles.css'],
  ['src/renderer/engine-catalog.js', 'src/renderer/engine-catalog.js'],
  ['src/renderer/app.js', 'src/renderer/app.js'],
  ['tools/browser-preview-bridge.js', 'src/renderer/browser-preview-bridge.js']
];
const warning = '<div id="offline-dev-banner" role="status">BROWSER UI DEMO — ALL ECU OPERATIONS DISABLED — NOT ELECTRON — NOT FOR VEHICLE USE</div>';
const css = '\n#offline-dev-banner{position:fixed;z-index:2147483647;top:0;left:0;right:0;padding:10px;background:#8b1029;color:#fff;text-align:center;font:bold 13px Arial,sans-serif;pointer-events:none}';
const launcher = '@echo off\r\nsetlocal\r\nstart "" "%~dp0src\\renderer\\index.html"\r\n';
const readme = 'TunIQ browser UI demo — no Electron, ECU, OBD, flashing, or tuning.\r\nDouble-click OPEN_PREVIEW.cmd on Windows, or open src/renderer/index.html in a browser.\r\nOnly UI navigation is enabled. No data is saved. This is NOT a verified Windows Electron build.\r\n';
function isInside(parent, candidate) {
  const rel = path.relative(parent, candidate);
  return !rel || (rel !== '..' && !rel.startsWith('..' + path.sep) && !path.isAbsolute(rel));
}
function checkPath(p) {
  const abs = path.resolve(p), base = path.parse(abs).root;
  let current = base;
  for (const segment of abs.slice(base.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, segment);
    const stat = fs.lstatSync(current, { throwIfNoEntry: false });
    if (!stat) break;
    if (stat.isSymbolicLink()) throw new Error('symlink-path-denied');
  }
}
function makeFiles() {
  const out = [];
  for (const [src, dest] of files) {
    const full = path.join(root, src);
    checkPath(full);
    const st = fs.lstatSync(full);
    if (!st.isFile() || st.isSymbolicLink() || st.nlink !== 1) throw new Error('unsafe-source-file');
    let bytes = fs.readFileSync(full);
    if (src.endsWith('/index.html')) {
      let html = bytes.toString('utf8');
      if (!html.includes("script-src 'self'") || !html.includes('<script src="engine-catalog.js"></script>') ||
          !html.includes('</body>')) throw new Error('unexpected-html-template');
      html = html.replace('<script src="engine-catalog.js"></script>',
        '<script src="browser-preview-bridge.js"></script>\n<script src="engine-catalog.js"></script>');
      html = html.replace('</body>', `${warning}\n</body>`);
      bytes = Buffer.from(html);
    } else if (src.endsWith('/styles.css')) bytes = Buffer.concat([bytes, Buffer.from(css)]);
    out.push([dest, bytes]);
  }
  out.push(['OPEN_PREVIEW.cmd', Buffer.from(launcher)]);
  out.push(['README.txt', Buffer.from(readme)]);
  return out;
}
function stage(dir) {
  const destination = path.resolve(dir);
  if (isInside(root, destination) || isInside(destination, root)) throw new Error('overlapping-output-denied');
  checkPath(destination);
  if (fs.existsSync(destination) && fs.readdirSync(destination).length) throw new Error('nonempty-output-denied');
  const prepared = makeFiles();
  fs.mkdirSync(path.dirname(destination), { recursive: true });
  const scratch = fs.mkdtempSync(path.join(path.dirname(destination), '.tuniq-browser-'));
  try {
    const manifest = [];
    for (const [name, bytes] of prepared) {
      const full = path.join(scratch, name);
      fs.mkdirSync(path.dirname(full), { recursive: true });
      fs.writeFileSync(full, bytes, { flag: 'wx' });
      manifest.push({ path: name, sha256: crypto.createHash('sha256').update(bytes).digest('hex') });
    }
    fs.writeFileSync(path.join(scratch, 'MANIFEST_SHA256.json'), JSON.stringify(manifest, null, 2) + '\n');
    if (fs.existsSync(destination)) fs.rmdirSync(destination);
    fs.renameSync(scratch, destination);
    return { output: destination, files: manifest.length, hardwareCodeIncluded: false };
  } finally { if (fs.existsSync(scratch)) fs.rmSync(scratch, { recursive: true, force: true }); }
}
function verify(dir) {
  const destination = path.resolve(dir);
  checkPath(destination);
  const expected = makeFiles();
  const manifest = JSON.parse(fs.readFileSync(path.join(destination, 'MANIFEST_SHA256.json'), 'utf8'));
  const names = expected.map(([name]) => name);
  const found = [];
  function walk(folder, prefix = '') {
    for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
      const name = prefix ? `${prefix}/${entry.name}` : entry.name;
      const st = fs.lstatSync(path.join(folder, entry.name));
      if (st.isSymbolicLink()) throw new Error('symlink-output-denied');
      if (st.isDirectory()) walk(path.join(folder, entry.name), name);
      else if (st.isFile() && st.nlink === 1) found.push(name);
      else throw new Error('unsafe-output-entry');
    }
  }
  walk(destination);
  if (found.length !== names.length + 1 ||
      found.some(name => name !== 'MANIFEST_SHA256.json' && !names.includes(name)) ||
      manifest.length !== expected.length || manifest.some((item, i) =>
        item.path !== expected[i][0] ||
        item.sha256 !== crypto.createHash('sha256').update(expected[i][1]).digest('hex') ||
        !fs.readFileSync(path.join(destination, item.path)).equals(expected[i][1])))
    throw new Error('browser-preview-integrity-failed');
  return { verifiedFiles: names.length, hardwareCodeIncluded: false };
}
if (require.main === module) {
  try {
    const arg = process.argv[2], dir = process.argv[3];
    if (!dir || !['--stage', '--verify'].includes(arg)) throw new Error('usage: --stage|--verify <absolute-output-directory>');
    console.log(JSON.stringify(arg === '--stage' ? stage(dir) : verify(dir)));
  } catch (e) { console.error(e.message); process.exitCode = 1; }
}
module.exports = { stage, verify, makeFiles };
