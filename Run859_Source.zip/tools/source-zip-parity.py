#!/usr/bin/env python3
"""Fail-closed, offline ZIP-vs-Git source parity audit. No ECU or runtime access.

Unlike extracted-directory checks, this rejects duplicate ZIP members, unsafe paths,
symlinks and malformed compressed data before accepting a source archive.
"""
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from pathlib import Path

MAX_FILES = 20000
MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_TOTAL_BYTES = 256 * 1024 * 1024
MAX_ISSUES = 32


def windows_unsafe_path(name):
    """Reject ZIP paths that cannot be safely materialized on Windows/NTFS."""
    for part in name.split('/'):
        if not part or len(part) > 255 or part.endswith((' ', '.')) or re.search(r'[<>:"|?*\x00-\x1f\x7f]', part):
            return True
        device = part.split('.', 1)[0].rstrip(' ').upper()
        if device in ('CON', 'PRN', 'AUX', 'NUL', 'CONIN$', 'CONOUT$') or re.fullmatch(r'(COM|LPT)[1-9¹²³]', device):
            return True
    return False


def audit(repo, archive, ref='HEAD'):
    repo, archive = str(Path(repo).resolve()), Path(archive).resolve()
    def git(*args):
        return subprocess.run(['git', '-C', repo, *args], capture_output=True,
                              check=True, timeout=30).stdout
    fmt = git('rev-parse', '--show-object-format').decode('ascii').strip()
    if fmt not in ('sha1', 'sha256'):
        raise ValueError('Unsupported Git object format')
    commit = git('rev-parse', '--verify', f'{ref}^{{commit}}').decode('ascii').strip()
    if not re.fullmatch('[a-f0-9]{40}|[a-f0-9]{64}', commit):
        raise ValueError('Invalid commit identifier')
    expected = {}
    for raw in git('ls-tree', '-rz', '--full-tree', commit).split(b'\0'):
        if not raw:
            continue
        match = re.fullmatch(rb'(\d{6}) blob ([a-f0-9]+)\t(.+)', raw, re.DOTALL)
        if not match:
            raise ValueError('Unsupported Git tree entry')
        name = match[3].decode('utf-8', errors='strict')
        if name in expected or len(expected) >= MAX_FILES:
            raise ValueError('Duplicate or oversized Git tree')
        expected[name] = (match[1].decode('ascii'), match[2].decode('ascii'))
    issues, seen, matched, total = [], set(), 0, 0
    windows_names = {}
    def issue(code, name):
        if len(issues) < MAX_ISSUES:
            issues.append({'code': code, 'path': name})
    with zipfile.ZipFile(archive, 'r', allowZip64=True) as zf:
        entries = zf.infolist()
        if len(entries) > MAX_FILES:
            raise ValueError('Too many ZIP members')
        # Accept either Git-root members or one consistent enclosing folder.
        # Mixed roots are never normalized into a passing archive.
        file_names = [item.filename for item in entries if not item.is_dir()]
        archive_root = ''
        if file_names and not any(name in expected for name in file_names):
            first = file_names[0].split('/', 1)[0]
            if first and all(name.startswith(first + '/') for name in file_names):
                archive_root = first + '/'
        def unsafe_path(name):
            return (not name or name.startswith('/') or '\\' in name or '\x00' in name or
                    re.match(r'^[a-zA-Z]:', name) or any(p in ('', '.', '..') for p in name.split('/')))
        for info in entries:
            raw_name = info.filename
            name = raw_name[len(archive_root):] if archive_root and raw_name.startswith(archive_root) else raw_name
            if info.is_dir():
                issue('directory-member', raw_name)
                continue
            # Validate the raw member *before* stripping an enclosing folder.
            # Otherwise a common ../ or C:/ prefix could conceal traversal.
            if unsafe_path(raw_name) or unsafe_path(name):
                issue('unsafe-path', raw_name)
                continue
            if windows_unsafe_path(raw_name) or windows_unsafe_path(name):
                issue('windows-unsafe-path', raw_name)
                continue
            # Even distinct Git paths can alias on case-insensitive Windows
            # filesystems, including at intermediate directory components.
            # Do not certify a ZIP that cannot round-trip its committed tree.
            components = name.split('/')
            collision = False
            for index in range(1, len(components) + 1):
                prefix = '/'.join(components[:index])
                key = prefix.casefold()
                previous = windows_names.get(key)
                if previous is not None and previous != prefix:
                    issue('windows-path-collision', name)
                    collision = True
                    break
                windows_names[key] = prefix
            if collision:
                continue
            if name in seen:
                issue('duplicate-member', name)
                continue
            seen.add(name)
            mode = (info.external_attr >> 16) & 0o170000
            if mode not in (0, 0o100000):
                issue('unsafe-member-mode', name)
                continue
            if info.flag_bits & 1 or info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                issue('unsupported-zip-feature', name)
                continue
            record = expected.get(name)
            if record is None:
                issue('extra-file', name)
                continue
            if record[0] not in ('100644', '100755'):
                issue('unsupported-git-mode', name)
                continue
            # Content hashes alone do not prove source-export parity: a ZIP
            # can preserve identical bytes while adding executable/setuid bits.
            # Require explicit Unix file-mode metadata matching the Git tree.
            # DOS-only ZIP metadata cannot attest these permission bits.
            if info.create_system != 3 or (info.external_attr >> 16) != int(record[0], 8):
                issue('source-mode-mismatch', name)
                continue
            if info.file_size > MAX_FILE_BYTES or total + info.file_size > MAX_TOTAL_BYTES:
                issue('oversized-entry', name)
                continue
            # Read in bounded chunks. Do not trust the declared uncompressed size.
            hasher = hashlib.new(fmt)
            hasher.update(f'blob {info.file_size}\0'.encode('ascii'))
            count = 0
            try:
                with zf.open(info, 'r') as stream:
                    while True:
                        chunk = stream.read(1024 * 1024)
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > info.file_size or count > MAX_FILE_BYTES or total + count > MAX_TOTAL_BYTES:
                            raise ValueError('Uncompressed size exceeded bounds')
                        hasher.update(chunk)
            except (OSError, EOFError, RuntimeError, ValueError, zipfile.BadZipFile):
                issue('unreadable-entry', name)
                continue
            total += count
            if count != info.file_size or hasher.hexdigest() != record[1]:
                issue('content-mismatch', name)
            else:
                matched += 1
    for name in expected:
        if name not in seen:
            issue('missing-file', name)
    return {'kind': 'tuniq-source-zip-git-parity', 'schemaVersion': 1,
            'commit': commit, 'objectFormat': fmt, 'expectedFiles': len(expected),
            'archiveMembers': len(seen), 'archiveRoot': archive_root, 'matchedFiles': matched,
            'passed': not issues and len(seen) == len(expected), 'issues': issues,
            'windowsRuntimeVerified': False, 'fullTunIQVerified': False,
            'hardwareUsed': False}


def main():
    if len(sys.argv) not in (3, 4):
        print('Usage: source-zip-parity.py <git-repo> <source.zip> [commit]', file=sys.stderr)
        return 2
    try:
        result = audit(*sys.argv[1:])
        print(json.dumps(result, indent=2))
        return 0 if result['passed'] else 1
    except (OSError, subprocess.SubprocessError, ValueError, UnicodeError, zipfile.BadZipFile) as exc:
        print(f'Source ZIP NOT VERIFIED: {type(exc).__name__}: {exc}', file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
