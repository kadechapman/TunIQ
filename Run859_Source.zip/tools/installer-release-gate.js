#!/usr/bin/env node
'use strict';

// Source-only beta checkpoints are NOT release attestations. This is a
// fail-closed barrier for the convenience installer scripts, not a substitute
// for a separately reviewed and signed production release workflow.
const path = require('path');
const { verifySnapshot, sourceAudit } = require('./launch-snapshot');

function checkInstallerAdmission(appPath = path.resolve(__dirname, '..')) {
  const snapshot = verifySnapshot(appPath);
  if (!snapshot.valid) {
    return { allowed: false, reason: 'source-snapshot-invalid', detail: snapshot.reason };
  }
  const audit = sourceAudit(appPath);
  if (audit.snapshotKind !== 'source-only' || audit.physicalHardwareVerified !== false) {
    return { allowed: false, reason: 'unexpected-audit-provenance', detail: 'Unexpected source audit provenance.' };
  }
  return {
    allowed: false,
    reason: 'source-only-not-release-authorized',
    detail: `Source-only checkpoint: ${audit.blockers.length} full-launch blockers. ` +
      'No reviewed release attestation or signed installer pipeline is available. ' +
      'Use the offline source-validation workflow; do not package an ECU-capable installer.',
    blockerIds: audit.blockers.map(blocker => blocker.id)
  };
}

if (require.main === module) {
  const result = checkInstallerAdmission();
  console.error(`TunIQ installer BLOCKED [${result.reason}]: ${result.detail}`);
  process.exitCode = 1;
}

module.exports = { checkInstallerAdmission };
