#ifndef TUNIQ_STANDALONE_TEMP_PATH_H
#define TUNIQ_STANDALONE_TEMP_PATH_H
/*
 * Fail closed when Windows' environment-derived TEMP/TMP points at a UNC,
 * device, drive-relative or noncanonical path. This is only a lexical guard;
 * the launcher separately checks GetDriveTypeW for mapped network drives.
 * Neither check proves absence of junctions/reparse points or native behavior.
 * Use UTF-16 code units, independent of host wchar_t size.
 */
/* Win32 normalizes trailing dots/spaces and interprets reserved DOS device
 * basenames even when an extension is supplied. Do not accept a TEMP path
 * whose spelling can be reinterpreted by Win32 file APIs. This is still a
 * lexical guard, not a reparse-point or native Windows runtime proof. */
static unsigned short tuniq_win_ascii_upper(unsigned short c) {
  return (c >= 'a' && c <= 'z') ? c - ('a' - 'A') : c;
}
static int tuniq_win_reserved_component(const unsigned short *p, unsigned long len) {
  unsigned long n = 0;
  while (n < len && p[n] != '.') n++;
  /* Fail closed on DOS-device aliases with spaces immediately before the
   * extension separator (for example CON .txt). Do not treat the spelling
   * as proof of an ordinary directory on a Windows host. */
  while (n && p[n - 1] == ' ') n--;
  if (n == 3) {
    unsigned short a=tuniq_win_ascii_upper(p[0]), b=tuniq_win_ascii_upper(p[1]);
    unsigned short c=tuniq_win_ascii_upper(p[2]);
    if ((a=='C' && b=='O' && c=='N') || (a=='P' && b=='R' && c=='N') ||
        (a=='A' && b=='U' && c=='X') || (a=='N' && b=='U' && c=='L')) return 1;
  }
  if (n == 4) {
    unsigned short a=tuniq_win_ascii_upper(p[0]), b=tuniq_win_ascii_upper(p[1]);
    unsigned short c=tuniq_win_ascii_upper(p[2]);
    /* Win32 treats superscript 1/2/3 as digits in COM/LPT device names. */
    if (((a=='C' && b=='O' && c=='M') || (a=='L' && b=='P' && c=='T')) &&
        ((p[3]>='1' && p[3]<='9') || p[3]==0x00b9 ||
         p[3]==0x00b2 || p[3]==0x00b3)) return 1;
  }
  /* Console input/output device aliases are also unsafe TEMP components. */
  if (n == 6 && tuniq_win_ascii_upper(p[0])=='C' &&
      tuniq_win_ascii_upper(p[1])=='O' && tuniq_win_ascii_upper(p[2])=='N' &&
      tuniq_win_ascii_upper(p[3])=='I' && tuniq_win_ascii_upper(p[4])=='N' &&
      p[5]=='$') return 1;
  if (n == 7 && tuniq_win_ascii_upper(p[0])=='C' &&
      tuniq_win_ascii_upper(p[1])=='O' && tuniq_win_ascii_upper(p[2])=='N' &&
      tuniq_win_ascii_upper(p[3])=='O' && tuniq_win_ascii_upper(p[4])=='U' &&
      tuniq_win_ascii_upper(p[5])=='T' && p[6]=='$') return 1;
  return 0;
}
static int tuniq_local_temp_path(const unsigned short *path, unsigned long length) {
  unsigned long start, i;
  unsigned short drive;
  if (!path || length < 3 || length > 32766 || path[length] != 0) return 0;
  drive = path[0];
  if (!((drive >= 'A' && drive <= 'Z') || (drive >= 'a' && drive <= 'z')) ||
      path[1] != ':' || path[2] != '\\' || path[length - 1] != '\\') return 0;
  for (i = 3; i < length; i++) {
    if (path[i] == '/' || path[i] == ':' || path[i] < 32 || path[i] == 127 ||
        path[i] == '?' || path[i] == '*' || path[i] == '"' ||
        path[i] == '<' || path[i] == '>' || path[i] == '|') return 0;
    /* Reject malformed UTF-16 before handing the environment-derived path
     * to Win32 APIs. Valid surrogate pairs remain permitted. */
    if (path[i] >= 0xD800 && path[i] <= 0xDBFF) {
      if (i + 1 >= length || path[i + 1] < 0xDC00 || path[i + 1] > 0xDFFF) return 0;
      i++;
    } else if (path[i] >= 0xDC00 && path[i] <= 0xDFFF) return 0;
  }
  for (start = 3; start < length;) {
    unsigned long end = start;
    while (end < length && path[end] != '\\') end++;
    if (end == length) return 0;
    if (end == start || (end == start + 1 && path[start] == '.') ||
        (end == start + 2 && path[start] == '.' && path[start + 1] == '.') ||
        path[end - 1] == '.' || path[end - 1] == ' ' ||
        tuniq_win_reserved_component(path + start, end - start)) return 0;
    start = end + 1;
  }
  return 1;
}
#endif
