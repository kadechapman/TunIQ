'use strict';

// The runner must EXIT successfully; a printed success banner alone is not proof.
// This wrapper never opens a COM port or communicates with an ECU.
const { spawn } = require('child_process');
const path = require('path');
const { StringDecoder } = require('string_decoder');
const EXPECTED_GROUPS = 76;
// A malformed or runaway child must not grow the verifier's progress set
// without bound. The real suite emits fewer than 100 distinct milestones.
const MAX_DISTINCT_PROGRESS = 128;
const MAX_PROGRESS_LABEL_LENGTH = 512;
// A printed count alone is insufficient: a broken runner can emit 76 unrelated
// progress lines and a success banner without exercising any safety checks.
// Keep this independent list synchronized with the suite's named milestones.
const REQUIRED_PROGRESS = require('../tests/suite-progress-required.json');
if (!Array.isArray(REQUIRED_PROGRESS) || REQUIRED_PROGRESS.length < EXPECTED_GROUPS / 2 ||
    REQUIRED_PROGRESS.some(label => typeof label !== 'string' || !label.trim()) ||
    new Set(REQUIRED_PROGRESS).size !== REQUIRED_PROGRESS.length) {
  throw new Error('TunIQ suite required-progress manifest is invalid.');
}
// Bind the success proof to this source version and the named suite.
// A banner from an older build (or an unrelated script) is not proof.
const EXPECTED_BANNER = `All TunIQ ${require('../package.json').version} Structured Read Integrity Status Guard automated tests passed (${EXPECTED_GROUPS} groups).`;
const SUCCESS = line => line === EXPECTED_BANNER;
const DEFAULT_TIMEOUT_MS = 300000;
const DEFAULT_IDLE_TIMEOUT_MS = 120000;
// Diagnostic-only heartbeats never count as progress or extend a deadline.
const DEFAULT_DIAGNOSTIC_INTERVAL_MS = 15000;

function validTimeout(value, label) {
  if (!Number.isSafeInteger(value) || value < 1 || value > 600000) {
    throw new Error(`Invalid ${label}.`);
  }
  return value;
}

function runSuite(command, args, options = {}) {
  const timeoutMs = validTimeout(options.timeoutMs ?? DEFAULT_TIMEOUT_MS, 'suite timeout');
  const idleTimeoutMs = validTimeout(options.idleTimeoutMs ?? DEFAULT_IDLE_TIMEOUT_MS, 'suite idle timeout');
  const diagnosticIntervalMs = validTimeout(options.diagnosticIntervalMs ?? DEFAULT_DIAGNOSTIC_INTERVAL_MS, 'suite diagnostic interval');
  const output = options.output || process.stdout;
  const errors = options.errors || process.stderr;
  return new Promise(resolve => {
    let child;
    try {
      child = spawn(command, args, {
        cwd: options.cwd || process.cwd(),
        env: options.env || process.env,
        stdio: ['ignore', 'pipe', 'pipe'],
        windowsHide: true
      });
    } catch (error) {
      errors.write(`Suite could not start: ${error.message}\n`);
      resolve({ ok: false, reason: 'spawn-failed', code: null });
      return;
    }
    let banner = false;
    let prematureBanner = false;
    let outputAfterBanner = false;
    let stdoutBuffer = '';
    let stderrBuffer = '';
    const stdoutDecoder = new StringDecoder('utf8');
    const stderrDecoder = new StringDecoder('utf8');
    const seenGroups = new Set();
    let lastGroup = null;
    let progressCount = 0;
    let invalidProgress = null;
    const requiredProgress = new Set(REQUIRED_PROGRESS);
    const seenRequired = new Set();
    let timedOut = false;
    let timeoutReason = null;
    let spawnError = null;
    let finished = false;
    let timer;
    let idleTimer;
    let diagnosticTimer;
    const startedAt = Date.now();
    let lastVerifiedProgressAt = startedAt;

    // Only NEW named required test milestones refresh the idle deadline.
    // Arbitrary output, fake checkmarks, duplicates, and early banners must
    // not keep a stalled suite alive. Keep line buffers bounded on bad output.
    const resetIdle = () => {
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => failTimeout('idle-timeout', idleTimeoutMs), idleTimeoutMs);
    };
    const acceptStdoutLine = line => {
      // Once success has been printed, any further nonblank stdout is
      // unexpected. A final failure diagnostic must not be ignored.
      if (banner && line.trim()) outputAfterBanner = true;
      if (line.startsWith('✓ ')) {
        const label = line.slice(2);
        if (!label || seenGroups.has(label)) return;
        if (label.length > MAX_PROGRESS_LABEL_LENGTH) {
          invalidProgress = 'oversized-group-label';
          return;
        }
        if (seenGroups.size >= MAX_DISTINCT_PROGRESS) {
          invalidProgress = 'excessive-group-progress';
          return;
        }
        seenGroups.add(label);
        // Only a first occurrence of a named, required suite milestone proves
        // forward progress. Unrelated or fabricated checkmarks must not keep
        // a stuck runner alive until the much longer total timeout.
        if (requiredProgress.has(label)) {
          seenRequired.add(label);
          lastVerifiedProgressAt = Date.now();
          resetIdle();
        }
        lastGroup = label.slice(0, 510);
        progressCount = seenGroups.size;
      } else if (SUCCESS(line)) {
        if (progressCount >= EXPECTED_GROUPS && seenRequired.size === requiredProgress.size) banner = true;
        else prematureBanner = true;
      }
    };
    const observe = (chunk, channel) => {
      // stdout is the only source of proof. stderr diagnostics cannot
      // manufacture a group or success banner, even when chunks interleave.
      const isStdout = channel === 'stdout';
      const decoder = isStdout ? stdoutDecoder : stderrDecoder;
      const value = decoder.write(chunk);
      const buffered = (isStdout ? stdoutBuffer : stderrBuffer) + value;
      const lines = buffered.split(/\r?\n/);
      const pending = lines.pop().slice(-4096);
      if (isStdout) stdoutBuffer = pending;
      else stderrBuffer = pending;
      if (!isStdout) return;
      for (const line of lines) acceptStdoutLine(line);
    };
    const settle = (code, signal) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      clearTimeout(idleTimer);
      clearInterval(diagnosticTimer);
      const missingRequired = REQUIRED_PROGRESS.filter(label => !seenRequired.has(label));
      // Any success banner before all required milestones is a protocol violation,
      // even if the child prints a second valid banner at the end. Otherwise
      // an early fabricated success claim can be laundered into a passing run.
      const ok = !invalidProgress && !prematureBanner && !outputAfterBanner && !timedOut && !spawnError && code === 0 && !signal && banner &&
        progressCount >= EXPECTED_GROUPS && missingRequired.length === 0;
      const reason = timeoutReason || invalidProgress || (outputAfterBanner ? 'output-after-success-banner' : spawnError ? 'spawn-failed' : code !== 0 || signal ? 'exit-failure' :
        prematureBanner && banner ? 'premature-success-banner' :
        banner ? 'passed' : prematureBanner ? (progressCount < EXPECTED_GROUPS ? 'insufficient-group-progress' :
          missingRequired.length ? 'missing-required-groups' : 'premature-success-banner') : 'missing-success-banner');
      if (!ok) errors.write(`Suite NOT VERIFIED: code=${code}, signal=${signal || 'none'}, banner=${banner}, prematureBanner=${prematureBanner}, groups=${progressCount}/${EXPECTED_GROUPS}, required=${seenRequired.size}/${REQUIRED_PROGRESS.length}, missingRequired=${JSON.stringify(missingRequired.slice(0, 3))}, timeout=${timedOut}, reason=${reason}, lastGroup=${JSON.stringify(lastGroup)}.\n`);
      resolve({ ok, reason, code, signal, banner, lastGroup, progressCount, requiredCount: seenRequired.size, missingRequiredCount: missingRequired.length });
    };
    const failTimeout = (reason, deadline) => {
      if (finished) return;
      timedOut = true;
      timeoutReason = reason;
      errors.write(`\nSuite ${reason === 'idle-timeout' ? 'made no completed-group progress' : 'exceeded total runtime'} for ${deadline} ms; last completed group: ${lastGroup || '(none)'}. Success is NOT verified.\n`);
      try { child.kill('SIGKILL'); } catch (error) {
        errors.write(`Suite child termination failed: ${error.message}\n`);
      }
      // A descendant may inherit stdout/stderr and prevent `close`. Do not
      // wait for those handles: the deadline itself must settle the verifier.
      child.stdout?.destroy();
      child.stderr?.destroy();
      settle(null, reason);
    };
    child.stdout.on('data', chunk => { output.write(chunk); observe(chunk, 'stdout'); });
    child.stderr.on('data', chunk => { errors.write(chunk); observe(chunk, 'stderr'); });
    child.on('error', error => { spawnError = error; });
    timer = setTimeout(() => failTimeout('timeout', timeoutMs), timeoutMs);
    resetIdle();
    diagnosticTimer = setInterval(() => {
      if (finished) return;
      const now = Date.now();
      errors.write(`Suite pending (NOT VERIFIED): elapsedMs=${now - startedAt}, idleMs=${now - lastVerifiedProgressAt}, required=${seenRequired.size}/${REQUIRED_PROGRESS.length}, banner=${banner}, lastGroup=${JSON.stringify(lastGroup)}.\n`);
    }, diagnosticIntervalMs);
    child.on('close', (code, signal) => {
      if (finished) return; // The timeout path already settled and cleared timers.
      // A cleanly closed stdout pipe proves that its final bytes are complete,
      // even when the child omitted the final newline. Never use stderr as proof.
      // This cannot turn a failed exit, signal, or timeout into a suite pass.
      const tail = stdoutBuffer + stdoutDecoder.end();
      if (tail && tail.length <= 4096) acceptStdoutLine(tail);
      settle(code, signal);
    });
  });
}

if (require.main === module) {
  const raw = process.env.TUNIQ_TEST_TIMEOUT_MS;
  const rawIdle = process.env.TUNIQ_TEST_IDLE_TIMEOUT_MS;
  const timeoutMs = raw === undefined ? DEFAULT_TIMEOUT_MS : Number(raw);
  const idleTimeoutMs = rawIdle === undefined ? DEFAULT_IDLE_TIMEOUT_MS : Number(rawIdle);
  runSuite(process.execPath, [path.join(__dirname, '..', 'tests', 'run-tests.js')], { timeoutMs, idleTimeoutMs })
    .then(result => { process.exitCode = result.ok ? 0 : 1; })
    .catch(error => { console.error(error); process.exitCode = 1; });
}
module.exports = { runSuite };
