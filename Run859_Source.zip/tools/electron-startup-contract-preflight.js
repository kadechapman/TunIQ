#!/usr/bin/env node
'use strict';
// Dependency-free, read-only source contract. NOT an Electron runtime test.
// Only checks literal IPC channels and local renderer startup assets.
const fs = require('node:fs');
const path = require('node:path');

const MAX_SOURCE_BYTES = 4 * 1024 * 1024;
function readSource(root, relative) {
  if (!/^[a-zA-Z0-9_.\/-]+$/.test(relative) || relative.startsWith('/') ||
      relative.split('/').some(part => !part || part === '.' || part === '..')) {
    throw new Error('unsafe-source-path');
  }
  let current = root;
  const parts = relative.split('/');
  for (let i = 0; i < parts.length; i++) {
    current = path.join(current, parts[i]);
    const stat = fs.lstatSync(current);
    if (stat.isSymbolicLink() || (i < parts.length - 1 ? !stat.isDirectory() :
        !stat.isFile() || stat.nlink !== 1 || stat.size > MAX_SOURCE_BYTES)) {
      throw new Error('unsafe-source-file');
    }
  }
  return fs.readFileSync(current, 'utf8');
}
function occurrences(source, regex) {
  return [...source.matchAll(regex)].map(match => match[1]);
}
function duplicates(items) {
  const seen = new Set();
  const repeated = new Set();
  for (const item of items) { if (seen.has(item)) repeated.add(item); else seen.add(item); }
  return [...repeated].sort();
}
// Defense in depth: a real Chromium/Electron CSP for the local document.
// Exact, early placement avoids a stale or weakened policy passing source audit.
// Keep script-src limited to local scripts; do not authorize inline/eval/remote code.
const REQUIRED_RENDERER_CSP = "script-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'; form-action 'none'";
function hasRequiredRendererCsp(html) {
  const literal = `<meta http-equiv="Content-Security-Policy" content="${REQUIRED_RENDERER_CSP}">`;
  const metas = [...html.matchAll(/<meta\b[^>]*\bhttp-equiv\s*=\s*['"]?content-security-policy\b[^>]*>/gi)];
  const at = html.indexOf(literal);
  const head = html.search(/<head\b[^>]*>/i);
  const body = html.search(/<body\b[^>]*>/i);
  const script = html.search(/<script\b/i);
  return metas.length === 1 && at >= 0 && head >= 0 && at > head &&
    (body < 0 || at < body) && (script < 0 || at < script);
}
// Fail closed on active HTML not represented by the audited local startup assets.
// This is deliberately a narrow source policy, not a general-purpose HTML parser.
function hasUnsafeActiveRendererHtml(html) {
  if (/<(?:iframe|frame|frameset|object|embed|base)\b/i.test(html) ||
      /<meta\b[^>]*\bhttp-equiv\s*=\s*['"]?refresh\b/i.test(html) ||
      /<[a-z][^>]*\s+on[a-z]+\s*=/i.test(html) ||
      /<form\b[^>]*\s+action\s*=/i.test(html)) return true;
  const scripts = [...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)];
  if (scripts.length !== [...html.matchAll(/<script\b/gi)].length) return true;
  const allowed = new Set(['engine-catalog.js', 'app.js']);
  const seen = new Set();
  for (const [, attrs, body] of scripts) {
    const src = /^\s+src\s*=\s*['"]([^'"]+)['"]\s*$/.exec(attrs);
    if (!src || !allowed.has(src[1]) || seen.has(src[1]) || body.trim()) return true;
    seen.add(src[1]);
  }
  if (seen.size !== allowed.size) return true;
  const links = [...html.matchAll(/<link\b([^>]*)>/gi)];
  if (links.length !== 1 ||
      !/^\s+rel\s*=\s*['"]stylesheet['"]\s+href\s*=\s*['"]styles\.css['"]\s*\/?\s*$/i.test(links[0][1])) {
    return true;
  }
  return false;
}
function inspectElectronStartupContract(root = path.resolve(__dirname, '..')) {
  const blockers = [];
  const add = code => { if (!blockers.includes(code)) blockers.push(code); };
  const files = {};
  for (const name of ['package.json', 'src/main.js', 'src/preload.js',
    'src/renderer/index.html', 'src/renderer/app.js']) {
    try { files[name] = readSource(root, name); }
    catch { add(`missing-or-unsafe:${name}`); }
  }
  let pkg;
  try { pkg = JSON.parse(files['package.json']); }
  catch { add('invalid-package-json'); }
  if (pkg && (pkg.main !== 'src/main.js' || !pkg.scripts || pkg.scripts.start !== 'electron .')) {
    add('unexpected-electron-entrypoint');
  }
  const main = files['src/main.js'] || '';
  const preload = files['src/preload.js'] || '';
  const renderer = files['src/renderer/app.js'] || '';
  const html = files['src/renderer/index.html'] || '';
  const registered = occurrences(main, /\bipcMain\.handle\(\s*['"]([^'"\r\n]+)['"]/g);
  const invoked = occurrences(preload, /\bipcRenderer\.invoke\(\s*['"]([^'"\r\n]+)['"]/g);
  const exposed = occurrences(preload, /\b([A-Za-z_$][\w$]*)\s*:\s*\([^)]*\)\s*=>/g);
  const used = occurrences(renderer, /\btuniq\.([A-Za-z_$][\w$]*)\b/g);
  if ((main.match(/\bipcMain\.handle\s*\(/g) || []).length !== registered.length ||
      (preload.match(/\bipcRenderer\.invoke\s*\(/g) || []).length !== invoked.length) {
    add('dynamic-or-unparseable-ipc-channel');
  }
  if (!registered.length || !invoked.length || !exposed.length || !used.length) add('missing-ipc-contract');
  if (duplicates(registered).length) add('duplicate-ipc-handler');
  if (duplicates(exposed).length) add('duplicate-preload-method');
  if (invoked.some(channel => !registered.includes(channel))) add('unhandled-preload-channel');
  if (used.some(method => !exposed.includes(method))) add('unexposed-renderer-method');
  if (!/\bcontextBridge\.exposeInMainWorld\(\s*['"]tuniq['"]/.test(preload)) add('missing-isolated-preload-bridge');
  if (!/\bcontextIsolation:\s*true\b/.test(main) ||
      !/\bnodeIntegration:\s*false\b/.test(main) ||
      !/\bsandbox:\s*true\b/.test(main)) add('missing-electron-window-isolation');
  if (!main.includes("preload: path.join(__dirname, 'preload.js')") ||
      !main.includes("mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))")) {
    add('unexpected-startup-resource-path');
  }
  const install = main.indexOf('attachRendererNavigationGuard(mainWindow.webContents)');
  const load = main.indexOf("mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))");
  if (install < 0 || load < 0 || install >= load) add('navigation-guard-not-installed-before-load');
  const resources = [...html.matchAll(/<(?:script|link)\b[^>]*\b(?:src|href)\s*=\s*['"]([^'"]+)['"][^>]*>/gi)]
    .map(match => match[1]);
  if (!resources.includes('app.js') || !resources.includes('engine-catalog.js') || !resources.includes('styles.css')) {
    add('missing-required-renderer-resource');
  }
  if (hasUnsafeActiveRendererHtml(html)) add('unsafe-active-renderer-html');
  if (!hasRequiredRendererCsp(html)) add('missing-or-weakened-renderer-csp');
  if (!resources.length) add('missing-renderer-resources');
  for (const resource of resources) {
    try { readSource(root, `src/renderer/${resource}`); }
    catch { add('unsafe-or-missing-renderer-resource'); }
  }
  return { schemaVersion: 1, auditKind: 'offline-electron-startup-contract',
    startupContractSafe: blockers.length === 0, blockers,
    registeredHandlers: registered.length, invokedChannels: invoked.length,
    exposedMethods: exposed.length, usedMethods: new Set(used).size,
    rendererResources: resources.length, electronRuntimeVerified: false,
    windowsBuildVerified: false, physicalHardwareVerified: false,
    note: 'Literal-source contract only. Does not execute Electron, verify runtime IPC registration, install dependencies, access COM ports, or authorize ECU writes.' };
}
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length > 2 || args.some(arg => arg.startsWith('--') && !['--report', '--require-safe'].includes(arg)) ||
      (args.includes('--report') && args.includes('--require-safe'))) {
    console.error('Usage: node tools/electron-startup-contract-preflight.js [project-folder] [--report|--require-safe]');
    process.exitCode = 1;
  } else {
    const root = args.find(arg => !arg.startsWith('--')) || path.resolve(__dirname, '..');
    const result = inspectElectronStartupContract(root);
    console.log(JSON.stringify(result, null, 2));
    if (!args.includes('--report') && !result.startupContractSafe) process.exitCode = 2;
  }
}
module.exports = { inspectElectronStartupContract };
