// Standalone Win64 GUI launcher for a SINGLE embedded hardware-free HTML preview.
// NOT Electron. No COM, OBD, ECU read/write/flash, or production main process.
typedef unsigned long DWORD;
typedef void *HANDLE;
typedef const unsigned short *LPCWSTR;
__declspec(dllimport) DWORD __stdcall GetTempPathW(DWORD,unsigned short*);
__declspec(dllimport) unsigned int __stdcall GetDriveTypeW(LPCWSTR);
__declspec(dllimport) unsigned int __stdcall GetTempFileNameW(LPCWSTR,LPCWSTR,unsigned int,unsigned short*);
__declspec(dllimport) int __stdcall MoveFileW(LPCWSTR,LPCWSTR);
__declspec(dllimport) HANDLE __stdcall CreateFileW(LPCWSTR,DWORD,DWORD,void*,DWORD,DWORD,HANDLE);
__declspec(dllimport) int __stdcall WriteFile(HANDLE,const void*,DWORD,DWORD*,void*);
__declspec(dllimport) int __stdcall GetFileInformationByHandle(HANDLE,void*);
__declspec(dllimport) DWORD __stdcall GetFileType(HANDLE);
__declspec(dllimport) int __stdcall CloseHandle(HANDLE);
__declspec(dllimport) int __stdcall DeleteFileW(LPCWSTR);
__declspec(dllimport) void __stdcall ExitProcess(unsigned int);
__declspec(dllimport) void* __stdcall ShellExecuteW(void*,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,int);
__declspec(dllimport) int __stdcall MessageBoxW(void*,LPCWSTR,LPCWSTR,unsigned int);
#include "embedded_preview.h"
#include "windows-standalone-temp-path.h"
#include "windows-standalone-file-guard.h"
static unsigned short temp_dir[32768], tmp_file[32768], html_file[32768];
static const unsigned short prefix[]=L"TQI";
static const unsigned short open_verb[]=L"open";
static const unsigned short title[]=L"TunIQ offline UI preview (NO ECU)";
static const unsigned short failed[]=L"Could not open the offline UI preview. This is NOT the Electron application.";
static unsigned short lower_ascii(unsigned short c) { return (c>='A' && c<='Z') ? c+32 : c; }
static void fail(unsigned int code) { MessageBoxW(0,failed,title,0x10); ExitProcess(code); }
void mainCRTStartup(void) {
  DWORD n=GetTempPathW(32768,temp_dir);
  if(!n || n>=32768 || !tuniq_local_temp_path(temp_dir,n)) fail(2);
  // Reject mapped network drives even when TEMP has a drive-letter path.
  // DRIVE_FIXED is 3; this is not a reparse-point or runtime proof.
  unsigned short drive_root[]={temp_dir[0],':','\\',0};
  if(GetDriveTypeW(drive_root)!=3) fail(2);
  if(!GetTempFileNameW(temp_dir,prefix,0,tmp_file)) fail(3);
  unsigned int i=0;
  while(tmp_file[i] && i<32760) { html_file[i]=tmp_file[i]; i++; }
  if(i<4 || i>=32760) fail(4);
  // GetTempFileNameW creates a unique *.tmp file. Rename it to *.html
  // without replacing any existing file; keep the original on failure.
  if(html_file[i-4]!='.' || lower_ascii(html_file[i-3])!='t' || lower_ascii(html_file[i-2])!='m' || lower_ascii(html_file[i-1])!='p') fail(5);
  html_file[i-3]='h'; html_file[i-2]='t'; html_file[i-1]='m'; html_file[i]='l'; html_file[i+1]=0;
  if(!MoveFileW(tmp_file,html_file)) fail(6);
  // OPEN_REPARSE_POINT ensures a final-component symlink is opened as the
  // link itself, not followed to an unrelated file. Require the newly
  // generated file to be regular, unlinked, and still zero length before
  // writing the embedded HTML. This does not prove parent directories are
  // free of junctions or that the browser will reopen the same file later.
  HANDLE h=CreateFileW(html_file,0x40000000UL,0,0,3,0x00200080UL,0);
  if(h==(HANDLE)-1) fail(7);
  tuniq_win_file_info info;
  if(!GetFileInformationByHandle(h,&info) || GetFileType(h)!=1 ||
     !tuniq_preview_fresh_regular_file(&info)) {
    CloseHandle(h);
    DeleteFileW(html_file);
    fail(7);
  }
  DWORD written=0;
  int ok=WriteFile(h,embedded_preview_html,(DWORD)sizeof(embedded_preview_html),&written,0);
  int closed=CloseHandle(h);
  if(!ok || !closed || written!=(DWORD)sizeof(embedded_preview_html)) { DeleteFileW(html_file); fail(8); }
  void *r=ShellExecuteW(0,open_verb,html_file,0,0,1);
  if((unsigned long long)r<=32ULL) { DeleteFileW(html_file); fail(9); }
  // Keep temporary HTML while the browser is using it. Windows may delete it
  // later via normal temporary-file cleanup. No permanent user files are changed.
  ExitProcess(0);
}
