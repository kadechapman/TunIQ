#ifndef TUNIQ_STANDALONE_FILE_GUARD_H
#define TUNIQ_STANDALONE_FILE_GUARD_H
/* Win32 BY_HANDLE_FILE_INFORMATION layout, using fixed-width Win32 types.
 * Portable host tests cover this predicate, not native Windows behavior.
 * The caller opens the final component with FILE_FLAG_OPEN_REPARSE_POINT.
 */
typedef struct tuniq_win_file_info {
  unsigned long dwFileAttributes;
  unsigned long ftCreationTimeLow, ftCreationTimeHigh;
  unsigned long ftLastAccessTimeLow, ftLastAccessTimeHigh;
  unsigned long ftLastWriteTimeLow, ftLastWriteTimeHigh;
  unsigned long dwVolumeSerialNumber;
  unsigned long nFileSizeHigh, nFileSizeLow;
  unsigned long nNumberOfLinks;
  unsigned long nFileIndexHigh, nFileIndexLow;
} tuniq_win_file_info;
#if defined(_WIN64)
typedef char tuniq_win_file_info_size_must_be_52[(sizeof(tuniq_win_file_info) == 52) ? 1 : -1];
#endif
/* Win32 unsigned long is 32-bit; Linux unsigned long may be 64-bit. The
 * predicate is architecture-independent; the struct is used as a Win32 ABI
 * only in the cross-compiled x64 launcher. */
static int tuniq_preview_fresh_regular_file(const tuniq_win_file_info *info) {
  if (!info) return 0;
  /* FILE_ATTRIBUTE_DIRECTORY=0x10, FILE_ATTRIBUTE_REPARSE_POINT=0x400.
   * A newly generated GetTempFileNameW file should have one link and no
   * existing content. Never overwrite a swapped-in directory, link or file.
   */
  return !(info->dwFileAttributes & (0x10UL | 0x400UL)) &&
    info->nNumberOfLinks == 1 && !info->nFileSizeHigh && !info->nFileSizeLow;
}
#endif
