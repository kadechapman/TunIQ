#!/usr/bin/env node
'use strict';
// Offline metadata-only dependency preflight. Does not install, build, or access ECUs.
const fs = require('node:fs');
const path = require('node:path');

const MAX_LOCK_BYTES = 8 * 1024 * 1024;
// Conservative relative-path budget for node_modules on Windows. This does
// not guarantee checkout success: the absolute project path also matters.
const MAX_WINDOWS_LOCK_PATH_UNITS = 240;
const PINNED_VERSION = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/;

// This project uses public npm registry tarballs. A passing metadata preflight
// must not silently accept local paths, linked packages, or unchecked transitives.
function validIntegrity(value) {
  if (typeof value !== 'string') return false;
  const match = /^(sha512|sha384|sha256)-([A-Za-z0-9+/]+={0,2})$/.exec(value);
  if (!match) return false;
  const bytes = Buffer.from(match[2], 'base64');
  const lengths = { sha512: 64, sha384: 48, sha256: 32 };
  return bytes.length === lengths[match[1]] && bytes.toString('base64') === match[2];
}

// A lockfile can be syntactically valid on Linux but unusable on Windows:
// reserved DOS device names, forbidden characters and trailing periods/spaces
// alias or fail on NTFS. This is conservative metadata preflight, not npm ci.
function validWindowsPackagePath(key) {
  // A syntactically valid chain of nested packages can exceed Windows'
  // default MAX_PATH even though each component is legal. Fail closed before
  // claiming that the lock graph is Windows-layout safe. Node's JS string
  // length counts UTF-16 code units, matching Windows path accounting.
  if (key.length > MAX_WINDOWS_LOCK_PATH_UNITS) return false;
  return key.split('/').every(component => component.length > 0 &&
    component.length <= 255 && !/[<>:\"\\|?*\x00-\x1f\x7f]/.test(component) &&
    !/[. ]$/.test(component) &&
    // CONIN$ and CONOUT$ are also reserved Windows device names.
    !/^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i.test(component));
}

function validPackagePath(key) {
  if (typeof key !== 'string' || key.includes('\\') || key.includes('\0')) return false;
  const parts = key.split('/');
  for (let i = 0; i < parts.length;) {
    if (parts[i++] !== 'node_modules') return false;
    const name = parts[i++];
    if (!name || name === '.' || name === '..') return false;
    if (name.startsWith('@')) {
      const scopedName = parts[i++];
      // Even an unreferenced transitive entry must be a legal registry
      // package name. Windows-valid spaces/percent escapes are not npm
      // package names; accepting them falsely certified the lock graph.
      if (!scopedName || !validDependencyName(`${name}/${scopedName}`)) return false;
    } else if (!validDependencyName(name)) {
      return false;
    }
  }
  return true;
}

// Resolve using Node/npm's nearest installed package rule. Return the
// actual locked entry so exact transitive dependency pins can be checked;
// mere presence previously admitted parent@1 requiring child@2 while only
// child@1 was locked. Semver ranges still require npm ci to validate.
function findLockedTarget(packages, from, name) {
  let base = from;
  for (;;) {
    const key = `${base ? `${base}/` : ''}node_modules/${name}`;
    if (Object.prototype.hasOwnProperty.call(packages, key)) return packages[key];
    if (!base) return undefined;
    const ancestor = base.lastIndexOf('/node_modules/');
    base = ancestor === -1 ? '' : base.slice(0, ancestor);
  }
}

// Peer dependencies must be installed alongside (or above) the package
// declaring them, never inside that package's own node_modules. Normal
// dependency lookup includes the latter and can incorrectly certify a peer
// that npm cannot use as a peer. This is still metadata triage, not npm ci.
function findLockedPeerTarget(packages, from, name) {
  if (!from) return findLockedTarget(packages, '', name);
  const ancestor = from.lastIndexOf('/node_modules/');
  const parent = ancestor === -1 ? '' : from.slice(0, ancestor);
  return findLockedTarget(packages, parent, name);
}

function validDependencyName(name) {
  if (typeof name !== 'string' || !/^(?:@[A-Za-z0-9._~-]+\/)?[A-Za-z0-9._~-]+$/.test(name)) return false;
  return name.split('/').every(part => part !== '.' && part !== '..');
}

// Only admit syntactically recognizable npm semver ranges. The old broad
// character whitelist accepted arbitrary dist-tags containing digits, e.g.
// `latest2` or `tag2026`, and reported them as registry-semver metadata.
// This intentionally does NOT prove range satisfaction: npm ci must do that.
const SEMVER_PART = String.raw`(?:0|[1-9]\d*|[xX*])`;
const SEMVER_CORE = String.raw`${SEMVER_PART}(?:\.${SEMVER_PART}){0,2}`;
const SEMVER_SUFFIX = String.raw`(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?`;
const SEMVER_ATOM = new RegExp(`^(?:[~^]|<=?|>=?|=)?${SEMVER_CORE}${SEMVER_SUFFIX}$`);
const SEMVER_HYPHEN_END = new RegExp(`^${SEMVER_CORE}${SEMVER_SUFFIX}$`);
function validDependencySpec(spec) {
  if (typeof spec !== 'string' || !spec.length || spec.length > 256 ||
      /[^0-9A-Za-z.*+~^<>=| -]/.test(spec)) return false;
  return spec.split('||').every(group => {
    const text = group.trim();
    if (!text || text.includes('|')) return false;
    // Hyphen ranges require spaces around the dash in npm semver syntax.
    const hyphen = text.split(/\s+-\s+/);
    if (hyphen.length === 2) return hyphen.every(part => SEMVER_HYPHEN_END.test(part.trim()));
    if (hyphen.length > 2) return false;
    return text.split(/\s+/).every(atom => SEMVER_ATOM.test(atom));
  });
}

// An approved registry hostname is not enough: a lockfile can point a
// seemingly pinned package at a different package/version's tarball on the
// same registry. Require the ordinary npm tarball route to match the package
// key and pinned version. This is metadata validation, not registry trust or
// proof that the tarball's contents are authentic.
function validRegistryResolution(value, packageKey, version) {
  if (value === undefined) return true; // npm may omit resolved URLs.
  if (typeof value !== 'string' || typeof packageKey !== 'string' ||
      typeof version !== 'string' || !PINNED_VERSION.test(version)) return false;
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' || url.hostname !== 'registry.npmjs.org' ||
        url.port || url.username || url.password || url.hash || url.search) return false;
    const packageName = packageKey.slice(packageKey.lastIndexOf('node_modules/') + 'node_modules/'.length);
    const basename = packageName.startsWith('@') ? packageName.split('/')[1] : packageName;
    if (!basename || !validDependencyName(packageName)) return false;
    // Decode the path for canonical comparison; npm may encode a scoped
    // package's slash as %2f or leave it as a literal slash.
    const expected = `/${packageName}/-/${basename}-${version}.tgz`;
    return decodeURIComponent(url.pathname) === expected;
  } catch { return false; }
}

function inspectRegularJson(file, maxBytes) {
  let stat;
  try { stat = fs.lstatSync(file); }
  catch (error) {
    if (error.code === 'ENOENT') return { error: 'missing' };
    return { error: 'unreadable' };
  }
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) return { error: 'unsafe-file' };
  if (!Number.isSafeInteger(stat.size) || stat.size > maxBytes) return { error: 'oversized-file' };
  let fd;
  try {
    fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.dev !== stat.dev || opened.ino !== stat.ino ||
        opened.size !== stat.size || opened.nlink !== 1) return { error: 'changed-file' };
    const bytes = Buffer.alloc(stat.size);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, null);
      if (!count) return { error: 'truncated-file' };
      offset += count;
    }
    if (fs.readSync(fd, Buffer.alloc(1), 0, 1, null)) return { error: 'grown-file' };
    const after = fs.fstatSync(fd);
    const current = fs.lstatSync(file);
    for (const check of [after, current]) {
      if (!check.isFile() || check.nlink !== 1 || check.dev !== stat.dev ||
          check.ino !== stat.ino || check.size !== stat.size ||
          check.mtimeMs !== stat.mtimeMs || check.ctimeMs !== stat.ctimeMs) {
        return { error: 'changed-file' };
      }
    }
    try { return { data: JSON.parse(bytes.toString('utf8')) }; }
    catch { return { error: 'invalid-json' }; }
  } catch { return { error: 'unreadable' }; }
  finally { if (fd !== undefined) fs.closeSync(fd); }
}

function inspectWindowsDependencyLock(appPath = path.resolve(__dirname, '..')) {
  const blockers = [];
  const add = reason => { if (!blockers.includes(reason)) blockers.push(reason); };
  const pkgResult = inspectRegularJson(path.join(appPath, 'package.json'), 1024 * 1024);
  const pkg = pkgResult.data;
  if (pkgResult.error) add(`package-json-${pkgResult.error}`);
  if (!pkgResult.error && (!pkg || typeof pkg !== 'object' || Array.isArray(pkg))) add('package-json-invalid-shape');
  const shrinkwrap = path.join(appPath, 'npm-shrinkwrap.json');
  if (fs.existsSync(shrinkwrap) || fs.lstatSync(shrinkwrap, { throwIfNoEntry: false })) add('shrinkwrap-takes-precedence');
  const lockResult = inspectRegularJson(path.join(appPath, 'package-lock.json'), MAX_LOCK_BYTES);
  const lock = lockResult.data;
  if (lockResult.error) add(`lockfile-${lockResult.error}`);
  if (!lockResult.error && (!lock || typeof lock !== 'object' || Array.isArray(lock) || ![2, 3].includes(lock.lockfileVersion) ||
      !lock.packages || typeof lock.packages !== 'object' || Array.isArray(lock.packages))) {
    add('lockfile-invalid-structure');
  }
  if (lock && !blockers.some(x => x.startsWith('lockfile-'))) {
    const windowsPathPrefixes = new Map();
    for (const [key, entry] of Object.entries(lock.packages)) {
      if (key === '') continue;
      if (!validPackagePath(key)) add('lockfile-invalid-package-path');
      if (!validWindowsPackagePath(key)) add('lockfile-invalid-windows-package-path');
      // NTFS generally treats names case-insensitively. Reject collisions
      // in ancestor directories too, not only identical full package paths.
      const components = key.split('/');
      for (let i = 1; i <= components.length; i++) {
        const prefix = components.slice(0, i).join('/');
        const folded = prefix.toLowerCase();
        const prior = windowsPathPrefixes.get(folded);
        if (prior !== undefined && prior !== prefix) add('lockfile-windows-case-collision');
        windowsPathPrefixes.set(folded, prefix);
      }
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
        add('lockfile-transitive-entry-invalid');
        continue;
      }
      if (entry.link === true) add('lockfile-linked-package');
      if (typeof entry.version !== 'string' || !PINNED_VERSION.test(entry.version)) {
        add('lockfile-transitive-version-invalid');
      }
      if (!validIntegrity(entry.integrity)) add('lockfile-transitive-integrity-invalid');
      if (!validRegistryResolution(entry.resolved, key, entry.version)) add('lockfile-unsafe-resolution');
    }
  }
  // A well-formed package entry can still point to an absent dependency.
  // Check required/optional edges for every installed package, including the
  // root's direct and development dependencies. Semver range satisfaction
  // and npm peer placement still require separate verification by npm ci.
  if (lock && !blockers.some(x => x.startsWith('lockfile-'))) {
    for (const [from, entry] of Object.entries(lock.packages)) {
      if (!entry || typeof entry !== 'object' || Array.isArray(entry)) continue;
      const sections = from === ''
        ? ['dependencies', 'devDependencies', 'optionalDependencies']
        : ['dependencies', 'optionalDependencies'];
      for (const section of sections) {
        const declared = entry[section];
        if (declared === undefined) continue;
        if (!declared || typeof declared !== 'object' || Array.isArray(declared)) {
          add('lockfile-dependency-map-invalid');
          continue;
        }
        for (const [name, spec] of Object.entries(declared)) {
          if (!validDependencyName(name)) {
            add('lockfile-dependency-name-invalid');
            continue;
          }
          if (!validDependencySpec(spec)) add('lockfile-dependency-spec-invalid');
          const target = findLockedTarget(lock.packages, from, name);
          if (target === undefined) add('lockfile-dependency-target-missing');
          // Exact pins need no semver solver. Reject mismatched locked versions
          // for required and optional edges, including nearest nested entries.
          // Ranges are deliberately NOT certified by this metadata-only audit.
          else if (PINNED_VERSION.test(spec) && target?.version !== spec) {
            add('lockfile-exact-dependency-version-mismatch');
          }
        }
      }
      // npm may reject a lockfile whose installed peer version conflicts with
      // an exact peer pin. Previously this was silently marked lockfileReady,
      // even though ordinary required/optional dependency edges were checked.
      // Optional peers may be absent only when peerDependenciesMeta marks them
      // optional. This is conservative metadata triage, NOT npm's peer solver.
      const peers = entry.peerDependencies;
      const meta = entry.peerDependenciesMeta;
      const validMap = value => value && typeof value === 'object' && !Array.isArray(value);
      if (meta !== undefined && !validMap(meta)) add('lockfile-peer-metadata-invalid');
      if (peers !== undefined && !validMap(peers)) add('lockfile-peer-dependency-map-invalid');
      if (validMap(meta)) {
        for (const [name, details] of Object.entries(meta)) {
          if (!validDependencyName(name) || !validMap(details) ||
              (details.optional !== undefined && typeof details.optional !== 'boolean') ||
              !validMap(peers) || !Object.prototype.hasOwnProperty.call(peers, name)) {
            add('lockfile-peer-metadata-invalid');
          }
        }
      }
      if (validMap(peers)) {
        for (const [name, spec] of Object.entries(peers)) {
          if (!validDependencyName(name)) { add('lockfile-peer-dependency-name-invalid'); continue; }
          if (!validDependencySpec(spec)) { add('lockfile-peer-dependency-spec-invalid'); continue; }
          const target = findLockedPeerTarget(lock.packages, from, name);
          const optional = validMap(meta) && meta[name]?.optional === true;
          if (target === undefined && !optional) add('lockfile-peer-dependency-target-missing');
          else if (target !== undefined && PINNED_VERSION.test(spec) && target?.version !== spec) {
            add('lockfile-exact-peer-version-mismatch');
          }
        }
      }
    }
  }
  if (pkg && !blockers.some(x => x.startsWith('package-json-')) &&
      lock && !lockResult.error && !blockers.includes('lockfile-invalid-structure')) {
    const root = lock.packages[''];
    if (!root || typeof root !== 'object' || root.name !== pkg.name || root.version !== pkg.version ||
        lock.name !== pkg.name || lock.version !== pkg.version) add('lockfile-root-mismatch');
    for (const section of ['dependencies', 'devDependencies', 'optionalDependencies']) {
      const declared = pkg[section] === undefined ? {} : pkg[section];
      const locked = root?.[section] === undefined ? {} : root[section];
      if (!declared || typeof declared !== 'object' || Array.isArray(declared) ||
          !locked || typeof locked !== 'object' || Array.isArray(locked)) { add(`lockfile-${section}-invalid`); continue; }
      const declaredNames = Object.keys(declared).sort();
      if (JSON.stringify(declaredNames) !== JSON.stringify(Object.keys(locked).sort())) {
        add(`lockfile-${section}-set-mismatch`);
      }
      for (const name of declaredNames) {
        const requested = declared[name];
        if (typeof requested !== 'string' || !PINNED_VERSION.test(requested)) add(`unpinned-${name}`);
        if (locked[name] !== requested) add(`lockfile-${name}-range-mismatch`);
        const resolved = lock.packages[`node_modules/${name}`];
        if (!resolved || resolved.version !== requested ||
            !validIntegrity(resolved.integrity)) {
          add(`lockfile-${name}-resolution-invalid`);
        }
      }
    }
  }
  return {
    schemaVersion: 1, auditKind: 'offline-dependency-metadata',
    lockfileReady: blockers.length === 0, blockers,
    windowsBuildVerified: false, nativeInstallVerified: false, physicalHardwareVerified: false,
    note: 'Passing validates local lock metadata, required/optional dependency targets, and exact peer/dependency pins. It does not prove registry authenticity, full peer dependency resolution, semver-range satisfaction, npm ci, Windows execution, or an installer.'
  };
}

if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length > 2 || args.some(arg => arg.startsWith('--') && !['--report', '--require-lock'].includes(arg)) ||
      (args.includes('--report') && args.includes('--require-lock'))) {
    console.error('Usage: node tools/windows-dependency-preflight.js [project-folder] [--report|--require-lock]');
    process.exitCode = 1;
  } else {
    const folder = args.find(arg => !arg.startsWith('--')) || path.resolve(__dirname, '..');
    const result = inspectWindowsDependencyLock(folder);
    console.log(JSON.stringify(result, null, 2));
    if (!args.includes('--report') && !result.lockfileReady) process.exitCode = 2;
  }
}
module.exports = { inspectWindowsDependencyLock, MAX_LOCK_BYTES };
