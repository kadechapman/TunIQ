#!/usr/bin/env node
'use strict';
// Offline, read-only: inspect the project Logs directory for partial imports.
const { auditPhoneLogImports } = require('../src/phone-log-import-audit');
if (require.main === module) {
  try {
    if (![3, 4].includes(process.argv.length) || process.argv[2].startsWith('--') ||
        (process.argv.length === 4 && process.argv[3] !== '--verify-contents')) {
      throw new Error('Usage: node tools/audit-phone-log-imports.js <project-folder> [--verify-contents]');
    }
    const result = auditPhoneLogImports(process.argv[2], { verifyContents: process.argv[3] === '--verify-contents' });
    console.log(JSON.stringify(result, null, 2));
    process.exitCode = result.status === 'clean' ? 0 : 2;
  } catch (error) {
    console.error(`Phone-log audit error: ${error.message}`);
    process.exitCode = 1;
  }
}
