#!/usr/bin/env node
'use strict';
// Independently hash EVERY delivered file in the hardware-isolated Windows UI
// preview. A valid EXE alone does not prove its resources were delivered intact.
// This is a file-integrity check, NOT proof of Windows execution or full TunIQ.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const MAX_FILES = 5000;
const MAX_DIRECTORIES = 1024;
const MAX_DEPTH = 32;
const MAX_TOTAL_BYTES = 1024 * 1024 * 1024;
const MAX_FILE_BYTES = 512 * 1024 * 1024;
const MAX_PROOF_BYTES = 1024 * 1024;
const KIND = 'tuniq-offline-preview-delivered-tree-integrity';
// Linux fixtures can contain names that Windows would alias, normalize or
// reject. Never certify a delivered Windows tree containing those entries.
function validateWindowsName(name) {
  if (!name || name === '.' || name === '..' || name.length > 255 ||
      /[<>:"/\\|?*\x00-\x1f\x7f]/.test(name) || /[. ]$/.test(name) ||
      /^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i.test(name)) {
    throw new Error('unsafe-windows-delivered-name');
  }
}
function safeRegularFile(file, limit) {
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 ||
      !Number.isSafeInteger(stat.size) || stat.size > limit) throw new Error('unsafe-delivered-file');
  return stat;
}
function hashFile(file, stat) {
  const fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.dev !== stat.dev || opened.ino !== stat.ino ||
        opened.nlink !== 1 || opened.size !== stat.size) throw new Error('delivered-file-changed');
    const hash = crypto.createHash('sha256');
    const buffer = Buffer.alloc(1024 * 1024);
    let offset = 0;
    while (offset < stat.size) {
      const n = fs.readSync(fd, buffer, 0, Math.min(buffer.length, stat.size - offset), offset);
      if (n <= 0) throw new Error('delivered-file-truncated');
      hash.update(buffer.subarray(0, n));
      offset += n;
    }
    const after = fs.fstatSync(fd);
    const current = fs.lstatSync(file);
    for (const value of [after, current]) {
      if (!value.isFile() || value.nlink !== 1 || value.dev !== stat.dev ||
          value.ino !== stat.ino || value.size !== stat.size ||
          value.mtimeMs !== stat.mtimeMs || value.ctimeMs !== stat.ctimeMs) {
        throw new Error('delivered-file-changed');
      }
    }
    return hash.digest('hex');
  } finally { fs.closeSync(fd); }
}
function inspectTree(directory) {
  const root = fs.lstatSync(directory);
  if (!root.isDirectory() || root.isSymbolicLink()) throw new Error('unsafe-delivered-root');
  const files = [];
  // Include directory entries (even empty ones) in the attested tree.
  // Otherwise a new unreviewed empty directory is invisible to verification.
  const directories = [];
  let totalBytes = 0;
  let directoryCount = 0;
  const walk = (dir, prefix, depth) => {
    // Empty directories do not count toward MAX_FILES. Bound both breadth and
    // recursion so malformed packaged trees cannot exhaust CI resources.
    if (depth > MAX_DEPTH) throw new Error('too-deep-delivered-tree');
    if (++directoryCount > MAX_DIRECTORIES) throw new Error('too-many-delivered-directories');
    const foldedNames = new Set();
    for (const name of fs.readdirSync(dir).sort()) {
      // Validate every component, including empty directories. Otherwise a
      // tree that works on Linux can alias or fail extraction on Windows.
      validateWindowsName(name);
      const foldedName = name.toLowerCase();
      if (foldedNames.has(foldedName)) throw new Error('delivered-path-case-collision');
      foldedNames.add(foldedName);
      const relative = prefix ? `${prefix}/${name}` : name;
      const absolute = path.join(dir, name);
      const stat = fs.lstatSync(absolute);
      if (stat.isSymbolicLink()) throw new Error('unsafe-delivered-link');
      if (stat.isDirectory()) {
        directories.push(relative);
        walk(absolute, relative, depth + 1);
        continue;
      }
      if (files.length >= MAX_FILES) throw new Error('too-many-delivered-files');
      // Avoid allocating unbounded buffers or hashing enormous trees.
      if (!stat.isFile() || stat.nlink !== 1 || !Number.isSafeInteger(stat.size) ||
          stat.size > MAX_FILE_BYTES || totalBytes + stat.size > MAX_TOTAL_BYTES) {
        throw new Error('unsafe-or-oversized-delivered-tree');
      }
      totalBytes += stat.size;
      files.push({ path: relative, sizeBytes: stat.size, sha256: hashFile(absolute, stat) });
    }
  };
  walk(directory, '', 0);
  if (!files.some(f => f.path === 'TunIQ Offline UI Preview.exe') ||
      !files.some(f => f.path === 'resources/app.asar')) {
    throw new Error('missing-delivered-executable-or-asar');
  }
  // A file set is only meaningful if paths are unambiguous on Windows.
  const folded = new Set();
  for (const file of files) {
    const key = file.path.toLowerCase();
    if (folded.has(key)) throw new Error('delivered-path-case-collision');
    folded.add(key);
  }
  files.sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  directories.sort();
  return { schemaVersion: 1, kind: KIND, fileCount: files.length,
    directoryCount: directories.length, directories, totalBytes,
    files, previewOnly: true, fullTunIQVerified: false, hardwareUsed: false };
}
function writeEvidence(directory, destination) {
  const proof = inspectTree(directory);
  fs.writeFileSync(destination, JSON.stringify(proof, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  return proof;
}
function readBoundedEvidence(evidenceFile) {
  // Never validate the path and then reopen it by name for reading: a proof
  // swapped between lstat and readFileSync could certify the wrong bytes.
  const stat = safeRegularFile(evidenceFile, MAX_PROOF_BYTES);
  if (stat.size < 100) throw new Error('empty-delivered-tree-proof');
  const fd = fs.openSync(evidenceFile, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const sameFile = current => current.isFile() && !current.isSymbolicLink() &&
      current.nlink === 1 && current.dev === stat.dev && current.ino === stat.ino &&
      current.size === stat.size && current.mtimeMs === stat.mtimeMs &&
      current.ctimeMs === stat.ctimeMs;
    if (!sameFile(fs.fstatSync(fd))) throw new Error('delivered-proof-changed');
    const bytes = Buffer.alloc(stat.size); // capped at MAX_PROOF_BYTES
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, offset);
      if (count <= 0) throw new Error('delivered-proof-truncated');
      offset += count;
    }
    if (!sameFile(fs.fstatSync(fd)) || !sameFile(fs.lstatSync(evidenceFile))) {
      throw new Error('delivered-proof-changed');
    }
    return JSON.parse(bytes.toString('utf8'));
  } finally { fs.closeSync(fd); }
}
function verifyEvidence(directory, evidenceFile) {
  const recorded = readBoundedEvidence(evidenceFile);
  assert.deepStrictEqual(recorded, inspectTree(directory), 'delivered tree integrity mismatch');
  return true;
}
if (require.main === module) {
  try {
    const [mode, directory, evidenceFile, ...extra] = process.argv.slice(2);
    if (extra.length || !['--write', '--verify'].includes(mode) || !directory || !evidenceFile) {
      throw new Error('usage');
    }
    if (mode === '--write') writeEvidence(directory, evidenceFile);
    else verifyEvidence(directory, evidenceFile);
    console.log('Delivered Windows UI preview tree integrity verified (NOT runtime/full-app proof).');
  } catch {
    // Do not print paths or sensitive filenames from an untrusted tree.
    console.error('Delivered Windows UI preview tree integrity NOT VERIFIED.');
    process.exitCode = 2;
  }
}
module.exports = { inspectTree, writeEvidence, verifyEvidence, validateWindowsName };
