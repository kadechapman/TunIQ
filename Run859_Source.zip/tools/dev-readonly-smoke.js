#!/usr/bin/env node
'use strict';
// Offline source-only smoke gate. Never starts Electron or accesses ECU hardware.
const fs = require('node:fs');
const path = require('node:path');
const { inspectElectronStartupContract } = require('./electron-startup-contract-preflight');
const { inspectReadOnlyAdmission } = require('./dev-readonly-admission-preflight');
const { inspectWindowsDependencyLock } = require('./windows-dependency-preflight');

// Keep dependency readiness separate from source safety: missing/malformed
// dependencies block runtime testing, but must not suppress offline CI checks.
function summarizeDevReadonlySmoke({ version, contract, admission, missing, dependency, lockfilePresent }) {
  // Do not let a contradictory or incomplete upstream preflight report turn
  // an unsafe source into a passing smoke gate. Flags are independent proof
  // requirements, not merely annotations on optional blocker lists.
  const startupSafe = contract?.startupContractSafe === true;
  const admissionSafe = admission?.safe === true;
  const dependencyReady = dependency?.lockfileReady === true && lockfilePresent === true;
  const dependencyBlockers = Array.isArray(dependency?.blockers) &&
    dependency.blockers.every(reason => typeof reason === 'string' && reason.length > 0)
    ? [...new Set(dependency.blockers)] : ['invalid-dependency-report'];
  if (lockfilePresent !== true && !dependencyBlockers.includes('lockfile-missing')) {
    dependencyBlockers.push('lockfile-missing');
  }
  if (!dependencyReady && dependencyBlockers.length === 0) {
    dependencyBlockers.push('lockfile-not-ready');
  }
  const startupBlockers = Array.isArray(contract?.blockers) ? contract.blockers : ['invalid-startup-report'];
  const admissionBlockers = Array.isArray(admission?.blockers) ? admission.blockers : ['invalid-admission-report'];
  const missingBlockers = Array.isArray(missing) ? missing.map(p => `missing:${p}`) : ['invalid-required-files-report'];
  const blockers = [...startupBlockers, ...admissionBlockers, ...missingBlockers];
  if (!startupSafe && startupBlockers.length === 0) blockers.push('startup-contract-not-safe');
  if (!admissionSafe && admissionBlockers.length === 0) blockers.push('production-write-admission-not-safe');
  return {
    mode: 'offline-source-only', version,
    startupContractSafe: startupSafe,
    productionWriteAdmissionSafe: admissionSafe,
    missing,
    dependencyLockfilePresent: lockfilePresent,
    dependencyLockfileReady: dependencyReady && dependencyBlockers.length === 0,
    dependencyLockfileBlockers: dependencyBlockers,
    runnableBuildVerified: false,
    ecuCommunicationPerformed: false,
    blockers,
    readinessBlockers: [
      ...dependencyBlockers.map(reason => `dependency:${reason}`),
      'native-electron-startup-not-verified', 'windows-build-not-verified'
    ]
  };
}

function inspectDevReadonlySmoke(root = path.resolve(__dirname, '..')) {
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const required = ['src/main.js', 'src/preload.js', 'src/renderer/index.html',
    'src/renderer/app.js', 'src/renderer/styles.css'];
  return summarizeDevReadonlySmoke({
    version: pkg.version,
    contract: inspectElectronStartupContract(root),
    admission: inspectReadOnlyAdmission(root),
    missing: required.filter(p => !fs.existsSync(path.join(root, p))),
    dependency: inspectWindowsDependencyLock(root),
    lockfilePresent: fs.existsSync(path.join(root, 'package-lock.json'))
  });
}

if (require.main === module) {
  const result = inspectDevReadonlySmoke();
  console.log(JSON.stringify(result, null, 2));
  // Source safety failures stop this offline job. Dependency readiness is
  // reported but is enforced separately before any native install or build.
  if (result.blockers.length) process.exitCode = 1;
}
module.exports = { summarizeDevReadonlySmoke, inspectDevReadonlySmoke };
