#!/usr/bin/env bash
# Cross-compile a single-file Win64 browser-only demo with embedded HTML.
# NOT Electron. Native Windows execution is NOT verified by cross-compilation.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
out="${1:?usage: build-windows-standalone-preview.sh <empty-output-directory>}"
# Resolve existing parent symlinks BEFORE mkdir. Previously an in-checkout
# output path (including one reached via a symlink alias) was created first,
# then rejected, leaving an untracked directory in the reviewed source tree.
# This is a Linux cross-build helper; GNU realpath -m handles missing leaves.
out="$(realpath -m -- "$out")"
if [[ "$out" == "$root" || "$out" == "$root/"* ]]; then echo 'Refusing in-source output' >&2; exit 2; fi
if [[ -e "$out" || -L "$out" ]]; then
  if [[ ! -d "$out" || -n "$(ls -A "$out")" ]]; then
    echo 'Refusing nonempty or non-directory output' >&2; exit 2
  fi
fi
mkdir -p -- "$out"
out="$(cd "$out" && pwd -P)"
if [[ "$out" == "$root" || "$out" == "$root/"* ]]; then echo 'Refusing in-source output' >&2; exit 2; fi
if [ -n "$(ls -A "$out")" ]; then echo 'Refusing nonempty output directory' >&2; exit 2; fi
for tool in node clang lld-link file python3; do command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 2; }; done
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
# Execute the portable TEMP-path guard regression before building the launcher.
# This is a host C unit test, never a native Windows runtime assertion.
clang -std=c11 -Wall -Wextra -Werror -pedantic \
  "$root/tests/standalone-temp-path-simulations.c" -o "$work/temp-path-fixtures"
"$work/temp-path-fixtures" > "$work/temp-path-fixtures.log"
clang -std=c11 -Wall -Wextra -Werror -pedantic \
  "$root/tests/standalone-file-guard-simulations.c" -o "$work/file-guard-fixtures"
"$work/file-guard-fixtures" > "$work/file-guard-fixtures.log"
node "$root/tools/build-standalone-browser-preview.js" "$work/preview.html" > "$work/html-build.json"
node - "$work/preview.html" "$work/embedded_preview.h" <<'NODE'
const fs = require('fs');
const bytes = fs.readFileSync(process.argv[2]);
if (bytes.length > 2 * 1024 * 1024) throw Error('Unexpected oversized browser preview');
const chunks=[];
for(let i=0;i<bytes.length;i+=32) chunks.push('  '+[...bytes.subarray(i,i+32)].map(x=>'0x'+x.toString(16).padStart(2,'0')).join(',')+',');
fs.writeFileSync(process.argv[3], 'static const unsigned char embedded_preview_html[] = {\n'+chunks.join('\n')+'\n};\n');
NODE
lld-link /lib "/def:$root/tools/win-browser-imports/standalone-kernel32.def" /machine:x64 "/out:$work/kernel32.lib"
for lib in shell32 user32; do
  lld-link /lib "/def:$root/tools/win-browser-imports/$lib.def" /machine:x64 "/out:$work/$lib.lib"
done
clang -target x86_64-pc-windows-msvc -c "$root/tools/windows-standalone-browser-preview.c" \
  -I"$work" -o "$work/launcher.obj" -fno-stack-protector -fshort-wchar
lld-link /subsystem:windows /entry:mainCRTStartup /nodefaultlib /timestamp:0 \
  "/out:$work/TunIQ_Standalone_Offline_Preview.exe" "$work/launcher.obj" \
  "$work/kernel32.lib" "$work/shell32.lib" "$work/user32.lib"
file "$work/TunIQ_Standalone_Offline_Preview.exe" | grep -q 'PE32+ executable.*x86-64'
# Bind the exact embedded HTML bytes and every Win64 import to the reviewed
# hardware-free launcher allowlist before copying a distributable artifact.
node "$root/tools/verify-windows-standalone-embed.js" \
  "$work/TunIQ_Standalone_Offline_Preview.exe" "$work/preview.html" > "$work/static-verification.json"
cp "$work/static-verification.json" "$out/static-verification.json"
cp "$work/TunIQ_Standalone_Offline_Preview.exe" "$out/TunIQ_Standalone_Offline_Preview.exe"
cp "$work/preview.html" "$out/TunIQ_Offline_Preview.html"
cp "$work/html-build.json" "$out/html-build.json"
cp "$work/temp-path-fixtures.log" "$out/temp-path-fixtures.log"
cp "$work/file-guard-fixtures.log" "$out/file-guard-fixtures.log"
# Ship only a ZIP whose exact EXE, embedded HTML and reviewed static proof agree.
python3 "$root/tools/package-standalone-preview.py" create "$out" > "$out/package-verification.json"
python3 "$root/tools/package-standalone-preview.py" verify "$out" > "$out/package-roundtrip-verification.json"
echo 'Cross-compiled standalone Win64 browser preview. NOT Electron; native Windows execution NOT verified.'
