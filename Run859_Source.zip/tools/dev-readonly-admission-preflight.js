#!/usr/bin/env node
'use strict';
// Source-only fail-closed check of production write admission. Never starts Electron/ECU tools.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { FlashManager } = require('../src/flash');

// SHA-256 of the reviewed, complete `const flashManager = new FlashManager({...})`
// expression in src/main.js. A regex-based property scan cannot safely
// interpret arbitrary JavaScript (including inline spreads, quoted keys or
// accessors). Fail closed on ANY constructor edit until the exact new block
// is manually reviewed and this fingerprint deliberately updated.
const REVIEWED_FLASH_CONSTRUCTOR_SHA256 = 'd9f38fd9293b0bfa5a90f5407f3390f794a4b47968f0560fc40bcc8c783853c8';

function inspectReadOnlyAdmissionSources(main, flash) {
  const blockers = [];
  const add = code => { if (!blockers.includes(code)) blockers.push(code); };
  const constructor = main.match(/const\s+flashManager\s*=\s*new\s+FlashManager\s*\(\s*\{([\s\S]*?)\n\s*\}\s*\)/);
  // JavaScript object literals use the LAST occurrence of a duplicate key.
  // A single `readOnlyBeta: true` text match does not prove the option is true:
  // a later duplicate, computed key or object spread can silently override it.
  // This is a conservative source gate, not a JavaScript parser; reject
  // ambiguous options rather than treating them as evidence of read-only mode.
  const optionsBody = constructor?.[1] || '';
  const constructors = main.match(/const\s+flashManager\s*=\s*new\s+FlashManager\s*\(/g) || [];
  const constructorDigest = constructor && crypto.createHash('sha256')
    .update(constructor[0], 'utf8').digest('hex');
  if (constructors.length !== 1 || constructorDigest !== REVIEWED_FLASH_CONSTRUCTOR_SHA256) {
    add('production-flash-constructor-unreviewed');
  }
  const readonlyKeys = optionsBody.match(/\breadOnlyBeta\s*:/g) || [];
  const explicitFlag = /^  readOnlyBeta:\s*true,\s*$/m.test(optionsBody);
  // Indentation is not semantically meaningful in JavaScript. A deeper
  // indentation or tab must not bypass the conservative dynamic-option gate.
  // Reject all such constructs inside the captured options object, even if
  // nested, because this source-only check cannot prove their effect.
  const dynamicTopLevelOptions = /^[ \t]*(?:\.\.\.|\[|(?:get|set)\s+readOnlyBeta\s*\()/m.test(optionsBody);
  if (!constructor || !explicitFlag || readonlyKeys.length !== 1 || dynamicTopLevelOptions) {
    add('production-readonly-flag-missing');
  }
  if (!/this\.readOnlyBeta\s*=\s*options\.readOnlyBeta\s*===\s*true\s*\|\|\s*!\(options\.platform\s*===\s*'test'\s*&&\s*options\.allowSimulatedWrites\s*===\s*true\)/.test(flash)) {
    add('flash-manager-default-readonly-contract-changed');
  }
  if (!/this\.readOnlyBeta\s*&&\s*!\['readProperties',\s*'read'\]\.includes\(normalized\)/.test(flash) ||
      !/throw\s+new\s+FlashStopError\('read-only-beta-write-blocked'/.test(flash)) {
    add('flash-manager-write-denial-missing');
  }
  const flashStart = main.match(/ipcMain\.handle\('flash:start',\s*async\s*\([^)]*\)\s*=>\s*\{([\s\S]*?)\n\}\);/);
  if (!flashStart || !/flashManager\.assertReadOnlyBetaOperation\(operation\)/.test(flashStart[1]) ||
      flashStart[1].indexOf('flashManager.assertReadOnlyBetaOperation(operation)') > flashStart[1].indexOf('flashManager.start(operation, options)')) {
    add('flash-ipc-write-denial-missing');
  }
  const autoWrite = main.match(/ipcMain\.handle\('p01-auto:write',\s*async\s*\([^)]*\)\s*=>\s*\{([\s\S]*?)\n\}\);/);
  if (!autoWrite || !/flashManager\.assertReadOnlyBetaOperation\('writeCalibration'\)/.test(autoWrite[1]) ||
      autoWrite[1].indexOf("flashManager.assertReadOnlyBetaOperation('writeCalibration')") > autoWrite[1].indexOf("flashManager.start('writeCalibration'")) {
    add('p01-auto-ipc-write-denial-missing');
  }
  return { safe: blockers.length === 0, blockers };
}

function inspectReadOnlyAdmission(root = path.resolve(__dirname, '..')) {
  const sources = [];
  for (const file of ['src/main.js', 'src/flash.js']) {
    const full = path.join(root, file);
    const stat = fs.lstatSync(full);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > 4 * 1024 * 1024) {
      return { safe: false, blockers: [`unsafe-source:${file}`] };
    }
    sources.push(fs.readFileSync(full, 'utf8'));
  }
  const result = inspectReadOnlyAdmissionSources(...sources);
  // Runtime proof: production-shaped manager must deny write operations before any CLI/COM work.
  let manager;
  try {
    manager = new FlashManager({ dataRoot: () => path.join(root, '.no-hardware-test'), getActiveProject: () => null, getToolPath: () => null });
    if (!manager.readOnlyBeta) result.blockers.push('runtime-readonly-disabled');
    for (const operation of ['testWrite', 'writeCalibration', 'writeFull', 'recovery']) {
      try { manager.assertReadOnlyBetaOperation(operation); result.blockers.push(`runtime-write-accepted:${operation}`); }
      catch (error) { if (error.code !== 'read-only-beta-write-blocked') result.blockers.push(`unexpected-denial:${operation}`); }
    }
  } catch (error) { result.blockers.push('runtime-guard-check-failed'); }
  result.safe = result.blockers.length === 0;
  return result;
}
if (require.main === module) {
  try {
    const result = inspectReadOnlyAdmission();
    console.log(JSON.stringify({ mode: 'offline-source-and-in-memory', ...result, hardwareAccessed: false }, null, 2));
    if (!result.safe) process.exitCode = 2;
  } catch (error) {
    console.error(JSON.stringify({ safe: false, blockers: [`preflight-error:${error.code || error.message}`] }));
    process.exitCode = 2;
  }
}
module.exports = { inspectReadOnlyAdmissionSources, inspectReadOnlyAdmission };
