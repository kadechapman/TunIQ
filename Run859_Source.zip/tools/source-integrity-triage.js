#!/usr/bin/env node
'use strict';
// Read-only source discrepancy inventory. Never rewrites trust baselines.
const path = require('node:path');
const { inspectWindowsSourceLayout } = require('./windows-source-path-preflight');
// Reject Windows alternate streams, reserved names, and invisible path controls.
const deceptiveText = /[\x00-\x1f\x7f-\x9f\u200b-\u200f\u202a-\u202e\u2060\u2066-\u2069\ufeff]/;
function unsafeWindowsRelativePath(p) {
  return typeof p !== 'string' || !p.trim() || p.startsWith('/') ||
    p.includes('\\') || deceptiveText.test(p) || /^[A-Za-z]:/.test(p) ||
    p.split('/').some(segment => !segment || segment === '.' || segment === '..' ||
      segment.includes(':') || /[. ]$/.test(segment) ||
      /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(segment));
}

function triage(root = path.resolve(__dirname, '..'), inspect = inspectWindowsSourceLayout) {
  const inspected = inspect(root);
  const result = inspected && typeof inspected === 'object' && !Array.isArray(inspected)
    ? inspected : {};
  const mismatches = Array.isArray(result.contentMismatches) ? result.contentMismatches : [];
  const missing = Array.isArray(result.unsafeSourcePaths) ? result.unsafeSourcePaths : [];
  const groups = { code: [], tests: [], tooling: [], generatedEvidence: [], other: [] };
  const evidenceIssues = [];
  // The upstream status must be an explicit boolean, never an absent or truthy value.
  if (typeof result.windowsSourcePathsSafe !== 'boolean')
    evidenceIssues.push('invalid-audit-status');
  // A successful status is not sufficient evidence when the upstream audit is
  // incomplete. Keep triage fail-closed without modifying the trust baseline.
  if (!Array.isArray(result.contentMismatches))
    evidenceIssues.push('missing-content-mismatch-evidence');
  if (!Number.isSafeInteger(result.fileCount) || result.fileCount <= 0)
    evidenceIssues.push('invalid-manifest-file-count');
  if (!Array.isArray(result.blockers) ||
      result.blockers.some(x => typeof x !== 'string' || !x.trim() || x.length > 512 || deceptiveText.test(x)))
    evidenceIssues.push('invalid-audit-blockers');
  // A repeated blocker is not independent evidence of a separate failure.
  if (Array.isArray(result.blockers)) {
    const seenBlockers = new Set();
    for (const blocker of result.blockers) {
      if (typeof blocker !== 'string' || !blocker.trim()) continue;
      if (seenBlockers.has(blocker)) evidenceIssues.push('duplicate-audit-blocker');
      seenBlockers.add(blocker);
    }
  }
  if (!Array.isArray(result.issues) || !Array.isArray(result.unsafeSourcePaths))
    evidenceIssues.push('missing-audit-path-evidence');
  // Do not accept malformed issue records as complete audit evidence.
  if (Array.isArray(result.issues) &&
      result.issues.some(issue => typeof issue !== 'string' || !issue.trim() || issue.length > 512 || deceptiveText.test(issue)))
    evidenceIssues.push('invalid-audit-issue-entry');
  // Repeated issue records can conceal an incomplete or corrupted audit inventory.
  if (Array.isArray(result.issues)) {
    const seenIssues = new Set();
    for (const issue of result.issues) {
      if (typeof issue !== 'string' || !issue.trim()) continue;
      if (seenIssues.has(issue)) evidenceIssues.push('duplicate-audit-issue');
      seenIssues.add(issue);
    }
  }
  // A failure status without any recorded failure evidence cannot be audited.
  if (result.windowsSourcePathsSafe === false &&
      Array.isArray(result.blockers) && result.blockers.length === 0 &&
      Array.isArray(result.issues) && result.issues.length === 0 &&
      Array.isArray(result.unsafeSourcePaths) && result.unsafeSourcePaths.length === 0 &&
      Array.isArray(result.contentMismatches) && result.contentMismatches.length === 0)
    evidenceIssues.push('unexplained-audit-failure');
  if (result.windowsSourcePathsSafe === true &&
      (!Array.isArray(result.blockers) || result.blockers.length !== 0 ||
       !Array.isArray(result.issues) || result.issues.length !== 0 ||
       !Array.isArray(result.unsafeSourcePaths) || result.unsafeSourcePaths.length !== 0 ||
       result.contentMismatchCount !== 0))
    evidenceIssues.push('contradictory-audit-success');
  if (!Number.isSafeInteger(result.contentMismatchCount) || result.contentMismatchCount < 0 ||
      result.contentMismatchCount !== mismatches.length) evidenceIssues.push('mismatch-count-inconsistent');
  if (Number.isSafeInteger(result.fileCount) && mismatches.length > result.fileCount)
    evidenceIssues.push('mismatch-inventory-exceeds-manifest');
  // Unsafe-path evidence is itself untrusted: reject empty or duplicate entries.
  if (Array.isArray(result.unsafeSourcePaths)) {
    const seenUnsafe = new Set();
    for (const entry of result.unsafeSourcePaths) {
      if (typeof entry !== 'string' || !entry.trim()) {
        evidenceIssues.push('invalid-unsafe-path-entry');
      } else if (unsafeWindowsRelativePath(entry)) {
        evidenceIssues.push('invalid-unsafe-path-format');
      } else if (seenUnsafe.has(entry.toLowerCase())) {
        evidenceIssues.push('duplicate-unsafe-path-entry');
      } else {
        seenUnsafe.add(entry.toLowerCase());
      }
    }
  }
  // The manifest has a finite number of distinct paths. Unsafe entries and
  // content mismatches are disjoint classifications, so their combined count
  // cannot exceed the manifest inventory even when each count alone fits.
  if (Number.isSafeInteger(result.fileCount) && result.fileCount > 0 &&
      Array.isArray(result.unsafeSourcePaths) &&
      Array.isArray(result.contentMismatches) &&
      result.unsafeSourcePaths.length + result.contentMismatches.length > result.fileCount)
    evidenceIssues.push('combined-inventory-exceeds-manifest');
  const unsafePathKeys = new Set(missing.filter(x => typeof x === 'string').map(x => x.toLowerCase()));
  const seenMismatchPaths = new Set();
  for (const item of mismatches) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) {
      evidenceIssues.push('invalid-mismatch-entry');
      continue;
    }
    const p = item.path;
    if (unsafeWindowsRelativePath(p)) {
      evidenceIssues.push('invalid-mismatch-path');
      continue;
    }
    if (seenMismatchPaths.has(p.toLowerCase())) {
      evidenceIssues.push('duplicate-mismatch-path');
      continue;
    }
    seenMismatchPaths.add(p.toLowerCase());
    if (unsafePathKeys.has(p.toLowerCase())) {
      evidenceIssues.push('mismatch-path-also-unsafe');
      continue;
    }
    if (!/^[a-f0-9]{64}$/.test(item.expectedSha256) || !/^[a-f0-9]{64}$/.test(item.actualSha256) ||
        !Number.isSafeInteger(item.expectedSize) || item.expectedSize < 0 ||
        !Number.isSafeInteger(item.actualSize) || item.actualSize < 0) {
      evidenceIssues.push('invalid-mismatch-digest-or-size');
      continue;
    }
    if (item.expectedSha256 === item.actualSha256) {
      evidenceIssues.push('identical-digests-in-mismatch');
      continue;
    }
    const group = p.startsWith('src/') ? 'code' : p.startsWith('tests/') ? 'tests' :
      p.startsWith('tools/') ? 'tooling' : p.startsWith('test-results/') ? 'generatedEvidence' : 'other';
    groups[group].push({ path: p, expectedSha256: item.expectedSha256,
      actualSha256: item.actualSha256, expectedSize: item.expectedSize, actualSize: item.actualSize });
  }
  return { auditKind: 'read-only-source-integrity-triage', sourceOnly: true,
    manifestVerified: result.windowsSourcePathsSafe === true && evidenceIssues.length === 0,
    evidenceComplete: evidenceIssues.length === 0, evidenceIssues,
    mismatchCount: result.contentMismatchCount, missingOrUnsafePaths: missing,
    groups, blockers: result.blockers,
    note: 'No manifest repair, checksum attestation, Windows execution, or ECU access performed.' };
}
if (require.main === module) {
  const report = triage(process.argv[2] ? path.resolve(process.argv[2]) : undefined);
  console.log(JSON.stringify(report, null, 2));
  if (!report.manifestVerified) process.exitCode = 2;
}
module.exports = { triage };
