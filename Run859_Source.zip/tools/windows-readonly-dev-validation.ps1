# Run from a trusted PowerShell terminal on Windows with Node.js/npm installed.
# Validation ONLY. Never starts src/main.js, attaches an ECU, or packages an installer.
# The dependency candidate and working directory are separate from the verified source.
param([switch]$PrepareOnly)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Run-Step([string]$Label, [string]$Program, [string[]]$Arguments) {
  Write-Host "[TunIQ] $Label"
  & $Program @Arguments
  if ($LASTEXITCODE -ne 0) { throw "$Label failed (exit $LASTEXITCODE). No user-testing approval." }
}

if ($env:OS -ne 'Windows_NT') { throw 'This validation script requires Windows.' }
$source = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
if (!(Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Install Node.js 20+ before running this validation.' }
if (!(Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'npm.cmd is required.' }
$nodeMajor = [int]((& node.exe -p 'process.versions.node.split(".")[0]').Trim())
if ($nodeMajor -lt 20) { throw 'Node.js 20+ is required.' }

# The full test suite can update test-results fixtures. Run ALL checks in a
# disposable source copy so the reviewed source tree remains byte-for-byte
# unchanged, including when a test fails or a network request times out.
# Do not let a generated lockfile silently modify the reviewed source archive.
$work = Join-Path $env:TEMP ('TunIQ-readonly-validation-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $work -Force | Out-Null
$skip = @('.git', 'node_modules', 'dist', 'release', 'private-hardware-evidence', 'dev-build-output')
if (Get-ChildItem -LiteralPath $source -Force -Recurse -Attributes ReparsePoint -ErrorAction Stop | Select-Object -First 1) {
  throw 'Source contains a reparse point. Refusing unsafe validation copy.'
}
# Bind the disposable test and npm candidate to the reviewed source manifest,
# not merely to whatever package.json happens to exist after the test suite.
$reviewedManifestHash = (Get-FileHash -LiteralPath (Join-Path $source 'package.json') -Algorithm SHA256).Hash
foreach ($entry in Get-ChildItem -LiteralPath $source -Force) {
  if ($skip -contains $entry.Name) { continue }
  Copy-Item -LiteralPath $entry.FullName -Destination $work -Recurse -Force
}
$copiedManifestHash = (Get-FileHash -LiteralPath (Join-Path $work 'package.json') -Algorithm SHA256).Hash
if ($copiedManifestHash -ne $reviewedManifestHash) {
  throw 'Disposable source manifest differs from reviewed package.json. No validation approval.'
}
Write-Host "[TunIQ] Disposable validation copy: $work"
Push-Location $work
try {
  # Prove source safety before any network/package activity.
  Run-Step 'Source syntax and launch snapshot' 'npm.cmd' @('run', 'check')
  Run-Step 'Windows source integrity' 'npm.cmd' @('run', 'check:windows-source-paths')
  Run-Step 'Write-admission safety' 'npm.cmd' @('run', 'check:dev-readonly-admission')
  Run-Step 'Offline Electron startup contract' 'npm.cmd' @('run', 'check:electron-startup-contract')
  Run-Step 'Offline renderer and write safety regressions' 'npm.cmd' @('run', 'test:renderer-smoke-contract')
  Run-Step 'Offline read-only smoke checks' 'npm.cmd' @('run', 'test:dev-readonly-smoke')
  Run-Step 'Full offline simulated suite' 'npm.cmd' @('test')
  # The suite legitimately rewrites test-results/*.json fixtures, so the
  # full SOURCE_MANIFEST hash audit cannot be repeated after it. Instead,
  # recheck the source-only launch snapshot: its critical-source fingerprint
  # covers application code, tools, tests, policies, and package.json but
  # deliberately excludes generated test-results. Fail before npm resolution.
  Run-Step 'Post-suite critical-source snapshot' 'node.exe' @('tools/launch-snapshot.js', '--check')
}
finally { Pop-Location }

# The disposable suite is not authorized to change the reviewed original.
# Run these checks against $source, not $work: the latter legitimately has
# regenerated test-results, while the original must retain every reviewed
# source-manifest byte. The snapshot additionally catches newly added code.
# A package.json-only comparison would miss changes to other original files.
Run-Step 'Reviewed original source snapshot unchanged' 'node.exe' @(
  (Join-Path $source 'tools/launch-snapshot.js'), '--check')
Run-Step 'Reviewed original source manifest unchanged' 'node.exe' @(
  (Join-Path $source 'tools/windows-source-path-preflight.js'), $source, '--require-safe')

# A test script can rewrite package.json before lockfile generation. Hashing
# only around npm resolution would bless the already-mutated manifest. Also
# recheck the original in case it changed while the disposable suite ran.
$testedManifestHash = (Get-FileHash -LiteralPath (Join-Path $work 'package.json') -Algorithm SHA256).Hash
$sourceManifestHashAfterTests = (Get-FileHash -LiteralPath (Join-Path $source 'package.json') -Algorithm SHA256).Hash
if ($testedManifestHash -ne $reviewedManifestHash -or
    $sourceManifestHashAfterTests -ne $reviewedManifestHash) {
  throw 'Test suite or source drift changed reviewed package.json. No lockfile candidate or build approval.'
}

# Keep npm's own debug logs from lockfile resolution and npm ci even if
# either fails before native Electron can launch. Paths may contain personal
# information; review raw logs before sharing them.
$diagnostics = Join-Path $source ('dev-build-output\Readonly-Validation-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $diagnostics -Force -ErrorAction Stop | Out-Null
Write-Host "[TunIQ] npm and native renderer diagnostics: $diagnostics"
$npmLogArg = '--logs-dir=' + $diagnostics
Push-Location $work
try {
  # Bind the lockfile candidate to the exact reviewed dependency manifest.
  # npm's lockfile-only mode can rewrite package.json before provenance is
  # captured; capturing afterward would incorrectly bless that mutation.
  $manifestHashBefore = (Get-FileHash -LiteralPath 'package.json' -Algorithm SHA256).Hash
  if ($manifestHashBefore -ne $reviewedManifestHash) {
    throw 'Pre-resolution package.json differs from reviewed source. No candidate or build approval.'
  }
  if (!(Test-Path -LiteralPath 'package-lock.json' -PathType Leaf)) {
    # No lockfile fabrication: ask npm to resolve a genuine registry lock graph.
    # npm --save=false returns exit 0 while suppressing package-lock.json.
    # Explicitly enable both lock writing flags and bound registry retries.
    Run-Step 'Generate npm lockfile candidate (no lifecycle scripts)' 'npm.cmd' @(
      'install', '--package-lock-only', '--package-lock=true', '--save=true',
      '--ignore-scripts', '--no-audit', '--no-fund', '--fetch-retries=0', '--fetch-timeout=15000', $npmLogArg)
    if (!(Test-Path -LiteralPath 'package-lock.json' -PathType Leaf)) {
      throw 'npm succeeded without writing package-lock.json; refusing candidate approval.'
    }
  }
  $manifestHashAfter = (Get-FileHash -LiteralPath 'package.json' -Algorithm SHA256).Hash
  if ($manifestHashAfter -ne $manifestHashBefore) {
    throw 'package.json changed during npm lockfile resolution. No candidate or build approval.'
  }
  Run-Step 'Validate lockfile metadata' 'node.exe' @('tools/windows-dependency-preflight.js', '--require-lock')
  # Preserve each validated candidate beside its own npm logs. A shared
  # dev-build-output/package-lock.candidate.json could be overwritten by a
  # later attempt and incorrectly attributed to this validation run.
  $candidate = Join-Path $diagnostics 'package-lock.candidate.json'
  if (Test-Path -LiteralPath $candidate) {
    throw 'Refusing to overwrite a prior lockfile candidate in this diagnostic run.'
  }
  Copy-Item -LiteralPath 'package-lock.json' -Destination $candidate -ErrorAction Stop
  $provenance = Join-Path $diagnostics 'lockfile-provenance.json'
  Run-Step 'Capture candidate and package provenance' 'node.exe' @('tools/windows-lockfile-provenance.js', '--capture', $candidate, $provenance)
  Write-Host "[TunIQ] Lockfile candidate for review: $candidate"
  if ($PrepareOnly) {
    Write-Host '[TunIQ] Preparation complete. No dependency install, renderer launch, or app build was attempted.'
    exit 0
  }
  Run-Step 'Install exact dependency graph in disposable copy' 'npm.cmd' @(
    'ci', '--no-audit', '--no-fund', '--fetch-retries=0', '--fetch-timeout=30000', $npmLogArg)
  Run-Step 'Verify npm ci preserved dependency provenance' 'node.exe' @('tools/windows-lockfile-provenance.js', '--verify', $candidate, $provenance)
  # This entrypoint intentionally has NO ECU IPC handlers; never run npm start here.
  # A zero process exit alone is not native renderer evidence. Run the actual
  # installed Electron executable with a fresh nonce, a hard timeout, and
  # preserved stdout/stderr. The evidence must be generated by this process.
  $electron = Join-Path $work 'node_modules\electron\dist\electron.exe'
  if (!(Test-Path -LiteralPath $electron -PathType Leaf)) {
    throw 'Installed Electron executable is missing; no native renderer verification.'
  }
  $rendererScript = Join-Path $work 'tools\electron-renderer-runtime-smoke.js'
  $nonce = [guid]::NewGuid().ToString('N')
  $report = Join-Path $diagnostics 'renderer-runtime-evidence.json'
  $oldReport = $env:TUNIQ_RENDERER_SMOKE_REPORT
  $oldNonce = $env:TUNIQ_RENDERER_SMOKE_NONCE
  try {
    $env:TUNIQ_RENDERER_SMOKE_REPORT = $report
    $env:TUNIQ_RENDERER_SMOKE_NONCE = $nonce
    Write-Host '[TunIQ] Hardware-isolated renderer runtime smoke (native Electron; 45-second limit)'
    $rendererArgs = '"' + $rendererScript.Replace('"', '') + '"'
    $process = Start-Process -FilePath $electron -ArgumentList $rendererArgs `
      -WorkingDirectory $work -PassThru `
      -RedirectStandardOutput (Join-Path $diagnostics 'renderer-runtime.stdout.log') `
      -RedirectStandardError (Join-Path $diagnostics 'renderer-runtime.stderr.log')
    if (-not $process.WaitForExit(45000)) {
      Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
      throw 'Native renderer timed out after 45 seconds. Inspect renderer-runtime.stderr.log.'
    }
    if ($process.ExitCode -ne 0) {
      throw "Native renderer exited $($process.ExitCode). Inspect renderer-runtime.stderr.log."
    }
  } finally {
    $env:TUNIQ_RENDERER_SMOKE_REPORT = $oldReport
    $env:TUNIQ_RENDERER_SMOKE_NONCE = $oldNonce
  }
  if (!(Test-Path -LiteralPath $report -PathType Leaf)) {
    throw 'Native renderer exited without nonce-bound evidence; no startup approval.'
  }
  $proof = Get-Content -LiteralPath $report -Raw -ErrorAction Stop | ConvertFrom-Json
  if ($proof.kind -ne 'tuniq-isolated-renderer-runtime-smoke' -or
      $proof.schemaVersion -ne 1 -or $proof.nonce -ne $nonce -or
      $proof.passed -ne $true -or $proof.actualElectronRuntime -ne $true -or
      $proof.fullTunIQVerified -ne $false -or $proof.hardwareUsed -ne $false -or
      $proof.ecuWriteOrFlashPerformed -ne $false) {
    throw 'Native renderer evidence was stale, incomplete, or unsuccessful.'
  }
  Write-Host '[TunIQ] Nonce-bound native renderer proof passed. Full application startup and Windows installer remain UNVERIFIED.'
  Write-Host '[TunIQ] NOT READY FOR USER TESTING. NO ECU access or writes were performed.'
}
finally { Pop-Location }
