#!/usr/bin/env node
'use strict';
// Hardware-disconnected, dependency-free SINGLE HTML browser preview.
// This is not Electron, does not enable OBD/ECM functionality and is not a full app.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { makeFiles } = require('./stage-browser-preview');

function createStandalone() {
  const assets = new Map(makeFiles());
  let html = assets.get('src/renderer/index.html').toString('utf8');
  const css = assets.get('src/renderer/styles.css').toString('utf8');
  const scripts = [
    'src/renderer/browser-preview-bridge.js',
    'src/renderer/engine-catalog.js',
    'src/renderer/app.js'
  // HTML parsers normalize CRLF to LF inside inline script elements.
  // Hash the exact bytes the browser will execute, not the source line endings.
  ].map(name => assets.get(name).toString('utf8').replace(/\r\n?/g, '\n'));
  if (scripts.some(s => /<\/script\s*>/i.test(s)) || /<\/style\s*>/i.test(css)) {
    throw new Error('Unsafe HTML inline closing tag in asset');
  }
  const oldCsp = "script-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'; form-action 'none'";
  if (!html.includes(oldCsp)) throw new Error('Unexpected CSP template');
  const hashes = scripts.map(s => "'sha256-" + crypto.createHash('sha256').update(s).digest('base64') + "'");
  const csp = "default-src 'none'; script-src " + hashes.join(' ') +
    "; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; object-src 'none'; " +
    "base-uri 'none'; frame-src 'none'; form-action 'none'";
  html = html.replace(oldCsp, csp);
  const replacements = [
    ['<link rel="stylesheet" href="styles.css">', `<style>${css}</style>`],
    ['<script src="browser-preview-bridge.js"></script>', `<script>${scripts[0]}</script>`],
    ['<script src="engine-catalog.js"></script>', `<script>${scripts[1]}</script>`],
    ['<script src="app.js"></script>', `<script>${scripts[2]}</script>`]
  ];
  for (const [oldText, newText] of replacements) {
    if (html.split(oldText).length !== 2) throw new Error('Unexpected asset reference: ' + oldText);
    // Replacement callback preserves literal $ and $$ in JavaScript assets.
    html = html.replace(oldText, () => newText);
  }
  if (/<(?:script|link)\b[^>]*(?:src|href)=/i.test(html)) throw new Error('External script or stylesheet remains');
  if (!html.includes('ALL ECU OPERATIONS DISABLED')) throw new Error('Hardware warning missing');
  return Buffer.from(html, 'utf8');
}
// Refuse preview output inside the reviewed source checkout, including through
// existing symlink ancestors. Resolve the nearest existing ancestor so paths
// with not-yet-created directories are checked BEFORE mkdir mutates the tree.
// This is a local build-path guard, not an atomic defense against hostile
// concurrent directory replacement.
function canonicalDestination(destination) {
  let ancestor = destination;
  const missing = [];
  while (true) {
    try { fs.lstatSync(ancestor); break; }
    catch (error) {
      if (error.code !== 'ENOENT') throw error;
      const parent = path.dirname(ancestor);
      if (parent === ancestor) throw new Error('Cannot resolve preview destination');
      missing.unshift(path.basename(ancestor));
      ancestor = parent;
    }
  }
  return path.resolve(fs.realpathSync(ancestor), ...missing);
}
function rejectSourceDestination(destination) {
  const root = fs.realpathSync(path.resolve(__dirname, '..'));
  const resolved = canonicalDestination(destination);
  if (resolved === root || resolved.startsWith(root + path.sep)) {
    throw new Error('Refusing in-source standalone preview output');
  }
}
function writeStandalone(output) {
  if (!output || path.extname(output).toLowerCase() !== '.html') throw new Error('Expected output .html');
  const abs = path.resolve(output);
  rejectSourceDestination(abs);
  if (fs.existsSync(abs)) throw new Error('Refusing to overwrite existing standalone preview');
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  rejectSourceDestination(abs);
  const bytes = createStandalone();
  fs.writeFileSync(abs, bytes, { flag: 'wx', mode: 0o600 });
  return { path: abs, bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
    nativeWindowsTested: false, electronRuntimeTested: false, hardwareAvailable: false };
}
if (require.main === module) {
  try { console.log(JSON.stringify(writeStandalone(process.argv[2]))); }
  catch (error) { console.error(error.message); process.exitCode = 1; }
}
module.exports = { createStandalone, writeStandalone };
