#!/usr/bin/env node
'use strict';
// Independent, read-only review of the delivered, hardware-free Windows preview.
// The build script must first run on Windows; this does NOT start Electron or an ECU.
const fs = require('node:fs');
const path = require('node:path');
const { diagnose } = require('./diagnose-windows-preview');
const { verifyEvidence, inspectPe } = require('./windows-pe-integrity');
const { verifyEvidence: verifyTreeEvidence } = require('./windows-preview-tree-integrity');

// The outcome is the final build-success admission proof. Do not validate
// metadata and then reopen its pathname: another file can be substituted
// between lstat and readFileSync. Bind one bounded read to the same file
// descriptor, then recheck both the descriptor and pathname. This is an
// offline filesystem-integrity check, not a signature or race-free lease.
function readBuildOutcome(file) {
  const before = fs.lstatSync(file);
  const sameFile = stat => stat.isFile() && !stat.isSymbolicLink() &&
    stat.nlink === 1 && stat.dev === before.dev && stat.ino === before.ino &&
    stat.size === before.size && stat.mtimeMs === before.mtimeMs &&
    stat.ctimeMs === before.ctimeMs;
  if (!sameFile(before) || before.size < 2 || before.size > 4096) {
    throw new Error('mismatched-build-provenance');
  }
  const fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    if (!sameFile(fs.fstatSync(fd))) throw new Error('mismatched-build-provenance');
    const bytes = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, offset);
      if (count <= 0) throw new Error('mismatched-build-provenance');
      offset += count;
    }
    if (!sameFile(fs.fstatSync(fd)) || !sameFile(fs.lstatSync(file))) {
      throw new Error('mismatched-build-provenance');
    }
    // Windows PowerShell 5.1 emits a UTF-8 BOM for Set-Content -Encoding UTF8.
    return JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, ''));
  } finally { fs.closeSync(fd); }
}
function verifyBuildProvenance(diagnostics, executable) {
  // The diagnostic JSON and delivered executable must belong to the SAME
  // dev-build-output root and to the exact named run recorded at build time.
  // A valid EXE hash plus unrelated passing smoke reports is not proof that
  // this particular executable was launched by this particular build.
  const root = path.dirname(diagnostics);
  const exeRoot = path.dirname(path.dirname(executable));
  const rootStat = fs.lstatSync(root);
  if (path.basename(root) !== 'dev-build-output' || !rootStat.isDirectory() ||
      rootStat.isSymbolicLink() || fs.realpathSync(root) !== fs.realpathSync(exeRoot)) {
    throw new Error('mismatched-build-provenance');
  }
  const file = path.join(diagnostics, 'build-outcome.json');
  const outcome = readBuildOutcome(file);
  // The build-only CI path ends after tree integrity. The one-click
  // launcher ends after its native visible-window check; do not reject that
  // legitimate later step or accept it without a bound window proof.
  const buildOnly = outcome.lastStep === 'Record delivered preview tree integrity' &&
    outcome.interactiveLaunchRequested !== true &&
    outcome.interactiveLaunchWindowVisible !== true;
  let interactive = false;
  if (outcome.lastStep === 'Open verified offline UI preview interactively' &&
      outcome.interactiveLaunchRequested === true &&
      outcome.interactiveLaunchProcessAlive === true &&
      outcome.interactiveLaunchWindowVisible === true) {
    try {
      const proof = readBuildOutcome(path.join(diagnostics, 'interactive-window-evidence.json'));
      interactive = proof.schemaVersion === 1 &&
        proof.kind === 'tuniq-offline-preview-visible-window' &&
        /^[a-f0-9]{32}$/.test(proof.nonce || '') &&
        proof.diagnosticsRun === path.basename(diagnostics) &&
        proof.deliveredPreviewDirectory === path.basename(path.dirname(executable)) &&
        proof.probeMethod === 'user32-IsWindowVisible-and-exact-title' &&
        proof.passed === true && proof.actualWindowsWindowCheck === true &&
        proof.exactExpectedTitle === true && proof.visible === true &&
        proof.hardwareUsed === false && proof.fullTunIQVerified === false &&
        proof.deliveredExeSha256 === inspectPe(executable).sha256;
    } catch { interactive = false; }
  }
  if (outcome.kind !== 'tuniq-offline-preview-build-outcome' ||
      outcome.schemaVersion !== 1 || outcome.passed !== true ||
      !(buildOnly || interactive) || outcome.windowsRuntimeVerified !== true ||
      outcome.fullTunIQVerified !== false || outcome.hardwareUsed !== false ||
      outcome.diagnosticsRun !== path.basename(diagnostics) ||
      outcome.deliveredPreviewDirectory !== path.basename(path.dirname(executable))) {
    throw new Error('mismatched-build-provenance');
  }
}
// Keep the actual Windows-host gate on the production entry point. Offline
// fixtures may exercise the same filesystem checks, but must NEVER return a
// positive native-Windows verification claim merely by passing a platform flag.
function reviewEvidenceCore(diagnostics, executable) {
  if (path.basename(executable) !== 'TunIQ Offline UI Preview.exe' ||
      !/^Offline-UI-Preview-[a-f0-9]{32}$/.test(path.basename(path.dirname(executable)))) {
    throw new Error('unexpected-delivered-executable-location');
  }
  const diag = fs.lstatSync(diagnostics);
  const exeDir = fs.lstatSync(path.dirname(executable));
  if (!diag.isDirectory() || diag.isSymbolicLink() ||
      !exeDir.isDirectory() || exeDir.isSymbolicLink()) {
    throw new Error('unsafe-evidence-directory');
  }
  verifyBuildProvenance(diagnostics, executable);
  // Check package-to-delivery equality first so a modified resource is
  // diagnosed as an integrity mismatch, not a generic missing-smoke-proof.
  verifyTreeEvidence(path.dirname(executable), path.join(diagnostics, 'packaged-preview-tree-integrity.json'));
  const summary = diagnose(diagnostics);
  if (!summary.offlinePreviewEvidenceComplete ||
      summary.fullTunIQVerified !== false || summary.hardwareUsed !== false ||
      summary.readyForUserTesting !== false) {
    throw new Error('four-native-preview-proofs-not-verified');
  }
  // Re-hash the actual final delivered EXE, not a temporary staging image.
  verifyEvidence(executable, path.join(diagnostics, 'packaged-executable-integrity.json'));
  // Verify resources/app.asar, Electron DLLs, locales, and the entire delivered
  // tree. An unchanged EXE with a missing/tampered app.asar is NOT a build.
  verifyTreeEvidence(path.dirname(executable), path.join(diagnostics, 'delivered-preview-tree-integrity.json'));
  return Object.freeze({
    schemaVersion: 1, kind: 'tuniq-independent-windows-preview-review',
    passed: true, windowsHostConfirmed: true, fourDistinctStartupProofs: true,
    deliveredExecutableSha256Verified: true, deliveredTreeIntegrityVerified: true, packagedToDeliveredTreeMatchVerified: true, previewOnly: true,
    fullTunIQVerified: false, readyForUserTesting: false,
    hardwareUsed: false, ecuWriteOrFlashPerformed: false
  });
}


function reviewEvidence(diagnostics, executable) {
  if (process.platform !== 'win32') throw new Error('native-windows-host-required');
  return reviewEvidenceCore(diagnostics, executable);
}

// Test-only metadata path: the checks are exercised against synthetic PE and
// JSON fixtures. Never return passed:true or windowsHostConfirmed:true here.
function reviewEvidenceFixture(diagnostics, executable) {
  const checked = reviewEvidenceCore(diagnostics, executable);
  return Object.freeze({ ...checked, passed: false, windowsHostConfirmed: false,
    fourDistinctStartupProofs: false, deliveredExecutableSha256Verified: false,
    deliveredTreeIntegrityVerified: false, packagedToDeliveredTreeMatchVerified: false,
    fixtureOnly: true, fixtureEvidenceValidated: true });
}

if (require.main === module) {
  try {
    if (process.argv.length !== 4) throw new Error('usage: DIAGNOSTICS_DIR DELIVERED_EXE');
    process.stdout.write(JSON.stringify(reviewEvidence(path.resolve(process.argv[2]),
      path.resolve(process.argv[3])), null, 2) + '\n');
  } catch (error) {
    // Never echo raw filesystem paths, log lines, or user-provided error text.
    const known = /^(?:native-windows-host-required|unexpected-delivered-executable-location|unsafe-evidence-directory|mismatched-build-provenance|four-native-preview-proofs-not-verified)$/.test(error.message);
    console.error('Windows preview independent review FAILED: ' + (known ? error.message : 'invalid-or-mismatched-evidence'));
    process.exitCode = 2;
  }
}
module.exports = { reviewEvidence, reviewEvidenceFixture };
