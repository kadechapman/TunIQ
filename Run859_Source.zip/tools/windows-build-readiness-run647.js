'use strict';
// Read-only readiness assessment. Never creates a lockfile or permits ECM operations.
const fs = require('fs');
const path = require('path');
function assess(root) {
  const pkgPath = path.join(root, 'package.json');
  const lockPath = path.join(root, 'package-lock.json');
  const result = { schema: 1, sourceRoot: root, packagePresent: fs.existsSync(pkgPath), lockfilePresent: fs.existsSync(lockPath), lockfileValid: false, lockfilePackageMatch: false, nativeWindowsRuntimeVerified: false, ecmWriteAuthorized: false, blockers: [] };
  if (!result.packagePresent) { result.blockers.push('package-json-missing'); return result; }
  let pkg;
  try { pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8')); } catch { result.blockers.push('package-json-invalid'); return result; }
  // Reject invalid root identity before comparing lockfile metadata.
  if (typeof pkg.name !== 'string' || !pkg.name.trim() || typeof pkg.version !== 'string' || !pkg.version.trim()) {
    result.blockers.push('package-json-identity-invalid'); return result;
  }
  const groups = ['dependencies', 'devDependencies', 'optionalDependencies'];
  if (groups.some(group => pkg[group] !== undefined && (pkg[group] === null || typeof pkg[group] !== 'object' || Array.isArray(pkg[group])))) { result.blockers.push('package-json-dependency-groups-invalid'); return result; }
  // npm dependency specifications must be nonempty strings, not objects or booleans.
  // Reject malformed metadata before any candidate lockfile can be admitted.
  if (groups.some(group => Object.values(pkg[group] || {}).some(spec => typeof spec !== 'string' || !spec.trim()))) {
    result.blockers.push('package-json-dependency-specs-invalid'); return result;
  }
  // Reject names that cannot represent a direct npm package entry. In particular,
  // do not allow path separators, empty scoped segments, or prototype-like keys
  // to be interpreted as trustworthy node_modules lockfile paths.
  const validDependencyName = name =>
    /^(?:@[a-z0-9._~-]+\/[a-z0-9._~-]+|[a-z0-9._~-]+)$/.test(name) &&
    !['.', '..', '__proto__', 'constructor', 'prototype'].includes(name) &&
    !name.split('/').some(part => ['.', '..', '__proto__', 'constructor', 'prototype'].includes(part));
  const invalidDependencyNames = [...new Set(groups.flatMap(group => Object.keys(pkg[group] || {})))].filter(name => !validDependencyName(name));
  result.invalidDependencyNames = invalidDependencyNames;
  if (invalidDependencyNames.length) { result.blockers.push('package-json-dependency-names-invalid'); return result; }
  if (!result.lockfilePresent) { result.blockers.push('package-lock-missing'); return result; }
  try {
    const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
    result.lockfileValid = Number.isInteger(lock.lockfileVersion) && lock.lockfileVersion >= 2 && !!lock.packages && typeof lock.packages === 'object' && !Array.isArray(lock.packages) && !!lock.packages[''] && typeof lock.packages[''] === 'object' && !Array.isArray(lock.packages['']);
    result.lockfilePackageMatch = result.lockfileValid && lock.packages['']?.name === pkg.name && lock.packages['']?.version === pkg.version;
    // npm lockfiles may carry top-level package identity as well as packages[''].
    // Reject contradictory identity metadata rather than trusting only the root entry.
    const topIdentityMismatch = result.lockfileValid &&
      (Object.prototype.hasOwnProperty.call(lock, 'name') && lock.name !== pkg.name ||
       Object.prototype.hasOwnProperty.call(lock, 'version') && lock.version !== pkg.version);
    result.lockfileTopLevelIdentityMatch = result.lockfileValid && !topIdentityMismatch;
    if (topIdentityMismatch) result.blockers.push('package-lock-top-level-identity-mismatch');
    if (!result.lockfileValid) result.blockers.push('package-lock-invalid');
    else if (!result.lockfilePackageMatch) result.blockers.push('package-lock-root-mismatch');
    else {
      if (groups.some(group => lock.packages[''][group] !== undefined && (lock.packages[''][group] === null || typeof lock.packages[''][group] !== 'object' || Array.isArray(lock.packages[''][group])))) { result.blockers.push('package-lock-root-dependency-groups-invalid'); return result; }
      if (groups.some(group => Object.values(lock.packages[''][group] || {}).some(spec => typeof spec !== 'string' || !spec.trim()))) {
        result.blockers.push('package-lock-root-dependency-specs-invalid'); return result;
      }
      // Validate lockfile root declaration names independently of package.json.
      // A stale or injected name must not be accepted as trustworthy npm metadata.
      const invalidLockRootNames = [...new Set(groups.flatMap(group => Object.keys(lock.packages[''][group] || {})))].filter(name => !validDependencyName(name));
      result.invalidLockRootDependencyNames = invalidLockRootNames;
      if (invalidLockRootNames.length) { result.blockers.push('package-lock-root-dependency-names-invalid'); return result; }
      // A lockfile can disagree with itself even if package.json has no duplicate.
      // Detect conflicting root declarations independently before trusting npm ci readiness.
      const lockRootConflicts = [...new Set(groups.flatMap(group => Object.keys(lock.packages[''][group] || {})))].filter(name => {
        const specs = groups.filter(group => Object.prototype.hasOwnProperty.call(lock.packages[''][group] || {}, name)).map(group => lock.packages[''][group][name]);
        return new Set(specs).size > 1;
      });
      result.conflictingLockRootDependencySpecs = lockRootConflicts;
      if (lockRootConflicts.length) result.blockers.push('package-lock-root-dependency-group-conflict');
      const duplicateConflicts = [...new Set(groups.flatMap(group => Object.keys(pkg[group] || {})))].filter(name => {
        const specs = groups.filter(group => Object.prototype.hasOwnProperty.call(pkg[group] || {}, name)).map(group => pkg[group][name]);
        return new Set(specs).size > 1;
      });
      result.conflictingPackageDependencySpecs = duplicateConflicts;
      if (duplicateConflicts.length) result.blockers.push('package-json-dependency-group-conflict');
      const declared = { ...pkg.dependencies, ...pkg.devDependencies, ...pkg.optionalDependencies };
      const missing = Object.keys(declared).filter(name => !Object.prototype.hasOwnProperty.call(lock.packages, 'node_modules/' + name));
      if (missing.length) result.blockers.push('package-lock-dependency-entries-missing');
      // Presence alone is insufficient: null/array/primitive package entries are malformed.
      const malformedEntries = Object.keys(declared).filter(name => {
        const entry = lock.packages['node_modules/' + name];
        return entry !== undefined && (entry === null || typeof entry !== 'object' || Array.isArray(entry));
      });
      result.malformedDependencyEntries = malformedEntries;
      if (malformedEntries.length) result.blockers.push('package-lock-dependency-entries-invalid');
      // A present resolved version must be a nonblank string. Some npm link
      // entries legitimately omit version, so absence is not proof of corruption.
      const invalidResolvedVersions = Object.keys(declared).filter(name => {
        const entry = lock.packages['node_modules/' + name];
        return entry && typeof entry === 'object' && !Array.isArray(entry) &&
          Object.prototype.hasOwnProperty.call(entry, 'version') &&
          (typeof entry.version !== 'string' || !entry.version.trim());
      });
      result.invalidResolvedVersions = invalidResolvedVersions;
      if (invalidResolvedVersions.length) result.blockers.push('package-lock-resolved-versions-invalid');
      // A link entry changes how npm resolves a dependency. Reject malformed link
      // metadata rather than treating it as an ordinary installed package.
      const invalidLinkEntries = Object.keys(declared).filter(name => {
        const entry = lock.packages['node_modules/' + name];
        if (!entry || typeof entry !== 'object' || Array.isArray(entry)) return false;
        if (!Object.prototype.hasOwnProperty.call(entry, 'link')) return false;
        return typeof entry.link !== 'boolean' ||
          (entry.link === true && (typeof entry.resolved !== 'string' || !entry.resolved.trim() || entry.resolved !== entry.resolved.trim() ||
            // Absolute/drive/UNC targets or NUL bytes are not safe portable workspace links.
            path.isAbsolute(entry.resolved) || path.win32.isAbsolute(entry.resolved) ||
            // Windows drive-relative paths (C:folder) and URL schemes are not
            // portable filesystem-relative workspace links.
            /^[a-zA-Z]:/.test(entry.resolved) || /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(entry.resolved) ||
            (/[\x00-\x1f\x7f]/.test(entry.resolved)) ||
            // Query/fragment delimiters are URL semantics, not portable workspace paths.
            /[?#]/.test(entry.resolved) ||
            // Windows cannot address these filename characters, even when a
            // fixture was assessed on Linux. Reject ambiguous trailing dots/spaces.
            /[<>|"*:]/.test(entry.resolved) ||
            // Windows device names (including CONIN$/CONOUT$ and superscript ¹²³ COM/LPT aliases) are reserved even with extensions or mixed case.
            entry.resolved.split(/[\\/]/).some(segment => /^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i.test(segment)) ||
            entry.resolved.split(/[\\/]/).some(segment => (segment !== '..' && segment !== '.' && segment.endsWith('.')) || segment.endsWith(' ')) ||
            // Decode URL escapes before validating portable Windows path syntax.
            // Some consumers decode a link target before creating a junction;
            // reject paths whose decoded spelling would be unsafe or ambiguous.
            (() => {
              if (!/%[0-9a-f]{2}/i.test(entry.resolved)) return false;
              let decoded;
              try { decoded = decodeURIComponent(entry.resolved); }
              catch { return true; }
              // A second decoding pass could turn %252e%252e or %255c into traversal.
              // Reject nested escapes rather than guessing how consumers decode links.
              if (/%[0-9a-f]{2}/i.test(decoded)) return true;
              if (/[\x00-\x1f\x7f<>|"*:?#]/.test(decoded)) return true;
              if (path.isAbsolute(decoded) || path.win32.isAbsolute(decoded) || /^[a-zA-Z]:/.test(decoded)) return true;
              if (decoded.split(/[\\/]/).some(segment =>
                /^(?:con|prn|aux|nul|conin\$|conout\$|com[1-9¹²³]|lpt[1-9¹²³])(?:\.|$)/i.test(segment) ||
                (segment !== '..' && segment !== '.' && segment.endsWith('.')) || segment.endsWith(' '))) return true;
              // Decoded traversal or links into node_modules must obey the same
              // containment rules as their literal counterparts.
              const target = path.win32.resolve('C:\\tuniq\\node_modules', decoded);
              const project = path.win32.resolve('C:\\tuniq');
              const nodeRoot = path.win32.resolve(project, 'node_modules');
              const relative = path.win32.relative(project, target);
              const inNode = path.win32.relative(nodeRoot, target);
              return relative === '..' || relative.startsWith('..' + path.win32.sep) ||
                target.toLowerCase() === project.toLowerCase() ||
                (inNode !== '..' && !inNode.startsWith('..' + path.win32.sep) && !path.win32.isAbsolute(inNode));
            })() ||
            // A relative link must stay within the project root when resolved from node_modules.
            // Reject traversal to unrelated filesystem locations.
            (() => {
              const target = path.resolve(root, 'node_modules', entry.resolved);
              const relative = path.relative(root, target);
              // Also evaluate Windows separators on Linux CI: path.resolve on POSIX
              // treats backslashes as ordinary characters and misses traversal.
              const winTarget = path.win32.resolve('C:\\tuniq\\node_modules', entry.resolved);
              const winRelative = path.win32.relative('C:\\tuniq', winTarget);
              // A workspace link resolving to its own node_modules entry is a
              // dependency cycle, not a valid installable workspace target.
              const selfTarget = path.resolve(root, 'node_modules', name);
              const winSelfTarget = path.win32.resolve('C:\\tuniq\\node_modules', name);
              return relative === '..' || relative.startsWith('..' + path.sep) ||
                winRelative === '..' || winRelative.startsWith('..' + path.win32.sep) ||
                target === path.resolve(root, 'node_modules') ||
                winTarget.toLowerCase() === path.win32.resolve('C:\\tuniq\\node_modules').toLowerCase() ||
                target === selfTarget || winTarget.toLowerCase() === winSelfTarget.toLowerCase() ||
                // Linking a dependency to the application root creates a root/package cycle.
                target === path.resolve(root) || winTarget.toLowerCase() === path.win32.resolve('C:\\tuniq').toLowerCase() ||
                // Workspace links must not resolve anywhere inside node_modules:
                // linking one dependency into another installed dependency can
                // create install-order cycles and Windows junction ambiguity.
                (() => {
                  const nodeRoot = path.resolve(root, 'node_modules');
                  const winNodeRoot = path.win32.resolve('C:\\tuniq\\node_modules');
                  const nodeRelative = path.relative(nodeRoot, target);
                  const winNodeRelative = path.win32.relative(winNodeRoot, winTarget);
                  return (!entry.resolved.includes('\\') && nodeRelative !== '' && nodeRelative !== '..' && !nodeRelative.startsWith('..' + path.sep) && !path.isAbsolute(nodeRelative)) ||
                    (winNodeRelative !== '' && winNodeRelative !== '..' && !winNodeRelative.startsWith('..' + path.win32.sep) && !path.win32.isAbsolute(winNodeRelative));
                })() ||
                // Percent-encoded path separators/traversal are ambiguous across tools.
                /%(?:00|2e|2f|5c|3a|3f|23|7c|3c|3e|22|2a)/i.test(entry.resolved);
            })()));
      });
      result.invalidLinkEntries = invalidLinkEntries;
      if (invalidLinkEntries.length) result.blockers.push('package-lock-link-metadata-invalid');
      const mismatched = Object.entries(declared).filter(([name, spec]) => {
        const entry = lock.packages['node_modules/' + name];
        if (!entry) return false;
        // npm aliases and non-registry sources cannot be authenticated by this lightweight check.
        // Compare the root lockfile declaration, not resolved versions (which are semver outcomes).
        return lock.packages['']?.dependencies?.[name] !== undefined && lock.packages[''].dependencies[name] !== spec ||
          lock.packages['']?.devDependencies?.[name] !== undefined && lock.packages[''].devDependencies[name] !== spec ||
          lock.packages['']?.optionalDependencies?.[name] !== undefined && lock.packages[''].optionalDependencies[name] !== spec;
      }).map(([name]) => name);
      const rootHasDependencyDeclarations = ['dependencies', 'devDependencies', 'optionalDependencies'].some(group => Object.prototype.hasOwnProperty.call(lock.packages[''] || {}, group));
      result.rootDependencyDeclarationsAbsent = Object.keys(declared).length > 0 && !rootHasDependencyDeclarations;
      if (result.rootDependencyDeclarationsAbsent) result.blockers.push('package-lock-root-declarations-absent');
      // Stale root declarations can make a lockfile appear aligned while npm ci would reject it.
      const extraRootDeclarations = groups.flatMap(group => Object.keys(lock.packages[''][group] || {}).filter(name =>
        !Object.prototype.hasOwnProperty.call(pkg[group] || {}, name)
      ).map(name => `${group}:${name}`));
      result.extraRootDependencyDeclarations = extraRootDeclarations;
      if (extraRootDeclarations.length) result.blockers.push('package-lock-root-extra-dependency-declarations');
      const missingRootDeclarations = !rootHasDependencyDeclarations ? [] : Object.keys(declared).filter(name =>
        !['dependencies', 'devDependencies', 'optionalDependencies'].some(group =>
          Object.prototype.hasOwnProperty.call(lock.packages['']?.[group] || {}, name)));
      if (missingRootDeclarations.length) result.blockers.push('package-lock-root-dependency-declarations-missing');
      result.missingRootDependencyDeclarations = missingRootDeclarations;
      // A dependency listed under the wrong root group is not an equivalent lock declaration.
      const wrongGroup = groups.flatMap(group => Object.keys(pkg[group] || {}).filter(name =>
        !Object.prototype.hasOwnProperty.call(lock.packages['']?.[group] || {}, name) &&
        groups.some(other => other !== group && Object.prototype.hasOwnProperty.call(lock.packages['']?.[other] || {}, name))
      ).map(name => `${group}:${name}`));
      result.wrongGroupRootDeclarations = wrongGroup;
      if (wrongGroup.length) result.blockers.push('package-lock-root-dependency-group-mismatch');
      if (mismatched.length) result.blockers.push('package-lock-dependency-spec-mismatch');
      result.mismatchedDependencySpecs = mismatched;
      result.lockfileDependencyEntriesPresent = missing.length === 0;
      result.missingDependencyEntries = missing;
    }
  } catch { result.blockers.push('package-lock-invalid'); }
  return result;
}
if (require.main === module) {
  const result = assess(path.resolve(process.argv[2] || path.join(__dirname, '..')));
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exitCode = result.blockers.length ? 2 : 0;
}
module.exports = { assess };
