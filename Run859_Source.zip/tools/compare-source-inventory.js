#!/usr/bin/env node
'use strict';
// Offline diagnostic only. Never updates the reviewed launch snapshot.
const fs = require('fs');
const path = require('path');
const { criticalSourceFingerprint } = require('./launch-snapshot');
function compare(saved, current) {
  if (!saved || !Array.isArray(saved.inventory) || !current || !Array.isArray(current.inventory)) throw new Error('Both inventories must contain per-file entries; an aggregate digest is insufficient.');
  const index = (items) => {
    const map = new Map();
    const windowsNames = new Set();
    for (const item of items) {
      if (!item || typeof item.path !== 'string' || !item.path || item.path.includes('\\') || item.path.startsWith('/') || /[\x00-\x1f\x7f:*?"<>|]/.test(item.path) || item.path.split('/').some(part => !part || part === '.' || part === '..') || !/^[a-f0-9]{64}$/.test(item.sha256) || !Number.isSafeInteger(item.bytes) || item.bytes < 0 || map.has(item.path)) throw new Error('Malformed or duplicate inventory entry');
      // Windows treats names case-insensitively by default and strips trailing dots/spaces.
      const segments = item.path.split('/');
      if (segments.some(part => /[. ]$/.test(part) || /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(part))) throw new Error('Malformed Windows inventory path');
      // Windows commonly treats canonically equivalent Unicode names as the same path.
      const windowsName = item.path.normalize('NFC').toLowerCase();
      if (windowsNames.has(windowsName)) throw new Error('Duplicate Windows inventory path');
      windowsNames.add(windowsName);
      map.set(item.path, item);
    }
    // A path cannot be both a regular file and a parent directory.
    for (const name of windowsNames) {
      const segments = name.split('/');
      for (let i = 1; i < segments.length; i++) {
        if (windowsNames.has(segments.slice(0, i).join('/'))) throw new Error('File/directory collision in Windows inventory');
      }
    }
    return map;
  };
  const before = index(saved.inventory), after = index(current.inventory);
  // A case-only rename is unsafe on default case-insensitive Windows volumes.
  // Fail rather than presenting it as an ordinary add/remove pair.
  const oldCase = new Map([...before.keys()].map(name => [name.normalize('NFC').toLowerCase(), name]));
  for (const name of after.keys()) {
    const previous = oldCase.get(name.normalize('NFC').toLowerCase());
    if (previous !== undefined && previous !== name) throw new Error('Case-only rename across inventories is unsafe on Windows');
  }
  const added = [], removed = [], modified = [];
  for (const [name, item] of after) {
    if (!before.has(name)) added.push(name);
    else if (before.get(name).sha256 !== item.sha256 || before.get(name).bytes !== item.bytes) modified.push(name);
  }
  for (const name of before.keys()) if (!after.has(name)) removed.push(name);
  return { added: added.sort(), removed: removed.sort(), modified: modified.sort(), baselineCount: before.size, currentCount: after.size };
}
if (require.main === module) {
  try {
    if (process.argv.length !== 3) throw new Error('Usage: node tools/compare-source-inventory.js <reviewed-inventory.json>');
    const saved = JSON.parse(fs.readFileSync(path.resolve(process.argv[2]), 'utf8'));
    const current = criticalSourceFingerprint(path.resolve(__dirname, '..'), true);
    console.log(JSON.stringify(compare(saved, current), null, 2));
  } catch (error) { console.error(error.message); process.exitCode = 2; }
}
module.exports = { compare };
