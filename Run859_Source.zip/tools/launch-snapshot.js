#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { buildLaunchReadiness } = require('../src/launch-readiness');

// Bind the source-only launch snapshot to the actual executable code, CI
// policies, and regression tests. Previously, changing src/flash.js without
// changing the nine blocker flags left a stale snapshot incorrectly 'valid'.
// Generated logs/manifests and the snapshot itself are excluded to avoid a
// self-referential digest and non-deterministic test-result timestamps.
function criticalSourceFingerprint(appPath, includeInventory = false) {
  const files = [];
  const add = (relative, requireFile = false) => {
    const full = path.join(appPath, relative);
    // existsSync follows symlinks and returns false for dangling links. A
    // lifecycle script could add an unreviewed dangling link under src/ or
    // tools/ and leave the critical-source hash unchanged. Inspect the entry
    // itself, not its target, before deciding that an optional path is absent.
    const stat = fs.lstatSync(full, { throwIfNoEntry: false });
    if (!stat) {
      if (requireFile) throw new Error(`Source fingerprint missing required file: ${relative}`);
      return;
    }
    if (stat.isSymbolicLink()) throw new Error(`Source fingerprint rejects symlinks: ${relative}`);
    if (stat.isDirectory()) {
      // A required root file replaced by an empty directory previously
      // vanished from the digest, just like a newly created FIFO/socket.
      // Neither is an acceptable reviewed dependency/policy input.
      if (requireFile && !['src', 'tools', 'tests'].includes(relative)) throw new Error(`Source fingerprint expects a regular file: ${relative}`);
      const entries = fs.readdirSync(full).sort();
      if (entries.length === 0) {
        throw new Error(`Source fingerprint rejects empty directory: ${relative}`);
      }
      for (const entry of entries) add(path.posix.join(relative, entry));
    } else if (stat.isFile()) {
      if (['src', 'tools', 'tests'].includes(relative)) throw new Error(`Source fingerprint expects a directory: ${relative}`);
      files.push(relative);
    } else {
      throw new Error(`Source fingerprint rejects non-regular entry: ${relative}`);
    }
  };
  // Include evidence schemas, installer assets and repository privacy/issue
  // policies. Previously these could change without invalidating the source-
  // only launch snapshot, even though they affect evidence admission or the
  // Windows package. Keep generated manifests and test output excluded.
  const rootFiles = [
    'package.json', 'package-lock.json', 'npm-shrinkwrap.json',
    'VERSION.json', '.gitignore', '.npmrc'
  ];
  const requiredRoots = ['package.json', 'VERSION.json', 'src', 'tools', 'tests'];
  for (const root of [...rootFiles, 'src', 'web', 'tools', 'tests',
    'schemas', 'build', '.github/workflows', '.github/ISSUE_TEMPLATE']) {
    add(root, requiredRoots.includes(root));
  }
  // Release-critical policy and installer documents live at the project root.
  // Without these, changing the privacy terms, license guidance or Windows
  // installer scripts left the source-only snapshot marked current. Include
  // both existing and newly added root documents; avoid generated manifests
  // and the snapshot itself to prevent a circular fingerprint.
  for (const entry of fs.readdirSync(appPath).sort()) {
    // Root JSON can control release attestations and packaging policy. A
    // newly added or modified JSON policy must not leave an old launch
    // snapshot looking fresh. Exclude only generated/self-referential JSON
    // and files already fingerprinted explicitly above.
    const rootJson = /\.json$/i.test(entry) &&
      !['package.json', 'VERSION.json', 'SOURCE_MANIFEST.json',
        'LAUNCH_READINESS_CURRENT.json'].includes(entry);
    if (rootJson || /\.(?:md|bat|cmd|ps1|sh|ya?ml)$/i.test(entry) ||
        /^(?:LICENSE|NOTICE|COPYING)(?:\.[A-Za-z0-9_-]+)?$/i.test(entry)) add(entry, true);
  }
  files.sort();
  const digest = crypto.createHash('sha256');
  const inventory = [];
  for (const relative of files) {
    const bytes = fs.readFileSync(path.join(appPath, relative));
    const fileHash = crypto.createHash('sha256').update(bytes).digest('hex');
    digest.update(`${relative}\0${bytes.length}\0${fileHash}\n`, 'utf8');
    if (includeInventory) inventory.push({ path: relative, bytes: bytes.length, sha256: fileHash });
  }
  const result = { schemaVersion: 1, algorithm: 'sha256', fileCount: files.length, sha256: digest.digest('hex') };
  if (includeInventory) result.inventory = inventory;
  return result;
}

// This is a conservative SOURCE AUDIT, not a runtime or physical hardware certification.
// Runtime evidence remains private and is never bundled into public source archives.
function sourceAudit(appPath) {
  const report = buildLaunchReadiness({
    appPath,
    betaState: { preferences: {}, matrix: [{ kind: 'flashing', status: 'experimental', id: 'p01' }] },
    betaProgress: { overall: 54 },
    updateStatus: { configured: false, message: 'No production update feed verified by this source-only audit.' }
  });
  return {
    ...report,
    snapshotKind: 'source-only',
    criticalSource: criticalSourceFingerprint(appPath),
    physicalHardwareVerified: false,
    assumptions: 'Source-only audit with no private hardware evidence, live update feed, or runtime release attestations. Live Release Center may report different state.'
  };
}
function stable(report) {
  const { generatedAt, ...stableFields } = report || {};
  return stableFields;
}
function verifySnapshot(appPath) {
  const file = path.join(appPath, 'LAUNCH_READINESS_CURRENT.json');
  let existing;
  try { existing = JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch { return { valid: false, reason: 'Source launch-readiness snapshot is missing or unreadable.' }; }
  if (existing.snapshotKind !== 'source-only' || existing.physicalHardwareVerified !== false) {
    return { valid: false, reason: 'Source snapshot lacks explicit source-only, non-hardware provenance.' };
  }
  const expected = sourceAudit(appPath);
  if (JSON.stringify(stable(existing)) !== JSON.stringify(stable(expected))) {
    const changedFields = [...new Set([...Object.keys(stable(existing)), ...Object.keys(stable(expected))])].filter(key => JSON.stringify(stable(existing)[key]) !== JSON.stringify(stable(expected)[key]));
    return { valid: false, reason: `Stale or modified source launch snapshot: snapshot=${existing.version || 'missing'}, current=${expected.version}; differing fields: ${changedFields.join(', ')}. Review changes before running npm run release:snapshot.`, changedFields };
  }
  return { valid: true, reason: `Source-only launch snapshot matches ${expected.version} (${expected.blockers.length} blockers).` };
}
function writeSnapshot(appPath) {
  const report = sourceAudit(appPath);
  fs.writeFileSync(path.join(appPath, 'LAUNCH_READINESS_CURRENT.json'), JSON.stringify(report, null, 2) + '\n');
  return report;
}
if (require.main === module) {
  const appPath = path.resolve(__dirname, '..');
  if (process.argv.includes('--inventory')) {
    console.log(JSON.stringify(criticalSourceFingerprint(appPath, true), null, 2));
  } else if (process.argv.includes('--write')) {
    const report = writeSnapshot(appPath);
    console.log(`Source-only launch snapshot written for ${report.version}: ${report.blockers.length} blockers; physical hardware unverified.`);
  } else if (process.argv.includes('--check')) {
    const result = verifySnapshot(appPath);
    console.log(result.reason);
    if (!result.valid) process.exitCode = 1;
  } else {
    console.error('Usage: node tools/launch-snapshot.js --write|--check|--inventory');
    process.exitCode = 2;
  }
}
module.exports = { criticalSourceFingerprint, sourceAudit, verifySnapshot, writeSnapshot };
