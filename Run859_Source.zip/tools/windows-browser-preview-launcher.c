typedef unsigned long DWORD;
typedef void *HWND;
typedef const unsigned short *LPCWSTR;
__declspec(dllimport) DWORD __stdcall GetModuleFileNameW(void*, unsigned short*, DWORD);
__declspec(dllimport) DWORD __stdcall GetFileAttributesW(LPCWSTR);
__declspec(dllimport) void __stdcall ExitProcess(unsigned int);
__declspec(dllimport) void* __stdcall ShellExecuteW(HWND,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,int);
__declspec(dllimport) int __stdcall MessageBoxW(HWND,LPCWSTR,LPCWSTR,unsigned int);
static unsigned short path[32768];
static const unsigned short suffix[] = L"src\\renderer\\index.html";
static const unsigned short open_verb[] = L"open";
static const unsigned short title[] = L"TunIQ offline browser UI preview";
static const unsigned short missing[] = L"Preview HTML is missing. Keep this executable in the extracted preview folder.";
static const unsigned short failed[] = L"Could not open the offline browser preview. Try OPEN_PREVIEW.cmd instead.";
static unsigned int append(unsigned int pos, const unsigned short* s) {
  unsigned int i=0;
  while(s[i]) { if(pos+i>=32767) return 0; path[pos+i]=s[i];i++; }
  path[pos+i]=0;
  return 1;
}
void mainCRTStartup(void) {
  DWORD n=GetModuleFileNameW(0,path,32768);
  if(n==0 || n>=32767) ExitProcess(2);
  DWORD cut=n;
  while(cut>0 && path[cut-1] != '\\' && path[cut-1] != '/') cut--;
  if(!append(cut,suffix)) ExitProcess(3);
  DWORD attrs=GetFileAttributesW(path);
  if(attrs==0xffffffffUL || (attrs & (0x10UL | 0x400UL))) {MessageBoxW(0,missing,title,0x10);ExitProcess(4);}
  void *r=ShellExecuteW(0,open_verb,path,0,0,1);
  if((unsigned long long)r<=32ULL) {MessageBoxW(0,failed,title,0x10);ExitProcess(5);}
  ExitProcess(0);
}
