#!/usr/bin/env node
'use strict';
// Offline byte-for-byte verification of the disabled-hardware browser preview.
// This is not Windows Electron runtime or ECU evidence.
const fs = require('node:fs');
const crypto = require('node:crypto');
const { createStandalone } = require('./build-standalone-browser-preview');
function verify(file) {
  if (typeof file !== 'string' || !file) throw new Error('Preview file required');
  const stat = fs.lstatSync(file);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1) throw new Error('Unsafe preview file');
  const expected = createStandalone();
  if (stat.size !== expected.length) throw new Error('Preview size mismatch');
  const actual = fs.readFileSync(file);
  if (!crypto.timingSafeEqual(actual, expected)) throw new Error('Preview content mismatch');
  return { verified: true, sourceOnly: true, nativeWindowsElectronVerified: false,
    hardwareOperationsAvailable: false, bytes: actual.length,
    sha256: crypto.createHash('sha256').update(actual).digest('hex') };
}
if (require.main === module) {
  try { console.log(JSON.stringify(verify(process.argv[2]), null, 2)); }
  catch (error) { console.error('NOT VERIFIED:', error.message); process.exitCode = 2; }
}
module.exports = { verify };
