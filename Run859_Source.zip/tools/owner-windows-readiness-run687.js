'use strict';
// Source-only diagnostic; never launches Electron, reads an ECU, or authorizes writes.
const path = require('node:path');
const { assess } = require('./windows-build-readiness-run647');
const { reviewP01Request } = require('../src/p01-request-review');
function exitCodeFor(_report) {
  // This command only inspects source/fixtures. Even a caller-supplied report
  // claiming native runtime and ECU authorization cannot upgrade its scope.
  // A separate, independently evidenced native-runtime verifier is required.
  return 2;
}
function inspect(root, activeProject, request) {
  // A missing or unreadable source root must yield a blocked diagnostic rather
  // than an uncaught exception or a misleading clean Windows dependency report.
  let windows;
  let windowsReviewError = null;
  try {
    windows = assess(root);
  } catch (error) {
    windowsReviewError = String(error?.message || error);
    windows = { blockers: ['windows-source-inspection-failed'], packagePresent: false, lockfilePresent: false };
  }
  if (!windows || !Array.isArray(windows.blockers) ||
      windows.blockers.some(item => typeof item !== 'string' || !item.trim()) ||
      typeof windows.packagePresent !== 'boolean' ||
      typeof windows.lockfilePresent !== 'boolean') {
    windowsReviewError = windowsReviewError || 'Windows readiness assessment returned an invalid result';
    windows = { blockers: ['windows-source-inspection-invalid'], packagePresent: false, lockfilePresent: false };
  }
  // Assessment results must be internally consistent. A missing package or lockfile
  // cannot be reported with an empty blocker list, even if a future assessor
  // accidentally regresses. This diagnostic never upgrades source-only status.
  if ((!windows.packagePresent && !windows.blockers.includes('package-json-missing')) ||
      (!windows.lockfilePresent && !windows.blockers.includes('package-lock-missing') && windows.packagePresent)) {
    windowsReviewError = windowsReviewError || 'Windows dependency assessment omitted a required missing-file blocker';
    windows = { blockers: ['windows-dependency-assessment-inconsistent'], packagePresent: false, lockfilePresent: false };
  }
  // Unsupported or malformed controller input must produce a blocked diagnostic,
  // not terminate the source-only readiness command with an uncaught exception.
  let owner;
  let reviewError = null;
  try {
    owner = reviewP01Request({ activeProject, request });
  } catch (error) {
    reviewError = String(error?.message || error);
    owner = { ready: false, unresolvedRequests: [], missingSafetyFacts: [
      'Controller-specific request review unavailable: ' + reviewError
    ] };
  }
  // A malformed review result must fail closed just like a thrown review error.
  // Do not let missing arrays or non-boolean readiness fields crash the CLI.
  if (!owner || typeof owner.ready !== 'boolean' ||
      !Array.isArray(owner.unresolvedRequests) ||
      !Array.isArray(owner.missingSafetyFacts) ||
      owner.unresolvedRequests.some(item => !item || typeof item.type !== 'string' || !item.type.trim()) ||
      owner.missingSafetyFacts.some(item => typeof item !== 'string' || !item.trim()) ||
      (owner.ready && (owner.unresolvedRequests.length > 0 || owner.missingSafetyFacts.length > 0))) {
    reviewError = reviewError || 'Controller request review returned an invalid result';
    owner = { ready: false, unresolvedRequests: [], missingSafetyFacts: [reviewError] };
  }
  // Explicitly separate calibration requirements; request parsing is not proof
  // of a verified ECU, output circuit, temperature target, or cam card.
  const calibrationGates = {
    ownerControllerIdentityVerified: false,
    exactOsVatsDefinitionVerified: false,
    electricFanOutputEnablementVerified: false,
    electricFanTemperatureThresholdsVerified: false,
    physicalCamCardAndCalibrationVerified: false,
    knockSensorRemovalDiagnosedWithProtectionPreserved: false
  };
  // Machine-readable, independent evidence blockers. A successful parser review
  // must never be mistaken for evidence of native runtime or ECU calibration.
  const evidenceBlockers = [
    'native-windows-electron-runtime-not-verified',
    'owner-controller-identity-not-verified',
    'exact-os-vats-definition-not-verified',
    'electric-fan-output-enablement-not-verified',
    'electric-fan-temperature-thresholds-not-verified',
    'physical-cam-card-calibration-not-verified',
    'knock-protection-diagnostics-not-verified'
  ];
  return {
    schema: 1,
    kind: 'source-only-owner-windows-readiness', fixtureController: activeProject?.controller === 'P01' ? 'P01 (hypothetical parser fixture; not verified owner ECU)' : null,
    windows: { inspectionError: windowsReviewError, blockers: windows.blockers, packagePresent: windows.packagePresent,
      lockfilePresent: windows.lockfilePresent, nativeWindowsRuntimeVerified: false },
    owner: { requestReviewReady: owner.ready, controllerEvidence: 'No authenticated owner controller identification; input controller is unverified; P01 is a hypothetical parser fixture only', reviewError, calibrationGates, ready: false, unresolvedTypes: owner.unresolvedRequests.map(x => x.type),
      missingSafetyFacts: owner.missingSafetyFacts },
    evidenceBlockers,
    readyForUserTesting: false,
    readyForPublicRelease: false,
    ecmWriteAuthorized: false,
    limitations: ['No native Windows Electron execution', 'No physical ECU testing', 'No verified ECU OS or calibration definition']
  };
}
if (require.main === module) {
  const root = path.resolve(process.argv[2] || path.join(__dirname, '..'));
  const result = inspect(root, { id: 'source-only-owner', name: 'Owner LS-swapped 5.3', controller: 'P01', os: 'unknown' },
    'Review exact-OS VATS disable, enable electric fan outputs and set fan on/off thresholds, tune physical LSX Stage 2 cam, and diagnose removed knock sensors.');
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  process.exitCode = exitCodeFor(result);
}
module.exports = { inspect, exitCodeFor };
