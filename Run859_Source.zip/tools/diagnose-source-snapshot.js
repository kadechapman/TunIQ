#!/usr/bin/env node
'use strict';
// Read-only diagnostic: never regenerates or blesses a stale source baseline.
const fs = require('node:fs');
const path = require('node:path');
const { criticalSourceFingerprint, verifySnapshot } = require('./launch-snapshot');
function diagnose(appPath, options = {}) {
  let current;
  try { current = criticalSourceFingerprint(appPath, options.includeInventory === true); }
  catch (error) {
    return { status: 'unverifiable', reason: 'source-fingerprint-error', error: error.message,
      warning: 'Source fingerprint failure is not evidence of source integrity; do not regenerate the baseline.' };
  }
  // A malformed fingerprint must never be treated as proof of matching source.
  if (!current || typeof current !== 'object' || Array.isArray(current) ||
      typeof current.sha256 !== 'string' || !/^[a-f0-9]{64}$/.test(current.sha256) ||
      !Number.isSafeInteger(current.fileCount) || current.fileCount < 0) {
    return { status: 'unverifiable', reason: 'invalid-current-source-fingerprint',
      warning: 'Malformed source fingerprint cannot authenticate the source tree.' };
  }
  const snapshotPath = path.join(appPath, 'LAUNCH_READINESS_CURRENT.json');
  let dependencyInputs;
  try {
    dependencyInputs = ['package-lock.json', 'npm-shrinkwrap.json'].map(name => ({
      path: name, present: (() => {
        try {
          const stat = fs.lstatSync(path.join(appPath, name));
          if (!stat || typeof stat.isFile !== 'function' || !stat.isFile() || (typeof stat.isSymbolicLink === 'function' && stat.isSymbolicLink())) {
            throw new Error(`Dependency input ${name} is not a regular non-symlink file`);
          }
          if (!Number.isSafeInteger(stat.size) || stat.size <= 0) throw new Error(`Dependency input ${name} has an invalid or empty file size; it cannot be trusted as an npm lockfile`);
          return true;
        }
        catch (error) {
          if (error && error.code === 'ENOENT') return false;
          throw error; // EACCES/EIO/etc. must not be misreported as absence.
        }
      })()
    }));
  } catch (error) {
    return { status: 'unverifiable', reason: 'dependency-input-probe-error', current,
      error: String(error && error.message || error),
      warning: 'Dependency input inspection failed; absence or integrity of lockfiles cannot be inferred.' };
  }
  let recorded;
  try { recorded = JSON.parse(fs.readFileSync(snapshotPath, 'utf8')); }
  catch (error) {
    return { status: 'missing-or-invalid-snapshot', error: error.message, current, dependencyInputs,
      warning: 'Missing or invalid baseline is not source authentication. Do not regenerate without independent review.' };
  }
  // JSON primitives and arrays are not valid readiness snapshots.
  if (!recorded || typeof recorded !== 'object' || Array.isArray(recorded)) {
    return { status: 'unverifiable', reason: 'invalid-snapshot-document-shape', current, dependencyInputs,
      warning: 'A non-object readiness snapshot cannot authenticate source; do not regenerate the baseline.' };
  }
  const previous = recorded.criticalSource || null;
  let verification;
  try { verification = verifySnapshot(appPath); }
  catch (error) {
    return { status: 'unverifiable', reason: 'snapshot-verifier-error', error: error.message, recorded: previous, current, dependencyInputs, warning: 'Verifier failure is not evidence of source integrity.' };
  }
  // A malformed verifier response is not proof and must produce a diagnostic, not a crash.
  if (!verification || typeof verification !== 'object' || Array.isArray(verification)) {
    return { status: 'unverifiable', reason: 'invalid-snapshot-verifier-result', recorded: previous, current, dependencyInputs,
      warning: 'Invalid verifier response is not evidence of source integrity.' };
  }
  // An absent/non-boolean verdict is not a negative verification result: it is unusable evidence.
  if (typeof verification.valid !== 'boolean') {
    return { status: 'unverifiable', reason: 'invalid-snapshot-verifier-verdict', recorded: previous, current, dependencyInputs,
      warning: 'Verifier verdict must be a boolean; missing or malformed verdict cannot authenticate source.' };
  }
  // Verifier evidence must have predictable types; malformed metadata is not proof.
  if ((verification.reason != null && typeof verification.reason !== 'string') ||
      (verification.changedFields != null &&
       (!Array.isArray(verification.changedFields) ||
        !verification.changedFields.every(field => typeof field === 'string')))) {
    return { status: 'unverifiable', reason: 'invalid-snapshot-verifier-evidence',
      recorded: previous, current, dependencyInputs,
      warning: 'Malformed verifier evidence cannot authenticate source integrity.' };
  }
  // Contradictory verifier evidence cannot authenticate a snapshot.
  if (verification.valid === true && (verification.reason != null ||
      (Array.isArray(verification.changedFields) && verification.changedFields.length > 0))) {
    return { status: 'unverifiable', reason: 'contradictory-snapshot-verifier-result',
      recorded: previous, current, dependencyInputs,
      warning: 'Verifier reports success alongside mismatch evidence; source authentication is blocked.' };
  }
  const metadataValid = previous && previous.schemaVersion === 1 && previous.algorithm === 'sha256' &&
    /^[a-f0-9]{64}$/.test(previous.sha256 || '') &&
    Number.isSafeInteger(previous.fileCount) && previous.fileCount >= 0;
  const digestMatches = metadataValid && previous.sha256 === current.sha256 && previous.fileCount === current.fileCount;
  // A verifier success must not mask malformed or stale critical-source metadata.
  return {
    status: !metadataValid ? 'unverifiable' : (verification.valid === true && digestMatches ? 'matches' : 'mismatch'),
    reason: verification.reason,
    changedFields: verification.changedFields || [],
    sourceDigestStatus: metadataValid
      ? (previous.sha256 === current.sha256 && previous.fileCount === current.fileCount ? 'matches' : 'mismatch')
      : 'unverifiable',
    recorded: previous,
    current,
    dependencyInputs,
    digestMatches: metadataValid ? previous.sha256 === current.sha256 : null,
    fileCountMatches: metadataValid ? previous.fileCount === current.fileCount : null,
    fileCountDelta: metadataValid ? current.fileCount - previous.fileCount : null,
    missingFileAttribution: metadataValid && previous.fileCount !== current.fileCount
      ? 'unknown-without-recorded-path-inventory' : null,
    // The fingerprint includes optional npm lockfiles. A missing lockfile is a
    // candidate for a count mismatch only up to the number actually absent, never proof of which path changed.
    lockfileCountMismatchCandidate: metadataValid && previous.fileCount > current.fileCount &&
      previous.fileCount - current.fileCount <= dependencyInputs.filter(input => !input.present).length
      ? 'npm-lockfile-absent-candidate-not-attribution' : null,
    warning: 'Digest comparison is not source authentication. Do not regenerate a baseline without independent review.'
  };
}
if (require.main === module) {
  const result = diagnose(path.resolve(__dirname, '..'), { includeInventory: process.argv.includes('--inventory') });
  process.stdout.write(JSON.stringify(result, null, 2) + '\n');
  if (result.status !== 'matches') process.exitCode = 1;
}
module.exports = { diagnose };
