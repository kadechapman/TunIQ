#!/usr/bin/env bash
# Cross-compile a minimal, hardware-free Windows browser-preview launcher.
# This is NOT Electron. It never loads TunIQ production ECM modules.
set -euo pipefail
root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
out="${1:?usage: build-windows-browser-preview-launcher.sh <empty-output-directory>}"
# Refuse paths inside the reviewed source tree, including symlink aliases,
# before creating anything. A preview build must never mutate its input.
out="$(realpath -m -- "$out")"
if [[ "$out" == "$root" || "$out" == "$root/"* ]]; then
  echo 'Refusing in-source output' >&2; exit 2
fi
if [[ -e "$out" || -L "$out" ]]; then
  if [[ ! -d "$out" || -n "$(ls -A "$out")" ]]; then
    echo 'Refusing nonempty or non-directory output' >&2; exit 2
  fi
fi
mkdir -p -- "$out"
out="$(cd "$out" && pwd -P)"
if [[ "$out" == "$root" || "$out" == "$root/"* ]]; then
  echo 'Refusing in-source output' >&2; exit 2
fi
if [ -n "$(ls -A "$out")" ]; then echo 'Refusing nonempty output directory' >&2; exit 2; fi
for tool in clang lld-link file; do command -v "$tool" >/dev/null || { echo "Missing $tool" >&2; exit 2; }; done
work="$(mktemp -d)"
trap 'rm -rf "$work"' EXIT
for lib in kernel32 shell32 user32; do
  lld-link /lib "/def:$root/tools/win-browser-imports/$lib.def" /machine:x64 "/out:$work/$lib.lib"
done
clang -target x86_64-pc-windows-msvc -c "$root/tools/windows-browser-preview-launcher.c" \
  -o "$work/launcher.obj" -fno-stack-protector -fshort-wchar
lld-link /subsystem:windows /entry:mainCRTStartup /nodefaultlib /timestamp:0 \
  "/out:$work/TunIQ_Browser_Preview.exe" "$work/launcher.obj" \
  "$work/kernel32.lib" "$work/shell32.lib" "$work/user32.lib"
file "$work/TunIQ_Browser_Preview.exe" | grep -q 'PE32+ executable.*x86-64'
cp "$work/TunIQ_Browser_Preview.exe" "$out/TunIQ_Browser_Preview.exe"
echo "Built a Win64 browser-preview launcher; Windows execution and Electron runtime NOT verified."
