# Wave 1 scope
Wave 1 establishes the visible product foundation and navigation. Real OBD, accounts, storage, cloud services, and calibration writing are intentionally deferred.
