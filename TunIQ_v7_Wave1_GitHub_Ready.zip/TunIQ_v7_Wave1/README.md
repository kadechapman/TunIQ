# TunIQ v7 — Wave 1

GitHub Pages-ready front-end prototype.

## Included
Dashboard, Live Data, Garage, AI Coach, Virtual Dyno, Tune Studio, Settings, responsive mobile layout, simulated data, charts, transitions, and tachometer branding.

## Publish
1. Extract this ZIP.
2. Upload every file and folder inside `TunIQ_v7_Wave1` to the root of your GitHub repository.
3. Confirm `index.html` is visible on the repository's main page.
4. Go to Settings → Pages.
5. Choose Deploy from a branch → main → /(root) → Save.

For a repository named `TunIQ-v7`, the URL will normally be:
`https://YOUR-USERNAME.github.io/TunIQ-v7/`

## Limitation
This is a front-end prototype. It does not connect to an OBD adapter, save cloud data, create real accounts, flash an ECU, or modify a calibration.
