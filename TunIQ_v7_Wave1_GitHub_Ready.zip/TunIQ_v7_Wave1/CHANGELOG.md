# Changelog

## v7.0.0-wave1
- GitHub Pages-ready app shell
- Seven navigable product screens
- Responsive phone and desktop UI
- Animated splash, simulated live values, charts, and AI chat demo
- Clear safety boundary around real ECU operations
