# Changelog

## v7.2 Wave 2
- Added vehicle wizard and local persistence
- Added CSV log analysis
- Added guided mode
- Added optional secure AI backend
- Added readiness checks and calibration education
