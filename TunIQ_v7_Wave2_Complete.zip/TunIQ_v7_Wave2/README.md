# TunIQ v7 — Wave 2

Wave 2 adds real local functionality while keeping all vehicle operations safe and simulated.

## New in Wave 2

- Beginner-friendly guided mode
- Vehicle profile wizard saved with browser localStorage
- CSV datalog importer and screening analysis
- Coach context from the active vehicle profile
- Optional secure Node AI backend
- Expanded safety/readiness checklist
- Read-only calibration education

## Open without installation

Open `index.html`. Most features work directly. The included sample CSV may require serving the folder rather than opening as a file because some browsers block local `fetch`. You can still select a CSV manually.

## Run with optional real AI

1. Install Node.js 20 or newer.
2. Copy `.env.example` to `.env` and enter your own API key.
3. In a terminal inside this folder, run `npm install` and then `npm start`.
4. Open `http://localhost:3000`.

The API key stays on the local Node server and is never placed in the browser code.

## Important limitation

Wave 2 does not connect to an OBD adapter or PCM Hammer and cannot read, edit, checksum, test-write, or flash a controller. Real vehicle communication requires the future Windows Bridge plus hardware bench testing.
