# Safety model

TunIQ must never represent simulated actions as real vehicle operations. PCM identification, voltage checks, original-file backups, compatibility verification, and explicit user confirmation are required before any future write workflow.
