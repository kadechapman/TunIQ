const assert=require('assert'); const fs=require('fs'); const os=require('os'); const path=require('path');
const {IntelligentConnectionManager}=require('../src/intelligent-connection-manager');
(async()=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq-icm-'));
 let devices=[
  {port:'COM3',name:'Standard Serial over Bluetooth link (Incoming)',bluetooth:true,incoming:true,pairKey:'mx'},
  {port:'COM4',name:'Standard Serial over Bluetooth link (Outgoing)',bluetooth:true,outgoing:true,pairKey:'mx'},
  {port:'COM1',name:'Communications Port'}
 ];
 const m=new IntelligentConnectionManager({dataRoot:()=>root,listDevices:async()=>devices,probePort:async({port})=>({available:port==='COM4',locked:false})});
 const r=await m.preflight({selectedPort:'COM3'}); assert.equal(r.ready,true); assert.equal(r.port,'COM4'); assert(!r.discovery.candidates.some(x=>x.port==='COM1'));
 const profile=m.load(); assert.equal(profile.lastWorkingPort,'COM4');
 devices=[{port:'COM3',name:'Standard Serial over Bluetooth link',bluetooth:true,incoming:true,pairKey:'mx'}];
 const n=new IntelligentConnectionManager({dataRoot:()=>fs.mkdtempSync(path.join(os.tmpdir(),'tuniq-icm2-')),listDevices:async()=>devices,probePort:async()=>({available:false})});
 const f=await n.preflight({selectedPort:'COM3'}); assert.equal(f.ready,false); assert.equal(f.state,'missing-outgoing-port');
 console.log('Intelligent Connection Manager simulations: 4/4 passed');
})().catch(e=>{console.error(e);process.exit(1)});
