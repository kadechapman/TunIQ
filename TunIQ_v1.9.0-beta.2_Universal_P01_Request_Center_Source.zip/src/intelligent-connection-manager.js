const fs = require('fs');
const path = require('path');

function clean(v, max=500){ return String(v ?? '').replace(/[\u0000-\u001f]/g,' ').trim().slice(0,max); }
function normalizePort(v){ const m=clean(v,40).toUpperCase().match(/^COM\d+$/); return m?m[0]:''; }
function textOf(d={}){ return `${d.name||''} ${d.description||''} ${d.manufacturer||''} ${d.hardwareId||''} ${d.instanceId||''} ${d.parentId||''} ${d.containerId||''} ${d.transport||''}`.toLowerCase(); }
function identityKey(d={}){ return clean(d.containerId||d.pairKey||d.parentId||d.instanceId||d.hardwareId||'',300).toLowerCase(); }
function isObdLink(d={}){ return Boolean(d.recognized)||/obdlink|scan\s*tool|scantool|stn11|stn21|mx\+|mxplus/.test(textOf(d)); }
function isBluetooth(d={}){ return Boolean(d.bluetooth)||/bluetooth|bthenum|bthmodem|bthport|spp/.test(textOf(d)); }
function scoreDevice(d={}, profile={}){
  const port=normalizePort(d.port); if(!port) return -9999;
  let score=0; const txt=textOf(d); const key=identityKey(d);
  if(isObdLink(d)) score+=120;
  if(isBluetooth(d)) score+=30;
  if(d.outgoing||/outgoing|client/.test(txt)) score+=85;
  if(d.incoming||/incoming|server/.test(txt)) score-=100;
  if(d.recommended) score+=30;
  if(profile.identityKey&&key&&profile.identityKey===key) score+=180;
  if(profile.lastWorkingPort&&port===profile.lastWorkingPort) score+=140;
  if(profile.lastSeenPorts?.includes(port)) score+=25;
  if(port==='COM1'&&!isObdLink(d)) score-=1000;
  return score;
}
class IntelligentConnectionManager{
  constructor({dataRoot,listDevices,probePort,appendActivity}={}){
    this.dataRoot=dataRoot||(()=>process.cwd()); this.listDevices=listDevices|| (async()=>[]); this.probePort=probePort|| (async()=>({available:true,supported:false})); this.appendActivity=appendActivity||(()=>{});
  }
  file(){ return path.join(this.dataRoot(),'Tools','obdlink-adapter-profile.json'); }
  load(){ try{return JSON.parse(fs.readFileSync(this.file(),'utf8'));}catch{return {adapterName:'',identityKey:'',lastWorkingPort:'',lastSeenPorts:[],lastSuccessfulAt:null};} }
  save(patch={}){ const next={...this.load(),...patch,updatedAt:new Date().toISOString()}; fs.mkdirSync(path.dirname(this.file()),{recursive:true}); fs.writeFileSync(this.file(),JSON.stringify(next,null,2)); return next; }
  async discover({selectedPort='',lastSuccessfulPort=''}={}){
    const profile=this.load(); let devices=[]; try{devices=await this.listDevices();}catch{}
    devices=(Array.isArray(devices)?devices:[]).map(d=>({...d,port:normalizePort(d.port)})).filter(d=>d.port);
    const preferred={...profile,lastWorkingPort:normalizePort(lastSuccessfulPort||profile.lastWorkingPort||selectedPort),lastSeenPorts:[...new Set([...(profile.lastSeenPorts||[]),normalizePort(selectedPort)].filter(Boolean))]};
    const ranked=devices.map(d=>({...d,connectionScore:scoreDevice(d,preferred),identityKey:identityKey(d),recognized:isObdLink(d),bluetooth:isBluetooth(d)})).sort((a,b)=>b.connectionScore-a.connectionScore||a.port.localeCompare(b.port,undefined,{numeric:true}));
    const candidates=[]; const add=(port,source,meta={})=>{port=normalizePort(port);if(!port||candidates.some(x=>x.port===port))return;if(port==='COM1'&&!meta.recognized)return;candidates.push({port,source,...meta});};
    for(const d of ranked.filter(d=>d.connectionScore>=20)) add(d.port,'live-windows-discovery',d);
    add(lastSuccessfulPort,'last-successful',{recognized:true,connectionScore:1000});
    add(selectedPort,'project-selected',{recognized:selectedPort!=='COM1',connectionScore:700});
    return {profile,devices,ranked,candidates,at:new Date().toISOString()};
  }
  async preflight(options={}){
    const discovery=await this.discover(options); const attempts=[];
    for(const c of discovery.candidates){
      let probe={}; try{probe=await this.probePort({port:c.port,timeout:2500});}catch(e){probe={available:false,error:clean(e.message||e)}}
      attempts.push({port:c.port,source:c.source,available:probe.available!==false,locked:Boolean(probe.locked),code:probe.code||null,message:clean(probe.message||probe.error||'')});
      if(probe.available!==false&&!probe.locked){
        const profile=this.save({adapterName:clean(c.name||discovery.profile.adapterName||'OBDLink MX+'),identityKey:c.identityKey||discovery.profile.identityKey||'',lastWorkingPort:c.port,lastSeenPorts:[...new Set(discovery.devices.map(d=>d.port))],lastSuccessfulAt:new Date().toISOString()});
        this.appendActivity('connection-manager-port-ready',{port:c.port,source:c.source});
        return {ready:true,port:c.port,candidate:c,attempts,discovery,profile};
      }
    }
    const missingOutgoing=discovery.devices.some(isBluetooth)&&!discovery.ranked.some(d=>d.outgoing||/outgoing|client/.test(textOf(d)));
    const state=discovery.devices.length? (missingOutgoing?'missing-outgoing-port':'ports-unavailable'):'adapter-not-detected';
    return {ready:false,port:'',attempts,discovery,state,repair:{title: state==='missing-outgoing-port'?'Bluetooth outgoing serial port is missing':'OBDLink connection is unavailable',steps:['Wake the OBDLink MX+ and keep it plugged into the powered vehicle.','Close phone OBD apps and other Windows OBD software.','In Windows Bluetooth settings, remove and re-pair OBDLink MX+ if no outgoing COM port appears.','Return to TunIQ and press Refresh Connection.']}};
  }
}
module.exports={IntelligentConnectionManager,normalizePort,isObdLink,isBluetooth,scoreDevice};
