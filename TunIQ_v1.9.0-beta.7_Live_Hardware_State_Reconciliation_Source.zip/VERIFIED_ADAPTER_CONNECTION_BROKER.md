# Verified Adapter Connection Broker

TunIQ v1.9.0-beta.3 verifies the Windows serial endpoint before starting PCM Hammer.

## Hardware path

1. Rescan the live Windows serial/Bluetooth inventory.
2. Exclude incoming-only Bluetooth endpoints and generic COM1.
3. Open each eligible port at most once.
4. Request ATI, AT@1, and STDI identity evidence without querying or writing the PCM.
5. Accept only a recognized OBDLink/STN-compatible identity.
6. Close TunIQ's probe handle, wait for Windows to release Bluetooth SPP, and launch PCM Hammer on that one verified port.

Read Properties, full reads, Test Write, and write-related operations all use the broker. A broker-backed PCM Hammer session does not repeat the same COM port and does not switch blindly to another port. If Windows changes state during the close-to-PCM-Hammer handoff, TunIQ stops with `adapter-handoff-failed`.

No actual PCM write is added or authorized by this release.
