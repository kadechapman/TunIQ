# TunIQ v1.9.0-beta.2 — Universal P01 Request Center

## Added

- Universal natural-language P01 request workflow for any isolated P01 project.
- Typed safety-fact parser that requests only facts relevant to elevated-RPM, high-speed, or ghost-idle requests.
- Request fingerprint bound to the project, OS, interpreted actions, and typed safety facts.
- Two-stage confirmation before revision creation.
- Guided P01 Setup request review without ten separate checkboxes.
- Strict automatic VATS and fan-cell candidate selection for Guided P01 Setup.

## Changed

- P01 Quick Service is now Universal P01 Command Center.
- The hard-coded “second PCM” wording and fixed VATS/fan form were removed.
- Exact-XDF binding, strict mapping, protected-revision creation, and Test Write authorization are built-in safety rules instead of repeated checkboxes.
- Existing P01 commissioning evidence still resumes through the disk-first continuation engine without requiring the request to be re-entered.

## Safety

- Every PCM still requires a separate project and its own verified evidence.
- TunIQ never guesses unsupported XDF addresses or security values.
- The request center creates revisions only. It does not Test Write or write a PCM.
- Guided setup may run PCM Hammer Test Write after all commissioning gates, but no real write is automatic.
- Real P01 hardware success is not claimed by this release.
