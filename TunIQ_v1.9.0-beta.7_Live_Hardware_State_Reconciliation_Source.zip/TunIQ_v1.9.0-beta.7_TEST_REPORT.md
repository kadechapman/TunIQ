# TunIQ v1.9.0-beta.7 Test Report

## Release

**TunIQ v1.9.0-beta.7 — Live Hardware State Reconciliation**

## Failures reproduced

- The guided progress headline and recovery code could remain on an older `adapter-conflict-process` result after a newer attempt started or was cancelled.
- Hardware Session Doctor could select an older project session and continue showing its COM attempts, recommended port, and stop code.
- A delayed PCM Hammer completion callback could overwrite a newer guided operation that happened to use the same phase.

## Fix verified

- Every hardware attempt receives a unique workflow attempt ID.
- PCM Hammer sessions, history, technical details, and completion callbacks carry that ID.
- Delayed completions from older/cancelled attempts are ignored.
- Starting, resuming, cancelling, completing, or failing an operation clears incompatible cached recovery data.
- Hardware Session Doctor selects only the session matching the current attempt or current stop.
- Renderer state revisions are monotonic; an older IPC snapshot cannot repaint the UI.

## Automated results

- Source syntax checks: **passed**
- Live-state reconciliation scenarios: **6/6 passed**
- Session Guard/Safety Vault scenarios: **15/15 passed**
- Full automated suite: **43/43 groups passed**
- Complete retained recovery chain: **passed**
- Real hardware Read Properties: **not claimed**
- Actual PCM write: **not performed**

Logs are stored in `test-results/`.
