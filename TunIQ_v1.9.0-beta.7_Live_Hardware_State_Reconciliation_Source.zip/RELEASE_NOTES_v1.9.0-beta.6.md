# TunIQ v1.9.0-beta.6 — TunIQ Runtime Process Guard Fix

## Fixed

- Prevents TunIQ's own `cmd.exe`, `node.exe`, and `electron.exe` process tree from triggering `adapter-conflict-process`.
- Stops source-folder names containing `OBDLink` from being interpreted as running OBD applications.
- Keeps real OBDwiz, serial-terminal, and other external adapter-owner detection active.
- Preserves all beta.5 OBDLink repair, manual COM verification, and read-only PCM Hammer direct handoff behavior.

No actual PCM write capability was enabled or exercised.
