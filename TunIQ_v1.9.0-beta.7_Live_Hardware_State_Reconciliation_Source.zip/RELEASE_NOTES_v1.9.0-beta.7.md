# TunIQ v1.9.0-beta.7 — Live Hardware State Reconciliation

- Gives every guided P01 hardware attempt a unique workflow attempt ID.
- Links PCM Hammer sessions and completion callbacks to that exact attempt.
- Ignores delayed completion events from older or cancelled operations.
- Clears stale recovery codes, port attempts, and Hardware Session Doctor data when a new attempt starts.
- Uses monotonic state revisions so the renderer cannot repaint an older snapshot over a newer one.
- Keeps verified project evidence unchanged and performs no PCM write.
