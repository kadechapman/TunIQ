# TunIQ v1.9.0-beta.1 — Multi-P01 Quick Service

## Added

- Dedicated P01 Quick Service panel in Tune Workflow.
- Separate-project preparation for an additional P01.
- Natural-language parsing for VATS disable and fan on/off targets.
- Exact fan-cell mapping with Fahrenheit/Celsius conversion.
- Exact VATS disabled-state mapping through enum or explicit Boolean semantics.
- Project/OS/XDF/BIN fingerprint isolation and commissioned-map reuse.
- Quick Switch entry for P01 Quick Service.

## Safety

- No raw VATS value or calibration address is guessed.
- Unitless fan tables are rejected.
- Invalid fan hysteresis is rejected.
- Read-only commissioning definitions remain non-writable.
- The workflow creates a new revision only; it never automatically Test Writes or writes a PCM.

Real hardware success is not claimed until a user confirms the physical Test Write and subsequent deliberate write workflow.
