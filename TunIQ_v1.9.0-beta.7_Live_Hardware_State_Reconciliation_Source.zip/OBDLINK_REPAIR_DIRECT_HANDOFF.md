# OBDLink Re-pair & Direct PCM Hammer Handoff

TunIQ v1.9.0-beta.5 adds a bounded recovery path for Windows Bluetooth systems that expose COM ports but refuse TunIQ's adapter-only identity probe.

The P01 workspace now offers:

- **Pair / Re-pair OBDLink** to open Windows Bluetooth pairing.
- **Verify Selected COM** to test a chosen live COM port using adapter identity commands only.
- **Try Selected COM with PCM Hammer** to authorize one read-only Read Properties attempt when TunIQ's own probe cannot open the port.

The direct PCM Hammer fallback never guesses between ports and never authorizes a real write. The first fallback is limited to Read Properties. When PCM Hammer proves communication, TunIQ records that exact COM port for the active project and may reuse it for the two protected full reads and Test Write. Calibration Write, Full Write, and Recovery remain behind TunIQ's verified connection broker and existing write confirmations.

All verified project evidence remains project-scoped and is preserved across pairing or COM recovery.
