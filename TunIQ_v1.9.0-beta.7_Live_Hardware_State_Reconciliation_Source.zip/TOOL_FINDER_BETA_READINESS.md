# TunIQ v1.8.8 Tool Finder & Beta Readiness

- Restores Tools as a permanent main workspace.
- Adds a searchable All TunIQ Modules catalog.
- Adds one-click Report Bug access from the header and Quick Switch.
- Expands direct Quick Switch actions for P01 Setup, Calibration, Revisions, Patches, and beta reporting.
- Fixes duplicate PCM Hammer, TunerPro, and Universal Patcher integration cards.
- Adds sanitized Hardware Session Doctor and Intelligent Connection Manager context to diagnostic bundles.
- Diagnostic bundles explicitly exclude raw BIN/XDF content and protected project files.
