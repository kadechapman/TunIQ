# TunIQ v1.9.0-beta.5 — OBDLink Re-pair & Direct PCM Hammer Handoff

## Fixed

- Adds a guided Pair / Re-pair OBDLink action when Windows Bluetooth SPP repair does not create an openable port.
- Lists every live Windows COM port for deliberate manual selection.
- Verifies a selected port with OBDLink/STN identity commands without querying or writing the PCM.
- Adds a controlled read-only PCM Hammer Read Properties fallback for ports that Windows exposes but TunIQ's adapter probe cannot open.
- Stores a PCM Hammer-proven COM port only after real controller communication succeeds.
- Reuses that proven port for the protected read pair and Test Write.
- Prevents the direct fallback from being used for Calibration Write, Full Write, or Recovery.
- Preserves the exact P01 project, saved request, read evidence, definition state, revision state, and Test Write progress.

## Safety boundary

This release does not claim a successful physical connection or PCM operation. A real PCM write remains separately locked and requires the verified connection broker, existing checksum controls, voltage proof, and explicit write confirmation.
