# TunIQ v1.8.7 — Intelligent Connection Manager

Replaces blind COM retries with live adapter identity discovery, outgoing-port selection, availability preflight, persistent proven-port memory, and guided Windows Bluetooth repair states.
