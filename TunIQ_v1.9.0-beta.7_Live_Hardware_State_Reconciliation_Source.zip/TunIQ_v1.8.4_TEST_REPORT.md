# TunIQ v1.8.4 Test Report

## Release
**PCM Hammer Process-Tree Cleanup Hotfix**

## Real hardware-session bug fixed
The v1.8.3 session guard could terminate a verified TunIQ-owned `PcmHammer.exe` process tree with `taskkill /T /F`, then classify the stale inventory captured before cleanup. This could falsely report both `PcmHammer.exe` and `pcmhammer-cli.exe` as live adapter conflicts.

## Corrected behavior
- Inventory Windows processes before cleanup.
- Terminate only registry-verified TunIQ-owned PCM Hammer roots.
- Wait briefly for the GUI/CLI process tree and serial handle to retire.
- Rescan Windows after cleanup.
- Classify only processes present in the fresh inventory.
- Preserve real external OBD/serial conflicts.
- Preserve verified reads, protected original, commissioning XDF, stock clone, and Safety Vault.

## Verification
- Source syntax/static checks: PASS
- Full automated suite: PASS — 36/36 groups
- Exclusive Session Guard/Safety Vault simulations: PASS — 11/11 scenarios
- Real-screen parent/child regression: PASS
- No actual PCM write performed or claimed
