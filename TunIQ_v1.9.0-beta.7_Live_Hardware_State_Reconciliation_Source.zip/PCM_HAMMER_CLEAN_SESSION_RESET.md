# PCM Hammer Clean Session Reset

TunIQ v1.8.6 replaces registry-dependent PCM Hammer ownership guesses with an unconditional clean-session boundary. Before integrated PCM Hammer starts, TunIQ identifies all PCM Hammer GUI/CLI process trees, terminates each root with its descendants, polls fresh Windows process inventories until no PCM Hammer process remains, and only then evaluates unrelated OBD or serial conflicts.
