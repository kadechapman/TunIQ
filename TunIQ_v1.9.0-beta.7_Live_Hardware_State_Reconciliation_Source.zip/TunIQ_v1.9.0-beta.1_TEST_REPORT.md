# TunIQ v1.9.0-beta.1 Test Report

## Release

- Name: Multi-P01 Quick Service
- Channel: Public Beta Candidate
- Scope: isolated second-P01 project workflow for exact VATS disable and electric-fan 210°F on / 190°F off revision creation
- Hardware write status: no real PCM write was performed or claimed

## New focused coverage

The P01 Quick Service simulation validates:

1. Combined VATS-disable and 210°F/190°F fan request parsing.
2. Exact VATS disabled-state enum mapping.
3. Fan 1 and Fan 2 on/off mapping.
4. Fahrenheit targets written in Fahrenheit XDF cells.
5. Fahrenheit-to-Celsius engineering conversion for Celsius XDF cells.
6. Refusal to guess an ambiguous VATS raw value.
7. Refusal to use unitless fan tables.
8. Cross-project workspace/proposal rejection.
9. Invalid fan hysteresis rejection.

## Results

- JavaScript source checks: passed
- Focused P01 Quick Service scenarios: 9/9 passed
- Full automated suite: 38/38 groups passed
- Retained recovery-lab chain: passed
- P01 clean commissioning simulation: passed
- COM lock/disconnect/restart simulation: passed
- Partial/mismatched read quarantine simulation: passed
- PCM Hammer COM3/COM4 and kernel recovery simulations: passed
- Project evidence continuity and Safety Vault simulations: passed

## Safety assertions

- Every physical PCM uses its own project identity and workspace binding.
- TunIQ does not reuse the unfinished Customline BIN, XDF, commissioned map, or revision.
- Exactly two complete 524,288-byte reads with matching SHA-256 remain required.
- A writable exact-OS XDF is required for VATS and fan changes.
- VATS raw values, addresses, and unitless fan values are never guessed.
- The quick-service workflow creates a new revision only.
- Test Write and any actual PCM write remain separate deliberate operations.

Software simulations do not prove real vehicle, adapter, wiring, relay, voltage, XDF, Test Write, or flash success.
