const fs = require('fs');
const path = require('path');

function finite(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }
function round(value, digits = 3) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }
function safe(value, max = 1000) { return String(value ?? '').trim().slice(0, max); }
function tableText(table) { return `${table?.name || ''} ${table?.description || ''} ${table?.category || ''} ${table?.unit || ''} ${(table?.rowHeaders || []).join(' ')} ${(table?.colHeaders || []).join(' ')}`.toLowerCase(); }
function tableCells(table) {
  const output = [];
  for (let row = 0; row < (table?.values?.length || 0); row += 1) {
    for (let col = 0; col < (table.values[row]?.length || 0); col += 1) {
      const value = finite(table.values[row][col]);
      if (value != null) output.push({ row, col, value, rowLabel: table.rowHeaders?.[row] ?? String(row), colLabel: table.colHeaders?.[col] ?? String(col) });
    }
  }
  return output;
}
function requestId() { return `${Date.now()}-goal-${Math.random().toString(16).slice(2,8)}`; }

function extractNear(text, keywords, unitPattern = '', digits = '{2,3}') {
  const patterns = keywords.map(keyword => new RegExp(`${keyword}[^0-9]{0,24}(\\d${digits}(?:\\.\\d+)?)\\s*${unitPattern}`, 'i'));
  for (const pattern of patterns) { const match = text.match(pattern); if (match) return Number(match[1]); }
  return null;
}

function parseTuneRequest(input) {
  const text = safe(input, 2000);
  const lower = text.toLowerCase();
  const intents = [];
  const ghost = /ghost\s*-?\s*cam|fake\s*cam|lopey?\s*idle|choppy?\s*idle/.test(lower);
  if (ghost) intents.push({ type: 'ghost-cam', label: 'Ghost-cam idle', requested: true });

  let rpm = extractNear(lower, ['(?:max(?:imum)?\\s*)?rev(?:\\s*limit)?','rpm(?:\\s*limit)?','redline','fuel\\s*cut'], '(?:rpm)?', '{4,5}');
  if (rpm == null) {
    const match = lower.match(/(?:raise|set|change).*?(\d{4,5})\s*rpm/); if (match) rpm = Number(match[1]);
  }
  if (rpm != null) intents.push({ type: 'rev-limit', label: 'Engine RPM limit', target: rpm, unit: 'RPM' });

  let speed = extractNear(lower, ['(?:max(?:imum)?\\s*)?speed(?:\\s*limit)?','vehicle\\s*speed','speed\\s*limiter'], '(?:mph|mi/h|km/h|kph)?');
  const speedUnit = /(?:km\/h|kph|kilomet)/i.test(lower) ? 'km/h' : 'mph';
  if (speed != null) intents.push({ type: 'speed-limit', label: 'Vehicle speed limiter', target: speed, unit: speedUnit });

  if (/remove\s+(?:the\s+)?speed\s+limit|disable\s+(?:the\s+)?speed\s+limiter/.test(lower) && !intents.some(item => item.type === 'speed-limit')) {
    intents.push({ type: 'speed-limit', label: 'Vehicle speed limiter', target: 255, unit: 'mph', interpretedAs: 'remove limiter' });
  }

  const vats = /(?:disable|remove|delete|turn\s*off|shut\s*off)\s+(?:the\s+)?(?:vats|vehicle\s+anti[- ]?theft|anti[- ]?theft|theft\s+deterrent|vtd)|(?:vats|vehicle\s+anti[- ]?theft|anti[- ]?theft|theft\s+deterrent|vtd)[^.!?]{0,30}(?:disable|remove|delete|off)/i.test(lower);
  if (vats) intents.push({ type: 'vats-disable', label: 'Disable VATS / theft deterrent', target: 'disabled' });

  const fanMention = /(?:electric\s+)?fans?|cooling\s+fans?/.test(lower);
  if (fanMention) {
    const unit = /(?:°\s*c|deg(?:rees?)?\s*c|celsius)/i.test(lower) ? 'C' : 'F';
    const onMatch = lower.match(/(?:fan(?:s)?[^0-9]{0,28})?(?:on|turn\s*on|enable|engage|activate)[^0-9]{0,18}(\d{2,3}(?:\.\d+)?)/i)
      || lower.match(/(\d{2,3}(?:\.\d+)?)\s*(?:°?[fc])?[^.!?]{0,18}(?:fan(?:s)?\s+)?(?:on|turn\s*on|enable|engage|activate)/i);
    const offMatch = lower.match(/(?:fan(?:s)?[^0-9]{0,28})?(?:off|turn\s*off|disable|release|deactivate)[^0-9]{0,18}(\d{2,3}(?:\.\d+)?)/i)
      || lower.match(/(\d{2,3}(?:\.\d+)?)\s*(?:°?[fc])?[^.!?]{0,18}(?:fan(?:s)?\s+)?(?:off|turn\s*off|disable|release|deactivate)/i);
    const on = onMatch ? Number(onMatch[1]) : null;
    const off = offMatch ? Number(offMatch[1]) : null;
    if (on != null || off != null) intents.push({ type: 'fan-control', label: 'Set electric-fan temperatures', fanOn: on, fanOff: off, unit });
  }

  return {
    text,
    intents,
    recognized: intents.length > 0,
    unrecognizedText: intents.length ? '' : text,
    warnings: [
      ...(ghost ? ['Ghost-cam behavior requires a verified controller/OS rule pack. TunIQ will not invent idle-spark values.'] : []),
      ...(speed != null && ((speedUnit === 'mph' && speed > 130) || (speedUnit === 'km/h' && speed > 210)) ? ['The requested speed limiter is high risk and requires tire, driveline, brake, and closed-course confirmations.'] : []),
      ...(rpm != null && rpm > 5800 ? ['The requested RPM limit requires confirmed valvetrain capability.'] : [])
    ]
  };
}

function matchTables(workspace, patterns, excludes = []) {
  return Object.entries(workspace?.tables || {}).filter(([, table]) => {
    const text = tableText(table);
    return patterns.some(pattern => pattern.test(text)) && !excludes.some(pattern => pattern.test(text));
  });
}

function valueForUnit(target, unit, table) {
  const tableUnit = String(table?.unit || '').toLowerCase();
  if (unit === 'mph' && /(km\/h|kph|kmh)/.test(tableUnit)) return target / 0.621371;
  if (unit === 'km/h' && /(mph|mi\/h)/.test(tableUnit)) return target * 0.621371;
  return target;
}

function mappedCellEntries(workspace, parameterMap, actionType) {
  const cells = parameterMap?.actions?.[actionType]?.cells || [];
  const output = [];
  for (const mapping of cells) {
    const table = workspace?.tables?.[mapping.tableKey];
    const value = finite(table?.values?.[Number(mapping.row)]?.[Number(mapping.col)]);
    if (!table || value == null) continue;
    output.push({ tableKey: mapping.tableKey, table, mapping, cell: {
      row: Number(mapping.row), col: Number(mapping.col), value,
      rowLabel: table.rowHeaders?.[Number(mapping.row)] ?? mapping.rowLabel ?? String(mapping.row),
      colLabel: table.colHeaders?.[Number(mapping.col)] ?? mapping.colLabel ?? String(mapping.col)
    }});
  }
  return output;
}

function cellProposal(prefix, action, tableKey, table, cell, proposed, reason, risk = 'moderate', blocked = false) {
  return {
    id: `${prefix}:${tableKey}:${cell.row}:${cell.col}`,
    actionId: action.id,
    actionType: action.type,
    tableKey,
    tableName: table.name,
    row: cell.row,
    col: cell.col,
    rowLabel: cell.rowLabel,
    colLabel: cell.colLabel,
    current: round(cell.value, 6),
    proposed: round(proposed, 6),
    delta: round(proposed - cell.value, 6),
    percent: cell.value ? round((proposed / cell.value - 1) * 100, 2) : null,
    reason,
    confidence: action.confidence || 'medium',
    risk,
    blocked,
    approvalRequired: true
  };
}

function buildRevAction(intent, workspace, confirmations, parameterMap = null) {
  const target = finite(intent.target);
  const commissioned = mappedCellEntries(workspace, parameterMap, 'rev-limit');
  const action = { id: `rev-${target}`, type: 'rev-limit', label: `Set RPM limit to ${target} RPM`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: [], mapCommissioned: commissioned.length > 0 };
  if (target == null || target < 3000 || target > 8500) { action.status = 'blocked'; action.requirements.push('Enter an RPM target between 3,000 and 8,500.'); return action; }
  if (target > 5800 && !confirmations.valvetrainVerified) { action.status = 'blocked'; action.requirements.push('Confirm the camshaft, valve springs, pushrods, lifters, oiling, and rotating assembly are suitable for this RPM.'); }
  const entries = commissioned.length ? commissioned : matchTables(workspace, [/rev/i,/engine.*speed.*limit/i,/fuel.*cut.*rpm/i,/rpm.*cut/i,/max.*rpm/i], [/fan/i,/speedometer/i,/input.*shaft/i,/output.*shaft/i,/trans.*rpm/i]).flatMap(([tableKey, table]) => tableCells(table).filter(item => item.value >= 2500 && item.value <= 10000).map(cell => ({ tableKey, table, mapping: {}, cell })));
  if (!entries.length) { action.status = 'blocked'; action.requirements.push('No RPM limiter parameter was found in the loaded XDF.'); return action; }
  let restoreFound = false;
  for (const { tableKey, table, mapping, cell } of entries) {
    const cellText = `${tableText(table)} ${cell.rowLabel} ${cell.colLabel}`.toLowerCase();
    if (!commissioned.length && !/(rev|rpm|engine.*speed|fuel.*cut)/i.test(cellText)) continue;
    const isRestore = mapping.role === 'restore' || /(resume|restore|hysteresis|re-enable)/i.test(`${cell.rowLabel} ${cell.colLabel}`);
    const proposed = isRestore ? target - 200 : target;
    if (isRestore) restoreFound = true;
    action.proposals.push(cellProposal(isRestore ? 'goal-rev-restore' : 'goal-rev', action, tableKey, table, cell, proposed, isRestore ? `Commissioned limiter restore/resume value set 200 RPM below the requested ${target} RPM cutoff.` : `Requested ${target} RPM maximum.`, target > 6500 ? 'high' : 'moderate', action.status === 'blocked'));
  }
  if (!commissioned.length) action.warnings.push('These are XDF mapping candidates. Confirm this action once for the exact P01 OS/XDF before applying it.');
  if (!restoreFound) action.warnings.push('No separate RPM restore/resume value is commissioned. Review the XDF for a companion hysteresis parameter.');
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The RPM mapping did not contain plausible limiter values.'); }
  return action;
}

function buildSpeedAction(intent, workspace, confirmations, parameterMap = null) {
  const target = finite(intent.target);
  const mph = intent.unit === 'km/h' ? target * 0.621371 : target;
  const commissioned = mappedCellEntries(workspace, parameterMap, 'speed-limit');
  const action = { id: `speed-${target}`, type: 'speed-limit', label: `Set speed limiter to ${target} ${intent.unit}`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Changing a limiter does not make the vehicle capable of safely reaching that speed.'], mapCommissioned: commissioned.length > 0 };
  if (target == null || mph < 30 || mph > 255) { action.status = 'blocked'; action.requirements.push('Enter a speed-limiter target between 30 and 255 MPH equivalent.'); return action; }
  if (mph > 130) {
    const tire = finite(confirmations.tireRatingMph);
    if (!(tire >= mph)) { action.status = 'blocked'; action.requirements.push(`Confirm a tire speed rating of at least ${Math.ceil(mph)} MPH.`); }
    if (!confirmations.drivelineVerified) { action.status = 'blocked'; action.requirements.push('Confirm driveshaft critical speed, U-joints, differential, and transmission output components.'); }
    if (!confirmations.brakesVerified) { action.status = 'blocked'; action.requirements.push('Confirm braking, wheel bearings, suspension, and vehicle stability are appropriate.'); }
    if (!confirmations.closedCourse) { action.status = 'blocked'; action.requirements.push('Confirm closed-course or controlled test use.'); }
  }
  const entries = commissioned.length ? commissioned : matchTables(workspace, [/vehicle.*speed/i,/speed.*limit/i,/top.*speed/i,/engine.*speed.*limits/i], [/fan/i,/shift/i,/speedometer.*cal/i,/output.*shaft/i]).flatMap(([tableKey, table]) => tableCells(table).filter(item => item.value >= 20 && item.value <= 450).map(cell => ({ tableKey, table, mapping: {}, cell })));
  if (!entries.length) { action.status = 'blocked'; action.requirements.push('No vehicle-speed limiter parameter was found in the loaded XDF.'); return action; }
  for (const { tableKey, table, cell } of entries) {
    const cellText = `${tableText(table)} ${cell.rowLabel} ${cell.colLabel}`.toLowerCase();
    if (!commissioned.length && !/(vehicle.*speed|speed.*limit|top.*speed)/i.test(cellText)) continue;
    const stored = valueForUnit(target, intent.unit, table);
    action.proposals.push(cellProposal('goal-speed', action, tableKey, table, cell, stored, `Requested vehicle-speed limiter of ${target} ${intent.unit}.`, mph > 130 ? 'high' : 'moderate', action.status === 'blocked'));
  }
  if (!commissioned.length) action.warnings.push('These are XDF mapping candidates. Confirm this action once for the exact P01 OS/XDF before applying it.');
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The speed-limiter mapping did not contain a plausible value.'); }
  return action;
}

function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function loadRulePacks(folders = []) {
  const packs = [];
  for (const folder of folders) {
    if (!folder || !fs.existsSync(folder)) continue;
    for (const name of fs.readdirSync(folder)) {
      if (!name.toLowerCase().endsWith('.json')) continue;
      const pack = readJson(path.join(folder, name), null);
      if (pack && typeof pack === 'object') packs.push({ ...pack, file: path.join(folder, name) });
    }
  }
  return packs;
}
function matchesPack(pack, active) {
  if (!pack?.verified || pack.goal !== 'ghost-cam') return false;
  const controller = String(active?.controller || '').toUpperCase();
  const os = String(active?.os || '');
  const controllers = Array.isArray(pack.controllers) ? pack.controllers.map(item => String(item).toUpperCase()) : ['*'];
  const operatingSystems = Array.isArray(pack.operatingSystems) ? pack.operatingSystems.map(String) : ['*'];
  return (controllers.includes('*') || controllers.includes(controller)) && (operatingSystems.includes('*') || operatingSystems.includes(os));
}
function applyRuleOperation(current, rule, index = 0) {
  const amount = finite(rule.value);
  if (amount == null) return null;
  if (rule.operation === 'set') return amount;
  if (rule.operation === 'add') return current + amount;
  if (rule.operation === 'percent') return current * (1 + amount / 100);
  if (rule.operation === 'alternating-add') return current + (index % 2 === 0 ? amount : -amount);
  return null;
}

function disabledEnumValue(table) {
  const labels = Array.isArray(table?.enumLabels) ? table.enumLabels : [];
  const preferred = labels.find(item => /(?:disabled?|none|not\s+used|not\s+present|no\s+vats|off)/i.test(String(item.value || '')));
  return preferred && Number.isFinite(Number(preferred.index)) ? Number(preferred.index) : null;
}
function vatsTargetForCell(table, cell, mapping = {}) {
  if (Number.isFinite(Number(mapping.disabledValue))) return { value: Number(mapping.disabledValue), evidence: 'commissioned disabled value' };
  const enumValue = disabledEnumValue(table);
  if (enumValue != null) return { value: enumValue, evidence: 'XDF enum label identifies the disabled state' };
  const text = `${tableText(table)} ${cell.rowLabel || ''} ${cell.colLabel || ''}`.toLowerCase();
  const current = finite(cell.value);
  if (current != null && [0, 1].includes(current)) {
    if (/(?:vats|anti.?theft|theft.?deterrent|vtd).*(?:enable|enabled|active)|(?:enable|enabled).*(?:vats|anti.?theft|theft.?deterrent|vtd)/i.test(text)) return { value: 0, evidence: 'explicit enable flag' };
    if (/(?:vats|anti.?theft|theft.?deterrent|vtd).*(?:disable|disabled)|(?:disable|disabled).*(?:vats|anti.?theft|theft.?deterrent|vtd)/i.test(text)) return { value: 1, evidence: 'explicit disable flag' };
  }
  return null;
}
function buildVatsAction(intent, workspace, confirmations, parameterMap = null) {
  const commissioned = mappedCellEntries(workspace, parameterMap, 'vats-disable');
  const action = { id: 'vats-disable', type: 'vats-disable', label: 'Disable VATS / theft deterrent', status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['VATS removal is intended for a lawful engine swap or authorized vehicle repair. It does not bypass physical security and must not be used on a vehicle you do not own or have permission to modify.'], mapCommissioned: commissioned.length > 0 };
  const candidates = commissioned.length ? commissioned : matchTables(workspace,
    [/\bvats\b/i,/vehicle.*anti.?theft/i,/anti.?theft/i,/theft.*deterrent/i,/\bvtd\b/i,/fuel.*enable.*password/i],
    [/diagnostic/i,/dtc/i,/history/i]).flatMap(([tableKey, table]) => tableCells(table).map(cell => ({ tableKey, table, mapping: {}, cell })));
  const seen = new Set();
  for (const entry of candidates) {
    const key = `${entry.tableKey}:${entry.cell.row}:${entry.cell.col}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const combined = `${tableText(entry.table)} ${entry.cell.rowLabel} ${entry.cell.colLabel}`;
    if (!commissioned.length && !/(?:\bvats\b|vehicle.*anti.?theft|anti.?theft|theft.*deterrent|\bvtd\b|fuel.*enable.*password)/i.test(combined)) continue;
    const target = vatsTargetForCell(entry.table, entry.cell, entry.mapping);
    if (!target) continue;
    action.proposals.push(cellProposal('goal-vats-disable', action, entry.tableKey, entry.table, entry.cell, target.value, `Set the mapped theft-deterrent parameter to its disabled state (${target.evidence}).`, 'moderate', false));
  }
  if (!action.proposals.length) {
    action.status = 'blocked';
    action.requirements.push('No unambiguous VATS disable value was found. Use an exact writable XDF or Universal Patcher definition that labels the disabled state; TunIQ will not guess a security value or address.');
  } else if (!commissioned.length) {
    action.warnings.push('These are exact XDF mapping candidates. Verify and commission the cells for this specific P01 OS, XDF hash, and protected original before applying them.');
  }
  return action;
}
function temperatureUnit(table) {
  const text = `${table?.unit || ''} ${table?.description || ''}`.toLowerCase();
  if (/(?:°\s*c|deg(?:rees?)?\s*c|celsius|\bdegc\b)/i.test(text)) return 'C';
  if (/(?:°\s*f|deg(?:rees?)?\s*f|fahrenheit|\bdegf\b)/i.test(text)) return 'F';
  return '';
}
function requestedTemperature(value, requestUnit, tableUnit) {
  const number = finite(value);
  if (number == null) return null;
  if (requestUnit === tableUnit || !tableUnit) return number;
  if (requestUnit === 'F' && tableUnit === 'C') return (number - 32) * 5 / 9;
  if (requestUnit === 'C' && tableUnit === 'F') return number * 9 / 5 + 32;
  return null;
}
function fanRole(entry) {
  if (entry?.mapping?.role === 'fan-on' || entry?.mapping?.role === 'fan-off') return entry.mapping.role;
  const text = `${entry?.table?.name || ''} ${entry?.table?.description || ''} ${entry?.cell?.rowLabel || ''} ${entry?.cell?.colLabel || ''}`.toLowerCase();
  if (/(?:\boff\b|turn\s*off|deactivat|release|disable|resume)/i.test(text)) return 'fan-off';
  if (/(?:\bon\b|turn\s*on|activat|engage|enable)/i.test(text)) return 'fan-on';
  return '';
}
function buildFanAction(intent, workspace, confirmations, parameterMap = null) {
  const fanOn = finite(intent.fanOn), fanOff = finite(intent.fanOff), requestUnit = intent.unit === 'C' ? 'C' : 'F';
  const commissioned = mappedCellEntries(workspace, parameterMap, 'fan-control');
  const action = { id: `fan-${fanOn ?? 'x'}-${fanOff ?? 'x'}-${requestUnit}`, type: 'fan-control', label: `Set electric fans ${fanOn ?? '?'}°${requestUnit} on / ${fanOff ?? '?'}°${requestUnit} off`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Verify coolant-temperature sensor accuracy, thermostat choice, relay/fuse capacity, fan wiring, and airflow direction before relying on PCM fan control.'], mapCommissioned: commissioned.length > 0 };
  if (fanOn == null || fanOff == null) { action.status = 'blocked'; action.requirements.push('Provide both a fan-on and fan-off temperature.'); return action; }
  const onF = requestUnit === 'F' ? fanOn : fanOn * 9 / 5 + 32;
  const offF = requestUnit === 'F' ? fanOff : fanOff * 9 / 5 + 32;
  if (onF < 150 || onF > 235 || offF < 130 || offF > 225) { action.status = 'blocked'; action.requirements.push('Fan temperatures must be within a plausible 150–235°F on and 130–225°F off range.'); }
  if (offF >= onF) { action.status = 'blocked'; action.requirements.push('Fan-off temperature must be lower than fan-on temperature to prevent rapid cycling.'); }
  const candidates = commissioned.length ? commissioned : matchTables(workspace,
    [/fan.*(?:temp|temperature|coolant|ect)/i,/(?:temp|temperature|coolant|ect).*fan/i,/electric.*fan/i],
    [/diagnostic/i,/dtc/i,/minimum.*speed/i,/maximum.*speed/i,/ac.*pressure/i]).flatMap(([tableKey, table]) => tableCells(table).map(cell => ({ tableKey, table, mapping: {}, cell })));
  let onCount = 0, offCount = 0;
  const seen = new Set();
  for (const entry of candidates) {
    const role = fanRole(entry);
    if (!role) continue;
    const key = `${entry.tableKey}:${entry.cell.row}:${entry.cell.col}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const unit = temperatureUnit(entry.table);
    if (!unit) continue;
    const target = requestedTemperature(role === 'fan-on' ? fanOn : fanOff, requestUnit, unit);
    if (target == null) continue;
    if (Number.isFinite(Number(entry.table.min)) && target < Number(entry.table.min)) continue;
    if (Number.isFinite(Number(entry.table.max)) && target > Number(entry.table.max)) continue;
    if (role === 'fan-on') onCount += 1; else offCount += 1;
    action.proposals.push(cellProposal(`goal-${role}`, action, entry.tableKey, entry.table, entry.cell, target, `${role === 'fan-on' ? 'Turn the mapped fan output on' : 'Turn the mapped fan output off'} at ${role === 'fan-on' ? fanOn : fanOff}°${requestUnit}${unit !== requestUnit ? ` (${round(target, 3)}°${unit} in this XDF)` : ''}.`, 'low', action.status === 'blocked'));
  }
  if (!onCount || !offCount) {
    action.status = 'blocked';
    action.requirements.push(!onCount && !offCount ? 'No labeled fan-on or fan-off temperature cells were found in the exact writable XDF.' : !onCount ? 'A fan-off cell was found, but no labeled fan-on temperature cell was found.' : 'A fan-on cell was found, but no labeled fan-off temperature cell was found.');
    action.requirements.push('TunIQ requires labeled engineering units (°F or °C) and will not guess raw fan-temperature addresses.');
    action.proposals.forEach(item => { item.blocked = true; });
  } else if (!commissioned.length) {
    action.warnings.push('Verify and commission these exact fan cells once for this P01 OS/XDF before applying the quick-service preset.');
  }
  return action;
}

function buildGhostAction(intent, workspace, activeProject, confirmations, ruleFolders, parameterMap = null) {
  const commissioned = mappedCellEntries(workspace, parameterMap, 'ghost-cam');
  const action = { id: 'ghost-cam', type: 'ghost-cam', label: 'Create ghost-cam idle profile', status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Ghost-cam calibrations can reduce idle quality, manifold vacuum, brake assist, emissions compliance, and accessory performance.'], mapCommissioned: commissioned.length > 0 };
  if (!confirmations.ghostCamRisksAccepted) { action.status = 'blocked'; action.requirements.push('Accept the idle-quality, vacuum, brake-assist, emissions, and drivability risks.'); }
  const pack = loadRulePacks(ruleFolders).find(item => matchesPack(item, activeProject));
  if (pack && !commissioned.length) {
    action.rulePack = { id: pack.id, name: pack.name, version: pack.version, source: pack.source || 'verified package' };
    action.confidence = 'verified-rule';
    for (const rule of pack.rules || []) {
      const regexes = (rule.tablePatterns || []).map(value => new RegExp(value, 'i'));
      const tables = matchTables(workspace, regexes.length ? regexes : [/$a/]);
      if (!tables.length) { action.status = 'blocked'; action.requirements.push(`Rule ${rule.id || 'unnamed'} could not find its required table.`); continue; }
      for (const [tableKey, table] of tables) {
        const cells = tableCells(table).filter(cell => {
          if (rule.rowLabels?.length && !rule.rowLabels.some(value => new RegExp(value, 'i').test(String(cell.rowLabel)))) return false;
          if (rule.colLabels?.length && !rule.colLabels.some(value => new RegExp(value, 'i').test(String(cell.colLabel)))) return false;
          return true;
        });
        cells.forEach((cell, index) => {
          const proposed = applyRuleOperation(cell.value, rule, index);
          if (!Number.isFinite(proposed)) return;
          action.proposals.push(cellProposal(`goal-ghost-${rule.id || 'rule'}`, action, tableKey, table, cell, proposed, rule.reason || `Verified ghost-cam rule ${rule.id || ''}.`, 'high', action.status === 'blocked'));
        });
      }
    }
  } else if (commissioned.length) {
    let sparkIndex = 0;
    for (const { tableKey, table, mapping, cell } of commissioned) {
      let proposed = cell.value;
      if (mapping.role === 'idle-spark') { proposed = cell.value + (sparkIndex++ % 2 === 0 ? 3 : -3); }
      else if (mapping.role === 'idle-airflow') proposed = cell.value * 1.05;
      else if (mapping.role === 'idle-speed') proposed = Math.max(700, Math.min(850, cell.value + 50));
      else continue;
      action.proposals.push(cellProposal(`goal-ghost-${mapping.role}`, action, tableKey, table, cell, proposed, `Mild reversible ghost-cam profile using the commissioned ${mapping.role} cell for this exact P01 OS/XDF.`, 'high', action.status === 'blocked'));
    }
  } else {
    const candidates = [];
    const addCandidates = (patterns, role, predicate, transform, limit = 8) => {
      for (const [tableKey, table] of matchTables(workspace, patterns)) {
        for (const cell of tableCells(table).filter(predicate).slice(0, limit)) {
          candidates.push({ tableKey, table, cell, role, proposed: transform(cell.value, candidates.length) });
        }
      }
    };
    addCandidates([/idle.*spark/i,/spark.*idle/i], 'idle-spark', cell => cell.value >= -30 && cell.value <= 60, (value, index) => value + (index % 2 === 0 ? 3 : -3));
    addCandidates([/base.*running.*air/i,/idle.*airflow/i,/airflow.*idle/i], 'idle-airflow', cell => cell.value >= 0 && cell.value <= 40, value => value * 1.05);
    addCandidates([/desired.*idle.*speed/i,/idle.*rpm/i,/idle.*speed/i], 'idle-speed', cell => cell.value >= 400 && cell.value <= 1200, value => Math.max(700, Math.min(850, value + 50)), 4);
    for (const item of candidates.slice(0, 20)) action.proposals.push(cellProposal(`goal-ghost-${item.role}`, action, item.tableKey, item.table, item.cell, item.proposed, `Candidate ${item.role} cell. Confirm it once for this exact P01 OS/XDF before use.`, 'high', true));
    action.status = 'blocked';
    action.requirements.push(candidates.length ? 'Review these exact candidate cells and commission the P01 parameter map, then rebuild the request.' : `No ghost-cam candidate tables were found for ${activeProject?.controller || 'unknown controller'} / OS ${activeProject?.os || 'unknown'}.`);
    action.warnings.push('TunIQ will not apply candidate idle cells until they are commissioned for this exact XDF hash.');
  }
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The ghost-cam mapping produced no exact calibration cells.'); }
  return action;
}

function buildGoalProposal({ request, workspace, activeProject, confirmations = {}, ruleFolders = [], parameterMap = null }) {
  if (!workspace || workspace.mode !== 'xdf' || !workspace.tables) throw new Error('Load the active project BIN and XDF before executing tune requests.');
  if (!activeProject?.id || workspace.projectId !== activeProject.id) throw new Error('The calibration workspace does not match the active project.');
  const parsed = typeof request === 'string' ? parseTuneRequest(request) : request;
  if (!parsed?.recognized) throw new Error('TunIQ could not identify a supported tune action in that request. Try “disable VATS and set fans on at 210°F and off at 190°F,” “set rev limiter to 6000 RPM,” or “set speed limiter to 120 MPH.”');
  const actions = [];
  for (const intent of parsed.intents) {
    if (intent.type === 'rev-limit') actions.push(buildRevAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'speed-limit') actions.push(buildSpeedAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'ghost-cam') actions.push(buildGhostAction(intent, workspace, activeProject, confirmations, ruleFolders, parameterMap));
    else if (intent.type === 'vats-disable') actions.push(buildVatsAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'fan-control') actions.push(buildFanAction(intent, workspace, confirmations, parameterMap));
  }
  const proposals = actions.flatMap(action => action.proposals || []);
  const blockedActions = actions.filter(action => action.status === 'blocked');
  return {
    id: requestId(), kind: 'goal-request', projectId: activeProject.id, projectName: activeProject.name,
    requestText: parsed.text, parsed, confirmations, generatedAt: new Date().toISOString(), actions, proposals,
    blocked: proposals.length === 0 || actions.every(action => action.status === 'blocked'),
    partiallyBlocked: blockedActions.length > 0 && actions.some(action => action.status !== 'blocked'),
    summary: { actions: actions.length, readyActions: actions.filter(action => action.status !== 'blocked').length, blockedActions: blockedActions.length, proposedCells: proposals.filter(item => !item.blocked).length, approvalRequired: true, automaticFlash: false },
    warnings: [
      'Natural-language requests are converted to exact mapped parameters; unidentified tables are never guessed.',
      'Every proposed cell requires approval and creates a new revision.',
      'Applying the revision does not flash the PCM. Flash Center still requires validation and a separate typed write confirmation.'
    ]
  };
}

function applyGoalApproved(workspace, proposal, approvedIds = []) {
  if (!workspace || workspace.mode !== 'xdf') throw new Error('Load an XDF calibration workspace first.');
  if (!proposal || proposal.projectId !== workspace.projectId || proposal.kind !== 'goal-request') throw new Error('The tune-request proposal does not match this calibration workspace.');
  const approved = new Set((approvedIds || []).map(String));
  if (!approved.size) throw new Error('Approve at least one requested calibration change.');
  const applied = [];
  for (const item of proposal.proposals || []) {
    if (!approved.has(String(item.id))) continue;
    if (item.blocked) throw new Error(`${item.tableName} is blocked by an unmet safety requirement.`);
    const table = workspace.tables?.[item.tableKey];
    if (!table?.values?.[item.row]) continue;
    const current = finite(table.values[item.row][item.col]);
    if (current == null || Math.abs(current - Number(item.current)) > 1e-5) throw new Error(`${item.tableName} changed after the request was generated. Build a fresh action sheet.`);
    table.values[item.row][item.col] = Number(item.proposed);
    workspace.modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
    workspace.modified[`${item.tableKey}:${item.row}:${item.col}`] = true;
    applied.push({ ...item, appliedAt: new Date().toISOString() });
  }
  if (!applied.length) throw new Error('None of the approved request changes could be applied.');
  workspace.updatedAt = new Date().toISOString();
  workspace.goalRequestApplied = { proposalId: proposal.id, requestText: proposal.requestText, applied, at: workspace.updatedAt };
  return { workspace, applied };
}

module.exports = { parseTuneRequest, buildGoalProposal, applyGoalApproved, loadRulePacks, matchesPack };
