const fs = require('fs');
const path = require('path');

function clean(v, max = 500) { return String(v ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max); }
function normalizePort(v) { const match = clean(v, 40).toUpperCase().match(/^COM\d+$/); return match ? match[0] : ''; }
function textOf(device = {}) {
  return `${device.name || ''} ${device.description || ''} ${device.manufacturer || ''} ${device.hardwareId || ''} ${device.instanceId || ''} ${device.parentId || ''} ${device.containerId || ''} ${device.transport || ''}`.toLowerCase();
}
function identityKey(device = {}) { return clean(device.containerId || device.pairKey || device.parentId || device.instanceId || device.hardwareId || '', 300).toLowerCase(); }
function isObdLink(device = {}) { return Boolean(device.recognized) || /obdlink|scan\s*tool|scantool|stn11|stn21|mx\+|mxplus|obdx|allpro|avt/.test(textOf(device)); }
function isBluetooth(device = {}) { return Boolean(device.bluetooth) || /bluetooth|bthenum|bthmodem|bthport|spp/.test(textOf(device)); }
function isOutgoing(device = {}) { return Boolean(device.outgoing) || /outgoing|client/.test(textOf(device)); }
function isIncoming(device = {}) { return Boolean(device.incoming) || /incoming|server/.test(textOf(device)); }
function identityText(probe = {}) { return `${probe.adapter || ''} ${probe.description || ''} ${probe.deviceId || ''} ${probe.identity || ''}`.trim(); }
function isSupportedAdapterIdentity(probe = {}) {
  if (probe.recognized === true) return true;
  return /obdlink|stn\d+|scantool|obdx|allpro|avt|elm327/i.test(identityText(probe));
}
function scoreDevice(device = {}, profile = {}) {
  const port = normalizePort(device.port);
  if (!port) return -9999;
  const key = identityKey(device);
  let score = 0;
  if (isObdLink(device)) score += 150;
  if (isBluetooth(device)) score += 35;
  if (isOutgoing(device)) score += 110;
  if (isIncoming(device) && !isOutgoing(device)) score -= 240;
  if (device.recommended) score += 35;
  if (profile.identityKey && key && profile.identityKey === key) score += 190;
  if (profile.lastWorkingPort && port === profile.lastWorkingPort && profile.identityVerifiedAt) score += 180;
  if (profile.lastSeenPorts?.includes(port)) score += 20;
  if (port === 'COM1' && !isObdLink(device) && port !== profile.lastWorkingPort) score -= 2000;
  return score;
}

class IntelligentConnectionManager {
  constructor({ dataRoot, listDevices, identifyPort, probePort, repairBluetooth, appendActivity } = {}) {
    this.dataRoot = dataRoot || (() => process.cwd());
    this.listDevices = listDevices || (async () => []);
    this.identifyPort = identifyPort || null;
    this.probePort = probePort || (async () => ({ available: false, identified: false, supported: false }));
    this.repairBluetooth = repairBluetooth || null;
    this.appendActivity = appendActivity || (() => {});
  }

  file() { return path.join(this.dataRoot(), 'Tools', 'obdlink-adapter-profile.json'); }
  load() {
    try { return JSON.parse(fs.readFileSync(this.file(), 'utf8')); }
    catch { return { adapterName: '', identityKey: '', adapterIdentity: '', lastWorkingPort: '', lastSeenPorts: [], identityVerifiedAt: null, lastSuccessfulAt: null }; }
  }
  save(patch = {}) {
    const next = { ...this.load(), ...patch, updatedAt: new Date().toISOString() };
    fs.mkdirSync(path.dirname(this.file()), { recursive: true });
    fs.writeFileSync(this.file(), JSON.stringify(next, null, 2));
    return next;
  }

  async discover({ selectedPort = '', lastSuccessfulPort = '', manualPortOnly = false } = {}) {
    const profile = this.load();
    let devices = [];
    try { devices = await this.listDevices(); } catch {}
    devices = (Array.isArray(devices) ? devices : [])
      .map(device => ({ ...device, port: normalizePort(device.port) }))
      .filter(device => device.port && !device.demo);
    const liveByPort = new Map(devices.map(device => [device.port, device]));
    const preferred = {
      ...profile,
      lastWorkingPort: normalizePort(profile.lastWorkingPort),
      lastSeenPorts: [...new Set([...(profile.lastSeenPorts || []), ...devices.map(device => device.port)].filter(Boolean))]
    };
    const ranked = devices
      .map(device => ({
        ...device,
        connectionScore: scoreDevice(device, preferred),
        identityKey: identityKey(device),
        recognized: isObdLink(device),
        bluetooth: isBluetooth(device),
        outgoing: isOutgoing(device),
        incoming: isIncoming(device)
      }))
      .sort((a, b) => b.connectionScore - a.connectionScore || a.port.localeCompare(b.port, undefined, { numeric: true }));

    const candidates = [];
    const add = (port, source, metadata = {}) => {
      port = normalizePort(port);
      if (!port || candidates.some(item => item.port === port)) return;
      const live = liveByPort.get(port) || {};
      const merged = { ...live, ...metadata, port };
      const proven = Boolean(metadata.provenIdentity || (profile.identityVerifiedAt && profile.lastWorkingPort === port));
      const forced = Boolean(metadata.forceCandidate);
      if (port === 'COM1' && !isObdLink(merged) && !proven && !forced) return;
      if (isIncoming(merged) && !isOutgoing(merged) && !isObdLink(merged) && !proven && !forced) return;
      candidates.push({ ...merged, source, provenIdentity: proven });
    };

    if (manualPortOnly) {
      const manual = normalizePort(selectedPort);
      if (manual && liveByPort.has(manual)) add(manual, 'manual-user-selection', { ...liveByPort.get(manual), forceCandidate: true, connectionScore: 5000 });
      return { profile, devices, ranked, candidates, selectedPort: manual, manualPortOnly: true, at: new Date().toISOString() };
    }

    // A previously identified adapter is preferred, but only when Windows still exposes the
    // port or the saved profile proves that exact port was positively identified before.
    const savedPort = normalizePort(profile.lastWorkingPort);
    if (savedPort && (liveByPort.has(savedPort) || profile.identityVerifiedAt)) add(savedPort, 'verified-adapter-profile', { provenIdentity: true, connectionScore: 2000 });
    const successful = normalizePort(lastSuccessfulPort);
    const successfulDevice = liveByPort.get(successful);
    if (successfulDevice && (isObdLink(successfulDevice) || isOutgoing(successfulDevice))) add(successful, 'last-successful-pcmhammer-port', { ...successfulDevice, connectionScore: 1500 });
    const selected = normalizePort(selectedPort);
    // Live Windows ranking comes before a generic remembered/selected COM number. This prevents
    // an old incoming endpoint such as COM8 from outranking a newly exposed outgoing COM4.
    for (const device of ranked.filter(device => device.connectionScore >= 20)) add(device.port, 'live-windows-discovery', device);
    if (selected && liveByPort.has(selected)) add(selected, 'project-selected-live-port', { ...liveByPort.get(selected), connectionScore: 1300 });

    return { profile, devices, ranked, candidates, selectedPort: selected, at: new Date().toISOString() };
  }

  async identify(candidate) {
    const request = { port: candidate.port, timeout: 12000, baud: 0, candidate };
    if (typeof this.identifyPort === 'function') return this.identifyPort(request);
    return this.probePort(request);
  }

  async preflight(options = {}) {
    const discovery = await this.discover(options);
    const attempts = [];
    const attempted = new Set();
    for (const candidate of discovery.candidates) {
      if (attempted.has(candidate.port)) continue;
      attempted.add(candidate.port);
      let probe = {};
      try { probe = await this.identify(candidate); }
      catch (error) { probe = { available: false, identified: false, error: clean(error.message || error) }; }
      const recognized = isSupportedAdapterIdentity(probe);
      const identified = probe.identified === true || Boolean(identityText(probe));
      const available = probe.available !== false && !probe.locked;
      const attempt = {
        port: candidate.port,
        source: candidate.source,
        available,
        locked: Boolean(probe.locked),
        identified,
        recognized,
        adapter: clean(probe.adapter || '', 180),
        description: clean(probe.description || '', 180),
        deviceId: clean(probe.deviceId || '', 180),
        baud: Number(probe.baud || 0) || null,
        code: probe.code || null,
        timedOut: Boolean(probe.timedOut),
        message: clean(probe.message || probe.error || '')
      };
      attempts.push(attempt);
      if (available && identified && recognized) {
        const verifiedAt = new Date().toISOString();
        const profile = this.save({
          adapterName: clean(probe.adapter || candidate.name || discovery.profile.adapterName || 'OBDLink/STN adapter'),
          adapterIdentity: clean(identityText(probe), 500),
          identityKey: candidate.identityKey || identityKey(candidate) || discovery.profile.identityKey || '',
          lastWorkingPort: candidate.port,
          lastSeenPorts: [...new Set(discovery.devices.map(device => device.port))],
          identityVerifiedAt: verifiedAt,
          lastSuccessfulAt: verifiedAt,
          baud: Number(probe.baud || 0) || discovery.profile.baud || 0
        });
        this.appendActivity('connection-broker-adapter-verified', { port: candidate.port, source: candidate.source, adapter: profile.adapterName, baud: profile.baud || null });
        return { ready: true, verified: true, port: candidate.port, candidate, attempt, attempts, discovery, profile, state: 'adapter-verified' };
      }
    }

    const bluetoothSeen = discovery.devices.some(isBluetooth);
    const outgoingSeen = discovery.ranked.some(device => device.outgoing || isObdLink(device));
    const anyIdentity = attempts.some(attempt => attempt.identified);
    const anyCandidate = discovery.candidates.length > 0;

    // One bounded Windows Bluetooth SPP repair is allowed before the broker stops. The repair
    // enables the remote Serial Port service, starts required Windows services, scans PnP again,
    // and then rebuilds the candidate list from scratch. It never loops more than once.
    if (!options.repairAttempted && options.allowRepair !== false && typeof this.repairBluetooth === 'function' && (bluetoothSeen || anyCandidate)) {
      let repairAttempt = null;
      try { repairAttempt = await this.repairBluetooth({ aggressive: false, targetName: discovery.profile.adapterName || 'OBDLink' }); }
      catch (error) { repairAttempt = { attempted: true, repaired: false, error: clean(error.message || error, 1200) }; }
      this.appendActivity('connection-broker-bluetooth-repair', { repaired: Boolean(repairAttempt?.repaired), newPorts: repairAttempt?.newPorts || [], requiresElevation: Boolean(repairAttempt?.requiresElevation) });
      const retried = await this.preflight({ ...options, repairAttempted: true, allowRepair: false });
      retried.repairAttempt = repairAttempt;
      if (retried.ready) {
        retried.state = 'adapter-verified-after-bluetooth-repair';
        return retried;
      }
      const deviceState = repairAttempt?.deviceState || null;
      let repairedState = 'bluetooth-spp-rebuild-failed';
      if (deviceState && deviceState.found === false) repairedState = 'bluetooth-adapter-unreachable';
      else if (deviceState && deviceState.found && (!deviceState.remembered || !deviceState.authenticated)) repairedState = 'bluetooth-pairing-required';
      retried.state = repairedState;
      const titles = {
        'bluetooth-adapter-unreachable': 'The OBDLink was not reachable during an active Bluetooth scan.',
        'bluetooth-pairing-required': 'Windows found the OBDLink, but it is not fully paired and authenticated.',
        'bluetooth-spp-rebuild-failed': 'Windows rebuilt the Bluetooth Serial Port service, but no openable OBDLink COM port appeared.'
      };
      retried.repair = {
        ...(retried.repair || {}),
        title: titles[repairedState],
        automaticRepairAttempted: true,
        requiresElevation: Boolean(repairAttempt?.requiresElevation),
        deviceState,
        serviceRebuilt: Boolean(repairAttempt?.serviceRebuilt),
        steps: repairedState === 'bluetooth-adapter-unreachable' ? [
          'Confirm the OBDLink is plugged into a powered OBD-II port and its light is on.',
          'Disconnect phones or tablets from the adapter and close their OBD apps.',
          'Open Bluetooth pairing, wake the adapter, and pair OBDLink MX+ again.',
          'Return to the same project; no verified PCM evidence will be discarded.'
        ] : repairedState === 'bluetooth-pairing-required' ? [
          'Open Windows Bluetooth pairing and finish pairing OBDLink MX+.',
          'Use the adapter PIN shown by the manufacturer if Windows requests one.',
          'Return to TunIQ and press Rebuild OBDLink Port once.',
          'Completed PCM evidence remains unchanged.'
        ] : [
          'TunIQ force-cycled the stale SPP driver instead of accepting an already-enabled service.',
          'Open Bluetooth pairing and remove/re-pair OBDLink MX+ if Windows still shows only dead COM ports.',
          'You may select a visible COM port manually; TunIQ will still require a real OBDLink/STN identity response.',
          'Return to the same project and continue after verification.'
        ]
      };
      return retried;
    }

    let state = 'adapter-not-detected';
    if (anyIdentity) state = 'adapter-identity-unverified';
    else if (options.repairAttempted && (bluetoothSeen || anyCandidate)) state = 'bluetooth-spp-rebuild-failed';
    else if (bluetoothSeen && !outgoingSeen) state = 'missing-outgoing-port';
    else if (anyCandidate) state = 'ports-unavailable';
    const title = state === 'bluetooth-spp-rebuild-failed'
      ? 'Windows rebuilt the Bluetooth Serial Port service, but no openable OBDLink COM port appeared.'
      : state === 'missing-outgoing-port'
      ? 'Windows did not expose a usable outgoing Bluetooth serial port.'
      : state === 'adapter-identity-unverified'
        ? 'A serial device answered, but TunIQ could not verify an OBDLink/STN identity.'
        : state === 'ports-unavailable'
          ? 'Windows exposed adapter candidates, but none could be opened and identified.'
          : 'TunIQ could not find an OBDLink serial adapter in Windows.';
    this.appendActivity('connection-broker-blocked', { state, attempts: attempts.map(item => ({ port: item.port, code: item.code, timedOut: item.timedOut })) });
    return {
      ready: false,
      verified: false,
      port: '',
      attempts,
      discovery,
      state,
      repair: {
        title,
        steps: [
          'Wake the OBDLink MX+ and keep it plugged into the powered vehicle.',
          'Disconnect the phone from OBDLink and close every other Windows OBD or serial application.',
          'In Windows Bluetooth settings, remove and re-pair OBDLink MX+ if no outgoing/client COM port appears.',
          'Return to TunIQ and retry once. TunIQ will test each eligible port only one time.'
        ]
      }
    };
  }
}

module.exports = {
  IntelligentConnectionManager,
  normalizePort,
  isObdLink,
  isBluetooth,
  isOutgoing,
  isIncoming,
  isSupportedAdapterIdentity,
  scoreDevice
};
