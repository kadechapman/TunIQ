const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function clean(value, max = 1000) { return String(value == null ? '' : value).replace(/\u0000/g, '').slice(0, max); }
function normalizePort(value = '') { return String(value || '').trim().toUpperCase(); }
function base(value = '') { return path.basename(String(value || '')).toLowerCase(); }

const EXCLUSIVE_PROCESS_PATTERNS = [
  /pcm\s*hammer/i, /pcmhammer/i, /pcm\s*logger/i, /pcmlogger/i,
  /obdwiz/i, /obdlink/i, /forscan/i, /alfaobd/i, /scanmaster/i,
  /touchscan/i, /scantool/i, /elmconfig/i, /carscanner/i
];
const SERIAL_TOOL_PATTERNS = [/putty/i, /teraterm/i, /realterm/i, /coolterm/i, /serial/i, /terminal/i, /powershell/i, /pwsh/i, /python/i];
const SAFE_OBSERVATION_PATTERNS = [/tunerpro/i, /universalpatcher/i, /universal\s*patcher/i];

function normalizeProcess(item = {}) {
  return {
    pid: Number(item.ProcessId ?? item.processId ?? item.pid ?? 0) || 0,
    parentPid: Number(item.ParentProcessId ?? item.parentProcessId ?? item.parentPid ?? 0) || 0,
    name: clean(item.Name ?? item.name ?? '', 260),
    executable: clean(item.ExecutablePath ?? item.executable ?? item.path ?? '', 1000),
    commandLine: clean(item.CommandLine ?? item.commandLine ?? '', 3000)
  };
}

function processMatches(patterns, processInfo) {
  const text = `${processInfo.name} ${processInfo.executable} ${processInfo.commandLine}`;
  return patterns.some(pattern => pattern.test(text));
}

function processIdentityMatches(patterns, processInfo) {
  // Match the actual process identity, not arbitrary folder names in the full command line.
  // A TunIQ source folder can legitimately contain words such as "OBDLink" without the
  // Electron/Node host process being an external OBD application.
  const text = `${processInfo.name || ''} ${processInfo.executable || ''}`;
  return patterns.some(pattern => pattern.test(text));
}

const TUNIQ_RUNTIME_HOSTS = /^(?:electron|node|cmd|conhost|powershell|pwsh)(?:\.exe)?$/i;

function collectTunIQRuntimePids(processes = [], currentPid = 0) {
  const normalized = processes.map(normalizeProcess);
  const byPid = new Map(normalized.map(item => [Number(item.pid), item]));
  const connected = new Set();
  const queue = [];
  if (Number(currentPid) && byPid.has(Number(currentPid))) {
    connected.add(Number(currentPid));
    queue.push(Number(currentPid));
  }
  while (queue.length) {
    const pid = queue.shift();
    const item = byPid.get(pid);
    const parentPid = Number(item?.parentPid || 0);
    if (parentPid && byPid.has(parentPid) && !connected.has(parentPid)) {
      connected.add(parentPid);
      queue.push(parentPid);
    }
    for (const child of normalized) {
      if (Number(child.parentPid) === pid && !connected.has(Number(child.pid))) {
        connected.add(Number(child.pid));
        queue.push(Number(child.pid));
      }
    }
  }

  const safe = new Set();
  for (const pid of connected) {
    const item = byPid.get(pid);
    const runtimeName = base(item?.name || item?.executable || '');
    if (pid === Number(currentPid) || TUNIQ_RUNTIME_HOSTS.test(runtimeName)) safe.add(pid);
  }

  // Fallback for source/portable launches where the current Electron PID can briefly
  // be absent from the CIM snapshot. Only generic runtime hosts with an explicit TunIQ
  // command line are accepted; actual OBD applications are never ignored by this rule.
  for (const item of normalized) {
    const runtimeName = base(item.name || item.executable || '');
    if (TUNIQ_RUNTIME_HOSTS.test(runtimeName) && /(?:^|[\\/ _-])tuniq(?:[\\/ _-]|$)/i.test(item.commandLine || '')) safe.add(Number(item.pid));
  }
  return safe;
}

function isPcmHammerProcess(processInfo = {}) {
  return /pcm\s*hammer|pcmhammer/i.test(`${processInfo.name || ''} ${processInfo.executable || ''} ${processInfo.commandLine || ''}`);
}

function pcmHammerRootPids(processes = []) {
  const pcm = processes.filter(isPcmHammerProcess);
  const pcmPids = new Set(pcm.map(item => Number(item.pid)).filter(Boolean));
  return pcm.filter(item => !pcmPids.has(Number(item.parentPid))).map(item => Number(item.pid)).filter(Boolean);
}

function runPowerShellProcessInventory(timeoutMs = 6000) {
  if (process.platform !== 'win32') return Promise.resolve([]);
  return new Promise(resolve => {
    const command = "Get-CimInstance Win32_Process | Select-Object ProcessId,ParentProcessId,Name,ExecutablePath,CommandLine | ConvertTo-Json -Compress";
    let stdout = ''; let finished = false;
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command], { windowsHide: true });
    const timer = setTimeout(() => { if (!finished) { finished = true; try { child.kill(); } catch {} resolve([]); } }, timeoutMs);
    child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
    child.on('error', () => { if (!finished) { finished = true; clearTimeout(timer); resolve([]); } });
    child.on('close', () => {
      if (finished) return; finished = true; clearTimeout(timer);
      try { const parsed = JSON.parse(stdout || '[]'); resolve((Array.isArray(parsed) ? parsed : [parsed]).map(normalizeProcess)); }
      catch { resolve([]); }
    });
  });
}

function killWindowsProcess(pid) {
  return new Promise(resolve => {
    if (process.platform !== 'win32' || !Number(pid)) return resolve(false);
    const child = spawn('taskkill.exe', ['/PID', String(pid), '/T', '/F'], { windowsHide: true });
    child.on('error', () => resolve(false));
    child.on('close', code => resolve(code === 0));
  });
}

class HardwareSessionGuard {
  constructor(options = {}) {
    this.dataRoot = options.dataRoot || (() => process.cwd());
    this.processProvider = options.processProvider || runPowerShellProcessInventory;
    this.killProvider = options.killProvider || killWindowsProcess;
    this.platform = options.platform || process.platform;
    this.currentPid = Number(options.currentPid || process.pid);
  }

  registryFile() { return path.join(this.dataRoot(), 'Runtime', 'hardware-process-registry.json'); }
  loadRegistry() { const value = readJson(this.registryFile(), { version: 1, processes: [] }); return { version: 1, processes: Array.isArray(value?.processes) ? value.processes : [] }; }
  saveRegistry(registry) { writeJson(this.registryFile(), { version: 1, updatedAt: new Date().toISOString(), processes: registry.processes || [] }); }

  registerOwnedProcess(pid, executable, sessionId = '') {
    if (!Number(pid)) return null;
    const registry = this.loadRegistry();
    registry.processes = registry.processes.filter(item => Number(item.pid) !== Number(pid));
    const entry = { pid: Number(pid), executable: path.resolve(String(executable || '')), sessionId: clean(sessionId, 160), startedAt: new Date().toISOString(), owner: 'TunIQ' };
    registry.processes.push(entry); this.saveRegistry(registry); return entry;
  }

  releaseOwnedProcess(pid) {
    const registry = this.loadRegistry();
    const before = registry.processes.length;
    registry.processes = registry.processes.filter(item => Number(item.pid) !== Number(pid));
    if (registry.processes.length !== before) this.saveRegistry(registry);
    return before !== registry.processes.length;
  }

  async cleanupOwnedOrphans(inventory = null) {
    const processes = (Array.isArray(inventory) ? inventory : await this.processProvider()).map(normalizeProcess);
    const byPid = new Map(processes.map(item => [Number(item.pid), item]));
    const registry = this.loadRegistry();
    const kept = []; const cleaned = []; const stale = []; const attempted = [];
    for (const owned of registry.processes) {
      const live = byPid.get(Number(owned.pid));
      if (!live) { stale.push({ ...owned, reason: 'not-running' }); continue; }
      const expected = base(owned.executable); const actual = base(live.executable || live.name);
      const looksLikePcmHammer = /pcmhammer|pcm\s*hammer/i.test(`${expected} ${actual} ${live.name}`);
      const executableMatches = Boolean(expected && actual && (expected === actual || base(live.name) === expected));
      if (!looksLikePcmHammer || !executableMatches) { kept.push(owned); continue; }
      attempted.push({ pid: Number(owned.pid), name: live.name, executable: live.executable, sessionId: owned.sessionId });
      const killed = await this.killProvider(Number(owned.pid), live);
      if (killed) cleaned.push({ pid: Number(owned.pid), name: live.name, executable: live.executable, sessionId: owned.sessionId });
      else kept.push(owned);
    }
    registry.processes = kept; this.saveRegistry(registry);
    return { cleaned, stale, retained: kept, attempted };
  }

  classify(processInfo, selectedPort = '', expectedExecutable = '', safeRuntimePids = new Set()) {
    const port = normalizePort(selectedPort);
    const expected = base(expectedExecutable);
    if (!processInfo.pid || processInfo.pid === this.currentPid || safeRuntimePids.has(Number(processInfo.pid))) return null;
    const actual = base(processInfo.executable || processInfo.name);
    // Integrated operations always sweep all PCM Hammer GUI/CLI trees before launch.
    // Never let a surviving or stale PCM Hammer row become a permanent guard loop.
    if (isPcmHammerProcess(processInfo)) return null;
    if (processIdentityMatches(EXCLUSIVE_PROCESS_PATTERNS, processInfo)) return { kind: 'conflict', reason: 'This OBD application may exclusively own the adapter.' };
    const mentionsPort = Boolean(port && new RegExp(`(?:^|[^A-Z0-9])${port}(?:$|[^A-Z0-9])`, 'i').test(processInfo.commandLine || ''));
    if (mentionsPort && processMatches(SERIAL_TOOL_PATTERNS, processInfo)) return { kind: 'conflict', reason: `${port} appears in this serial tool's command line.` };
    if (mentionsPort && processMatches(SAFE_OBSERVATION_PATTERNS, processInfo)) return { kind: 'warning', reason: `${port} appears in another tuning tool's command line.` };
    return null;
  }

  async inspect({ selectedPort = '', expectedExecutable = '' } = {}) {
    const firstInventory = (await this.processProvider()).map(normalizeProcess);

    // v1.8.6 hard reset: integrated PCM Hammer owns the whole PCM Hammer runtime.
    // Close every GUI/CLI tree, whether registered, orphaned, or manually launched,
    // then prove Windows removed it before evaluating unrelated OBD conflicts.
    const forcedRoots = pcmHammerRootPids(firstInventory);
    const forcedAttempts = [];
    for (const pid of forcedRoots) {
      const live = firstInventory.find(item => Number(item.pid) === pid) || {};
      const killed = await this.killProvider(pid, live);
      forcedAttempts.push({ pid, name: live.name || 'PCM Hammer', executable: live.executable || '', killed: Boolean(killed), scope: 'all-pcmhammer-tree' });
    }

    const cleanup = await this.cleanupOwnedOrphans(firstInventory);

    // taskkill /T can remove a registered PCM Hammer root and its CLI child, but the
    // original inventory still contains both rows. Never classify that stale snapshot.
    // Give Windows a moment to retire the process tree, then inspect a fresh inventory.
    let activeInventory = firstInventory;
    let rescannedAfterCleanup = false;
    let cleanupSettlePasses = 0;
    const attemptedPids = new Set([...(cleanup.attempted || []).map(item => Number(item.pid)), ...forcedRoots].filter(Boolean));
    if (attemptedPids.size > 0 || cleanup.cleaned.length > 0 || cleanup.stale.length > 0 || forcedAttempts.length > 0) {
      // Windows can return a non-zero taskkill result while the GUI/CLI tree is already
      // exiting. Never trust the pre-cleanup snapshot or the taskkill exit code alone.
      // Poll fresh inventories until every registered root PID is gone or the settle
      // window expires, then classify only the newest inventory.
      const maxPasses = this.platform === 'win32' ? 20 : 3;
      for (let pass = 0; pass < maxPasses; pass += 1) {
        await new Promise(resolve => setTimeout(resolve, this.platform === 'win32' ? 250 : 5));
        activeInventory = (await this.processProvider()).map(normalizeProcess);
        cleanupSettlePasses = pass + 1;
        rescannedAfterCleanup = true;
        if (![...attemptedPids].some(pid => activeInventory.some(item => Number(item.pid) === pid)) && !activeInventory.some(isPcmHammerProcess)) break;
      }
    }

    const safeRuntimePids = collectTunIQRuntimePids(activeInventory, this.currentPid);
    const conflicts = []; const warnings = [];
    for (const item of activeInventory) {
      const result = this.classify(item, selectedPort, expectedExecutable, safeRuntimePids);
      if (!result) continue;
      const entry = { pid: item.pid, parentPid: item.parentPid, name: item.name, executable: item.executable, commandLine: item.commandLine, reason: result.reason };
      (result.kind === 'conflict' ? conflicts : warnings).push(entry);
    }
    return {
      version: 3, inspectedAt: new Date().toISOString(), selectedPort: normalizePort(selectedPort),
      blocked: conflicts.length > 0, conflicts, warnings, cleanedOwnedProcesses: cleanup.cleaned, forcedPcmHammerCleanup: forcedAttempts,
      rescannedAfterCleanup, cleanupSettlePasses, attemptedOwnedProcesses: cleanup.attempted || [], initialInventoryCount: firstInventory.length, inventoryCount: activeInventory.length,
      ignoredTunIQRuntimePids: [...safeRuntimePids].sort((a, b) => a - b),
      inventorySupported: this.platform === 'win32' || Boolean(this.processProvider)
    };
  }
}

module.exports = { HardwareSessionGuard, normalizeProcess, isPcmHammerProcess, pcmHammerRootPids, collectTunIQRuntimePids, EXCLUSIVE_PROCESS_PATTERNS, SERIAL_TOOL_PATTERNS };
