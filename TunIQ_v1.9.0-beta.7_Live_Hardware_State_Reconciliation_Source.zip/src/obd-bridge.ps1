param(
  [ValidateSet('List','Probe','Identify','Sample','LockProbe','BluetoothRepair')]
  [string]$Action = 'List',
  [string]$PortName = '',
  [int]$Baud = 0,
  [string]$TargetName = 'OBDLink',
  [switch]$Aggressive
)

$ErrorActionPreference = 'Stop'

function Write-JsonResult($Value) {
  [Console]::Out.WriteLine(($Value | ConvertTo-Json -Compress -Depth 8))
}

function Get-SerialDevices {
  $items = @()
  try {
    $entities = Get-CimInstance Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match '\(COM\d+\)' }
    foreach ($entity in $entities) {
      $match = [regex]::Match([string]$entity.Name, '\((COM\d+)\)')
      if ($match.Success) {
        $items += [pscustomobject]@{
          port = $match.Groups[1].Value
          name = [string]$entity.Name
          manufacturer = [string]$entity.Manufacturer
          deviceId = [string]$entity.DeviceID
          status = [string]$entity.Status
          service = [string]$entity.Service
          classGuid = [string]$entity.ClassGuid
          parentId = ''
          containerId = ''
          location = ''
        }
      }
    }
  } catch {
    try {
      $entities = Get-WmiObject Win32_PnPEntity -ErrorAction Stop | Where-Object { $_.Name -match '\(COM\d+\)' }
      foreach ($entity in $entities) {
        $match = [regex]::Match([string]$entity.Name, '\((COM\d+)\)')
        if ($match.Success) {
          $items += [pscustomobject]@{
            port = $match.Groups[1].Value
            name = [string]$entity.Name
            manufacturer = [string]$entity.Manufacturer
            deviceId = [string]$entity.DeviceID
            status = [string]$entity.Status
            service = [string]$entity.Service
            classGuid = [string]$entity.ClassGuid
            parentId = ''
            containerId = ''
            location = ''
          }
        }
      }
    } catch {}
  }

  try {
    $registry = Get-ItemProperty 'HKLM:\HARDWARE\DEVICEMAP\SERIALCOMM' -ErrorAction Stop
    foreach ($property in $registry.PSObject.Properties) {
      if ($property.Name -notmatch '^PS' -and [string]$property.Value -match '^COM\d+$') {
        $port = [string]$property.Value
        if (-not ($items | Where-Object { $_.port -eq $port })) {
          $items += [pscustomobject]@{
            port = $port
            name = "Serial Port ($port)"
            manufacturer = ''
            deviceId = [string]$property.Name
            status = 'Unknown'
            service = ''
            classGuid = ''
            parentId = ''
            containerId = ''
            location = ''
          }
        }
      }
    }
  } catch {}

  # Get-PnpDevice exposes parent/container information that lets TunIQ recognize the two
  # generic “Standard Serial over Bluetooth link” ports as a paired SPP device even when
  # Windows does not include “OBDLink” or “Outgoing” in the friendly name.
  try {
    $pnpPorts = Get-PnpDevice -Class Ports -ErrorAction Stop | Where-Object { $_.FriendlyName -match '\(COM\d+\)' }
    foreach ($device in $pnpPorts) {
      $match = [regex]::Match([string]$device.FriendlyName, '\((COM\d+)\)')
      if (-not $match.Success) { continue }
      $port = $match.Groups[1].Value
      $existing = $items | Where-Object { $_.port -eq $port } | Select-Object -First 1
      if (-not $existing) {
        $existing = [pscustomobject]@{
          port = $port; name = [string]$device.FriendlyName; manufacturer = '';
          deviceId = [string]$device.InstanceId; status = [string]$device.Status;
          service = ''; classGuid = ''; parentId = ''; containerId = ''; location = ''
        }
        $items += $existing
      }
      foreach ($property in @(
        @{ Key = 'DEVPKEY_Device_Parent'; Field = 'parentId' },
        @{ Key = 'DEVPKEY_Device_ContainerId'; Field = 'containerId' },
        @{ Key = 'DEVPKEY_Device_LocationInfo'; Field = 'location' },
        @{ Key = 'DEVPKEY_Device_BusReportedDeviceDesc'; Field = 'busDescription' }
      )) {
        try {
          $value = Get-PnpDeviceProperty -InstanceId $device.InstanceId -KeyName $property.Key -ErrorAction Stop
          if ($value.Data) { $existing | Add-Member -NotePropertyName $property.Field -NotePropertyValue ([string]$value.Data) -Force }
        } catch {}
      }
    }
  } catch {}

  # Final fallback: include every port Windows exposes through System.IO.Ports. Registry-only
  # Bluetooth ports usually carry a BthModem device name, which is preserved above when known.
  try {
    foreach ($port in [System.IO.Ports.SerialPort]::GetPortNames()) {
      if (-not ($items | Where-Object { $_.port -eq $port })) {
        $items += [pscustomobject]@{
          port = [string]$port; name = "Serial Port ($port)"; manufacturer = '';
          deviceId = ''; status = 'Unknown'; service = ''; classGuid = '';
          parentId = ''; containerId = ''; location = ''
        }
      }
    }
  } catch {}

  foreach ($item in $items) {
    $text = "$($item.name) $($item.deviceId) $($item.service) $($item.parentId) $($item.busDescription)"
    $item | Add-Member -NotePropertyName bluetooth -NotePropertyValue ([bool]($text -match 'Bluetooth|BTHENUM|BthModem|BTHPORT|SPP')) -Force
    $item | Add-Member -NotePropertyName outgoing -NotePropertyValue ([bool]($text -match 'Outgoing|Client')) -Force
    $item | Add-Member -NotePropertyName incoming -NotePropertyValue ([bool]($text -match 'Incoming|Server')) -Force
    $pairKey = if ($item.containerId) { [string]$item.containerId } elseif ($item.parentId) { [string]$item.parentId } else { '' }
    $item | Add-Member -NotePropertyName pairKey -NotePropertyValue $pairKey -Force
  }

  return @($items | Group-Object port | ForEach-Object { $_.Group | Select-Object -First 1 } | Sort-Object port)
}


function Ensure-BluetoothSupportServices {
  $results = @()
  $serviceNames = @('bthserv','DeviceAssociationService')
  try { $serviceNames += @(Get-Service -Name 'BluetoothUserService_*' -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) } catch {}
  try { $serviceNames += @(Get-Service -Name 'DeviceAssociationBrokerSvc_*' -ErrorAction SilentlyContinue | ForEach-Object { $_.Name }) } catch {}
  foreach ($name in @($serviceNames | Select-Object -Unique)) {
    try {
      $service = Get-Service -Name $name -ErrorAction Stop
      $before = [string]$service.Status
      if ($service.Status -ne 'Running') {
        Start-Service -Name $name -ErrorAction Stop
        $service.WaitForStatus('Running', [TimeSpan]::FromSeconds(8))
      }
      $results += [pscustomobject]@{ name = $name; before = $before; after = [string](Get-Service -Name $name).Status; success = $true }
    } catch {
      $results += [pscustomobject]@{ name = $name; success = $false; error = $_.Exception.Message }
    }
  }
  return @($results)
}

function Add-BluetoothNativeType {
  if ('TunIQBluetoothNative' -as [type]) { return }
  Add-Type -TypeDefinition @"
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;

public static class TunIQBluetoothNative
{
    const uint ERROR_SUCCESS = 0;
    const uint ERROR_MORE_DATA = 234;
    const uint E_INVALIDARG = 0x80070057;
    const uint SERVICE_DISABLE = 0;
    const uint SERVICE_ENABLE = 1;
    static readonly Guid SerialPortService = new Guid("00001101-0000-1000-8000-00805F9B34FB");

    [StructLayout(LayoutKind.Sequential)]
    public struct SYSTEMTIME
    {
        public ushort Year, Month, DayOfWeek, Day, Hour, Minute, Second, Milliseconds;
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct BLUETOOTH_DEVICE_INFO
    {
        public int dwSize;
        public ulong Address;
        public uint ulClassofDevice;
        [MarshalAs(UnmanagedType.Bool)] public bool fConnected;
        [MarshalAs(UnmanagedType.Bool)] public bool fRemembered;
        [MarshalAs(UnmanagedType.Bool)] public bool fAuthenticated;
        public SYSTEMTIME stLastSeen;
        public SYSTEMTIME stLastUsed;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 248)] public string szName;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct BLUETOOTH_DEVICE_SEARCH_PARAMS
    {
        public int dwSize;
        [MarshalAs(UnmanagedType.Bool)] public bool fReturnAuthenticated;
        [MarshalAs(UnmanagedType.Bool)] public bool fReturnRemembered;
        [MarshalAs(UnmanagedType.Bool)] public bool fReturnUnknown;
        [MarshalAs(UnmanagedType.Bool)] public bool fReturnConnected;
        [MarshalAs(UnmanagedType.Bool)] public bool fIssueInquiry;
        public byte cTimeoutMultiplier;
        public IntPtr hRadio;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct BLUETOOTH_FIND_RADIO_PARAMS { public int dwSize; }

    [DllImport("bthprops.cpl", SetLastError = true)]
    static extern IntPtr BluetoothFindFirstRadio(ref BLUETOOTH_FIND_RADIO_PARAMS pbtfrp, out IntPtr phRadio);
    [DllImport("bthprops.cpl", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool BluetoothFindNextRadio(IntPtr hFind, out IntPtr phRadio);
    [DllImport("bthprops.cpl", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool BluetoothFindRadioClose(IntPtr hFind);
    [DllImport("bthprops.cpl", CharSet = CharSet.Unicode, SetLastError = true)]
    static extern IntPtr BluetoothFindFirstDevice(ref BLUETOOTH_DEVICE_SEARCH_PARAMS pbtsp, ref BLUETOOTH_DEVICE_INFO pbtdi);
    [DllImport("bthprops.cpl", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool BluetoothFindNextDevice(IntPtr hFind, ref BLUETOOTH_DEVICE_INFO pbtdi);
    [DllImport("bthprops.cpl", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool BluetoothFindDeviceClose(IntPtr hFind);
    [DllImport("bthprops.cpl", SetLastError = true)]
    static extern uint BluetoothSetServiceState(IntPtr hRadio, ref BLUETOOTH_DEVICE_INFO pbtdi, ref Guid pGuidService, uint dwServiceFlags);
    [DllImport("bthprops.cpl", EntryPoint = "BluetoothEnumerateInstalledServices", SetLastError = true)]
    static extern uint BluetoothEnumerateInstalledServicesCount(IntPtr hRadio, ref BLUETOOTH_DEVICE_INFO pbtdi, ref uint pcServiceInout, IntPtr pGuidServices);
    [DllImport("bthprops.cpl", EntryPoint = "BluetoothEnumerateInstalledServices", SetLastError = true)]
    static extern uint BluetoothEnumerateInstalledServicesArray(IntPtr hRadio, ref BLUETOOTH_DEVICE_INFO pbtdi, ref uint pcServiceInout, [Out] Guid[] pGuidServices);
    [DllImport("kernel32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)] static extern bool CloseHandle(IntPtr hObject);

    public sealed class ServiceResult
    {
        public string Name = "";
        public string Address = "";
        public bool Connected;
        public bool Remembered;
        public bool Authenticated;
        public bool Matched;
        public bool InquiryPass;
        public bool SppInstalledBefore;
        public bool SppInstalledAfter;
        public bool ForceCycled;
        public uint EnumerateBeforeCode;
        public uint DisableCode;
        public uint EnableCode;
        public uint EnumerateAfterCode;
        public string Error = "";
    }

    static bool NameMatches(string name, string target)
    {
        string value = name ?? "";
        string requested = (target ?? "").Trim();
        return value.IndexOf("OBDLink", StringComparison.OrdinalIgnoreCase) >= 0 ||
               value.IndexOf("ScanTool", StringComparison.OrdinalIgnoreCase) >= 0 ||
               value.IndexOf("STN", StringComparison.OrdinalIgnoreCase) >= 0 ||
               value.IndexOf("MX+", StringComparison.OrdinalIgnoreCase) >= 0 ||
               value.IndexOf("MX Plus", StringComparison.OrdinalIgnoreCase) >= 0 ||
               (!String.IsNullOrWhiteSpace(requested) && value.IndexOf(requested, StringComparison.OrdinalIgnoreCase) >= 0);
    }

    static Tuple<uint, Guid[]> InstalledServices(IntPtr radio, ref BLUETOOTH_DEVICE_INFO info)
    {
        uint count = 0;
        uint first = BluetoothEnumerateInstalledServicesCount(radio, ref info, ref count, IntPtr.Zero);
        if (count == 0) return Tuple.Create(first, new Guid[0]);
        var services = new Guid[count];
        uint capacity = count;
        uint code = BluetoothEnumerateInstalledServicesArray(radio, ref info, ref capacity, services);
        if (capacity < services.Length) Array.Resize(ref services, (int)capacity);
        return Tuple.Create(code, services);
    }

    static void SearchRadio(IntPtr radio, string target, bool inquiry, bool forceCycle, Dictionary<ulong, ServiceResult> results)
    {
        var search = new BLUETOOTH_DEVICE_SEARCH_PARAMS
        {
            dwSize = Marshal.SizeOf(typeof(BLUETOOTH_DEVICE_SEARCH_PARAMS)),
            fReturnAuthenticated = true,
            fReturnRemembered = true,
            fReturnUnknown = inquiry,
            fReturnConnected = true,
            fIssueInquiry = inquiry,
            cTimeoutMultiplier = inquiry ? (byte)4 : (byte)2,
            hRadio = radio
        };
        var info = new BLUETOOTH_DEVICE_INFO { dwSize = Marshal.SizeOf(typeof(BLUETOOTH_DEVICE_INFO)) };
        IntPtr deviceFind = BluetoothFindFirstDevice(ref search, ref info);
        if (deviceFind == IntPtr.Zero) return;
        try
        {
            do
            {
                string name = info.szName ?? "";
                bool matched = NameMatches(name, target);
                if (matched && !results.ContainsKey(info.Address))
                {
                    var result = new ServiceResult
                    {
                        Name = name,
                        Address = info.Address.ToString("X12"),
                        Connected = info.fConnected,
                        Remembered = info.fRemembered,
                        Authenticated = info.fAuthenticated,
                        Matched = true,
                        InquiryPass = inquiry
                    };
                    try
                    {
                        var before = InstalledServices(radio, ref info);
                        result.EnumerateBeforeCode = before.Item1;
                        result.SppInstalledBefore = before.Item2.Any(value => value == SerialPortService);
                        if (forceCycle)
                        {
                            Guid sppDisable = SerialPortService;
                            result.DisableCode = BluetoothSetServiceState(radio, ref info, ref sppDisable, SERVICE_DISABLE);
                            result.ForceCycled = result.DisableCode == ERROR_SUCCESS || result.DisableCode == E_INVALIDARG;
                            Thread.Sleep(900);
                        }
                        Guid sppEnable = SerialPortService;
                        result.EnableCode = BluetoothSetServiceState(radio, ref info, ref sppEnable, SERVICE_ENABLE);
                        Thread.Sleep(900);
                        var after = InstalledServices(radio, ref info);
                        result.EnumerateAfterCode = after.Item1;
                        result.SppInstalledAfter = after.Item2.Any(value => value == SerialPortService) || result.EnableCode == ERROR_SUCCESS || result.EnableCode == E_INVALIDARG;
                    }
                    catch (Exception ex) { result.Error = ex.Message; }
                    results[info.Address] = result;
                }
                info.dwSize = Marshal.SizeOf(typeof(BLUETOOTH_DEVICE_INFO));
            }
            while (BluetoothFindNextDevice(deviceFind, ref info));
        }
        finally { BluetoothFindDeviceClose(deviceFind); }
    }

    public static ServiceResult[] RebuildSerialPortService(string targetText, bool forceCycle, bool issueInquiry)
    {
        var results = new Dictionary<ulong, ServiceResult>();
        var radioParams = new BLUETOOTH_FIND_RADIO_PARAMS { dwSize = Marshal.SizeOf(typeof(BLUETOOTH_FIND_RADIO_PARAMS)) };
        IntPtr radio;
        IntPtr radioFind = BluetoothFindFirstRadio(ref radioParams, out radio);
        if (radioFind == IntPtr.Zero) return results.Values.ToArray();
        try
        {
            do
            {
                SearchRadio(radio, targetText, false, forceCycle, results);
                if (issueInquiry && results.Count == 0) SearchRadio(radio, targetText, true, forceCycle, results);
                CloseHandle(radio);
            }
            while (BluetoothFindNextRadio(radioFind, out radio));
        }
        finally { BluetoothFindRadioClose(radioFind); }
        return results.Values.ToArray();
    }
}
"@
}

function Invoke-BluetoothSerialRepair([string]$RequestedTarget, [bool]$UseAggressiveRepair) {
  $before = @(Get-SerialDevices)
  $services = @(Ensure-BluetoothSupportServices)
  $native = @()
  $nativeError = ''
  try {
    Add-BluetoothNativeType
    # A stale SPP installation can report "already enabled" while its COM device is dead.
    # Force-cycling the service removes and reinstalls the Windows driver mapping.
    $native = @([TunIQBluetoothNative]::RebuildSerialPortService($RequestedTarget, $true, $true))
  } catch {
    $nativeError = $_.Exception.Message
  }

  $matched = @($native | Where-Object { $_.Matched })
  $deviceState = [pscustomobject]@{
    found = [bool]($matched.Count -gt 0)
    remembered = [bool](@($matched | Where-Object { $_.Remembered }).Count -gt 0)
    authenticated = [bool](@($matched | Where-Object { $_.Authenticated }).Count -gt 0)
    connected = [bool](@($matched | Where-Object { $_.Connected }).Count -gt 0)
    inquiryUsed = [bool](@($matched | Where-Object { $_.InquiryPass }).Count -gt 0)
    sppInstalledBefore = [bool](@($matched | Where-Object { $_.SppInstalledBefore }).Count -gt 0)
    sppInstalledAfter = [bool](@($matched | Where-Object { $_.SppInstalledAfter }).Count -gt 0)
    serviceCycled = [bool](@($matched | Where-Object { $_.ForceCycled }).Count -gt 0)
    devices = @($matched | ForEach-Object { [pscustomobject]@{
      name = $_.Name; address = $_.Address; connected = $_.Connected; remembered = $_.Remembered;
      authenticated = $_.Authenticated; inquiryPass = $_.InquiryPass; sppInstalledBefore = $_.SppInstalledBefore;
      sppInstalledAfter = $_.SppInstalledAfter; forceCycled = $_.ForceCycled; disableCode = $_.DisableCode;
      enableCode = $_.EnableCode; error = $_.Error
    } })
  }

  $restartResults = @()
  $requiresElevation = $false
  if ($UseAggressiveRepair) {
    try {
      $targets = Get-PnpDevice -Class Ports -ErrorAction Stop | Where-Object {
        $_.InstanceId -match '^BTHENUM\\' -or $_.FriendlyName -match 'Bluetooth|OBDLink|ScanTool|STN'
      }
      foreach ($device in $targets) {
        try {
          $output = & pnputil.exe /restart-device "$($device.InstanceId)" 2>&1
          $code = $LASTEXITCODE
          if ($code -ne 0 -and ($output -join ' ') -match 'access|administrator|denied|privilege') { $requiresElevation = $true }
          $restartResults += [pscustomobject]@{ instanceId = [string]$device.InstanceId; name = [string]$device.FriendlyName; exitCode = $code; output = ($output -join ' ') }
        } catch {
          if ($_.Exception.Message -match 'access|administrator|denied|privilege') { $requiresElevation = $true }
          $restartResults += [pscustomobject]@{ instanceId = [string]$device.InstanceId; name = [string]$device.FriendlyName; exitCode = -1; output = $_.Exception.Message }
        }
      }
    } catch {}
  }

  $scanOutput = ''
  try { $scanOutput = ((& pnputil.exe /scan-devices 2>&1) -join ' ') } catch { $scanOutput = $_.Exception.Message }

  $beforePorts = @($before | ForEach-Object { [string]$_.port } | Where-Object { $_ } | Select-Object -Unique)
  $after = @()
  $newPorts = @()
  $deadline = [DateTime]::UtcNow.AddSeconds(18)
  do {
    Start-Sleep -Milliseconds 900
    $after = @(Get-SerialDevices)
    $afterPorts = @($after | ForEach-Object { [string]$_.port } | Where-Object { $_ } | Select-Object -Unique)
    $newPorts = @($afterPorts | Where-Object { $port = $_; -not ($beforePorts -contains $port) })
    if ($newPorts.Count -gt 0) { break }
  } while ([DateTime]::UtcNow -lt $deadline)

  return [pscustomobject]@{
    success = $true
    attempted = $true
    # "repaired" means Windows exposed a new COM endpoint. A successful service cycle is
    # reported separately and still must pass TunIQ's live open-and-identify broker.
    repaired = [bool]($newPorts.Count -gt 0)
    serviceRebuilt = [bool]$deviceState.serviceCycled
    target = $RequestedTarget
    aggressive = $UseAggressiveRepair
    services = $services
    native = $native
    nativeError = $nativeError
    deviceState = $deviceState
    restartResults = $restartResults
    requiresElevation = $requiresElevation
    scanOutput = $scanOutput
    beforeDevices = $before
    afterDevices = $after
    newPorts = $newPorts
  }
}

function Open-SerialPort([string]$Name, [int]$Speed) {
  $port = New-Object System.IO.Ports.SerialPort
  $port.PortName = $Name
  $port.BaudRate = $Speed
  $port.Parity = [System.IO.Ports.Parity]::None
  $port.DataBits = 8
  $port.StopBits = [System.IO.Ports.StopBits]::One
  $port.Handshake = [System.IO.Ports.Handshake]::None
  $port.ReadTimeout = 350
  $port.WriteTimeout = 1200
  $port.NewLine = "`r"
  $port.Encoding = [System.Text.Encoding]::ASCII
  $port.DtrEnable = $false
  $port.RtsEnable = $false
  $port.Open()
  Start-Sleep -Milliseconds 220
  return $port
}

function Send-ObdCommand($Port, [string]$Command, [int]$TimeoutMs = 1800) {
  try { $Port.DiscardInBuffer() } catch {}
  $Port.Write("$Command`r")
  $deadline = [DateTime]::UtcNow.AddMilliseconds($TimeoutMs)
  $text = ''
  while ([DateTime]::UtcNow -lt $deadline) {
    Start-Sleep -Milliseconds 35
    try { $text += $Port.ReadExisting() } catch {}
    if ($text.Contains('>')) { break }
  }
  return $text.Trim()
}

function Initialize-Adapter($Port, [bool]$Reset) {
  $raw = @{}
  if ($Reset) {
    $raw.ATZ = Send-ObdCommand $Port 'ATZ' 2800
    Start-Sleep -Milliseconds 180
  }
  $raw.ATE0 = Send-ObdCommand $Port 'ATE0' 1000
  $raw.ATL0 = Send-ObdCommand $Port 'ATL0' 1000
  $raw.ATS0 = Send-ObdCommand $Port 'ATS0' 1000
  $raw.ATH0 = Send-ObdCommand $Port 'ATH0' 1000
  if ($Reset) { $raw.ATSP0 = Send-ObdCommand $Port 'ATSP0' 1200 }
  return $raw
}


function Identify-Adapter([string]$Name, [int]$RequestedBaud) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  $rates = if ($RequestedBaud -gt 0) { @($RequestedBaud) } else { @(115200, 38400, 9600) }
  $lastError = ''
  foreach ($rate in $rates) {
    $port = $null
    try {
      $port = Open-SerialPort $Name $rate
      try { $null = $port.ReadExisting() } catch {}
      $null = Send-ObdCommand $port 'ATE0' 900
      $ati = Send-ObdCommand $port 'ATI' 1800
      if ([string]::IsNullOrWhiteSpace($ati) -or $ati -notmatch '>') {
        $null = Send-ObdCommand $port 'ATZ' 2600
        Start-Sleep -Milliseconds 350
        $ati = Send-ObdCommand $port 'ATI' 1800
      }
      if ([string]::IsNullOrWhiteSpace($ati) -or $ati -match 'UNABLE TO CONNECT|NO DATA' -or $ati -notmatch '[A-Za-z0-9]') {
        throw "No adapter identity response at $rate baud."
      }
      $description = Send-ObdCommand $port 'AT@1' 1200
      $deviceId = Send-ObdCommand $port 'STDI' 1200
      $identity = "$ati $description $deviceId"
      $recognized = [bool]($identity -match 'OBDLink|STN\d+|ScanTool|OBDX|AllPro|AVT|ELM327')
      return [pscustomobject]@{
        success = $true
        available = $true
        locked = $false
        identified = $true
        recognized = $recognized
        port = $Name
        baud = $rate
        adapter = $ati
        description = $description
        deviceId = $deviceId
        identity = $identity
      }
    } catch {
      $lastError = $_.Exception.Message
    } finally {
      if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
      if ($port) { try { $port.Dispose() } catch {} }
    }
  }
  throw "Could not identify an adapter on $Name. $lastError"
}

function Probe-Adapter([string]$Name, [int]$RequestedBaud) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  $rates = if ($RequestedBaud -gt 0) { @($RequestedBaud) } else { @(115200, 38400, 9600) }
  $lastError = ''
  foreach ($rate in $rates) {
    $port = $null
    try {
      $port = Open-SerialPort $Name $rate
      $init = Initialize-Adapter $port $true
      $ati = Send-ObdCommand $port 'ATI' 1400
      if ([string]::IsNullOrWhiteSpace($ati) -or $ati -match 'UNABLE TO CONNECT') { throw "No adapter response at $rate baud." }
      $description = Send-ObdCommand $port 'AT@1' 1200
      $deviceId = Send-ObdCommand $port 'STDI' 1200
      $voltage = Send-ObdCommand $port 'ATRV' 1200
      $protocol = Send-ObdCommand $port 'ATDP' 1200
      $vin = Send-ObdCommand $port '0902' 3000
      return [pscustomobject]@{
        success = $true
        port = $Name
        baud = $rate
        adapter = $ati
        description = $description
        deviceId = $deviceId
        voltageRaw = $voltage
        protocol = $protocol
        vinRaw = $vin
        init = $init
      }
    } catch {
      $lastError = $_.Exception.Message
    } finally {
      if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
      if ($port) { try { $port.Dispose() } catch {} }
    }
  }
  throw "Could not communicate with $Name. $lastError"
}


function Test-PortLock([string]$Name, [int]$Speed) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  if ($Speed -le 0) { $Speed = 115200 }
  $port = $null
  try {
    $port = Open-SerialPort $Name $Speed
    return [pscustomobject]@{ success = $true; available = $true; locked = $false; port = $Name; baud = $Speed }
  } catch {
    $message = $_.Exception.Message
    return [pscustomobject]@{ success = $true; available = $false; locked = $true; port = $Name; baud = $Speed; error = $message }
  } finally {
    if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
    if ($port) { try { $port.Dispose() } catch {} }
  }
}

function Read-Sample([string]$Name, [int]$Speed) {
  if ([string]::IsNullOrWhiteSpace($Name)) { throw 'A COM port is required.' }
  if ($Speed -le 0) { $Speed = 115200 }
  $port = $null
  try {
    $port = Open-SerialPort $Name $Speed
    $null = Initialize-Adapter $port $false
    $commands = @('010C','010D','0105','010F','0111','010B','0110','0106','0107','010E','0104','0123')
    $responses = @{}
    foreach ($command in $commands) {
      $responses[$command] = Send-ObdCommand $port $command 1500
    }
    $responses['ATRV'] = Send-ObdCommand $port 'ATRV' 1000
    $responses['ATDP'] = Send-ObdCommand $port 'ATDP' 1000
    return [pscustomobject]@{
      success = $true
      port = $Name
      baud = $Speed
      responses = $responses
    }
  } finally {
    if ($port -and $port.IsOpen) { try { $port.Close() } catch {} }
    if ($port) { try { $port.Dispose() } catch {} }
  }
}

try {
  switch ($Action) {
    'List' { Write-JsonResult ([pscustomobject]@{ success = $true; devices = @(Get-SerialDevices) }) }
    'Probe' { Write-JsonResult (Probe-Adapter $PortName $Baud) }
    'Identify' { Write-JsonResult (Identify-Adapter $PortName $Baud) }
    'Sample' { Write-JsonResult (Read-Sample $PortName $Baud) }
    'LockProbe' { Write-JsonResult (Test-PortLock $PortName $Baud) }
    'BluetoothRepair' { Write-JsonResult (Invoke-BluetoothSerialRepair $TargetName ([bool]$Aggressive)) }
  }
} catch {
  Write-JsonResult ([pscustomobject]@{ success = $false; error = $_.Exception.Message; action = $Action; port = $PortName })
  exit 1
}
