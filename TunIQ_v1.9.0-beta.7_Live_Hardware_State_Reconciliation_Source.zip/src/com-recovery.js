const RECOVERABLE_P01_CODES = new Set([
  'lock-probe-timeout', 'adapter-locked', 'adapter-disconnected', 'bridge-timeout',
  'pcmhammer-start-failed', 'operation-running', 'cli-launch-failed', 'cli-not-found',
  'cli-operation-unavailable', 'unsupported-cli', 'app-restarted-during-step',
  'adapter-open-timeout', 'adapter-open-failed', 'adapter-not-detected', 'missing-outgoing-port', 'ports-unavailable', 'bluetooth-spp-unavailable', 'adapter-identity-unverified', 'connection-broker-failed', 'adapter-handoff-failed', 'kernel-files-missing',
  'adapter-conflict-process', 'safety-snapshot-failed', 'bus-speed-interference'
]);

function clean(value, max = 1000) {
  return String(value ?? '').replace(/[\u0000-\u001f]/g, ' ').trim().slice(0, max);
}

function bridgeError(error, action = '', port = '') {
  const message = clean(error?.message || error || 'Windows serial bridge request failed.');
  const explicit = clean(error?.code || '', 120);
  let code = explicit || 'bridge-request-failed';
  if (/timed out/i.test(message)) code = String(action).toLowerCase() === 'lockprobe' ? 'lock-probe-timeout' : 'bridge-timeout';
  else if (/in use|access.*denied|unauthorized|cannot open|busy|locked/i.test(message)) code = 'adapter-locked';
  return {
    code,
    action: clean(action, 80),
    port: clean(port, 30),
    message,
    timedOut: code === 'lock-probe-timeout' || code === 'bridge-timeout',
    recoverable: ['lock-probe-timeout', 'bridge-timeout', 'adapter-locked'].includes(code)
  };
}

function isRecoverableP01Stop(code) { return RECOVERABLE_P01_CODES.has(clean(code, 120)); }

function normalizeP01RecoveryState(input = {}, processInstanceId = '') {
  const state = { ...input, completedSteps: { ...(input.completedSteps || {}) } };
  const stopCode = clean(state.stop?.code || '', 120);
  const stoppedPhase = /^stopped-|^assisted-/.test(String(state.phase || ''));
  const recoverable = isRecoverableP01Stop(stopCode) || stoppedPhase;
  if ((state.status === 'running' && state.stop) || (['failed', 'cancelled'].includes(state.status) && recoverable)) {
    state.status = 'paused';
  }
  if (state.status === 'paused' || recoverable) {
    state.resumePhase = state.resumePhase || state.nextStep || state.stop?.resumePhase || state.stop?.priorPhase || 'preflight';
    state.nextStep = state.resumePhase;
  }
  if (processInstanceId) state.runInstanceId = processInstanceId;
  return state;
}

function rankAlternatePorts(devices = [], currentPort = '') {
  const current = clean(currentPort, 30).toUpperCase();
  const source = Array.isArray(devices) ? devices : [];
  const currentItem = source.find(item => String(item?.port || '').toUpperCase() === current) || null;
  const currentText = `${currentItem?.name || ''} ${currentItem?.manufacturer || ''} ${currentItem?.hardwareId || ''} ${currentItem?.transport || ''} ${currentItem?.parentId || ''} ${currentItem?.pairKey || ''}`.toLowerCase();
  const currentBluetooth = Boolean(currentItem?.bluetooth) || /bluetooth|bthenum|bthmodem|bthport|spp/.test(currentText);
  const currentRecognized = Boolean(currentItem?.recognized || currentItem?.recommended) || /obdlink|scantool|stn11|stn21/.test(currentText);
  const currentPairKey = clean(currentItem?.pairKey || currentItem?.containerId || currentItem?.parentId || '', 300).toLowerCase();
  return source
    .filter(item => item && item.port && String(item.port).toUpperCase() !== current && !item.demo)
    .map(item => {
      const text = `${item.name || ''} ${item.manufacturer || ''} ${item.hardwareId || ''} ${item.transport || ''} ${item.parentId || ''} ${item.pairKey || ''}`.toLowerCase();
      const bluetooth = Boolean(item.bluetooth) || /bluetooth|bthenum|bthmodem|bthport|spp/.test(text);
      const outgoing = Boolean(item.outgoing) || /outgoing|client/.test(text);
      const incoming = Boolean(item.incoming) || /incoming|server/.test(text);
      const pairKey = clean(item.pairKey || item.containerId || item.parentId || '', 300).toLowerCase();
      let score = 0;
      if (/obdlink|scantool|stn11|stn21/.test(text)) score += 80;
      if (item.recommended) score += 35;
      if (item.recognized) score += 20;
      // Windows commonly names both OBDLink SPP ports only “Standard Serial over Bluetooth
      // link.” A generic Bluetooth sibling must still be eligible when the selected port is
      // Bluetooth, otherwise COM3 can never fail over to the paired outgoing COM4.
      if (bluetooth) score += 25;
      if (currentBluetooth && bluetooth) score += 25;
      if (currentRecognized && bluetooth) score += 15;
      if (currentPairKey && pairKey && currentPairKey === pairKey) score += 70;
      if (outgoing) score += 55;
      if (incoming) score -= 45;
      return { ...item, bluetooth, outgoing, incoming, recoveryScore: score };
    })
    .filter(item => item.recoveryScore >= 20)
    .sort((a, b) => b.recoveryScore - a.recoveryScore || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }));
}

module.exports = { RECOVERABLE_P01_CODES, bridgeError, isRecoverableP01Stop, normalizeP01RecoveryState, rankAlternatePorts };
