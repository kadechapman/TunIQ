# TunIQ v1.9.0-beta.4 — Bluetooth SPP Rescue & Exact-Step Resume

- Enables the OBDLink Serial Port Profile service with BluetoothSetServiceState.
- Starts required Windows Bluetooth services without restarting the whole radio.
- Performs one bounded PnP rescan and one fresh adapter-broker pass.
- Resumes the exact interrupted Read Properties/read/Test Write step when a verified port appears.
- Adds Repair Bluetooth Port and Open Windows COM Setup actions.
- Keeps all project evidence and real-write locks unchanged.
