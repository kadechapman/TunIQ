# TunIQ v1.9.0-beta.3 — Verified Adapter Connection Broker

- Fixes Read Properties and full reads bypassing adapter validation.
- Positively opens and identifies the adapter before PCM Hammer starts.
- Uses only one verified COM port per hardware session.
- Removes duplicate same-port attempts and blind COM8/COM4/COM1 fallback in broker-backed sessions.
- Rejects incoming-only Bluetooth endpoints and generic COM1 unless identity is proven.
- Preserves project evidence and the separate Test Write/write boundary.
