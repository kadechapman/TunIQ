# TunIQ v1.9.0-beta.3 Test Report

## Release

**Verified Adapter Connection Broker**

## Failure reproduced from the supplied screenshots

The prior build allowed Read Properties/full-read startup to bypass the intelligent connection manager. PCM Hammer then tried COM8, COM4, and COM1, with a bounded same-port retry that made each port appear twice. The session stopped before PCM communication with `adapter-open-timeout`.

## Implemented fix

- Read Properties, full reads, Test Write, calibration write, full write, and recovery now require the connection broker.
- TunIQ opens the Windows serial endpoint itself and requests ATI, AT@1, and STDI adapter identity before PCM Hammer starts.
- Only a positively identified OBDLink/STN-compatible endpoint is accepted.
- Incoming-only Bluetooth endpoints and generic COM1 are excluded unless identity is positively proven.
- A stale selected COM port cannot outrank a live outgoing endpoint.
- Each eligible COM port is tested at most once per broker preflight.
- PCM Hammer receives exactly one verified port and does not perform blind same-port or alternate-port retries in that session.
- If Windows changes state between TunIQ closing the verified probe and PCM Hammer opening it, the session stops as `adapter-handoff-failed`.
- The Hardware Session Doctor records the broker attempt and verified identity without exposing project BIN data.

## Automated verification

- Source syntax checks: **passed**
- Verified Adapter Connection Broker simulations: **11/11 passed**
- Full TunIQ automated suite: **40/40 groups passed**
- Complete retained recovery chain: **passed**
- Universal P01 request scenarios: **passed**
- Multi-P01 quick-service scenarios: **passed**
- Session Guard/Safety Vault scenarios: **passed**

## Safety and truth boundary

- No physical PCM operation was performed in this environment.
- No real Read Properties, full read, Test Write, or PCM write success is claimed.
- The update does not enable a new automatic actual-write path.
- Existing protected project evidence and per-project BIN isolation remain required.
