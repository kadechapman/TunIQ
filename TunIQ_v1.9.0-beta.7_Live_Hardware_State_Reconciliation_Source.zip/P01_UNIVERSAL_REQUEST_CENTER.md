# TunIQ Universal P01 Request Center

TunIQ v1.9.0-beta.2 replaces the hard-coded second-P01 preset and the Guided P01 checkbox wall with one project-scoped request flow.

## User flow

1. Create or activate the project that belongs to the connected P01.
2. Type the complete calibration request in plain language.
3. Type safety facts only when the request needs them.
4. Analyze the request and review the exact mapped actions and cells.
5. Complete confirmation 1: confirm the exact plan and, when required, bind the map to this project/OS/XDF/original fingerprint.
6. Complete confirmation 2: create a numbered revision.

No PCM write occurs in the request center. Test Write and real writing remain separate Flash Center operations.

## Supported natural-language actions in this beta

- Disable VATS / theft deterrent for an authorized swap or repair.
- Set electric-fan on/off temperatures.
- Set engine RPM limiter values.
- Set vehicle-speed limiter values.
- Request a mapped ghost-cam idle profile when an exact commissioned map or verified rule pack exists.

TunIQ stops on unsupported or ambiguous wording rather than guessing a calibration address or value.

## Universal P01 scope

The workflow is not bound to the Customline PCM or a specific second PCM. It accepts any active project identified as P01 when that project has its own protected original, matching read evidence, exact OS identity, and exact writable definition.

Every project remains isolated by project ID, OS ID, XDF hash, and protected-original hash. Maps, BINs, and revisions are never copied across projects automatically.

## Typed safety facts

Low-risk requests such as VATS disable and normal fan temperatures do not require a checklist. Higher-risk requests trigger only the facts that apply:

- Valvetrain/rotating-assembly capability for elevated RPM.
- Tire speed rating for high speed-limit settings.
- Driveline verification.
- Brake/bearing/suspension/stability verification.
- Closed-course or controlled-test use.
- Ghost-idle vacuum, brake-assist, emissions, and drivability acknowledgement.

The request fingerprint changes whenever the project, request, interpreted actions, or safety facts change. A changed request must be analyzed and confirmed again.
