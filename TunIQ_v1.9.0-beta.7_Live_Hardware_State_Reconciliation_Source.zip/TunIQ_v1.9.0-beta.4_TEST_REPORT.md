# TunIQ v1.9.0-beta.4 Test Report

## Release

- Version: `1.9.0-beta.4`
- Name: Bluetooth SPP Rescue & Exact-Step Resume
- Base: verified `v1.9.0-beta.3` source
- Physical P01 hardware success: **not claimed**

## Problem addressed

On the P01 Service project, Windows exposed Bluetooth serial entries but neither candidate produced an openable outgoing/client connection. The verified adapter broker correctly blocked PCM Hammer, but it could not repair the Windows Serial Port Profile (SPP) service.

## Implemented

- Added a bounded Windows Bluetooth repair action.
- Uses `BluetoothSetServiceState` with the standard Bluetooth Serial Port service GUID to enable the remote SPP driver for an OBDLink/ScanTool/STN device.
- Starts required Windows Bluetooth services if stopped.
- Requests a Windows Plug-and-Play device rescan.
- Rebuilds the live COM inventory and reruns adapter identity verification once.
- Resumes the exact preserved P01 phase when a verified port becomes available.
- Adds `Repair Bluetooth Port` and `Open Windows COM Setup` UI actions.
- Stops with `bluetooth-spp-unavailable` after one unsuccessful repair rather than looping.
- Does not clear verified reads, import another project BIN, perform Test Write automatically, or perform a real PCM write.

## Automated results

- Source syntax checks: **passed**
- Bluetooth SPP Rescue scenarios: **5/5 passed**
- Verified Adapter Connection Broker scenarios: **11/11 passed**
- Full automated suite: **41/41 groups passed**
- Complete retained recovery chain: **passed**
- Clean extracted archive checks: recorded separately in the archive verification report

## Hardware boundary

The Windows Bluetooth API and PnP repair path were validated through source contracts and simulated device inventories. It still requires confirmation on the user's actual Windows Bluetooth stack and OBDLink MX+.
