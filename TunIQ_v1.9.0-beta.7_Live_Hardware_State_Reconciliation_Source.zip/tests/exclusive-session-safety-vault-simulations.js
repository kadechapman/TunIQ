const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { HardwareSessionGuard } = require('../src/hardware-session-guard');
const { ProjectSafetyVault } = require('../src/project-safety-vault');
const { FlashManager } = require('../src/flash');
const { classifyPcmHammerResult } = require('../src/pcmhammer');
const { classifyFailure, buildHardwareSessionReport } = require('../src/hardware-session-doctor');
const { P01AutoManager } = require('../src/p01-auto');

function fixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-183-'));
  const project = { id: 'customline', name: 'Customline', controller: 'P01', os: '9379910', folder: path.join(root, 'Projects', 'Customline') };
  fs.mkdirSync(path.join(project.folder, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(project.folder, 'Reports'), { recursive: true });
  fs.writeFileSync(path.join(project.folder, 'Originals', 'protected.bin'), Buffer.alloc(524288, 0x51));
  fs.writeFileSync(path.join(project.folder, 'Reports', 'p01-evidence.json'), JSON.stringify({ os: '9379910', verified: true }));
  return { root, project };
}
function waitFor(predicate, timeout = 5000) { return new Promise((resolve, reject) => { const start = Date.now(); const timer = setInterval(() => { const value = predicate(); if (value) { clearInterval(timer); resolve(value); } else if (Date.now() - start > timeout) { clearInterval(timer); reject(new Error('Timed out')); } }, 15); }); }

async function runExclusiveSessionSafetyVaultSimulations(options = {}) {
  const { root, project } = fixture();
  try {
    const guard = new HardwareSessionGuard({
      dataRoot: () => root, platform: 'win32', currentPid: 900,
      processProvider: async () => [{ ProcessId: 111, Name: 'OBDwiz.exe', ExecutablePath: 'C:/OBDwiz/OBDwiz.exe', CommandLine: 'OBDwiz.exe' }],
      killProvider: async () => false
    });
    const blocked = await guard.inspect({ selectedPort: 'COM3', expectedExecutable: 'C:/PCM/PcmHammerCLI.exe' });
    assert.equal(blocked.blocked, true);
    assert.equal(blocked.conflicts[0].pid, 111);

    const serialGuard = new HardwareSessionGuard({
      dataRoot: () => root, platform: 'win32', currentPid: 900,
      processProvider: async () => [{ ProcessId: 112, Name: 'putty.exe', CommandLine: 'putty.exe -serial COM4' }],
      killProvider: async () => false
    });
    assert.equal((await serialGuard.inspect({ selectedPort: 'COM3' })).blocked, false);
    assert.equal((await serialGuard.inspect({ selectedPort: 'COM4' })).blocked, true);

    // v1.9.0-beta.6 real-screen regression: running TunIQ from a source folder whose
    // name contains "OBDLink" made the guard classify TunIQ's own cmd/node/electron
    // process tree as an external OBD application. The complete generic runtime family
    // connected to the current Electron PID must be ignored.
    const sourceFolder = 'C:/Users/Test/Downloads/TunIQ_v1.9.0-beta.5_OBDLink_Repair_Direct_PCM_Hammer_Handoff_Source';
    const selfTreeGuard = new HardwareSessionGuard({
      dataRoot: () => path.join(root, 'self-tree'), platform: 'win32', currentPid: 12708,
      processProvider: async () => [
        { ProcessId: 9320, ParentProcessId: 800, Name: 'cmd.exe', ExecutablePath: 'C:/Windows/System32/cmd.exe', CommandLine: `cmd.exe /d /s /c cd /d ${sourceFolder} && npm start` },
        { ProcessId: 9640, ParentProcessId: 9320, Name: 'node.exe', ExecutablePath: 'C:/Program Files/nodejs/node.exe', CommandLine: `node.exe ${sourceFolder}/node_modules/electron/cli.js .` },
        { ProcessId: 12708, ParentProcessId: 9640, Name: 'electron.exe', ExecutablePath: `${sourceFolder}/node_modules/electron/dist/electron.exe`, CommandLine: `electron.exe ${sourceFolder}` },
        { ProcessId: 15976, ParentProcessId: 12708, Name: 'electron.exe', ExecutablePath: `${sourceFolder}/node_modules/electron/dist/electron.exe`, CommandLine: `electron.exe --type=renderer --app-path=${sourceFolder}` },
        { ProcessId: 16012, ParentProcessId: 12708, Name: 'electron.exe', ExecutablePath: `${sourceFolder}/node_modules/electron/dist/electron.exe`, CommandLine: `electron.exe --type=utility --app-path=${sourceFolder}` }
      ],
      killProvider: async () => false
    });
    const selfTreeInspection = await selfTreeGuard.inspect({ selectedPort: 'COM4' });
    assert.equal(selfTreeInspection.blocked, false);
    assert.deepEqual(selfTreeInspection.conflicts, []);
    assert(selfTreeInspection.ignoredTunIQRuntimePids.includes(9320));
    assert(selfTreeInspection.ignoredTunIQRuntimePids.includes(15976));

    // A source/install path containing "OBDLink" alone is not an OBD-process identity.
    // This protects a generic launcher even when the current PID is temporarily absent
    // from the Windows process inventory.
    const pathNameGuard = new HardwareSessionGuard({
      dataRoot: () => path.join(root, 'path-name'), platform: 'win32', currentPid: 99999,
      processProvider: async () => [
        { ProcessId: 17001, ParentProcessId: 1, Name: 'cmd.exe', ExecutablePath: 'C:/Windows/System32/cmd.exe', CommandLine: `cmd.exe /c ${sourceFolder}/START_TUNIQ.bat` }
      ],
      killProvider: async () => false
    });
    assert.equal((await pathNameGuard.inspect({ selectedPort: 'COM4' })).blocked, false);

    const killed = [];
    const orphanGuard = new HardwareSessionGuard({
      dataRoot: () => root, platform: 'win32', currentPid: 900,
      processProvider: async () => [{ ProcessId: 222, Name: 'PcmHammerCLI.exe', ExecutablePath: 'C:/PCM/PcmHammerCLI.exe', CommandLine: '' }, { ProcessId: 333, Name: 'PcmHammerCLI.exe', ExecutablePath: 'D:/Other/PcmHammerCLI.exe', CommandLine: '' }],
      killProvider: async pid => { killed.push(pid); return true; }
    });
    orphanGuard.registerOwnedProcess(222, 'C:/PCM/PcmHammerCLI.exe', 'owned-session');
    const cleanup = await orphanGuard.cleanupOwnedOrphans();
    assert.deepEqual(killed, [222]);
    assert.equal(cleanup.cleaned.length, 1);

    // Regression from the real v1.8.3 Customline session: taskkill /T removed the
    // TunIQ-owned GUI/CLI tree, but the guard classified its stale first inventory.
    let inventoryPass = 0;
    const treeGuard = new HardwareSessionGuard({
      dataRoot: () => root, platform: 'win32', currentPid: 900,
      processProvider: async () => {
        inventoryPass += 1;
        if (inventoryPass <= 1) return [
          { ProcessId: 11816, ParentProcessId: 900, Name: 'PcmHammer.exe', ExecutablePath: 'C:/PCM/PcmHammer.exe', CommandLine: 'PcmHammer.exe' },
          { ProcessId: 12412, ParentProcessId: 11816, Name: 'pcmhammer-cli.exe', ExecutablePath: 'C:/PCM/pcmhammer-cli.exe', CommandLine: 'pcmhammer-cli.exe --test-write stock.bin --device COM3' }
        ];
        return [];
      },
      killProvider: async pid => pid === 11816
    });
    treeGuard.registerOwnedProcess(11816, 'C:/PCM/PcmHammer.exe', 'stale-test-write');
    const treeInspection = await treeGuard.inspect({ selectedPort: 'COM3', expectedExecutable: 'C:/PCM/PcmHammer.exe' });
    assert.equal(treeInspection.rescannedAfterCleanup, true);
    assert.equal(treeInspection.blocked, false);
    assert.equal(treeInspection.conflicts.length, 0);
    assert.equal(treeInspection.cleanedOwnedProcesses[0].pid, 11816);


    // v1.8.5 regression: taskkill can return false even though Windows removes the
    // registered process moments later. TunIQ must poll fresh inventories and must
    // not reclassify the stale first snapshot as an external conflict.
    let delayedPass = 0;
    const delayedExitGuard = new HardwareSessionGuard({
      dataRoot: () => root, platform: 'win32', currentPid: 900,
      processProvider: async () => {
        delayedPass += 1;
        if (delayedPass <= 2) return [
          { ProcessId: 11816, ParentProcessId: 900, Name: 'PcmHammer.exe', ExecutablePath: 'C:/PCM/PcmHammer.exe', CommandLine: 'PcmHammer.exe' },
          { ProcessId: 12412, ParentProcessId: 11816, Name: 'pcmhammer-cli.exe', ExecutablePath: 'C:/PCM/pcmhammer-cli.exe', CommandLine: 'pcmhammer-cli.exe --test-write stock.bin --device COM3' }
        ];
        return [];
      },
      killProvider: async () => false
    });
    delayedExitGuard.registerOwnedProcess(11816, 'C:/PCM/PcmHammer.exe', 'delayed-exit-test-write');
    const delayedInspection = await delayedExitGuard.inspect({ selectedPort: 'COM3', expectedExecutable: 'C:/PCM/PcmHammer.exe' });
    assert.equal(delayedInspection.blocked, false);
    assert.equal(delayedInspection.rescannedAfterCleanup, true);
    assert(delayedInspection.cleanupSettlePasses >= 2);

    // v1.8.6 real-hardware regression: the same unregistered GUI/CLI PIDs may
    // survive from an earlier source run. TunIQ must sweep the entire PCM Hammer
    // tree before evaluating conflicts, even when the registry is empty.
    let hardResetPass = 0;
    const hardResetKilled = [];
    const hardResetGuard = new HardwareSessionGuard({
      dataRoot: () => path.join(root, 'hard-reset'), platform: 'win32', currentPid: 900,
      processProvider: async () => {
        hardResetPass += 1;
        if (hardResetPass === 1) return [
          { ProcessId: 11816, ParentProcessId: 777, Name: 'PcmHammer.exe', ExecutablePath: 'C:/PCM/PcmHammer.exe', CommandLine: 'PcmHammer.exe' },
          { ProcessId: 12412, ParentProcessId: 11816, Name: 'pcmhammer-cli.exe', ExecutablePath: 'C:/PCM/pcmhammer-cli.exe', CommandLine: 'pcmhammer-cli.exe --test-write stock.bin --device COM3' }
        ];
        return [];
      },
      killProvider: async pid => { hardResetKilled.push(pid); return true; }
    });
    const hardResetInspection = await hardResetGuard.inspect({ selectedPort: 'COM3', expectedExecutable: 'C:/PCM/pcmhammer-cli.exe' });
    assert.deepEqual(hardResetKilled, [11816]);
    assert.equal(hardResetInspection.blocked, false);
    assert.equal(hardResetInspection.forcedPcmHammerCleanup.length, 1);
    assert.equal(hardResetInspection.forcedPcmHammerCleanup[0].scope, 'all-pcmhammer-tree');

    const vault = new ProjectSafetyVault({ dataRoot: () => root, getActiveProject: () => project, retention: 3 });
    const first = vault.create('before-testWrite');
    assert.equal(first.verified, true);
    assert(fs.existsSync(first.manifestFile));
    const manifest = JSON.parse(fs.readFileSync(first.manifestFile, 'utf8'));
    assert.equal(manifest.fileCount, 2);
    assert.equal(manifest.files.every(item => /^[a-f0-9]{64}$/.test(item.sha256)), true);
    const second = vault.create('before-testWrite');
    assert.equal(second.reused, true);
    assert.equal(second.path, first.path);
    fs.writeFileSync(path.join(project.folder, 'Reports', 'new-result.txt'), 'changed');
    const third = vault.create('before-testWrite');
    assert.notEqual(third.path, first.path);

    const mock = path.join(root, 'mock-test-write.js');
    fs.writeFileSync(mock, "console.log('PCM communication started'); console.log('Test Write completed successfully; no changes were written'); process.exit(0);\n");
    const manager = new FlashManager({
      dataRoot: () => root, getActiveProject: () => project,
      inspectExclusiveSession: async () => ({ blocked: false, conflicts: [], warnings: [] }),
      createSafetySnapshot: reason => vault.create(reason),
      registerOwnedProcess: () => {}, releaseOwnedProcess: () => {},
      releasePort: async () => ({ released: true }), findAlternatePorts: async () => [],
      onSessionComplete: async () => {}
    });
    manager.preflight = () => ({
      operation: 'testWrite', active: project, values: { input: path.join(project.folder, 'Originals', 'protected.bin'), device: '' }, voltage: 13.2,
      resolved: { executable: process.execPath, prefixArgs: [mock] }, config: { integrationMode: 'test' }, kernel: null,
      candidateProfiles: [{ id: 'test-profile', label: 'test', templates: { testWrite: [] } }]
    });
    const started = await manager.start('testWrite', {});
    assert.equal(started.safetySnapshot.verified, true);
    const completed = await waitFor(() => manager.getHistory().find(item => item.id === started.id));
    assert.equal(completed.state, 'complete');
    assert.equal(completed.testWritePassed, true);
    assert.equal(completed.technicalDetails.safetySnapshot.verified, true);

    const conflictManager = new FlashManager({
      dataRoot: () => root, getActiveProject: () => project,
      inspectExclusiveSession: async () => blocked,
      createSafetySnapshot: () => { throw new Error('must not run'); }
    });
    conflictManager.preflight = manager.preflight;
    await assert.rejects(() => conflictManager.start('testWrite', {}), error => error.code === 'adapter-conflict-process' && error.details.exclusiveGuard.conflicts.length === 1);

    const bus = classifyPcmHammerResult('testWrite', 'PCM communication started\n4x bus traffic interrupted by a 1x module message\nTest Write aborted', 1);
    assert.equal(bus.busSpeedInterference, true);
    assert.equal(bus.stopCode, 'bus-speed-interference');
    assert.equal(classifyFailure({ stopCode: bus.stopCode, operation: 'testWrite', communicationStarted: true }).category, 'vehicle-network');

    const auto = new P01AutoManager({ getActiveProject: () => project });
    auto.save({ ...auto.blank(project), status: 'running', phase: 'test-write', nextStep: 'test-write' }, project);
    const paused = auto.pause('adapter-conflict-process', 'Close OBDwiz.', { resumePhase: 'test-write', details: { exclusiveGuard: blocked } });
    assert.equal(paused.stop.details.exclusiveGuard.conflicts[0].pid, 111);
    const report = buildHardwareSessionReport({ appVersion: '1.8.3', activeProject: project, p01: { identity: { controller: 'P01', os: '9379910' }, dualReadVerified: true }, p01Auto: paused, flash: {} });
    assert.equal(report.schemaVersion, 2);
    assert.equal(report.exclusiveSessionGuard.blocked, true);

    const result = { passed: true, scenarios: 15, features: ['exclusive-process-guard', 'owned-orphan-cleanup', 'hash-verified-project-safety-vault', 'snapshot-deduplication', 'bus-speed-interference-diagnosis', 'post-cleanup-process-rescan', 'taskkill-false-delayed-pid-exit', 'unregistered-pcmhammer-tree-hard-reset', 'tuniq-runtime-family-exclusion', 'command-line-folder-name-not-process-identity'] };
    if (!options.quiet) console.log(JSON.stringify(result, null, 2));
    return result;
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

if (require.main === module) runExclusiveSessionSafetyVaultSimulations().catch(error => { console.error(error.stack || error); process.exit(1); });
module.exports = { runExclusiveSessionSafetyVaultSimulations };
