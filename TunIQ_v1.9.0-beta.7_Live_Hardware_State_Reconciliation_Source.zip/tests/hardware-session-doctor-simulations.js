const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const {
  classifyFailure,
  buildHardwareSessionReport,
  renderHardwareSessionText,
  HardwareSessionDoctor
} = require('../src/hardware-session-doctor');

function fixtureRoot() { return fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-hardware-doctor-')); }
function activeProject(root) {
  const folder = path.join(root, 'Projects', 'Customline');
  fs.mkdirSync(path.join(folder, 'Reports'), { recursive: true });
  return { id: 'customline-p01', name: 'Customline', folder, controller: 'P01', os: '9379910', bin: path.join(folder, 'Originals', 'protected-original.bin') };
}
function p01Status() {
  return {
    applicable: true,
    identity: { controller: 'P01', os: '9379910', hardwareId: '9386530', serviceNumber: '12200411' },
    dualReadVerified: true,
    canonicalReadSha256: 'a'.repeat(64),
    canonicalPath: 'C:/TunIQ/Customline/Originals/Customline-Protected-Original.bin',
    definition: { commissioningOnly: true },
    testWrite: null,
    readyForWrite: false
  };
}
function autoState() {
  return {
    projectId: 'customline-p01', projectName: 'Customline', status: 'paused', phase: 'stopped-adapter-open-failed',
    resumePhase: 'test-write', progress: 95, commissioningOnly: true,
    revision: { name: 'Customline-Commissioning-Stock-Clone.bin', path: 'C:/TunIQ/Customline/Revisions/Customline-Commissioning-Stock-Clone.bin', sha256: 'a'.repeat(64) },
    stop: { code: 'adapter-open-failed' },
    portRecovery: { code: 'adapter-open-failed' }
  };
}
function failedFlash(root) {
  const stdout3 = path.join(root, 'com3.stdout.log');
  const stderr3 = path.join(root, 'com3.stderr.log');
  const stdout4 = path.join(root, 'com4.stdout.log');
  const stderr4 = path.join(root, 'com4.stderr.log');
  for (const file of [stdout3, stderr3, stdout4, stderr4]) fs.writeFileSync(file, 'mock log');
  return {
    executable: 'C:/Tools/PcmHammer/PcmHammerCLI.exe',
    lastSuccessfulDevice: '',
    lastDeviceCandidates: [{ port: 'COM3' }, { port: 'COM4', outgoing: true, recognized: true, recoveryScore: 90 }],
    history: [{
      id: 'testwrite-failed', projectId: 'customline-p01', operation: 'testWrite', state: 'failed', phase: 'Running Test Write',
      device: 'COM4', initialDevice: 'COM3', exitCode: 1, stopCode: 'adapter-open-failed', testWritePassed: false,
      kernelDir: 'C:/Tools/PcmHammer', kernelFiles: ['Kernel-P01.bin', 'Loader-P01.bin'],
      deviceAttempts: [
        { attempt: 1, device: 'COM3', source: 'selected', exitCode: 1, openFailure: true, communicationStarted: false, stdoutLog: stdout3, stderrLog: stderr3 },
        { attempt: 2, device: 'COM3', source: 'same-port-retry', exitCode: 1, openTimeout: true, communicationStarted: false, stdoutLog: stdout3, stderrLog: stderr3 },
        { attempt: 3, device: 'COM4', source: 'recognized-alternate', exitCode: 1, openFailure: true, communicationStarted: false, stdoutLog: stdout4, stderrLog: stderr4 }
      ],
      deviceCandidates: [{ port: 'COM3', source: 'selected' }, { port: 'COM4', source: 'recognized-alternate', outgoing: true, recognized: true, recoveryScore: 90 }],
      technicalDetails: { communicationStarted: false, sessionLog: path.join(root, 'testwrite.log') }
    }]
  };
}

function runHardwareSessionDoctorSimulations(options = {}) {
  const root = fixtureRoot();
  try {
    const active = activeProject(root);
    const p01 = p01Status();
    const auto = autoState();
    const flash = failedFlash(root);
    fs.writeFileSync(flash.history[0].technicalDetails.sessionLog, 'session log');

    const report = buildHardwareSessionReport({ appVersion: '1.8.3', activeProject: active, p01, p01Auto: auto, flash });
    assert.equal(report.diagnosis.category, 'connection');
    assert.equal(report.diagnosis.safeToRetryFailedStep, true);
    assert.equal(report.diagnosis.verifiedEvidencePreserved, true);
    assert.equal(report.diagnosis.noActualPcmWriteOccurred, true);
    assert.equal(report.diagnosis.recommendedPort, 'COM4');
    assert.equal(report.session.attempts.length, 3);
    assert.equal(report.session.attempts[1].outcome, 'port open timeout');
    assert.equal(report.workflow.rawProgress, 95);
    assert(renderHardwareSessionText(report).includes('No actual PCM write occurred: YES'));

    const kernel = classifyFailure({ stopCode: 'kernel-files-missing', operation: 'testWrite' });
    assert.equal(kernel.category, 'installation');
    assert(kernel.actions.some(item => /complete PCM Hammer/i.test(item)));

    const communication = classifyFailure({ stopCode: 'pcmhammer-failed', operation: 'testWrite', communicationStarted: true });
    assert.equal(communication.category, 'pcmhammer');
    assert.equal(communication.communicationStarted, true);

    const successFlash = {
      ...flash,
      lastSuccessfulDevice: 'COM4', lastSuccessfulAt: '2026-07-22T12:00:00.000Z',
      history: [{ ...flash.history[0], id: 'testwrite-success', state: 'complete', exitCode: 0, stopCode: '', testWritePassed: true, verified: true, device: 'COM4', deviceAttempts: [{ attempt: 1, device: 'COM4', exitCode: 0, communicationStarted: true }] }]
    };
    const success = buildHardwareSessionReport({ appVersion: '1.8.3', activeProject: active, p01: { ...p01, testWrite: { passed: true } }, p01Auto: { ...auto, status: 'complete', phase: 'commissioning-complete', progress: 100 }, flash: successFlash });
    assert.equal(success.diagnosis.severity, 'ready');
    assert.equal(success.diagnosis.recommendedPort, 'COM4');
    assert.equal(success.diagnosis.noActualPcmWriteOccurred, true);


    const com1Unsafe = buildHardwareSessionReport({
      appVersion: '1.8.5', activeProject: active, p01, p01Auto: auto,
      flash: { device: '', lastSuccessfulDevice: '', lastDeviceCandidates: [{ port: 'COM1', recognized: false, outgoing: false }, { port: 'COM3', recognized: true, recoveryScore: 80 }], history: [] }
    });
    assert.equal(com1Unsafe.diagnosis.recommendedPort, 'COM3');
    const persistedCom3 = buildHardwareSessionReport({
      appVersion: '1.8.5', activeProject: active, p01, p01Auto: auto,
      flash: { device: 'COM3', lastSuccessfulDevice: '', lastDeviceCandidates: [{ port: 'COM1' }], history: [{ projectId: active.id, operation: 'testWrite', state: 'failed', device: 'COM3', deviceCandidates: [{ port: 'COM1' }] }] }
    });
    assert.equal(persistedCom3.diagnosis.recommendedPort, 'COM3');

    const activities = [];
    const doctor = new HardwareSessionDoctor({
      appVersion: '1.8.3', dataRoot: () => root, getActiveProject: () => active,
      getP01Status: () => p01, getP01AutoState: () => auto, getFlashStatus: () => flash,
      appendActivity: (type, details) => activities.push({ type, details })
    });
    const latest = doctor.saveLatest();
    assert(fs.existsSync(latest.jsonFile));
    assert(fs.existsSync(latest.textFile));
    assert.equal(JSON.parse(fs.readFileSync(latest.jsonFile, 'utf8')).schemaVersion, 2);
    assert.equal(doctor.latestLog(latest.report), flash.history[0].technicalDetails.sessionLog);
    const exported = path.join(root, 'exported-hardware-session.txt');
    doctor.export(exported, latest.report);
    assert(fs.readFileSync(exported, 'utf8').includes('Port attempt timeline'));
    assert(activities.some(item => item.type === 'hardware-session-report-exported'));

    const renderer = fs.readFileSync(path.join(__dirname, '../src/renderer/app.js'), 'utf8');
    const html = fs.readFileSync(path.join(__dirname, '../src/renderer/index.html'), 'utf8');
    assert(renderer.includes("stopped?'STOPPED'"), 'stopped hardware session must not present a misleading 95% completion label');
    assert(renderer.includes('renderHardwareSessionDoctor'), 'Hardware Session Doctor renderer missing');
    for (const id of ['p01HardwareDoctor','p01HardwareDoctorRefresh','p01HardwareDoctorExport','p01HardwareDoctorOpenLog','p01HardwareDoctorOpenReports','p01HardwareDoctorOpenSnapshot']) assert(html.includes(`id="${id}"`), `missing Hardware Session Doctor DOM id ${id}`);

    const result = {
      passed: true,
      scenarios: [
        { scenario: 'com3-com4-failure-diagnosis', passed: true, attempts: report.session.attempts.map(item => item.port), recommendedPort: report.diagnosis.recommendedPort },
        { scenario: 'kernel-installation-guidance', passed: true },
        { scenario: 'communication-boundary-classification', passed: true },
        { scenario: 'successful-test-write-diagnosis', passed: true, port: success.diagnosis.recommendedPort },
        { scenario: 'deterministic-project-report-export', passed: true, files: [latest.jsonFile, latest.textFile] },
        { scenario: 'com1-unrecognized-fallback-rejected', passed: true, recommendedPort: com1Unsafe.diagnosis.recommendedPort },
        { scenario: 'persisted-project-port-preferred', passed: true, recommendedPort: persistedCom3.diagnosis.recommendedPort }
      ]
    };
    if (!options.quiet) console.log(JSON.stringify(result, null, 2));
    return result;
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

if (require.main === module) {
  try { runHardwareSessionDoctorSimulations(); }
  catch (error) { console.error(error.stack || error); process.exit(1); }
}

module.exports = { runHardwareSessionDoctorSimulations };
