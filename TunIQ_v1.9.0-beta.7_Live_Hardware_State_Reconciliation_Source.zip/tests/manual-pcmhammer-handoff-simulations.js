const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager, allowsDirectPcmHammerHandoff } = require('../src/flash');

function temp(prefix) { return fs.mkdtempSync(path.join(os.tmpdir(), prefix)); }

async function runManualPcmHammerHandoffSimulations({ quiet = false } = {}) {
  const reports = [];

  // 1. A user-authorized read-only fallback bypasses TunIQ's adapter probe and hands one exact port to PCM Hammer.
  {
    const root = temp('tuniq-direct-pcmhammer-1-');
    const active = { id: 'p01', name: 'P01', folder: path.join(root, 'project'), controller: 'P01' };
    fs.mkdirSync(active.folder, { recursive: true });
    let brokerCalls = 0;
    const releases = [];
    const manager = new FlashManager({
      dataRoot: () => root,
      getActiveProject: () => active,
      getToolPath: () => null,
      connectionManager: { preflight: async () => { brokerCalls += 1; throw new Error('broker must not run'); } },
      releasePort: async ({ port }) => { releases.push(port); return { released: true, port }; },
      abortBridgeRequests: () => ({ aborted: 0 })
    });
    const lease = await manager.preparePort({
      operation: 'readProperties',
      values: { device: 'COM4', port: 'COM4' },
      config: {},
      directPortHandoffAuthorized: true,
      directPortHandoffReason: 'read-only fallback'
    });
    assert.equal(brokerCalls, 0);
    assert.equal(lease.port, 'COM4');
    assert.equal(lease.mode, 'manual-pcmhammer-direct-handoff');
    assert.equal(lease.directPortHandoff, true);
    assert.deepEqual(releases, ['COM4']);
    assert.deepEqual(lease.candidates.map(item => item.port), ['COM4']);
    reports.push({ scenario: 'read-properties-direct-handoff-skips-broker', passed: true });
  }

  // 2. The fallback may cover protected reads and Test Write, but never a real PCM write.
  {
    assert.equal(allowsDirectPcmHammerHandoff('readProperties'), true);
    assert.equal(allowsDirectPcmHammerHandoff('read'), true);
    assert.equal(allowsDirectPcmHammerHandoff('testWrite'), true);
    assert.equal(allowsDirectPcmHammerHandoff('writeCalibration'), false);
    assert.equal(allowsDirectPcmHammerHandoff('writeFull'), false);
    assert.equal(allowsDirectPcmHammerHandoff('recovery'), false);
    reports.push({ scenario: 'direct-handoff-write-boundary', passed: true });
  }

  // 3. Without explicit authorization, the verified adapter broker remains mandatory.
  {
    const root = temp('tuniq-direct-pcmhammer-3-');
    const active = { id: 'p01', name: 'P01', folder: path.join(root, 'project'), controller: 'P01' };
    fs.mkdirSync(active.folder, { recursive: true });
    let brokerCalls = 0;
    const manager = new FlashManager({
      dataRoot: () => root,
      getActiveProject: () => active,
      getToolPath: () => null,
      connectionManager: {
        preflight: async () => {
          brokerCalls += 1;
          return {
            ready: true, verified: true, port: 'COM7',
            attempts: [{ port: 'COM7', identified: true, recognized: true }],
            attempt: { port: 'COM7', adapter: 'OBDLink MX+', baud: 115200 },
            profile: { adapterName: 'OBDLink MX+' }
          };
        }
      },
      releasePort: async ({ port }) => ({ released: true, port }),
      abortBridgeRequests: () => ({ aborted: 0 })
    });
    const lease = await manager.preparePort({
      operation: 'readProperties',
      values: { device: 'COM4', port: 'COM4' },
      config: {},
      directPortHandoffAuthorized: false
    });
    assert.equal(brokerCalls, 1);
    assert.equal(lease.port, 'COM7');
    assert.equal(lease.mode, 'verified-broker-handoff');
    reports.push({ scenario: 'broker-remains-default', passed: true });
  }

  // 4. Desktop wiring exposes pairing, manual identity verification, and read-only PCM Hammer fallback.
  {
    const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
    const preload = fs.readFileSync(path.join(__dirname, '..', 'src', 'preload.js'), 'utf8');
    const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
    const html = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'index.html'), 'utf8');
    assert(main.includes("p01-auto:manual-pcmhammer-handoff"));
    assert(main.includes('directPcmHammerAttemptPending'));
    assert(main.includes('pcmHammerProvenPort'));
    assert(preload.includes('tryP01ManualPcmHammerPort'));
    assert(renderer.includes('tryP01ManualPcmHammerPort'));
    assert(html.includes('p01AutoManualPcmHammer'));
    reports.push({ scenario: 'desktop-direct-handoff-contract', passed: true });
  }

  if (!quiet) console.log(`Manual PCM Hammer Handoff simulations passed (${reports.length}/${reports.length}).`);
  return { generatedAt: new Date().toISOString(), reports };
}

if (require.main === module) {
  runManualPcmHammerHandoffSimulations().catch(error => {
    console.error(error.stack || error);
    process.exit(1);
  });
}

module.exports = { runManualPcmHammerHandoffSimulations };
