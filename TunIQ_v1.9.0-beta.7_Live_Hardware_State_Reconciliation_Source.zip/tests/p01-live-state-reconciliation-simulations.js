const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01AutoManager } = require('../src/p01-auto');
const { buildHardwareSessionReport, pickLatestSession } = require('../src/hardware-session-doctor');

function project(root) { return { id: 'p01-live-state', name: 'P01 Live State', controller: 'P01', folder: root }; }
function run(options = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-live-state-'));
  const active = project(root); fs.mkdirSync(path.join(root, 'Reports'), { recursive: true });
  const manager = new P01AutoManager({ getActiveProject: () => active });
  let state = manager.begin({ request: 'Read properties', exactXdfAuthorization: true, autoMapAuthorized: true, autoRevisionAuthorized: true, testWriteAuthorized: true });
  const firstRevision = state.stateRevision;
  state = manager.pause('adapter-conflict-process', 'old conflict', { resumePhase: 'read-properties', portRecovery: { code: 'adapter-conflict-process', attemptId: 'old-attempt', attempts: [{ port: 'COM4' }] } });
  assert(state.stateRevision > firstRevision, 'state revision must increase monotonically');
  state = manager.resume({ phase: 'read-properties' });
  assert.equal(state.stop, null); assert.equal(state.portRecovery, null);
  state = manager.advance('waiting-read-properties', 10, 'new attempt', { activeAttemptId: 'new-attempt', activeAttemptStartedAt: '2026-08-03T04:00:00.000Z' });
  const oldSession = { id: 'old-session', projectId: active.id, workflowAttemptId: 'old-attempt', stopCode: 'adapter-conflict-process', startedAt: '2026-08-03T03:00:00.000Z', deviceAttempts: [{ device: 'COM4', openFailure: true }] };
  const newSession = { id: 'new-session', projectId: active.id, workflowAttemptId: 'new-attempt', state: 'running', operation: 'readProperties', startedAt: '2026-08-03T04:00:00.000Z', device: 'COM3', deviceAttempts: [] };
  assert.equal(pickLatestSession({ session: newSession, history: [oldSession] }, active.id, state).id, 'new-session');
  const report = buildHardwareSessionReport({ appVersion: '1.9.0-beta.7', activeProject: active, p01Auto: state, flash: { session: newSession, history: [oldSession] } });
  assert.equal(report.workflow.stopCode, '');
  assert.equal(report.session.id, 'new-session');
  assert.equal(report.session.attempts.length, 0);
  const cancelled = manager.cancel();
  const cancelledReport = buildHardwareSessionReport({ appVersion: '1.9.0-beta.7', activeProject: active, p01Auto: cancelled, flash: { history: [oldSession] } });
  assert.equal(cancelledReport.workflow.stopCode, '');
  assert.equal(cancelledReport.session.id, '');
  const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
  assert(renderer.includes('incoming<current'), 'renderer must reject older state revisions');
  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  assert(main.includes('p01-stale-flash-completion-ignored'));
  assert(main.includes('workflowAttemptId'));
  fs.rmSync(root, { recursive: true, force: true });
  if (!options.quiet) console.log('✓ P01 live state reconciliation: newest attempt wins and stale doctor/session data is rejected');
  return { scenarios: 6 };
}
if (require.main === module) run();
module.exports = { run };
