const assert = require('assert');
const { parseTuneRequest, buildGoalProposal, applyGoalApproved } = require('../src/goal-executor');

function workspaceF(projectId = 'service-p01') {
  return {
    mode: 'xdf', projectId, modified: {}, tables: {
      vats: {
        name: 'Vehicle Anti Theft System Enable', description: 'VATS operating mode', unit: '',
        rowHeaders: ['Value'], colHeaders: ['Value'], values: [[1]],
        enumLabels: [{ index: 0, value: 'Disabled' }, { index: 1, value: 'Enabled' }]
      },
      fans: {
        name: 'Cooling Fan Temperature Control', description: 'Electric fan coolant temperature thresholds', unit: 'deg F',
        rowHeaders: ['Fan 1 On', 'Fan 1 Off', 'Fan 2 On', 'Fan 2 Off'], colHeaders: ['Value'],
        values: [[205], [198], [215], [208]], min: 130, max: 235
      }
    }
  };
}

function runP01QuickServiceSimulations(options = {}) {
  const quiet = Boolean(options.quiet);
  const active = { id: 'service-p01', name: 'Second P01', controller: 'P01', os: '12212156' };
  const request = 'disable VATS and set the electric fans on at 210 F and off at 190 F';
  const parsed = parseTuneRequest(request);
  assert.deepEqual(parsed.intents.map(item => item.type), ['vats-disable', 'fan-control']);
  assert.equal(parsed.intents[1].fanOn, 210);
  assert.equal(parsed.intents[1].fanOff, 190);

  const proposal = buildGoalProposal({ request: parsed, workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [] });
  assert.equal(proposal.blocked, false);
  assert.equal(proposal.actions.length, 2);
  const vats = proposal.proposals.find(item => item.actionType === 'vats-disable');
  const fanOn = proposal.proposals.filter(item => item.actionType === 'fan-control' && / On$/i.test(item.rowLabel));
  const fanOff = proposal.proposals.filter(item => item.actionType === 'fan-control' && / Off$/i.test(item.rowLabel));
  assert(vats, 'VATS disable proposal missing');
  assert.equal(vats.proposed, 0);
  assert.equal(fanOn.length, 2);
  assert.equal(fanOff.length, 2);
  assert(fanOn.every(item => item.proposed === 210));
  assert(fanOff.every(item => item.proposed === 190));

  const applied = applyGoalApproved(workspaceF(), proposal, proposal.proposals.map(item => item.id));
  assert.equal(applied.workspace.tables.vats.values[0][0], 0);
  assert.deepEqual(applied.workspace.tables.fans.values, [[210], [190], [210], [190]]);
  assert.equal(Object.keys(applied.workspace.modified).length, 5);

  const parameterMap = { actions: {
    'vats-disable': { cells: [{ tableKey: 'vats', row: 0, col: 0, role: 'disabled-state' }] },
    'fan-control': { cells: [
      { tableKey: 'fans', row: 0, col: 0, role: 'fan-on' },
      { tableKey: 'fans', row: 1, col: 0, role: 'fan-off' },
      { tableKey: 'fans', row: 2, col: 0, role: 'fan-on' },
      { tableKey: 'fans', row: 3, col: 0, role: 'fan-off' }
    ] }
  } };
  const commissioned = buildGoalProposal({ request, workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [], parameterMap });
  assert(commissioned.proposals.every(item => item.confidence === 'commissioned-os-map'));
  assert(commissioned.actions.every(action => action.mapCommissioned));

  const workspaceC = workspaceF('service-c');
  workspaceC.tables.fans.unit = 'deg C';
  workspaceC.tables.fans.values = [[96.1], [91.1], [101.7], [97.8]];
  workspaceC.tables.fans.min = 60;
  workspaceC.tables.fans.max = 115;
  const cProposal = buildGoalProposal({ request, workspace: workspaceC, activeProject: { ...active, id: 'service-c' }, confirmations: {}, ruleFolders: [] });
  const cOn = cProposal.proposals.filter(item => item.actionType === 'fan-control' && / On$/i.test(item.rowLabel));
  const cOff = cProposal.proposals.filter(item => item.actionType === 'fan-control' && / Off$/i.test(item.rowLabel));
  assert(cOn.every(item => Math.abs(item.proposed - 98.888889) < 0.001));
  assert(cOff.every(item => Math.abs(item.proposed - 87.777778) < 0.001));

  const ambiguous = workspaceF('ambiguous');
  ambiguous.tables.vats = { name: 'VATS Type', rowHeaders: ['Value'], colHeaders: ['Value'], values: [[2]] };
  const ambiguousProposal = buildGoalProposal({ request: 'disable VATS', workspace: ambiguous, activeProject: { ...active, id: 'ambiguous' }, confirmations: {}, ruleFolders: [] });
  assert.equal(ambiguousProposal.actions[0].status, 'blocked');
  assert(/will not guess/i.test(ambiguousProposal.actions[0].requirements.join(' ')));

  const unitless = workspaceF('unitless');
  unitless.tables.fans.unit = '';
  unitless.tables.fans.description = 'Fan thresholds';
  const unitlessProposal = buildGoalProposal({ request: 'set fans on at 210 and off at 190', workspace: unitless, activeProject: { ...active, id: 'unitless' }, confirmations: {}, ruleFolders: [] });
  assert.equal(unitlessProposal.actions[0].status, 'blocked');
  assert(/labeled engineering units/i.test(unitlessProposal.actions[0].requirements.join(' ')));

  assert.throws(() => buildGoalProposal({ request, workspace: workspaceF('wrong-project'), activeProject: active, confirmations: {}, ruleFolders: [] }), /does not match the active project/i);
  assert.throws(() => applyGoalApproved(workspaceF('other-project'), proposal, [vats.id]), /does not match/i);

  const invalidHysteresis = buildGoalProposal({ request: 'set fans on at 190 and off at 210', workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [] });
  const fanAction = invalidHysteresis.actions.find(item => item.type === 'fan-control');
  assert.equal(fanAction.status, 'blocked');
  assert(/lower than fan-on/i.test(fanAction.requirements.join(' ')));

  if (!quiet) console.log('✓ P01 quick service: project isolation, VATS disable, 210/190 fan mapping, C/F conversion, and no-guessed-address gates');
  return { scenarios: 9 };
}

if (require.main === module) {
  try { runP01QuickServiceSimulations(); }
  catch (error) { console.error(error.stack || error); process.exit(1); }
}

module.exports = { runP01QuickServiceSimulations };
