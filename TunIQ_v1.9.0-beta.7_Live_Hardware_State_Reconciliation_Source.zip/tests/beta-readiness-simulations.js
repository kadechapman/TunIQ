const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const zlib = require('zlib');
const { BetaManager } = require('../src/beta');

function runBetaReadinessSimulations({ quiet = false } = {}) {
  const projectRoot = path.join(__dirname, '..');
  const html = fs.readFileSync(path.join(projectRoot, 'src', 'renderer', 'index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(projectRoot, 'src', 'renderer', 'app.js'), 'utf8');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta-ready-'));
  try {
    assert(html.includes('data-page="bridge"'), 'Tools must be a permanent main workspace');
    assert(html.includes('id="allModulesGrid"') && html.includes('id="moduleSearch"'), 'searchable All Modules catalog missing');
    assert(html.includes('id="reportBugButton"'), 'permanent Report Bug action missing');
    assert(renderer.includes('function openBugReport()'), 'Report Bug routing missing');
    assert(renderer.includes("title:'Open Tools & All Modules'"), 'Quick Switch must expose the Tool Finder');
    const appendCount = (renderer.match(/container\.appendChild\(card\)/g) || []).length;
    assert.equal(appendCount, 1, 'integration cards must render once, not duplicate');

    const settings = { detailLevel: 'beginner', aiMode: 'guided' };
    const manager = new BetaManager({
      appVersion: '1.9.0-beta.1', dataRoot: () => root,
      getActiveProject: () => ({ id: 'customline', name: 'Customline', controller: 'P01', os: '9379910', binInfo: { name: 'protected.bin', size: 524288 } }),
      getSettings: () => settings,
      getDeviceStatus: () => ({ connected: false, connection: { adapter: 'OBDLink MX+', port: 'COM3' } }),
      getWorkspaceSummary: () => ({ activeProject: { id: 'customline' } }),
      getFlashStatus: () => ({ history: [{ operation: 'testWrite', stopCode: 'adapter-open-timeout' }] }),
      getHardwareSessionReport: () => ({ diagnosis: { category: 'connection' }, evidence: { dualReadVerified: true }, rawBin: Buffer.alloc(32, 1) }),
      getConnectionProfile: () => ({ adapterName: 'OBDLink MX+', lastWorkingPort: 'COM3', identityKey: 'private-device-key' }),
      getActivity: () => [], appendActivity: () => {}
    });
    const file = path.join(root, 'report.tuniqreport');
    manager.exportDiagnostic(file, { description: 'Connection failed', currentPage: 'flash' });
    const report = JSON.parse(zlib.gunzipSync(fs.readFileSync(file)).toString('utf8'));
    assert.equal(report.appVersion, '1.9.0-beta.1');
    assert.equal(report.uiContext.currentPage, 'flash');
    assert.equal(report.connectionProfile.lastWorkingPort, 'COM3');
    assert.equal(report.connectionProfile.identityKey, '[redacted]');
    assert.equal(report.hardwareSession.evidence.dualReadVerified, true);
    assert.equal(report.privacy.rawBinIncluded, false);
    assert(!JSON.stringify(report).includes('buffer 32 bytes'), 'raw BIN buffers must be omitted from diagnostic reports');
    assert(!Object.prototype.hasOwnProperty.call(report.hardwareSession, 'rawBin'), 'rawBin key must be omitted');
    const resilient = new BetaManager({ appVersion: '1.9.0-beta.1', dataRoot: () => root, getActiveProject: () => null, getSettings: () => settings, getDeviceStatus: () => { throw new Error('device subsystem unavailable'); }, getWorkspaceSummary: () => null, getFlashStatus: () => null, getHardwareSessionReport: () => null, getConnectionProfile: () => null, getActivity: () => [], appendActivity: () => {} });
    const resilientFile = path.join(root, 'resilient.tuniqreport'); resilient.exportDiagnostic(resilientFile, { currentPage: 'diagnostics' });
    const resilientReport = JSON.parse(zlib.gunzipSync(fs.readFileSync(resilientFile)).toString('utf8'));
    assert.equal(resilientReport.device.unavailable, true, 'diagnostic export must survive a failed subsystem');
    const result = { passed: true, scenarios: 6 };
    if (!quiet) console.log('Tool Finder & Beta Readiness simulations: 6/6 passed');
    return result;
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runBetaReadinessSimulations();
module.exports = { runBetaReadinessSimulations };
