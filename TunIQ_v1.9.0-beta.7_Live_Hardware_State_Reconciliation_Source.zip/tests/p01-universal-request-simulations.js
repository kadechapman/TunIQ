const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { reviewP01Request, parseP01SafetyFacts } = require('../src/p01-request-review');
const { buildGoalProposal } = require('../src/goal-executor');
const { selectGoalMapCandidates } = require('../src/p01-auto');

function workspace(projectId = 'p01-any-os') {
  return {
    mode: 'xdf', projectId, modified: {}, tables: {
      vats: {
        name: 'Vehicle Anti Theft System Enable', description: 'VATS operating mode', unit: '',
        rowHeaders: ['Value'], colHeaders: ['Value'], values: [[1]],
        enumLabels: [{ index: 0, value: 'Disabled' }, { index: 1, value: 'Enabled' }]
      },
      fans: {
        name: 'Cooling Fan Temperature Control', description: 'Electric fan coolant temperature thresholds', unit: 'deg F',
        rowHeaders: ['Fan 1 On', 'Fan 1 Off', 'Fan 2 On', 'Fan 2 Off'], colHeaders: ['Value'],
        values: [[205], [198], [215], [208]], min: 130, max: 235
      }
    }
  };
}

function runP01UniversalRequestSimulations(options = {}) {
  const quiet = Boolean(options.quiet);
  const active = { id: 'p01-any-os', name: 'Customer P01', controller: 'P01', os: '12587603' };

  const lowRisk = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS and set both electric fans on at 210 F and off at 190 F.'
  });
  assert.equal(lowRisk.ready, true);
  assert.deepEqual(lowRisk.parsed.intents.map(item => item.type), ['vats-disable', 'fan-control']);
  assert.equal(lowRisk.os, '12587603');
  assert.equal(lowRisk.protections.length, 4);

  const highRisk = reviewP01Request({
    activeProject: active,
    request: 'Give it a mild ghost cam, set the rev limiter to 6000 RPM, and set the speed limiter to 190 MPH.'
  });
  assert.equal(highRisk.ready, false);
  assert(highRisk.missingSafetyFacts.some(item => /valvetrain/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /tire speed rating/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /closed-course/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /ghost-idle/i.test(item)));

  const factsText = 'Valvetrain and rotating assembly verified for 6000 RPM. Tires rated 200 MPH. Driveshaft and driveline verified. Brakes, bearings, suspension and stability verified. Closed-course testing only. I accept ghost idle vacuum, brake-assist, emissions and drivability risks.';
  const facts = parseP01SafetyFacts(factsText);
  assert.equal(facts.valvetrainVerified, true);
  assert.equal(facts.tireRatingMph, 200);
  assert.equal(facts.drivelineVerified, true);
  assert.equal(facts.brakesVerified, true);
  assert.equal(facts.closedCourse, true);
  assert.equal(facts.ghostCamRisksAccepted, true);

  const highRiskReady = reviewP01Request({ activeProject: active, request: highRisk.requestText, safetyFacts: factsText });
  assert.equal(highRiskReady.ready, true);
  assert.equal(highRiskReady.missingSafetyFacts.length, 0);
  assert.notEqual(highRisk.requestFingerprint, highRiskReady.requestFingerprint);

  assert.throws(() => reviewP01Request({ activeProject: { ...active, controller: 'P59' }, request: 'Disable VATS' }), /not identified as a P01/i);
  assert.throws(() => reviewP01Request({ activeProject: null, request: 'Disable VATS' }), /activate a P01 project/i);

  const proposal = buildGoalProposal({
    request: lowRisk.requestText,
    workspace: workspace(),
    activeProject: active,
    confirmations: lowRisk.confirmations,
    ruleFolders: []
  });
  const selection = selectGoalMapCandidates(proposal);
  assert.equal(selection.safeToAutoMap, true);
  assert(selection.actionIds.includes('vats-disable'));
  assert(selection.actionIds.some(id => /^fan-/.test(id)));
  assert.equal(selection.proposalIds.length, 5);

  const html = fs.readFileSync(path.join(__dirname, '../src/renderer/index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(__dirname, '../src/renderer/app.js'), 'utf8');
  const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  assert(html.includes('UNIVERSAL P01 COMMAND CENTER'));
  assert(html.includes('CONFIRMATION 1 OF 2') && html.includes('CONFIRMATION 2 OF 2'));
  assert(html.includes('id="quickServiceRequest"'));
  assert(html.includes('id="p01AutoSafetyFacts"'));
  assert(!html.includes('id="quickServiceVats"'));
  assert(!html.includes('id="p01AutoValvetrain"'));
  assert(renderer.includes('reviewP01Request'));
  assert(renderer.includes('quickServicePlanConfirmed'));
  assert(main.includes("ipcMain.handle('p01-request:review'"));

  if (!quiet) console.log('✓ Universal P01 request center: any P01 OS, typed safety facts, VATS/fan automap, and two-stage confirmation');
  return { scenarios: 10 };
}

if (require.main === module) {
  try { runP01UniversalRequestSimulations(); }
  catch (error) { console.error(error.stack || error); process.exit(1); }
}

module.exports = { runP01UniversalRequestSimulations };
