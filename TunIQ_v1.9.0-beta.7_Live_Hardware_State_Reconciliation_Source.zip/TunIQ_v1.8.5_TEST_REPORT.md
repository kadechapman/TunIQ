# TunIQ v1.8.5 Test Report

## Release
PCM Hammer Runtime Ownership Reconciliation

## Real failure fixed
The Customline project continued to display PcmHammer.exe PID 11816 and pcmhammer-cli.exe PID 12412 as adapter conflicts after cleanup, and Hardware Session Doctor incorrectly recommended COM1.

## Corrections
- Polls fresh Windows process inventories after every registered-process cleanup attempt, even when taskkill returns a non-zero code.
- Waits for registered root PIDs to actually disappear before classifying live conflicts.
- Clears persisted adapter-conflict-process stops when no current conflict exists.
- Rejects unrecognized COM1 fallback recommendations.
- Prefers last-successful, active-project, and recognized outgoing OBDLink ports.
- Preserves verified reads, protected original, commissioning XDF, stock clone, and Test Write-only safety boundary.

## Verification
- Source syntax checks: PASS
- Full automated suite: PASS — 36 groups
- Session Guard simulations: PASS — 12 scenarios
- Hardware Session Doctor simulations: PASS — 7 scenarios
- Delayed PID exit with taskkill failure: PASS
- COM1 rejection and COM3 persistence: PASS

No physical Test Write success is claimed.
