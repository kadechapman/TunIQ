# TunIQ v1.8.7 Intelligent Connection Manager

TunIQ no longer launches PCM Hammer against a remembered COM number without first rebuilding the live Windows adapter inventory.

- Identifies OBDLink/STN and Bluetooth SPP devices by friendly name, hardware identity, container/pair key, and previous successful profile.
- Prefers a recognized outgoing/client Bluetooth port over an incoming/server port.
- Validates candidate availability before PCM Hammer starts.
- Never selects generic COM1 unless Windows positively identifies an OBDLink there.
- Stores a persistent adapter profile under `%AppData%\TunIQ\Tools\obdlink-adapter-profile.json`.
- Returns explicit `adapter-not-detected`, `missing-outgoing-port`, or `ports-unavailable` repair states.
- Preserves all P01 evidence and performs no actual PCM write.
