# TunIQ v1.8.6 — PCM Hammer Clean Session Reset

- Force-closes every running PCM Hammer GUI/CLI process tree before an integrated hardware session.
- Does not classify PCM Hammer itself as an adapter conflict after the reset.
- Waits for a fresh Windows inventory with no PCM Hammer process before launch.
- Clears persisted adapter-conflict-process state when no unrelated OBD application remains.
- Keeps COM3/recognized OBDLink routing and rejects generic COM1 fallback.
- Preserves verified P01 evidence and performs Test Write only.
