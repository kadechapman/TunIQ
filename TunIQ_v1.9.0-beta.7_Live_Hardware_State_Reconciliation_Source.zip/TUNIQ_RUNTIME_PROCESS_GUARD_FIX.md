# TunIQ Runtime Process Guard Fix

The direct PCM Hammer handoff exposed a false conflict in which the source folder name contained `OBDLink`. The previous guard searched complete command lines, so TunIQ's own `cmd.exe`, `node.exe`, and `electron.exe` runtime processes were misidentified as external OBD applications.

Version 1.9.0-beta.6:

- Builds the TunIQ runtime family from Windows parent/child PID relationships.
- Excludes only generic TunIQ runtime hosts connected to the current Electron process.
- Matches exclusive OBD applications by process name and executable identity, not arbitrary folder text.
- Continues to block real external OBD and serial applications.
- Preserves the selected COM port, project evidence, read-only direct handoff, and no-write boundary.
