# TunIQ v1.8.5 — PCM Hammer Runtime Ownership Reconciliation

- Polls fresh Windows process inventories after cleanup even when taskkill returns a non-zero result.
- Waits for registered PCM Hammer root PIDs to actually disappear before classifying conflicts.
- Clears persisted adapter-conflict-process stops when the reported PIDs are no longer live.
- Preserves genuine external-process blocking.
- Rejects COM1 as a generic fallback unless the OBD adapter was positively recognized there.
- Prefers the active project port, last successful port, and recognized outgoing Bluetooth ports.
- Does not alter verified reads, protected originals, definitions, revisions, or Test Write safety locks.
