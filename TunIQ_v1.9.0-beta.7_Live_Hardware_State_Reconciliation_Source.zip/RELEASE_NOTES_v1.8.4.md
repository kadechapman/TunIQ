# TunIQ v1.8.4 — PCM Hammer Process-Tree Cleanup Hotfix

## Real failure corrected
TunIQ v1.8.3 could terminate a TunIQ-owned stale PCM Hammer process tree and then immediately block itself because it classified the process inventory captured before cleanup. The stopped screen could list `PcmHammer.exe` and `pcmhammer-cli.exe` even after `taskkill /T` had removed them.

## Fixes
- Rescans the Windows process inventory after any owned-process cleanup.
- Waits briefly for the GUI/CLI process tree and serial handle to retire.
- Classifies only the fresh post-cleanup inventory.
- Captures parent process IDs for clearer process-tree diagnostics.
- Reports whether a post-cleanup rescan occurred and both inventory counts.
- Keeps genuinely external PCM Hammer, OBDwiz, FORScan, and serial-terminal conflicts blocked.
- Preserves verified reads, protected original, commissioning definition, stock clone, and Safety Vault behavior.
- No actual PCM write is performed automatically.
