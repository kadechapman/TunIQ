# PCM Hammer Runtime Ownership Reconciliation

This hotfix addresses the real Customline session where stale PcmHammer.exe and pcmhammer-cli.exe PIDs remained in the saved stop message after the process tree was no longer usable. TunIQ now treats process ownership as live evidence, not a cached PID list or taskkill exit code.
