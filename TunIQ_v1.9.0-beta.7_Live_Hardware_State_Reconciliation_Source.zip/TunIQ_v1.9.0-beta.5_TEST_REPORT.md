# TunIQ v1.9.0-beta.5 Test Report

## Release

- Version: `1.9.0-beta.5`
- Name: OBDLink Re-pair & Direct PCM Hammer Handoff
- Base: verified `v1.9.0-beta.4` source
- Physical P01 hardware success: **not claimed**
- Actual PCM write performed: **no**

## Problem addressed

Windows exposes COM3/COM4 for the OBDLink MX+, but the TunIQ adapter-only serial verifier cannot open either endpoint. The bounded Windows SPP rebuild also completes without producing an openable client port. That left the P01 workflow blocked before Read Properties even though PCM Hammer itself had not been allowed to test the deliberately selected port.

## Implemented

- Added a guided **Pair / Re-pair OBDLink** action.
- Added a live Windows COM selector.
- Added **Verify Selected COM** using adapter-only `ATI`, `AT@1`, and `STDI` identity checks.
- Added **Try Selected COM with PCM Hammer** as a controlled fallback.
- The first direct fallback is limited to the read-only **Read Properties** step.
- TunIQ passes exactly one user-selected COM port to PCM Hammer and does not run its own serial probe first.
- A port becomes PCM Hammer-proven only after a successful controller operation.
- The proven port may be reused for the two protected full reads and Test Write.
- Calibration Write, Full Write, and Recovery cannot use the direct bypass.
- Existing project identity, saved request, reads, definition, revision, and Test Write evidence remain project-scoped and preserved.

## Automated results

- Source syntax checks: **passed**
- Bluetooth SPP rescue/re-pair scenarios: **7/7 passed**
- Manual PCM Hammer handoff scenarios: **4/4 passed**
- Verified Adapter Connection Broker scenarios: **12/12 passed**
- Full automated suite: **42/42 groups passed**
- Complete retained recovery chain: **passed**
- Clean extracted archive checks: recorded separately in the archive verification report

## Hardware boundary

The direct handoff and safety restrictions were validated using simulated Windows COM inventories and the mock PCM Hammer CLI. The user's physical OBDLink/PCM result is still unconfirmed. No actual PCM write is claimed.
