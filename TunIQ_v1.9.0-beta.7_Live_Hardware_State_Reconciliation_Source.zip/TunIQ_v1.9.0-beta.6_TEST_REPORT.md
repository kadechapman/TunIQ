# TunIQ v1.9.0-beta.6 Test Report

## Release

**TunIQ v1.9.0-beta.6 — TunIQ Runtime Process Guard Fix**

## Real failure reproduced

The direct PCM Hammer handoff was stopped by `adapter-conflict-process` because the Hardware Session Guard interpreted the word `OBDLink` in TunIQ's own source-folder command line as an external OBD application. The reported processes were TunIQ's own `cmd.exe`, `node.exe`, and `electron.exe` runtime family.

## Fix verified

- Builds the current TunIQ runtime family from Windows parent/child PID relationships.
- Excludes only generic TunIQ runtime hosts connected to the active Electron process.
- Matches exclusive OBD tools by actual process name/executable identity rather than arbitrary folder text.
- Preserves blocking for a real external OBDwiz process and serial tools that reference the selected COM port.
- Preserves the beta.5 read-only direct PCM Hammer handoff and all write restrictions.

## Automated results

- Source syntax checks: **passed**
- Exact screenshot regression: **passed**
- Session Guard/Safety Vault scenarios: **15/15 passed**
- Full automated suite: **42/42 groups passed**
- Complete retained recovery chain: **passed**
- Real hardware Read Properties: **not claimed**
- Actual PCM write: **not performed**

Logs are stored in `test-results/`.
