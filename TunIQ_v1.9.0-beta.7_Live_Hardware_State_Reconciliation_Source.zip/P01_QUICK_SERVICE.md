# Multi-P01 Quick Service

This workflow is for an additional GM P01 that needs a small, explicit calibration revision without contaminating another vehicle project.

## Supported request

- Disable VATS / vehicle theft deterrent for an authorized engine-swap or repair project.
- Set clearly labeled electric-fan temperature cells to 210°F on and 190°F off.

## Required evidence

1. A separate TunIQ project for the physical PCM.
2. PCM identity captured for that controller and OS.
3. Two complete 524,288-byte reads with matching SHA-256 hashes.
4. A protected original BIN from that read pair.
5. An exact writable XDF for the same OS.
6. Unambiguous VATS and fan on/off cells with explicit engineering units.

## Hard stops

TunIQ blocks the workflow when the project/workspace identity differs, the XDF is read-only, VATS has no explicit disabled state, fan cells lack °F/°C units, fan-off is not lower than fan-on, or any address/value would need to be guessed.

The quick-service action only creates a revision. Test Write and any real PCM write remain separate operations. Verify the vehicle's fan wiring, relay outputs, coolant-temperature signal, thermostat, and safe voltage before hardware testing.
