# TunIQ v1.9.0-beta.2 Test Report

Release: Universal P01 Request Center

## New coverage

- Any isolated P01 project and OS can enter the natural-language request-review workflow.
- Non-P01, missing-project, and cross-project requests are rejected.
- VATS and fan requests do not require unrelated checkbox acknowledgements.
- Elevated-RPM, high-speed, and ghost-idle requests identify only the safety facts that actually apply.
- Typed safety facts populate the existing strict goal-executor confirmations.
- Request fingerprints are bound to the active project, controller, OS, requested changes, and supplied safety facts.
- Changing the project, request, or safety facts invalidates both confirmations.
- VATS and both fan on/off roles can be selected by Guided P01 strict mapping.
- Exact-OS writable definitions and unambiguous cells remain mandatory.
- Existing saved commissioning evidence can resume without repeating completed work.
- Old quick-service and Guided P01 checkbox-wall controls are absent.
- Two staged confirmation controls are present before revision creation.
- Request-review IPC is exposed through the context-isolated preload bridge.
- Revision creation remains separate from Test Write and any real PCM write.

## Results

- Source syntax checks: passed.
- Universal P01 request simulations: 10/10 passed.
- Existing P01 quick-service simulations: 9/9 passed.
- Complete automated suite: 39/39 groups passed.
- Complete retained recovery-lab chain: passed.
- No real hardware Test Write or PCM write is claimed.
