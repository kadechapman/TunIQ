# TunIQ v1.8.8 — Tool Finder & Beta Readiness

## Discoverability
- Tools is restored to the permanent sidebar.
- Every TunIQ module is searchable from the new All Modules catalog.
- Quick Switch includes direct P01 Setup, Calibration, Revision, Patch, Tool, and Bug Report actions.
- The Dashboard now exposes Tools directly.

## Beta feedback
- A permanent Report Bug button opens the privacy-safe beta report form.
- Diagnostic packages include sanitized hardware-session and connection-profile context.
- Raw BIN files, raw XDF files, protected project files, credentials, VINs, emails, and usernames are not included.

## Bug fixes
- Fixed integration cards appearing twice on the Tool Connections page.
- Updated navigation highlighting after promoting Tools out of Settings.
