# Bluetooth SPP Rescue & Exact-Step Resume

TunIQ v1.9.0-beta.4 adds one bounded Windows Bluetooth repair before stopping a P01 hardware step. It starts the required Bluetooth services, enables the remote Serial Port Profile (SPP) service for a remembered OBDLink device through the Windows Bluetooth API, requests a PnP rescan, rebuilds the COM inventory, verifies the adapter identity, and resumes the exact preserved P01 phase.

The repair never clears verified reads, never reuses another project BIN, and never starts a PCM write. If Windows still does not create an openable outgoing/client COM port, TunIQ exposes Windows Bluetooth COM setup instead of looping through COM ports.
