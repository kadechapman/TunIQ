# PCM Hammer Process-Tree Hotfix

The hardware session guard now follows this order:

1. Inventory processes.
2. Verify registry ownership of stale PCM Hammer roots.
3. Terminate only verified TunIQ-owned process trees with `taskkill /T /F`.
4. Wait for Windows to release the child CLI and serial handle.
5. Inventory processes again.
6. Block only conflicts that still exist in the fresh inventory.

This prevents a terminated PCM Hammer GUI/CLI tree from being reported as a live adapter conflict.
