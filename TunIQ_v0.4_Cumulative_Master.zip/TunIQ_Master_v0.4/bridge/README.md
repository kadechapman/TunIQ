# TunIQ Wave 4 Bridge

Wave 4 includes an experimental **read-only browser serial connector** for some ELM327-style adapters. It uses standard OBD-II Mode 01 PIDs and Mode 03 DTC reads.

It does not support PCM Hammer, J2534, CAN programming, code clearing, calibration editing, reading BIN files, writing controllers, or recovery. A dedicated signed Windows bridge is planned for Wave 5.
