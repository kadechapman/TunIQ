# TunIQ v0.4 — Wave 4: Live Diagnostics Foundation

This cumulative release contains the functionality from Waves 1–3 and adds a scanner workspace, demo/replay mode, data recording/export, DTC organization, live charts, and an experimental read-only ELM327 serial connection for supported desktop browsers.

## Fast preview

Open `index.html`, go to **Scanner**, and select **Run demo**. This requires no vehicle or adapter. CSV replay and export also work locally.

## Run with the optional AI backend

1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Set `OPENAI_API_KEY` in the environment.
4. Run `npm start`.
5. Open `http://localhost:8787`.

## Experimental adapter connection

On a desktop Chromium browser that exposes Web Serial, open TunIQ from localhost or a secure origin and select **Connect adapter**. The current implementation targets common serial ELM327-style adapters and only requests basic read-only OBD-II information. Adapter clones, baud rates, protocols, vehicle support, and browser support vary, so demo/replay is the dependable Wave 4 path.

## Included

- Everything from Waves 1–3
- Scanner demo mode
- Experimental read-only serial adapter path
- RPM, coolant, speed, throttle, MAP, and voltage displays
- Live graphing, recording, CSV export, and CSV replay
- Mode 03 DTC reading framework and local code explanations
- Session/command log
- Optional AI backend
- Smoke tests and syntax checks

## Not included yet

No PCM Hammer control, J2534, code clearing, BIN reading/writing, calibration editing, checksums, controller flashing, recovery, or automatic tuning. Those capabilities require the dedicated Windows bridge and hardware bench testing planned for later waves.
