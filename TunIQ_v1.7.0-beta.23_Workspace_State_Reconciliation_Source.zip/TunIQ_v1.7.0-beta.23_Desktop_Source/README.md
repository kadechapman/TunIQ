# TunIQ v1.7.0-beta.23 — Workspace State Reconciliation

Beta.23 fixes the remaining P01 commissioning dead end where Calibration visibly showed the protected BIN and commissioning-only XDF as **BOUND**, but Guided Setup still reported that they were not loaded.

## What changed

- Reconciles the P01 commissioning state from the actual protected BIN, the two verified read files, the active XDF, and the saved Calibration workspace.
- Ignores stale beta.21/beta.22 canonical hashes and legacy workspace source fields when the current on-disk binding is proven.
- Keeps writable definitions fingerprint-strict; relaxed reconciliation applies only to TunIQ commissioning-only definitions with zero writable tables.
- Converts the old unrecoverable `unexpected-error` definition stop into a resumable `create-revision` step.
- Makes the header **Refresh** button perform a real backend reload and reconciliation instead of repainting cached renderer state.
- Runs the same reconciliation automatically at startup and before **Resume Failed Step**.
- Continues to the unchanged stock-clone revision and integrated PCM Hammer Test Write without asking the user to load BIN/XDF files manually.

## Existing Customline project

Open the existing project and press **Resume Failed Step**. Beta.23 will repair the bound workspace first and continue at stock-clone creation. The header Refresh button can also repair the state and then expose Resume.

## Safety boundary

The commissioning definition remains read-only with zero writable calibration tables. This update completes hardware commissioning and Test Write only; it does not unlock AI/manual tuning or PCM writing without a trusted writable definition.

See `WORKSPACE_STATE_RECONCILIATION_HOTFIX.md` and `TEST_REPORT_v1.7.0-beta.23.md`.
