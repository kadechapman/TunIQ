# TunIQ v1.7.0-beta.17 — Integrated PCM Hammer Pipeline Test Report

## Release purpose

Beta.17 removes the external assisted PCM Hammer step from Guided Automatic P01 Setup. The normal workflow now keeps Read Properties, two full reads, Test Write, and an explicitly authorized calibration write under one TunIQ operation coordinator.

This release was created in response to a real beta.16 hardware-session screenshot where Guided Setup reached `assisted-readProperties` and required the user to leave TunIQ.

## Implemented changes

- Added an explicit COM-port ownership lease with owner, port, operation, lease ID, and timestamp.
- TunIQ closes its own OBD bridge and aborts stale bridge requests before granting PCM Hammer the port.
- Removed the separate pre-operation lock probe that could open the same Bluetooth serial port and race PCM Hammer.
- Added an internal PCM Hammer process runner that captures stdout, stderr, progress, voltage, identity, read output, Test Write proof, and write verification.
- Added safe runtime discovery for several PCM Hammer 2.x command-line forms when help/version output is blank.
- Runtime command discovery is permitted only for Read Properties and full read.
- A command profile is retried only after a clear syntax failure, before any serial/adapter communication, and before any output file exists.
- Test Write and write operations require a profile already proven by a non-destructive operation.
- Successful profile discovery is cached for the installed CLI.
- Read Properties results are imported automatically.
- Full reads are accepted only when PCM Hammer proves success and the file is exactly 524,288 bytes.
- Guided Setup still requires two independent full reads with matching SHA-256 hashes.
- Test Write proof and controlled-write verification remain bound to the exact revision.
- Old beta.15/beta.16 `assisted-*` states migrate to an integrated resumable step.
- The former assisted-bypass button now retries the internal runner.
- Manual PCM Hammer launch/import remains in a collapsed advanced recovery section only.

## Automated verification

- `npm run check`: **PASS**
- `npm test`: **PASS — 22/22 automated groups**
- `npm run test:integrated-pcmhammer`: **PASS — 3/3 scenarios**
- `npm run test:recovery-labs`: **PASS — 33/33 focused simulations**

### Integrated PCM Hammer scenarios

1. **Runtime profile discovery**
   - CLI help/version output intentionally blank.
   - First command form rejected before communication.
   - Second known profile accepted and cached.
   - No separate lock-probe serial open occurred.

2. **Complete internal pipeline**
   - Read Properties completed internally.
   - Two independent 524,288-byte reads completed and matched by SHA-256.
   - Test Write completed and was explicitly proven.
   - Controlled calibration write completed in simulation with verification proof.

3. **Safe failure and legacy migration**
   - Every known command form rejected before communication.
   - TunIQ stopped with `integrated-cli-profile-unresolved` and did not open an external window.
   - A beta.16 assisted state migrated and resumed at the exact internal step.

## Retained safety and recovery coverage

The recovery suite also passed COM cleanup, app restart/resume, adapter lock, adapter disconnect, partial read rejection, mismatched read rejection, repeated block failures, Garage lifecycle, project workspace recovery, Connection Doctor, Offline P01 Lab, tune-engine, autonomous-tune, and closed-loop-tune simulations.

## Verification boundary

This release is **software and simulation verified only**. It has not yet been proven with the user's physical OBDLink MX+, Windows Bluetooth COM3, vehicle, P01 PCM, real PCM Hammer 2.0 CLI process, Test Write, or live calibration write.

The installed Windows CLI must still prove one supported command profile at runtime. If none is accepted, TunIQ stops safely inside the app and records every attempted syntax. It does not guess a destructive command or silently launch another program.

No real hardware verification or flash-success claim is made.
