# TunIQ v1.7.0-beta.22 Test Report

## Release

**Automatic Commissioning Definition Binding**

Built from TunIQ v1.7.0-beta.21 P01 Setup Completion.

## Reproduced user failure

Beta.21 correctly generated and installed a read-only commissioning definition for P01 OS 9379910, but Guided Setup stopped with:

> Load the protected original and XDF in Calibration before confirming the definition.

The project header showed both files, so the stop was incorrect. The calibration workspace could inherit a stale `active.binInfo.sha256` cached by an older beta. The P01 manager compared that stale workspace fingerprint with the canonical SHA-256 proven by the two matching PCM reads and refused to bind it.

## Fixes

- Workspace bindings now hash the protected BIN bytes directly.
- XDF workspace loading refreshes stale BIN and XDF project metadata.
- Commissioning definitions created by TunIQ bind automatically; no manual Calibration load is required.
- A beta.21 stale commissioning workspace is archived and rebuilt once if encountered during Resume.
- The exact OS, two-read proof, protected-original hash, XDF hash, and zero-writable-table boundary remain enforced.
- Guided Setup continues to create an unchanged stock clone and then runs PCM Hammer Test Write.
- AI tuning, manual calibration changes, Calibration Write, Full Write, and OS conversion remain locked when only the commissioning definition is available.

## Verification results

- Source syntax check: **PASS**
- Automated test groups: **27/27 PASS**
- Focused simulations: **46/46 PASS**
- New stale-fingerprint commissioning scenario: **PASS**
- Existing P01 setup-completion scenarios: **4/4 PASS**
- Definition pipeline: **3/3 PASS**
- Real PCM Hammer CLI command recovery: **3/3 PASS**
- Integrated PCM Hammer pipeline: **3/3 PASS**
- COM recovery: **3/3 PASS**
- Startup recovery: **3/3 PASS**
- Closed-loop tuning: **3/3 PASS**
- Autonomous Tune: **3/3 PASS**
- Unified Tune Engine: **3/3 PASS**
- Garage: **3/3 PASS**
- Project workspace: **3/3 PASS**
- QoL: **3/3 PASS**
- Connection Doctor: **3/3 PASS**
- Offline P01 Lab: **3/3 PASS**
- P01 hardware recovery: **3/3 PASS**

## New regression evidence

The new scenario deliberately sets the project BIN cache to an incorrect SHA-256 while the protected BIN on disk and both verified reads remain valid. It proves that:

- the real file hash overrides stale metadata;
- the generated OS 9379910 commissioning XDF binds automatically;
- exact-definition confirmation succeeds;
- no manual Calibration loading is required;
- zero writable tuning tables remain enforced.

## Hardware boundary

This release was tested with software simulations and filesystem state only. It was not launched on the user's Windows PC and does not claim a real COM3, OBDLink MX+, vehicle, P01 PCM, or physical PCM Hammer Test Write result.
