# TunIQ v1.7.0-beta.12 Test Report

## Release

- Version: `1.7.0-beta.12`
- Name: **Unified Tune Engine & AI Tune Planner**
- Base source: TunIQ v1.7.0-beta.11 Tune Workspace & Revision Control
- Test date: July 20, 2026
- Runtime used for source tests: Node.js 22.16.0 / npm 10.9.2

## Objective

Beta.12 is the largest tuning-workflow update before the planned 2.0 release. It connects Garage/build data, project-scoped BIN/XDF workspaces, logs, AI planning, exact-cell proposals, approvals, snapshots, checksum-corrected revision export, audit history, and protected external-tool handoff.

## New feature verification

The Unified Tune Engine was tested for:

- Project-scoped durable plans, proposals, applied stages, and audit history.
- Exact BIN/XDF fingerprint binding and stale-workspace rejection.
- XDF role coverage and ambiguity reporting.
- Readiness scoring from build data, table coverage, evidence, and confirmations.
- Recovery, baseline, drivability, airflow, fueling, spark, transmission, validation, and flash stages.
- Exact-cell proposals for supported mapped tables.
- Apply-time value, percentage, XDF min/max, fingerprint, and stage safety checks.
- Automatic spark reduction from repeated logged knock while rejecting automatic spark increases.
- Restart/resume behavior and proposal persistence.
- Before/after project snapshots and revision-control integration.
- Handoff bundles containing project identity, fingerprints, plan, applied-stage history, warnings, and an optional exported revision.
- Separation between tune preparation and separately confirmed Flash Center writes.

## Automated suite

Command: `npm test`

Result: **17 of 17 automated groups passed.**

The suite covered XDF parsing/writing, checksum correction, AI log proposals, PCM Hammer 2.0 command handling, strict P01 reads, logger persistence, Connection Doctor, Offline P01 Lab, QoL state, Garage/project links, project-scoped revision control, Unified Tune Engine, public-beta privacy, phone-log import, natural-language goals, P01 commissioning/evidence, Guided P01 state, and renderer/preload/main IPC contracts.

## Focused software simulations

All were run as separate commands after the automated suite.

| Area | Scenarios | Result |
|---|---:|---|
| Unified Tune Engine | 3 | Passed |
| Garage/project lifecycle | 3 | Passed |
| Project workspace/revision recovery | 3 | Passed |
| Quality-of-life restart/navigation | 3 | Passed |
| Connection Doctor | 3 | Passed |
| Offline P01 Recovery Lab | 3 | Passed |
| P01 hardware-recovery emulation | 3 | Passed |
| **Total** | **21** | **Passed** |

The Tune Engine scenarios specifically exercised:

1. A clean staged street-tune workflow with recognized idle, fan, limit, MAF, VE, PE, spark, and transmission tables.
2. Application restart/resume, durable proposal/audit state, and a complete external-tool handoff bundle.
3. Low-voltage, missing-wideband, incomplete fuel-system confirmation, forced-induction gating, BIN fingerprint mismatch, and attempted automatic spark-increase rejection.

## Source checks

Command: `npm run check`

Result: passed for Electron main/preload/renderer sources, tuning/calibration modules, all retained recovery modules, the Unified Tune Engine, and all simulation scripts.

## Safety and verification boundary

This release was verified through source-level tests, static IPC/DOM contracts, generated calibration fixtures, mock PCM Hammer processes, synthetic logs, and software simulations.

**No claim is made that beta.12 was verified with a physical OBDLink MX+, Windows Bluetooth COM port, vehicle, bench harness, PCM, real dynamometer, road test, or live controller write.** The Linux build environment could not physically exercise Windows Bluetooth, PowerShell serial access, Electron GUI interaction with real devices, or the external tuning programs.

The Unified Tune Engine is not a universal autonomous tuner. Automatic changes require exact writable XDF mappings and supported roles. Unknown mappings, injector characterization without exact data, calibration-segment surgery, automatic spark increases, aggressive unsupported power tuning, and silent PCM writes remain blocked or require qualified human/external-tool review.

## Logs

Command output and JSON reports are retained in the source package under `test-results/`.
