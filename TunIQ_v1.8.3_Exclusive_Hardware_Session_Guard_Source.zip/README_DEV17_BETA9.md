# TunIQ v1.7.0-beta.9 — Quality of Life

This release keeps the beta.8 Connection Doctor, Offline P01 Recovery Lab, and beta.7 hardware-recovery protections while making normal desktop use faster and less repetitive.

## Added

- **Quick Switch (`Ctrl+K`)** searches pages, saved projects, Connection Doctor, project creation, Garage, BIN import, and XDF import.
- **Instant active-project switcher** in the header.
- **Back and forward navigation** with header buttons or `Alt+Left` / `Alt+Right`.
- **Collapsible sidebar** with `Ctrl+B` and persistent state.
- **Restart restoration** for the last page, recent pages, Tune Path state, sidebar state, density preference, reduced-motion preference, and per-page scroll positions.
- **Recent Work** panel on the Dashboard.
- **Compact density** and **reduced motion** settings.
- **Non-blocking toast notifications** for normal status changes while destructive or flash-sensitive confirmations remain blocking.
- Escape closes Quick Switch and keyboard navigation works with Up, Down, and Enter.

## Safety boundaries

This update does not weaken flash confirmation, P01 commissioning, checksum validation, read-size validation, Test Write requirements, or critical-write shutdown protection.

## Verification boundary

The release is tested through source checks, automated unit/integration tests, renderer contracts, and simulated recovery workflows. It is not claimed as real-vehicle or real-adapter verification.
