# TunIQ v1.8.1 Test Report

## Release

- Version: `1.8.1`
- Channel: `stable`
- Name: **PCM Hammer COM Failover Hotfix**
- Base: `TunIQ v1.8.0 — Dashboard & Quality of Life`
- Primary retained hardware project: Customline, GM P01, OS 9379910

## Real failure addressed

TunIQ v1.8.0 correctly recovered the existing verified commissioning evidence and continued directly to PCM Hammer Test Write, but the physical run stopped after PCM Hammer attempted to open `COM3`. The stopped screen only identified COM3, showing that the fallback path did not reliably recognize every Windows Bluetooth serial-port naming pattern.

This hotfix broadens the pre-communication port-open failure detector and rebuilds the fallback sequence around fresh Windows and PCM Hammer device inventories.

## Runtime recovery changes verified

- Recognizes `Unable to open serial port`, `Failed to open`, `Could not open`, timeout, access-denied, unavailable-port, and busy-port variants as pre-communication open failures.
- Does not mistake a lone `Opening serial port COMx` line for successful PCM communication.
- Releases TunIQ serial ownership and aborts known PowerShell bridge activity before each PCM Hammer handoff.
- Retries the selected port once before switching ports.
- Rescans Windows serial devices and PCM Hammer device output after the retry fails.
- Recognizes generic Windows names such as `Standard Serial over Bluetooth link`.
- Ranks outgoing/client Bluetooth ports above incoming/server ports.
- Uses Bluetooth PnP parent/container pairing evidence to recognize sibling COM ports.
- Falls back to `System.IO.Ports.SerialPort.GetPortNames()` when richer Windows metadata is unavailable.
- Preserves separate stdout and stderr logs, exit code, attempted port, source, and open-failure classification for every launch.
- Shows all tested ports and discovered candidate ports on the stopped screen.
- Preserves the verified read pair, protected original, commissioning definition, and deterministic stock clone throughout recovery.
- Performs Test Write only. It does not authorize or initiate a real PCM write.

## Focused PCM Hammer scenarios

All five dedicated runtime scenarios passed:

1. `COM3` timeout → retry `COM3` → outgoing `COM4` succeeds.
2. Only `COM3` exists → two bounded attempts → exact `adapter-open-timeout` stop.
3. Generic Bluetooth names plus real `Unable to open serial port` output → `COM4` succeeds.
4. First scan misses `COM4`; post-failure rescan discovers it → `COM4` succeeds.
5. Missing kernel files → stops before PCM Hammer is launched.

## Automated verification

- Source syntax/static validation: **PASS**
- Full automated suite: **PASS — 34/34 groups**
- PCM Hammer Test Write runtime recovery: **PASS — 5/5 scenarios**
- P01 continuity-lock recovery: **PASS**
- P01 Setup Finalizer: **PASS — 4/4 scenarios**
- Final 48%-to-Test-Write completion harness: **PASS — 3/3 scenarios**
- Clean P01 commissioning simulation: **PASS**
- Adapter lock, disconnect, and app-restart recovery simulation: **PASS**
- Partial/mismatched/repeated-block read rejection and recovery: **PASS**
- Dashboard, tachometer-Q startup, and eight-workspace navigation: **PASS**
- Garage, project workspace, revision control, definitions, tuning, AI, logging, Connection Doctor, startup recovery, and retained recovery labs: **PASS**

The retained logs are included under `test-results/`.

## Safety assertions

- The two verified 524,288-byte commissioning reads remain immutable evidence.
- Failed, partial, mismatched, and unnecessary later reads cannot replace the verified pair.
- The unchanged commissioning stock clone is reused rather than duplicated.
- A read-only OS 9379910 commissioning definition continues to block manual tuning, AI tuning, Calibration Write, Full Write, and OS conversion.
- Successful Test Write may mark hardware setup complete, but it does not mean a PCM write occurred.
- No automatic real write was added.

## Hardware boundary

This release is source-, archive-, and simulation-verified. It has not yet proven a physical Test Write on the user's Windows Bluetooth stack, OBDLink MX+, COM3/COM4 ports, Customline, or P01 PCM. Real hardware success must only be claimed after the user confirms the Test Write passes.
