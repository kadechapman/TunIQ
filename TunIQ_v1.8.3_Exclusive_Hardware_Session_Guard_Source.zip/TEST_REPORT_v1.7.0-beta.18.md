# TunIQ v1.7.0-beta.18 — Startup Recovery Hotfix Test Report

## Release purpose

Beta.18 is a focused correction for the Windows startup failure reported immediately after beta.17. The planned 1.8 dashboard/navigation redesign is intentionally deferred until the current 1.7 line starts reliably.

## Reproduced failure

The reported stack was:

```text
ReferenceError: s is not defined
at renderP01Auto
at refreshWorkspace
at init
```

The failing expression was in `src/renderer/app.js` while restoring the Guided P01 automation state. It attempted to read `s.stop.code`, but no variable named `s` existed in that function.

## Corrections

- Replaced the undefined reference with the current automation object: `auto.stop.code`.
- Added a renderer isolation boundary around major workspace sections.
- Wrapped the initial workspace refresh render chain.
- Wrapped Guided P01 progress-event rendering.
- Wrapped the post-bootstrap renderer chain.
- Added static rejection of the beta.17 expression.
- Added executable tests using the actual shipped `renderP01Auto` function.

## Dedicated beta.18 startup scenarios

1. **Exact startup reference-error regression**
   - Loads a paused integrated PCM Hammer recovery state.
   - Includes an `unsupported-cli` stop code.
   - Confirms the renderer does not throw.
   - Confirms Resume and integrated retry remain available.

2. **Renderer isolation boundary**
   - Forces one renderer to throw.
   - Confirms the error is contained and reported.
   - Confirms the following renderer still executes normally.

3. **P01 state coverage**
   - Renders active full-read progress.
   - Renders a COM timeout with alternate-port attempts.
   - Renders ready-to-write state and confirmation text.

Result: **3/3 passed**.

## Full automated verification

- Source syntax checks: passed.
- Automated test groups: **23/23 passed**.
- Focused recovery and workflow simulations: **36/36 passed**.
- Integrated PCM Hammer simulations: passed.
- COM recovery simulations: passed.
- Closed-loop autonomous tuning simulations: passed.
- Autonomous Tune Agent simulations: passed.
- Unified Tune Engine simulations: passed.
- Garage/project simulations: passed.
- Project-workspace simulations: passed.
- Quality-of-life simulations: passed.
- Connection Doctor simulations: passed.
- Offline P01 Recovery Lab simulations: passed.
- P01 hardware-recovery simulations: passed.

## Protected behavior retained

Beta.18 does not weaken or remove:

- Protected original BIN handling.
- Two independent 524,288-byte read requirement.
- Matching SHA-256 requirement.
- Exact-OS XDF binding.
- Checksum/revision validation.
- Test Write proof.
- Exclusive COM ownership.
- Separate explicit final-write confirmation.

## Validation boundary

The build environment verified source behavior and simulations. It did not launch the application on the user's Windows PC and did not verify a physical OBDLink MX+, Bluetooth COM port, vehicle, P01 PCM, Test Write, or live calibration write.
