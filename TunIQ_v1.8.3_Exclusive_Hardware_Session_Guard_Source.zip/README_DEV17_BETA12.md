# TunIQ v1.7.0-beta.12 Developer Notes

## Release objective

Beta.12 replaces the separate “Full AI plan,” natural-language goal executor, and log proposal experience with a shared project-scoped orchestration layer. Existing engines remain available, but Tune Studio is now the primary coordinator for staged tuning work.

## New architecture

`src/tune-engine.js` owns:

- XDF table-role classification and confidence ranking.
- Project/build target normalization.
- Log health and instrumentation gates.
- Tune readiness scoring.
- Stage planning and dependency status.
- Exact-cell proposal generation.
- Safety-envelope validation during apply.
- Durable plan, proposal, audit, and handoff storage.

The Electron main process exposes the engine through `tune-engine:*` IPC handlers. The renderer presents it in the Full AI/Tune Studio page. Applied work continues through `TuneWorkspaceManager`, snapshots, calibration export, checksum validation, and Flash Center instead of bypassing those controls.

## Storage

Each project receives:

```text
<Project>/AI/TuneEngine/plan.json
<Project>/AI/TuneEngine/audit.json
<Project>/AI/TuneEngine/Proposals/*.json
<Project>/Handoff/<timestamp-profile>/handoff.json
<Project>/Handoff/<timestamp-profile>/CHANGE_SUMMARY.md
```

No plan is accepted when its project ID or BIN/XDF binding differs from the active workspace.

## Safety decisions

- Unknown or ambiguous table mappings are not silently edited.
- Automatic spark movement is reduction-only and requires repeated logged knock evidence.
- Fueling and airflow stages require suitable logs and wideband/fuel-system confirmations where applicable.
- Forced-induction projects require injector, fuel-pressure, wideband, mechanical, and controlled-test confirmations.
- Every exact-cell proposal is revalidated at apply time.
- Tune Studio exports revisions but does not directly authorize a controller write.

## Test entry points

```text
npm run check
npm test
npm run test:tune-engine
npm run test:recovery-labs
```

The dedicated Tune Engine simulations cover a clean staged workflow, restart/resume plus handoff, and intentional health/instrumentation/fingerprint/spark-safety failures.
