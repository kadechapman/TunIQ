# TunIQ 1.4 dev.1 implementation notes

1. Full AI is implemented as structured project data and a deterministic workflow engine before connecting a remote model or allowing actions.
2. The AI intake is project-specific and persists in each project's `AI` folder.
3. The plan changes based on hardware and goal. A real cam requires cam data; a ghost-cam goal does not.
4. The Tune Library copies source BINs into a separate AppData vault and fingerprints every saved file.
5. Applying a library tune creates a new project revision. It cannot overwrite `Originals`.
6. Controller and OS mismatches are blocked. Missing controller or OS identification also blocks a tune that declares those requirements.
7. The Community Hub is intentionally local-only in dev.1. This allows the UI, filters, post format, attached project context, and AI-readable data model to be tested before accounts and moderation are introduced.
8. PCM/TCM writes, automatic calibration modification, cloud posting, and remote AI execution remain locked.
