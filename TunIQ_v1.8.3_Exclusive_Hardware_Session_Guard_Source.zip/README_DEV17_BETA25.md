# Developer Notes — v1.7.0-beta.25

## Main changes

- Added PCM Hammer kernel-folder discovery and explicit `--kernel-dir` injection.
- Changed PCM Hammer process working directory from the active TunIQ project to the verified kernel/tool directory.
- Added safe parsing of PCM Hammer `--list-devices` output.
- Added bounded same-port retry and recognized outgoing-port failover for non-destructive operations.
- Added explicit `adapter-open-timeout` and `kernel-files-missing` classification.
- Added device-attempt and kernel provenance to technical details and diagnostic history.
- Added `tests/p01-test-write-runtime-recovery-simulations.js` based on the real beta.24 failure text.

## Deliberate limits

- No automatic device failover is allowed for Calibration Write, Full Write, or Recovery.
- TunIQ does not invent or download kernel binaries.
- Hardware success is not claimed until the Windows/OBDLink/P01 Test Write completes.
