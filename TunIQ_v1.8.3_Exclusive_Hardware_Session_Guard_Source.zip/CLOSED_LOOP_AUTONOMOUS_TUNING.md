# TunIQ Closed-Loop Autonomous Tuning

TunIQ beta.14 extends the Autonomous Tune Agent with a project-scoped validation and correction loop.

## Workflow

1. Complete the autonomous base tune using the exact project BIN and XDF.
2. Start a Closed-Loop session. TunIQ creates a protected rollback snapshot.
3. Record or import a fresh vehicle log.
4. TunIQ normalizes the log, fingerprints it, scores channel quality and operating-zone coverage, and checks voltage, temperature, knock, wideband error, misfires, injector duty, and other available evidence.
5. When confidence is sufficient, TunIQ automatically runs the next supported mapped correction cycle and exports a new revision.
6. Record a new validation drive. TunIQ compares the new error score to the previous drive.
7. A converged result creates a validated snapshot and report. A critical or materially worse result restores the rollback snapshot and exports a rollback revision.

## Operating-zone coverage

Confidence considers idle, cruise, acceleration, high-load/WOT, and transmission-shift coverage. Missing zones reduce confidence instead of being treated as proof that the tune is correct.

## Duplicate-log protection

Every normalized log has a content fingerprint. The same drive cannot be reused as both correction evidence and validation evidence.

## Automatic rollback

Closed-loop correction never modifies the protected original BIN. A snapshot is created before every correction cycle. Critical safety findings or a large validation regression can restore that snapshot automatically and export a new rollback revision.

## Controller-write boundary

Closed-loop tuning can create, compare, validate, and roll back calibration revisions. The final PCM write remains a separate Flash Center confirmation and is never performed silently.
