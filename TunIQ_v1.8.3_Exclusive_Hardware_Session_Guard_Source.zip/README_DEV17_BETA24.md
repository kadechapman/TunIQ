# Developer Notes — v1.7.0-beta.24

- Added `src/p01-finalizer.js`.
- Added disk-only commissioning definition confirmation.
- Commissioning-only mapping no longer depends on a Calibration workspace object.
- Resume and Refresh call the finalizer when two verified reads exist.
- Generated stock-clone names are deterministic by original SHA-256.
- Added four finalizer scenarios, including no-workspace disk binding.
