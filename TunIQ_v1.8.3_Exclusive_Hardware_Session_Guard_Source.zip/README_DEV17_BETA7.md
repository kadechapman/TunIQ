# TunIQ v1.7.0-beta.7 — P01 Hardware Recovery

This release replaces beta.6's previous automatic-setup wording and retry-oriented read logic with a recoverable, evidence-driven **Guided Automatic P01 Setup**.

## Implemented

- PCM Hammer 2.x help-driven operation discovery and real-format result parsing.
- Read Properties identity flow without requiring `identify`.
- TunIQ serial-session release and non-communicating COM lock detection.
- Assisted normal PCM Hammer fallback with automatic evidence import.
- Exactly two independent 524,288-byte reads with matching SHA-256 hashes.
- Rejection/quarantine of failed, partial, oversized, missing, and mismatched BINs.
- Exact-step durable ledger and restart/resume behavior.
- Explicit, non-looping stop reasons.
- Automated suite plus three isolated end-to-end software simulations.

No real-hardware verification is claimed.
