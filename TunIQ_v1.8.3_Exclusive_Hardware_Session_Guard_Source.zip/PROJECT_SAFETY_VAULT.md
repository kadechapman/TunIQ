# Project Safety Vault

Before PCM Hammer Test Write, Calibration Write, Full Write, or Recovery, TunIQ 1.8.3 creates a verified project snapshot.

- Copies the complete active project into `%AppData%\TunIQ\Backups\Projects\<project>`.
- Calculates SHA-256 for every source file.
- Recalculates each copied file and refuses the operation if any size or hash differs.
- Writes `snapshot-manifest.json` with source identity, file list, hashes, total size, and reason.
- Reuses an identical verified snapshot instead of creating duplicates.
- Retains the latest eight distinct snapshots per project.
- Never modifies the protected original or replaces the commissioning read pair.

A snapshot failure blocks the hardware operation before PCM Hammer is launched.
