# Workspace State Reconciliation Hotfix

## Observed beta.22 failure

The Calibration page visibly displayed the protected original and TunIQ commissioning-only XDF as bound, while Guided Automatic P01 Setup stopped with:

`Load the protected original and XDF in Calibration before confirming the definition.`

The renderer Refresh button only re-fetched cached summary data and did not rebuild backend workspace state.

## Beta.23 repair

Beta.23 verifies four independent facts before accepting the commissioning binding:

1. The active project contains an existing 524,288-byte protected original.
2. The saved P01 read pair contains two independent, matching, valid P01 reads.
3. The active XDF is the exact-OS TunIQ commissioning-only definition with zero writable tables.
4. The Calibration workspace or its current binding fingerprints match the protected BIN and XDF bytes on disk.

When those conditions are true, stale canonical hashes and stale legacy source fields are repaired. The definition is confirmed automatically and the Guided Setup ledger advances to `create-revision`.

## Refresh behavior

The header Refresh button now calls a backend reconciliation IPC action. It reloads the project files, rebuilds the XDF workspace, repairs the P01 confirmation, and changes the old failed state into a resumable stock-clone step.

## Safety

This repair is only permissive for a commissioning-only definition with zero writable tables. Writable XDFs continue to require strict project, BIN SHA-256, and XDF SHA-256 matches.
