# TunIQ v1.8.3 — Exclusive Hardware Session Guard & Project Safety Vault

## Major fix

TunIQ now prevents the most common hidden serial-ownership failure before PCM Hammer starts. It identifies competing OBD/serial applications, reports their process details, and stops without touching project evidence.

## Safety Vault

Every Test Write or write-related operation now requires a complete hash-verified project snapshot. Identical snapshots are reused and older distinct snapshots are retained on a bounded rotation.

## Vehicle-network diagnosis

PCM Hammer output that explicitly identifies 1x traffic interrupting a 4x session is classified as `bus-speed-interference`. TunIQ provides a conservative assisted fallback recommendation and never invents an unsupported CLI speed option.

## Preserved behavior

- Existing Customline project and verified P01 reads remain unchanged.
- Read-only OS 9379910 commissioning locks remain active.
- No actual PCM write is performed by Guided P01 Test Write.
- The 1.8 dashboard, logo, loading animation, and eight-workspace navigation remain intact.

## Hardware boundary

Software and simulated recovery are verified. Real OBDLink MX+/Windows Bluetooth/P01 Test Write success still requires confirmation on the user's hardware.
