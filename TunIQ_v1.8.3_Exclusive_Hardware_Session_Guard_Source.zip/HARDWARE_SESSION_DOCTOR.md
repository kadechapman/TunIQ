# Hardware Session Doctor

TunIQ v1.8.2 adds a project-scoped diagnostic layer around PCM Hammer operations.

## What it records

- The active project, controller, and OS identity.
- Whether the two matching 524,288-byte reads remain verified.
- The exact commissioning revision used for Test Write.
- PCM Hammer executable, command line, kernel directory, and loader/kernel files.
- Every COM-port attempt, including bounded retries and alternate-port selection.
- Separate stdout and stderr log paths for each attempt.
- Exit code, failure category, and whether PCM communication actually began.
- The last successful device remembered by TunIQ.

## What it never does

- It does not alter the protected original.
- It does not replace a verified read pair.
- It does not perform an actual PCM write.
- It does not treat an incomplete or ambiguous PCM Hammer result as success.

## Failure UX

A stopped Test Write now displays `STOPPED` rather than a misleading near-complete percentage. The Doctor explains whether the stop happened during Windows COM-port opening, after PCM communication began, because kernels were missing, because power evidence was insufficient, or because the CLI result was not proven.

The user can refresh the diagnosis, export a JSON or text hardware report, open the latest PCM Hammer log, or open the project Reports folder without resetting the project.
