# TunIQ v1.7.0-beta.24 Test Report

## Release

- Version: `1.7.0-beta.24`
- Name: **P01 Setup Finalizer**
- Purpose: permanently remove the repeated 48% commissioning/workspace dead end and advance a verified P01 project directly to integrated PCM Hammer Test Write.

## Exact failure removed

Earlier builds allowed the Calibration page and Guided Setup to disagree about whether the commissioning BIN/XDF were bound. Beta.24 no longer asks the Calibration workspace or renderer cache to prove commissioning-only setup.

The finalizer reconstructs the software state directly from:

- PCM Hammer Read Properties identity
- Two distinct 524,288-byte reads
- Matching read SHA-256 values
- The protected original bytes
- The generated exact-OS commissioning XDF on disk

It then creates one deterministic unchanged stock clone, records a validation report and finalizer audit, and moves directly to Test Write.

## Automated verification

- Syntax/static checks: **PASS**
- Automated suite: **PASS — 30/30 groups**
- Focused simulations: **PASS — 56/56**
- P01 finalizer scenarios: **PASS — 4/4**
- Full 48%-to-Test-Write completion harness: **PASS — 3/3**
- Retained recovery and tuning simulations: **PASS**

## Final completion harness

1. **Complete from 48 percent** — no Calibration workspace was supplied; disk binding, stock clone, and PCM Hammer Test Write completed.
2. **Test Write disconnect/retry** — the first Test Write stopped as `adapter-disconnected`; the same verified revision retried and passed.
3. **Restart/reuse** — restarting reused the deterministic verified stock clone instead of generating duplicate revisions.

## Safety checks

- Missing read: hard stop
- Duplicate read path: hard stop
- Partial read: hard stop
- Changed read after verification: hard stop
- Mismatched hashes: hard stop
- Wrong-size protected original: repaired only from the verified pair
- Commissioning XDF with writable tables: hard stop
- Stock clone containing changed bytes: hard stop
- AI/manual tuning with commissioning-only definition: remains locked
- Calibration/Full Write with commissioning-only definition: remains locked

## Hardware boundary

The software path is simulation verified. A physical Windows/COM3/OBDLink MX+/P01 Test Write cannot be performed in the Linux build environment. Therefore the only legitimate remaining stop after beta.24 is a real PCM Hammer, COM-port, ignition, voltage, adapter, or PCM communication result—not the old 48% workspace state.
