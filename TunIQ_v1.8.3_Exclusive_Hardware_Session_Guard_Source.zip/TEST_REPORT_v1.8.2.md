# TunIQ v1.8.2 Test Report

## Release

- Version: `1.8.2`
- Name: **Hardware Session Doctor & Failure UX**
- Base: TunIQ v1.8.1 PCM Hammer COM Failover Hotfix
- Test date: July 22, 2026
- Verification environment: Linux source/test environment with mocked PCM Hammer and Windows-device fixtures

## Purpose

TunIQ v1.8.2 makes the final P01 commissioning failure path understandable and safely resumable. A stopped PCM Hammer Test Write no longer appears nearly complete. TunIQ records each COM-port attempt, identifies whether failure occurred before or after PCM communication, remembers a proven port, and exports a project-scoped report without changing verified commissioning evidence.

## Implemented behavior

- Added an embedded **Hardware Session Doctor** to Guided P01 Setup.
- Failed or paused hardware operations display **STOPPED** instead of a misleading 95% state.
- Shows an ordered COM-attempt timeline with port, result, exit code, retry/fallback role, and communication boundary.
- Persists the last successful PCM Hammer device and prioritizes it in future bounded candidate selection.
- Creates deterministic `hardware-session-latest.json` and `hardware-session-latest.txt` reports in the active project's Reports folder.
- Supports refreshing the diagnosis, exporting JSON or text, opening the latest exact PCM Hammer log, and opening the project Reports folder.
- Explains whether the stop was caused by COM opening, adapter locking/disconnection, missing kernels/loaders, insufficient power evidence, an unresolved CLI profile, or an unproven Test Write result.
- Makes **Retry Failed Test Write** the primary action when immutable commissioning evidence is already complete.

## Safety retained

- The protected original is never altered by the Hardware Session Doctor.
- The two verified 524,288-byte matching reads remain immutable evidence.
- Failed, partial, or extra reads cannot replace the verified pair.
- The deterministic unchanged commissioning stock clone is reused.
- The read-only OS 9379910 commissioning definition does not grant tuning or write authority.
- No automatic real PCM write is performed.
- A Test Write is not marked complete unless PCM Hammer success is explicitly proven.

## Automated verification

- Source syntax/static checks: **PASS**
- Full automated suite: **PASS — 35/35 groups**
- New Hardware Session Doctor simulations: **PASS — 5/5 scenarios**
- Complete retained recovery-lab chain: **PASS**

### New Hardware Session Doctor scenarios

1. COM3, bounded COM3 retry, then COM4 failure diagnosis with COM4 retained as the recommended route.
2. Missing kernel/loader files produce installation guidance before an unsafe launch.
3. The report distinguishes a pre-communication Windows COM failure from a failure after PCM traffic begins.
4. A successful Test Write records the proven device and completion evidence.
5. Project reports are deterministic, exportable, and do not mutate commissioning files.

## Retained P01 and application coverage

The retained chain passed continuity recovery, accidental restart protection, COM3-to-COM4 failover, late COM4 discovery, generic Bluetooth sibling detection, kernel discovery, corrupt-ledger rebuilding, deterministic clone reuse, Test Write disconnect/retry, startup recovery, integrated PCM Hammer command discovery, real CLI syntax, workspace reconciliation, commissioning-definition binding, partial-read quarantine, mismatched-read rejection, repeated block-read stops, Garage/project lifecycle, Tune Workspace, Tune Engine, autonomous/closed-loop tuning simulations, Connection Doctor, and Offline P01 Lab.

## Archive boundary

This report covers the working source. The final release archive must also pass ZIP integrity, clean extraction, source-manifest verification, source checks, the 35-group suite, the 5 Hardware Session Doctor scenarios, and the retained recovery chain before publication.

## Hardware boundary

This release is software and simulation verified only. It does **not** claim that the user's physical Customline, P01 PCM, OBDLink MX+, Windows Bluetooth COM3/COM4 stack, or real PCM Hammer Test Write has passed. The app continues to require explicit real PCM Hammer proof before displaying P01 hardware setup complete.
