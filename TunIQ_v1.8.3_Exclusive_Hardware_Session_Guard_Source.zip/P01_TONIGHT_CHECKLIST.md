# P01 Hardware Recovery Checklist

Do not skip a red step.

## Before connecting

- Use an official PCM Hammer 2.x Windows build.
- Use stable power appropriate for bench/vehicle programming.
- Close every other OBD/serial program.
- Prevent the PC from sleeping.
- Keep the exact-OS XDF unavailable to automation until OSID is known.

## Guided Automatic P01 Setup

1. Create the project and select **P01**.
2. Select the interface and COM port.
3. Probe PCM Hammer. TunIQ uses Read Properties; it does not require `identify`.
4. Start **Guided Automatic P01 Setup**.
5. When CLI automation is unsupported, follow the assisted normal PCM Hammer instructions and save results in the assisted-import folder.
6. Complete Read Properties and verify OSID, Hardware ID, service number, controller, and voltage evidence.
7. Complete two independent full reads.
8. Confirm each read is exactly 524,288 bytes and both SHA-256 hashes match.
9. Stop on a mismatch. Correct the cause and start a fresh two-read pair; do not use a third-read majority.
10. Bind and review the exact-OS XDF.
11. Review mapped cells and create the protected revision.
12. Validate layout/checksum evidence.
13. Run or import Test Write for the exact revision.
14. Keep Calibration Write locked until every proof is green.
15. Preserve the two original reads and all logs in more than one location.

## Stop immediately when

- the COM port is locked;
- the adapter disconnects;
- the controller evidence is incomplete;
- either read is not exactly 524,288 bytes;
- the two hashes differ;
- block reads repeatedly fail;
- the XDF is not an exact OS match;
- checksum/layout validation is not valid;
- Test Write is failed or unproven;
- power is unstable.

This checklist is for software-assisted commissioning. It is not a claim of real-hardware verification.
