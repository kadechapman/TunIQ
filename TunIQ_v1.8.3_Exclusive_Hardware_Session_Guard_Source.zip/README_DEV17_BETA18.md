# Developer Notes — v1.7.0-beta.18

## Release purpose

Beta.18 is a focused startup recovery release. Development of the planned 1.8 dashboard redesign is intentionally paused until the beta.17 startup regression is corrected and verified.

## Root cause

`src/renderer/app.js::renderP01Auto()` used `s.stop?.code` even though the function parameter and current automation state are named `auto`. JavaScript syntax validation cannot detect this class of runtime reference error, so beta.17 passed `node --check` while failing during the first workspace refresh.

## Fixes

- Replaced the invalid reference with `auto.stop?.code`.
- Added `renderSafely(section, renderer, ...args)` to isolate renderer failures.
- Wrapped the initial workspace render chain.
- Wrapped Guided P01 progress renders.
- Wrapped the post-bootstrap render chain.
- Added an executable startup regression suite using the shipped renderer source.
- Added static assertions that reject the beta.17 expression.

## Testing commands

```bash
npm run check
npm test
npm run test:startup-recovery
npm run test:recovery-labs
```

Real Windows/Electron startup remains a user-hardware validation step. The source tests prove the exact failing renderer path no longer throws.
