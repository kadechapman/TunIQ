# Developer Notes — v1.7.0-beta.17

- Added `src/pcmhammer-integrated.js` for runtime PCM Hammer 2.x command-profile discovery.
- `FlashManager` now maintains an explicit COM ownership lease and avoids lock-probe double opens.
- Guided P01 operations use the internal runner for Read Properties, full reads, Test Write, and controlled write.
- Successful non-destructive discovery caches one profile for later destructive operations.
- Profile retry is prohibited after any communication activity or output creation.
- Old `assisted-*` P01 states migrate to `stopped-integrated-migration` and resume internally.
- Backward-compatible assisted IPC names remain so older renderer states do not crash, but they now trigger an integrated retry.
- Advanced normal-PCM-Hammer import APIs remain for emergency manual use only.
- Added integrated pipeline automated and end-to-end simulations.
