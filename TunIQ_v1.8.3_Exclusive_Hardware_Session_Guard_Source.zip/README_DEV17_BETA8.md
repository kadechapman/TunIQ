# TunIQ v1.7.0-beta.8 — Connection Doctor & Offline Lab

This release builds on beta.7 P01 Hardware Recovery and addresses the next practical bottleneck: proving the Windows-to-OBDLink route before starting PCM Hammer.

## Added

- Staged Connection Doctor with durable JSON reports.
- OBDLink/STN-aware COM-port ranking and alternate-port recovery.
- Exclusive port-lock test before adapter communication.
- Automatic 115200 / 38400 / 9600 baud fallback.
- Adapter identity, firmware, voltage, protocol, and VIN evidence.
- One-click connection using the proven port and baud.
- Offline P01 Recovery Lab with three production-parser scenarios.
- Expanded automated and standalone simulation coverage.

## Preserved

- Help-driven PCM Hammer 2.x commands.
- Assisted normal PCM Hammer fallback.
- Exactly two complete matching 524,288-byte reads.
- Durable exact-step Guided Automatic P01 Setup recovery.

No real-hardware verification is claimed.
