# Startup Recovery Hotfix — v1.7.0-beta.18

## User-reported failure fixed

Beta.17 could stop during application initialization with:

```text
ReferenceError: s is not defined
at renderP01Auto
at refreshWorkspace
at init
```

The Guided P01 renderer referenced an undefined temporary variable while deciding whether the integrated PCM Hammer retry control should be shown. The renderer now reads the recovery code from the current automation state (`auto.stop.code`).

## Renderer isolation

Workspace refreshes now run major UI sections through a renderer isolation boundary. A failure in one card or workspace section is logged and that section is skipped, while the remainder of TunIQ remains usable. Once the app is visible, a warning notification identifies the section that failed.

This isolation covers the initial workspace refresh, Guided P01 progress updates, and the post-bootstrap rendering pass.

## Regression coverage

The beta.18 startup-recovery simulations execute the actual `renderP01Auto` function extracted from the shipped renderer source against:

- The exact paused `unsupported-cli` state that crashed beta.17.
- A running full-read state.
- A COM-timeout recovery state with alternate-port attempts.
- A ready-to-write state.
- A deliberately failing independent renderer to prove that the isolation boundary preserves later renders.

The test fails if the undefined `s.stop` reference returns.

## Data safety

This hotfix does not change protected BINs, project folders, PCM identity, read-pair evidence, Test Write proof, COM ownership, or flash authorization rules.
