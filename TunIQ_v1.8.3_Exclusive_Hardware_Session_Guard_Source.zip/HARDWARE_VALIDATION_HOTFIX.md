# TunIQ beta.15 Hardware Validation Hotfix

## Fixes

- Makes `workspace:get-summary` IPC-safe. Error objects, BigInts, buffers, native handles, maps, sets, dates, circular references, and unsupported values are converted to plain structured-clone-safe data.
- Returns a minimal fallback workspace summary instead of stopping the page if summary generation fails.
- Logs the exact sanitized field paths in the desktop startup/crash logs.
- Treats an unverified PCM Hammer CLI as an assisted-mode result instead of a resume loop.
- Detects portable PCM Hammer layouts where `Cli\pcmhammer-cli.exe` sits below the normal `PcmHammer.exe`.
- Adds a separately persisted normal PCM Hammer GUI executable path for assisted operations.
- Preserves the existing two-read, exact-size, matching-hash, exact-XDF, Test Write, and explicit final-write gates.

## Real diagnostic fixture

The hotfix was developed against the structure reported by the supplied beta.14 `diagnostic.tuniqreport`: a valid Customline P01 project, 524,288-byte protected original, imported reads, OS 9379910, and an unsupported portable CLI probe. Private user paths and the raw report are not included in the release package.
