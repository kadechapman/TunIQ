# Real PCM Hammer CLI Command Recovery — v1.7.0-beta.19

Beta.19 is based on a diagnostic report captured from the user's real PCM Hammer 2.0 portable installation.

## Observed CLI contract

The installed executable advertises these commands:

```text
--get-properties --device COM3
--read <file> --device COM3
--test-write <file> --device COM3
--write <file> --device COM3
```

Earlier TunIQ builds attempted `read-properties --port COM3`. The CLI rejected that syntax with `No operation specified` and printed its usage banner. Beta.18 incorrectly treated words inside that static usage text as proof that communication had begun, so safe command-profile recovery stopped prematurely.

## Corrections

- Parses operation flags at the beginning of help lines instead of matching words in descriptions.
- Supports `--get-properties`, `--read`, `--test-write`, `--write`, and `--device` exactly as advertised.
- Classifies a usage/help banner as a syntax rejection rather than PCM communication.
- Retries another non-destructive profile only when no PCM communication or output file began.
- Migrates saved beta.18 command templates to schema version 2 from the stored CLI help text.
- Records executable, arguments, command line, port, exit code, stdout, stderr, and classification in project history.
- Adds **Copy Technical Details** to the stopped Guided P01 state.

## Saved P01 evidence recovery

Beta.19 validates saved read files again before reconstructing a missing read pair. It requires two distinct files, sessions, and proof sources, both exactly 524,288 bytes, with identical SHA-256 and matching P01 identity fingerprints. Guided Setup then reconciles completed Read Properties and read steps and advances to the first genuinely incomplete step.

## Destructive-mode boundary

The observed CLI exposes `--write`, described as an entire-PCM write. It does not advertise a separate calibration-only write command. TunIQ does **not** silently substitute Full Write for Calibration Write. Test Write is integrated; any real Full Write remains blocked unless a future workflow adds an explicit, separately validated Full Write authorization path.
