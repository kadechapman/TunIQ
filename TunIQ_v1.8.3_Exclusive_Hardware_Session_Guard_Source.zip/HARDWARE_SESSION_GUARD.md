# Exclusive Hardware Session Guard

TunIQ 1.8.3 adds a non-invasive process guard before PCM Hammer operations.

- Scans Windows process metadata without opening the COM port.
- Blocks high-confidence competing OBD, PCM Hammer, logger, and serial-terminal processes.
- Reports the exact process name, PID, executable, and reason.
- Tracks only PCM Hammer processes started by TunIQ.
- At startup, terminates an orphan only when its PID and executable match TunIQ's ownership registry.
- Never automatically terminates arbitrary external scan or tuning applications.
- Preserves all verified commissioning evidence when a conflict is found.

The guard exists because a serial Bluetooth adapter can be exclusively owned by one application even when Windows still displays the device as paired.
