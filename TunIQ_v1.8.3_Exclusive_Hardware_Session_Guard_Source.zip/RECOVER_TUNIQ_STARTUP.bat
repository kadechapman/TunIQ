@echo off
setlocal
set ROOT=%APPDATA%\TunIQ
set WORKSPACE=%ROOT%\Calibration\workspace.json
set STAMP=%RANDOM%-%RANDOM%
if exist "%WORKSPACE%" (
  move "%WORKSPACE%" "%ROOT%\Calibration\workspace.manual-recovery-%STAMP%.json" >nul
  echo Calibration workspace moved to a recovery backup.
)
if exist "%ROOT%\Runtime" rmdir /s /q "%ROOT%\Runtime"
if exist "%APPDATA%\tuniq-desktop" rmdir /s /q "%APPDATA%\tuniq-desktop"
echo Startup recovery completed. Projects, vehicles, original BINs, and XDF files remain untouched.
pause
endlocal
