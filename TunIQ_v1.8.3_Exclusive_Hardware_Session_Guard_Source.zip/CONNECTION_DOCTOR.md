# Connection Doctor — retained in TunIQ v1.7.0-beta.10

Connection Doctor tests the route from Windows to the selected serial port, the adapter, and vehicle power without reading or writing the PCM.

## Stages

1. Enumerate physical Windows COM devices.
2. Rank likely OBDLink/STN ports while demoting incoming or stale Bluetooth ports.
3. Release any TunIQ-owned serial session.
4. Open and close the candidate port without sending vehicle commands to detect an external lock.
5. Attempt the adapter handshake at 115200, 38400, and 9600 baud.
6. Parse adapter identity, firmware, voltage, protocol, and VIN when available.
7. Save a permanent JSON report and proven port/baud recommendation.

A failed wrong port does not block a later successful alternate port. Low or missing voltage blocks PCM work, but does not erase proof that the PC-to-adapter link works.

## Common stop codes

- `no-serial-port`
- `adapter-locked`
- `stale-com-port`
- `adapter-timeout`
- `adapter-no-response`
- `unsafe-voltage`
- `voltage-unavailable`

Connection Doctor does not claim that a controller read or write will succeed. It only proves the connection stages it actually observed.
