# Unified Tune Engine & AI Tune Planner

## Purpose

The Unified Tune Engine turns a TunIQ project into a controlled tuning workflow rather than a collection of unrelated suggestions. It uses known vehicle data, the protected original BIN, the active XDF, captured logs, user targets, and explicit confirmations to determine what TunIQ can safely propose.

## Workflow

1. Select a Garage vehicle and project.
2. Protect and fingerprint the original BIN.
3. Load the exact XDF for the controller and OS.
4. Complete build information and required confirmations.
5. Select a representative log when a stage needs evidence.
6. Build the tune plan.
7. Review readiness, blockers, table coverage, and the next stage.
8. Generate a stage proposal.
9. Approve individual exact-cell changes.
10. Apply the approved cells to the project workspace.
11. Review the before/after snapshot and checksum-corrected revision.
12. Create a handoff bundle or move to Flash Center for a separately confirmed write.

## Table roles

The first release recognizes roles for idle speed/airflow, MAF, VE, power enrichment, stoichiometric ratio, injector flow/offset, cranking fuel, high/low-octane spark, rev/speed limits, cooling fans, shift RPM/pressure, torque management, gear ratio, and tire revolutions.

Recognition is evidence-based from XDF names/descriptions/categories and writable table metadata. A role can be marked ambiguous or unavailable. TunIQ does not invent addresses or equations.

## Safety envelopes

Examples of apply-time bounds include:

- Desired idle: at most 150 RPM from the current cell.
- Cooling fan thresholds: at most 20 °F/°C-equivalent table units per proposal.
- RPM limits: at most 500 RPM per proposal.
- MAF/VE: bounded percentage correction derived from logged error.
- Idle airflow: bounded percentage and absolute movement.
- Power enrichment: small bounded changes only.
- Spark: automatic reductions only, capped per proposal; increases are rejected.
- WOT shift RPM: bounded movement with driveline and valvetrain confirmation.

The XDF’s own min/max limits remain authoritative as an additional layer.

## Readiness and blockers

Readiness considers original-file protection, project binding, controller/OS context, table coverage, build information, confirmations, voltage, temperature, misfire data, wideband coverage, and log sample quality. A high readiness score does not authorize flashing; it only indicates that supported planning stages have adequate inputs.

## Handoff bundle

The handoff bundle includes project/controller identity, workspace fingerprints, full staged plan, applied-stage history, modified-cell count, warnings, a Markdown summary, and an optional copy of the latest exported revision. It is intended for review with TunerPro, Universal Patcher, PCM Hammer, or another supported bridge tool.

## Explicit limitations

Beta.12 is not a universal self-tuning system. It only proposes changes for exact supported XDF mappings, and some jobs—injector characterization, unknown operating systems, calibration-segment surgery, aggressive power tuning, and validation of real mechanical limits—still require qualified human review and external tools. No physical hardware verification is claimed for this release.
