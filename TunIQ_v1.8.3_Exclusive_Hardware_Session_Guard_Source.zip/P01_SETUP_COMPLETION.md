# P01 Setup Completion

## Purpose

A missing writable XDF must not prevent TunIQ from proving the hardware and communication path. It also must not cause TunIQ to guess calibration addresses.

Beta.21 adds a narrow commissioning-only fallback that is generated only after controller identity and two matching P01 reads are verified.

## Commissioning-only definition

The generated XDF:

- Declares the exact identified OS and controller.
- Contains a TunIQ commissioning marker.
- Exposes zero writable calibration tables.
- Records the verified original SHA-256 and BIN size in a provenance file.
- States explicitly that no calibration addresses were guessed.

## Stock-clone validation

TunIQ copies the protected verified original into Revisions and proves:

- Both files are 524,288 bytes.
- Both SHA-256 hashes match.
- The comparison reports zero changed bytes.
- The layout is compatible.

Only then is the revision recorded as `valid-stock-clone` and allowed into PCM Hammer Test Write.

## Safety boundary

A successful Test Write completes hardware commissioning. Commissioning-only mode continues to block AI tuning, manual editing, Calibration Write, Full Write, and OS conversion.

Installing a trustworthy writable exact-OS definition invalidates the read-only workspace binding and starts a normal writable mapping workflow.
