# TunIQ v1.8.2 — Hardware Session Doctor & Failure UX

## Added

- Hardware Session Doctor embedded in Guided P01 Setup.
- Exact COM-port attempt timeline with result, exit code, and communication boundary.
- Project-scoped `hardware-session-latest.json` and `hardware-session-latest.txt` reports.
- One-click JSON/text hardware report export.
- Open Latest Log and Open Project Reports actions.
- Last successful PCM Hammer port memory and priority fallback.
- Clear evidence-preservation and “no actual PCM write occurred” status.

## Changed

- Failed or paused hardware operations display `STOPPED` instead of appearing 95% complete.
- The primary guided action becomes `Retry Failed Test Write` when verified commissioning evidence already exists.
- The Hardware Session Doctor distinguishes pre-communication COM failures from failures after PCM traffic began.

## Preserved

- v1.8 dashboard, tachometer-Q branding, loading screen, and eight-workspace navigation.
- v1.8.1 COM3 retry, Windows rescan, generic Bluetooth sibling detection, and COM4 failover.
- Immutable verified read-pair evidence and deterministic commissioning stock-clone reuse.
- Read-only OS 9379910 commissioning safety locks.
- No automatic real PCM write.
