const crypto = require('crypto');

function bufferMeta(value) {
  return { type: 'Buffer', size: value.length, sha256: crypto.createHash('sha256').update(value).digest('hex') };
}

function toIpcSafe(value, options = {}) {
  const warnings = [];
  const seen = new WeakMap();
  const maxDepth = Number.isFinite(options.maxDepth) ? options.maxDepth : 24;
  const maxArray = Number.isFinite(options.maxArray) ? options.maxArray : 2000;
  function walk(input, path = '$', depth = 0) {
    if (input == null || typeof input === 'string' || typeof input === 'boolean') return input;
    if (typeof input === 'number') return Number.isFinite(input) ? input : String(input);
    if (typeof input === 'bigint') { warnings.push(`${path}: bigint converted to string`); return input.toString(); }
    if (typeof input === 'function' || typeof input === 'symbol') { warnings.push(`${path}: unsupported value removed`); return undefined; }
    if (depth > maxDepth) { warnings.push(`${path}: maximum depth reached`); return '[MaxDepth]'; }
    if (Buffer.isBuffer(input) || input instanceof Uint8Array) { warnings.push(`${path}: binary data summarized`); return bufferMeta(Buffer.from(input)); }
    if (input instanceof Date) return input.toISOString();
    if (input instanceof Error) return { name: input.name || 'Error', message: String(input.message || input), code: input.code == null ? null : String(input.code), stack: input.stack ? String(input.stack) : null, details: walk(input.details, `${path}.details`, depth + 1) };
    if (input instanceof Map) return Object.fromEntries([...input.entries()].slice(0, maxArray).map(([k, v], i) => [String(k), walk(v, `${path}.map[${i}]`, depth + 1)]));
    if (input instanceof Set) return [...input.values()].slice(0, maxArray).map((v, i) => walk(v, `${path}.set[${i}]`, depth + 1));
    if (typeof input === 'object') {
      if (seen.has(input)) { warnings.push(`${path}: circular reference removed`); return `[Circular:${seen.get(input)}]`; }
      seen.set(input, path);
      if (Array.isArray(input)) return input.slice(0, maxArray).map((v, i) => walk(v, `${path}[${i}]`, depth + 1));
      const output = {};
      for (const key of Object.keys(input)) {
        if (['child','socket','stdin','stdout','stderr','webContents'].includes(key)) { if (input[key] != null) warnings.push(`${path}.${key}: native handle removed`); continue; }
        try { const next = walk(input[key], `${path}.${key}`, depth + 1); if (next !== undefined) output[key] = next; }
        catch (error) { warnings.push(`${path}.${key}: ${error.message}`); }
      }
      return output;
    }
    return String(input);
  }
  return { value: walk(value), warnings };
}

function safeIpcResult(value, meta = {}) {
  const result = toIpcSafe(value);
  const output = result.value && typeof result.value === 'object' ? result.value : { value: result.value };
  if (result.warnings.length) output.ipcWarnings = result.warnings.slice(0, 100);
  if (meta.fallback) output.ipcFallback = true;
  return output;
}
module.exports = { toIpcSafe, safeIpcResult };
