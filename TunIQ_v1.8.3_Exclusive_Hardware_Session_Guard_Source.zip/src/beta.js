const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const BETA_AGREEMENT_VERSION = '1.0';
const SUPPORT_MATRIX_VERSION = '2026.07-beta1';

const SUPPORT_MATRIX = [
  {
    id: 'virtual-obd',
    label: 'Virtual OBD Adapter',
    kind: 'logging',
    status: 'verified',
    match: value => String(value?.adapter || value?.port || '').toLowerCase().includes('virtual'),
    note: 'Verified for software testing only. It does not connect to a real vehicle.'
  },
  {
    id: 'obdlink-standard',
    label: 'OBDLink / STN standard OBD-II logging',
    kind: 'logging',
    status: 'experimental',
    match: value => /obdlink|stn/i.test(String(value?.adapter || value?.name || value?.port || '')),
    note: 'Standard OBD-II logging foundation is implemented. Real adapter and vehicle validation is still required.'
  },
  {
    id: 'p01-p59-pcmhammer',
    label: 'GM P01 / P59 through PCM Hammer',
    kind: 'flashing',
    status: 'experimental',
    controllers: ['P01', 'P59'],
    note: 'Managed read/write workflow exists, but each controller, OS, interface, and recovery path must be bench-verified.'
  }
];

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function sha256Buffer(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function sha256File(file) { return sha256Buffer(fs.readFileSync(file)); }
function randomId() { return crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${crypto.randomBytes(10).toString('hex')}`; }

function redactText(input, salt = '') {
  let value = String(input ?? '');
  value = value.replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email redacted]');
  value = value.replace(/\b(?![IOQ])[A-HJ-NPR-Z0-9]{17}\b/gi, match => `[VIN:${sha256Buffer(`${salt}:${match.toUpperCase()}`).slice(0, 12)}]`);
  value = value.replace(/(?:[A-Z]:\\Users\\|\/Users\/|\/home\/)[^\\/\s]+/gi, match => match.replace(/[^\\/]+$/, '[user]'));
  return value;
}

function sanitizeValue(value, salt = '', key = '') {
  const lowered = String(key || '').toLowerCase();
  if (['email', 'vin', 'licenseplate', 'plate', 'apikey', 'token', 'password', 'secret'].includes(lowered)) {
    if (!value) return null;
    return lowered === 'vin' ? `[VIN:${sha256Buffer(`${salt}:${String(value).toUpperCase()}`).slice(0, 12)}]` : '[redacted]';
  }
  if (Buffer.isBuffer(value)) return `[buffer ${value.length} bytes omitted]`;
  if (Array.isArray(value)) return value.slice(0, 5000).map(item => sanitizeValue(item, salt));
  if (value && typeof value === 'object') {
    const output = {};
    for (const [childKey, childValue] of Object.entries(value)) {
      if (['bin', 'rawbin', 'filebytes', 'content', 'password', 'token', 'secret', 'apikey'].includes(childKey.toLowerCase())) continue;
      output[childKey] = sanitizeValue(childValue, salt, childKey);
    }
    return output;
  }
  if (typeof value === 'string') return redactText(value, salt);
  return value;
}

function readTail(file, maxBytes = 128000) {
  try {
    const stat = fs.statSync(file);
    const start = Math.max(0, stat.size - maxBytes);
    const fd = fs.openSync(file, 'r');
    const buffer = Buffer.alloc(stat.size - start);
    fs.readSync(fd, buffer, 0, buffer.length, start);
    fs.closeSync(fd);
    return buffer.toString('utf8');
  } catch { return ''; }
}

function parseCsvLine(line) {
  const fields = []; let current = ''; let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') { current += '"'; i += 1; }
      else quoted = !quoted;
    } else if (char === ',' && !quoted) { fields.push(current); current = ''; }
    else current += char;
  }
  fields.push(current); return fields;
}

function sanitizeCsv(file, salt, maxRows = 5000) {
  if (!file || !fs.existsSync(file)) return null;
  const raw = fs.readFileSync(file, 'utf8').split(/\r?\n/).filter(Boolean);
  if (raw.length < 2) return null;
  const headers = parseCsvLine(raw[0]);
  const keptHeaders = headers.filter(header => !/vin|email|latitude|longitude|gps|location/i.test(header));
  const indexes = keptHeaders.map(header => headers.indexOf(header));
  const rows = raw.slice(1, maxRows + 1).map((line, rowIndex) => {
    const values = parseCsvLine(line);
    const row = {};
    for (let i = 0; i < keptHeaders.length; i += 1) {
      const header = keptHeaders[i];
      let value = values[indexes[i]] ?? '';
      if (/timestamp/i.test(header)) value = rowIndex;
      if (/marker|comment|note/i.test(header)) value = redactText(value, salt).slice(0, 240);
      row[header] = value;
    }
    return row;
  });
  return { sourceSha256: sha256File(file), headers: keptHeaders, rows, truncated: raw.length - 1 > rows.length };
}

class BetaManager {
  constructor(options) {
    this.options = options;
  }
  root() { return path.join(this.options.dataRoot(), 'Beta'); }
  preferencesFile() { return path.join(this.root(), 'preferences.json'); }
  queueFile() { return path.join(this.root(), 'improvement-queue.json'); }
  outcomesFile() { return path.join(this.root(), 'outcomes.json'); }
  reportsRoot() { return path.join(this.root(), 'Reports'); }
  defaultPreferences() {
    return {
      installationId: randomId(),
      agreementVersion: null,
      agreementAcceptedAt: null,
      improvementOptIn: false,
      shareSanitizedLogs: false,
      shareCrashReports: false,
      allowExperimentalHardware: false,
      updateChannel: 'beta',
      updateFeedUrl: '',
      improvementEndpoint: '',
      updatedAt: new Date().toISOString()
    };
  }
  preferences() {
    ensureDir(this.root());
    const current = readJson(this.preferencesFile(), null);
    if (current?.installationId) return { ...this.defaultPreferences(), ...current };
    const created = this.defaultPreferences(); writeJson(this.preferencesFile(), created); return created;
  }
  savePreferences(payload = {}) {
    const current = this.preferences();
    const allowed = ['improvementOptIn', 'shareSanitizedLogs', 'shareCrashReports', 'allowExperimentalHardware', 'updateChannel', 'updateFeedUrl', 'improvementEndpoint'];
    const next = { ...current };
    for (const key of allowed) if (Object.prototype.hasOwnProperty.call(payload, key)) next[key] = payload[key];
    next.improvementOptIn = Boolean(next.improvementOptIn);
    next.shareSanitizedLogs = Boolean(next.improvementOptIn && next.shareSanitizedLogs);
    next.shareCrashReports = Boolean(next.improvementOptIn && next.shareCrashReports);
    next.allowExperimentalHardware = Boolean(next.allowExperimentalHardware);
    next.updateChannel = ['stable', 'beta', 'developer'].includes(next.updateChannel) ? next.updateChannel : 'beta';
    next.updateFeedUrl = String(next.updateFeedUrl || '').trim();
    next.improvementEndpoint = String(next.improvementEndpoint || '').trim();
    next.updatedAt = new Date().toISOString();
    writeJson(this.preferencesFile(), next);
    return this.state();
  }
  acceptAgreement(accepted) {
    const preferences = this.preferences();
    if (!accepted) {
      preferences.agreementVersion = null;
      preferences.agreementAcceptedAt = null;
    } else {
      preferences.agreementVersion = BETA_AGREEMENT_VERSION;
      preferences.agreementAcceptedAt = new Date().toISOString();
    }
    preferences.updatedAt = new Date().toISOString();
    writeJson(this.preferencesFile(), preferences);
    return this.state();
  }
  agreementAccepted() {
    const preferences = this.preferences();
    return preferences.agreementVersion === BETA_AGREEMENT_VERSION && Boolean(preferences.agreementAcceptedAt);
  }
  supportFor({ controller = '', os = '', adapter = '', port = '' } = {}) {
    const normalizedController = String(controller || '').trim().toUpperCase();
    const loggingEntry = SUPPORT_MATRIX.find(item => item.kind === 'logging' && item.match?.({ adapter, port })) || null;
    const flashingEntry = SUPPORT_MATRIX.find(item => item.kind === 'flashing' && item.controllers?.includes(normalizedController)) || null;
    const flashing = flashingEntry ? { ...flashingEntry, controller: normalizedController, os: String(os || '') } : {
      id: 'unsupported-controller', label: normalizedController ? `${normalizedController} flashing` : 'Controller not identified', kind: 'flashing', status: 'unsupported', note: normalizedController ? 'No verified TunIQ public-beta workflow exists for this controller yet.' : 'Identify the controller before evaluating flash support.'
    };
    const logging = loggingEntry ? { ...loggingEntry } : {
      id: 'unknown-adapter', label: adapter || port || 'No adapter connected', kind: 'logging', status: adapter || port ? 'experimental' : 'unsupported', note: adapter || port ? 'This adapter has not been verified in the TunIQ compatibility matrix.' : 'Connect an adapter to evaluate logging support.'
    };
    return { matrixVersion: SUPPORT_MATRIX_VERSION, flashing, logging };
  }
  assertFlashAllowed(operation, context = {}) {
    if (!this.agreementAccepted()) throw new Error('Accept the TunIQ Public Beta Agreement before using controller operations.');
    const support = this.supportFor(context).flashing;
    if (!['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(operation)) return support;
    const preferences = this.preferences();
    const appSettings = this.options.getSettings?.() || {};
    if (support.status === 'verified') return support;
    if (support.status === 'experimental' && preferences.allowExperimentalHardware && appSettings.detailLevel === 'advanced') return support;
    if (support.status === 'experimental') throw new Error('This controller workflow is still Experimental. Beginner View blocks real writes. Advanced testers must explicitly enable Experimental hardware in Public Beta settings after preparing a bench/recovery plan.');
    throw new Error('TunIQ does not support writing this controller in the public beta.');
  }
  queue() { const value = readJson(this.queueFile(), []); return Array.isArray(value) ? value : []; }
  outcomes() { const value = readJson(this.outcomesFile(), []); return Array.isArray(value) ? value : []; }
  queueItem(type, payload) {
    const preferences = this.preferences();
    if (!preferences.improvementOptIn) throw new Error('Enable “Help improve TunIQ” before adding data to the improvement queue.');
    const item = { id: randomId(), type, createdAt: new Date().toISOString(), schemaVersion: 1, payload: sanitizeValue(payload, preferences.installationId) };
    const queue = this.queue(); queue.push(item); writeJson(this.queueFile(), queue.slice(-500));
    this.options.appendActivity?.('beta-improvement-queued', { type, id: item.id });
    return { item, state: this.state() };
  }
  saveOutcome(payload = {}) {
    const preferences = this.preferences();
    const csvPath = String(payload.csvPath || '');
    if (!csvPath || !fs.existsSync(csvPath)) throw new Error('Select a saved log before recording an outcome.');
    const active = this.options.getActiveProject?.() || null;
    const outcome = {
      id: randomId(),
      createdAt: new Date().toISOString(),
      logSha256: sha256File(csvPath),
      projectId: active?.id || null,
      controller: active?.controller || null,
      os: active?.os || null,
      engine: payload.engine || null,
      tuneGoal: payload.tuneGoal || null,
      rating: String(payload.rating || '').trim(),
      newDtcs: String(payload.newDtcs || '').trim(),
      repairsMade: String(payload.repairsMade || '').trim(),
      notes: String(payload.notes || '').trim(),
      widebandUsed: Boolean(payload.widebandUsed),
      aiProposalChanged: Boolean(payload.aiProposalChanged),
      consentToImprove: Boolean(payload.consentToImprove && preferences.improvementOptIn)
    };
    if (!outcome.rating) throw new Error('Choose how the revision or test performed.');
    const outcomes = this.outcomes(); outcomes.unshift(outcome); writeJson(this.outcomesFile(), outcomes.slice(0, 1000));
    if (outcome.consentToImprove) {
      const queuePayload = { ...outcome };
      if (preferences.shareSanitizedLogs) queuePayload.log = sanitizeCsv(csvPath, preferences.installationId);
      this.queueItem('tuning-outcome', queuePayload);
    }
    this.options.appendActivity?.('beta-outcome-recorded', { rating: outcome.rating, logSha256: outcome.logSha256, shared: outcome.consentToImprove });
    return { outcome, state: this.state() };
  }
  buildDiagnosticBundle(extra = {}) {
    const preferences = this.preferences();
    const active = this.options.getActiveProject?.() || null;
    const device = this.options.getDeviceStatus?.() || null;
    const logsRoot = path.join(this.options.dataRoot(), 'Logs');
    const bundle = {
      format: 'TunIQ Public Beta Diagnostic Report',
      schemaVersion: 1,
      createdAt: new Date().toISOString(),
      appVersion: this.options.appVersion,
      platform: process.platform,
      arch: process.arch,
      osRelease: require('os').release(),
      installation: sha256Buffer(preferences.installationId).slice(0, 16),
      agreementAccepted: this.agreementAccepted(),
      betaPreferences: sanitizeValue({ ...preferences, installationId: undefined, improvementEndpoint: preferences.improvementEndpoint ? '[configured]' : '' }, preferences.installationId),
      support: this.supportFor({ controller: active?.controller, os: active?.os, adapter: device?.connection?.adapter, port: device?.connection?.port }),
      activeProject: active ? sanitizeValue({ id: active.id, name: active.name, vehicle: active.vehicle, controller: active.controller, os: active.os, binInfo: active.binInfo, xdfInfo: active.xdfInfo, notes: active.notes }, preferences.installationId) : null,
      device: sanitizeValue(device, preferences.installationId),
      workspace: sanitizeValue(this.options.getWorkspaceSummary?.() || null, preferences.installationId),
      flash: sanitizeValue(this.options.getFlashStatus?.() || null, preferences.installationId),
      recentActivity: sanitizeValue((this.options.getActivity?.() || []).slice(0, 100), preferences.installationId),
      logs: {
        startup: redactText(readTail(path.join(logsRoot, 'startup.log')), preferences.installationId),
        crash: redactText(readTail(path.join(logsRoot, 'desktop-crash.log')), preferences.installationId)
      },
      userDescription: redactText(extra.description || '', preferences.installationId),
      reproductionSteps: redactText(extra.steps || '', preferences.installationId)
    };
    return bundle;
  }
  writeCompressed(file, payload) {
    ensureDir(path.dirname(file)); fs.writeFileSync(file, zlib.gzipSync(Buffer.from(JSON.stringify(payload, null, 2), 'utf8'))); return file;
  }
  exportDiagnostic(file, extra = {}) {
    const bundle = this.buildDiagnosticBundle(extra);
    return this.writeCompressed(file, bundle);
  }
  exportQueue(file) {
    const preferences = this.preferences();
    const payload = { format: 'TunIQ Improvement Package', schemaVersion: 1, createdAt: new Date().toISOString(), installation: sha256Buffer(preferences.installationId).slice(0, 16), items: this.queue() };
    return this.writeCompressed(file, payload);
  }
  clearQueue() { writeJson(this.queueFile(), []); return this.state(); }
  clearOutcomes() { writeJson(this.outcomesFile(), []); return this.state(); }
  async submitQueue() {
    const preferences = this.preferences();
    if (!preferences.improvementOptIn) throw new Error('Improvement sharing is disabled.');
    const endpoint = String(preferences.improvementEndpoint || '').trim();
    if (!/^https:\/\//i.test(endpoint)) throw new Error('A secure HTTPS improvement endpoint has not been configured yet. Export the package instead.');
    const items = this.queue(); if (!items.length) throw new Error('The improvement queue is empty.');
    const response = await fetch(endpoint, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ schemaVersion: 1, installation: sha256Buffer(preferences.installationId).slice(0, 16), items }) });
    if (!response.ok) throw new Error(`TunIQ server returned HTTP ${response.status}. Nothing was deleted from the local queue.`);
    writeJson(this.queueFile(), []);
    this.options.appendActivity?.('beta-improvement-submitted', { count: items.length });
    return { submitted: items.length, state: this.state() };
  }
  state() {
    const preferences = this.preferences();
    const active = this.options.getActiveProject?.() || null;
    const device = this.options.getDeviceStatus?.() || null;
    return {
      agreementVersion: BETA_AGREEMENT_VERSION,
      agreementAccepted: this.agreementAccepted(),
      preferences,
      queueCount: this.queue().length,
      outcomeCount: this.outcomes().length,
      supportMatrixVersion: SUPPORT_MATRIX_VERSION,
      support: this.supportFor({ controller: active?.controller, os: active?.os, adapter: device?.connection?.adapter, port: device?.connection?.port }),
      matrix: SUPPORT_MATRIX.map(({ match, ...item }) => item)
    };
  }
}

module.exports = { BetaManager, BETA_AGREEMENT_VERSION, SUPPORT_MATRIX_VERSION, SUPPORT_MATRIX, sanitizeValue, redactText, sanitizeCsv };
