const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function safeName(value) { return String(value || 'project').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'project'; }
function sha256File(file) { const hash = crypto.createHash('sha256'); hash.update(fs.readFileSync(file)); return hash.digest('hex'); }
function isoStamp() { return new Date().toISOString().replace(/[:.]/g, '-'); }
function shouldSkip(relative) {
  return relative.split(path.sep).some(part => /^(?:node_modules|\.git|dist|temp|tmp)$/i.test(part)) || /(?:\.rejected-\d+|\.tmp)$/i.test(relative);
}
function walk(folder, root = folder, out = []) {
  for (const entry of fs.readdirSync(folder, { withFileTypes: true })) {
    if (entry.isSymbolicLink()) continue;
    const full = path.join(folder, entry.name); const relative = path.relative(root, full);
    if (shouldSkip(relative)) continue;
    if (entry.isDirectory()) walk(full, root, out);
    else if (entry.isFile()) out.push({ full, relative });
  }
  return out;
}
function manifestFingerprint(files) {
  const hash = crypto.createHash('sha256');
  for (const item of files.slice().sort((a, b) => a.relative.localeCompare(b.relative))) hash.update(`${item.relative}\0${item.size}\0${item.sha256}\n`);
  return hash.digest('hex');
}

class ProjectSafetyVault {
  constructor(options = {}) {
    this.dataRoot = options.dataRoot || (() => process.cwd());
    this.getActiveProject = options.getActiveProject || (() => null);
    this.retention = Number(options.retention || 8);
  }
  root(project) { return ensureDir(path.join(this.dataRoot(), 'Backups', 'Projects', safeName(project.id || project.name))); }
  indexFile(project) { return path.join(this.root(project), 'vault-index.json'); }
  loadIndex(project) { const value = readJson(this.indexFile(project), { version: 1, snapshots: [] }); return { version: 1, snapshots: Array.isArray(value?.snapshots) ? value.snapshots : [] }; }
  saveIndex(project, index) { writeJson(this.indexFile(project), { version: 1, updatedAt: new Date().toISOString(), snapshots: index.snapshots || [] }); }

  create(reason = 'hardware-session', options = {}) {
    const project = options.project || this.getActiveProject();
    if (!project?.folder || !fs.existsSync(project.folder)) throw new Error('The active project folder is unavailable for a safety snapshot.');
    const sourceFiles = walk(project.folder).map(item => {
      const stat = fs.statSync(item.full);
      return { ...item, size: stat.size, sha256: sha256File(item.full) };
    });
    if (!sourceFiles.length) throw new Error('The active project contains no files to preserve.');
    const fingerprint = manifestFingerprint(sourceFiles);
    const index = this.loadIndex(project);
    const reusable = index.snapshots.find(item => item.fingerprint === fingerprint && item.verified && fs.existsSync(item.path));
    if (reusable) return { ...reusable, reused: true, reason, checkedAt: new Date().toISOString() };

    const finalFolder = path.join(this.root(project), `${isoStamp()}-${safeName(reason)}`);
    const tempFolder = `${finalFolder}.tmp-${process.pid}-${Date.now()}`;
    ensureDir(tempFolder);
    let totalBytes = 0;
    try {
      for (const item of sourceFiles) {
        const destination = path.join(tempFolder, item.relative);
        ensureDir(path.dirname(destination)); fs.copyFileSync(item.full, destination);
        const copiedSize = fs.statSync(destination).size; const copiedHash = sha256File(destination);
        if (copiedSize !== item.size || copiedHash !== item.sha256) throw new Error(`Snapshot verification failed for ${item.relative}.`);
        totalBytes += item.size;
      }
      const createdAt = new Date().toISOString();
      const manifest = {
        type: 'tuniq-project-safety-snapshot', version: 1, projectId: project.id, projectName: project.name,
        reason, sourceFolder: path.resolve(project.folder), createdAt, fingerprint, verified: true,
        fileCount: sourceFiles.length, totalBytes,
        files: sourceFiles.map(item => ({ path: item.relative.replace(/\\/g, '/'), size: item.size, sha256: item.sha256 }))
      };
      const manifestFile = path.join(tempFolder, 'snapshot-manifest.json'); writeJson(manifestFile, manifest);
      fs.renameSync(tempFolder, finalFolder);
      const record = { path: finalFolder, manifestFile: path.join(finalFolder, 'snapshot-manifest.json'), createdAt, reason, fingerprint, verified: true, fileCount: sourceFiles.length, totalBytes, reused: false };
      index.snapshots.unshift(record);
      const keep = index.snapshots.slice(0, Math.max(1, this.retention)); const remove = index.snapshots.slice(Math.max(1, this.retention));
      for (const old of remove) { try { if (old.path && path.resolve(old.path).startsWith(path.resolve(this.root(project)))) fs.rmSync(old.path, { recursive: true, force: true }); } catch {} }
      index.snapshots = keep; this.saveIndex(project, index); return record;
    } catch (error) {
      try { fs.rmSync(tempFolder, { recursive: true, force: true }); } catch {}
      throw error;
    }
  }

  latest(project = this.getActiveProject()) { return this.loadIndex(project).snapshots.find(item => item.verified && fs.existsSync(item.path)) || null; }
}

module.exports = { ProjectSafetyVault, walk, manifestFingerprint, sha256File };
