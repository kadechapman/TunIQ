const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { buildTunePlan, buildStageProposal, applyStageProposal, assertPlan } = require('./tune-engine');
const { sameBinding } = require('./tune-workspace');

const AUTONOMOUS_TUNE_SCHEMA_VERSION = 1;
const MAX_AUDIT = 1000;
const CALIBRATION_STAGE_IDS = ['drivability', 'airflow', 'fueling', 'spark', 'transmission'];
const LOG_CYCLE_STAGE_IDS = ['airflow', 'fueling', 'spark'];

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function now() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`; }
function finite(value) { const number = Number(value); return Number.isFinite(number) ? number : null; }
function clamp(value, minimum, maximum) { return Math.max(minimum, Math.min(maximum, value)); }
function safe(value, maximum = 1000) { return String(value ?? '').trim().slice(0, maximum); }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function atomicWriteJson(file, value) {
  ensureDir(path.dirname(file));
  const temporary = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temporary, file); }
  catch (error) {
    if (!['EEXIST', 'EPERM', 'EACCES'].includes(error?.code)) { try { fs.unlinkSync(temporary); } catch {} throw error; }
    try { fs.unlinkSync(file); } catch {}
    fs.renameSync(temporary, file);
  }
}

function hasText(intake, patterns) {
  const text = `${intake?.engine || ''} ${intake?.aspiration || ''} ${intake?.fuel || ''} ${intake?.tuneGoal || ''} ${(intake?.modifications || []).join(' ')} ${intake?.buildNotes || ''}`.toLowerCase();
  return patterns.some(pattern => pattern.test(text));
}

function deriveProfile(intake = {}, requested = '') {
  if (requested) return requested;
  if (hasText(intake, [/turbo/, /supercharg/, /boost/, /forced.?induction/])) return 'forced-induction';
  if (hasText(intake, [/camshaft/, /\bcam\b/, /ghost.?cam/])) return 'cam';
  if (hasText(intake, [/tow/, /hauling/, /trailer/])) return 'tow';
  if (hasText(intake, [/economy/, /mpg/, /fuel mileage/])) return 'economy';
  if (hasText(intake, [/race/, /drag/, /performance/, /power/])) return 'performance';
  return 'street';
}

function deriveIdleTarget(intake = {}, targets = {}) {
  const explicit = finite(targets.desiredIdle ?? intake.desiredIdle);
  if (explicit != null) return clamp(Math.round(explicit), 500, 1400);
  if (!hasText(intake, [/camshaft/, /\bcam\b/, /ghost.?cam/])) return null;
  const intakeDuration = finite(intake?.cam?.durationIntake);
  const exhaustDuration = finite(intake?.cam?.durationExhaust);
  const lsa = finite(intake?.cam?.lsa);
  const duration = Math.max(intakeDuration || 0, exhaustDuration || 0);
  let target = 750;
  if (duration >= 230) target += 50;
  if (duration >= 240) target += 50;
  if (lsa && lsa <= 110) target += 50;
  return clamp(target, 700, 950);
}

function deriveLambdaTarget(intake = {}, targets = {}) {
  const explicitLambda = finite(targets.targetLambda);
  if (explicitLambda != null) return clamp(explicitLambda, 0.55, 1.2);
  if (finite(targets.targetAfr) != null) return null;
  if (hasText(intake, [/turbo/, /supercharg/, /boost/, /forced.?induction/])) return 0.80;
  if (hasText(intake, [/nitrous/])) return 0.82;
  return 0.86;
}

function deriveAutonomousTargets(intake = {}, targets = {}, authorization = {}) {
  const confirmations = { ...(targets.confirmations || {}) };
  const confirmed = authorization.confirmedFacts && typeof authorization.confirmedFacts === 'object' ? authorization.confirmedFacts : {};
  for (const key of ['protectedOriginal', 'mechanicalHealth', 'injectorData', 'fuelPressure', 'wideband', 'valvetrain', 'driveline', 'controlledTest']) {
    if (confirmed[key] === true) confirmations[key] = true;
  }
  const revLimit = finite(targets.revLimit);
  const derivedShift = finite(targets.shiftRpm) ?? (revLimit != null && !/manual|no pcm|no transmission control/i.test(String(intake.transmission || '')) ? clamp(Math.round(revLimit - 300), 2500, 8000) : null);
  return {
    ...targets,
    profile: deriveProfile(intake, targets.profile),
    aggressiveness: clamp(Math.round(finite(targets.aggressiveness) || 2), 1, 5),
    desiredIdle: deriveIdleTarget(intake, targets),
    targetLambda: deriveLambdaTarget(intake, targets),
    shiftRpm: derivedShift,
    selectedLog: targets.selectedLog || null,
    confirmations
  };
}

function isMappingUnavailable(stage) {
  const blockers = stage?.blockers || [];
  return blockers.length > 0 && blockers.every(message => /no (exact|supported)|was identified|is mapped|mapped role/i.test(String(message)));
}
function isNoChangeProposal(proposal) {
  return Boolean(proposal?.blockers?.length) && proposal.blockers.every(message => /already match|within .* stage limit|could not be isolated|not contain enough repeatable knock/i.test(String(message)));
}
function isOptionalUnrequestedStage(stage) {
  const blockers = stage?.blockers || [];
  return blockers.length > 0 && blockers.every(message => /enter at least one exact target|enter an explicit wot shift rpm|no supported shift rpm|no exact drivability/i.test(String(message)));
}
function foundationBlockers(plan) {
  const ids = new Set(['recovery', 'baseline']);
  return plan.stages.filter(stage => ids.has(stage.id) && stage.status === 'blocked').flatMap(stage => (stage.blockers || []).map(message => `${stage.title}: ${message}`));
}
function highRiskStage(stageId) { return ['fueling', 'spark', 'transmission'].includes(stageId); }

class AutonomousTuneManager {
  constructor(options = {}) { this.appendActivity = options.appendActivity || (() => {}); }
  root(active) { return ensureDir(path.join(active.folder, 'AI', 'AutonomousTune')); }
  stateFile(active) { return path.join(this.root(active), 'state.json'); }
  auditFile(active) { return path.join(this.root(active), 'audit.json'); }
  archiveRoot(active) { return ensureDir(path.join(this.root(active), 'Archive')); }
  load(active) {
    const state = readJson(this.stateFile(active), null);
    return state?.projectId === active.id ? state : null;
  }
  save(active, state) { atomicWriteJson(this.stateFile(active), state); return state; }
  audit(active, type, details = {}) {
    const items = readJson(this.auditFile(active), []);
    const next = [{ id: id('auto-audit'), type, details, at: now() }, ...(Array.isArray(items) ? items : [])].slice(0, MAX_AUDIT);
    atomicWriteJson(this.auditFile(active), next);
    return next[0];
  }
  begin(active, workspace, intake, targets, authorization, mode = 'complete') {
    if (!authorization?.allowAutomaticCalibration) throw new Error('Autonomous calibration authorization is required.');
    const previous = this.load(active);
    if (previous) {
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      atomicWriteJson(path.join(this.archiveRoot(active), `${stamp}-${previous.id}.json`), previous);
    }
    if (!authorization?.finalFlashSeparate) throw new Error('Final controller writing must remain a separate confirmed operation.');
    const state = {
      schemaVersion: AUTONOMOUS_TUNE_SCHEMA_VERSION,
      id: id('autonomous-run'),
      kind: 'autonomous-tune-run',
      projectId: active.id,
      projectName: active.name,
      binding: clone(workspace.binding),
      mode,
      status: 'running',
      phase: 'planning',
      createdAt: now(),
      updatedAt: now(),
      cycle: mode === 'log-cycle' ? 1 : 0,
      intake: clone(intake),
      targets: clone(targets),
      authorization: {
        allowAutomaticCalibration: true,
        allowHighRiskMappedChanges: Boolean(authorization.allowHighRiskMappedChanges),
        finalFlashSeparate: true,
        confirmedFacts: clone(authorization.confirmedFacts || {})
      },
      completedStages: [],
      skippedStages: [],
      stageResults: [],
      blockers: [],
      warnings: [],
      finalRevision: null,
      handoff: null,
      totalAppliedCells: 0,
      resumeCount: 0
    };
    this.save(active, state);
    this.audit(active, 'run-started', { runId: state.id, mode, selectedLog: targets.selectedLog || null });
    this.appendActivity('autonomous-tune-started', { projectId: active.id, runId: state.id, mode });
    return state;
  }
  assertState(state, active, workspace) {
    if (!state || state.projectId !== active.id) throw new Error('The autonomous tune run does not belong to the active project.');
    if (!sameBinding(state.binding, workspace.binding)) throw new Error('The BIN/XDF fingerprint changed during the autonomous tune run. Start a new run.');
  }
  update(active, patch) {
    const current = this.load(active);
    if (!current) throw new Error('No autonomous tune run exists for this project.');
    const next = { ...current, ...patch, updatedAt: now() };
    return this.save(active, next);
  }
  status(active, workspace = null) {
    if (!active) return { active: false, run: null, audit: [] };
    const run = this.load(active);
    let stale = false, staleReason = null;
    if (run && workspace && !sameBinding(run.binding, workspace.binding)) { stale = true; staleReason = 'The active BIN/XDF fingerprint no longer matches this autonomous run.'; }
    const audit = readJson(this.auditFile(active), []);
    return { active: true, run, stale, staleReason, audit: Array.isArray(audit) ? audit.slice(0, 150) : [] };
  }
  reset(active) {
    const state = this.load(active);
    if (!state) return { reset: false, archive: null };
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const archive = path.join(this.archiveRoot(active), `${stamp}-${state.id}.json`);
    atomicWriteJson(archive, state);
    try { fs.unlinkSync(this.stateFile(active)); } catch {}
    this.audit(active, 'run-reset', { runId: state.id, archive });
    this.appendActivity('autonomous-tune-reset', { projectId: active.id, runId: state.id, archive });
    return { reset: true, archive };
  }
}

async function executeAutonomousTune(options = {}) {
  const {
    manager, engineManager, active, intake, workspace: initialWorkspace, targets: rawTargets = {}, authorization = {}, mode = 'complete', resume = false,
    callbacks = {}
  } = options;
  if (!manager || !engineManager) throw new Error('Autonomous Tune services are unavailable.');
  let workspace = clone(initialWorkspace);
  let state = resume ? manager.load(active) : null;
  const targets = state?.targets || deriveAutonomousTargets(intake, rawTargets, authorization);
  if (state) {
    manager.assertState(state, active, workspace);
    if (!['stopped', 'waiting-for-log', 'running'].includes(state.status)) throw new Error(`This autonomous run is ${state.status} and cannot be resumed.`);
    state = manager.update(active, { status: 'running', phase: 'resuming', resumeCount: (state.resumeCount || 0) + 1, blockers: [] });
    manager.audit(active, 'run-resumed', { runId: state.id, resumeCount: state.resumeCount });
  } else {
    state = manager.begin(active, workspace, intake, targets, authorization, mode);
  }

  const stop = (phase, blockers, extra = {}) => {
    const { plan: resultPlan = null, ...stateExtra } = extra;
    const stopped = manager.update(active, { status: phase === 'waiting-for-log' ? 'waiting-for-log' : 'stopped', phase, blockers: blockers.map(String), ...stateExtra });
    manager.audit(active, 'run-stopped', { runId: stopped.id, phase, blockers: stopped.blockers });
    manager.appendActivity('autonomous-tune-stopped', { projectId: active.id, runId: stopped.id, phase, blocker: stopped.blockers[0] || null });
    return { state: stopped, workspace, plan: resultPlan };
  };

  let plan;
  try {
    plan = engineManager.createPlan(active, intake, workspace, targets);
    assertPlan(plan, active, workspace);
  } catch (error) { return stop('planning', [error.message]); }

  const foundations = foundationBlockers(plan);
  if (foundations.length) {
    const missingLog = foundations.some(message => /record or select a baseline log|no baseline log|log is required/i.test(message));
    return stop(missingLog ? 'waiting-for-log' : 'foundation-blocked', foundations, { plan });
  }

  state = manager.update(active, { phase: 'executing', planId: plan.id, readiness: plan.readiness, coverage: plan.coverage, health: plan.health, blockers: [] });
  const stageIds = mode === 'log-cycle' ? LOG_CYCLE_STAGE_IDS : CALIBRATION_STAGE_IDS;
  const completed = new Set(state.completedStages || []);
  let lastRevision = state.finalRevision || null;

  for (const stageId of stageIds) {
    if (completed.has(stageId)) continue;
    const stage = plan.stages.find(item => item.id === stageId);
    if (!stage) continue;
    if (stage.status === 'blocked') {
      if (isMappingUnavailable(stage) || isOptionalUnrequestedStage(stage)) {
        state.skippedStages = [...(state.skippedStages || []), { stageId, title: stage.title, reason: stage.blockers.join(' '), at: now() }];
        state = manager.save(active, { ...state, updatedAt: now() });
        manager.audit(active, 'stage-skipped', { runId: state.id, stageId, reason: isMappingUnavailable(stage) ? 'mapping-unavailable' : 'optional-target-not-requested' });
        continue;
      }
      return stop(`stage-${stageId}`, stage.blockers || [`${stage.title} is blocked.`], { plan });
    }
    if (highRiskStage(stageId) && !state.authorization.allowHighRiskMappedChanges) {
      return stop(`stage-${stageId}`, [`${stage.title} requires autonomous high-risk mapped-change authorization.`], { plan });
    }

    let proposal;
    try {
      proposal = buildStageProposal({ plan, stageId, workspace, activeProject: active, csvPath: targets.selectedLog || null });
      proposal.autonomous = true;
      proposal.summary = { ...(proposal.summary || {}), approvalRequired: false, automaticCalibration: true, automaticFlash: false };
      engineManager.saveProposal(active, proposal);
    } catch (error) { return stop(`stage-${stageId}`, [error.message], { plan }); }

    if (proposal.blocked || !proposal.proposals?.length) {
      if (isNoChangeProposal(proposal)) {
        state.stageResults.push({ stageId, title: stage.title, status: 'no-change', blockers: proposal.blockers || [], at: now() });
        state.completedStages.push(stageId);
        state = manager.save(active, { ...state, updatedAt: now() });
        manager.audit(active, 'stage-no-change', { runId: state.id, stageId, reason: proposal.blockers?.[0] || null });
        continue;
      }
      return stop(`stage-${stageId}`, proposal.blockers || [`${stage.title} could not produce safe mapped changes.`], { plan });
    }

    try {
      callbacks.createSnapshot?.(workspace, { name: `Before Autonomous ${stage.title}`, note: `Automatic recovery snapshot before run ${state.id}, stage ${stageId}.` });
      const appliedResult = applyStageProposal(workspace, proposal, proposal.proposals.map(item => item.id));
      workspace = appliedResult.workspace;
      callbacks.validateWorkspace?.(workspace);
      workspace = callbacks.saveWorkspace ? callbacks.saveWorkspace(workspace) : workspace;
      const revision = callbacks.exportRevision ? callbacks.exportRevision(workspace, { suffix: `Autonomous-${stageId}` }) : null;
      callbacks.createSnapshot?.(workspace, { name: `Autonomous ${stage.title} Complete`, note: `${appliedResult.applied.length} cells automatically applied in run ${state.id}${revision?.name ? `; revision ${revision.name}` : ''}.` });
      plan = engineManager.recordApplied(active, plan, proposal, appliedResult.applied, revision);
      lastRevision = revision || lastRevision;
      const result = { stageId, title: stage.title, status: 'applied', appliedCells: appliedResult.applied.length, proposalId: proposal.id, revision: revision ? { name: revision.name, path: revision.path, sha256: revision.sha256, checksumStatus: revision.checksumStatus, compatible: revision.compatible } : null, at: now() };
      state.stageResults.push(result);
      state.completedStages.push(stageId);
      state.totalAppliedCells = (state.totalAppliedCells || 0) + appliedResult.applied.length;
      state.finalRevision = lastRevision;
      state = manager.save(active, { ...state, phase: `completed-${stageId}`, updatedAt: now() });
      manager.audit(active, 'stage-auto-applied', { runId: state.id, stageId, appliedCells: appliedResult.applied.length, revision: revision?.name || null });
      manager.appendActivity('autonomous-tune-stage-applied', { projectId: active.id, runId: state.id, stageId, appliedCells: appliedResult.applied.length, revision: revision?.name || null });
    } catch (error) { return stop(`stage-${stageId}`, [error.message], { plan }); }
  }

  if (!lastRevision && callbacks.exportRevision) {
    try { lastRevision = callbacks.exportRevision(workspace, { suffix: 'Autonomous-Complete' }); }
    catch (error) { return stop('final-export', [error.message], { plan }); }
  }
  let handoff = null;
  try { handoff = callbacks.createHandoff?.(plan, workspace, lastRevision) || null; }
  catch (error) { return stop('handoff', [error.message], { plan }); }
  const finalState = manager.update(active, {
    status: 'ready-for-flash-confirmation',
    phase: 'complete',
    blockers: [],
    planId: plan.id,
    finalRevision: lastRevision,
    handoff,
    completedAt: now(),
    message: 'The complete supported calibration has been generated automatically. Controller writing remains a separate confirmed Flash Center operation.'
  });
  manager.audit(active, 'run-completed', { runId: finalState.id, totalAppliedCells: finalState.totalAppliedCells, revision: lastRevision?.name || null, handoff: handoff?.folder || null });
  manager.appendActivity('autonomous-tune-completed', { projectId: active.id, runId: finalState.id, totalAppliedCells: finalState.totalAppliedCells, revision: lastRevision?.name || null });
  return { state: finalState, workspace, plan, revision: lastRevision, handoff };
}

module.exports = {
  AutonomousTuneManager,
  AUTONOMOUS_TUNE_SCHEMA_VERSION,
  CALIBRATION_STAGE_IDS,
  LOG_CYCLE_STAGE_IDS,
  deriveAutonomousTargets,
  executeAutonomousTune,
  foundationBlockers,
  isMappingUnavailable,
  isNoChangeProposal,
  isOptionalUnrequestedStage
};
