(function(root,factory){
  const api=factory();
  if(typeof module==='object'&&module.exports)module.exports=api;
  else root.TunIQEngineCatalog=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const catalog=[
    {family:'LS',groups:[
      {displacement:'4.8L',codes:['LR4','LY2','L20','Unknown / identify later']},
      {displacement:'5.3L',codes:['LM7','L59','LM4','L33','LH6','LC9','LY5','LMG','LMF','LH8','LH9','Unknown / identify later']},
      {displacement:'5.7L',codes:['LS1','LS6','Unknown / identify later']},
      {displacement:'6.0L',codes:['LQ4','LQ9','LS2','LY6','L76','L77','L96','Unknown / identify later']},
      {displacement:'6.2L',codes:['LS3','L92','L9H','L99','LSA','LS9','Unknown / identify later']},
      {displacement:'7.0L',codes:['LS7','Unknown / identify later']}
    ]},
    {family:'GM LT / EcoTec3',groups:[
      {displacement:'5.3L',codes:['L83','L84','Unknown / identify later']},
      {displacement:'5.5L',codes:['LT6','LT7','Unknown / identify later']},
      {displacement:'6.2L',codes:['L86','L87','LT1','LT2','LT4','LT5','Unknown / identify later']},
      {displacement:'6.6L',codes:['L8T','Unknown / identify later']}
    ]},
    {family:'GM Small-Block Chevy',groups:[
      {displacement:'5.0L / 305',codes:['305 carbureted','305 TBI / LO3','305 Tuned Port / LB9','Unknown / custom build']},
      {displacement:'5.7L / 350',codes:['350 carbureted','350 TBI / LO5','350 Tuned Port / L98','350 Vortec / L31','Unknown / custom build']},
      {displacement:'6.3L / 383',codes:['383 stroker','Unknown / custom build']},
      {displacement:'6.6L / 400',codes:['400 SBC','Unknown / custom build']}
    ]},
    {family:'GM Big-Block Chevy',groups:[
      {displacement:'6.5L / 396',codes:['396 BBC','Unknown / custom build']},
      {displacement:'6.6L / 402',codes:['402 BBC','Unknown / custom build']},
      {displacement:'7.0L / 427',codes:['427 BBC','Unknown / custom build']},
      {displacement:'7.4L / 454',codes:['454 carbureted','454 TBI / L19','454 Vortec / L29','Unknown / custom build']},
      {displacement:'8.1L / 496',codes:['L18 Vortec 8100','Unknown / custom build']}
    ]},
    {family:'GM Ecotec',groups:[
      {displacement:'2.0L',codes:['LSJ','LNF','LHU','LTG','Unknown / identify later']},
      {displacement:'2.2L',codes:['L61','LAP','L42','Unknown / identify later']},
      {displacement:'2.4L',codes:['LE5','LEA','LAF','Unknown / identify later']}
    ]},
    {family:'GM Duramax',groups:[
      {displacement:'6.6L',codes:['LB7','LLY','LBZ','LMM','LML','LGH','L5P','Unknown / identify later']}
    ]},
    {family:'Ford Windsor',groups:[
      {displacement:'5.0L / 302',codes:['302 carbureted','5.0 HO EFI','Unknown / custom build']},
      {displacement:'5.8L / 351W',codes:['351W carbureted','351W EFI','Unknown / custom build']},
      {displacement:'6.7L / 408',codes:['408 Windsor stroker','Unknown / custom build']}
    ]},
    {family:'Ford Modular / Coyote',groups:[
      {displacement:'4.6L',codes:['2-valve','3-valve','4-valve','Unknown / identify later']},
      {displacement:'5.0L',codes:['Coyote Gen 1','Coyote Gen 2','Coyote Gen 3','Coyote Gen 4','Unknown / identify later']},
      {displacement:'5.2L',codes:['Voodoo','Predator','Aluminator XS','Unknown / identify later']},
      {displacement:'5.4L',codes:['2-valve','3-valve','4-valve','Unknown / identify later']},
      {displacement:'5.8L',codes:['Trinity','Unknown / identify later']}
    ]},
    {family:'Ford Godzilla',groups:[
      {displacement:'6.8L',codes:['Godzilla 6.8','Unknown / identify later']},
      {displacement:'7.3L',codes:['Godzilla 7.3','Megazilla','Unknown / identify later']}
    ]},
    {family:'Ford EcoBoost',groups:[
      {displacement:'2.0L',codes:['EcoBoost 2.0','Unknown / identify later']},
      {displacement:'2.3L',codes:['EcoBoost 2.3','Unknown / identify later']},
      {displacement:'2.7L',codes:['Nano 2.7','Unknown / identify later']},
      {displacement:'3.0L',codes:['Nano 3.0','Unknown / identify later']},
      {displacement:'3.5L',codes:['Cyclone EcoBoost Gen 1','Cyclone EcoBoost Gen 2','High Output 3.5','Unknown / identify later']}
    ]},
    {family:'Ford Power Stroke',groups:[
      {displacement:'6.0L',codes:['6.0 Power Stroke','Unknown / identify later']},
      {displacement:'6.4L',codes:['6.4 Power Stroke','Unknown / identify later']},
      {displacement:'6.7L',codes:['Scorpion 6.7','Unknown / identify later']},
      {displacement:'7.3L',codes:['7.3 Power Stroke','Unknown / identify later']}
    ]},
    {family:'Mopar Gen III Hemi',groups:[
      {displacement:'5.7L',codes:['5.7 Hemi pre-Eagle','5.7 Hemi Eagle','Unknown / identify later']},
      {displacement:'6.1L',codes:['6.1 SRT Hemi','Unknown / identify later']},
      {displacement:'6.2L',codes:['Hellcat','Demon','Redeye / High Output','Unknown / identify later']},
      {displacement:'6.4L',codes:['Apache passenger car','BGE truck','Unknown / identify later']}
    ]},
    {family:'Mopar LA / Magnum',groups:[
      {displacement:'5.2L / 318',codes:['LA 318','Magnum 5.2','Unknown / custom build']},
      {displacement:'5.9L / 360',codes:['LA 360','Magnum 5.9','Unknown / custom build']},
      {displacement:'6.7L / 408',codes:['408 stroker','Unknown / custom build']}
    ]},
    {family:'Cummins',groups:[
      {displacement:'5.9L',codes:['12-valve 6BT','24-valve ISB','Common-rail 5.9','Unknown / identify later']},
      {displacement:'6.7L',codes:['6.7 ISB','High Output 6.7','Unknown / identify later']}
    ]},
    {family:'Toyota JZ',groups:[
      {displacement:'2.5L',codes:['1JZ-GE','1JZ-GTE','Unknown / identify later']},
      {displacement:'3.0L',codes:['2JZ-GE','2JZ-GTE','Unknown / identify later']}
    ]},
    {family:'Nissan RB / VR',groups:[
      {displacement:'2.5L',codes:['RB25DE','RB25DET','Unknown / identify later']},
      {displacement:'2.6L',codes:['RB26DETT','Unknown / identify later']},
      {displacement:'3.0L',codes:['VR30DDTT','Unknown / identify later']},
      {displacement:'3.8L',codes:['VR38DETT','Unknown / identify later']}
    ]},
    {family:'Honda K-Series',groups:[
      {displacement:'2.0L',codes:['K20A','K20A2','K20Z1','K20C1','Unknown / identify later']},
      {displacement:'2.4L',codes:['K24A2','K24A4','K24Z7','K24W','Unknown / identify later']}
    ]},
    {family:'Subaru EJ / FA',groups:[
      {displacement:'2.0L',codes:['EJ20','FA20','FA20DIT','Unknown / identify later']},
      {displacement:'2.4L',codes:['FA24','FA24DIT','Unknown / identify later']},
      {displacement:'2.5L',codes:['EJ25','EJ255','EJ257','Unknown / identify later']}
    ]},
    {family:'Custom / Other',groups:[{displacement:'Custom',codes:['Custom engine']} ]}
  ];

  const normalize=value=>String(value||'').trim().toLowerCase().replace(/[^a-z0-9.]+/g,' ');
  function familyEntry(family){return catalog.find(item=>item.family===family)||null}
  function groupEntry(family,displacement){return familyEntry(family)?.groups.find(item=>item.displacement===displacement)||null}
  function composeEngineLabel(selection={}){
    const family=String(selection.family||'').trim();
    const displacement=String(selection.displacement||'').trim();
    const code=String(selection.code||'').trim();
    const custom=String(selection.custom||'').trim();
    if(family==='Custom / Other')return custom;
    const usefulCode=/^unknown\s*\//i.test(code)?'':code;
    return [family,displacement,usefulCode].filter(Boolean).join(' / ');
  }
  function findEngineSelection(value){
    const raw=String(value||'').trim();
    if(!raw)return {family:'',displacement:'',code:'',custom:''};
    const hay=normalize(raw);
    for(const family of catalog){
      if(family.family==='Custom / Other')continue;
      for(const group of family.groups){
        for(const code of group.codes){
          if(/^unknown\s*\//i.test(code))continue;
          const needle=normalize(code);
          if(needle&&hay.includes(needle))return {family:family.family,displacement:group.displacement,code,custom:''};
        }
      }
    }
    for(const family of catalog){
      if(family.family==='Custom / Other')continue;
      const familyAliases={
        'LS':['ls','gen iii','gen iv'],
        'GM LT / EcoTec3':['lt','ecotec3'],
        'GM Small-Block Chevy':['small block','sbc'],
        'GM Big-Block Chevy':['big block','bbc']
      };
      const familyTokens=[...(familyAliases[family.family]||[]),...normalize(family.family).split(' ').filter(token=>token.length>1&&token!=='gm'&&token!=='ford'&&token!=='mopar')];
      const familyMatch=familyTokens.some(token=>hay.includes(token));
      if(!familyMatch)continue;
      const group=family.groups.find(item=>normalize(item.displacement).split(' ')[0]&&hay.includes(normalize(item.displacement).split(' ')[0]))||family.groups[0];
      return {family:family.family,displacement:group?.displacement||'',code:'Unknown / identify later',custom:''};
    }
    return {family:'Custom / Other',displacement:'Custom',code:'Custom engine',custom:raw};
  }
  return {catalog,familyEntry,groupEntry,composeEngineLabel,findEngineSelection};
});
