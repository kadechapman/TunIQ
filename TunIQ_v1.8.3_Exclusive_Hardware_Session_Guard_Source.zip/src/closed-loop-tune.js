const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { normalizeFile } = require('./log-import');
const { sameBinding } = require('./tune-workspace');

const CLOSED_LOOP_SCHEMA_VERSION = 1;
const MAX_AUDIT = 1000;
const MAX_EVALUATIONS = 100;
const DEFAULT_MAX_CYCLES = 5;

function clone(value) { return JSON.parse(JSON.stringify(value)); }
function now() { return new Date().toISOString(); }
function id(prefix) { return `${prefix}-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`; }
function safe(value, maximum = 1000) { return String(value ?? '').trim().slice(0, maximum); }
function finite(value) { const number = Number(value); return Number.isFinite(number) ? number : null; }
function clamp(value, minimum, maximum) { return Math.max(minimum, Math.min(maximum, value)); }
function round(value, digits = 2) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function atomicWriteJson(file, value) {
  ensureDir(path.dirname(file));
  const temporary = `${file}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temporary, JSON.stringify(value, null, 2), 'utf8');
  try { fs.renameSync(temporary, file); }
  catch (error) {
    if (!['EEXIST', 'EPERM', 'EACCES'].includes(error?.code)) { try { fs.unlinkSync(temporary); } catch {} throw error; }
    try { fs.unlinkSync(file); } catch {}
    fs.renameSync(temporary, file);
  }
}
function average(values) { const usable = values.map(finite).filter(Number.isFinite); return usable.length ? usable.reduce((sum, value) => sum + value, 0) / usable.length : null; }
function minimum(values) { const usable = values.map(finite).filter(Number.isFinite); return usable.length ? Math.min(...usable) : null; }
function maximum(values) { const usable = values.map(finite).filter(Number.isFinite); return usable.length ? Math.max(...usable) : null; }
function percentile(values, percentileValue) {
  const usable = values.map(finite).filter(Number.isFinite).sort((a, b) => a - b);
  if (!usable.length) return null;
  const index = Math.min(usable.length - 1, Math.max(0, Math.round((usable.length - 1) * percentileValue)));
  return usable[index];
}
function present(row, key) { return row[key] !== null && row[key] !== '' && row[key] !== undefined && Number.isFinite(Number(row[key])); }
function values(rows, key) { return rows.filter(row => present(row, key)).map(row => Number(row[key])); }
function rowLoad(row) {
  const load = finite(row.load); if (load != null) return load > 2 ? load / 100 : load;
  const map = finite(row.map); return map != null ? clamp(map / 100, 0, 1.5) : null;
}
function isIdle(row) { const rpm = finite(row.rpm), speed = finite(row.speed), tps = finite(row.tps); return rpm != null && rpm >= 450 && rpm <= 1300 && (speed == null || speed < 5) && (tps == null || tps < 18); }
function isCruise(row) { const speed = finite(row.speed), tps = finite(row.tps), load = rowLoad(row); return speed != null && speed >= 20 && (tps == null || (tps >= 5 && tps <= 45)) && (load == null || load <= 0.65); }
function isAcceleration(row) { const rpm = finite(row.rpm), tps = finite(row.tps), load = rowLoad(row); return rpm != null && rpm > 1400 && ((tps != null && tps >= 45) || (load != null && load >= 0.6)); }
function isWot(row) { const tps = finite(row.tps), load = rowLoad(row); return (tps != null && tps >= 75) || (load != null && load >= 0.78); }
function hasShiftEvidence(rows) {
  let previousGear = null;
  for (const row of rows) {
    const gear = finite(row.actualGear ?? row.commandedGear);
    if (gear != null && previousGear != null && gear !== previousGear) return true;
    if (gear != null) previousGear = gear;
    if (finite(row.shiftTime) != null || finite(row.transSlip) != null || finite(row.tccSlip) != null) return true;
  }
  return false;
}
function zoneScore(count, target) { return clamp(Math.round((count / target) * 100), 0, 100); }
function channelScore(available, required) { return required.length ? Math.round(required.filter(key => available.includes(key)).length / required.length * 100) : 100; }

function buildCoverage(rows, available) {
  const counts = {
    idle: rows.filter(isIdle).length,
    cruise: rows.filter(isCruise).length,
    acceleration: rows.filter(isAcceleration).length,
    wot: rows.filter(isWot).length,
    shifts: hasShiftEvidence(rows) ? rows.filter(row => present(row, 'actualGear') || present(row, 'commandedGear') || present(row, 'shiftTime') || present(row, 'transSlip') || present(row, 'tccSlip')).length : 0
  };
  const zones = {
    idle: { rows: counts.idle, score: zoneScore(counts.idle, 30) },
    cruise: { rows: counts.cruise, score: zoneScore(counts.cruise, 50) },
    acceleration: { rows: counts.acceleration, score: zoneScore(counts.acceleration, 30) },
    wot: { rows: counts.wot, score: zoneScore(counts.wot, 20) },
    shifts: { rows: counts.shifts, score: zoneScore(counts.shifts, 12) }
  };
  const stageChannels = {
    drivability: ['rpm', 'speed', 'ect', 'tps', 'desiredIdle'],
    airflow: ['rpm', 'tps', 'map', 'maf', 'stft1', 'ltft1'],
    fueling: ['rpm', 'tps', 'load', 'commandedEqRatio', 'widebandAfr'],
    spark: ['rpm', 'load', 'knockRetard', 'spark'],
    transmission: ['rpm', 'speed', 'commandedGear', 'actualGear', 'shiftTime', 'tccSlip']
  };
  const stageConfidence = {};
  for (const [stage, required] of Object.entries(stageChannels)) {
    const channels = channelScore(available, required);
    const zone = stage === 'drivability' ? zones.idle.score : stage === 'airflow' ? Math.round((zones.cruise.score + zones.acceleration.score) / 2) : stage === 'fueling' || stage === 'spark' ? zones.wot.score : zones.shifts.score;
    stageConfidence[stage] = { channels, zone, score: Math.round((channels * 0.6) + (zone * 0.4)), missing: required.filter(key => !available.includes(key)) };
  }
  const overall = Math.round((zones.idle.score + zones.cruise.score + zones.acceleration.score + zones.wot.score + zones.shifts.score) / 5);
  return { zones, stageConfidence, overall };
}

function buildMetrics(rows, targets = {}) {
  const idleRows = rows.filter(isIdle), cruiseRows = rows.filter(isCruise), wotRows = rows.filter(isWot);
  const trims = cruiseRows.flatMap(row => ['stft1', 'stft2', 'ltft1', 'ltft2'].map(key => finite(row[key])).filter(Number.isFinite));
  const absoluteTrimError = average(trims.map(value => Math.abs(value)));
  const desiredIdle = finite(targets.desiredIdle) ?? average(values(idleRows, 'desiredIdle'));
  const idleError = desiredIdle != null ? average(values(idleRows, 'rpm').map(value => Math.abs(value - desiredIdle))) : null;
  const targetAfr = finite(targets.targetAfr) ?? (finite(targets.targetLambda) != null ? Number(targets.targetLambda) * 14.7 : null);
  const afrErrors = [];
  for (const row of wotRows) {
    const actual = finite(row.widebandAfr), commandedAfr = finite(row.commandedAfr), commandedEq = finite(row.commandedEqRatio);
    const target = targetAfr ?? commandedAfr ?? (commandedEq != null && commandedEq > 0 ? 14.7 / commandedEq : null);
    if (actual != null && target != null) afrErrors.push(actual - target);
  }
  const knock = values(wotRows.length ? wotRows : rows, 'knockRetard');
  const voltage = values(rows, 'voltage'), ect = values(rows, 'ect'), iat = values(rows, 'iat'), duty = values(rows, 'injectorDuty'), fuelPressure = values(rows, 'fuelPressure');
  const misfires = values(rows, 'misfireTotal');
  const misfireDelta = misfires.length ? Math.max(0, Math.max(...misfires) - Math.min(...misfires)) : null;
  const trimPenalty = absoluteTrimError == null ? 18 : clamp(absoluteTrimError * 3, 0, 35);
  const afrPenalty = afrErrors.length ? clamp(average(afrErrors.map(value => Math.abs(value))) * 12, 0, 35) : 18;
  const knockPenalty = knock.length ? clamp((percentile(knock, 0.95) || 0) * 5, 0, 25) : 10;
  const idlePenalty = idleError == null ? 5 : clamp(idleError / 20, 0, 10);
  const compositeError = round(trimPenalty + afrPenalty + knockPenalty + idlePenalty, 2);
  return {
    targetAfr: round(targetAfr, 3),
    trimErrorPercent: round(absoluteTrimError, 2),
    idleErrorRpm: round(idleError, 1),
    afrErrorWot: round(average(afrErrors.map(value => Math.abs(value))), 3),
    afrBiasWot: round(average(afrErrors), 3),
    maxKnockRetard: round(maximum(knock), 2),
    p95KnockRetard: round(percentile(knock, 0.95), 2),
    minimumVoltage: round(minimum(voltage), 2),
    maximumEct: round(maximum(ect), 1),
    maximumIat: round(maximum(iat), 1),
    maximumInjectorDuty: round(maximum(duty), 1),
    minimumFuelPressure: round(minimum(fuelPressure), 1),
    misfireDelta: round(misfireDelta, 0),
    compositeError
  };
}

function buildSafety(metrics) {
  const critical = [], warnings = [];
  if (metrics.minimumVoltage != null && metrics.minimumVoltage < 11.5) critical.push(`System voltage fell to ${metrics.minimumVoltage} V.`);
  else if (metrics.minimumVoltage != null && metrics.minimumVoltage < 12.2) warnings.push(`System voltage fell to ${metrics.minimumVoltage} V.`);
  if (metrics.maximumEct != null && metrics.maximumEct >= 240) critical.push(`Coolant temperature reached ${metrics.maximumEct} °F.`);
  else if (metrics.maximumEct != null && metrics.maximumEct >= 225) warnings.push(`Coolant temperature reached ${metrics.maximumEct} °F.`);
  if (metrics.maximumIat != null && metrics.maximumIat >= 180) critical.push(`Intake-air temperature reached ${metrics.maximumIat} °F.`);
  else if (metrics.maximumIat != null && metrics.maximumIat >= 150) warnings.push(`Intake-air temperature reached ${metrics.maximumIat} °F.`);
  if (metrics.maxKnockRetard != null && metrics.maxKnockRetard >= 8) critical.push(`Knock retard reached ${metrics.maxKnockRetard}°.`);
  else if (metrics.maxKnockRetard != null && metrics.maxKnockRetard >= 4) warnings.push(`Knock retard reached ${metrics.maxKnockRetard}°.`);
  if (metrics.afrBiasWot != null && metrics.afrBiasWot >= 1.5) critical.push(`Wideband data averaged ${metrics.afrBiasWot.toFixed(2)} AFR leaner than target at high load.`);
  else if (metrics.afrBiasWot != null && metrics.afrBiasWot >= 0.8) warnings.push(`Wideband data averaged ${metrics.afrBiasWot.toFixed(2)} AFR leaner than target at high load.`);
  if (metrics.misfireDelta != null && metrics.misfireDelta >= 100) critical.push(`Misfire count increased by ${metrics.misfireDelta}.`);
  else if (metrics.misfireDelta != null && metrics.misfireDelta >= 25) warnings.push(`Misfire count increased by ${metrics.misfireDelta}.`);
  if (metrics.maximumInjectorDuty != null && metrics.maximumInjectorDuty >= 100) critical.push(`Injector duty reached ${metrics.maximumInjectorDuty}%.`);
  else if (metrics.maximumInjectorDuty != null && metrics.maximumInjectorDuty >= 92) warnings.push(`Injector duty reached ${metrics.maximumInjectorDuty}%.`);
  return { status: critical.length ? 'critical' : warnings.length ? 'warning' : 'clear', critical, warnings };
}

function compareEvaluations(previous, current) {
  if (!previous) return { available: false, improvementPercent: null, regression: false, converged: false, summary: 'Baseline evaluation recorded.' };
  const before = finite(previous.metrics?.compositeError), after = finite(current.metrics?.compositeError);
  const improvementPercent = before != null && before > 0 && after != null ? round(((before - after) / before) * 100, 1) : null;
  const regression = improvementPercent != null && improvementPercent <= -20;
  const converged = current.safety.status === 'clear'
    && current.confidence.score >= 75
    && (current.metrics.trimErrorPercent == null || current.metrics.trimErrorPercent <= 4)
    && (current.metrics.afrErrorWot == null || current.metrics.afrErrorWot <= 0.35)
    && (current.metrics.p95KnockRetard == null || current.metrics.p95KnockRetard <= 1)
    && (current.metrics.idleErrorRpm == null || current.metrics.idleErrorRpm <= 75);
  const summary = regression ? `Composite error regressed ${Math.abs(improvementPercent).toFixed(1)}%.`
    : converged ? 'The latest log meets the current convergence thresholds.'
      : improvementPercent == null ? 'Not enough comparable metrics were available.'
        : improvementPercent >= 0 ? `Composite error improved ${improvementPercent.toFixed(1)}%.` : `Composite error worsened ${Math.abs(improvementPercent).toFixed(1)}%.`;
  return { available: true, improvementPercent, regression, converged, summary };
}

function evaluateLog(csvPath, options = {}) {
  if (!csvPath || !fs.existsSync(csvPath)) throw new Error('Select an existing normalized or supported vehicle log.');
  const normalized = normalizeFile(csvPath, { profile: options.profile || 'power' });
  if (!normalized.rows.length) throw new Error('The selected log contains no usable sensor rows.');
  const coverage = buildCoverage(normalized.rows, normalized.available);
  const metrics = buildMetrics(normalized.rows, options.targets || {});
  const safety = buildSafety(metrics);
  const qualityBase = normalized.quality.status === 'usable' ? 78 : normalized.quality.status === 'limited' ? 52 : 25;
  const durationBonus = clamp((finite(normalized.quality.durationSeconds) || 0) / 120 * 12, 0, 12);
  const sampleBonus = clamp((finite(normalized.quality.sampleRateHz) || 0) / 10 * 10, 0, 10);
  const qualityScore = Math.round(clamp(qualityBase + durationBonus + sampleBonus - (normalized.missing.length * 1.5), 0, 100));
  const stageScores = Object.values(coverage.stageConfidence).map(item => item.score);
  const confidenceScore = Math.round(clamp((qualityScore * 0.45) + (coverage.overall * 0.25) + ((average(stageScores) || 0) * 0.30) - (safety.status === 'critical' ? 35 : safety.status === 'warning' ? 10 : 0), 0, 100));
  const confidence = { score: confidenceScore, label: confidenceScore >= 85 ? 'high' : confidenceScore >= 65 ? 'medium' : confidenceScore >= 45 ? 'limited' : 'insufficient', qualityScore, coverageScore: coverage.overall };
  return {
    schemaVersion: CLOSED_LOOP_SCHEMA_VERSION,
    id: id('log-evaluation'),
    kind: 'closed-loop-log-evaluation',
    createdAt: now(),
    csvPath,
    csvName: path.basename(csvPath),
    normalizedFingerprint: normalized.normalizedFingerprint,
    source: normalized.source,
    rows: normalized.rows.length,
    durationSeconds: normalized.quality.durationSeconds,
    sampleRateHz: normalized.quality.sampleRateHz,
    availableChannels: normalized.available,
    missingRecommendedChannels: normalized.missing,
    quality: normalized.quality,
    coverage,
    metrics,
    safety,
    confidence,
    role: options.role || 'validation',
    targets: clone(options.targets || {})
  };
}

function buildProjectReadiness({ workspace, autonomousRun, session, evaluation, recoverySnapshot = null }) {
  const checks = [
    { id: 'binding', label: 'Exact BIN/XDF binding', weight: 15, passed: Boolean(workspace?.mode === 'xdf' && workspace?.binding?.binSha256 && workspace?.binding?.xdfSha256) },
    { id: 'coverage', label: 'Mapped calibration coverage', weight: 15, passed: Boolean(workspace?.mappingSummary?.loaded >= 5 || Object.keys(workspace?.tables || {}).length >= 5) },
    { id: 'autonomous', label: 'Autonomous base tune completed', weight: 20, passed: autonomousRun?.status === 'ready-for-flash-confirmation' || Boolean(autonomousRun?.finalRevision) },
    { id: 'log-quality', label: 'Usable validation log', weight: 15, passed: Boolean(evaluation?.confidence?.score >= 65) },
    { id: 'safety', label: 'Validation safety clear', weight: 15, passed: evaluation?.safety?.status === 'clear' },
    { id: 'convergence', label: 'Closed-loop convergence', weight: 15, passed: session?.status === 'converged' || Boolean(evaluation?.comparison?.converged) },
    { id: 'recovery', label: 'Recovery snapshot available', weight: 5, passed: Boolean(recoverySnapshot || session?.lastStableSnapshotId) }
  ];
  const score = checks.reduce((sum, check) => sum + (check.passed ? check.weight : 0), 0);
  return { score, label: score >= 95 ? 'release-candidate' : score >= 80 ? 'validation-ready' : score >= 60 ? 'in-progress' : 'blocked', checks, missing: checks.filter(check => !check.passed).map(check => check.label) };
}

class ClosedLoopTuneManager {
  constructor(options = {}) { this.appendActivity = options.appendActivity || (() => {}); }
  root(active) { return ensureDir(path.join(active.folder, 'AI', 'ClosedLoopTune')); }
  stateFile(active) { return path.join(this.root(active), 'state.json'); }
  auditFile(active) { return path.join(this.root(active), 'audit.json'); }
  evaluationsRoot(active) { return ensureDir(path.join(this.root(active), 'Evaluations')); }
  reportFile(active) { return path.join(this.root(active), 'closed-loop-validation-report.json'); }
  load(active) { const state = readJson(this.stateFile(active), null); return state?.projectId === active.id ? state : null; }
  save(active, state) { atomicWriteJson(this.stateFile(active), state); return state; }
  audit(active, type, details = {}) {
    const items = readJson(this.auditFile(active), []);
    const next = [{ id: id('closed-loop-audit'), type, details, at: now() }, ...(Array.isArray(items) ? items : [])].slice(0, MAX_AUDIT);
    atomicWriteJson(this.auditFile(active), next);
    return next[0];
  }
  evaluations(active) {
    const state = this.load(active);
    const ids = Array.isArray(state?.evaluationIds) ? state.evaluationIds : [];
    return ids.map(evaluationId => readJson(path.join(this.evaluationsRoot(active), `${evaluationId}.json`), null)).filter(Boolean);
  }
  start(active, workspace, autonomousRun, payload = {}) {
    if (!workspace?.binding?.projectId || !workspace?.binding?.binSha256 || !workspace?.binding?.xdfSha256 || workspace.mode !== 'xdf') throw new Error('Load an exact project BIN/XDF workspace before starting closed-loop tuning.');
    const previous = this.load(active);
    if (previous) {
      const folder = ensureDir(path.join(this.root(active), 'Archive'));
      atomicWriteJson(path.join(folder, `${new Date().toISOString().replace(/[:.]/g, '-')}-${previous.id}.json`), previous);
    }
    if (!autonomousRun || autonomousRun.status !== 'ready-for-flash-confirmation') throw new Error('Complete the Autonomous Tune base calibration before starting closed-loop validation.');
    if (!sameBinding(autonomousRun.binding, workspace.binding)) throw new Error('The Autonomous Tune run and current BIN/XDF fingerprints do not match.');
    const state = {
      schemaVersion: CLOSED_LOOP_SCHEMA_VERSION,
      id: id('closed-loop-session'),
      kind: 'closed-loop-tune-session',
      projectId: active.id,
      projectName: active.name,
      binding: clone(workspace.binding),
      status: 'waiting-for-log',
      phase: 'baseline-validation',
      createdAt: now(),
      updatedAt: now(),
      maxCycles: clamp(Math.round(finite(payload.maxCycles) || DEFAULT_MAX_CYCLES), 1, 10),
      autoProcessNewLogs: payload.autoProcessNewLogs !== false,
      autoRunCorrections: payload.autoRunCorrections !== false,
      cycleCount: 0,
      targets: clone(payload.targets || autonomousRun.targets || {}),
      intake: clone(autonomousRun.intake || {}),
      autonomousRunId: autonomousRun.id,
      lastStableSnapshotId: payload.lastStableSnapshotId || null,
      rollbackSnapshotId: null,
      evaluationIds: [],
      cycles: [],
      blockers: [],
      warnings: [],
      latestEvaluationId: null,
      validatedEvaluationId: null,
      finalRevision: autonomousRun.finalRevision || null,
      handoff: autonomousRun.handoff || null,
      readiness: null
    };
    this.save(active, state);
    this.audit(active, 'session-started', { sessionId: state.id, autonomousRunId: autonomousRun.id, maxCycles: state.maxCycles });
    this.appendActivity('closed-loop-session-started', { projectId: active.id, sessionId: state.id });
    return state;
  }
  assertState(state, active, workspace) {
    if (!state || state.projectId !== active.id) throw new Error('No closed-loop session belongs to the active project.');
    if (!sameBinding(state.binding, workspace.binding)) throw new Error('The BIN/XDF fingerprint changed during closed-loop tuning. Start a new session.');
  }
  status(active, workspace = null, autonomousRun = null) {
    if (!active) return { active: false, session: null, evaluations: [], audit: [], readiness: null };
    const session = this.load(active), evaluations = this.evaluations(active), latest = evaluations[0] || null;
    let stale = false, staleReason = null;
    if (session && workspace && !sameBinding(session.binding, workspace.binding)) { stale = true; staleReason = 'The active BIN/XDF fingerprint no longer matches this closed-loop session.'; }
    const readiness = buildProjectReadiness({ workspace, autonomousRun, session, evaluation: latest });
    const audit = readJson(this.auditFile(active), []);
    return { active: true, session, evaluations: evaluations.slice(0, 30), latestEvaluation: latest, stale, staleReason, readiness, audit: Array.isArray(audit) ? audit.slice(0, 150) : [] };
  }
  analyze(active, workspace, csvPath, options = {}) {
    const state = this.load(active);
    this.assertState(state, active, workspace);
    const evaluation = evaluateLog(csvPath, { profile: options.profile || 'power', targets: state.targets, role: options.role || (state.phase === 'awaiting-validation-log' ? 'post-correction' : 'baseline') });
    const existing = this.evaluations(active).find(item => item.normalizedFingerprint === evaluation.normalizedFingerprint);
    if (existing) throw new Error(`This log was already evaluated as ${existing.csvName}. Record a new drive before the next closed-loop decision.`);
    const previous = this.evaluations(active)[0] || null;
    evaluation.comparison = compareEvaluations(previous, evaluation);
    atomicWriteJson(path.join(this.evaluationsRoot(active), `${evaluation.id}.json`), evaluation);
    const evaluationIds = [evaluation.id, ...(state.evaluationIds || [])].slice(0, MAX_EVALUATIONS);
    let status = 'ready-for-correction', phase = 'analysis-complete', blockers = [], warnings = [...evaluation.safety.warnings, ...(evaluation.quality.warnings || [])];
    if (evaluation.safety.status === 'critical') { status = 'safety-stop'; phase = 'rollback-required'; blockers = evaluation.safety.critical; }
    else if (evaluation.confidence.score < 60) { status = 'waiting-for-log'; phase = 'insufficient-log-confidence'; blockers = [`Log confidence is ${evaluation.confidence.score}%. Record a longer log with the missing channels and operating zones.`]; }
    else if (state.phase === 'awaiting-validation-log' && evaluation.comparison.regression) { status = 'rollback-required'; phase = 'validation-regression'; blockers = [evaluation.comparison.summary]; }
    else if (evaluation.comparison.converged) { status = 'converged'; phase = 'validated'; }
    else if (state.cycleCount >= state.maxCycles) { status = 'max-cycles-reached'; phase = 'manual-review-required'; blockers = [`The session reached its ${state.maxCycles}-cycle limit without convergence.`]; }
    const next = {
      ...state,
      status,
      phase,
      updatedAt: now(),
      evaluationIds,
      latestEvaluationId: evaluation.id,
      validatedEvaluationId: status === 'converged' ? evaluation.id : state.validatedEvaluationId,
      blockers,
      warnings,
      readiness: buildProjectReadiness({ workspace, autonomousRun: { status: 'ready-for-flash-confirmation', finalRevision: state.finalRevision }, session: { ...state, status }, evaluation })
    };
    this.save(active, next);
    this.audit(active, 'log-evaluated', { sessionId: state.id, evaluationId: evaluation.id, csvName: evaluation.csvName, confidence: evaluation.confidence.score, safety: evaluation.safety.status, status });
    this.appendActivity('closed-loop-log-evaluated', { projectId: active.id, evaluationId: evaluation.id, confidence: evaluation.confidence.score, safety: evaluation.safety.status, status });
    return { session: next, evaluation };
  }
  markCorrectionStarted(active, workspace, evaluation, snapshot) {
    const state = this.load(active); this.assertState(state, active, workspace);
    if (!evaluation || evaluation.id !== state.latestEvaluationId) throw new Error('Analyze the latest log before starting a correction cycle.');
    if (state.status !== 'ready-for-correction') throw new Error(`Closed-loop correction is not ready while the session is ${state.status}.`);
    if (state.cycleCount >= state.maxCycles) throw new Error('The closed-loop cycle limit has been reached.');
    const next = { ...state, status: 'correcting', phase: `cycle-${state.cycleCount + 1}`, rollbackSnapshotId: snapshot?.id || state.lastStableSnapshotId || null, blockers: [], updatedAt: now() };
    this.save(active, next); this.audit(active, 'correction-started', { sessionId: next.id, cycle: next.cycleCount + 1, evaluationId: evaluation.id, rollbackSnapshotId: next.rollbackSnapshotId });
    return next;
  }
  recordCorrection(active, workspace, evaluation, result = {}) {
    const state = this.load(active); this.assertState(state, active, workspace);
    const cycle = {
      id: id('closed-loop-cycle'),
      number: state.cycleCount + 1,
      evaluationId: evaluation.id,
      inputLog: evaluation.csvPath,
      inputFingerprint: evaluation.normalizedFingerprint,
      confidence: evaluation.confidence.score,
      safety: evaluation.safety.status,
      autonomousRunId: result.state?.id || null,
      appliedCells: result.state?.totalAppliedCells || 0,
      stageResults: clone(result.state?.stageResults || []),
      revision: result.revision || result.state?.finalRevision || null,
      handoff: result.handoff || result.state?.handoff || null,
      completedAt: now(),
      status: result.state?.status === 'ready-for-flash-confirmation' ? 'awaiting-validation' : 'stopped',
      blockers: clone(result.state?.blockers || [])
    };
    const successful = cycle.status === 'awaiting-validation';
    const next = {
      ...state,
      cycleCount: successful ? cycle.number : state.cycleCount,
      cycles: [cycle, ...(state.cycles || [])].slice(0, 30),
      status: successful ? 'waiting-for-validation-log' : 'correction-stopped',
      phase: successful ? 'awaiting-validation-log' : 'correction-stopped',
      finalRevision: cycle.revision || state.finalRevision,
      handoff: cycle.handoff || state.handoff,
      blockers: cycle.blockers,
      updatedAt: now()
    };
    this.save(active, next); this.audit(active, successful ? 'correction-completed' : 'correction-stopped', { sessionId: next.id, cycle: cycle.number, appliedCells: cycle.appliedCells, revision: cycle.revision?.name || null, blockers: cycle.blockers });
    this.appendActivity(successful ? 'closed-loop-correction-completed' : 'closed-loop-correction-stopped', { projectId: active.id, cycle: cycle.number, appliedCells: cycle.appliedCells, revision: cycle.revision?.name || null });
    return { session: next, cycle };
  }
  markRollback(active, workspace, details = {}) {
    const state = this.load(active); this.assertState(state, active, workspace);
    const next = { ...state, status: 'rolled-back', phase: 'rollback-complete', blockers: [], warnings: [...(state.warnings || []), safe(details.reason || 'The last correction cycle was rolled back.')], lastStableSnapshotId: details.snapshotId || state.lastStableSnapshotId, finalRevision: details.revision || state.finalRevision, updatedAt: now() };
    this.save(active, next); this.audit(active, 'rollback-completed', { sessionId: next.id, snapshotId: details.snapshotId || null, revision: details.revision?.name || null, reason: details.reason || null });
    this.appendActivity('closed-loop-rollback-completed', { projectId: active.id, snapshotId: details.snapshotId || null, revision: details.revision?.name || null });
    return next;
  }
  markValidated(active, workspace, snapshot = null) {
    const state = this.load(active); this.assertState(state, active, workspace);
    const next = { ...state, status: 'converged', phase: 'validated', lastStableSnapshotId: snapshot?.id || state.lastStableSnapshotId, blockers: [], updatedAt: now() };
    this.save(active, next); this.audit(active, 'session-validated', { sessionId: next.id, evaluationId: next.validatedEvaluationId, snapshotId: snapshot?.id || null, cycleCount: next.cycleCount });
    this.appendActivity('closed-loop-session-validated', { projectId: active.id, cycleCount: next.cycleCount, evaluationId: next.validatedEvaluationId });
    return next;
  }
  exportReport(active, workspace, autonomousRun = null) {
    const status = this.status(active, workspace, autonomousRun);
    const report = { format: 'TunIQ Closed-Loop Validation Report', schemaVersion: CLOSED_LOOP_SCHEMA_VERSION, generatedAt: now(), project: { id: active.id, name: active.name, controller: active.controller || '', os: active.os || '' }, binding: clone(workspace.binding || {}), readiness: status.readiness, session: status.session, evaluations: status.evaluations, audit: status.audit };
    atomicWriteJson(this.reportFile(active), report);
    this.audit(active, 'report-exported', { sessionId: status.session?.id || null, path: this.reportFile(active), readiness: status.readiness?.score || 0 });
    return { path: this.reportFile(active), report };
  }
  reset(active) {
    const state = this.load(active); if (!state) return { reset: false, archive: null };
    const folder = ensureDir(path.join(this.root(active), 'Archive'));
    const archive = path.join(folder, `${new Date().toISOString().replace(/[:.]/g, '-')}-${state.id}.json`);
    atomicWriteJson(archive, state); try { fs.unlinkSync(this.stateFile(active)); } catch {}
    this.audit(active, 'session-reset', { sessionId: state.id, archive });
    return { reset: true, archive };
  }
}

async function executeClosedLoopCorrection(options = {}) {
  const { manager, active, workspace: initialWorkspace, csvPath, callbacks = {} } = options;
  if (!manager) throw new Error('Closed-loop tuning service is unavailable.');
  let workspace = clone(initialWorkspace);
  const existingSession = manager.load(active);
  const latest = manager.evaluations(active)[0] || null;
  const analysis = existingSession?.status === 'ready-for-correction' && latest?.csvPath === csvPath
    ? { session: existingSession, evaluation: latest }
    : manager.analyze(active, workspace, csvPath, { role: 'correction-input' });
  if (analysis.session.status !== 'ready-for-correction') return { ...analysis, workspace, corrected: false };
  const snapshot = callbacks.createSnapshot?.(workspace, { name: `Closed-Loop Cycle ${analysis.session.cycleCount + 1} Rollback Point`, note: `Automatic rollback point before closed-loop correction using ${analysis.evaluation.csvName}.` }) || null;
  manager.markCorrectionStarted(active, workspace, analysis.evaluation, snapshot);
  let result;
  try { result = await callbacks.runCorrection?.(analysis.evaluation.csvPath); }
  catch (error) {
    const stopped = manager.recordCorrection(active, workspace, analysis.evaluation, { state: { status: 'stopped', blockers: [error.message], stageResults: [] } });
    return { ...stopped, evaluation: analysis.evaluation, workspace, corrected: false };
  }
  workspace = result?.workspace || workspace;
  const recorded = manager.recordCorrection(active, workspace, analysis.evaluation, result || {});
  return { ...recorded, evaluation: analysis.evaluation, workspace, correction: result, corrected: recorded.cycle.status === 'awaiting-validation' };
}

async function analyzeClosedLoopValidation(options = {}) {
  const { manager, active, workspace: initialWorkspace, csvPath, callbacks = {} } = options;
  let workspace = clone(initialWorkspace);
  const result = manager.analyze(active, workspace, csvPath, { role: 'post-correction' });
  if (['safety-stop', 'rollback-required'].includes(result.session.status)) {
    const snapshotId = result.session.rollbackSnapshotId || result.session.lastStableSnapshotId;
    if (snapshotId && callbacks.restoreSnapshot) {
      workspace = callbacks.restoreSnapshot(snapshotId);
      const revision = callbacks.exportRevision?.(workspace, { suffix: 'ClosedLoop-Rollback' }) || null;
      const session = manager.markRollback(active, workspace, { snapshotId, revision, reason: result.session.blockers?.[0] || 'Validation regression triggered automatic rollback.' });
      return { ...result, session, workspace, revision, rolledBack: true };
    }
    return { ...result, workspace, rolledBack: false };
  }
  if (result.session.status === 'converged') {
    const snapshot = callbacks.createSnapshot?.(workspace, { name: 'Closed-Loop Validated Tune', note: `Validation log ${result.evaluation.csvName} met confidence, safety, and convergence thresholds.` }) || null;
    const session = manager.markValidated(active, workspace, snapshot);
    return { ...result, session, workspace, snapshot, validated: true };
  }
  return { ...result, workspace, validated: false };
}

module.exports = {
  ClosedLoopTuneManager,
  CLOSED_LOOP_SCHEMA_VERSION,
  DEFAULT_MAX_CYCLES,
  evaluateLog,
  compareEvaluations,
  buildProjectReadiness,
  executeClosedLoopCorrection,
  analyzeClosedLoopValidation
};
