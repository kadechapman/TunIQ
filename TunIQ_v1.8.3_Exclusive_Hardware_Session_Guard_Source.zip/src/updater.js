class UpdateManager {
  constructor(options) {
    this.options = options;
    this.current = { configured: false, state: 'idle', message: 'Update feed is not configured.', channel: 'beta', availableVersion: null, downloaded: false };
    this.autoUpdater = null;
    try {
      this.autoUpdater = require('electron-updater').autoUpdater;
      this.bindEvents();
    } catch {
      this.current.message = 'electron-updater will be available in packaged installer builds.';
    }
  }
  emit() { this.options.emit?.({ ...this.current }); }
  bindEvents() {
    const updater = this.autoUpdater;
    updater.autoDownload = false;
    updater.autoInstallOnAppQuit = true;
    updater.on('checking-for-update', () => { this.current.state = 'checking'; this.current.message = 'Checking for updates…'; this.emit(); });
    updater.on('update-available', info => { this.current.state = 'available'; this.current.availableVersion = info.version; this.current.message = `TunIQ ${info.version} is available.`; this.emit(); });
    updater.on('update-not-available', () => { this.current.state = 'current'; this.current.message = 'This TunIQ build is up to date.'; this.emit(); });
    updater.on('download-progress', progress => { this.current.state = 'downloading'; this.current.progress = progress.percent; this.current.message = `Downloading update: ${Math.round(progress.percent)}%`; this.emit(); });
    updater.on('update-downloaded', info => { this.current.state = 'downloaded'; this.current.downloaded = true; this.current.availableVersion = info.version; this.current.message = `TunIQ ${info.version} is ready to install.`; this.emit(); });
    updater.on('error', error => { this.current.state = 'error'; this.current.message = error.message || String(error); this.emit(); });
  }
  configure() {
    const preferences = this.options.getPreferences();
    this.current.channel = preferences.updateChannel || 'beta';
    const url = String(preferences.updateFeedUrl || '').trim();
    this.current.configured = Boolean(this.autoUpdater && this.options.isPackaged() && /^https:\/\//i.test(url));
    if (this.current.configured) {
      this.autoUpdater.channel = this.current.channel;
      this.autoUpdater.allowPrerelease = this.current.channel !== 'stable';
      this.autoUpdater.setFeedURL({ provider: 'generic', url });
      this.current.message = 'Automatic update feed configured.';
    } else if (!this.options.isPackaged()) this.current.message = 'Updates are disabled while running from source.';
    else if (!url) this.current.message = 'Update feed URL is not configured yet.';
    return this.status();
  }
  status() { return { ...this.current }; }
  async check() {
    this.configure();
    if (!this.current.configured) throw new Error(this.current.message);
    await this.autoUpdater.checkForUpdates();
    return this.status();
  }
  async download() {
    if (!this.current.configured) this.configure();
    if (!this.current.configured) throw new Error(this.current.message);
    await this.autoUpdater.downloadUpdate();
    return this.status();
  }
  install() {
    if (!this.current.downloaded) throw new Error('No downloaded TunIQ update is ready.');
    setImmediate(() => this.autoUpdater.quitAndInstall(false, true));
    return { installing: true };
  }
}
module.exports = { UpdateManager };
