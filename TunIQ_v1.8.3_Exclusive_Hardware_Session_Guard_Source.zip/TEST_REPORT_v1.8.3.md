# TunIQ v1.8.3 Test Report

## Release

- Version: `1.8.3`
- Name: **Exclusive Hardware Session Guard & Project Safety Vault**
- Base: TunIQ v1.8.2 Hardware Session Doctor
- Verification environment: Linux source/test environment with mocked PCM Hammer and Windows process/device fixtures

## Major fix

The OBDLink/PCM Hammer hardware path previously released TunIQ's serial handles but could not explain or prevent a separate application from owning the Bluetooth adapter. v1.8.3 scans Windows process metadata without opening the COM port, blocks high-confidence competing OBD/serial applications, and records the process name, PID, executable, and command line in the Hardware Session Doctor report.

TunIQ tracks only PCM Hammer processes it launches. Startup cleanup terminates an orphan only when both the recorded PID and executable identity still match. Arbitrary external software is never killed automatically.

## Project Safety Vault

Before Test Write, Calibration Write, Full Write, or Recovery, TunIQ now:

- Enumerates the active project without following symbolic links.
- Calculates SHA-256 and size for every project file.
- Copies the project into `%AppData%\TunIQ\Backups\Projects`.
- Recalculates every copied file and blocks hardware access if verification differs.
- Writes a complete `snapshot-manifest.json`.
- Reuses an identical verified snapshot.
- Retains the latest eight distinct snapshots per project.

## Vehicle-network recovery

PCM Hammer output that explicitly associates 1x/4x traffic with interruption, collision, or contention is classified as `bus-speed-interference`. TunIQ preserves the exact logs and recommends an assisted retry in normal PCM Hammer with faster bus communication disabled when that option is actually available. No unsupported CLI option is guessed.

## Safety retained

- Verified P01 reads remain immutable commissioning evidence.
- The protected original and deterministic stock clone are not replaced.
- OS 9379910 remains read-only for commissioning.
- Test Write remains non-writing.
- Actual PCM writes remain separately confirmation-gated.
- A failed safety snapshot or competing-process check stops before PCM Hammer opens the adapter.

## Automated verification

- Source syntax/static checks: **PASS**
- Full automated suite: **PASS — 36/36 groups**
- Exclusive Session Guard & Safety Vault: **PASS — 10/10 scenarios**
- Hardware Session Doctor: **PASS — 5/5 scenarios**
- Complete retained recovery-lab chain: **PASS**

### New scenarios

1. OBDwiz-like process blocks before COM ownership or PCM Hammer launch.
2. A serial terminal blocks only when its command line names the selected COM port.
3. A clean process inventory allows the session.
4. Only a TunIQ-owned matching orphan PCM Hammer process is terminated.
5. A complete project snapshot verifies every file by SHA-256.
6. An identical snapshot is reused.
7. A changed project creates a new distinct snapshot.
8. Integrated Test Write carries verified snapshot proof into the session report.
9. A competing-process stop preserves exact details through the P01 continuation ledger.
10. Explicit 1x/4x collision output is classified separately from COM failure.

## Retained coverage

The full retained chain passed the 1.8 dashboard and eight-workspace navigation, P01 continuity reconstruction, corrupt-ledger recovery, partial-read quarantine, matching 524,288-byte read enforcement, deterministic stock-clone reuse, COM3 retry and COM4 fallback, generic Bluetooth sibling detection, runtime COM rescan, missing-kernel handling, exact real CLI syntax, startup recovery, workspace reconciliation, definition binding, final Test Write simulations, Garage/project lifecycle, Tune Workspace, Tune Engine, autonomous and closed-loop simulations, Connection Doctor, and Offline P01 Lab.

## Hardware boundary

This release is software and simulation verified only. It does not claim that the physical Customline, P01 PCM, OBDLink MX+, Windows Bluetooth stack, or real PCM Hammer Test Write passed. TunIQ will display hardware setup complete only after the user's real Test Write produces explicit success proof.
