# TunIQ beta.16 COM Recovery & Resume Fix

## Reported failure

A real Windows run reached PCM Hammer Read Properties and then stopped because the `LockProbe` PowerShell request timed out. The workflow UI displayed a stop, but its stored/runtime state could leave Resume unavailable.

## Recovery design

- Every bridge process has a request ID and one-settlement guard.
- Timeout kills the PowerShell process tree and removes it from the active-request registry.
- Lock probes return structured `available`, `locked`, `timedOut`, `code`, `port`, and `message` fields.
- The flash handoff checks the selected port, then recognized alternate OBDLink ports.
- A timeout automatically switches Guided P01 Setup to normal PCM Hammer assisted mode when available.
- Manual recovery clears stale bridge state and converts legacy stopped/running records into resumable paused records.
- Resume retries `read-properties`, `read-1`, `read-2`, or `test-write` based on the exact stored ledger.

## Safety boundary

Skipping the problematic lock probe does not silently run a CLI write. Assisted bypass opens normal PCM Hammer and requires evidence import. Final PCM write confirmation is unchanged.
