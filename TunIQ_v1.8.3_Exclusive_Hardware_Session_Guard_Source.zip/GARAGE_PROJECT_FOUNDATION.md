# Garage & Project Foundation

TunIQ v1.7.0-beta.10 replaces the original name-only Garage relationship with durable vehicle IDs and richer profiles.

## Durable project links

- New and edited projects store `vehicleId`, the display name, and a project-safe vehicle snapshot.
- Existing projects that only contain a vehicle name are migrated when a matching Garage profile is found.
- Renaming a Garage vehicle updates every linked project manifest without moving or deleting project files.
- Vehicle deletion is blocked while a project still references that vehicle. Reassign the project first.

## Rich vehicle profiles

A Garage vehicle can retain:

- Year, make, model, trim, mileage, and an AppData-managed photo.
- Engine, transmission, drivetrain, fuel, tire size, and rear gear.
- Controller, operating system, hardware ID, and service number.
- Modifications, maintenance history, VIN, and build notes.
- Favorite state and linked-project count.

PCM Hammer Read Properties results can update controller, OS, hardware ID, and service number for the vehicle linked to the active project.

## VIN handling

VIN processing is local. TunIQ checks the 17-character format, rejects I/O/Q, calculates the North American check digit, and records possible model-year cycles. A check-digit mismatch is shown as a review warning rather than silently accepted as verified.

Legacy records with incomplete VIN text are migrated without preventing TunIQ from starting. They remain marked invalid until corrected.

## Photos

Vehicle photos are copied into `%APPDATA%\TunIQ\Vehicles\Photos`. Supported formats are JPG, PNG, and WebP, with a 15 MB limit. Project folders do not depend on the original photo location.

## Safety boundary

This release changes Garage and project metadata. It does not weaken P01 dual-read verification, checksum gates, Test Write requirements, COM ownership rules, or final-write confirmation.
