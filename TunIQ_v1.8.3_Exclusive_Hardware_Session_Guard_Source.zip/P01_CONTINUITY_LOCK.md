# P01 Continuity Lock — v1.7.0-beta.26

Beta.26 prevents Guided P01 Setup from discarding completed work.

- **Start** acts as **Continue** when the project already contains P01 evidence.
- Two matching 524,288-byte reads are recovered directly from clearly named PCM Hammer read files when an older ledger is missing.
- Protected originals, revisions, stock clones, exports, and tuned BINs are excluded from independent-read recovery.
- Once a pair is verified, later accidental or unnecessary reads cannot replace it.
- A failed unnecessary read advances from the preserved pair instead of stopping the setup.
- Only an explicit fresh-pair action after a true hash mismatch may clear the continuity lock.
