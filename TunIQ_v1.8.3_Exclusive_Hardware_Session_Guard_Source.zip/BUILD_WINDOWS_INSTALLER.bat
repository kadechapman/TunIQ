@echo off
setlocal
cd /d "%~dp0"
echo.
echo TunIQ Windows Installer Builder
echo ================================
echo This creates an unsigned public-beta installer in the dist folder.
echo A signed public release requires a code-signing certificate.
echo.
where node >nul 2>nul || (echo Node.js 18 or newer is required.& pause & exit /b 1)
if not exist node_modules (
  echo Installing build dependencies...
  call npm install || (echo Dependency installation failed.& pause & exit /b 1)
)
set CSC_IDENTITY_AUTO_DISCOVERY=false
call npm run dist:win || (echo Installer build failed.& pause & exit /b 1)
echo.
echo Installer created in: %CD%\dist
pause
