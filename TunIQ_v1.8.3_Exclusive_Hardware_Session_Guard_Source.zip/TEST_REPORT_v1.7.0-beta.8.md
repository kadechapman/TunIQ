# TunIQ v1.7.0-beta.8 Test Report

## Release

- Version: `1.7.0-beta.8`
- Name: **Connection Doctor & Offline Lab**
- Base: `TunIQ_v1.7.0-beta.7_P01_Hardware_Recovery_Source.zip`
- Verification type: automated tests and software simulations only
- Real hardware verified: **No**

## Implemented and tested

### Connection Doctor

- Windows serial-device result normalization and OBDLink/STN-aware candidate ranking.
- Preferred-port handling with likely incoming Bluetooth ports demoted.
- TunIQ serial-session release before diagnostics.
- Non-communicating exclusive COM-port lock probe.
- Explicit `adapter-locked`, `stale-com-port`, timeout, and no-response classifications.
- Automatic 115200, 38400, and 9600 baud fallback.
- Adapter identity, firmware, voltage, protocol, and VIN result normalization.
- Successful alternate ports resolve a failure on the wrong port instead of blocking connection.
- Low/missing voltage remains visible as a PCM-work warning without discarding a proven PC-to-adapter route.
- Durable JSON reports and saved proven connection settings.
- Renderer controls for running the doctor, reviewing exact corrective actions, and connecting with proven settings.

### Offline P01 Recovery Lab

- Uses the production PCM Hammer property/result parser.
- Uses the production exact 524,288-byte P01 read validator.
- Uses the production Guided Automatic P01 Setup durable ledger for lock/restart recovery.
- Clean matching-read scenario.
- Adapter-lock and exact-step restart/resume scenario.
- Partial read, SHA-256 mismatch, repeated block-read failure, and fresh-pair recovery scenario.
- Never opens a COM port.

### Beta.7 P01 recovery behavior retained

- PCM Hammer 2.x help-driven commands and real-format output parsing.
- No literal `identify` command requirement.
- Assisted normal PCM Hammer fallback.
- Exactly two complete matching 524,288-byte reads.
- Exact-step durable resume.
- Exact-OS definition, checksum, revision, Test Write, and write gates.

## Final verification commands

```text
npm run check
npm test
npm run test:connection-doctor
npm run test:p01-offline-lab
npm run test:p01-sim:clean
npm run test:p01-sim:recovery
npm run test:p01-sim:failures
```

## Results

- Source syntax check: **passed**
- Automated suite: **13 test groups passed**
- Connection Doctor simulations: **3 of 3 passed**
  - clean success
  - locked/wrong port with alternate-port and baud recovery
  - stale COM port
- Offline P01 Recovery Lab: **3 of 3 scenarios passed**
  - clean success
  - adapter lock and exact-step restart/resume
  - read-integrity failure recovery
- Existing P01 end-to-end simulations: **3 of 3 passed**
  - clean successful workflow
  - COM lock, disconnect, and app restart/resume
  - partial reads, mismatched reads, and repeated block-read failures

## Important limits

The test environment was not a Windows PC connected to an OBDLink MX+, vehicle, bench harness, or P01 PCM. The Windows PowerShell serial bridge was syntax-reviewed as source but could not be executed in this Linux build environment. Therefore this release does **not** verify:

- real Windows Bluetooth pairing or COM-port enumeration;
- actual OBDLink MX+ firmware or baud behavior;
- a physical COM4 lock owner;
- cable, DLC, vehicle wiring, ignition, or battery behavior;
- real Read Properties, full reads, Test Write, write, or recovery operations;
- voltage under flash load.

The first physical validation should remain read-only on a supported spare/bench P01 with stable regulated power and complete PCM Hammer logs retained.
