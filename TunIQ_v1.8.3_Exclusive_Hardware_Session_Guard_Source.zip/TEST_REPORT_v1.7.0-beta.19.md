# TunIQ v1.7.0-beta.19 — Real CLI Command Recovery Test Report

## Release purpose

Beta.19 fixes the integrated PCM Hammer failure captured in the user's beta.18 diagnostic report and repairs Guided P01 progress when valid identity/read evidence exists but the saved read-pair object or completed-step ledger is incomplete.

The planned v1.8 dashboard redesign remains deferred until the current 1.7 hardware workflow is proven reliable.

## Diagnostic root cause

TunIQ launched the installed PCM Hammer CLI with:

```text
read-properties --port COM3
```

The installed CLI advertises:

```text
--get-properties --device COM3
--read <file> --device COM3
--test-write <file> --device COM3
--write <file> --device COM3
```

The rejected command returned `No operation specified` followed by the CLI usage banner. Beta.18 incorrectly interpreted generic words in that static help text as PCM communication activity, so the integrated runner would not try another safe command profile.

The same diagnostic contained valid saved P01 identity and multiple matching 524,288-byte read files, but `readPair` and parts of the Guided P01 completed-step ledger were absent. Resume therefore returned to Read Properties instead of continuing to the first incomplete step.

## Corrections

### Real CLI command recovery

- Added exact `--get-properties`, `--read`, `--test-write`, `--write`, and `--device` parsing.
- Help parsing now requires an operation token at the start of an operation line instead of matching words in descriptions.
- Preserves the CLI's positional file ordering before `--device`.
- Detects a full usage/help response as syntax rejection.
- Does not count static help words as adapter/PCM communication.
- Allows another non-destructive command profile only before communication or output creation begins.
- Migrates saved command templates to schema version 2 using the stored CLI help text.
- Persists executable, arguments, reconstructed command, COM port, exit code, stdout, stderr, and classification.
- Adds **Copy Technical Details** to Guided P01 Setup.

### Saved P01 evidence recovery

- Revalidates saved read files from disk.
- Requires exactly 524,288 bytes per accepted P01 read.
- Requires actual SHA-256 to match each saved record.
- Requires matching identity fingerprints.
- Requires two distinct session IDs, paths, and proof sources.
- Reconstructs the verified read pair only when both files have matching SHA-256.
- Reconciles Read Properties, read 1, and read 2 into the automation ledger.
- Advances to exact-XDF definition when those steps are already proven.

## Dedicated beta.19 scenarios

1. **Exact observed CLI pipeline**
   - Read Properties used `--get-properties --device COM3`.
   - Full read used `--read <output> --device COM3`.
   - Test Write used `--test-write <revision> --device COM3`.
   - Read output was exactly 524,288 bytes.
   - The CLI's Full Write capability was detected separately.
   - Calibration Write remained unavailable rather than being silently mapped to Full Write.

2. **Diagnostic command-config migration**
   - Began with the beta.18 `read-properties --port` template.
   - Rebuilt templates from the saved real CLI help.
   - Upgraded the command schema to version 2.
   - Confirmed a usage banner is syntax-only and safe for a non-destructive retry.
   - Confirmed the usage banner does not count as communication activity.

3. **Saved evidence and ledger repair**
   - Began with complete P01 identity and two valid matching read files.
   - Removed the saved `readPair` to model the diagnostic state.
   - Reconstructed the pair after strict disk/hash/session/proof checks.
   - Rebuilt completed Read Properties/read-1/read-2 steps.
   - Advanced Guided Setup to `definition`.

Result: **3/3 passed**.

## Full verification

- Source syntax validation: passed.
- Automated test groups: **24/24 passed**.
- Focused workflow and recovery simulations: **39/39 passed**.
- Real CLI recovery simulations: **3/3 passed**.
- Startup-recovery simulations: **3/3 passed**.
- Integrated PCM Hammer simulations: **3/3 passed**.
- COM recovery simulations: **3/3 passed**.
- Closed-loop tuning simulations: **3/3 passed**.
- Autonomous Tune simulations: **3/3 passed**.
- Unified Tune Engine simulations: **3/3 passed**.
- Garage/project simulations: **3/3 passed**.
- Tune-workspace simulations: **3/3 passed**.
- Quality-of-life simulations: **3/3 passed**.
- Connection Doctor simulations: **3/3 passed**.
- Offline P01 Recovery Lab simulations: **3/3 passed**.
- P01 hardware-recovery simulations: **3/3 passed**.

## Destructive-mode boundary

The observed CLI describes `--write` as writing the entire PCM. It does not advertise a separate calibration-only write command. Beta.19 does not silently substitute Full Write for Calibration Write. Test Write is supported. Any future integrated Full Write workflow must have separate capability validation and explicit authorization.

## Protected behavior retained

- Original BIN is never overwritten.
- Two independent full reads are required.
- Each accepted P01 read must be exactly 524,288 bytes.
- Both accepted reads must have identical SHA-256 hashes.
- Exact-OS XDF binding remains required.
- Mapping ambiguity remains blocking.
- Revision/checksum validation remains required.
- Test Write proof remains required.
- Final controller write remains separately authorized.

## Validation boundary

The source and software simulations were verified in the build environment. The release was not run against the user's actual Windows PCM Hammer installation after the fix. A physical OBDLink MX+, COM3, vehicle, P01 PCM, real Read Properties, full reads, Test Write, and any controller write remain unverified until tested on the user's hardware.
