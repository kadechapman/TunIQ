# Security and Safety Reporting

Before a public repository is launched, configure GitHub private vulnerability reporting and replace the placeholder contact information.

Treat these as private, urgent reports:
- A path that bypasses write confirmations, checksum validation, support gates, or beta agreement.
- Unsafe command injection or unrestricted shell execution.
- Leakage of VINs, emails, credentials, raw BINs, user paths, or private logs.
- A reproducible controller corruption or recovery failure.
- Malicious XDF, tune package, PID profile, update, or diagnostic-package handling.

Do not publicly post exploit steps or private vehicle data.
