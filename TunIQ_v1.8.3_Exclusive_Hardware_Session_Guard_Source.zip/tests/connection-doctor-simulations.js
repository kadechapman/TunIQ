const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { ConnectionDoctor } = require('../src/connection-doctor');

function scenarioManager(name) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-doctor-${name}-`));
  const common = {
    dataRoot: () => root,
    releasePort: async () => ({ released: false }),
    getPreferred: () => ({ port: '', baud: 0 }),
    savePreferred: value => value,
    normalizeProbe: value => ({ port: value.port, baud: value.baud, adapter: value.adapter, description: value.description || '', firmware: value.deviceId || '', protocol: value.protocol || '', voltage: value.voltage, vin: value.vin || '', transport: 'Bluetooth Serial' }),
    appendActivity: () => {}
  };
  if (name === 'clean-success') return new ConnectionDoctor({ ...common,
    listDevices: async () => [{ port: 'COM4', name: 'OBDLink MX+ (COM4) Outgoing', manufacturer: 'ScanTool.net', hardwareId: 'BTHENUM\\OBDLINK', transport: 'Bluetooth Serial', recognized: true, recommended: true }],
    probePortLock: async () => ({ available: true, locked: false }),
    probeAdapter: async ({ port, baud }) => ({ port, baud, adapter: 'OBDLink MX+', deviceId: 'STN2255 v5.6.19', protocol: 'ISO 15765-4 CAN', voltage: 13.6, vin: '1GNEK13Z32R123456' })
  });
  if (name === 'locked-port-alternate') return new ConnectionDoctor({ ...common,
    listDevices: async () => [
      { port: 'COM7', name: 'Standard Serial over Bluetooth link (COM7) Incoming', manufacturer: 'Microsoft', hardwareId: 'BTHENUM\\INCOMING', transport: 'Bluetooth Serial' },
      { port: 'COM4', name: 'OBDLink MX+ (COM4) Outgoing', manufacturer: 'ScanTool.net', hardwareId: 'BTHENUM\\OBDLINK', transport: 'Bluetooth Serial', recognized: true, recommended: true }
    ],
    probePortLock: async ({ port }) => port === 'COM7' ? ({ available: false, locked: true, message: 'Access denied because the port is in use.' }) : ({ available: true, locked: false }),
    probeAdapter: async ({ port, baud }) => {
      if (port !== 'COM4') throw new Error('Wrong port.');
      if (baud === 115200) throw new Error('No adapter response at 115200 baud.');
      return { port, baud, adapter: 'OBDLink MX+', deviceId: 'STN2255', protocol: 'ISO 15765-4 CAN', voltage: 13.2 };
    }
  });
  if (name === 'stale-port') return new ConnectionDoctor({ ...common,
    listDevices: async () => [{ port: 'COM9', name: 'Serial Port (COM9)', manufacturer: '', hardwareId: 'STALE', transport: 'Bluetooth Serial' }],
    probePortLock: async () => ({ available: false, locked: true, message: 'The specified port does not exist.' }),
    probeAdapter: async () => { throw new Error('must not probe a missing port'); }
  });
  throw new Error(`Unknown simulation ${name}`);
}

async function run(name) {
  const manager = scenarioManager(name); const report = await manager.run({ port: name === 'locked-port-alternate' ? 'COM7' : '', tryAlternates: true });
  if (name === 'clean-success') { assert.equal(report.status, 'ready'); assert.equal(report.recommendedConnection.port, 'COM4'); }
  if (name === 'locked-port-alternate') { assert.equal(report.status, 'ready'); assert.equal(report.recommendedConnection.port, 'COM4'); assert.equal(report.recommendedConnection.baud, 38400); assert(report.issues.some(item => item.resolvedByAlternate)); }
  if (name === 'stale-port') { assert.equal(report.status, 'blocked'); assert(report.issues.some(item => item.code === 'stale-com-port')); }
  return report;
}

(async () => {
  const requested = process.argv[2]; const names = requested ? [requested] : ['clean-success', 'locked-port-alternate', 'stale-port'];
  const results = [];
  for (const name of names) { const report = await run(name); results.push({ name, status: report.status, recommendedConnection: report.recommendedConnection, issueCodes: report.issues.map(item => item.code), attempts: report.attempts }); console.log(`✓ Connection Doctor simulation: ${name}`); }
  const output = path.join(__dirname, '..', 'test-results', 'connection-doctor-simulations.json'); fs.mkdirSync(path.dirname(output), { recursive: true }); fs.writeFileSync(output, JSON.stringify({ at: new Date().toISOString(), passed: true, results }, null, 2));
})().catch(error => { console.error(error.stack || error); process.exit(1); });
