#!/usr/bin/env node
const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { P01AutoManager } = require('../src/p01-auto');
const { buildCommissioningOnlyXdf } = require('../src/definition-pipeline');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta23-workspace-reconcile-'));
const sha256 = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function setup(name) {
  const folder = path.join(root, name);
  for (const child of ['Originals','Definitions','Reports','Workspace']) fs.mkdirSync(path.join(folder, child), { recursive: true });
  const first = path.join(folder, 'Originals', 'p01_original_read1.bin');
  const second = path.join(folder, 'Originals', 'p01_original_read2.bin');
  const xdf = path.join(folder, 'Definitions', 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x5b));
  fs.copyFileSync(first, second);
  buildCommissioningOnlyXdf(xdf, { os: '9379910', controller: 'P01', binSize: P01_BIN_SIZE, originalSha256: sha256(first) });
  const active = {
    id: `customline-${name}`, name: 'Customline', folder, controller: 'P01', os: '9379910',
    bin: first, binInfo: { path:first, name:path.basename(first), size:P01_BIN_SIZE, sha256:'stale-ui-cache' },
    xdf, xdfInfo: { path:xdf, name:path.basename(xdf), title:'TunIQ Commissioning Only — P01 OS 9379910', sha256:sha256(xdf), tableCount:1, warnings:[], commissioningOnly:true, writableTables:0 }
  };
  return { folder, first, second, xdf, active };
}
function commission(context, workspace) {
  const manager = new P01CommissioningManager({
    getActiveProject: () => context.active,
    getCalibrationWorkspace: () => workspace,
    getFlashStatus: () => ({ configured:true, backend:{ official:true, product:'PCM Hammer', version:'2.0.0', major:2 } }),
    appendActivity: () => {}
  });
  manager.recordIdentity({ controller:'P01', os:'9379910', hardwareId:'4294967295', serviceNumber:'9354896' });
  manager.recordRead(context.first, {}, { id:'read-one', device:'COM3' });
  manager.recordRead(context.second, {}, { id:'read-two', device:'COM3' });
  return manager;
}
function scenarioStaleCanonicalHash() {
  const context = setup('stale-canonical');
  const actualBin = sha256(context.first), actualXdf = sha256(context.xdf);
  const workspace = { mode:'xdf', projectId:context.active.id, sourceBinSha256:actualBin, sourceXdfSha256:actualXdf, binding:{ projectId:context.active.id, binSha256:actualBin, xdfSha256:actualXdf }, mappingSummary:{ loaded:1, writableTables:0, commissioningOnly:true, warnings:[] }, tables:{ identity:{ values:[[91]] } } };
  const manager = commission(context, workspace);
  const state = JSON.parse(fs.readFileSync(manager.file(context.active), 'utf8'));
  state.canonicalReadSha256 = 'deadbeef'.repeat(8);
  fs.writeFileSync(manager.file(context.active), JSON.stringify(state, null, 2));
  const before = manager.status(context.active);
  assert.equal(before.definition.mappingLoaded, true, 'verified read pair and actual protected BIN should repair a stale canonical hash');
  assert.equal(before.definition.mappingLoaded, true);
  const after = manager.reconcileBoundCommissioningDefinition();
  assert.equal(after.definition.confirmedExact, true);
  assert.equal(after.canonicalReadSha256, actualBin);
  return { scenario:'stale-canonical-hash', passed:true, mappingReconciled:true, confirmed:true };
}
function scenarioStaleWorkspaceSourceField() {
  const context = setup('stale-workspace-source');
  const actualBin = sha256(context.first), actualXdf = sha256(context.xdf);
  const workspace = { mode:'xdf', projectId:context.active.id, sourceBinSha256:'old-source-hash', sourceXdfSha256:'old-xdf-hash', binding:{ projectId:context.active.id, binSha256:actualBin, xdfSha256:actualXdf }, mappingSummary:{ loaded:1, writableTables:0, commissioningOnly:true, warnings:[] }, tables:{ identity:{ values:[[91]] } } };
  const manager = commission(context, workspace);
  const status = manager.reconcileBoundCommissioningDefinition();
  assert.equal(status.definition.confirmedExact, true, 'current binding hashes should win over stale legacy source fields');
  return { scenario:'stale-workspace-source-field', passed:true, bindingFallback:true };
}
function scenarioFailedWorkflowRepair() {
  const context = setup('failed-workflow');
  const auto = new P01AutoManager({ getActiveProject:()=>context.active, appendActivity:()=>{}, processInstanceId:'beta23-test' });
  fs.writeFileSync(auto.file(context.active), JSON.stringify({ ...auto.blank(context.active), status:'failed', phase:'failed', nextStep:null, resumePhase:null, progress:48, stop:{ code:'unexpected-error', message:'Load the protected original and XDF in Calibration before confirming the definition.', at:new Date().toISOString() }, blocker:'Load the protected original and XDF in Calibration before confirming the definition.', completedSteps:{ 'read-properties':{}, 'read-1':{}, 'read-2':{} } }, null, 2));
  const state = auto.load(context.active);
  assert.equal(auto.canResume(state), false, 'legacy unexpected-error state demonstrates the beta.23 dead end');
  const repaired = auto.patch({ status:'paused', phase:'stopped-workspace-reconciled', nextStep:'create-revision', resumePhase:'create-revision', progress:73, blocker:'Workspace repaired.', stop:{ code:'workspace-reconciled', message:'workspace repaired', at:new Date().toISOString(), priorPhase:'failed' }, completedSteps:{ ...state.completedSteps, definition:{ at:new Date().toISOString(), evidence:{ commissioningOnly:true } } } });
  assert.equal(auto.canResume(repaired), true);
  assert.equal(auto.resume().phase, 'create-revision');
  return { scenario:'failed-workflow-repair', passed:true, resumePhase:'create-revision' };
}
async function run(options={}) {
  try {
    const reports=[scenarioStaleCanonicalHash(),scenarioStaleWorkspaceSourceField(),scenarioFailedWorkflowRepair()];
    if(!options.quiet) reports.forEach(item=>console.log(`✓ beta.23 workspace reconciliation simulation: ${item.scenario}`));
    const result={ type:'tuniq-workspace-state-reconciliation-simulations', version:'1.7.0-beta.23', generatedAt:new Date().toISOString(), softwareSimulationOnly:true, realHardwareVerified:false, reports };
    const out=path.join(__dirname,'..','test-results'); fs.mkdirSync(out,{recursive:true}); fs.writeFileSync(path.join(out,'workspace-state-reconciliation-simulations.json'),JSON.stringify(result,null,2));
    return result;
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
if(require.main===module) run().then(result=>{console.log(JSON.stringify(result.reports,null,2));console.log('All TunIQ beta.23 Workspace State Reconciliation simulations passed.');}).catch(error=>{console.error(error.stack||error);process.exit(1)});
module.exports={ runWorkspaceStateReconciliationSimulations:run };
