#!/usr/bin/env node
const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { parseXdf } = require('../src/xdf');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { buildCommissioningOnlyXdf, isCommissioningOnlyXdf, scanDefinitionSources } = require('../src/definition-pipeline');
const { TuneWorkspaceManager } = require('../src/tune-workspace');

const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-beta21-p01-completion-'));
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
function makeFolder(name) { const value = path.join(tempRoot, name); fs.mkdirSync(value, { recursive: true }); return value; }

function scenarioCommissioningDefinition() {
  const folder = makeFolder('commissioning-definition');
  const xdf = path.join(folder, 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  const built = buildCommissioningOnlyXdf(xdf, { os: '9379910', binSize: P01_BIN_SIZE, controller: 'P01', originalSha256: 'stock-proof' });
  const parsed = parseXdf(xdf);
  assert.equal(isCommissioningOnlyXdf(xdf), true);
  assert(parsed.title.includes('9379910'));
  assert.equal(parsed.tables.length, 1);
  assert.equal(built.provenance.writableCalibrationTables, 0);
  assert.equal(built.provenance.guessedCalibrationAddresses, false);
  return { scenario: 'commissioning-definition', passed: true, os: built.provenance.os, writableTables: 0, guessedAddresses: false };
}

function scenarioFinishSetupWithoutTuneAuthority() {
  const folder = makeFolder('finish-setup');
  for (const sub of ['Originals', 'Definitions', 'Revisions', 'Reports']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const first = path.join(folder, 'Originals', 'read-1.bin');
  const second = path.join(folder, 'Originals', 'read-2.bin');
  const revision = path.join(folder, 'Revisions', 'commissioning-stock-clone.bin');
  const xdf = path.join(folder, 'Definitions', 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x39));
  fs.copyFileSync(first, second);
  fs.copyFileSync(first, revision);
  buildCommissioningOnlyXdf(xdf, { os: '9379910', binSize: P01_BIN_SIZE, controller: 'P01', originalSha256: hash(first) });
  const active = {
    id: 'customline-p01', name: 'Customline', folder, controller: 'P01', os: '9379910',
    bin: first, binInfo: { path: first, name: path.basename(first), size: P01_BIN_SIZE, sha256: hash(first) },
    xdf, xdfInfo: { path: xdf, name: path.basename(xdf), title: 'TunIQ Commissioning Only — P01 OS 9379910', tableCount: 1, warnings: [], sha256: hash(xdf), commissioningOnly: true, writableTables: 0 }
  };
  const workspace = {
    mode: 'xdf', projectId: active.id, sourceBinSha256: hash(first), sourceXdfSha256: hash(xdf),
    mappingSummary: { loaded: 1, writableTables: 0, commissioningOnly: true, warnings: [] },
    tables: { commissioning_identity: { name: 'Commissioning identity byte (read-only)', unsupportedReason: 'Commissioning-only definition is read-only.', values: [[0x39]] } }
  };
  const manager = new P01CommissioningManager({
    getActiveProject: () => active,
    getCalibrationWorkspace: () => workspace,
    getFlashStatus: () => ({ configured: true, backend: { official: true, product: 'PCM Hammer', version: '2.0.0', major: 2, sha256: 'mock' } }),
    appendActivity: () => {}
  });
  manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: '4294967295', serviceNumber: '9354896' });
  manager.recordRead(first, {}, { id: 'read-a', device: 'COM3' });
  manager.recordRead(second, {}, { id: 'read-b', device: 'COM3' });
  manager.confirmDefinition({ typedOs: '9379910', acknowledged: true });
  manager.recordValidation({ targetFile: revision, targetFileName: path.basename(revision), targetFileSha256: hash(revision), compatible: true, checksumStatus: 'valid-stock-clone' });
  let status = manager.status(active, revision);
  assert.equal(status.dualReadVerified, true);
  assert.equal(status.definition.commissioningOnly, true);
  assert.equal(status.readyForAi, false);
  assert.equal(status.readyForTestWrite, true);
  assert.equal(status.readyForWrite, false);
  assert.equal(manager.assertOperationReady('testWrite', revision).readyForTestWrite, true);
  manager.recordFlashSession({ id: 'tw-stock-clone', operation: 'testWrite', state: 'complete', verified: true, testWritePassed: true, input: revision, device: 'COM3', voltage: 13.6 });
  status = manager.status(active, revision);
  assert(status.testWrite);
  assert.equal(status.readyForWrite, false);
  assert.throws(() => manager.assertOperationReady('writeCalibration', revision), /commissioning-only/i);
  return { scenario: 'finish-setup-without-tune-authority', passed: true, testWriteReady: true, aiTuningLocked: true, pcmWriteLocked: true };
}

function scenarioWritableDefinitionReplacement() {
  const folder = makeFolder('replacement');
  const commissioning = path.join(folder, 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  const writable = path.join(folder, 'Trusted-OS-9379910.xdf');
  buildCommissioningOnlyXdf(commissioning, { os: '9379910', binSize: P01_BIN_SIZE, controller: 'P01' });
  fs.writeFileSync(writable, `<?xml version="1.0"?><XDF><XDFHEADER><deftitle>Trusted writable P01 OS 9379910</deftitle><baseoffset>0</baseoffset></XDFHEADER><XDFCONSTANT uniqueid="idle" title="Idle RPM"><EMBEDDEDDATA mmedaddress="0x20" mmedelementsizebits="16" lsbfirst="1"/><MATH equation="X" units="RPM"/></XDFCONSTANT></XDF>`);
  const scan = scanDefinitionSources({ os: '9379910', roots: [folder], parseXdf, controller: 'P01' });
  assert.equal(scan.xdfs.length, 1);
  assert.equal(scan.xdfs[0].name, path.basename(writable));
  assert.equal(scan.commissioningXdfs.length, 1);
  return { scenario: 'writable-definition-replacement', passed: true, writableCandidates: 1, commissioningCandidates: 1 };
}


function scenarioStaleFingerprintAutoBinding() {
  const folder = makeFolder('stale-fingerprint-auto-binding');
  for (const sub of ['Originals', 'Definitions', 'Workspace']) fs.mkdirSync(path.join(folder, sub), { recursive: true });
  const bin = path.join(folder, 'Originals', 'p01-original.bin');
  const xdf = path.join(folder, 'Definitions', 'TunIQ-Commissioning-Only-OS-9379910.xdf');
  fs.writeFileSync(bin, Buffer.alloc(P01_BIN_SIZE, 0x51));
  buildCommissioningOnlyXdf(xdf, { os: '9379910', binSize: P01_BIN_SIZE, controller: 'P01', originalSha256: hash(bin) });
  const active = {
    id: 'customline-stale-cache', name: 'Customline', folder, controller: 'P01', os: '9379910',
    bin, binInfo: { path: bin, name: path.basename(bin), size: P01_BIN_SIZE, sha256: 'stale-beta21-cache' },
    xdf, xdfInfo: { path: xdf, name: path.basename(xdf), title: 'TunIQ Commissioning Only — P01 OS 9379910', tableCount: 1, warnings: [], sha256: hash(xdf), commissioningOnly: true, writableTables: 0 }
  };
  const workspaceManager = new TuneWorkspaceManager({ appendActivity: () => {} });
  const binding = workspaceManager.binding(active);
  assert.equal(binding.binSha256, hash(bin), 'workspace binding must fingerprint protected bytes, not stale binInfo metadata');
  assert.notEqual(binding.binSha256, active.binInfo.sha256);
  const workspace = {
    mode: 'xdf', projectId: active.id, binding,
    sourceBin: bin, sourceBinSha256: hash(bin), sourceXdf: xdf, sourceXdfSha256: hash(xdf),
    mappingSummary: { loaded: 1, writableTables: 0, commissioningOnly: true, warnings: [] },
    tables: { commissioning_identity: { name: 'Commissioning identity byte', values: [[0x51]], unsupportedReason: 'read-only' } }
  };
  const manager = new P01CommissioningManager({
    getActiveProject: () => active,
    getCalibrationWorkspace: () => workspace,
    getFlashStatus: () => ({ configured: true, backend: { official: true, product: 'PCM Hammer', version: '2.0.0', major: 2 } }),
    appendActivity: () => {}
  });
  manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: '4294967295', serviceNumber: '9354896' });
  const read2 = path.join(folder, 'Originals', 'p01-original-2.bin'); fs.copyFileSync(bin, read2);
  manager.recordRead(bin, {}, { id: 'read-one', device: 'COM3' });
  manager.recordRead(read2, {}, { id: 'read-two', device: 'COM3' });
  const confirmed = manager.confirmDefinition({ typedOs: '9379910', acknowledged: true });
  assert.equal(confirmed.definition.confirmedExact, true);
  assert.equal(confirmed.definition.commissioningOnly, true);
  return { scenario: 'stale-fingerprint-auto-binding', passed: true, staleCacheIgnored: true, manualCalibrationLoadRequired: false };
}

async function runP01SetupCompletionSimulations(options = {}) {
  try {
    const reports = [scenarioCommissioningDefinition(), scenarioFinishSetupWithoutTuneAuthority(), scenarioWritableDefinitionReplacement(), scenarioStaleFingerprintAutoBinding()];
    if (!options.quiet) for (const report of reports) console.log(`✓ beta.23 P01 setup completion simulation: ${report.scenario}`);
    const result = { type: 'tuniq-p01-setup-completion-simulations', version: '1.7.0-beta.23', generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false, reports };
    const out = path.join(__dirname, '..', 'test-results'); fs.mkdirSync(out, { recursive: true });
    fs.writeFileSync(path.join(out, 'p01-setup-completion-simulations.json'), JSON.stringify(result, null, 2));
    return result;
  } finally { fs.rmSync(tempRoot, { recursive: true, force: true }); }
}

if (require.main === module) runP01SetupCompletionSimulations().then(result => { console.log(JSON.stringify(result.reports, null, 2)); console.log('All TunIQ beta.23 Automatic Commissioning Definition Binding simulations passed.'); }).catch(error => { console.error(error.stack || error); process.exit(1); });
module.exports = { runP01SetupCompletionSimulations };
