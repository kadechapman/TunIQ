const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { P01LabManager } = require('../src/p01-lab');

const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-p01-offline-lab-'));
const report = new P01LabManager({ dataRoot: () => root, appendActivity: () => {} }).runAll();
assert.equal(report.passed, true);
assert.equal(report.scenarios.length, 3);
assert(report.scenarios.every(item => item.passed));
const summary = { ...report, scenarios: report.scenarios.map(item => ({ scenario: item.scenario, passed: item.passed, steps: item.steps.map(step => ({ id: step.id, status: step.status, message: step.message })) })) };
const output = path.join(__dirname, '..', 'test-results', 'p01-offline-lab.json'); fs.mkdirSync(path.dirname(output), { recursive: true }); fs.writeFileSync(output, JSON.stringify(summary, null, 2));
console.log('✓ Offline P01 Recovery Lab: all three scenarios passed');
