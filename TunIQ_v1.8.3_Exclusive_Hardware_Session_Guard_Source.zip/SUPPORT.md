# TunIQ Public Beta Support

Start with the in-app Public Beta Center:
1. Confirm the compatibility label.
2. Create a privacy-safe diagnostic package.
3. Record exact reproduction steps.
4. Report the issue through the official GitHub issue form after the repository is created.

Do not rely on chat or community posts for emergency controller recovery. Use the recovery instructions and tools published for the exact verified controller/interface combination.
