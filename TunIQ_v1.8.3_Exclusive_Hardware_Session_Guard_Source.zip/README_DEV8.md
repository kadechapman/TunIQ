# TunIQ v1.2.2-dev.8 — Crash Recovery Hotfix

This build addresses the immediate-close/startup crash reported after dev.7.

## Changes

- Calibration data is no longer loaded during the main application startup.
- Calibration Lab initializes only when the user opens it.
- Invalid or excessively large workspace JSON is moved to a timestamped recovery backup instead of terminating the app.
- XDF row/column counts and total hydrated cells are bounded to prevent malformed definitions from exhausting memory.
- Electron runtime/cache data is isolated under `%APPDATA%\TunIQ\Runtime`.
- Added startup-stage logging at `%APPDATA%\TunIQ\Logs\startup.log`.
- Added renderer crash logging and a one-time window recovery attempt.
- Scoped navigation selectors so Calibration Lab buttons cannot be treated as main navigation buttons.
- Electron is pinned to version 37.2.3 instead of floating to a newer 37.x release.
- Added `RECOVER_TUNIQ_STARTUP.bat` as a manual fallback. It preserves projects, vehicles, BINs, and XDF files.

## Run

Extract the complete ZIP into a new local folder and run `INSTALL_AND_RUN_WINDOWS.bat` once.
