# OBDLink Phone Logs in TunIQ

TunIQ beta.2 supports a phone-first logging workflow for users who cannot carry a Windows PC in the vehicle.

## Recommended workflow

1. Pair the OBDLink MX+ with the phone and open the OBDLink app.
2. Select the PIDs needed for the test.
3. Use the app's fastest practical CSV logging mode, **Trigger on PID frame**, when available.
4. Record the drive safely. Do not interact with the phone while driving.
5. In OBDLink, open the saved log and use Share/Export to save the CSV.
6. Either:
   - move the CSV to the Windows PC and select **Live Log → Import OBDLink Phone Log**, or
   - open the TunIQ GitHub Pages importer on the phone, process the CSV locally, and download a `.tuniqlog` package for the desktop app.

## Privacy behavior

The importer removes columns that appear to contain VIN, latitude, longitude, GPS/location, email, Bluetooth/device identifiers, or serial numbers. The website importer performs this work in the browser and does not include a server upload implementation.

Always review a file before posting it publicly. A vendor-specific column name may not match TunIQ's automatic redaction rules.

## Data quality

TunIQ reports:

- sample count and duration
- approximate sampling rate
- recognized channels
- missing channels
- conversion warnings
- privacy columns removed

The AI only analyzes channels present in the file. A fuel or power analysis may require appropriate airflow, trim, commanded-fuel, and wideband data. Standard OBD-II logs cannot provide every enhanced controller value.

## Supported formats

- OBDLink-style `.csv`
- delimited `.txt` or `.log`
- TunIQ website `.tuniqlog` JSON packages

The desktop importer normalizes common units such as km/h to mph and Celsius to Fahrenheit while preserving the imported source metadata.
