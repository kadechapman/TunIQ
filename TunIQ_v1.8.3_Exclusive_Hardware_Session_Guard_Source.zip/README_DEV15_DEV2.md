# TunIQ 1.5 dev.2 implementation notes

## Added

- Cascading Full AI engine selector: family, displacement, engine code/model.
- Engine catalog and legacy free-text migration.
- Custom engine fallback.
- Optional spec status and Use Saved Specs helper.
- Unknown gear ratio, tire size, converter stall, and desired idle remain blank and do not block planning.
- Structured engine fields saved into each project AI intake.
- Plan metadata records which optional details are known and unknown.

## Safety behavior

- No factory specification is silently assumed.
- Saved Garage/project notes are used only when an explicit value is found.
- Calibration editing and controller writing remain approval-gated.
