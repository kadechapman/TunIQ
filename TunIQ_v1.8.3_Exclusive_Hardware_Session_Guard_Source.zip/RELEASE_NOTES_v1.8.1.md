# TunIQ v1.8.1 — PCM Hammer COM Failover Hotfix

## Release focus

Version 1.8.1 is a focused runtime recovery patch for the integrated PCM Hammer Test Write path. It preserves the complete 1.8 Dashboard & Quality-of-Life redesign and the beta.26 P01 continuity lock.

## Fixed

- Recognizes real PCM Hammer port-open failures that do not use the exact old timeout wording.
- Prevents a failed “Opening COM3” line from falsely blocking safe failover.
- Retries COM3 once after clearing TunIQ and PowerShell serial ownership.
- Rescans Windows devices after the bounded retry.
- Detects generic Bluetooth serial siblings such as COM4.
- Uses PnP parent/container metadata and Bluetooth direction hints when available.
- Retains previously discovered ports when a later Windows scan fails temporarily.
- Chooses the best untried outgoing/Bluetooth/OBDLink candidate.
- Captures separate stdout and stderr logs for every attempt.
- Shows tested and candidate ports in Guided P01 recovery details.

## Preserved

- Tachometer-Q logo and accelerated-needle startup.
- Eight main workspaces and contextual navigation.
- Dashboard command center and quality-of-life settings.
- Existing `%AppData%\TunIQ` data path and Customline project.
- Immutable verified read pair and protected original.
- Deterministic unchanged commissioning stock clone.
- Read-only OS 9379910 definition and tuning/write locks.
- Test Write-only commissioning completion.

## Hardware boundary

This release is software- and simulation-verified. It does not claim that the physical Customline P01 Test Write passed. That result must come from the user's OBDLink MX+, Windows Bluetooth COM ports, PCM Hammer installation, vehicle power, and PCM.
