# P01 Test Write Runtime Recovery

## Diagnostic basis

The beta.24 diagnostic showed that all commissioning prerequisites were complete and the unchanged stock clone was valid. PCM Hammer was launched with the correct real CLI syntax, but Test Write exited before PCM communication because:

1. the CLI defaulted its kernel search to the TunIQ project directory; and
2. Windows did not open COM3 before the CLI timeout expired.

## Kernel resolution

TunIQ searches only the configured PCM Hammer installation tree and nearby portable-layout folders. It accepts a folder only when it contains one or more files named `Kernel-*.bin` or `Loader-*.bin`.

For operations that need kernels, TunIQ adds:

```text
--kernel-dir <verified PCM Hammer kernel folder>
```

If the complete portable package is missing, the operation stops before launch with `kernel-files-missing` instead of allowing a misleading generic PCM Hammer failure.

## COM recovery

For non-destructive operations only—Read Properties, Read Entire PCM, and Test Write—TunIQ may recover before any PCM communication begins:

- release its own OBD/serial session;
- terminate stale TunIQ bridge requests;
- wait for Windows to release the handle;
- retry the selected port once;
- inspect Windows adapter ranking and PCM Hammer `--list-devices`;
- try recognized outgoing OBDLink alternatives.

The selected port is saved only after a successful operation. The operation never loops indefinitely.

## Safety boundary

Calibration Write, Full Write, and Recovery do not automatically switch devices. The beta.25 recovery is designed to finish the commissioning Test Write without making permanent PCM changes.
