# TunIQ v1.8.3 — Exclusive Hardware Session Guard & Project Safety Vault

TunIQ 1.8.3 is a hardware-session safety update for the **1.8 Dashboard & Quality of Life** release.

It preserves the complete P01 continuity lock, COM3/COM4 failover, and Hardware Session Doctor, then adds two major protections:

1. An Exclusive Hardware Session Guard that identifies competing OBD, PCM Hammer, logger, and serial-terminal processes before PCM Hammer starts.
2. A Project Safety Vault that creates and verifies a complete SHA-256 project snapshot before Test Write or any write-related operation.

The update also distinguishes explicit 1x/4x vehicle-network interference from an ordinary COM-port failure. TunIQ does not invent an unsupported PCM Hammer CLI speed flag; it preserves the log and provides an assisted normal-PCM-Hammer recovery instruction.

Existing `%AppData%\TunIQ` projects, protected originals, verified read pairs, Garage data, definitions, revisions, and logs are preserved. Guided P01 commissioning still performs Test Write only and never authorizes an automatic real PCM write.

See `RELEASE_NOTES_v1.8.3.md`, `HARDWARE_SESSION_GUARD.md`, `PROJECT_SAFETY_VAULT.md`, and `TEST_REPORT_v1.8.3.md`.
