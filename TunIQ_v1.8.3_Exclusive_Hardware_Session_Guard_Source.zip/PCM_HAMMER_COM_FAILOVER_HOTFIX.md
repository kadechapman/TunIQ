# PCM Hammer COM Failover Hotfix

## Failure addressed

TunIQ 1.8.0 correctly recovered the Customline project's verified P01 commissioning evidence and advanced directly to Test Write, but the real hardware attempt stopped on COM3 with `pcmhammer-failed`. The old recovery detector depended too heavily on one exact timeout phrase and could treat PCM Hammer's initial “Opening serial port COM3” line as proof that communication had already begun.

Windows also commonly names both OBDLink Bluetooth SPP ports only as **Standard Serial over Bluetooth link**, without identifying which one is the outgoing client port. The earlier ranking system could reject the generic COM4 sibling because it did not contain the words OBDLink or Outgoing.

## Runtime changes

- Broad port-open failure recognition covers timeout, unable-to-open, failed-to-open, missing-port, unavailable-port, access-denied, busy, and related PCM Hammer wording.
- An “Opening serial port” line followed immediately by an open failure is not treated as PCM communication.
- TunIQ aborts known PowerShell serial bridge children before and after releasing its persistent OBD session.
- Windows receives a bounded settle period before PCM Hammer opens the port.
- The selected port is retried exactly once.
- After the retry, TunIQ performs a fresh Windows and PCM Hammer device scan.
- Generic Bluetooth siblings are eligible even when Windows does not expose OBDLink branding.
- PnP parent/container metadata is collected when available to rank ports belonging to the same Bluetooth device.
- `[System.IO.Ports.SerialPort]::GetPortNames()` provides an additional Windows inventory fallback.
- The best untried outgoing/Bluetooth/recognized candidate is selected automatically.
- Every PCM Hammer attempt records its device, source, exit code, open-failure classification, and separate exact stdout/stderr log files.
- The Guided P01 stopped screen reports tested ports and candidate ports instead of only the last port.

## Safety boundary

The automatic failover is limited to Read Properties, full read, and Test Write. It does not authorize or start a real PCM write. Existing protected-original, read-pair, stock-clone, voltage, kernel, definition, and commissioning locks remain unchanged.
