# TunIQ v1.8.0 — Dashboard & Quality of Life

## Release focus

Version 1.8.0 delivers the planned dashboard, branding, loading-screen, navigation, and general quality-of-life redesign while retaining the complete beta.26 P01 commissioning-continuity system.

## New identity and startup

- Replaced the plain Q mark with a custom tachometer-Q logo.
- The dial includes 0, 40, 80, 120, and 160 markings.
- The Q tail doubles as the tach needle.
- Startup accelerates the needle across the dial instead of showing a separate progress bar.
- The same identity is used on startup, in the header, on the Dashboard, and in first-run setup.
- Preserved the requested dark gray/black translucent interface with mint-green accents.

## Consolidated navigation

The permanent sidebar is reduced from eighteen entries to eight main workspaces:

1. Dashboard
2. Garage
3. Projects
4. Tune Center
5. Live Data
6. AI Studio
7. Library
8. Settings

Related tools remain available through contextual workspace navigation:

- **Projects:** Project setup, Project Files, History
- **Tune Center:** Flash, Calibration, Patches, Device Manager
- **AI Studio:** AI Studio, AI Coach
- **Library:** Tune Library, Community
- **Settings:** Settings, Tool Setup, Diagnostics, Release Center

Opening a contextual child tool keeps its parent sidebar workspace highlighted, preventing the interface from feeling like unrelated pages stitched together.

## Dashboard command center

- Rebuilt the Dashboard around the active project and next guided action.
- Added six consolidated command cards for Project, Tune Center, Live Data, AI Studio, Library, and System.
- Kept project readiness, controller, vehicle, BIN/XDF state, system status, and recent work visible without switching pages.
- Retained Quick Switch, Back/Forward navigation, project switching, scroll restoration, compact density, reduced motion, and collapsible sidebar preferences.

## Retained P01 continuity and safety

- One primary Guided P01 action: **Continue / Finish P01 Setup**.
- Existing verified reads are recovered from disk and remain continuity-locked.
- Failed, partial, or unnecessary extra reads cannot replace commissioning evidence.
- Deterministic stock-clone reuse prevents duplicate commissioning revisions.
- PCM Hammer Test Write retains kernel-directory recovery, COM release, COM3 retry, and outgoing OBDLink port fallback.
- Read-only OS 9379910 commissioning definitions continue to block tuning and real controller writing.
- No physical Customline Test Write success is claimed by this source package.
