# TunIQ 1.8 Workspace Quality of Life

## Eight main workspaces

- Dashboard
- Garage
- Projects
- Tune Center
- Live Data
- AI Studio
- Library
- Settings

Project Files, History, Calibration, Patches, Device Manager, AI Coach, Community, Tool Setup, Diagnostics, and Release Center are available through the contextual bar inside their parent workspace. A contextual child page keeps the correct parent highlighted in the main sidebar.

## Branding and startup

TunIQ 1.8 uses the tachometer-Q identity across the splash screen, header, Dashboard, and first-run wizard. The Q tail acts as the tach needle, the dial is numbered 0–160, and the splash needle accelerates instead of using a separate loading bar.

## Shortcuts

- `Ctrl+K`: Open Quick Switch
- `Ctrl+B`: Collapse or expand the sidebar
- `Alt+Left`: Previous TunIQ page
- `Alt+Right`: Next TunIQ page
- `Escape`: Close Quick Switch
- `Up` / `Down` / `Enter`: Navigate and run a Quick Switch result

## Restored workspace state

TunIQ stores UI preferences inside `AppData\TunIQ\Settings\settings.json`. It remembers the last page, recent pages, per-page scroll positions, sidebar state, Tune Path state, compact density, and reduced-motion preference.
