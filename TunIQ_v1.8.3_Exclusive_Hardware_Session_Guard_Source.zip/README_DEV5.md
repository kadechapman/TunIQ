# TunIQ v1.2.2-dev.5

Built directly from the v1.2.2-dev.4 crash-fix source.

## Added in dev.5
- Application data now uses `%APPDATA%\TunIQ`.
- One-time, non-destructive migration copies missing data from the old `Documents\TunIQ` location.
- Calibration Lab now has persistent editable tables for spark, VE, idle airflow, fans, fuel, transmission, and engine/speed limits.
- Multi-cell selection using Shift-click.
- Add, subtract, multiply, and percentage operations.
- Copy/paste, undo/redo, stock comparison highlighting, safety range validation, and saved revision snapshots.

## Run on Windows
1. Extract the ZIP to a normal local folder such as `C:\TunIQ-dev5` (avoid running inside OneDrive).
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Existing dev.4 data is migrated automatically on first launch.

This remains a development build. Calibration tables are a safe local workspace and are not yet mapped to real BIN addresses.
