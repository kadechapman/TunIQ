# TunIQ v1.7.0-beta.1 — Public Beta Foundation

This release adds the product and privacy foundation needed before TunIQ can be shared with outside testers.

## Added
- Public Beta Center with Verified / Experimental / Unsupported compatibility labels.
- Beta agreement gate before controller operations.
- Beginner View blocks Experimental controller writes.
- Advanced testers may explicitly enable Experimental hardware writes; all existing checksum, power, revision, and typed-confirmation gates remain active.
- Optional post-log outcome questionnaire.
- Local, opt-in improvement queue. Nothing uploads automatically.
- Optional sanitized sensor-row inclusion.
- VIN, email, user-folder, credential, GPS/location, and absolute-time redaction.
- Compressed `.tuniqreport` diagnostic packages.
- Compressed `.tuniqfeedback` improvement packages.
- Queue deletion and beta-consent reset controls.
- Secure HTTPS endpoint support when a future TunIQ server is configured.
- Electron updater foundation for packaged installer builds.
- Electron Builder NSIS installer configuration.
- Windows installer batch file.
- GitHub Actions Windows build/release workflow.
- Draft privacy, beta agreement, release checklist, and license-decision documents.

## Compatibility policy
The built-in virtual adapter is Verified for software testing only. Real OBDLink logging and P01/P59 PCM Hammer workflows remain Experimental until real bench/vehicle test evidence is recorded for exact combinations.

## Important release blockers
This build does not include an official hosted server, final legal documents, code-signing certificate, public update URL, or selected open-source license. Those require owner accounts, credentials, infrastructure, and deliberate legal/business decisions.
