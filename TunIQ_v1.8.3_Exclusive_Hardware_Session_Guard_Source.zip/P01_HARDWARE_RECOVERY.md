# P01 Hardware Recovery — v1.7.0-beta.7

## What changed

### PCM Hammer 2.x integration

TunIQ probes the installed executable, parses its version/help output, and derives supported operation templates from that exact build. The identity step is **Read Properties**; no `identify` command is required. Real-format output parsing supports OSID, Hardware ID, service number, controller/description, VIN, and voltage.

### Serial-port handoff

TunIQ releases its OBD session before spawning PCM Hammer, waits for the release, and performs an open/close lock probe that sends no vehicle commands. A locked port stops once with instructions to close the program using the adapter.

### Assisted normal-app fallback

When a CLI operation is unavailable or cannot be automated safely, TunIQ creates an assisted-import folder, provides exact normal-app instructions, optionally launches PCM Hammer, watches for new evidence, and imports:

- Read Properties `.txt`/`.log` output;
- full-read `.bin` files;
- Test Write `.txt`/`.log` output.

### Strict read proof

- Required size: 524,288 bytes.
- Required count: exactly two independent successful reads.
- Required comparison: matching SHA-256 hashes.
- Rejected: missing, partial, oversized, failed, mismatched, or unproven reads.
- Rejected files are quarantined instead of becoming the protected original.
- A mismatch requires a new pair; there is no third-read majority.

### Durable recovery ledger

The setup ledger records completed steps and the active step. On restart, TunIQ resumes at the exact unfinished step. Stops are durable and named, including adapter lock, disconnect, app restart during a step, partial read, read mismatch, repeated block-read failure, missing proof, or unsupported CLI operation.

## Safety boundary

This build has not been verified on real hardware. Software simulation cannot validate adapter drivers, cable quality, vehicle wiring, real battery voltage under load, PCM condition, or flash recovery behavior.
