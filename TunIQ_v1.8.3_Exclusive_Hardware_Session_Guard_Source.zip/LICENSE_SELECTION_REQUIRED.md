# License decision required

TunIQ is currently marked `UNLICENSED`. That protects the source from accidental redistribution but is not compatible with a true public open-source launch.

Before publishing the repository, the owner should deliberately choose a license after deciding:
- Whether commercial use is allowed.
- Whether modified versions must remain open source.
- Whether companies may sell TunIQ-based products.
- How third-party tuning definitions and binaries are handled.
- Whether contributors must sign a contributor agreement.

Common options to discuss with a qualified advisor include MIT/Apache-2.0 for permissive use or GPL/AGPL families for stronger share-alike requirements. No license has been selected automatically in this build.
