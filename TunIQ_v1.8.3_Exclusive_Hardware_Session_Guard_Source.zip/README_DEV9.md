# TunIQ v1.2.2-dev.9 — Bridge and Project Stability Pass

This build fixes the issues reported after dev.8 and includes a broader workflow audit.

## Fixed

- No-active-project startup no longer throws an Electron IPC error.
- Tune File Manager now shows a normal empty state until a project is created or activated.
- Saved tool paths are validated at startup instead of being shown as installed when the executable was moved or deleted.
- Bridge launch failures clear stale paths and return a useful Scan/Browse message.
- Added a Verify button for PCM Hammer, TunerPro, and Universal Patcher.
- Deep Scan now checks common install locations and bounded searches in Downloads, Desktop, and LocalAppData.
- External-program launch waits for Windows to confirm the process was spawned before reporting success.
- Project BIN/XDF metadata is now stored in each project manifest, so switching projects does not lose file associations.
- Existing project folders can recover their original BIN and XDF association when older manifests do not contain it.
- New projects include Originals, Definitions, Revisions, Logs, and Backups folders.
- Imported files are deduplicated without overwriting a different protected original.
- Calibration workspaces are tied to the active project and exact BIN/XDF pair.
- Export is blocked if the active project, original BIN, or XDF changed after the workspace was loaded.
- Revision export writes only cells marked modified, preserving every untouched BIN byte.
- Reset Stock restores the imported XDF values instead of replacing a real mapping with practice tables.
- Shift-click selection no longer gets cleared by the input focus event.
- Project switches and new imports visibly invalidate stale Calibration Lab state.
- Additional malformed-workspace size, table, rectangular-grid, label-count, row, and numeric validation was added.
- Calibration workspaces that fail validation are quarantined to a timestamped recovery file instead of breaking the Lab.
- PCM Hammer download now points to the current project release page.
- When an older project manifest is missing file associations, TunIQ recovers the newest matching BIN/XDF in the protected folders.
- Installer checks Node.js version and available disk space before unpacking Electron.

## Run

Extract the ZIP into a new folder. Run `INSTALL_AND_RUN_WINDOWS.bat` once, then use `START_TUNIQ_WINDOWS.bat` afterward.

TunIQ data remains in `%APPDATA%\TunIQ` and is not removed by changing source folders.
