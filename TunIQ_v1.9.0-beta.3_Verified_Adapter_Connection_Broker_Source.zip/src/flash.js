const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');
const {
  P01_BIN_SIZE, OPERATIONS, normalizeOperation, tokenizeTemplate, expandTemplate, parseProgress,
  parseIdentityText, parseBackendIdentity, inferTemplates, classifyPcmHammerResult,
  validateP01ReadFile, assistedInstructions, sha256File, clean
} = require('./pcmhammer');
const { IntelligentConnectionManager } = require('./intelligent-connection-manager');
const {
  profilesForOperation, profileCapabilities, profileMatchingTemplate, isRecognizedPcmHammerExecutable,
  safeToRetryProfile, isPortOpenFailure, hasCommunicationActivity, looksLikeCliUsageOnly
} = require('./pcmhammer-integrated');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function safeName(value) { return String(value || 'PCM').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'PCM'; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function hardwareSettle(ms) { return process.platform === 'win32' ? ms : Math.min(ms, 25); }
function uniqueFiles(files = []) { return [...new Set(files.filter(Boolean).map(file => path.resolve(String(file))))]; }
function fileFingerprint(file) {
  try { const stat = fs.statSync(file); return `${path.resolve(file)}:${stat.size}:${stat.mtimeMs}`; } catch { return path.resolve(String(file)); }
}

function isKernelFileName(name = '') { return /^(?:Kernel|Loader)-.+\.bin$/i.test(String(name)); }
function kernelFilesInFolder(folder) {
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && isKernelFileName(entry.name))
      .map(entry => path.join(folder, entry.name));
  } catch { return []; }
}
function findKernelFolders(root, maxDepth = 4, maxFolders = 800) {
  if (!root) return [];
  const found = []; const seen = new Set(); const queue = [{ folder: path.resolve(root), depth: 0 }];
  while (queue.length && seen.size < maxFolders) {
    const item = queue.shift();
    if (!item || seen.has(item.folder)) continue;
    seen.add(item.folder);
    const kernels = kernelFilesInFolder(item.folder);
    if (kernels.length) found.push({ folder: item.folder, files: kernels });
    if (item.depth >= maxDepth) continue;
    let entries = [];
    try { entries = fs.readdirSync(item.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      if (!entry.isDirectory() || entry.isSymbolicLink()) continue;
      if (/^(?:node_modules|dist|logs?|projects?|revisions?|originals?|reports?)$/i.test(entry.name)) continue;
      queue.push({ folder: path.join(item.folder, entry.name), depth: item.depth + 1 });
    }
  }
  return found;
}
function portOpenTimedOut(text = '') {
  return /(?:could\s+not\s+open\s+the\s+selected\s+device[^\n]*timed\s+out|timed\s+out\s+trying\s+to\s+open\s+(?:serial\s+)?port)/i.test(String(text || ''));
}
function kernelFilesMissing(text = '') {
  return /(?:no\s+\.bin\s+kernel\s+files\s+found|kernel\s+directory[^\n]*(?:missing|not\s+found|empty))/i.test(String(text || ''));
}

class FlashStopError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'FlashStopError'; this.code = code; this.details = details; }
}

class FlashManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.getToolPath = options.getToolPath;
    this.getDeviceStatus = options.getDeviceStatus || (() => ({}));
    this.releasePort = options.releasePort || (async () => ({ released: false }));
    this.probePortLock = options.probePortLock || (async () => ({ available: true, locked: false, supported: false }));
    this.findAlternatePorts = options.findAlternatePorts || (async () => []);
    this.abortBridgeRequests = options.abortBridgeRequests || (() => ({ aborted: 0 }));
    this.appendActivity = options.appendActivity || (() => {});
    this.emit = options.emit || (() => {});
    this.onReadComplete = options.onReadComplete || (() => {});
    this.onIdentifyComplete = options.onIdentifyComplete || (() => {});
    this.onSessionComplete = options.onSessionComplete || (() => {});
    this.inspectExclusiveSession = options.inspectExclusiveSession || (async () => ({ blocked: false, conflicts: [], warnings: [] }));
    this.createSafetySnapshot = options.createSafetySnapshot || (async reason => ({ verified: true, reused: true, reason, path: '', source: 'no-snapshot-provider' }));
    this.registerOwnedProcess = options.registerOwnedProcess || (() => null);
    this.releaseOwnedProcess = options.releaseOwnedProcess || (() => false);
    this.connectionManagerRequired = Boolean(options.connectionManager);
    this.connectionManager = options.connectionManager || new IntelligentConnectionManager({ dataRoot: this.dataRoot, listDevices: async () => [], probePort: details => this.probePortLock(details), appendActivity: this.appendActivity });
    this.session = null;
    this.history = null;
    this.assistedWatchers = new Map();
    this.portOwner = { owner: 'idle', port: '', operation: '', leaseId: '', since: null };
  }

  configFile() { return path.join(this.dataRoot(), 'Tools', 'pcmhammer-cli.json'); }
  sessionsRoot() { return ensureDir(path.join(this.dataRoot(), 'Logs', 'Flash')); }
  historyFile() { return path.join(this.sessionsRoot(), 'history.json'); }
  assistedStateFile(active = this.getActiveProject()) { return active?.folder ? path.join(active.folder, 'Reports', 'p01-assisted-pcmhammer.json') : null; }
  assistedFolder(active = this.getActiveProject()) { return active?.folder ? ensureDir(path.join(active.folder, 'Imports', 'PCM-Hammer-Assisted')) : null; }
  getHistory() { if (!Array.isArray(this.history)) this.history = readJson(this.historyFile(), []); return Array.isArray(this.history) ? this.history : []; }
  recordHistory(session) {
    const summary = { ...session, child: undefined, log: Array.isArray(session.log) ? session.log.slice(-120) : [] };
    const history = this.getHistory(); history.unshift(summary); if (history.length > 150) history.length = 150;
    this.history = history; writeJson(this.historyFile(), history); return summary;
  }
  getConfig() {
    const fallback = {
      executable: '', prefixArgs: [], device: '', mode: 'auto', probedAt: null, helpText: '',
      integratedProfileId: '', integrationMode: 'unprobed', profileAttempts: [],
      lastSuccessfulDevice: '', lastSuccessfulAt: null, lastSuccessfulOperation: '', lastSuccessfulProfileId: '',
      lastDeviceCandidates: [], lastDeviceDiscoveryAt: null,
      templates: { readProperties: null, read: null, testWrite: null, writeCalibration: null, writeFull: null, recovery: null }
    };
    const config = readJson(this.configFile(), fallback) || fallback;
    if (!config.templates?.readProperties && config.templates?.identify) config.templates.readProperties = config.templates.identify;
    delete config.templates?.identify;
    const normalized = { ...fallback, ...config, templates: { ...fallback.templates, ...(config.templates || {}) } };
    const inferred = inferTemplates(normalized.helpText || '');
    let repaired = false;
    for (const operation of Object.keys(OPERATIONS)) {
      if (!inferred[operation]) continue;
      if (JSON.stringify(normalized.templates[operation]) !== JSON.stringify(inferred[operation])) {
        normalized.templates[operation] = inferred[operation]; repaired = true;
      }
    }
    if (repaired || Number(normalized.commandSchemaVersion || 0) < 2) {
      normalized.commandSchemaVersion = 2;
      if (Object.values(inferred).some(Boolean)) normalized.integrationMode = 'help-driven';
      normalized.commandRepair = repaired ? { at: new Date().toISOString(), source: 'saved-cli-help', message: 'PCM Hammer command templates were rebuilt from the installed CLI usage text.' } : normalized.commandRepair || null;
      try { writeJson(this.configFile(), normalized); } catch {}
    }
    return normalized;
  }
  saveConfig(patch = {}) {
    const current = this.getConfig();
    const next = { ...current, ...patch, templates: { ...current.templates, ...(patch.templates || {}) }, updatedAt: new Date().toISOString() };
    delete next.templates.identify;
    writeJson(this.configFile(), next);
    return next;
  }

  resolveExecutable() {
    const config = this.getConfig();
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const candidates = [];
    if (config.executable) candidates.push(config.executable);
    if (toolPath) {
      const folder = path.extname(toolPath) ? path.dirname(toolPath) : toolPath;
      candidates.push(toolPath);
      for (const name of ['PcmHammerCLI.exe', 'PCM Hammer CLI.exe', 'pcmhammer-cli.exe', 'PcmHammer.Console.exe', 'PcmHammerCLI']) candidates.push(path.join(folder, name));
    }
    for (const candidate of candidates) {
      try {
        if (fs.statSync(candidate).isFile() && /(?:cli|console)/i.test(path.basename(candidate))) return { executable: candidate, prefixArgs: Array.isArray(config.prefixArgs) ? config.prefixArgs : [] };
      } catch {}
    }
    return null;
  }
  resolveGuiExecutable() {
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const config = this.getConfig();
    const candidates = [];
    const addFolder = folder => {
      if (!folder) return;
      for (const name of ['PcmHammer.exe', 'PCM Hammer.exe', 'pcmhammer.exe']) candidates.push(path.join(folder, name));
    };
    if (config.guiExecutable) candidates.push(config.guiExecutable);
    for (const source of [toolPath, config.executable]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      if (!/(?:cli|console)/i.test(path.basename(source))) candidates.push(source);
      addFolder(folder);
      addFolder(path.dirname(folder)); // Portable releases commonly place Cli\ beside PcmHammer.exe.
      addFolder(path.join(folder, '..', 'PcmHammer'));
      addFolder(path.join(folder, '..', 'GUI'));
    }
    for (const candidate of [...new Set(candidates.map(item => path.resolve(item)))]) {
      try { if (fs.statSync(candidate).isFile() && !/(?:cli|console)/i.test(path.basename(candidate))) return candidate; } catch {}
    }
    return null;
  }

  saveGuiExecutable(executable) {
    if (!executable) return this.saveConfig({ guiExecutable: null });
    const resolved = path.resolve(String(executable));
    if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile() || /(?:cli|console)/i.test(path.basename(resolved))) {
      throw new FlashStopError('gui-invalid', 'Select the normal PcmHammer.exe application, not a CLI or console executable.');
    }
    return this.saveConfig({ guiExecutable: resolved });
  }

  resolveKernelDirectory(executableOverride = '') {
    const config = this.getConfig();
    const resolved = executableOverride ? { executable: executableOverride } : this.resolveExecutable();
    const executable = resolved?.executable || config.executable || '';
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const gui = this.resolveGuiExecutable();
    const roots = [];
    const add = (folder, source, priority = 0) => {
      if (!folder) return;
      const resolvedFolder = path.resolve(String(folder));
      if (!roots.some(item => item.folder === resolvedFolder)) roots.push({ folder: resolvedFolder, source, priority });
    };
    add(config.kernelDir, 'configured', 500);
    for (const source of [executable, toolPath, gui]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      add(folder, 'tool-folder', 260);
      add(path.join(folder, 'Kernels'), 'kernels-subfolder', 420);
      add(path.join(folder, 'Kernel'), 'kernel-subfolder', 400);
      if (/(?:cli|console|bin)$/i.test(path.basename(folder))) {
        add(path.dirname(folder), 'tool-parent', 300);
        add(path.join(path.dirname(folder), 'Kernels'), 'parent-kernels', 450);
        add(path.join(path.dirname(folder), 'Kernel'), 'parent-kernel', 430);
      }
    }
    const results = [];
    for (const root of roots) {
      const direct = kernelFilesInFolder(root.folder);
      if (direct.length) results.push({ folder: root.folder, files: direct, source: root.source, score: root.priority + direct.length });
      if (!fs.existsSync(root.folder)) continue;
      for (const found of findKernelFolders(root.folder, root.priority >= 400 ? 1 : 3)) {
        const nameBonus = /kernels?/i.test(path.basename(found.folder)) ? 80 : 0;
        const distancePenalty = Math.max(0, found.folder.split(path.sep).length - root.folder.split(path.sep).length) * 8;
        results.push({ ...found, source: root.source, score: root.priority + nameBonus + found.files.length - distancePenalty });
      }
    }
    const best = results
      .filter(item => item.files.length > 0)
      .sort((a, b) => b.score - a.score || b.files.length - a.files.length || a.folder.localeCompare(b.folder))[0] || null;
    return best ? { folder: best.folder, files: uniqueFiles(best.files), source: best.source, fileCount: best.files.length } : null;
  }

  async discoverCliDevices() {
    const resolved = this.resolveExecutable();
    if (!resolved) return [];
    try {
      const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, '--list-devices'], 10000);
      if (Number(result.code) !== 0) return [];
      const devices = [];
      for (const line of String(result.text || '').split(/\r?\n/)) {
        if (!line || /usage|example|--device/i.test(line)) continue;
        const matches = [...line.matchAll(/\bCOM\d+\b/gi)];
        for (const match of matches) {
          const port = match[0].toUpperCase();
          if (devices.some(item => item.port === port)) continue;
          const recognized = /obdlink|scan\s*tool|stn11|stn21/i.test(line);
          const outgoing = /outgoing|client/i.test(line);
          const incoming = /incoming|server/i.test(line);
          devices.push({ port, name: clean(line, 300), recognized, recommended: recognized || outgoing, outgoing, incoming, source: 'pcmhammer-list-devices' });
        }
      }
      return devices.sort((a, b) => Number(b.recommended) - Number(a.recommended) || Number(b.outgoing) - Number(a.outgoing) || Number(a.incoming) - Number(b.incoming) || a.port.localeCompare(b.port, undefined, { numeric: true }));
    } catch { return []; }
  }

  async resolveDeviceCandidates(selectedPort = '', operation = '') {
    const candidates = [];
    const add = (port, source, metadata = {}) => {
      const cleanPort = clean(port, 40);
      if (!cleanPort || candidates.some(item => item.port.toUpperCase() === cleanPort.toUpperCase())) return;
      candidates.push({ port: cleanPort, source, ...metadata });
    };
    add(selectedPort, 'selected');
    const remembered = this.getConfig().lastSuccessfulDevice || '';
    if (remembered && String(remembered).toUpperCase() !== String(selectedPort || '').toUpperCase()) add(remembered, 'last-successful-port', { recognized: true, recommended: true, recoveryScore: 1000 });
    if (['readProperties', 'read', 'testWrite'].includes(String(operation || ''))) {
      let alternates = [];
      try { alternates = await this.findAlternatePorts(selectedPort); } catch {}
      for (const item of Array.isArray(alternates) ? alternates : []) add(item.port, 'recognized-alternate', item);
      let cliDevices = [];
      try { cliDevices = await this.discoverCliDevices(); } catch {}
      for (const item of cliDevices) add(item.port, item.source || 'pcmhammer-list-devices', item);
      // A previous successful Windows scan remains useful after an app restart or when a
      // transient PowerShell/CIM request fails. Only non-destructive operations use this list.
      for (const item of this.getConfig().lastDeviceCandidates || []) add(item.port, 'saved-device-inventory', item);
    }
    if (candidates.length) {
      try {
        this.saveConfig({
          lastDeviceCandidates: candidates.slice(0, 12).map(item => ({
            port: item.port, name: clean(item.name || '', 300), source: item.source || '',
            recognized: Boolean(item.recognized), recommended: Boolean(item.recommended),
            bluetooth: Boolean(item.bluetooth), outgoing: Boolean(item.outgoing), incoming: Boolean(item.incoming),
            pairKey: clean(item.pairKey || '', 300), recoveryScore: Number(item.recoveryScore || 0)
          })),
          lastDeviceDiscoveryAt: new Date().toISOString()
        });
      } catch {}
    }
    return candidates;
  }

  mergeDeviceCandidates(existing = [], discovered = []) {
    const merged = [];
    for (const item of [...(Array.isArray(existing) ? existing : []), ...(Array.isArray(discovered) ? discovered : [])]) {
      const port = clean(item?.port, 40);
      if (!port) continue;
      const prior = merged.find(candidate => candidate.port.toUpperCase() === port.toUpperCase());
      if (!prior) merged.push({ ...item, port });
      else Object.assign(prior, Object.fromEntries(Object.entries(item).filter(([, value]) => value !== '' && value != null && value !== false)));
    }
    return merged;
  }

  async refreshSessionDeviceCandidates(session, reason = 'runtime-rescan') {
    const before = Array.isArray(session.deviceCandidates) ? session.deviceCandidates.map(item => item.port) : [];
    let discovered = [];
    try { discovered = await this.resolveDeviceCandidates(session.initialDevice || session.device || '', session.operation); } catch {}
    session.deviceCandidates = this.mergeDeviceCandidates(session.deviceCandidates, discovered);
    const added = session.deviceCandidates.filter(item => !before.some(port => String(port).toUpperCase() === String(item.port).toUpperCase()));
    session.deviceDiscoveryPasses = [...(session.deviceDiscoveryPasses || []), {
      at: new Date().toISOString(), reason, before, discovered: discovered.map(item => item.port), added: added.map(item => item.port)
    }].slice(-12);
    return added;
  }

  async handoffPort(port, operation, leaseId, source = 'selected') {
    const bridgeBefore = this.abortBridgeRequests(`PCM Hammer direct lease ${leaseId} pre-release`) || { aborted: 0 };
    const release = await this.releasePort({ port, operation, leaseId, owner: 'pcmhammer' });
    const bridgeAfter = this.abortBridgeRequests(`PCM Hammer direct lease ${leaseId} post-release`) || { aborted: 0 };
    const bridge = { aborted: Number(bridgeBefore.aborted || 0) + Number(bridgeAfter.aborted || 0), before: bridgeBefore, after: bridgeAfter };
    // Bluetooth SPP handles can remain in a closing state after the owning PowerShell process
    // exits. Give Windows a bounded settle period before PCM Hammer opens the port.
    await sleep(hardwareSettle(750));
    this.setPortOwner('pcmhammer', { port, operation, leaseId });
    return { port, source, release, bridge, at: new Date().toISOString(), lockProbe: { skipped: true, reason: 'direct PCM Hammer lease' } };
  }

  async runCapture(executable, args, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const child = spawn(executable, args, { windowsHide: true, cwd: path.dirname(executable) });
      let stdout = ''; let stderr = ''; let finished = false;
      const done = value => { if (finished) return; finished = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => { try { child.kill(); } catch {} reject(new Error('PCM Hammer CLI probe timed out.')); }, timeout);
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => done({ code, stdout, stderr, text: `${stdout}\n${stderr}`.trim() }));
    });
  }

  async probe(payload = {}) {
    if (payload.executable) this.saveConfig({ executable: payload.executable, prefixArgs: payload.prefixArgs || [] });
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer 2.x CLI was not found. Configure the pcmhammer-cli executable in Tool Connections.');
    let helpResult = null;
    const probeAttempts = [];
    for (const attempt of [['--help'], ['-h'], ['help'], []]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt]);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text?.length > 20) { helpResult = result; break; }
      } catch (error) { probeAttempts.push({ args: attempt, error: clean(error.message, 500) }); }
    }
    let versionText = '';
    for (const attempt of [['--version'], ['-v'], ['version']]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt], 8000);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text) { versionText = result.text; break; }
      } catch (error) { probeAttempts.push({ args: attempt, error: clean(error.message, 500) }); }
    }
    const combined = `${versionText}\n${helpResult?.text || ''}`;
    const parsedBackend = parseBackendIdentity(combined, resolved.executable);
    const recognizedExecutable = isRecognizedPcmHammerExecutable(resolved.executable, parsedBackend);
    const backend = {
      ...parsedBackend,
      product: parsedBackend.product || (recognizedExecutable ? 'PCM Hammer' : ''),
      recognizedExecutable,
      sha256: sha256File(resolved.executable),
      executable: resolved.executable
    };
    const inferred = inferTemplates(helpResult?.text || '');
    const existing = this.getConfig();
    const kernel = this.resolveKernelDirectory(resolved.executable);
    const templates = {};
    for (const operation of Object.keys(OPERATIONS)) templates[operation] = inferred[operation] || existing.templates?.[operation] || null;
    const helpCapabilities = Object.fromEntries(Object.entries(templates).map(([key, value]) => [key, Boolean(value)]));
    const cachedCapabilities = profileCapabilities(existing.integratedProfileId);
    const runtimeDiscovery = recognizedExecutable && !Object.values(helpCapabilities).some(Boolean) && !Object.values(cachedCapabilities).some(Boolean);
    const capabilities = Object.fromEntries(Object.keys(OPERATIONS).map(operation => [
      operation,
      Boolean(helpCapabilities[operation] || cachedCapabilities[operation] || (runtimeDiscovery && ['readProperties','read'].includes(operation)))
    ]));
    const integrationMode = Object.values(helpCapabilities).some(Boolean) ? 'help-driven'
      : Object.values(cachedCapabilities).some(Boolean) ? 'cached-profile'
        : runtimeDiscovery ? 'runtime-profile-discovery' : 'unsupported';
    const official = Boolean(parsedBackend.official || existing.backend?.verifiedByOperation);
    const stop = !recognizedExecutable ? { code: 'unsupported-cli', message: 'The selected executable is not recognized as PCM Hammer CLI.' } : null;
    const config = this.saveConfig({
      executable: resolved.executable,
      prefixArgs: resolved.prefixArgs,
      helpText: (helpResult?.text || '').slice(0, 50000),
      versionText: versionText.slice(0, 5000),
      backend: { ...backend, official, integrationReady: integrationMode !== 'unsupported' },
      templates,
      integrationMode,
      profileAttempts: probeAttempts.slice(-12),
      kernelDir: kernel?.folder || '',
      kernelFiles: kernel?.files?.map(file => path.basename(file)) || [],
      kernelDetectedAt: kernel ? new Date().toISOString() : null,
      probedAt: new Date().toISOString(),
      lastProbeStop: stop
    });
    return {
      executable: resolved.executable,
      backend: config.backend,
      capabilities,
      templates: config.templates,
      help: (helpResult?.text || '').slice(0, 16000),
      probedAt: config.probedAt,
      assistedAvailable: Boolean(this.resolveGuiExecutable()),
      mode: integrationMode,
      integratedProfileId: config.integratedProfileId || '',
      kernel: kernel ? { folder: kernel.folder, files: kernel.files.map(file => path.basename(file)), fileCount: kernel.fileCount, source: kernel.source } : null,
      stop
    };
  }

  status() {
    const resolved = this.resolveExecutable();
    const config = this.getConfig();
    const active = this.getActiveProject();
    const assisted = active ? readJson(this.assistedStateFile(active), null) : null;
    return {
      configured: Boolean(resolved), executable: resolved?.executable || null,
      backend: config.backend || null,
      capabilities: Object.fromEntries(Object.keys(OPERATIONS).map(operation => [operation, Boolean(config.templates?.[operation] || profileCapabilities(config.integratedProfileId)[operation] || (config.integrationMode === 'runtime-profile-discovery' && ['readProperties','read'].includes(operation)))])),
      templates: config.templates || {}, session: this.session ? { ...this.session, child: undefined } : null,
      device: config.device || '', probedAt: config.probedAt || null, history: this.getHistory().slice(0, 30),
      lastSuccessfulDevice: config.lastSuccessfulDevice || '', lastSuccessfulAt: config.lastSuccessfulAt || null,
      lastSuccessfulOperation: config.lastSuccessfulOperation || '', lastSuccessfulProfileId: config.lastSuccessfulProfileId || '',
      lastDeviceCandidates: Array.isArray(config.lastDeviceCandidates) ? config.lastDeviceCandidates : [], lastDeviceDiscoveryAt: config.lastDeviceDiscoveryAt || null,
      integrationMode: config.integrationMode || 'unprobed', integratedProfileId: config.integratedProfileId || '',
      kernel: (() => { const value = this.resolveKernelDirectory(resolved?.executable || ''); return value ? { folder: value.folder, files: value.files.map(file => path.basename(file)), fileCount: value.fileCount, source: value.source } : null; })(),
      portOwner: { ...this.portOwner }, integrated: Boolean(resolved && config.integrationMode !== 'unsupported'),
      assistedAvailable: Boolean(this.resolveGuiExecutable()), assisted
    };
  }

  saveDevice(device) { return this.saveConfig({ device: clean(device, 200) }); }
  saveTemplates(templates) {
    const normalized = {};
    for (const operation of Object.keys(OPERATIONS)) {
      const template = templates?.[operation] ?? (operation === 'readProperties' ? templates?.identify : null);
      if (template == null || String(Array.isArray(template) ? template.join(' ') : template).trim() === '') { normalized[operation] = null; continue; }
      const text = String(Array.isArray(template) ? template.join(' ') : template);
      if (OPERATIONS[operation].io === 'input' && !text.includes('{input}')) throw new Error(`${operation} command template must include {input}.`);
      if (OPERATIONS[operation].io === 'output' && !text.includes('{output}')) throw new Error(`${operation} command template must include {output}.`);
      normalized[operation] = tokenizeTemplate(template);
    }
    return this.saveConfig({ templates: normalized });
  }

  preflight(operation, payload = {}) {
    const normalizedOperation = normalizeOperation(operation);
    if (!OPERATIONS[normalizedOperation]) throw new FlashStopError('unsupported-operation', `Unsupported PCM Hammer operation: ${operation}.`);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const config = this.getConfig();
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer CLI is unavailable. Guided Automatic P01 Setup can switch to the normal PCM Hammer app and import its evidence.');
    const template = config.templates?.[normalizedOperation] || null;
    const recognized = isRecognizedPcmHammerExecutable(resolved.executable, config.backend);
    if (!recognized) throw new FlashStopError('unsupported-cli', 'The configured executable is not recognized as PCM Hammer CLI.');
    const candidateProfiles = profilesForOperation(normalizedOperation, config.integratedProfileId, template);
    if (!candidateProfiles.length) throw new FlashStopError('integrated-profile-unresolved', `TunIQ could not resolve a PCM Hammer command profile for ${OPERATIONS[normalizedOperation].label}. Run integrated Read Properties or a full read first so TunIQ can safely discover and cache the installed CLI syntax.`);
    if (!template && !config.integratedProfileId && !['readProperties','read'].includes(normalizedOperation)) throw new FlashStopError('integrated-profile-unresolved', `The PCM Hammer CLI syntax has not been proven yet. Run integrated Read Properties or a full read before ${OPERATIONS[normalizedOperation].label}.`);
    if (this.session) throw new FlashStopError('operation-running', 'Another PCM Hammer operation is already running.');
    const deviceStatus = this.getDeviceStatus() || {};
    const voltage = Number(payload.voltage ?? deviceStatus.connection?.voltage);
    const selectedDevice = payload.device || config.device || deviceStatus.connection?.port || '';
    const kernel = this.resolveKernelDirectory(resolved.executable);
    const kernelRequired = ['read', 'testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (kernelRequired && !kernel) {
      throw new FlashStopError('kernel-files-missing', `PCM Hammer ${OPERATIONS[normalizedOperation].label} requires Kernel-*.bin / Loader-*.bin files. TunIQ searched the configured PCM Hammer portable folder but could not find them. Re-extract the complete PCM Hammer package instead of copying only the CLI executable.`);
    }
    const values = {
      device: selectedDevice, port: selectedDevice, project: active.folder, controller: active.controller || '',
      input: payload.input || '', output: payload.output || '', kernelDir: kernel?.folder || ''
    };
    const writeOperation = ['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (writeOperation) {
      if (!values.input || !fs.existsSync(values.input)) throw new FlashStopError('input-missing', 'Select an existing revision BIN before Test Write or writing.');
      if (!active.bin || !fs.existsSync(active.bin)) throw new FlashStopError('original-missing', 'A protected verified original BIN is required before any write-related operation.');
      const sourceSize = fs.statSync(values.input).size;
      const originalSize = fs.statSync(active.bin).size;
      if (sourceSize !== originalSize) throw new FlashStopError('input-size-mismatch', `Revision size (${sourceSize}) does not match the protected original (${originalSize}).`);
      if (!Number.isFinite(voltage) && !payload.benchPowerConfirmed) throw new FlashStopError('power-proof-missing', 'Live voltage is unavailable. Enter voltage or confirm a regulated bench supply.');
      if (Number.isFinite(voltage) && voltage < 12.2) throw new FlashStopError('voltage-low', `Voltage is too low for a controlled ${OPERATIONS[normalizedOperation].label} (${voltage.toFixed(2)} V).`);
      if (normalizedOperation !== 'testWrite') {
        const expected = ['writeFull', 'recovery'].includes(normalizedOperation) ? `FULL WRITE ${active.name}` : `WRITE ${active.name}`;
        if (String(payload.confirmation || '').trim() !== expected) throw new FlashStopError('confirmation-missing', `Type exactly “${expected}” to authorize this operation.`);
        if (!payload.checksumApproved) throw new FlashStopError('checksum-not-approved', 'Checksum and compatibility validation must pass before writing.');
      }
    }
    if (normalizedOperation === 'read') {
      const output = values.output || path.join(active.folder, 'Originals', `${safeName(active.name)}-P01-Full-Read-${new Date().toISOString().replace(/[:.]/g, '-')}.bin`);
      ensureDir(path.dirname(output)); values.output = output;
    }
    return { operation: normalizedOperation, active, config, resolved, template, candidateProfiles, values, kernel, voltage: Number.isFinite(voltage) ? voltage : null };
  }

  setPortOwner(owner, details = {}) {
    this.portOwner = {
      owner,
      port: clean(details.port || this.portOwner.port, 40),
      operation: clean(details.operation || '', 80),
      leaseId: clean(details.leaseId || '', 120),
      since: owner === 'idle' ? null : new Date().toISOString()
    };
    this.emit('flash:port-owner', { ...this.portOwner });
    return this.portOwner;
  }

  async preparePort(preflight) {
    const selectedPort = preflight.values.device;
    const leaseId = `${Date.now()}-${preflight.operation}-${selectedPort || 'auto'}`;
    const validateConnection = this.connectionManagerRequired && ['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].includes(preflight.operation);
    let intelligent = null;
    if (validateConnection) {
      try {
        intelligent = await this.connectionManager.preflight({ selectedPort, lastSuccessfulPort: preflight.config?.lastSuccessfulDevice || '' });
      } catch (error) {
        intelligent = { ready: false, verified: false, state: 'connection-broker-failed', warning: clean(error.message || error, 1200), attempts: [], repair: { title: 'TunIQ could not complete adapter verification.' } };
      }
    }
    if (validateConnection && !intelligent?.ready) {
      throw new FlashStopError(intelligent?.state || 'ports-unavailable', intelligent?.repair?.title || 'TunIQ could not positively open and identify an OBDLink/STN adapter.', { intelligentConnection: intelligent });
    }
    // When the broker is enabled, PCM Hammer receives exactly the one port that TunIQ
    // positively opened and identified. Blind COM fallbacks and duplicate same-port attempts
    // are intentionally excluded from this hardware session.
    const chosenPort = intelligent?.ready ? intelligent.port : selectedPort;
    let candidates = [];
    if (intelligent?.ready) {
      candidates = [{
        port: chosenPort,
        source: 'verified-adapter-connection-broker',
        verified: true,
        recognized: true,
        adapter: intelligent.attempt?.adapter || intelligent.profile?.adapterName || '',
        baud: intelligent.attempt?.baud || intelligent.profile?.baud || null
      }];
    } else {
      candidates = await this.resolveDeviceCandidates(selectedPort, preflight.operation);
    }
    if (!chosenPort && !validateConnection) {
      this.setPortOwner('pcmhammer', { port: '', operation: preflight.operation, leaseId });
      return { port: '', released: false, mode: 'direct-handoff', lockProbeSkipped: true, verifiedByBroker: false, leaseId, attempts: [], candidates, intelligentConnection: intelligent };
    }
    if (!chosenPort) throw new FlashStopError('adapter-not-detected', 'TunIQ could not identify an available OBDLink serial port.', { intelligentConnection: intelligent });
    preflight.values.device = chosenPort;
    preflight.values.port = chosenPort;
    const handoff = await this.handoffPort(chosenPort, preflight.operation, leaseId, intelligent?.ready ? 'verified-adapter-connection-broker' : 'selected');
    return {
      port: chosenPort,
      released: Boolean(handoff.release?.released),
      release: handoff.release,
      bridge: handoff.bridge,
      mode: intelligent?.ready ? 'verified-broker-handoff' : 'direct-handoff',
      lockProbeSkipped: !validateConnection,
      verifiedByBroker: Boolean(intelligent?.ready && intelligent?.verified !== false),
      leaseId,
      attempts: [...(intelligent?.attempts || []), handoff],
      candidates,
      intelligentConnection: intelligent
    };
  }

  clearTransientRecoveryState(reason = 'workflow recovery') {
    const bridge = this.abortBridgeRequests(reason) || { aborted: 0 };
    if (this.session && !['writeCalibration','writeFull','recovery'].includes(this.session.operation)) {
      try { this.session.child?.kill(); } catch {}
      this.session = null;
    }
    if (!this.session) this.setPortOwner('idle', { port: this.portOwner.port });
    return { bridge, activeSession: Boolean(this.session) };
  }

  async start(operation, payload = {}) {
    const preflight = this.preflight(operation, payload);
    let exclusiveGuard = null;
    try {
      exclusiveGuard = await this.inspectExclusiveSession({
        selectedPort: preflight.values.device || '', expectedExecutable: preflight.resolved.executable,
        operation: preflight.operation, project: preflight.active
      });
    } catch (error) {
      exclusiveGuard = { blocked: false, warning: clean(error.message || error, 1200), conflicts: [], warnings: [] };
    }
    if (exclusiveGuard?.blocked) {
      const conflictText = (exclusiveGuard.conflicts || []).map(item => `${item.name || 'process'} (PID ${item.pid || '?'})`).join(', ');
      throw new FlashStopError('adapter-conflict-process', `Another OBD/serial application may own the adapter: ${conflictText || 'conflicting process detected'}. Close it and retry the same step.`, { exclusiveGuard });
    }
    let safetySnapshot = null;
    if (['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(preflight.operation)) {
      try {
        safetySnapshot = await this.createSafetySnapshot(`before-${preflight.operation}`, { project: preflight.active, operation: preflight.operation });
      } catch (error) {
        throw new FlashStopError('safety-snapshot-failed', `TunIQ could not create and verify the required project safety snapshot: ${error.message}`, { snapshotError: clean(error.message || error, 2000) });
      }
      if (!safetySnapshot?.verified) throw new FlashStopError('safety-snapshot-failed', 'TunIQ did not receive a verified project safety snapshot, so the hardware operation was blocked.', { safetySnapshot });
    }
    const portLease = await this.preparePort(preflight);
    const profiles = preflight.candidateProfiles || [];
    const session = {
      id: `${Date.now()}-${preflight.operation}`, operation: preflight.operation,
      projectId: preflight.active.id, projectName: preflight.active.name,
      executable: preflight.resolved.executable, backendSha256: preflight.config?.backend?.sha256 || '', backendVersion: preflight.config?.backend?.version || '',
      args: [], input: preflight.values.input || null, output: preflight.values.output || null,
      device: preflight.values.device || null, initialDevice: preflight.values.device || null, voltage: preflight.voltage, portLease,
      kernelDir: preflight.kernel?.folder || null, kernelFiles: preflight.kernel?.files?.map(file => path.basename(file)) || [],
      deviceCandidates: Array.isArray(portLease.candidates) ? portLease.candidates : [], deviceIndex: 0, deviceAttempts: [], deviceDiscoveryPasses: [], portRetryCounts: {},
      integrated: true, integrationMode: preflight.config.integrationMode || 'runtime-profile-discovery',
      profileAttempts: [], startedAt: new Date().toISOString(), state: 'running', progress: 0,
      phase: `Starting integrated PCM Hammer ${OPERATIONS[preflight.operation].label}`, log: [], technicalDetails: null,
      exclusiveGuard, safetySnapshot
    };
    const sessionLog = path.join(this.sessionsRoot(), `${session.id}.log`);
    session.sessionLog = sessionLog;
    this.session = session;
    const emit = () => this.emit('flash:progress', { ...session, child: undefined });
    const append = (stream, chunk) => {
      const text = chunk.toString(); fs.appendFileSync(sessionLog, text, 'utf8');
      for (const line of text.split(/\r?\n/).filter(Boolean)) {
        const entry = { at: new Date().toISOString(), stream, text: clean(line, 3000) };
        session.log.push(entry); if (session.log.length > 1200) session.log.shift();
        session.progress = parseProgress(entry.text, session.progress);
        if (/read\s+propert|OSID|Hardware ID|Service No/i.test(entry.text)) session.phase = 'Reading controller properties inside TunIQ';
        else if (/read|block/i.test(entry.text)) session.phase = 'Reading PCM inside TunIQ';
        else if (/erase/i.test(entry.text)) session.phase = 'Erasing flash';
        else if (/write|program/i.test(entry.text)) session.phase = 'Writing flash';
        else if (/verif/i.test(entry.text)) session.phase = 'Verifying';
        const voltage = entry.text.match(/(?:battery\s+)?voltage(?:\s+is)?\s*:\s*(\d+(?:\.\d+)?)/i)?.[1];
        if (voltage) session.voltage = Number(voltage);
      }
      emit();
    };

    const finalize = async (code, attemptText, profile) => {
      if (session.finalized) return;
      session.exitCode = code; session.finishedAt = new Date().toISOString();
      session.result = classifyPcmHammerResult(session.operation, attemptText, code);
      session.identity = parseIdentityText(attemptText);
      if (Number.isFinite(session.identity.voltage)) session.voltage = session.identity.voltage;
      session.stopCode = session.result.stopCode;
      session.state = session.cancelRequested ? 'cancelled' : session.result.success ? 'complete' : 'failed';
      if (portLease.verifiedByBroker && ['adapter-open-timeout','adapter-open-failed','adapter-locked'].includes(session.stopCode)) {
        session.stopCode = 'adapter-handoff-failed';
        session.error = `TunIQ positively opened and identified ${session.device || 'the adapter port'}, released the handle, and then PCM Hammer could not claim it. Windows Bluetooth changed state during the handoff; TunIQ did not retry another COM port or repeat the same port.`;
      }
      session.progress = session.result.success ? 100 : session.progress;
      session.testWritePassed = Boolean(session.result.testWritePassed);
      session.verified = Boolean(session.result.verificationPassed || session.result.testWritePassed);
      const allProfilesRejectedBeforeCommunication = session.profileAttempts.length >= profiles.length
        && session.profileAttempts.length > 0
        && session.profileAttempts.every(item => item.syntaxFailure && !item.communicationStarted);
      if (allProfilesRejectedBeforeCommunication) {
        session.state = 'failed';
        session.stopCode = 'integrated-cli-profile-unresolved';
        session.error = `TunIQ tried every safe PCM Hammer 2.x command profile for ${OPERATIONS[session.operation].label}, but this CLI build did not accept any of them. No PCM communication began and no output was accepted.`;
      }
      if (session.state === 'complete' && profile?.id) {
        const provenProfile = profile.id === 'configured-template' ? profileMatchingTemplate(session.operation, profile.templates?.[session.operation]) : profile;
        const existingBackend = this.getConfig().backend || {};
        const config = this.saveConfig({
          integratedProfileId: provenProfile?.id || this.getConfig().integratedProfileId || '',
          integrationMode: provenProfile ? 'verified-profile' : 'help-driven-verified-operation',
          templates: provenProfile?.templates || this.getConfig().templates,
          backend: { ...existingBackend, product: 'PCM Hammer', official: true, verifiedByOperation: true, integrationReady: true, verifiedAt: new Date().toISOString() },
          device: session.device || this.getConfig().device || '',
          lastSuccessfulDevice: session.device || this.getConfig().lastSuccessfulDevice || '',
          lastSuccessfulAt: new Date().toISOString(),
          lastSuccessfulOperation: session.operation,
          lastSuccessfulProfileId: provenProfile?.id || profile.id || '',
          kernelDir: session.kernelDir || this.getConfig().kernelDir || '',
          kernelFiles: Array.isArray(session.kernelFiles) ? session.kernelFiles : this.getConfig().kernelFiles || [],
          profileAttempts: session.profileAttempts.slice(-20)
        });
        session.integratedProfileId = provenProfile?.id || profile.id;
        session.backendVersion = config.backend?.version || session.backendVersion;
      }
      if (session.operation === 'read' && !allProfilesRejectedBeforeCommunication) {
        const validation = validateP01ReadFile(session.output, session.result);
        session.outputValidation = validation;
        if (!validation.valid) {
          const communicationStops = new Set(['adapter-open-timeout', 'adapter-open-failed', 'kernel-files-missing', 'adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'pcmhammer-failed']);
          const classifiedStop = session.result?.stopCode;
          session.state = 'failed';
          session.stopCode = communicationStops.has(classifiedStop) ? classifiedStop : validation.code;
          session.error = communicationStops.has(classifiedStop)
            ? `PCM Hammer stopped before a complete read (${classifiedStop}). ${validation.message}`
            : validation.message;
          if (session.output && fs.existsSync(session.output)) {
            const rejected = `${session.output}.rejected-${Date.now()}`;
            try { fs.renameSync(session.output, rejected); session.rejectedOutput = rejected; } catch {}
          }
        } else {
          session.outputInfo = validation;
          try { await this.onReadComplete(session.output, session.outputInfo, session); }
          catch (error) { session.state = 'failed'; session.stopCode = 'read-import-failed'; session.importWarning = error.message; }
        }
      }
      const identityUseful = session.operation === 'readProperties'
        ? Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.controller)
        : Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.vin);
      if (identityUseful) {
        try { await this.onIdentifyComplete(session.identity, session); }
        catch (error) { session.identityWarning = error.message; if (session.operation === 'readProperties') { session.state = 'failed'; session.stopCode = 'identity-import-failed'; } }
      }
      if (session.operation === 'readProperties' && !identityUseful && !allProfilesRejectedBeforeCommunication) {
        session.state = 'failed';
        const specificStops = new Set(['adapter-open-timeout', 'adapter-open-failed', 'kernel-files-missing', 'adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'partial-read', 'pcmhammer-failed']);
        if (!specificStops.has(session.result?.stopCode)) {
          session.stopCode = 'properties-incomplete';
          session.error = 'Read Properties finished without OSID, Hardware ID, service number, or controller evidence.';
        } else {
          session.stopCode = session.result.stopCode;
          session.error = `PCM Hammer stopped before Read Properties completed (${session.result.stopCode}).`;
        }
      }
      if (session.state === 'failed' && !session.error) {
        if (['adapter-open-timeout', 'adapter-open-failed'].includes(session.stopCode)) {
          const tried = [...new Set((session.deviceAttempts || []).map(item => item.device).filter(Boolean))];
          const candidates = [...new Set((session.deviceCandidates || []).map(item => item.port).filter(Boolean))];
          session.error = `PCM Hammer could not open an adapter port before PCM communication began. TunIQ released its own serial/PowerShell handles and tested ${tried.length ? tried.join(', ') : session.device || 'the selected port'}${candidates.length > tried.length ? ` from candidates ${candidates.join(', ')}` : ''}, but Windows/Bluetooth did not provide an openable outgoing OBDLink port.`;
        } else if (session.stopCode === 'kernel-files-missing') {
          session.error = 'PCM Hammer could not find its Kernel-*.bin / Loader-*.bin files. TunIQ searched the complete portable installation and did not accept a Test Write without the required kernels.';
        } else if (session.stopCode) {
          session.error = `PCM Hammer ${OPERATIONS[session.operation].label} stopped (${session.stopCode}).`;
        }
      }
      if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && code === 0 && !session.verified) {
        session.state = 'complete-unverified'; session.stopCode = 'verification-not-proven';
        session.verificationWarning = 'PCM Hammer exited, but TunIQ did not parse an explicit verification-pass result. Re-read properties and read back before treating the hardware as verified.';
      }
      session.technicalDetails = {
        executable: session.executable,
        args: Array.isArray(session.args) ? [...session.args] : [],
        commandLine: [session.executable, ...(session.args || [])].map(value => /\s/.test(String(value)) ? `"${String(value)}"` : String(value)).join(' '),
        device: session.device || '', deviceAttempts: session.deviceAttempts || [], exitCode: code, stopCode: session.stopCode || session.result?.stopCode || '',
        kernelDir: session.kernelDir || '', kernelFiles: session.kernelFiles || [],
        deviceCandidates: session.deviceCandidates || [], deviceDiscoveryPasses: session.deviceDiscoveryPasses || [],
        usageOnly: looksLikeCliUsageOnly(attemptText), communicationStarted: hasCommunicationActivity(attemptText),
        stdoutStderrExcerpt: clean(attemptText, 12000), sessionLog,
        exclusiveGuard: session.exclusiveGuard || null, safetySnapshot: session.safetySnapshot || null
      };
      this.appendActivity(`flash-${session.operation}-${session.state}`, {
        projectId: session.projectId, projectName: session.projectName,
        input: session.input ? path.basename(session.input) : null,
        output: session.output ? path.basename(session.output) : null,
        exitCode: code, stopCode: session.stopCode, sessionLog,
        integratedProfileId: session.integratedProfileId || profile?.id || '', portLeaseId: portLease.leaseId
      });
      try { await this.onSessionComplete({ ...session, child: undefined }); }
      catch (error) { session.sessionCompletionWarning = error.message; }
      session.finalized = true;
      this.recordHistory(session);
      this.setPortOwner('idle', { port: session.device });
      emit();
      this.session = null;
    };

    const launchProfile = async (index, deviceIndex = Number(session.deviceIndex || 0)) => {
      const profile = profiles[index];
      if (!profile?.templates?.[preflight.operation]) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('integrated-profile-unresolved', `No integrated PCM Hammer command profile exists for ${OPERATIONS[preflight.operation].label}.`);
      }
      const candidate = session.deviceCandidates?.[deviceIndex] || { port: preflight.values.device || '', source: 'selected' };
      const attemptValues = { ...preflight.values, device: candidate.port || '', port: candidate.port || '' };
      const template = profile.templates[preflight.operation];
      const args = [...preflight.resolved.prefixArgs, ...expandTemplate(template, attemptValues)];
      if (session.kernelDir && ['read','testWrite','writeCalibration','writeFull','recovery'].includes(session.operation) && !args.some(value => String(value).toLowerCase() === '--kernel-dir')) args.push('--kernel-dir', session.kernelDir);
      session.args = args;
      session.device = candidate.port || null;
      session.deviceIndex = deviceIndex;
      session.currentProfileId = profile.id;
      session.currentProfileLabel = profile.label;
      session.profileIndex = index;
      session.phase = profiles.length > 1
        ? `Discovering PCM Hammer command profile ${index + 1} of ${profiles.length} on ${session.device || 'automatic device selection'}`
        : `Running integrated PCM Hammer ${OPERATIONS[preflight.operation].label} on ${session.device || 'automatic device selection'}`;
      const attemptStart = session.log.length;
      const attemptNumber = session.deviceAttempts.length + 1;
      const attemptBase = path.join(this.sessionsRoot(), `${session.id}.attempt-${String(attemptNumber).padStart(2, '0')}-${safeName(session.device || 'auto')}`);
      const deviceAttempt = {
        device: session.device || '', source: candidate.source || 'selected', profileId: profile.id,
        kernelDir: session.kernelDir || '', startedAt: new Date().toISOString(), attempt: attemptNumber,
        stdoutLog: `${attemptBase}.stdout.log`, stderrLog: `${attemptBase}.stderr.log`
      };
      session.deviceAttempts.push(deviceAttempt);
      let child;
      try {
        child = spawn(preflight.resolved.executable, args, {
          windowsHide: true,
          cwd: session.kernelDir || path.dirname(preflight.resolved.executable)
        });
      } catch (error) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('cli-launch-failed', `PCM Hammer CLI could not start: ${error.message}`);
      }
      session.child = child;
      try { this.registerOwnedProcess(child.pid, preflight.resolved.executable, session.id); } catch {}
      child.stdout?.on('data', chunk => {
        try { fs.appendFileSync(deviceAttempt.stdoutLog, chunk); } catch {}
        append('stdout', chunk);
      });
      child.stderr?.on('data', chunk => {
        try { fs.appendFileSync(deviceAttempt.stderrLog, chunk); } catch {}
        append('stderr', chunk);
      });
      child.on('error', async error => {
        session.state = 'failed'; session.error = error.message;
        session.stopCode = /denied|busy|in use/i.test(error.message) ? 'adapter-locked' : 'cli-process-error';
        session.finishedAt = new Date().toISOString();
        deviceAttempt.finishedAt = session.finishedAt; deviceAttempt.stopCode = session.stopCode; deviceAttempt.error = clean(error.message, 1000);
        try { this.releaseOwnedProcess(child.pid); } catch {}
        this.setPortOwner('idle', { port: session.device });
        try { await this.onSessionComplete({ ...session, child: undefined }); } catch {}
        session.finalized = true; this.recordHistory(session); emit(); this.session = null;
      });
      child.on('close', async code => {
        try { this.releaseOwnedProcess(child.pid); } catch {}
        if (session.finalized) return;
        const attemptEntries = session.log.slice(attemptStart);
        const attemptText = attemptEntries.map(item => item.text).join('\n');
        const communicationStarted = hasCommunicationActivity(attemptText);
        const retryable = safeToRetryProfile({ operation: session.operation, text: attemptText, exitCode: code, output: session.output });
        const usageOnly = looksLikeCliUsageOnly(attemptText);
        const openTimeout = portOpenTimedOut(attemptText);
        const openFailure = isPortOpenFailure(attemptText);
        const missingKernel = kernelFilesMissing(attemptText);
        const accessBlocked = !communicationStarted && /(?:access\s+(?:to\s+the\s+port\s+)?is\s+denied|port\s+.*(?:busy|in use|locked)|another\s+(?:program|process).*using)/i.test(attemptText);
        deviceAttempt.finishedAt = new Date().toISOString();
        deviceAttempt.exitCode = code;
        deviceAttempt.communicationStarted = communicationStarted;
        deviceAttempt.openTimeout = openTimeout;
        deviceAttempt.openFailure = openFailure;
        deviceAttempt.accessBlocked = accessBlocked;
        deviceAttempt.kernelMissing = missingKernel;
        deviceAttempt.excerpt = clean(attemptText, 2400);
        session.profileAttempts.push({
          profileId: profile.id, label: profile.label, args, device: session.device || '', kernelDir: session.kernelDir || '',
          exitCode: code, syntaxFailure: retryable,
          usageOnly, communicationStarted,
          openTimeout, openFailure, accessBlocked, kernelMissing: missingKernel,
          at: new Date().toISOString(), excerpt: clean(attemptText, 2400)
        });
        session.technicalDetails = {
          executable: session.executable, args: [...args],
          commandLine: [session.executable, ...args].map(value => /\s/.test(String(value)) ? `"${String(value)}"` : String(value)).join(' '),
          device: session.device || '', deviceAttempts: session.deviceAttempts || [], exitCode: code, profileId: profile.id, usageOnly,
          kernelDir: session.kernelDir || '', kernelFiles: session.kernelFiles || [],
          communicationStarted, openFailure, openTimeout,
          deviceCandidates: session.deviceCandidates || [], deviceDiscoveryPasses: session.deviceDiscoveryPasses || [],
          stdoutStderrExcerpt: clean(attemptText, 12000), sessionLog,
          exclusiveGuard: session.exclusiveGuard || null, safetySnapshot: session.safetySnapshot || null
        };

        const canRetryPort = !portLease.verifiedByBroker && !session.cancelRequested && !communicationStarted && ['readProperties', 'read', 'testWrite'].includes(session.operation);
        if (canRetryPort && (openFailure || openTimeout || accessBlocked)) {
          const retryKey = `${session.device || 'auto'}:${profile.id}`;
          const retryCount = Number(session.portRetryCounts[retryKey] || 0);
          if (retryCount < 1 && session.device) {
            session.portRetryCounts[retryKey] = retryCount + 1;
            append('recovery', `${session.device} did not open. TunIQ is clearing stale serial ownership and retrying this same port once.\n`);
            const handoff = await this.handoffPort(session.device, session.operation, portLease.leaseId, 'same-port-retry');
            portLease.attempts.push(handoff);
            await sleep(hardwareSettle(450));
            launchProfile(index, deviceIndex);
            return;
          }
          const added = await this.refreshSessionDeviceCandidates(session, `${session.device || 'selected port'} failed after bounded retry`);
          if (added.length) append('recovery', `Windows/PCM Hammer rescan found additional serial candidate(s): ${added.map(item => item.port).join(', ')}.\n`);
          const attemptedPorts = new Set((session.deviceAttempts || []).map(item => String(item.device || '').toUpperCase()).filter(Boolean));
          const nextCandidate = (session.deviceCandidates || [])
            .filter(item => item?.port && !attemptedPorts.has(String(item.port).toUpperCase()))
            .sort((a, b) => Number(b.recoveryScore || 0) - Number(a.recoveryScore || 0)
              || Number(Boolean(b.outgoing)) - Number(Boolean(a.outgoing))
              || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }))[0];
          const nextIndex = nextCandidate ? session.deviceCandidates.findIndex(item => String(item.port).toUpperCase() === String(nextCandidate.port).toUpperCase()) : -1;
          if (nextCandidate?.port) {
            append('recovery', `${session.device} could not be opened. TunIQ is switching to alternate ${nextCandidate.outgoing ? 'outgoing ' : ''}Bluetooth/OBDLink port ${nextCandidate.port}.\n`);
            const handoff = await this.handoffPort(nextCandidate.port, session.operation, portLease.leaseId, nextCandidate.source || 'recognized-alternate');
            portLease.attempts.push(handoff);
            await sleep(hardwareSettle(450));
            launchProfile(index, nextIndex);
            return;
          }
        }

        if (!session.cancelRequested && retryable && index + 1 < profiles.length) {
          append('integration', `Command profile ${profile.id} was rejected before any PCM communication. Retrying safely with ${profiles[index + 1].id}.\n`);
          await sleep(80);
          launchProfile(index + 1, deviceIndex);
          return;
        }
        await finalize(code, attemptText, profile);
      });
      emit();
    };

    this.appendActivity(`flash-${session.operation}-started`, {
      projectId: session.projectId, projectName: session.projectName,
      device: session.device, voltage: session.voltage,
      releasedTunIQPort: portLease.released, directPortLease: true, portLeaseId: portLease.leaseId
    });
    launchProfile(0, 0);
    emit();
    return { ...session, child: undefined };
  }

  async cancel() {
    if (!this.session?.child) return this.status();
    const session = this.session;
    if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && /eras|writ|program|verif/i.test(session.phase || '')) {
      session.cancelBlocked = true; session.phase = 'Cancellation blocked during critical flash phase';
      session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'TunIQ will not terminate PCM Hammer during erase/write/verify. Maintain power and allow it to finish.' });
      this.emit('flash:progress', { ...session, child: undefined }); return this.status();
    }
    session.cancelRequested = true; session.phase = 'Safe cancellation requested';
    try {
      if (process.platform === 'win32' && session.child.pid) spawn('taskkill.exe', ['/PID', String(session.child.pid), '/T', '/F'], { windowsHide: true });
      else session.child.kill('SIGTERM');
    } catch {}
    return this.status();
  }

  prepareAssisted(operation, payload = {}, reason = null) {
    const normalizedOperation = normalizeOperation(operation);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const folder = this.assistedFolder(active);
    const state = {
      type: 'pcmhammer-assisted-operation', version: 1, projectId: active.id, projectName: active.name,
      operation: normalizedOperation, status: 'waiting-for-evidence', folder,
      input: payload.input || null, device: payload.device || this.getConfig().device || this.getDeviceStatus()?.connection?.port || '',
      reason: reason ? clean(reason.message || reason, 2000) : 'CLI automation is unavailable for this step.',
      instructions: assistedInstructions(normalizedOperation, folder),
      knownFiles: fs.readdirSync(folder).map(name => fileFingerprint(path.join(folder, name))),
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    writeJson(this.assistedStateFile(active), state);
    return state;
  }

  async launchAssisted(operation, payload = {}, reason = null) {
    const state = this.prepareAssisted(operation, payload, reason);
    const gui = this.resolveGuiExecutable();
    if (state.device) {
      await this.releasePort({ port: state.device, operation: state.operation });
      await sleep(100);
      const lock = await this.probePortLock({ port: state.device, operation: state.operation });
      if (lock?.locked || lock?.available === false) {
        state.status = 'blocked'; state.stopCode = 'adapter-locked'; state.stopMessage = `${state.device} is still locked. Close the program using it before opening PCM Hammer.`;
        writeJson(this.assistedStateFile(), state); return state;
      }
    }
    if (gui) {
      try { const child = spawn(gui, [], { detached: true, windowsHide: false, cwd: path.dirname(gui), stdio: 'ignore' }); child.unref(); state.guiExecutable = gui; state.guiLaunchedAt = new Date().toISOString(); }
      catch (error) { state.launchWarning = error.message; }
    } else state.launchWarning = 'The normal PcmHammer.exe was not found. Open it manually.';
    state.updatedAt = new Date().toISOString(); writeJson(this.assistedStateFile(), state);
    this.watchAssisted(state);
    this.appendActivity('pcmhammer-assisted-started', { projectId: state.projectId, operation: state.operation, folder: state.folder, reason: state.reason });
    return state;
  }

  watchAssisted(state) {
    if (!state?.folder || this.assistedWatchers.has(state.projectId)) return;
    let timer = null;
    try {
      const watcher = fs.watch(state.folder, () => {
        clearTimeout(timer); timer = setTimeout(() => this.scanAssisted().catch(() => {}), 350);
      });
      watcher.on('error', () => {});
      this.assistedWatchers.set(state.projectId, watcher);
    } catch {}
  }
  stopAssistedWatcher(projectId) {
    const watcher = this.assistedWatchers.get(projectId); if (watcher) { try { watcher.close(); } catch {} this.assistedWatchers.delete(projectId); }
  }

  async importAssistedEvidence(files = [], payload = {}) {
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const state = readJson(this.assistedStateFile(active), null) || this.prepareAssisted(payload.operation || 'readProperties', payload);
    const candidates = uniqueFiles(files).filter(file => fs.existsSync(file) && fs.statSync(file).isFile());
    if (!candidates.length) return { ...state, imported: [] };
    const imported = []; const logs = [];
    for (const file of candidates) {
      const ext = path.extname(file).toLowerCase();
      if (ext === '.bin') {
        const validation = validateP01ReadFile(file, { success: true });
        if (!validation.valid) { imported.push({ file, type: 'read', accepted: false, code: validation.code, message: validation.message }); continue; }
        const session = { id: `${Date.now()}-assisted-read`, operation: 'read', state: 'complete', device: state.device, proofSource: 'PCM Hammer WinForms assisted full read', result: { success: true }, assisted: true };
        try { await this.onReadComplete(file, validation, session); await this.onSessionComplete(session); imported.push({ file, type: 'read', accepted: true, sha256: validation.sha256, size: validation.size }); }
        catch (error) { imported.push({ file, type: 'read', accepted: false, code: 'read-import-failed', message: error.message }); }
      } else if (['.txt', '.log'].includes(ext)) logs.push({ file, text: fs.readFileSync(file, 'utf8') });
    }
    for (const log of logs) {
      const identity = parseIdentityText(log.text);
      const usefulIdentity = identity.os || identity.hardwareId || identity.serviceNumber || identity.controller;
      if (usefulIdentity) {
        const session = { id: `${Date.now()}-assisted-properties`, operation: 'readProperties', state: 'complete', device: state.device, proofSource: log.file, source: 'PCM Hammer WinForms Read Properties', assisted: true };
        try { await this.onIdentifyComplete(identity, session); await this.onSessionComplete(session); imported.push({ file: log.file, type: 'read-properties', accepted: true, identity }); }
        catch (error) { imported.push({ file: log.file, type: 'read-properties', accepted: false, code: 'identity-import-failed', message: error.message }); }
      }
      const testResult = classifyPcmHammerResult('testWrite', log.text, 0);
      if (testResult.testWritePassed && state.input && fs.existsSync(state.input)) {
        const session = { id: `${Date.now()}-assisted-test-write`, operation: 'testWrite', input: state.input, state: 'complete', testWritePassed: true, verified: true, device: state.device, proofSource: log.file, sessionLog: log.file, result: testResult, assisted: true };
        try { await this.onSessionComplete(session); imported.push({ file: log.file, type: 'test-write', accepted: true, input: state.input }); }
        catch (error) { imported.push({ file: log.file, type: 'test-write', accepted: false, code: 'test-write-import-failed', message: error.message }); }
      }
    }
    const accepted = imported.filter(item => item.accepted);
    state.imported = [...(state.imported || []), ...accepted.map(item => ({ ...item, importedAt: new Date().toISOString() }))].slice(-50);
    state.knownFiles = [...new Set([...(state.knownFiles || []), ...candidates.map(fileFingerprint)])];
    state.updatedAt = new Date().toISOString();
    if (accepted.length) state.status = 'evidence-imported';
    writeJson(this.assistedStateFile(active), state);
    return { ...state, imported };
  }

  async scanAssisted() {
    const active = this.getActiveProject();
    if (!active) return null;
    const state = readJson(this.assistedStateFile(active), null);
    if (!state?.folder || !fs.existsSync(state.folder)) return state;
    const known = new Set(state.knownFiles || []);
    const files = fs.readdirSync(state.folder).map(name => path.join(state.folder, name)).filter(file => {
      try { return fs.statSync(file).isFile() && !known.has(fileFingerprint(file)); } catch { return false; }
    });
    if (!files.length) { this.watchAssisted(state); return { ...state, imported: [] }; }
    return this.importAssistedEvidence(files, { operation: state.operation, input: state.input });
  }
}

module.exports = {
  FlashManager, FlashStopError, inferTemplates, expandTemplate, parseProgress, parseIdentityText,
  parseBackendIdentity, classifyPcmHammerResult, validateP01ReadFile, normalizeOperation, P01_BIN_SIZE
};
