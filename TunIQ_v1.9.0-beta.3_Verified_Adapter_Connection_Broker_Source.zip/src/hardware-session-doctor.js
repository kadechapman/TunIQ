const fs = require('fs');
const path = require('path');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function clean(value, max = 4000) { return String(value == null ? '' : value).replace(/\u0000/g, '').slice(0, max); }
function unique(values = []) { return [...new Set(values.filter(Boolean).map(value => String(value)))]; }
function fileExists(file) { try { return Boolean(file && fs.statSync(file).isFile()); } catch { return false; } }
function fileName(file) { return file ? path.basename(file) : ''; }
function now() { return new Date().toISOString(); }
function normalizePort(value = '') { return String(value || '').trim().toUpperCase(); }

const GUIDANCE = Object.freeze({
  'adapter-conflict-process': {
    category: 'session-guard', severity: 'blocked', title: 'Another OBD or serial application may own the adapter',
    summary: 'TunIQ stopped before launching PCM Hammer because a high-confidence conflicting process was detected. The adapter was not opened and project evidence was not changed.',
    actions: ['Close the named OBD, PCM Hammer, logger, or serial-terminal process.', 'Do not redo the verified reads or stock clone.', 'Retry the failed Test Write after the Hardware Session Guard reports clear.']
  },
  'safety-snapshot-failed': {
    category: 'safety-vault', severity: 'blocked', title: 'The project safety snapshot could not be verified',
    summary: 'TunIQ blocked Test Write or writing before hardware access because it could not create a hash-verified project snapshot.',
    actions: ['Check free disk space and permissions in the TunIQ Backups folder.', 'Keep the project open and do not manually move its verified evidence.', 'Retry only after a verified snapshot can be created.']
  },
  'bus-speed-interference': {
    category: 'vehicle-network', severity: 'blocked', title: 'Vehicle bus traffic interrupted the PCM Hammer session',
    summary: 'PCM communication began, but the log explicitly indicated 1x/4x bus traffic interference or collision. This is different from a COM-port opening failure.',
    actions: ['Preserve the complete log and keep ignition and voltage stable.', 'Disconnect unnecessary aftermarket modules or devices that may transmit on the diagnostic bus.', 'Use the normal PCM Hammer interface to retry with its faster-bus option disabled when that option is available; TunIQ will not guess an unsupported CLI flag.']
  },

  'adapter-not-detected': { title: 'OBDLink adapter was not detected', summary: 'Windows did not expose a matching OBDLink Bluetooth or serial device.', action: 'Wake or re-pair the adapter, then refresh the connection.' },
  'missing-outgoing-port': { title: 'Bluetooth outgoing port is missing', summary: 'Windows sees Bluetooth serial service data but no usable outgoing/client COM port.', action: 'Remove and re-pair OBDLink MX+, then refresh the connection.' },
  'ports-unavailable': { title: 'Detected adapter ports are unavailable', summary: 'TunIQ found candidate ports but Windows would not provide an openable serial handle.', action: 'Close other OBD apps, wake the adapter, and retry connection validation.' },
  'adapter-identity-unverified': { title: 'Adapter identity could not be verified', summary: 'A serial device answered, but TunIQ did not receive a recognized OBDLink/STN identity.', action: 'Choose the actual OBDLink outgoing port or re-pair the adapter, then retry.' },
  'connection-broker-failed': { title: 'Adapter Connection Broker failed', summary: 'TunIQ could not complete its live open-and-identify preflight.', action: 'Refresh the connection and export the hardware report if this repeats.' },
  'adapter-handoff-failed': { title: 'Windows changed the port during handoff', summary: 'TunIQ verified the adapter, closed its test handle, and PCM Hammer could not claim the same verified port.', action: 'Wake the adapter and retry once. TunIQ will not scan or repeat other COM ports in this session.' },
  'adapter-open-timeout': {
    category: 'connection', severity: 'blocked', title: 'Windows did not finish opening the adapter port',
    summary: 'PCM Hammer never reached the PCM. TunIQ released its own serial handles, but the Windows Bluetooth serial port remained unavailable or timed out.',
    actions: ['Leave the verified project evidence unchanged.', 'Keep the OBDLink paired and close any other scan or tuning program.', 'Retry the failed Test Write; TunIQ will retry the selected port once, rescan Windows, and try the best Bluetooth sibling port.']
  },
  'adapter-open-failed': {
    category: 'connection', severity: 'blocked', title: 'PCM Hammer could not open an adapter port',
    summary: 'The failure happened before PCM communication. The protected reads and commissioning stock clone were not changed.',
    actions: ['Do not redo Read Properties or either full read.', 'Confirm the OBDLink is connected in Windows Bluetooth settings and no other program owns its COM port.', 'Retry the failed step and let TunIQ use its remembered and rescanned COM-port candidates.']
  },
  'adapter-locked': {
    category: 'connection', severity: 'blocked', title: 'Another process still owns the adapter',
    summary: 'Windows reported the serial device as busy, locked, or access denied before PCM communication began.',
    actions: ['Close PCM Hammer, terminal windows, serial monitors, and other OBD software.', 'Use Clear Stuck COM State once, then retry the same Test Write.', 'Do not reset the project or create another read pair.']
  },
  'adapter-disconnected': {
    category: 'connection', severity: 'blocked', title: 'The adapter disconnected during the operation',
    summary: 'PCM communication began and then the interface or Bluetooth link dropped.',
    actions: ['Keep ignition and power stable.', 'Reconnect the OBDLink and retry only the failed step.', 'Inspect the attempt logs before changing ports if the disconnect repeats.']
  },
  'kernel-files-missing': {
    category: 'installation', severity: 'blocked', title: 'PCM Hammer kernel or loader files are missing',
    summary: 'Test Write cannot run safely without the matching Kernel-*.bin and Loader-*.bin files from the complete PCM Hammer package.',
    actions: ['Re-extract the complete PCM Hammer release instead of copying only the executable.', 'Keep the CLI, GUI, kernels, and loaders together.', 'Retry Test Write after TunIQ shows a valid kernel directory.']
  },
  'integrated-cli-profile-unresolved': {
    category: 'installation', severity: 'blocked', title: 'The installed PCM Hammer CLI syntax is not proven',
    summary: 'TunIQ refused to guess a write-related command after the CLI rejected every safely testable profile.',
    actions: ['Keep the current project evidence.', 'Verify the configured executable is the real PCM Hammer 2.x CLI.', 'Run the capability probe, then retry the same step.']
  },
  'unsupported-cli': {
    category: 'installation', severity: 'blocked', title: 'The configured executable is not recognized as PCM Hammer CLI',
    summary: 'TunIQ blocked the operation before hardware communication to avoid launching an unknown program with controller-write arguments.',
    actions: ['Select the actual PCM Hammer CLI executable.', 'Keep the complete portable PCM Hammer folder intact.', 'Probe capabilities and retry.']
  },
  'cli-not-found': {
    category: 'installation', severity: 'blocked', title: 'PCM Hammer CLI is not configured',
    summary: 'No recognized PCM Hammer command-line executable could be found.',
    actions: ['Open Tool Setup and select the PCM Hammer installation.', 'Use the complete extracted package.', 'Return to the same project and retry Test Write.']
  },
  'power-proof-missing': {
    category: 'power', severity: 'blocked', title: 'Power evidence is required before Test Write',
    summary: 'TunIQ could not confirm live voltage or a regulated bench supply.',
    actions: ['Enter the observed voltage or confirm regulated bench power.', 'Use a stable battery/charger setup.', 'Retry Test Write without changing the project files.']
  },
  'voltage-low': {
    category: 'power', severity: 'blocked', title: 'Voltage is below the safe Test Write threshold',
    summary: 'TunIQ stopped before beginning the write simulation because the supplied voltage was too low.',
    actions: ['Stabilize vehicle or bench voltage above the required threshold.', 'Do not continue while voltage is dropping.', 'Retry the same Test Write after power is stable.']
  },
  'test-write-unproven': {
    category: 'verification', severity: 'blocked', title: 'Test Write did not produce complete proof',
    summary: 'PCM Hammer did not provide the explicit successful Test Write result required for commissioning completion.',
    actions: ['Review the exact PCM Hammer attempt logs.', 'Correct the stated connection, installation, or PCM communication problem.', 'Retry Test Write only; the verified reads and stock clone remain valid.']
  },
  'pcmhammer-failed': {
    category: 'pcmhammer', severity: 'blocked', title: 'PCM Hammer stopped without a proven result',
    summary: 'The process exited without enough evidence to accept the operation as successful.',
    actions: ['Open or export the Hardware Session Report.', 'Use the attempt timeline to identify whether the failure was before or after PCM communication.', 'Retry only the failed step after correcting the reported cause.']
  },
  'properties-incomplete': {
    category: 'evidence', severity: 'blocked', title: 'Controller identity evidence is incomplete',
    summary: 'Read Properties did not include the complete controller, OS, hardware ID, and service-number evidence required by TunIQ.',
    actions: ['Use a complete PCM Hammer Read Properties result.', 'Do not guess the operating system.', 'Resume from Read Properties only.']
  },
  'partial-read': {
    category: 'evidence', severity: 'blocked', title: 'A full read was incomplete',
    summary: 'The produced BIN was missing, partial, or not exactly 524,288 bytes and was not accepted as commissioning evidence.',
    actions: ['Keep any previously verified pair unchanged.', 'Correct the connection or power problem.', 'Only repeat the missing read when no verified pair already exists.']
  }
});

function classifyFailure({ stopCode = '', operation = '', sessionState = '', testWritePassed = false, communicationStarted = false } = {}) {
  if (testWritePassed || (operation === 'testWrite' && sessionState === 'complete')) {
    return {
      category: 'success', severity: 'ready', title: 'PCM Hammer Test Write passed',
      summary: 'The exact validated revision completed Test Write. No real PCM write was performed by Test Write.',
      actions: ['Keep the successful report with the project.', 'Commissioning may be marked complete when the exact revision proof is bound.', 'A real write remains a separate confirmation-gated operation.']
    };
  }
  const code = clean(stopCode, 120);
  if (GUIDANCE[code]) return { stopCode: code, communicationStarted: Boolean(communicationStarted), ...GUIDANCE[code] };
  if (communicationStarted) {
    return {
      stopCode: code || 'pcm-communication-stopped', communicationStarted: true,
      category: 'communication', severity: 'blocked', title: 'PCM communication began but did not finish',
      summary: 'The adapter opened and PCM traffic was detected, so this was not only a Windows COM-port opening failure.',
      actions: ['Review the final PCM Hammer lines and voltage evidence.', 'Keep ignition, power, and the adapter stable.', 'Retry only the failed operation after correcting the reported communication fault.']
    };
  }
  return {
    stopCode: code || 'unknown-hardware-stop', communicationStarted: false,
    category: 'unknown', severity: 'blocked', title: 'Hardware session stopped before success was proven',
    summary: 'TunIQ preserved the project and did not accept an incomplete result.',
    actions: ['Export the Hardware Session Report.', 'Review the exact command, port attempts, exit code, and logs.', 'Retry only the failed step after correcting the identified cause.']
  };
}

function attemptOutcome(attempt = {}) {
  if (attempt.verified || (attempt.identified && attempt.recognized && attempt.available !== false)) return 'adapter identity verified';
  if (attempt.timedOut) return 'adapter verification timed out';
  if (attempt.identified && !attempt.recognized) return 'serial device answered but identity was not accepted';
  if (attempt.kernelMissing) return 'kernel files missing';
  if (attempt.accessBlocked) return 'port locked / access denied';
  if (attempt.openTimeout) return 'port open timeout';
  if (attempt.openFailure) return 'port open failed';
  if (attempt.communicationStarted && Number(attempt.exitCode) === 0) return 'communication completed';
  if (attempt.communicationStarted) return 'PCM communication stopped';
  if (Number(attempt.exitCode) === 0) return 'process exited without proof';
  if (Number.isFinite(Number(attempt.exitCode))) return `process exit ${Number(attempt.exitCode)}`;
  return 'attempt did not finish';
}

function normalizeAttempt(attempt = {}, index = 0) {
  return {
    number: Number(attempt.attempt || index + 1),
    port: clean(attempt.device || attempt.port || '', 40),
    source: clean(attempt.source || '', 120),
    profileId: clean(attempt.profileId || '', 160),
    startedAt: attempt.startedAt || null,
    finishedAt: attempt.finishedAt || null,
    exitCode: Number.isFinite(Number(attempt.exitCode)) ? Number(attempt.exitCode) : null,
    communicationStarted: Boolean(attempt.communicationStarted),
    available: attempt.available !== false,
    identified: Boolean(attempt.identified),
    recognized: Boolean(attempt.recognized),
    verified: Boolean(attempt.verified || (attempt.identified && attempt.recognized && attempt.available !== false)),
    timedOut: Boolean(attempt.timedOut),
    adapter: clean(attempt.adapter || '', 240),
    openTimeout: Boolean(attempt.openTimeout),
    openFailure: Boolean(attempt.openFailure),
    accessBlocked: Boolean(attempt.accessBlocked),
    kernelMissing: Boolean(attempt.kernelMissing),
    outcome: attemptOutcome(attempt),
    stdoutLog: fileExists(attempt.stdoutLog) ? path.resolve(attempt.stdoutLog) : clean(attempt.stdoutLog || '', 1200),
    stderrLog: fileExists(attempt.stderrLog) ? path.resolve(attempt.stderrLog) : clean(attempt.stderrLog || '', 1200),
    excerpt: clean(attempt.excerpt || '', 3000)
  };
}

function pickLatestSession(flash = {}, projectId = '') {
  const active = flash.session && (!projectId || flash.session.projectId === projectId) ? flash.session : null;
  if (active) return active;
  return (Array.isArray(flash.history) ? flash.history : []).find(item => !projectId || item.projectId === projectId) || null;
}

function recommendedPort(flash = {}, session = null) {
  if (flash.lastSuccessfulDevice) return flash.lastSuccessfulDevice;
  const direct = [session?.device, session?.initialDevice, flash.device]
    .map(normalizePort).find(port => port && port !== 'COM1');
  if (direct) return direct;
  const candidates = Array.isArray(session?.deviceCandidates) ? [...session.deviceCandidates] : Array.isArray(flash.lastDeviceCandidates) ? [...flash.lastDeviceCandidates] : [];
  const eligible = candidates.filter(item => {
    const port = normalizePort(item?.port);
    if (!port) return false;
    // COM1 is commonly a motherboard/debug UART. It is never a safe generic fallback;
    // accept it only when Windows/PCM Hammer positively identified the adapter there.
    if (port === 'COM1' && !item.recognized && !item.outgoing) return false;
    return true;
  });
  return eligible
    .sort((a, b) => Number(Boolean(b.outgoing)) - Number(Boolean(a.outgoing))
      || Number(Boolean(b.recognized)) - Number(Boolean(a.recognized))
      || Number(b.recoveryScore || 0) - Number(a.recoveryScore || 0)
      || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }))[0]?.port || '';
}

function buildHardwareSessionReport({ appVersion = '', activeProject = null, p01 = null, p01Auto = null, flash = null } = {}) {
  const flashState = flash || {};
  const projectId = activeProject?.id || p01Auto?.projectId || '';
  const session = pickLatestSession(flashState, projectId);
  const details = session?.technicalDetails || p01Auto?.portRecovery?.technicalDetails || p01Auto?.stop?.details || {};
  const exclusiveGuard = session?.exclusiveGuard || details?.exclusiveGuard || p01Auto?.stop?.details?.exclusiveGuard || null;
  const safetySnapshot = session?.safetySnapshot || details?.safetySnapshot || p01Auto?.stop?.details?.safetySnapshot || null;
  const broker = details?.intelligentConnection || p01Auto?.stop?.details?.intelligentConnection || null;
  const attemptsRaw = session?.deviceAttempts || p01Auto?.portRecovery?.attempts || details?.deviceAttempts || broker?.attempts || [];
  const attempts = (Array.isArray(attemptsRaw) ? attemptsRaw : []).map(normalizeAttempt);
  const stopCode = session?.stopCode || session?.result?.stopCode || p01Auto?.stop?.code || p01Auto?.portRecovery?.code || details?.stopCode || '';
  const communicationStarted = Boolean(details?.communicationStarted || attempts.some(item => item.communicationStarted));
  const operation = session?.operation || (String(p01Auto?.phase || '').includes('test-write') ? 'testWrite' : '');
  const diagnosis = classifyFailure({
    stopCode,
    operation,
    sessionState: session?.state || '',
    testWritePassed: Boolean(session?.testWritePassed),
    communicationStarted
  });
  const dualReadVerified = Boolean(p01?.dualReadVerified);
  const commissioningOnly = Boolean(p01Auto?.commissioningOnly || p01?.definition?.commissioningOnly);
  const actualWriteOperation = ['writeCalibration', 'writeFull', 'recovery'].includes(operation);
  const candidateSource = session?.deviceCandidates || p01Auto?.portRecovery?.candidates || details?.deviceCandidates || broker?.discovery?.candidates || flashState.lastDeviceCandidates || [];
  const candidates = (Array.isArray(candidateSource) ? candidateSource : []).filter(item => item?.port).map(item => ({
    port: clean(item.port, 40), name: clean(item.name || '', 300), source: clean(item.source || '', 120),
    recognized: Boolean(item.recognized), recommended: Boolean(item.recommended), bluetooth: Boolean(item.bluetooth),
    outgoing: Boolean(item.outgoing), incoming: Boolean(item.incoming), recoveryScore: Number(item.recoveryScore || 0)
  }));
  const report = {
    type: 'tuniq-hardware-session-report', schemaVersion: 2, appVersion, generatedAt: now(),
    project: activeProject ? { id: activeProject.id, name: activeProject.name, controller: activeProject.controller || '', os: activeProject.os || '', folder: activeProject.folder || '' } : null,
    workflow: {
      status: p01Auto?.status || 'idle', phase: p01Auto?.phase || 'idle', rawProgress: Number(p01Auto?.progress || 0),
      stopCode: clean(stopCode, 120), resumePhase: p01Auto?.resumePhase || p01Auto?.nextStep || null,
      revision: p01Auto?.revision ? { name: p01Auto.revision.name || fileName(p01Auto.revision.path), path: p01Auto.revision.path || '', sha256: p01Auto.revision.sha256 || '' } : null,
      commissioningOnly
    },
    evidence: {
      controller: p01?.identity?.controller || activeProject?.controller || '', os: p01?.identity?.os || activeProject?.os || '',
      hardwareId: p01?.identity?.hardwareId || '', serviceNumber: p01?.identity?.serviceNumber || '',
      dualReadVerified, canonicalReadSha256: p01?.canonicalReadSha256 || '',
      protectedOriginal: p01?.canonicalPath ? fileName(p01.canonicalPath) : fileName(activeProject?.bin),
      testWriteBound: Boolean(p01?.testWrite), readyForWrite: Boolean(p01?.readyForWrite)
    },
    session: session ? {
      id: session.id || '', operation, state: session.state || '', phase: session.phase || '', startedAt: session.startedAt || null, finishedAt: session.finishedAt || null,
      device: session.device || details?.device || '', initialDevice: session.initialDevice || '', exitCode: Number.isFinite(Number(session.exitCode)) ? Number(session.exitCode) : null,
      stopCode: clean(stopCode, 120), testWritePassed: Boolean(session.testWritePassed), verified: Boolean(session.verified),
      executable: session.executable || details?.executable || flashState.executable || '', args: session.args || details?.args || [],
      commandLine: details?.commandLine || '', kernelDir: session.kernelDir || details?.kernelDir || flashState.kernel?.folder || '',
      kernelFiles: session.kernelFiles || details?.kernelFiles || flashState.kernel?.files || [], sessionLog: details?.sessionLog || session.sessionLog || '',
      communicationStarted, attempts, candidates
    } : {
      id: '', operation, state: '', phase: '', device: details?.device || '', stopCode: clean(stopCode, 120),
      executable: details?.executable || flashState.executable || '', args: details?.args || [], commandLine: details?.commandLine || '',
      kernelDir: details?.kernelDir || flashState.kernel?.folder || '', kernelFiles: details?.kernelFiles || flashState.kernel?.files || [],
      sessionLog: details?.sessionLog || '', communicationStarted, attempts, candidates
    },
    diagnosis: {
      ...diagnosis,
      safeToRetryFailedStep: !actualWriteOperation && diagnosis.severity !== 'ready',
      verifiedEvidencePreserved: dualReadVerified,
      noActualPcmWriteOccurred: !actualWriteOperation,
      recommendedPort: recommendedPort(flashState, session),
      lastSuccessfulDevice: flashState.lastSuccessfulDevice || '',
      lastSuccessfulAt: flashState.lastSuccessfulAt || null
    },
    exclusiveSessionGuard: exclusiveGuard ? {
      blocked: Boolean(exclusiveGuard.blocked), inspectedAt: exclusiveGuard.inspectedAt || null,
      conflicts: Array.isArray(exclusiveGuard.conflicts) ? exclusiveGuard.conflicts : [],
      warnings: Array.isArray(exclusiveGuard.warnings) ? exclusiveGuard.warnings : [],
      cleanedOwnedProcesses: Array.isArray(exclusiveGuard.cleanedOwnedProcesses) ? exclusiveGuard.cleanedOwnedProcesses : []
    } : null,
    safetySnapshot: safetySnapshot ? {
      path: safetySnapshot.path || '', manifestFile: safetySnapshot.manifestFile || '', verified: Boolean(safetySnapshot.verified),
      reused: Boolean(safetySnapshot.reused), fingerprint: safetySnapshot.fingerprint || '', createdAt: safetySnapshot.createdAt || null,
      fileCount: Number(safetySnapshot.fileCount || 0), totalBytes: Number(safetySnapshot.totalBytes || 0), reason: safetySnapshot.reason || ''
    } : null
  };
  return report;
}

function renderHardwareSessionText(report) {
  const lines = [];
  lines.push(`TunIQ Hardware Session Report`, `Generated: ${report.generatedAt}`, `TunIQ: ${report.appVersion || 'unknown'}`, '');
  if (report.project) lines.push(`Project: ${report.project.name}`, `Controller / OS: ${report.evidence.controller || 'unknown'} / ${report.evidence.os || 'unknown'}`);
  lines.push(`Workflow: ${report.workflow.status} / ${report.workflow.phase}`, `Diagnosis: ${report.diagnosis.title}`, `Recovery code: ${report.workflow.stopCode || 'none'}`, '');
  lines.push(report.diagnosis.summary, '');
  lines.push(`Verified matching reads: ${report.evidence.dualReadVerified ? 'YES' : 'NO'}`);
  lines.push(`Protected original SHA-256: ${report.evidence.canonicalReadSha256 || 'not available'}`);
  lines.push(`No actual PCM write occurred: ${report.diagnosis.noActualPcmWriteOccurred ? 'YES' : 'NO'}`);
  lines.push(`Safe to retry failed step: ${report.diagnosis.safeToRetryFailedStep ? 'YES' : 'NO'}`);
  if (report.diagnosis.recommendedPort) lines.push(`Recommended port: ${report.diagnosis.recommendedPort}`);
  lines.push(`Exclusive session guard: ${report.exclusiveSessionGuard ? (report.exclusiveSessionGuard.blocked ? 'BLOCKED' : 'CLEAR') : 'not recorded'}`);
  if (report.exclusiveSessionGuard?.conflicts?.length) for (const item of report.exclusiveSessionGuard.conflicts) lines.push(`- Conflict: ${item.name || 'process'} PID ${item.pid || '?'} — ${item.reason || 'may own adapter'}`);
  lines.push(`Project safety snapshot: ${report.safetySnapshot?.verified ? 'VERIFIED' : 'not recorded'}`);
  if (report.safetySnapshot?.path) lines.push(`Snapshot path: ${report.safetySnapshot.path}`);
  lines.push('');
  lines.push('Next actions:');
  for (const action of report.diagnosis.actions || []) lines.push(`- ${action}`);
  lines.push('', 'PCM Hammer session:');
  lines.push(`Operation: ${report.session.operation || 'none'}`);
  lines.push(`State: ${report.session.state || 'none'}`);
  lines.push(`Device: ${report.session.device || 'none'}`);
  lines.push(`Exit code: ${report.session.exitCode == null ? 'not available' : report.session.exitCode}`);
  lines.push(`Executable: ${report.session.executable || 'not available'}`);
  lines.push(`Kernel directory: ${report.session.kernelDir || 'not available'}`);
  lines.push(`Session log: ${report.session.sessionLog || 'not available'}`);
  lines.push('', 'Port attempt timeline:');
  if (!report.session.attempts.length) lines.push('- No completed port attempts were recorded.');
  for (const attempt of report.session.attempts) {
    lines.push(`- Attempt ${attempt.number}: ${attempt.port || 'automatic device'} — ${attempt.outcome}${attempt.exitCode == null ? '' : ` (exit ${attempt.exitCode})`}`);
    if (attempt.stdoutLog) lines.push(`  stdout: ${attempt.stdoutLog}`);
    if (attempt.stderrLog) lines.push(`  stderr: ${attempt.stderrLog}`);
  }
  return `${lines.join('\n')}\n`;
}

class HardwareSessionDoctor {
  constructor(options = {}) { this.options = options; }
  activeProject() { return this.options.getActiveProject?.() || null; }
  reportsRoot(active = this.activeProject()) { return active?.folder ? ensureDir(path.join(active.folder, 'Reports')) : ensureDir(path.join(this.options.dataRoot(), 'Reports')); }
  build() {
    const activeProject = this.activeProject();
    let p01 = null;
    try { p01 = activeProject ? this.options.getP01Status?.(activeProject) || null : null; } catch {}
    let p01Auto = null;
    try { p01Auto = this.options.getP01AutoState?.() || null; } catch {}
    let flash = null;
    try { flash = this.options.getFlashStatus?.() || {}; } catch { flash = {}; }
    return buildHardwareSessionReport({ appVersion: this.options.appVersion || '', activeProject, p01, p01Auto, flash });
  }
  saveLatest(report = this.build()) {
    const root = this.reportsRoot();
    const jsonFile = path.join(root, 'hardware-session-latest.json');
    const textFile = path.join(root, 'hardware-session-latest.txt');
    fs.writeFileSync(jsonFile, JSON.stringify(report, null, 2), 'utf8');
    fs.writeFileSync(textFile, renderHardwareSessionText(report), 'utf8');
    return { report, jsonFile, textFile };
  }
  export(file, report = this.build()) {
    ensureDir(path.dirname(file));
    const ext = path.extname(file).toLowerCase();
    if (ext === '.txt') fs.writeFileSync(file, renderHardwareSessionText(report), 'utf8');
    else fs.writeFileSync(file, JSON.stringify(report, null, 2), 'utf8');
    this.options.appendActivity?.('hardware-session-report-exported', { file: path.basename(file), stopCode: report.workflow.stopCode || '', projectId: report.project?.id || '' });
    return file;
  }
  latestLog(report = this.build()) {
    const candidates = [report.session.sessionLog, ...report.session.attempts.flatMap(item => [item.stderrLog, item.stdoutLog])];
    return unique(candidates).find(fileExists) || '';
  }
}

module.exports = {
  GUIDANCE,
  classifyFailure,
  normalizeAttempt,
  buildHardwareSessionReport,
  renderHardwareSessionText,
  HardwareSessionDoctor
};
