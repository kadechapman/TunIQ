const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function clean(value, max = 1000) { return String(value ?? '').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, max); }
function safeName(value) { return String(value || 'PCM').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'PCM'; }

const COMMAND_CANDIDATES = {
  identify: ['identify', 'properties', 'read-properties', 'readproperties', 'info'],
  read: ['read', 'read-entire', 'read-entire-pcm', 'read-full', 'readfull'],
  testWrite: ['test-write', 'testwrite'],
  writeCalibration: ['write-calibration', 'writecalibration', 'write-cal', 'writecal'],
  writeFull: ['write-full', 'writefull', 'write-entire'],
  recovery: ['recovery', 'recover', 'recovery-write', 'write-recovery']
};

function tokenizeTemplate(template) {
  if (Array.isArray(template)) return template.map(String);
  const text = String(template || '').trim();
  if (!text) return [];
  const tokens = [];
  let current = ''; let quote = '';
  for (let index = 0; index < text.length; index += 1) {
    const char = text[index];
    if (quote) {
      if (char === quote) quote = '';
      else current += char;
    } else if (char === '"' || char === "'") quote = char;
    else if (/\s/.test(char)) { if (current) { tokens.push(current); current = ''; } }
    else current += char;
  }
  if (current) tokens.push(current);
  return tokens;
}

function expandTemplate(template, values) {
  return tokenizeTemplate(template).map(token => token.replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => values[key] == null ? '' : String(values[key]))).filter(token => token !== '');
}

function parseProgress(line, current = 0) {
  const percent = line.match(/(?:^|\s)(100|[0-9]{1,2})(?:\.\d+)?\s*%/);
  if (percent) return Math.max(current, Number(percent[1]));
  const fraction = line.match(/\b(\d+)\s*(?:\/|of)\s*(\d+)\b/i);
  if (fraction && Number(fraction[2]) > 0) return Math.max(current, Math.min(100, Number(fraction[1]) * 100 / Number(fraction[2])));
  if (/complete|success|verified|finished/i.test(line)) return Math.max(current, 100);
  return current;
}

function parseIdentityText(text) {
  const source = String(text || '');
  const first = patterns => patterns.map(pattern => source.match(pattern)?.[1]).find(Boolean) || '';
  return {
    vin: first([/\bVIN\s*[:=]\s*([A-HJ-NPR-Z0-9]{17})\b/i, /\b([A-HJ-NPR-Z0-9]{17})\b/]),
    os: first([/(?:operating\s*system|\bOS\b|OSID)\s*[:=#-]?\s*(\d{7,9})\b/i]),
    hardwareId: first([/(?:hardware(?:\s*id|\s*number)?|HWID)\s*[:=#-]?\s*([A-Z0-9._-]{4,40})/i]),
    serviceNumber: first([/(?:service\s*(?:number|no\.?|#)|serviceno)\s*[:=#-]?\s*([A-Z0-9._-]{4,40})/i]),
    controller: first([/(?:controller|pcm|ecm)\s*(?:type|family)?\s*[:=#-]\s*([A-Z][A-Z0-9 -]{1,30})/i, /\b(P01|P59|P04|P06|P08|P10|P11|P12|E38|E40|E54|E67)\b/i])
  };
}

function parseBackendIdentity(text, executable = '') {
  const source = String(text || '');
  const version = source.match(/(?:pcm\s*hammer[^0-9]{0,20}|version\s*[:=]?\s*)(\d+\.\d+(?:\.\d+)?(?:[-+a-z0-9.]*)?)/i)?.[1] || source.match(/\b(2\.\d+(?:\.\d+)?)\b/)?.[1] || '';
  const major = Number((version.match(/^(\d+)/) || [])[1] || 0);
  const product = /pcm\s*hammer/i.test(source) || /pcmhammer/i.test(executable) ? 'PCM Hammer' : '';
  return { product, version, major, official: product === 'PCM Hammer' && major >= 2 };
}

function inferTemplates(helpText) {
  const lower = String(helpText || '').toLowerCase();
  const commands = new Set();
  for (const line of String(helpText || '').split(/\r?\n/)) {
    const match = line.match(/^\s{0,8}([a-z][a-z0-9_-]{1,40})(?:\s{2,}|\s+-|\s+<)/i);
    if (match) commands.add(match[1].toLowerCase());
  }
  const pick = operation => COMMAND_CANDIDATES[operation].find(candidate => commands.has(candidate) || new RegExp(`^\\s*${candidate.replace(/-/g, '[- ]?')}(?:\\s|$)`, 'im').test(String(helpText || '')));
  const deviceOption = /--device\b/.test(lower) ? '--device' : /--interface\b/.test(lower) ? '--interface' : /--port\b/.test(lower) ? '--port' : null;
  const inputOption = /--input\b/.test(lower) ? '--input' : /--file\b/.test(lower) ? '--file' : /--bin\b/.test(lower) ? '--bin' : null;
  const outputOption = /--output\b/.test(lower) ? '--output' : /--file\b/.test(lower) ? '--file' : /--bin\b/.test(lower) ? '--bin' : null;
  const make = (command, io) => {
    if (!command) return null;
    const args = [command];
    if (deviceOption) args.push(deviceOption, '{device}');
    if (io === 'input' && inputOption) args.push(inputOption, '{input}');
    if (io === 'output' && outputOption) args.push(outputOption, '{output}');
    return args;
  };
  return {
    identify: make(pick('identify')),
    read: make(pick('read'), 'output'),
    testWrite: make(pick('testWrite'), 'input'),
    writeCalibration: make(pick('writeCalibration'), 'input'),
    writeFull: make(pick('writeFull'), 'input'),
    recovery: make(pick('recovery'), 'input')
  };
}

class FlashManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.getToolPath = options.getToolPath;
    this.getDeviceStatus = options.getDeviceStatus || (() => ({}));
    this.appendActivity = options.appendActivity || (() => {});
    this.emit = options.emit || (() => {});
    this.onReadComplete = options.onReadComplete || (() => {});
    this.onIdentifyComplete = options.onIdentifyComplete || (() => {});
    this.onSessionComplete = options.onSessionComplete || (() => {});
    this.session = null;
    this.history = null;
  }

  configFile() { return path.join(this.dataRoot(), 'Tools', 'pcmhammer-cli.json'); }
  sessionsRoot() { return ensureDir(path.join(this.dataRoot(), 'Logs', 'Flash')); }
  historyFile() { return path.join(this.sessionsRoot(), 'history.json'); }
  getHistory() { if (!Array.isArray(this.history)) this.history = readJson(this.historyFile(), []); return Array.isArray(this.history) ? this.history : []; }
  recordHistory(session) {
    const summary = { ...session, child: undefined, log: Array.isArray(session.log) ? session.log.slice(-80) : [] };
    const history = this.getHistory(); history.unshift(summary); if (history.length > 100) history.length = 100;
    this.history = history; writeJson(this.historyFile(), history); return summary;
  }
  getConfig() {
    return readJson(this.configFile(), {
      executable: '', prefixArgs: [], device: '', mode: 'auto', probedAt: null, helpText: '',
      templates: { identify: null, read: null, testWrite: null, writeCalibration: null, writeFull: null, recovery: null }
    });
  }
  saveConfig(patch = {}) {
    const current = this.getConfig();
    const next = { ...current, ...patch, templates: { ...current.templates, ...(patch.templates || {}) }, updatedAt: new Date().toISOString() };
    writeJson(this.configFile(), next);
    return next;
  }

  resolveExecutable() {
    const config = this.getConfig();
    const configured = config.executable;
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const candidates = [];
    if (configured) candidates.push(configured);
    if (toolPath) {
      candidates.push(toolPath);
      const folder = path.dirname(toolPath);
      for (const name of ['PcmHammerCLI.exe','PCM Hammer CLI.exe','pcmhammer-cli.exe','PcmHammer.Console.exe']) candidates.push(path.join(folder, name));
    }
    for (const candidate of candidates) {
      try { if (fs.statSync(candidate).isFile()) return { executable: candidate, prefixArgs: Array.isArray(config.prefixArgs) ? config.prefixArgs : [] }; } catch {}
    }
    return null;
  }

  async runCapture(executable, args, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const child = spawn(executable, args, { windowsHide: true, cwd: path.dirname(executable) });
      let stdout = ''; let stderr = '';
      const timer = setTimeout(() => { try { child.kill(); } catch {} reject(new Error('PCM Hammer CLI probe timed out.')); }, timeout);
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => { clearTimeout(timer); resolve({ code, stdout, stderr, text: `${stdout}\n${stderr}`.trim() }); });
    });
  }

  async probe(payload = {}) {
    if (payload.executable) this.saveConfig({ executable: payload.executable, prefixArgs: payload.prefixArgs || [] });
    const resolved = this.resolveExecutable();
    if (!resolved) throw new Error('PCM Hammer CLI was not found. Install PCM Hammer 2.x and browse to PcmHammerCLI.exe in Tool Setup.');
    let result = null;
    const attempts = [['--help'], ['-h'], ['help']];
    for (const attempt of attempts) {
      try {
        result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt]);
        if (result.text && result.text.length > 20) break;
      } catch {}
    }
    if (!result?.text) throw new Error('PCM Hammer CLI did not return help output. Verify that the CLI executable, not only the WinForms app, is configured.');
    let versionText = '';
    for (const attempt of [['--version'], ['-v'], ['version']]) {
      try { const versionResult = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt], 8000); if (versionResult.text) { versionText = versionResult.text; break; } } catch {}
    }
    const backend = { ...parseBackendIdentity(`${versionText}\n${result.text}`, resolved.executable), sha256: sha256(resolved.executable), executable: resolved.executable };
    const inferred = inferTemplates(result.text);
    const config = this.saveConfig({ executable: resolved.executable, prefixArgs: resolved.prefixArgs, helpText: result.text.slice(0, 50000), versionText: versionText.slice(0, 5000), backend, templates: inferred, probedAt: new Date().toISOString() });
    const capabilities = Object.fromEntries(Object.entries(config.templates).map(([key, value]) => [key, Boolean(value)]));
    return { executable: resolved.executable, backend, capabilities, templates: config.templates, help: result.text.slice(0, 12000), probedAt: config.probedAt };
  }

  status() {
    const resolved = this.resolveExecutable();
    const config = this.getConfig();
    return {
      configured: Boolean(resolved),
      executable: resolved?.executable || null,
      backend: config.backend || null,
      capabilities: Object.fromEntries(Object.entries(config.templates || {}).map(([key, value]) => [key, Boolean(value)])),
      templates: config.templates || {},
      session: this.session ? { ...this.session, child: undefined } : null,
      device: config.device || '',
      probedAt: config.probedAt || null,
      history: this.getHistory().slice(0, 30)
    };
  }

  saveDevice(device) { return this.saveConfig({ device: clean(device, 200) }); }
  saveTemplates(templates) {
    const normalized = {};
    for (const operation of Object.keys(COMMAND_CANDIDATES)) {
      const template = templates?.[operation];
      if (template == null || String(Array.isArray(template) ? template.join(' ') : template).trim() === '') { normalized[operation] = null; continue; }
      const text = String(Array.isArray(template) ? template.join(' ') : template);
      if (['testWrite','writeCalibration','writeFull','recovery'].includes(operation) && !text.includes('{input}')) throw new Error(`${operation} command template must include {input}.`);
      if (operation === 'read' && !text.includes('{output}')) throw new Error('Read command template must include {output}.');
      normalized[operation] = tokenizeTemplate(template);
    }
    return this.saveConfig({ templates: normalized });
  }

  preflight(operation, payload = {}) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const config = this.getConfig();
    const resolved = this.resolveExecutable();
    if (!resolved) throw new Error('Configure PCM Hammer CLI in Tool Setup first.');
    const template = config.templates?.[operation];
    if (!template) throw new Error(`PCM Hammer CLI did not advertise a safe ${operation} command. Re-probe the CLI or configure its command template.`);
    const templateText = Array.isArray(template) ? template.join(' ') : String(template);
    if (['testWrite','writeCalibration','writeFull','recovery'].includes(operation) && !templateText.includes('{input}')) throw new Error(`${operation} command template is missing the required {input} placeholder.`);
    if (operation === 'read' && !templateText.includes('{output}')) throw new Error('Read command template is missing the required {output} placeholder.');
    if (this.session) throw new Error('Another flash operation is already running.');
    const deviceStatus = this.getDeviceStatus() || {};
    const voltage = Number(payload.voltage ?? deviceStatus.connection?.voltage);
    const values = {
      device: payload.device || config.device || deviceStatus.connection?.port || '',
      port: payload.device || config.device || deviceStatus.connection?.port || '',
      project: active.folder,
      controller: active.controller || '',
      input: payload.input || '',
      output: payload.output || ''
    };
    if (!values.device && !payload.allowCliDevicePrompt) throw new Error('Select the PCM Hammer interface/device before starting.');
    const writeOperation = ['writeCalibration','writeFull','recovery','testWrite'].includes(operation);
    if (writeOperation) {
      if (!values.input || !fs.existsSync(values.input)) throw new Error('Select an existing revision BIN before writing.');
      if (!active.bin || !fs.existsSync(active.bin)) throw new Error('A protected original BIN is required before any write operation.');
      const sourceSize = fs.statSync(values.input).size;
      const originalSize = fs.statSync(active.bin).size;
      if (sourceSize !== originalSize) throw new Error(`Revision size (${sourceSize}) does not match the protected original (${originalSize}).`);
      if (!Number.isFinite(voltage) && !payload.benchPowerConfirmed) throw new Error('Live voltage is unavailable. Confirm a regulated bench supply or connect a voltage-capable diagnostic adapter.');
      if (Number.isFinite(voltage) && voltage < 12.2) throw new Error(`Voltage is too low for a controlled ${operation === 'testWrite' ? 'test write' : 'write'} (${voltage.toFixed(2)} V).`);
      if (operation !== 'testWrite') {
        const expected = operation === 'writeFull' || operation === 'recovery' ? `FULL WRITE ${active.name}` : `WRITE ${active.name}`;
        if (String(payload.confirmation || '').trim() !== expected) throw new Error(`Type exactly “${expected}” to authorize this operation.`);
        if (!payload.checksumApproved) throw new Error('Checksum and compatibility validation must pass before writing.');
      }
    }
    if (operation === 'read') {
      const output = values.output || path.join(active.folder, 'Originals', `${safeName(active.name)}-PCM-Read-${new Date().toISOString().replace(/[:.]/g, '-')}.bin`);
      ensureDir(path.dirname(output)); values.output = output;
    }
    return { active, config, resolved, template, values, voltage: Number.isFinite(voltage) ? voltage : null };
  }

  start(operation, payload = {}) {
    const preflight = this.preflight(operation, payload);
    const args = [...preflight.resolved.prefixArgs, ...expandTemplate(preflight.template, preflight.values)];
    const session = {
      id: `${Date.now()}-${operation}`,
      operation,
      projectId: preflight.active.id,
      projectName: preflight.active.name,
      executable: preflight.resolved.executable,
      backendSha256: preflight.config?.backend?.sha256 || '',
      backendVersion: preflight.config?.backend?.version || '',
      args,
      input: preflight.values.input || null,
      output: preflight.values.output || null,
      device: preflight.values.device || null,
      voltage: preflight.voltage,
      startedAt: new Date().toISOString(),
      state: 'running',
      progress: 0,
      phase: 'Starting PCM Hammer CLI',
      log: []
    };
    const child = spawn(preflight.resolved.executable, args, { windowsHide: true, cwd: preflight.active.folder });
    session.child = child;
    this.session = session;
    const sessionLog = path.join(this.sessionsRoot(), `${session.id}.log`);
    const emit = () => this.emit('flash:progress', { ...session, child: undefined });
    const voltageTimer = setInterval(() => {
      const live = Number(this.getDeviceStatus()?.connection?.voltage);
      if (Number.isFinite(live)) { session.voltage = live; if (['writeCalibration','writeFull','recovery'].includes(operation) && live < 12.0) session.voltageWarning = `Critical voltage ${live.toFixed(2)} V — do not disconnect power or interface.`; emit(); }
    }, 1000);
    const append = (stream, chunk) => {
      const text = chunk.toString();
      fs.appendFileSync(sessionLog, text, 'utf8');
      for (const line of text.split(/\r?\n/).filter(Boolean)) {
        const entry = { at: new Date().toISOString(), stream, text: clean(line, 2000) };
        session.log.push(entry); if (session.log.length > 500) session.log.shift();
        session.progress = parseProgress(entry.text, session.progress);
        if (/identif|propert/i.test(entry.text)) session.phase = 'Identifying controller';
        else if (/read/i.test(entry.text)) session.phase = 'Reading PCM';
        else if (/erase/i.test(entry.text)) session.phase = 'Erasing flash';
        else if (/write|program/i.test(entry.text)) session.phase = 'Writing flash';
        else if (/verif/i.test(entry.text)) session.phase = 'Verifying';
        if (/verif(?:ication|y).*?(?:success|pass|complete)|verified\s+success/i.test(entry.text)) session.verified = true;
        if (/voltage\s*[:=]?\s*(\d+(?:\.\d+)?)\s*v/i.test(entry.text)) session.voltage = Number(entry.text.match(/voltage\s*[:=]?\s*(\d+(?:\.\d+)?)\s*v/i)[1]);
      }
      emit();
    };
    child.stdout?.on('data', chunk => append('stdout', chunk));
    child.stderr?.on('data', chunk => append('stderr', chunk));
    child.on('error', error => {
      clearInterval(voltageTimer);
      session.state = 'failed'; session.error = error.message; session.finishedAt = new Date().toISOString(); session.finalized = true; emit();
      this.recordHistory(session); this.session = null;
    });
    child.on('close', async code => {
      clearInterval(voltageTimer);
      if (session.finalized) return;
      session.exitCode = code;
      session.finishedAt = new Date().toISOString();
      session.state = session.cancelRequested ? 'cancelled' : code === 0 ? 'complete' : 'failed';
      if (code === 0) session.progress = 100;
      const combinedLog = session.log.map(item => item.text).join('\n');
      const fatalOutput = /\b(error|failed|failure|aborted|unable to|mismatch)\b/i.test(combinedLog);
      if (operation === 'testWrite' && code === 0 && !fatalOutput) {
        session.testWritePassed = true;
        session.verified = true;
        session.phase = 'Test Write passed';
        session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'PCM Hammer CLI exited successfully without a failure result. TunIQ recorded this exact revision as a passed Test Write.' });
      }
      if (code === 0 && ['writeCalibration','writeFull','recovery'].includes(operation) && !session.verified) {
        session.state = 'complete-unverified';
        session.verificationWarning = 'PCM Hammer exited successfully but TunIQ did not detect an explicit verification-pass message. Treat this operation as unverified and re-identify/read before driving.';
        session.log.push({ at: new Date().toISOString(), stream: 'safety', text: session.verificationWarning });
      }
      if (operation === 'identify' && code === 0) {
        session.identity = parseIdentityText(session.log.map(item => item.text).join('\n'));
        try { await this.onIdentifyComplete(session.identity, session); } catch (error) { session.identityWarning = error.message; }
      }
      if (operation === 'read' && code === 0 && session.output && fs.existsSync(session.output)) {
        session.outputInfo = { path: session.output, name: path.basename(session.output), size: fs.statSync(session.output).size, sha256: sha256(session.output) };
        try { await this.onReadComplete(session.output, session.outputInfo, session); } catch (error) { session.importWarning = error.message; }
      }
      this.appendActivity(`flash-${operation}-${session.state}`, { projectId: session.projectId, projectName: session.projectName, input: session.input ? path.basename(session.input) : null, output: session.output ? path.basename(session.output) : null, exitCode: code, sessionLog });
      try { await this.onSessionComplete({ ...session, child: undefined }); } catch (error) { session.sessionCompletionWarning = error.message; }
      session.finalized = true; this.recordHistory(session);
      emit(); this.session = null;
    });
    this.appendActivity(`flash-${operation}-started`, { projectId: session.projectId, projectName: session.projectName, device: session.device, voltage: session.voltage });
    emit();
    return { ...session, child: undefined };
  }

  async cancel() {
    if (!this.session?.child) return this.status();
    const session = this.session;
    if (['writeCalibration','writeFull','recovery'].includes(session.operation) && /eras|writ|program|verif/i.test(session.phase || '')) {
      session.cancelBlocked = true;
      session.phase = 'Cancellation blocked during critical flash phase';
      session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'TunIQ will not terminate PCM Hammer during erase/write/verify. Maintain power and allow the recovery-capable operation to finish.' });
      this.emit('flash:progress', { ...session, child: undefined });
      return this.status();
    }
    session.cancelRequested = true; session.phase = 'Safe cancellation requested';
    try {
      if (process.platform === 'win32' && session.child.pid) spawn('taskkill.exe', ['/PID', String(session.child.pid), '/T', '/F'], { windowsHide: true });
      else session.child.kill('SIGTERM');
    } catch {}
    this.emit('flash:progress', { ...session, child: undefined });
    return this.status();
  }
}

module.exports = { FlashManager, inferTemplates, expandTemplate, parseProgress, parseIdentityText, parseBackendIdentity };
