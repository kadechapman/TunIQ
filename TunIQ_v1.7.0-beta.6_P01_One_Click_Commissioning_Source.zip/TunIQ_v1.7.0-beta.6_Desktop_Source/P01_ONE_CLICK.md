# P01 One-Click Commissioning

TunIQ v1.7.0-beta.6 adds a guided automation runner for the first GM P01 workflow.

## Automated sequence

After the project is set to P01 and the official PCM Hammer 2.x Windows CLI is configured, One-Click mode can:

1. Check the Public Beta agreement, interface, voltage or regulated bench-power confirmation, and requested-tune permissions.
2. Identify the connected controller and require P01, OS, hardware ID, and service number.
3. Run two independent full 512 KB reads.
4. Run a third read automatically when the first two differ, then accept only a matching two-of-three result.
5. Protect the verified matching read as the original.
6. Search local project, TunIQ compatibility, Downloads, and TunIQ Documents folders for an XDF declaring the exact detected OS.
7. Bind an unambiguous clean XDF to the verified original.
8. Map only unambiguous cells for the requested RPM limiter, speed limiter, and conservative ghost-idle roles.
9. Create a new revision without modifying the original.
10. Correct supported XDF checksums, validate the exact revision fingerprint, and run PCM Hammer Test Write.
11. Stop at **Ready to Write**.

## What still requires a person

TunIQ pauses instead of guessing when identity proof is incomplete, reads do not match, no exact-OS XDF is available, several definitions or parameter groups are equally plausible, mapping warnings exist, checksum proof is unavailable, or Test Write fails.

A real Calibration Write is never started silently. After Test Write passes, the user must review the exact revision and type `WRITE <project name>` to authorize the separate write operation.

## Ghost-idle boundary

The beta.6 ghost-idle action is conservative and reversible. It uses only commissioned idle-spark, idle-airflow, and desired-idle cells exposed by the exact OS definition. It is not a universal professional ghost-cam recipe and must be verified by hot-idle, in-gear, A/C-load, brake-vacuum, restart, fuel-trim, and knock logs.

## Hardware boundary

The automated tests use generated P01 files and a mock PCM Hammer CLI. They do not prove a physical PCM, adapter, Bluetooth/USB connection, bench harness, or power supply. Maintain stable power and stop on any communication or voltage problem.
