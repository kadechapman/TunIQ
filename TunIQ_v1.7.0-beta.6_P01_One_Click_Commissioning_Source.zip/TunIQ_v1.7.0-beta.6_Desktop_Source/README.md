# TunIQ v1.7.0-beta.6 — P01 One-Click Commissioning

TunIQ is a beginner-first Windows tuning workspace. This release focuses on one real controller path: **GM P01** through the official PCM Hammer 2.x Windows CLI.

## What beta.6 adds

- A persistent **Start One-Click P01 Setup** runner.
- Automatic controller identification and complete P01 identity proof.
- Two full 512 KB reads, with an automatic third tie-breaker read when necessary.
- SHA-256 comparison and automatic protected-original promotion only after a matching pair exists.
- Local discovery of XDFs that explicitly declare the detected OS.
- Automatic exact-OS definition binding only when the choice is unambiguous and the mapping loads cleanly.
- Strict automatic calibration-role selection for RPM limit, vehicle-speed limit, and conservative ghost-idle cells.
- Automatic revision creation, supported checksum correction, exact-file validation, and PCM Hammer Test Write.
- Pause/resume behavior when anything is missing or ambiguous.
- One separate typed confirmation before any real Calibration Write.

## P01 workflow

1. Create or activate a project and set its controller to P01.
2. Configure the official PCM Hammer 2.x Windows CLI and enter the interface plus voltage or regulated bench-power confirmation.
3. Open P01 Commissioning, review the tune request and safety confirmations, and press **Start One-Click P01 Setup**.
4. TunIQ runs Identify, matching reads, exact-OS XDF selection, strict parameter mapping, revision creation, checksum validation, and Test Write.
5. When the status reaches **Ready to Write**, review the generated revision.
6. Type `WRITE <project name>` to deliberately authorize the separate Calibration Write.

TunIQ stops instead of guessing when a required proof, definition, checksum, or unambiguous table mapping is unavailable. See `P01_ONE_CLICK.md`.

## What this does not claim

Automated tests verify the software gates with generated BIN/XDF files and a mock PCM Hammer process. They cannot prove your physical adapter, Bluetooth connection, wiring, power supply, exact XDF, or PCM. The first real Identify, dual read, Test Write, and write are the hardware validation.

TunIQ never silently flashes a controller. A write remains a separate action with compatibility, voltage/power, checksum, exact-file, and typed authorization checks.

## Other included systems

- OBDLink phone-log import and local browser `.tuniqlog` creator
- Live logging and enhanced PID profile import
- AI log review and evidence-based MAF/VE/idle proposals
- Tune Library, Community foundation, Garage and project revisions
- Public-beta privacy, diagnostics, installer/update, and feedback foundations

## Install from source

1. Extract into a new local folder.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Keep project data under `%APPDATA%\TunIQ`.

## Validate the build

```bat
npm run check
npm test
```

TunIQ remains `UNLICENSED` until its owner deliberately chooses a public license or proprietary distribution terms.
