# P01 Tonight Checklist

Do not skip a red step.

## Before connecting

- Use PCM Hammer 2.0.0 Windows CLI/WinForms from the official release.
- Connect a stable 12.5–14 V source with adequate current.
- Close other OBD programs.
- Prevent the PC from sleeping.
- Have the exact P01 XDF available only after the OS is identified.

## In TunIQ

1. Create the project and select **P01**.
2. Open **Flash Center** and probe PCM Hammer CLI.
3. Press **Identify P01**. When service number is missing, save Read Properties and press **Import Read Properties**.
4. Run **Full Read** twice. Use **Import 2–3 Reads** when the reads were made in PCM Hammer GUI.
5. Stop immediately if no two reads match.
6. Import the exact-OS XDF and load Calibration.
7. Press **Confirm Exact XDF** and type the OS.
8. In **Full AI**, describe the request and fill required hardware confirmations.
9. Verify the proposed table/cells. Select the action and press **Confirm These P01 Parameters**.
10. Rebuild the action sheet, approve the commissioned cells, and export the revision.
11. Open Checksums and validate the exact revision. Import its Universal Patcher report when required.
12. Select that revision in Flash Center and run **Test Write**. A GUI result can be imported with **Import Test Write Result**.
13. Calibration Write stays locked until every step is green.
14. For the first physical write, prefer a spare/bench PCM. Save all logs.

## Stop conditions

Do not write when:

- The controller is not reported as P01.
- OS, hardware ID, or service number is missing.
- Two reads do not match.
- The XDF is for another OS or has mapping/address warnings.
- The requested cells were not commissioned.
- Checksum/layout validation is not valid.
- Test Write fails or used a different revision.
- Voltage/power is unstable.
- Bluetooth or the interface disconnects.
