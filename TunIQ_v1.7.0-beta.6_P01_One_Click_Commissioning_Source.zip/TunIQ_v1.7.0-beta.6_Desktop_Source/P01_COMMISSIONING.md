# P01 Live Commissioning Guide

TunIQ beta.4 will not create or expose a P01 calibration write from one unverified file.

## Evidence required

### Controller identity

The proof must contain:

- Controller: P01
- Operating system number
- Hardware ID
- Service number

Use the managed **Identify Controller** action. When the CLI output omits a field, save PCM Hammer's Read Properties output as `.txt` or `.log` and use **Import Read Properties**.

### Matching reads

Each full P01 image must be exactly 524,288 bytes. TunIQ requires two matching SHA-256 fingerprints. If the first two differ, a third read can establish a matching 2-of-3 majority. No matching pair means no Full AI tune and no write.

### Exact definition

The XDF filename or title must include the detected OS. Load the verified original and XDF in Calibration, resolve mapping warnings, press **Confirm Exact XDF**, and type the OS exactly. This binds the XDF SHA, original BIN SHA, and OS.

### Exact AI parameters

The first action sheet is a mapping candidate. Confirm only actions whose displayed table/cells you verified against the exact XDF. TunIQ stores those addresses for this OS/XDF/original. Rebuild the action sheet; the second sheet uses the commissioned map and can be approved.

Ghost idle is allowed only after the exact idle spark/airflow/speed parameters are commissioned. The included profile is mild and reversible; it is not a universal camshaft calibration and it does not replace proper mechanical tuning.

### Revision and Test Write

The exact revision must have:

- P01 size/layout match
- Valid native checksum result or a valid Universal Patcher report bound to its SHA-256
- Successful PCM Hammer Test Write on the same file and controller identity

A renamed but byte-identical file keeps the same proof. A one-byte change invalidates it.

## Power and connection

Use a known PCM Hammer-supported interface and stable power. Bluetooth instability, voltage loss, a sleeping laptop, loose OBD wiring, or another app holding the adapter can interrupt operations. Do not start a write when any commissioning step is red.

## Recovery

Keep the two matching original reads in multiple locations. Recovery remains an Advanced operation. Do not improvise recovery commands; use the operation supported by the installed PCM Hammer backend and preserve its complete log.
