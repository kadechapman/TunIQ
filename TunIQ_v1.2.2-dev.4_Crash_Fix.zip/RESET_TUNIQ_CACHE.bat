@echo off
setlocal
set CACHE=%APPDATA%\tuniq-desktop
if exist "%CACHE%" (
  echo Removing Electron cache only. Your vehicles and projects in Documents\TunIQ will not be deleted.
  rmdir /s /q "%CACHE%"
)
echo Cache reset complete.
pause
endlocal
