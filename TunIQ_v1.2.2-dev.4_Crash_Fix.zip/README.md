# TunIQ v1.2.2-dev.4

This build fixes the Garage and adds honest project-aware integration with external tuning tools.

## What works
- Add, edit, and delete persistent vehicles
- Vehicle profiles survive upgrades in `Documents\TunIQ\Vehicles`
- Garage vehicles populate Tune Workflow
- Create a project and set it as the active project
- Tool launches are recorded with the active project context
- AI Coach can use Garage/project/controller/OS context and launch history
- PCM Hammer, TunerPro, and Universal Patcher are launched as separate native Windows programs

## Integration limitation
TunIQ currently performs project-aware handoff and activity tracking. It does not yet read every click, table edit, or live value inside external programs. Deeper file watching and import-back synchronization are planned next.

## Windows
1. Extract the ZIP fully.
2. Double-click `INSTALL_AND_RUN_WINDOWS.bat` the first time.
3. Use `START_TUNIQ_WINDOWS.bat` afterward.
