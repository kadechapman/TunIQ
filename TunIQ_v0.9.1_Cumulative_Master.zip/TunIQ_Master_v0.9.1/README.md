# TunIQ v0.9.1 Cumulative Master

Open `OPEN_TUNIQ_WINDOWS.bat` on Windows. It starts a loopback-only PowerShell bridge and opens the self-contained app. Normal use does not require Node.js.

## v0.9.1 integration proof
- Detect PCM Hammer, TunerPro/TunerPro RT, and Universal Patcher
- Save custom executable paths
- Launch each detected utility
- List Windows COM ports
- Export an integration diagnostic report

## Safety boundary
TunIQ v0.9.1 does not automate PCM reading, writing, recovery, checksum correction, calibration edits, or flashing. External utilities retain their own controls and safety requirements.


## v0.9.1 startup recovery
The dashboard now loads independently of optional modules. A watchdog dismisses the splash screen, a Continue to Dashboard button is always available, and startup errors are shown in a readable diagnostic panel.
