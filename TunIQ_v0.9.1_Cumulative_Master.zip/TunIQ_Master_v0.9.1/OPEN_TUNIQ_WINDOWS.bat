@echo off
setlocal
cd /d "%~dp0"
start "TunIQ Bridge" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0bridge\TunIQ-Bridge.ps1"
timeout /t 2 /nobreak >nul
start "" "%~dp0TunIQ_Open_Me.html"
exit /b 0
