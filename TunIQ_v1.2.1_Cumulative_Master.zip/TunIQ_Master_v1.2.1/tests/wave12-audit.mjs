import fs from 'node:fs';
const h=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'); const j=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
for(const x of ['id="workflow"','createTuneProject','workflowOriginalFile','workflowReadiness']) if(!h.includes(x)) throw new Error('Missing '+x);
for(const x of ['tuniq-v12-projects','/api/projects/create','SHA-256','data-workflow-tool']) if(!j.includes(x)) throw new Error('Missing '+x);
console.log('Wave 12 audit passed');
