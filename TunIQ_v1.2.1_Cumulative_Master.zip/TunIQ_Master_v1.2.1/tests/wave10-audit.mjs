import fs from 'node:fs';
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
const js=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
for(const token of ['value="guided"','value="manual"','value="fullai"','typingText'])if(!html.includes(token))throw new Error('Missing '+token);
for(const token of ["experienceModes=['guided','manual','fullai']",'modeLabel','bootDelay','aiPacing','Math.max(1200'])if(!js.includes(token))throw new Error('Missing '+token);
console.log('Wave 10 audit passed');
