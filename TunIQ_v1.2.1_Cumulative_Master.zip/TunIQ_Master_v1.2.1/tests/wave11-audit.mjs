import fs from 'node:fs';
const h=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8'); const j=fs.readFileSync(new URL('../js/app.js',import.meta.url),'utf8');
for(const x of ['Download latest','missingToolsModal','bridgeModeBanner']) if(!h.includes(x)) throw new Error('missing '+x);
for(const x of ['downloadMissing','AbortController','v1.1']) if(!j.includes(x)) throw new Error('missing '+x);
console.log('Wave 11 audit passed');
