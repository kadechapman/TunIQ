import fs from 'node:fs';
const h=fs.readFileSync('index.html','utf8'); const j=fs.readFileSync('js/app.js','utf8');
for(const x of ['calTable','studioUndo','studioCompare','studioExport']) if(!h.includes(x)) throw new Error('Missing '+x);
for(const x of ['safe calibration practice sandbox','trainingOnly:true','hardwareWriteLocked']){}
if(!j.includes('trainingOnly:true')||!j.includes('Not a PCM calibration')) throw new Error('Safety labeling missing');
console.log('v0.7 audit passed');
