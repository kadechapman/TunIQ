@echo off
setlocal
cd /d "%~dp0"
echo Starting TunIQ in debug mode...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0Start-TunIQ.ps1"
