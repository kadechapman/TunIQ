@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start-TunIQ.ps1"
if errorlevel 1 (
  echo.
  echo TunIQ did not start normally. The launcher window is staying open so you can read the error.
  pause
)
