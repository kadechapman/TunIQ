# Wave 9 / v0.9 Scope

## Enabled
- Loopback-only PowerShell bridge with no Node.js requirement
- Auto-detection for PCM Hammer, TunerPro/TunerPro RT, and Universal Patcher
- Custom executable-path persistence
- Controlled utility launching
- Windows COM-port inventory
- Project/Tools folder opening
- Integration report export

## Hard locked
- PCM reads and writes
- Flash/recovery commands
- Automated TunerPro edits or XDF selection
- Universal Patcher checksum/patch automation
- Passing unverified BINs into a write workflow
