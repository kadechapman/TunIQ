# Safety boundaries

TunIQ advice is educational and may be incomplete or wrong. Confirm critical specifications using trusted service information and direct measurements.

Never flash a controller from an unverified AI suggestion. Identify exact hardware and OS compatibility, preserve a verified original backup, use a supported interface, maintain stable regulated voltage, validate the file, review every change, and have a documented recovery path.

Correct mechanical, fuel-delivery, wiring, sensor, and diagnostic problems before attempting calibration changes.
