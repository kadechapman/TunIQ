# Wave 11 / v1.1

- Repairs bridge button feedback and timeout handling.
- Adds launch-mode status banner.
- Adds official download controls for PCM Hammer, TunerPro, and Universal Patcher.
- Prompts to download missing tools after a scan.
- Improves launcher bridge readiness check.
- PCM read/write/flash automation remains absent.
