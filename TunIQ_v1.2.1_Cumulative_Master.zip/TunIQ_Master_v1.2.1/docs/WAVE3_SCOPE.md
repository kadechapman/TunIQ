# Wave 3 scope

Wave 3 is the intelligence, memory, and project-management layer. It makes automotive advice context-aware without claiming hardware capabilities.

Included: vehicle/build context, project memory, persistent chat, optional AI backend, local knowledge, task/cost management, build screening, and log summaries.

Excluded: real-time OBD, PCM Hammer automation, BIN parsing/editing, OS definition support, checksums, flashing, and automatic calibration changes.
