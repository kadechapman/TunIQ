# v0.7 Calibration Sandbox

Adds a browser-only training workspace for example calibration tables. Users can practice cell editing, undo changes, compare against a baseline, save local snapshots, and export a clearly labeled practice JSON file. No real BIN parsing, definitions, checksums, controller communication, or flashing are included.
