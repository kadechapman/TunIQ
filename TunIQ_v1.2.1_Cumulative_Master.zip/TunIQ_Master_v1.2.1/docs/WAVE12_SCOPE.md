# Wave 12 / TunIQ v1.2 Scope

TunIQ v1.2 proves the project workflow around real tuning tools without claiming native flashing. It creates organized vehicle project folders, fingerprints original files locally, tracks revisions, launches installed utilities through the bridge, and reports readiness. Automated UI control, checksum correction, calibration definitions, writing, and flashing remain out of scope.
