# v1.1.2 Stability Scope

- Replaced HttpListener with a loopback TcpListener HTTP bridge that does not require URL reservations.
- Added automatic port fallback from 8788 through 8797.
- Added persistent launcher and bridge logs in Data/.
- Added visible offline recovery instead of a disappearing console window.
- Added a debug launcher that keeps PowerShell open.
- Preserved the write/flash safety lock.
