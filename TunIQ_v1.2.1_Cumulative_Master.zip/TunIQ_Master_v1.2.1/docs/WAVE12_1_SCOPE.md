# TunIQ v1.2.1 Stability Scope

- Fix PowerShell child-process argument quoting for install paths containing spaces or parentheses.
- Capture bridge stdout and stderr in Data logs.
- Keep offline recovery and add retry behavior.
- Preserve all v1.2 features.
- PCM writing and flashing remain locked.
