# TunIQ v0.9 Windows Bridge

Uses Windows PowerShell and a loopback-only HTTP listener at `127.0.0.1:8788`. It detects saved/common executable paths, lists Windows COM ports, launches approved `.exe` files, and opens project folders.

The API intentionally contains no PCM read, write, recovery, checksum, TunerPro-editing, or flash command.
