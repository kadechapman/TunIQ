# TunIQ v1.7.0-beta.24 — P01 Setup Finalizer

Beta.24 removes the repeated 48% P01 commissioning dead end. The setup finalizer reconstructs every software prerequisite directly from the two verified reads and project files on disk. It does not depend on the Calibration page, renderer state, cached workspace fingerprints, or a successful Refresh action.

For commissioning-only OS definitions, **Finish P01 Setup** now:

1. Revalidates both distinct 524,288-byte reads and matching SHA-256 hashes.
2. Repairs the protected original from the verified read pair when needed.
3. Verifies or regenerates the exact-OS read-only commissioning definition.
4. Binds it directly from disk with zero writable calibration addresses.
5. Creates one deterministic byte-for-byte stock clone.
6. Writes a full pre-Test-Write audit report.
7. Advances directly to integrated PCM Hammer Test Write.

A corrupt, missing, partial, or mismatched read still stops safely. Tuning and controller writes remain locked until a trustworthy writable exact-OS definition is installed.

See `P01_SETUP_FINALIZER.md` and `TEST_REPORT_v1.7.0-beta.24.md`.
