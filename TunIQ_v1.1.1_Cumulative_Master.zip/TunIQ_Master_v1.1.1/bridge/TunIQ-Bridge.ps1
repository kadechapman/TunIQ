param([int]$Port = 8788)
$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$DataDir = Join-Path $Root 'Data'
$ToolsDir = Join-Path $Root 'Tools'
$ConfigPath = Join-Path $DataDir 'bridge-config.json'
New-Item -ItemType Directory -Force -Path $DataDir,$ToolsDir | Out-Null

function Read-Config { if(Test-Path $ConfigPath){ try { return Get-Content $ConfigPath -Raw | ConvertFrom-Json } catch {} }; return [pscustomobject]@{} }
function Save-Config($cfg){ $cfg | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 $ConfigPath }
function First-Existing([string[]]$paths){ foreach($p in $paths){ if($p -and (Test-Path -LiteralPath $p -PathType Leaf)){ return (Resolve-Path -LiteralPath $p).Path } }; return '' }
function Tool-Inventory {
  $cfg=Read-Config
  $pf=$env:ProgramFiles; $pfx=${env:ProgramFiles(x86)}; $local=$env:LOCALAPPDATA; $app=$env:APPDATA
  $defs=@{
    pcmhammer=@('PCM Hammer', @($cfg.pcmhammer, "$pf\PCM Hammer\PcmHammer.exe", "$pfx\PCM Hammer\PcmHammer.exe", "$local\Programs\PCM Hammer\PcmHammer.exe", "$ToolsDir\PCM Hammer\PcmHammer.exe", "$ToolsDir\PcmHammer.exe"));
    tunerpro=@('TunerPro / TunerPro RT', @($cfg.tunerpro, "$pf\TunerPro RT\TunerPro.exe", "$pfx\TunerPro RT\TunerPro.exe", "$pf\TunerPro\TunerPro.exe", "$pfx\TunerPro\TunerPro.exe", "$local\Programs\TunerPro\TunerPro.exe", "$ToolsDir\TunerPro\TunerPro.exe", "$ToolsDir\TunerPro.exe"));
    universalpatcher=@('Universal Patcher', @($cfg.universalpatcher, "$pf\Universal Patcher\UniversalPatcher.exe", "$pfx\Universal Patcher\UniversalPatcher.exe", "$local\Programs\Universal Patcher\UniversalPatcher.exe", "$ToolsDir\Universal Patcher\UniversalPatcher.exe", "$ToolsDir\UniversalPatcher.exe"))
  }
  $out=[ordered]@{}
  foreach($k in $defs.Keys){ $path=First-Existing $defs[$k][1]; $out[$k]=[ordered]@{label=$defs[$k][0];installed=[bool]$path;path=$path} }
  return $out
}
function Com-Ports { try { @(Get-CimInstance Win32_SerialPort | ForEach-Object { [ordered]@{device=$_.DeviceID;description=$_.Name;manufacturer=$_.Manufacturer;pnpDeviceId=$_.PNPDeviceID} }) } catch { @() } }
function Snapshot { [ordered]@{ok=$true;name='TunIQ Local Windows Bridge';version='1.1.1';platform=[Environment]::OSVersion.VersionString;arch=$env:PROCESSOR_ARCHITECTURE;runtime=$PSVersionTable.PSVersion.ToString();writeLocked=$true;capabilities=[ordered]@{inventory=$true;configurePaths=$true;launchTools=$true;openFolders=$true;readPcm=$false;writePcm=$false;flashPcm=$false;automateTunerPro=$false};comPorts=Com-Ports;tools=Tool-Inventory} }
function Send-Json($ctx,$obj,[int]$status=200){ $json=$obj|ConvertTo-Json -Depth 8; $bytes=[Text.Encoding]::UTF8.GetBytes($json); $ctx.Response.StatusCode=$status; $ctx.Response.ContentType='application/json; charset=utf-8'; $ctx.Response.Headers['Access-Control-Allow-Origin']='*'; $ctx.Response.Headers['Access-Control-Allow-Headers']='content-type'; $ctx.Response.Headers['Access-Control-Allow-Methods']='GET, POST, OPTIONS'; $ctx.Response.ContentLength64=$bytes.Length; $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length); $ctx.Response.Close() }
function Read-Body($ctx){ $reader=New-Object IO.StreamReader($ctx.Request.InputStream,$ctx.Request.ContentEncoding); $text=$reader.ReadToEnd(); if([string]::IsNullOrWhiteSpace($text)){return [pscustomobject]@{}}; return $text|ConvertFrom-Json }

$listener=[Net.HttpListener]::new(); $listener.Prefixes.Add("http://127.0.0.1:$Port/")
try { $listener.Start() } catch { exit 2 }
while($listener.IsListening){
  try {
    $ctx=$listener.GetContext(); $path=$ctx.Request.Url.AbsolutePath.ToLowerInvariant();
    if($ctx.Request.HttpMethod -eq 'OPTIONS'){ Send-Json $ctx ([ordered]@{ok=$true}) 204; continue }
    if($path -eq '/' -or $path -eq '/index.html' -or $path -eq '/tuniq_open_me.html'){ $file=Join-Path $Root 'TunIQ_Open_Me.html'; $bytes=[IO.File]::ReadAllBytes($file); $ctx.Response.StatusCode=200; $ctx.Response.ContentType='text/html; charset=utf-8'; $ctx.Response.ContentLength64=$bytes.Length; $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length); $ctx.Response.Close(); continue }
    if($path -eq '/api/bridge/health'){ Send-Json $ctx (Snapshot); continue }
    if($path -eq '/api/bridge/config' -and $ctx.Request.HttpMethod -eq 'POST'){
      $b=Read-Body $ctx; if($b.tool -notin @('pcmhammer','tunerpro','universalpatcher')){throw 'Unknown tool key'}; $cfg=Read-Config; $cfg|Add-Member -Force NoteProperty $b.tool ([string]$b.path); Save-Config $cfg; Send-Json $ctx (Snapshot); continue
    }
    if($path -eq '/api/bridge/launch' -and $ctx.Request.HttpMethod -eq 'POST'){
      $b=Read-Body $ctx; if($b.tool -notin @('pcmhammer','tunerpro','universalpatcher')){throw 'Unknown tool key'}; $snap=Snapshot; $tool=$snap.tools.($b.tool); $candidate=[string]$b.path; if(-not $candidate){$candidate=$tool.path}; if(-not (Test-Path -LiteralPath $candidate -PathType Leaf)){throw 'Executable not found. Save or paste a valid full .exe path.'}; if([IO.Path]::GetExtension($candidate).ToLowerInvariant() -ne '.exe'){throw 'Only Windows .exe files can be launched.'}; $proc=Start-Process -FilePath $candidate -PassThru; Send-Json $ctx ([ordered]@{ok=$true;label=$tool.label;path=$candidate;pid=$proc.Id;writeLocked=$true}); continue
    }
    if($path -eq '/api/bridge/open-folder' -and $ctx.Request.HttpMethod -eq 'POST'){
      $b=Read-Body $ctx; $target=if($b.kind -eq 'tools'){$ToolsDir}else{$Root}; Start-Process explorer.exe -ArgumentList @($target); Send-Json $ctx ([ordered]@{ok=$true;path=$target}); continue
    }
    Send-Json $ctx ([ordered]@{error='Not found'}) 404
  } catch { try { Send-Json $ctx ([ordered]@{error=$_.Exception.Message;writeLocked=$true}) 400 } catch {} }
}
