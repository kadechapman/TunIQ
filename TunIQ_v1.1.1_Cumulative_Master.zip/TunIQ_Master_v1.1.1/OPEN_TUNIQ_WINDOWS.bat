@echo off
setlocal
cd /d "%~dp0"
start "TunIQ Bridge" /min powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%~dp0bridge\TunIQ-Bridge.ps1"
echo Starting TunIQ Windows Bridge...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ok=$false; 1..30 | %% { try { $r=Invoke-RestMethod -Uri 'http://127.0.0.1:8788/api/bridge/health' -TimeoutSec 1; if($r.ok){$ok=$true;break} } catch {}; Start-Sleep -Milliseconds 250 }; if($ok){Start-Process 'http://127.0.0.1:8788/'} else {Write-Host 'Bridge did not respond. Opening browser-only mode.' -ForegroundColor Yellow; Start-Process '%~dp0TunIQ_Open_Me.html'; Start-Sleep 2}"
exit /b 0
