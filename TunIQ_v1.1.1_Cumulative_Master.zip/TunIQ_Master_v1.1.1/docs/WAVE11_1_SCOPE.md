# v1.1.1 Stability Scope

- Embedded logo uses a safe Base64 data URI.
- Windows launcher opens TunIQ from the local bridge origin.
- Bridge API is same-origin when launched normally.
- Browser-only fallback remains available.
- PCM read/write/flash commands remain absent and locked.
