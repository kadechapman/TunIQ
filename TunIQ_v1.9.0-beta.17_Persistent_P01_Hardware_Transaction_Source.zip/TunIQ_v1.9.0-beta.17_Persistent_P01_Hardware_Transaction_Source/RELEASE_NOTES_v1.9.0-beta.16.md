# TunIQ v1.9.0-beta.16 — Startup Resume-State Reconciliation

## Fixed

- A cancelled or stopped Guided P01 snapshot saved by a previous TunIQ process no longer appears as a live frozen operation after restart.
- Completed Read Properties, first-read, matching-read, definition, revision, and Test Write evidence remain preserved.
- Startup converts stale transient state into `resume-ready` and selects the exact next incomplete P01 step.
- Hardware Session Doctor no longer reuses the prior version's failed COM attempt list when no current operation is running.
- The progress bar shows the retained percentage rather than `STOPPED`.
- `Stop Current Operation` appears only when a real PCM Hammer or Guided runtime operation is active.
- Pressing Continue resumes the saved step without resetting commissioning.

## Safety

No PCM write behavior or write gate was loosened. This release changes persisted workflow/UI reconciliation only.
