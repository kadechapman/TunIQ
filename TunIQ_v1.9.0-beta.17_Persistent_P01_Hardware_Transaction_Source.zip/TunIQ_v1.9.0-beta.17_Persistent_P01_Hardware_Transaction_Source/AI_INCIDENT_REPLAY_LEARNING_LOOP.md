# AI Incident Replay & Learning Loop

TunIQ v1.9.0-beta.12 adds a local, privacy-safe incident recorder and a structured learning loop.

## Incident replay

The desktop keeps an in-memory rolling history of the previous 30 or 60 seconds. It records:

- page navigation
- button and control identifiers
- action labels
- operation/activity events
- renderer/runtime errors
- stop and recovery codes
- current project/controller context

It does not record typed input values, passwords, credentials, raw BIN bytes, raw XDF contents, VINs, email addresses, or private usernames.

Pressing **Report Bug** freezes the current replay before navigating to the report screen. The user can immediately create a diagnostic package; description and reproduction fields are optional.

## Learning loop

Every locally generated diagnostic report creates or updates a structured incident cluster using:

- stop code
- inferred subsystem
- controller and OS
- adapter and port context
- last user action
- application version

Repeated incidents increment the same cluster instead of creating duplicate knowledge. A repair does not become verified merely because it was suggested. It becomes verified only after at least two confirmed successful outcomes with no recorded failed repair outcome.

## Repair boundary

Safe auto-repair remains limited to application state and configuration. The learning loop cannot autonomously change:

- PCM flash/write logic
- calibration BIN bytes
- XDF addresses
- checksum algorithms
- kernels/loaders
- controller identity
- write/recovery safety gates

Those areas require a reviewed TunIQ software update.
