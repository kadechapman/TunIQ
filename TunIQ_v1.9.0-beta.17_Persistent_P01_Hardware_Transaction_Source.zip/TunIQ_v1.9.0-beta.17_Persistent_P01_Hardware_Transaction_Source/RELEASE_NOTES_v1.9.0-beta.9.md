# TunIQ v1.9.0-beta.9 — Unified P01 Workflow State Machine

- Reset Commissioning stays in the current project and resets both commissioning and guided automation state.
- Begin P01 Setup starts Read Controller Properties in the active P01 project instead of returning to project creation.
- Continue / Finish and all P01 entry points use the same continuation engine.
- Resolve Automatically starts Read Controller Properties first when controller OS identity is missing.
- Protected BINs, reads, revisions, logs, and reports remain preserved by reset.
