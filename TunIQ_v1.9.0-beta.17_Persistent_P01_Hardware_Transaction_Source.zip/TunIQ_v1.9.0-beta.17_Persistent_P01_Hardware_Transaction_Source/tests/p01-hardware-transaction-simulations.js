const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01HardwareTransactionManager } = require('../src/p01-hardware-transaction');

async function runP01HardwareTransactionSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-p01-transaction-'));
  let now = 1_000_000;
  const waits = [];
  const manager = new P01HardwareTransactionManager({
    dataRoot: () => root,
    platform: 'win32',
    now: () => now,
    sleep: async ms => { waits.push(ms); now += ms; },
    interOperationCooldownMs: 4000,
    reopenRecoveryDelayMs: 5000
  });

  const first = manager.begin({ projectId: 'project-a', controller: 'P01', os: '9373372', port: 'COM4', operation: 'readProperties' });
  manager.markProcessStarted({ port: 'COM4', operation: 'readProperties', sessionId: 'properties-1' });
  now += 600;
  manager.markProcessClosed({ port: 'COM4', operation: 'readProperties', sessionId: 'properties-1', success: true });
  const second = manager.begin({ projectId: 'project-a', controller: 'P01', os: '9373372', port: 'COM4', operation: 'read' });
  assert.equal(second.transactionId, first.transactionId, 'same project and proven port must retain one transaction ID');
  const waited = await manager.settleBeforeOpen('COM4');
  assert.equal(waited, 4000, 'new protected step must wait for the full Windows RFCOMM cooldown');
  assert.equal(waits[0], 4000);

  manager.markProcessStarted({ port: 'COM4', operation: 'read', sessionId: 'read-1' });
  manager.markProcessClosed({ port: 'COM4', operation: 'read', sessionId: 'read-1', success: false, stopCode: 'adapter-open-failed' });
  assert.equal(manager.canAttemptControlledReopen({ port: 'COM4', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' }), true);
  const recovery = await manager.controlledReopen({ port: 'COM4', operation: 'read', stopCode: 'adapter-open-failed' });
  assert.equal(recovery.waitMs, 5000);
  assert.equal(manager.canAttemptControlledReopen({ port: 'COM4', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' }), false, 'only one controlled reopen is allowed');

  const different = manager.begin({ projectId: 'project-b', controller: 'P01', os: '12212156', port: 'COM7', operation: 'readProperties' });
  assert.notEqual(different.transactionId, first.transactionId, 'another project/port must start an isolated transaction');
  assert.equal(different.recoveryCount, 0);
  assert.equal(different.port, 'COM7');

  const persisted = JSON.parse(fs.readFileSync(manager.file(), 'utf8'));
  assert.equal(persisted.projectId, 'project-b');
  assert(Array.isArray(persisted.history) && persisted.history.length >= 6, 'transaction ledger must persist preparation, process, cooldown, and recovery events');

  if (!quiet) console.log('✓ P01 hardware transaction: persistent lease, inter-operation cooldown, one controlled reopen, and project isolation (4/4)');
  return { passed: 4, total: 4 };
}

if (require.main === module) runP01HardwareTransactionSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01HardwareTransactionSimulations };
