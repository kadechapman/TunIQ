const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01AutoManager } = require('../src/p01-auto');
const { buildHardwareSessionReport, pickLatestSession } = require('../src/hardware-session-doctor');

function runP01StartupResumeReconciliationSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-startup-resume-'));
  const active = { id: 'startup-resume-p01', name: 'Startup Resume P01', controller: 'P01', folder: root };
  fs.mkdirSync(path.join(root, 'Reports'), { recursive: true });
  const manager = new P01AutoManager({ getActiveProject: () => active, processInstanceId: 'beta16-process' });
  let state = manager.begin({
    request: 'Disable VATS', requestFingerprint: 'startup-resume', exactXdfAuthorization: true,
    autoMapAuthorized: true, autoRevisionAuthorized: true, testWriteAuthorized: true
  });
  state = manager.completeStep('read-properties', 'read-1', 20, 'Read Properties completed.', {
    identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' }
  });
  state = manager.patch({
    status: 'cancelled', phase: 'cancelled', nextStep: null, resumePhase: null,
    lastAttemptId: 'old-attempt', lastAttemptStartedAt: '2026-08-03T20:00:00.000Z',
    portRecovery: { code: 'adapter-open-failed', attempts: [{ port: 'COM4' }, { port: 'COM1' }, { port: 'COM3' }] }
  }, { level: 'warning', text: 'Old build saved setup cancelled.' });

  const p01 = {
    identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' },
    readPair: { first: null }, dualReadVerified: false
  };
  const reconciled = manager.reconcileStartupState(p01, { runtimeActive: false, reason: 'beta.16 startup' });
  assert.equal(reconciled.status, 'resume-ready');
  assert.equal(reconciled.phase, 'read-1');
  assert.equal(reconciled.nextStep, 'read-1');
  assert.equal(reconciled.progress, 20);
  assert.equal(reconciled.stop, null);
  assert.equal(reconciled.portRecovery, null);
  assert.equal(reconciled.lastAttemptId, null);
  assert.equal(reconciled.activeFlashSessionId, null);
  assert.equal(manager.canResume(reconciled), true);

  const oldSession = {
    id: 'old-session', projectId: active.id, workflowAttemptId: 'old-attempt', operation: 'read',
    stopCode: 'adapter-open-failed', device: 'COM4', deviceAttempts: [
      { device: 'COM4', openFailure: true }, { device: 'COM1', openTimeout: true }, { device: 'COM3', openFailure: true }
    ]
  };
  assert.equal(pickLatestSession({ history: [oldSession] }, active.id, reconciled), null, 'resume-ready state must not reuse old failed session');
  const report = buildHardwareSessionReport({
    appVersion: '1.9.0-beta.16', activeProject: active, p01, p01Auto: reconciled,
    flash: { history: [oldSession], lastSuccessfulDevice: 'COM4', lastSuccessfulOperation: 'readProperties' }
  });
  assert.equal(report.workflow.stopCode, '');
  assert.equal(report.session.id, '');
  assert.equal(report.session.attempts.length, 0);
  assert.equal(report.diagnosis.category, 'resume-ready');
  assert.equal(report.diagnosis.severity, 'ready');
  assert(report.diagnosis.title.includes('read 1'));
  assert.equal(report.diagnosis.recommendedPort, 'COM4');

  const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
  assert(renderer.includes("resumeReady=auto.status==='resume-ready'"));
  assert(renderer.includes("box.textContent=commissioned?'SETUP COMPLETE':written?'WRITE COMPLETE':ready?'READY TO WRITE':running?'RUNNING':resumeReady?'READY TO RESUME'"));
  assert(renderer.includes('const activeOperation=Boolean(running&&'));
  assert(!renderer.includes("stopButton.classList.toggle('hidden',!running)"));

  fs.rmSync(root, { recursive: true, force: true });
  if (!quiet) console.log('✓ P01 startup resume reconciliation: stale cancel state becomes ready-to-resume with current-only diagnostics');
  return { scenarios: 9 };
}

if (require.main === module) runP01StartupResumeReconciliationSimulations();
module.exports = { runP01StartupResumeReconciliationSimulations };
