const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return;
    await wait(20);
  }
  throw new Error('Timed out waiting for proven-port transaction simulation.');
}

function fixture(name) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-proven-port-${name}-`));
  const project = path.join(root, 'project');
  const portable = path.join(root, 'PCM-Hammer');
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  const executable = path.join(portable, 'PcmHammerCLI');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const active = { id: `p01-${name}`, name: `P01 ${name}`, folder: project, controller: 'P01', os: '9373372' };
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data'),
    getActiveProject: () => active,
    getToolPath: () => portable,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
    releasePort: async () => ({ released: true }),
    abortBridgeRequests: () => ({ aborted: 0 }),
    appendActivity: () => {},
    emit: () => {},
    onReadComplete: async () => {},
    onSessionComplete: async () => {},
    platform: 'test',
    interOperationCooldownMs: 5,
    reopenRecoveryDelayMs: 10
  });
  return { root, project, portable, executable, mock, active, manager };
}

async function configure(f) {
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  process.env.PCMHAMMER_MOCK_TIMEOUT_PORT = 'COM4';
  process.env.PCMHAMMER_MOCK_DEVICE_LIST = '0: OBDLink MX+ Incoming (COM3)\n1: Generic Communications Port (COM1)\n2: OBDLink MX+ Outgoing (COM4)';
  await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
  f.manager.saveConfig({
    device: 'COM4',
    lastSuccessfulDevice: 'COM4',
    lastSuccessfulOperation: 'readProperties',
    lastDeviceCandidates: [
      { port: 'COM4', recognized: true, outgoing: true, recoveryScore: 1000 },
      { port: 'COM3', recognized: true, incoming: true, recoveryScore: 200 },
      { port: 'COM1', recognized: false, recoveryScore: 0 }
    ]
  });
}

async function runControlledRecoverySuccess() {
  const f = fixture('controlled-recovery');
  await configure(f);
  const marker = path.join(f.root, 'open-once.marker');
  process.env.PCMHAMMER_MOCK_SCENARIO = 'open-failed-once';
  process.env.PCMHAMMER_MOCK_ONCE_FILE = marker;
  await f.manager.start('read', {
    device: 'COM4',
    directPortHandoffAuthorized: true,
    authoritativeProvenPort: true,
    directPortHandoffReason: 'Read Properties already proved COM4 for this exact P01 project.'
  });
  await waitFor(() => !f.manager.session);
  const history = f.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'controlled-recovery read must be recorded');
  assert.equal(history.state, 'complete');
  assert.equal(history.device, 'COM4');
  assert.equal(history.portLease?.pinnedProvenPort, true);
  assert.deepEqual(history.deviceAttempts.map(item => item.device), ['COM4', 'COM4']);
  assert.equal(history.deviceAttempts[1].source, 'proven-port-controlled-reopen');
  assert.deepEqual([...new Set(history.deviceCandidates.map(item => item.port))], ['COM4']);
  assert.equal((history.deviceDiscoveryPasses || []).length, 0);
  assert.equal(history.hardwareTransaction?.recoveryCount, 0, 'successful operation resets recovery count');
  assert(/waiting for the RFCOMM driver to settle/i.test((history.log || []).map(item => item.text).join('\n')));
  return history;
}

async function runControlledRecoveryStopsCleanly() {
  const f = fixture('controlled-stop');
  await configure(f);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'open-failed';
  delete process.env.PCMHAMMER_MOCK_ONCE_FILE;
  await f.manager.start('read', {
    device: 'COM4',
    directPortHandoffAuthorized: true,
    authoritativeProvenPort: true,
    directPortHandoffReason: 'Read Properties already proved COM4 for this exact P01 project.'
  });
  await waitFor(() => !f.manager.session);
  const history = f.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'failed controlled-reopen read must be recorded');
  assert.equal(history.state, 'failed');
  assert.equal(history.stopCode, 'proven-port-reopen-failed');
  assert.deepEqual(history.deviceAttempts.map(item => item.device), ['COM4', 'COM4']);
  assert.deepEqual([...new Set(history.deviceCandidates.map(item => item.port))], ['COM4']);
  assert.equal((history.deviceDiscoveryPasses || []).length, 0);
  assert(/no alternate COM port was attempted/i.test(history.error || ''));
  assert.equal(history.hardwareTransaction?.recoveryCount, 1);
  return history;
}

async function runP01ProvenPortPinSimulations({ quiet = false } = {}) {
  await runControlledRecoverySuccess();
  await runControlledRecoveryStopsCleanly();
  const flashSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'flash.js'), 'utf8');
  const transactionSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'p01-hardware-transaction.js'), 'utf8');
  assert(flashSource.includes('proven-port-controlled-reopen'));
  assert(flashSource.includes('proven-port-reopen-failed'));
  assert(transactionSource.includes('interOperationCooldownMs'));
  assert(transactionSource.includes('controlledReopen'));
  if (!quiet) console.log('✓ Proven P01 port transaction: cooldown, one controlled COM4 reopen, no COM1/COM3 fallback (2/2)');
  return { passed: 2, total: 2 };
}

if (require.main === module) runP01ProvenPortPinSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01ProvenPortPinSimulations };
