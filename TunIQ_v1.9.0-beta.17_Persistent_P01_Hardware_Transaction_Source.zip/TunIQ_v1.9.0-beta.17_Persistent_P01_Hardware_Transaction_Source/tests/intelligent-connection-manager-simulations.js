const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { IntelligentConnectionManager } = require('../src/intelligent-connection-manager');
const { FlashManager } = require('../src/flash');
const { ObdManager } = require('../src/obd');

function temp(prefix) { return fs.mkdtempSync(path.join(os.tmpdir(), prefix)); }
function identity(port, overrides = {}) {
  return {
    available: true,
    locked: false,
    identified: true,
    recognized: true,
    port,
    baud: 115200,
    adapter: 'OBDLink MX+',
    description: 'OBDLink MX+',
    deviceId: 'STN2255',
    ...overrides
  };
}

async function run() {
  const scenarios = [];

  // 1. Outgoing endpoint wins; incoming and generic COM1 are never attempted.
  {
    const root = temp('tuniq-broker-1-');
    const calls = [];
    const devices = [
      { port: 'COM3', name: 'Standard Serial over Bluetooth link (Incoming)', bluetooth: true, incoming: true, pairKey: 'mx' },
      { port: 'COM4', name: 'Standard Serial over Bluetooth link (Outgoing)', bluetooth: true, outgoing: true, pairKey: 'mx' },
      { port: 'COM1', name: 'Communications Port' }
    ];
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => devices,
      identifyPort: async ({ port }) => { calls.push(port); return identity(port); }
    });
    const result = await manager.preflight({ selectedPort: 'COM3' });
    assert.equal(result.ready, true);
    assert.equal(result.port, 'COM4');
    assert.deepEqual(calls, ['COM4']);
    assert(!result.discovery.candidates.some(item => item.port === 'COM1'));
    scenarios.push('outgoing-port-preferred');
  }

  // 2. A stale selected COM8 cannot outrank a live outgoing COM4.
  {
    const root = temp('tuniq-broker-2-');
    const calls = [];
    const devices = [
      { port: 'COM8', name: 'Standard Serial over Bluetooth link', bluetooth: true },
      { port: 'COM4', name: 'OBDLink MX+ Outgoing', bluetooth: true, outgoing: true, recognized: true }
    ];
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => devices,
      identifyPort: async ({ port }) => { calls.push(port); return identity(port); }
    });
    const result = await manager.preflight({ selectedPort: 'COM8' });
    assert.equal(result.port, 'COM4');
    assert.deepEqual(calls, ['COM4']);
    scenarios.push('stale-selected-port-does-not-win');
  }

  // 3. Only an incoming Bluetooth endpoint yields a specific missing-outgoing stop.
  {
    const root = temp('tuniq-broker-3-');
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [{ port: 'COM3', name: 'Standard Serial over Bluetooth link (Incoming)', bluetooth: true, incoming: true }],
      identifyPort: async () => { throw new Error('should not be called'); }
    });
    const result = await manager.preflight({ selectedPort: 'COM3' });
    assert.equal(result.ready, false);
    assert.equal(result.state, 'missing-outgoing-port');
    assert.equal(result.attempts.length, 0);
    scenarios.push('missing-outgoing-specific-stop');
  }

  // 4. A responding but unknown serial device is not accepted as the PCM adapter.
  {
    const root = temp('tuniq-broker-4-');
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [{ port: 'COM7', name: 'USB Serial Device', recognized: true }],
      identifyPort: async ({ port }) => identity(port, { recognized: false, adapter: 'Generic UART', description: '', deviceId: '' })
    });
    const result = await manager.preflight({ selectedPort: 'COM7' });
    assert.equal(result.ready, false);
    assert.equal(result.state, 'adapter-identity-unverified');
    assert.equal(result.attempts.length, 1);
    scenarios.push('unknown-identity-rejected');
  }

  // 5. Every eligible port is tested at most once.
  {
    const calls = [];
    const root = temp('tuniq-broker-5-');
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [
        { port: 'COM4', name: 'OBDLink Outgoing', outgoing: true, recognized: true },
        { port: 'COM5', name: 'OBDLink Backup', recognized: true }
      ],
      identifyPort: async ({ port }) => { calls.push(port); return { available: false, identified: false, recognized: false, code: 'adapter-open-timeout', timedOut: true }; }
    });
    const result = await manager.preflight({ selectedPort: 'COM4', lastSuccessfulPort: 'COM4' });
    assert.equal(result.ready, false);
    assert.equal(result.state, 'ports-unavailable');
    assert.equal(new Set(calls).size, calls.length);
    assert.deepEqual(calls.sort(), ['COM4', 'COM5']);
    scenarios.push('one-attempt-per-port');
  }

  // 6. A previously identified profile is not trusted when Windows no longer exposes that port.
  {
    const root = temp('tuniq-broker-6-');
    fs.mkdirSync(path.join(root, 'Tools'), { recursive: true });
    fs.writeFileSync(path.join(root, 'Tools', 'obdlink-adapter-profile.json'), JSON.stringify({
      adapterName: 'OBDLink MX+', adapterIdentity: 'OBDLink MX+ STN2255', identityKey: 'mx',
      lastWorkingPort: 'COM9', identityVerifiedAt: new Date().toISOString(), lastSeenPorts: ['COM9']
    }));
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [],
      identifyPort: async ({ port }) => identity(port)
    });
    const result = await manager.preflight({});
    assert.equal(result.ready, false);
    assert.equal(result.port, '');
    assert(!result.discovery.candidates.some(item => item.port === 'COM9'));
    scenarios.push('stale-profile-rejected');
  }

  // 7. COM1 remains excluded unless its live device identity explicitly identifies the adapter.
  {
    const genericRoot = temp('tuniq-broker-7a-');
    const generic = new IntelligentConnectionManager({
      dataRoot: () => genericRoot,
      listDevices: async () => [{ port: 'COM1', name: 'Communications Port' }],
      identifyPort: async ({ port }) => identity(port)
    });
    const blocked = await generic.preflight({ selectedPort: 'COM1' });
    assert.equal(blocked.ready, false);
    assert.equal(blocked.attempts.length, 0);

    const recognizedRoot = temp('tuniq-broker-7b-');
    const recognized = new IntelligentConnectionManager({
      dataRoot: () => recognizedRoot,
      listDevices: async () => [{ port: 'COM1', name: 'OBDLink MX+ (COM1)', recognized: true, outgoing: true }],
      identifyPort: async ({ port }) => identity(port)
    });
    const ready = await recognized.preflight({ selectedPort: 'COM1' });
    assert.equal(ready.ready, true);
    assert.equal(ready.port, 'COM1');
    scenarios.push('com1-requires-positive-identity');
  }

  // 8. Flash handoff uses exactly the broker-verified port, not the stale selected port or alternates.
  {
    const root = temp('tuniq-broker-8-');
    const active = { id: 'p01', name: 'P01', folder: path.join(root, 'project'), controller: 'P01' };
    fs.mkdirSync(active.folder, { recursive: true });
    const events = [];
    const connectionManager = {
      preflight: async () => ({
        ready: true, verified: true, port: 'COM4', attempts: [{ port: 'COM4', identified: true, recognized: true }],
        attempt: { port: 'COM4', adapter: 'OBDLink MX+', baud: 115200 }, profile: { adapterName: 'OBDLink MX+' }
      })
    };
    const flash = new FlashManager({
      dataRoot: () => root,
      getActiveProject: () => active,
      getToolPath: () => null,
      connectionManager,
      releasePort: async ({ port }) => { events.push(`release:${port}`); return { released: true, port }; },
      findAlternatePorts: async () => { events.push('alternates'); return [{ port: 'COM8' }]; },
      abortBridgeRequests: () => ({ aborted: 0 })
    });
    const lease = await flash.preparePort({ operation: 'readProperties', values: { device: 'COM8', port: 'COM8' }, config: { lastSuccessfulDevice: 'COM8' } });
    assert.equal(lease.port, 'COM4');
    assert.equal(lease.verifiedByBroker, true);
    assert.deepEqual(lease.candidates.map(item => item.port), ['COM4']);
    assert(events.includes('release:COM4'));
    assert(!events.includes('alternates'));
    scenarios.push('flash-uses-one-verified-port');
  }

  // 9. A successful verification is persisted only after real adapter identity proof.
  {
    const root = temp('tuniq-broker-9-');
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [{ port: 'COM11', name: 'OBDLink MX+ Outgoing', recognized: true, outgoing: true, containerId: 'container-1' }],
      identifyPort: async ({ port }) => identity(port)
    });
    const result = await manager.preflight({});
    const profile = manager.load();
    assert.equal(result.ready, true);
    assert.equal(profile.lastWorkingPort, 'COM11');
    assert.equal(profile.identityKey, 'container-1');
    assert(profile.identityVerifiedAt);
    scenarios.push('identity-profile-persisted');
  }

  // 10. The Windows OBD bridge performs identity-only verification without querying the PCM.
  {
    const root = temp('tuniq-broker-10-');
    const calls = [];
    const obd = new ObdManager({
      dataRoot: () => root,
      getActiveProject: () => null,
      platform: 'win32',
      bridgeRunner: async (action, payload) => {
        calls.push({ action, payload });
        if (action !== 'Identify') throw new Error(`Unexpected action ${action}`);
        return { success: true, available: true, identified: true, recognized: true, port: payload.port, baud: 115200, adapter: 'OBDLink MX+', description: 'ScanTool.net', deviceId: 'STN2255' };
      }
    });
    const result = await obd.identifyAdapterPort({ port: 'COM4' });
    assert.equal(result.available, true);
    assert.equal(result.recognized, true);
    assert.equal(result.port, 'COM4');
    assert.deepEqual(calls.map(item => item.action), ['Identify']);
    scenarios.push('identity-only-windows-probe');
  }

  // 11. A Windows identify timeout becomes one bounded adapter-open-timeout result.
  {
    const root = temp('tuniq-broker-11-');
    const obd = new ObdManager({
      dataRoot: () => root,
      getActiveProject: () => null,
      platform: 'win32',
      bridgeRunner: async () => { throw new Error('The identify request timed out on COM4.'); }
    });
    const result = await obd.identifyAdapterPort({ port: 'COM4' });
    assert.equal(result.available, false);
    assert.equal(result.code, 'adapter-open-timeout');
    assert.equal(result.timedOut, true);
    scenarios.push('identity-timeout-bounded');
  }

  // 12. Manual selection may test a generically labeled or incoming endpoint, but it still
  // requires a real OBDLink/STN identity before the P01 workflow can resume.
  {
    const root = temp('tuniq-broker-12-');
    const calls = [];
    const manager = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [
        { port: 'COM3', name: 'Standard Serial over Bluetooth link (Incoming)', bluetooth: true, incoming: true },
        { port: 'COM4', name: 'Standard Serial over Bluetooth link', bluetooth: true }
      ],
      identifyPort: async ({ port }) => { calls.push(port); return port === 'COM3' ? identity(port) : identity(port, { recognized: false, adapter: 'Generic UART', description: '', deviceId: '' }); }
    });
    const verified = await manager.preflight({ selectedPort: 'COM3', manualPortOnly: true, allowRepair: false });
    assert.equal(verified.ready, true);
    assert.equal(verified.port, 'COM3');
    assert.deepEqual(calls, ['COM3']);

    calls.length = 0;
    const rejected = await manager.preflight({ selectedPort: 'COM4', manualPortOnly: true, allowRepair: false });
    assert.equal(rejected.ready, false);
    assert.equal(rejected.state, 'adapter-identity-unverified');
    assert.deepEqual(calls, ['COM4']);
    scenarios.push('manual-port-still-requires-obdlink-identity');
  }

  console.log(`Verified Adapter Connection Broker simulations: ${scenarios.length}/${scenarios.length} passed`);
  return { passed: true, scenarios };
}

if (require.main === module) run().catch(error => { console.error(error.stack || error); process.exit(1); });
module.exports = { runIntelligentConnectionManagerSimulations: run };
