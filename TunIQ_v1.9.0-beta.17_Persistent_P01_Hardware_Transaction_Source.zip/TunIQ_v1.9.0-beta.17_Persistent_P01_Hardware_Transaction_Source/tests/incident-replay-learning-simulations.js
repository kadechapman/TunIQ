const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const zlib = require('zlib');
const { IncidentReplayRecorder } = require('../src/incident-replay');
const { KnowledgeRepairEngine } = require('../src/knowledge-repair-engine');
const { BetaManager } = require('../src/beta');

function runIncidentReplayLearningSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-incident-replay-'));
  const dataRoot = () => path.join(root, 'data');
  const projectFolder = path.join(root, 'project');
  fs.mkdirSync(projectFolder, { recursive: true });
  const project = { id: 'p01-incident', name: 'Bench P01', folder: projectFolder, controller: 'P01', os: '12212156' };
  const results = [];
  const pass = (scenario, extra = {}) => results.push({ scenario, passed: true, ...extra });
  try {
    const recorder = new IncidentReplayRecorder({ dataRoot, windowMs: 60_000 });
    recorder.recordUi({ action: 'navigate', targetId: 'flash', label: 'Open Tune Center', page: 'flash' });
    recorder.recordUi({ action: 'click', targetId: 'p01AutoStart', label: 'Begin P01 Setup', page: 'flash' });
    recorder.record('hardware-stopped', { stopCode: 'adapter-open-timeout', vin: '1GNEK13Z32R123456', email: 'owner@example.com', message: 'Timed out opening COM4' });
    const snapshot = recorder.capture({ currentPage: 'flash', windowMs: 60_000 });
    assert.equal(snapshot.summary.stopCode, 'adapter-open-timeout');
    assert.equal(snapshot.summary.inferredLayer, 'adapter-connection');
    assert.equal(snapshot.summary.lastUserAction, 'Begin P01 Setup');
    pass('captures the previous 60 seconds and identifies the last action and stop code', { events: snapshot.events.length });

    const snapshotText = JSON.stringify(snapshot);
    assert(!snapshotText.includes('1GNEK13Z32R123456'));
    assert(!snapshotText.includes('owner@example.com'));
    assert.equal(snapshot.privacy.inputValuesIncluded, false);
    pass('redacts VIN/email and never captures typed input values');

    recorder.events.unshift({ id: 'old', at: new Date(Date.now() - 130_000).toISOString(), source: 'renderer', type: 'click', details: { label: 'Old action' } });
    assert(!recorder.recent(60_000).some(item => item.id === 'old'));
    pass('drops events outside the selected replay window');

    const activities = [];
    const knowledge = new KnowledgeRepairEngine({ dataRoot, getActiveProject: () => project, appendActivity: (type, details) => activities.push({ type, details }) });
    let learned = null;
    const beta = new BetaManager({
      appVersion: '1.9.0-beta.12', dataRoot, getActiveProject: () => project, getSettings: () => ({ detailLevel: 'advanced', aiMode: 'full-ai' }),
      getDeviceStatus: () => ({ connection: { adapter: 'OBDLink MX+', port: 'COM4' } }), getWorkspaceSummary: () => ({ activeProject: project }),
      getFlashStatus: () => ({ stopCode: 'adapter-open-timeout' }), getHardwareSessionReport: () => ({ stopCode: 'adapter-open-timeout' }),
      getConnectionProfile: () => ({ adapterName: 'OBDLink MX+', lastWorkingPort: 'COM4' }), getActivity: () => [],
      getIncidentReplay: id => recorder.get(id), getKnowledgeMatches: context => knowledge.incidentInsights(context),
      onDiagnosticBuilt: bundle => { learned = knowledge.ingestIncidentReport(bundle); }, appendActivity: () => {}
    });
    beta.savePreferences({ incidentReplaySeconds: 60 });
    const reportFile = path.join(root, 'incident.tuniqreport');
    beta.exportDiagnostic(reportFile, { incidentReplayId: snapshot.id, currentPage: 'flash' });
    const report = JSON.parse(zlib.gunzipSync(fs.readFileSync(reportFile)).toString('utf8'));
    assert.equal(report.schemaVersion, 2);
    assert.equal(report.incidentReplay.id, snapshot.id);
    assert.equal(report.aiIncidentAnalysis.inferredLayer, 'adapter-connection');
    assert.equal(report.privacy.inputValuesIncluded, false);
    pass('diagnostic package embeds the frozen replay and deterministic AI incident analysis');

    assert(learned && learned.signature);
    assert.equal(knowledge.state().incidentClusterCount, 1);
    assert.equal(knowledge.state().totalIncidentOccurrences, 1);
    pass('turns a bug report into a local incident-learning candidate');

    knowledge.ingestIncidentReport(report);
    const clustered = knowledge.incidentClusters()[0];
    assert.equal(clustered.occurrences, 2);
    assert(clustered.confidence > learned.confidence);
    pass('clusters repeated failures instead of creating duplicate lessons');

    knowledge.recordIncidentResolution({ signature: clustered.signature, outcome: 'fixed', repairId: 'remove-stale-com-cache' });
    const verified = knowledge.recordIncidentResolution({ signature: clustered.signature, outcome: 'fixed', repairId: 'remove-stale-com-cache' });
    assert.equal(verified.status, 'verified');
    assert(verified.confidence >= 0.86);
    assert(knowledge.incidentInsights({ stopCode: 'adapter-open-timeout', controller: 'P01' }).length >= 1);
    pass('promotes a repeated confirmed fix to verified reusable knowledge');

    if (!quiet) console.log(`✓ Incident replay and AI learning loop simulations passed (${results.length}/${results.length})`);
    return results;
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

if (require.main === module) {
  try { runIncidentReplayLearningSimulations(); } catch (error) { console.error(error.stack || error); process.exit(1); }
}
module.exports = { runIncidentReplayLearningSimulations };
