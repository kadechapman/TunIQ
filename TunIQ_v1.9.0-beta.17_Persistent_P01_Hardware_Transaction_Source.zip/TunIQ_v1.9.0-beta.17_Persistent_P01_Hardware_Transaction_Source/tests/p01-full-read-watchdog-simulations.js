const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { FlashManager, P01_BIN_SIZE } = require('../src/flash');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return true;
    await wait(20);
  }
  throw new Error('Timed out waiting for full-read watchdog simulation.');
}
function makeFixture(name, options = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-read-watchdog-${name}-`));
  const project = path.join(root, 'project');
  const data = path.join(root, 'data');
  const portable = path.join(root, 'PCM-Hammer');
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(project, 'Revisions'), { recursive: true });
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const executable = path.join(portable, 'PcmHammerCLI');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const events = [];
  const completed = [];
  const active = { id: `p-${name}`, name: `P01 ${name}`, folder: project, controller: 'P01' };
  const manager = new FlashManager({
    dataRoot: () => data,
    getActiveProject: () => active,
    getToolPath: () => portable,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
    releasePort: async () => ({ released: true }),
    appendActivity: () => {},
    emit: (channel, payload) => { if (channel === 'flash:progress') events.push(payload); },
    onReadComplete: async () => {},
    onSessionComplete: async session => completed.push(session),
    readWatchdogPollMs: options.pollMs || 20,
    readStallTimeoutMs: options.stallMs || 500
  });
  return { root, project, data, portable, mock, executable, events, completed, active, manager };
}
async function configure(fixture) {
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  await fixture.manager.probe({ executable: fixture.executable, prefixArgs: [fixture.mock] });
  fixture.manager.saveDevice('COM4');
}
async function runSlowRead() {
  const fixture = makeFixture('slow', { pollMs: 20, stallMs: 1500 });
  await configure(fixture);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'slow-silent-read';
  process.env.PCMHAMMER_MOCK_CHUNK_DELAY_MS = '70';
  await fixture.manager.start('read', { directPortHandoffAuthorized: true, directPortHandoffReason: 'focused read monitor test' });
  await waitFor(() => !fixture.manager.session, 8000);
  const history = fixture.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'completed read should be recorded');
  assert.equal(history.state, 'complete');
  assert.equal(history.outputInfo.size, P01_BIN_SIZE);
  const heartbeats = fixture.events.filter(item => item.readHeartbeat && item.operation === 'read');
  assert(heartbeats.length >= 2, 'quiet read should emit repeated live heartbeats');
  assert(heartbeats.some(item => Number(item.readHeartbeat.outputBytes) > 0), 'heartbeat should observe growing read file');
  assert(heartbeats.some(item => Number(item.progress) > 0 && Number(item.progress) < 100), 'read-file growth should produce visible progress before completion');
  assert(heartbeats.some(item => /still running|bytes received|waiting for PCM Hammer completion proof/i.test(item.phase || '')), 'phase should explain what the quiet read is doing');
  return fixture;
}
async function runStalledRead() {
  const fixture = makeFixture('stall', { pollMs: 20, stallMs: 180 });
  await configure(fixture);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'stalled-read';
  process.env.PCMHAMMER_MOCK_STALL_HOLD_MS = '5000';
  await fixture.manager.start('read', { directPortHandoffAuthorized: true, directPortHandoffReason: 'focused stalled-read test' });
  await waitFor(() => !fixture.manager.session, 8000);
  const history = fixture.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'stalled read should be recorded');
  assert.equal(history.state, 'failed');
  assert.equal(history.stopCode, 'read-stalled-no-progress');
  assert.equal(history.readWatchdogTriggered, true);
  assert(/completed Read Properties evidence was preserved/i.test(history.error || ''));
  assert(history.rejectedOutput && fs.existsSync(history.rejectedOutput), 'partial read should be renamed as rejected evidence');
  assert.notEqual(fs.statSync(history.rejectedOutput).size, P01_BIN_SIZE, 'rejected stalled file must not look complete');
  return fixture;
}
function staticLiveUiContract() {
  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
  assert(main.includes("channel === 'flash:progress' && p01AutoManager"), 'Flash progress must refresh Guided P01 state live.');
  assert(main.includes('overlayP01LiveFlash'), 'Guided P01 snapshot must map live PCM Hammer progress.');
  assert(renderer.includes('auto.liveOperationPhase'), 'Guided P01 renderer must show live operation phase.');
  assert(renderer.includes('auto.liveOperationHeartbeat'), 'Guided P01 renderer must show process/read heartbeat.');
}
async function runP01FullReadWatchdogSimulations({ quiet = false } = {}) {
  staticLiveUiContract();
  await runSlowRead();
  await runStalledRead();
  if (!quiet) console.log('✓ P01 full-read monitor: live heartbeat, byte progress, Guided UI overlay, and safe stall stop (3/3)');
  return { passed: 3, total: 3 };
}
if (require.main === module) runP01FullReadWatchdogSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01FullReadWatchdogSimulations };
