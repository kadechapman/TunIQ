const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { IntelligentConnectionManager } = require('../src/intelligent-connection-manager');

async function runBridgeCoreRewriteSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-bridge-core-'));
  try {
    const stale = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [{ port: 'COM1', name: 'Communications Port', transport: 'Motherboard UART' }],
      identifyPort: async () => ({ available: false, identified: false, timedOut: true })
    });
    stale.save({ lastWorkingPort: 'COM3', identityVerifiedAt: new Date().toISOString(), adapterName: 'OBDLink MX+' });
    const staleDiscovery = await stale.discover();
    assert(!staleDiscovery.candidates.some(item => item.port === 'COM3'), 'a stale profile port must not be treated as live');
    const missing = await stale.preflight({ allowRepair: false });
    assert.equal(missing.state, 'windows-obdlink-port-missing');
    assert.equal(missing.discovery.candidates.length, 0);

    const attempts = [];
    const live = new IntelligentConnectionManager({
      dataRoot: () => root,
      listDevices: async () => [
        { port: 'COM1', name: 'Communications Port', transport: 'Motherboard UART' },
        { port: 'COM3', name: 'Standard Serial over Bluetooth link', description: 'OBDLink MX+ Outgoing', bluetooth: true, outgoing: true, recognized: true }
      ],
      identifyPort: async ({ port }) => {
        attempts.push(port);
        return port === 'COM3'
          ? { available: true, identified: true, recognized: true, adapter: 'OBDLink MX+', identity: 'STN2255', baud: 115200 }
          : { available: false, identified: false };
      }
    });
    const verified = await live.preflight({ selectedPort: 'COM1', allowRepair: false });
    assert.equal(verified.ready, true);
    assert.equal(verified.port, 'COM3');
    assert.deepEqual(attempts, ['COM3']);

    const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
    const renderer = fs.readFileSync(path.join(__dirname, '../src/renderer/app.js'), 'utf8');
    assert(main.includes('prepareFreshPhysicalP01Bridge'), 'fresh physical bridge preparation missing');
    assert(main.includes('p01-auto-direct-read-properties-fallback'), 'automatic read-only PCM Hammer fallback missing');
    assert(main.includes("port !== 'COM1'"), 'generic COM1 exclusion missing from automatic fallback');
    assert(renderer.includes('No OBDLink COM port exposed by Windows'), 'manual selector must not present generic COM1 as an OBDLink');
    assert(renderer.includes('state.device=await window.tuniq.getDeviceStatus()'), 'header device state must refresh after P01 start');
    if (!quiet) console.log('Bridge Core Rewrite simulations passed (5/5).');
    return { passed: 5, total: 5 };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}

if (require.main === module) runBridgeCoreRewriteSimulations().catch(error => { console.error(error.stack || error); process.exit(1); });
module.exports = { runBridgeCoreRewriteSimulations };
