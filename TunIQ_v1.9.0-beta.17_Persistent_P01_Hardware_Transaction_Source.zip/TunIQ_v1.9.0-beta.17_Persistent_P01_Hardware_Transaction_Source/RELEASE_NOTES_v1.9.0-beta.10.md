# TunIQ v1.9.0-beta.10 — Learning Memory & Safe Self-Repair Foundation

- Project-isolated learning memory
- Sanitized verified/candidate shared knowledge store
- Failure-code and controller/OS pattern matching
- Observe, Recommend, and Safe Auto-Repair modes
- Approved repairs for stale state, COM cache, folders, UI preferences, and metadata
- Hard block against automatic flash/calibration/kernel/checksum/identity changes
- Audit history and rollback markers for every applied repair
