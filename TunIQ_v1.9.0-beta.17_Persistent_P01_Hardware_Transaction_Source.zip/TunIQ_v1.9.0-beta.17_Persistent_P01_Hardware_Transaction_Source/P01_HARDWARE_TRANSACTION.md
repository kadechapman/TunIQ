# Persistent P01 Hardware Transaction

TunIQ v1.9.0-beta.17 replaces the repeated P01 step-to-step COM reopen path with one project-bound hardware transaction.

## Why this exists

Read Properties can complete successfully while Windows is still releasing the Bluetooth RFCOMM serial handle when the next PCM Hammer process starts. Starting Full Read 1 too quickly can therefore produce an adapter-open failure even though the same PCM, OBDLink, project, and COM port were just proven.

## Transaction behavior

For one exact P01 project, controller OS, and proven COM port, TunIQ persists a transaction ledger containing:

- Project and transaction identifiers
- Controller and OS
- Proven COM port
- Current and last successful operation
- PCM Hammer process start and close timestamps
- Controlled-reopen count
- A bounded event history

Read Properties, Full Read 1, Full Read 2, and Test Write reuse that project-bound transaction.

## Windows settle and recovery

- TunIQ waits four seconds between PCM Hammer processes on Windows so the RFCOMM driver can release the proven port.
- If a non-destructive read or Test Write still fails before PCM communication, TunIQ releases its own handles, waits five additional seconds, and retries the same proven port once.
- COM1, COM3, and other alternate ports are not scanned during this recovery.
- A second failure stops with `proven-port-reopen-failed` and preserves completed P01 Properties and all verified evidence.

## Safety boundary

The transaction does not bypass dual-read matching, exact-OS definition binding, checksum validation, Test Write, recovery, or final write confirmation. It cannot convert a partial read into evidence and does not perform an actual PCM write.
