# TunIQ v1.9.0-beta.8 — P01 Project State Unlock

- Always exposes Continue, Start New P01 Service, Reset Commissioning, and Archive Project.
- Reset preserves protected BINs, reads, revisions, logs, and reports.
- New P01 service creates a separate protected project.
- Archived projects preserve every file and leave the active workflow.
- Workspace BIN/XDF labels reconcile from recovered disk evidence.
