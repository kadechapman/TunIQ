# TunIQ v1.9.0-beta.11 — Authoritative P01 Bridge Core Rewrite

- Disconnects the TunIQ virtual adapter before physical P01 commissioning.
- Clears transient bridge/session state for a genuinely fresh P01 hardware session.
- Rejects stale saved COM ports that Windows no longer exposes.
- Excludes generic motherboard COM1 unless Windows positively identifies it as the adapter.
- Makes the live verified/ranked physical port the only source of truth for PCM Hammer.
- Synchronizes the manual COM selector and header with the current hardware state.
- If TunIQ's adapter-only handshake times out during Read Properties, performs one automatic read-only PCM Hammer attempt on the best non-COM1 candidate.
- Never uses the direct fallback for a real PCM write.
- Keeps beta.10 learning memory and safe self-repair.

Physical PCM communication is not claimed until verified on the user's Windows PC and hardware.
