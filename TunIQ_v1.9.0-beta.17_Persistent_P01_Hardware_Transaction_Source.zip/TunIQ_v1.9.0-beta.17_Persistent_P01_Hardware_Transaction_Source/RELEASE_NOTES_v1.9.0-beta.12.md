# TunIQ v1.9.0-beta.12

## AI Incident Replay & Learning Loop

- Report Bug freezes a privacy-safe 30- or 60-second activity replay.
- The replay captures navigation, control IDs, operation state, errors, and stop codes.
- Typed form values, credentials, raw BIN/XDF data, VINs, emails, and private usernames are excluded.
- Bug descriptions and reproduction steps are now optional.
- Diagnostic reports include deterministic incident analysis and matching learned patterns.
- Repeated reports are clustered by controller, OS, adapter, stop code, subsystem, and last action.
- Confirmed resolutions can promote a repeated repair pattern to verified knowledge.
- Project learning remains isolated from other vehicles unless a lesson is explicitly promoted into shared verified knowledge.
- Safe auto-repair remains restricted to low-risk application state/configuration.
- All v1.9.0-beta.11 authoritative bridge behavior is retained.

No physical PCM read, Test Write, calibration write, or recovery write is claimed by this release.
