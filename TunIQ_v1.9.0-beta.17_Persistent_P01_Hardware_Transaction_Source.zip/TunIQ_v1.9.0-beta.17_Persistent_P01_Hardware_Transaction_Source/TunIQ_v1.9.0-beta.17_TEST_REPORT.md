# TunIQ v1.9.0-beta.17 Test Report

Release: **Persistent P01 Hardware Transaction**  
Base: **v1.9.0-beta.16 Startup Resume-State Reconciliation**  
Verification: source syntax, PCM Hammer process mocks, Windows RFCOMM timing simulations, project persistence, clean archive extraction, and retained recovery tests.

## Repeated physical failure reproduced

The reported sequence was modeled as:

1. P01 Read Properties succeeds on COM4 and identifies OS 9373372.
2. The PCM Hammer process closes.
3. Full Read 1 begins while Windows is still releasing the Bluetooth/RFCOMM serial handle.
4. COM4 fails before PCM communication.

Previous builds either stopped immediately or entered older recovery paths. Beta.17 replaces that handoff with one persistent project-bound hardware transaction.

## New focused verification

### Hardware transaction manager — 4/4 passed

- Same project and COM4 retain one transaction ID.
- The next protected step waits the complete four-second RFCOMM cooldown.
- One controlled five-second COM4 reopen is permitted.
- Another project or COM port receives an isolated transaction.

### Proven-port transaction — 2/2 passed

- First COM4 open fails, controlled COM4 reopen succeeds, and the read completes.
- Both COM4 attempts fail, TunIQ stops with `proven-port-reopen-failed`, and no COM1/COM3 discovery occurs.

## Complete verification

- Source syntax checks: **passed**
- Full automated suite: **50/50 groups passed**
- Complete retained recovery chain: **passed**
- Startup resume-state reconciliation: **passed**
- Full-read progress/watchdog: **passed**
- AI incident replay and safe repair: **passed**
- P01 dual-read and Test Write safeguards: **passed**

## Development progress

| Area | Progress | Remaining priority |
|---|---:|---|
| Overall TunIQ beta | **53%** | Confirm repeatable physical reads and Test Write, then expand outside testing |
| P01 commissioning | **34%** | Complete two matching physical 512 KB reads, exact definition binding, and physical Test Write |
| Hardware bridge and PCM Hammer | **74%** | Confirm the persistent COM4 transaction on the real Windows Bluetooth stack |
| Calibration, definitions and revisions | **35%** | Add trustworthy writable exact-OS definitions and verify real VATS/fan changes |
| AI learning and safe self-repair | **64%** | Add reviewed forum ingestion, resolution feedback, and more approved repair actions |
| Garage, projects and evidence | **73%** | Finish migration/usability testing and evidence views across more controller projects |
| Public beta readiness | **63%** | Installer signing, documentation, multi-PC testing, and outside tester feedback |

Percentages are conservative evidence-weighted estimates. Physical proof is weighted more heavily than simulation coverage.

## Safety boundary

No physical Full Read 1, Test Write, or actual PCM write was performed or claimed in the build environment. Existing BIN validation, exact-XDF, checksum, dual-read, Test Write, recovery, and actual-write confirmation gates remain unchanged.
