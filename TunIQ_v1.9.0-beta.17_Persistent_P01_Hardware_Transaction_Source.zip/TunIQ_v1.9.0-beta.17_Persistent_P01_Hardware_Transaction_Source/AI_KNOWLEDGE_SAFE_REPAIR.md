# AI Knowledge & Safe Self-Repair Foundation

TunIQ beta.10 adds durable project learning, a shared confidence-scored knowledge store, failure-pattern matching, and a bounded repair engine.

Automatic repairs are restricted to approved low-risk state/configuration actions. TunIQ will not automatically modify flashing logic, calibration bytes, XDF addresses, checksum algorithms, controller identity, or PCM Hammer kernels.
