# TunIQ v1.9.0-beta.13 Test Report

Release: **P01 Full-Read Progress & Watchdog**  
Base: **TunIQ v1.9.0-beta.12 AI Incident Replay & Learning Loop**  
Hardware status: **software simulation only; no physical P01 full-read completion or PCM write is claimed.**

## Reported failure reproduced

The Guided P01 workflow could complete Read Properties, start full read 1, and remain near the step-start percentage while PCM Hammer continued running. Flash Center received process output, but Guided P01 Setup did not mirror the active Flash session. A quiet PCM Hammer read therefore looked frozen even when the process or output file was still active.

## Implemented fixes

- Mirrors every active PCM Hammer session into Guided P01 Setup.
- Maps live PCM Hammer read progress into the Guided P01 percentage range for read 1 and read 2.
- Polls the active read output for byte size and modification activity.
- Shows process-alive state, elapsed time, quiet time, and current bytes versus 524,288 bytes.
- Shows a distinct state when the file reaches 524,288 bytes but PCM Hammer completion proof is still pending.
- Keeps quiet reads alive; no failure is inferred merely because PCM Hammer has not printed a new line.
- Adds a 15-minute no-output **and** no-file-activity watchdog for non-destructive full reads.
- Stops only the stalled read process, rejects/renames any incomplete output, and preserves completed Read Properties and prior project evidence.
- Adds Hardware Session Doctor guidance for `read-stalled-no-progress`.
- Retains beta.12 incident replay, AI learning memory, and safe self-repair.

## Focused simulations

**3/3 passed**

1. A deliberately quiet full read wrote the 512 KB image in eight delayed chunks. TunIQ emitted repeated heartbeats and visible intermediate progress before accepting the complete file.
2. A deliberately stalled full read produced a partial file and then stopped all output/file activity. The watchdog terminated only that read, returned `read-stalled-no-progress`, and quarantined the partial file.
3. Static UI contracts verified that Flash progress is mirrored into Guided P01 Setup and the live phase/heartbeat is rendered there.

## Complete verification

- Source syntax checks: **passed**
- Full automated suite: **46/46 groups passed**
- Focused full-read monitor: **3/3 passed**
- Complete retained recovery chain: **passed**
- Existing Connection Broker, Session Guard, Safety Vault, dual-read verification, definition binding, AI incident replay, learning memory, and write boundaries: **retained**

## Safety boundary

A growing or quiet read is never accepted until PCM Hammer exits successfully and the output is exactly **524,288 bytes**. Any partial or incorrectly sized output remains rejected. The watchdog does not apply to calibration write, full write, or recovery operations. No physical PCM operation or real write was performed in the build environment.
