# P01 Pinned Proven-Port Lease

After PCM Hammer completes Read Properties for an active P01 project, TunIQ records the exact COM port as project-bound communication evidence. Protected full reads and Test Write may inherit that port directly.

Beta.15 makes that inherited lease authoritative:

1. The lease contains only the proven COM port.
2. TunIQ releases its own handles and gives PCM Hammer one attempt.
3. A pre-communication open failure stops the current non-destructive step.
4. TunIQ does not repeat the same COM attempt and does not scan COM1 or alternate ports.
5. A later user retry resumes the same project step using the same proven port.

This rule is limited to Read Properties, full reads, and Test Write. Calibration Write, Full Write, and Recovery keep the verified connection broker and all existing safety gates.
