# TunIQ v1.9.0-beta.13 — P01 Full-Read Progress & Watchdog

- Mirrors live PCM Hammer progress into Guided P01 Setup instead of leaving the bar at the step-start percentage.
- Adds a process heartbeat for quiet full reads.
- Reports read-file byte growth and elapsed/quiet time.
- Shows when 524,288 bytes have arrived but PCM Hammer completion proof is still pending.
- Adds a 15-minute no-output/no-file-activity watchdog for non-destructive full reads only.
- Rejects and renames partial files after a stalled read.
- Preserves completed Read Properties, verified reads, revisions, and project evidence.
- Retains beta.12 incident replay, AI learning, and safe self-repair.
