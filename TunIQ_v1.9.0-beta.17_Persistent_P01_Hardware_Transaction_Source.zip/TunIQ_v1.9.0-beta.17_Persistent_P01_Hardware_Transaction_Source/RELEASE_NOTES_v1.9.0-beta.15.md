# TunIQ v1.9.0-beta.15 — Pinned Proven-Port Lease

## Diagnostic reproduced

A real P01 Read Properties operation completed on COM4 and identified OS 9373372. The following full-read step inherited COM4, but the runtime retry engine still classified the direct handoff as recoverable. After the first pre-communication COM4 open failure it retried COM4 and then admitted COM1/COM3 candidates.

## Fix

- Read Properties proof now marks the next protected read/Test Write lease as `pinnedProvenPort`.
- A pinned lease contains one candidate: the exact project-bound proven port.
- Pre-communication open failures on that lease do not retry the same port.
- COM1, COM3, and other alternates cannot be added through runtime rescans.
- Retrying later remains on the same full-read step and the same proven port.
- Completed P01 identity and all protected evidence remain unchanged.
- Actual write operations retain their existing safety gates and cannot use this change to bypass verification.

## Verification

- Exact pinned-port regression: 1/1 passed.
- Proven-port/readiness scenarios: 9/9 passed.
- Full-read progress/watchdog scenarios: 3/3 passed.
- Full automated suite: 48/48 groups passed.
- Retained recovery chain: passed.
- Physical full-read completion is not claimed until tested on the user's bench setup.
- No actual PCM write was performed.
