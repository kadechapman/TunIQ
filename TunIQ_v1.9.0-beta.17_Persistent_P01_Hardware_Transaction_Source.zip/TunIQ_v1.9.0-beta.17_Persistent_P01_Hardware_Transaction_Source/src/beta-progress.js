function clamp(value) { return Math.max(0, Math.min(100, Math.round(Number(value) || 0))); }
function area(id, label, percent, status, next, evidence = []) {
  return { id, label, percent: clamp(percent), status, next, evidence: evidence.filter(Boolean) };
}
function buildBetaProgress({ p01 = null, flash = {}, activeProject = null, knowledge = {}, beta = {}, version = '' } = {}) {
  const identity = p01?.identity || {};
  const readCount = [p01?.readPair?.first, p01?.readPair?.second].filter(Boolean).length;
  const exactDefinition = Boolean(p01?.definition?.path || activeProject?.xdf);
  const writableDefinition = Boolean(exactDefinition && !p01?.definition?.commissioningOnly);
  const selectedRevision = Boolean(p01?.selectedRevision?.path);
  const testWrite = Boolean(p01?.testWrite);
  const integrated = Boolean(flash?.integrated || flash?.configured);
  const provenPort = Boolean(flash?.lastSuccessfulDevice || flash?.config?.lastSuccessfulDevice);
  const identityComplete = Boolean(identity.os && identity.hardwareId && identity.serviceNumber && String(identity.controller || '').toUpperCase() === 'P01');

  const commissioning = 5 + (identityComplete ? 20 : 0) + (readCount >= 1 ? 25 : 0) + (readCount >= 2 && p01?.dualReadVerified ? 25 : 0) + (exactDefinition ? 15 : 0) + (testWrite ? 10 : 0);
  const bridge = 25 + (integrated ? 15 : 0) + (provenPort ? 15 : 0) + (identityComplete ? 10 : 0) + (readCount >= 1 ? 15 : 0) + (testWrite ? 20 : 0);
  const calibration = 35 + (exactDefinition ? 15 : 0) + (writableDefinition ? 20 : 0) + (selectedRevision ? 15 : 0) + (testWrite ? 15 : 0);
  const ai = 48 + (Number(knowledge.incidentClusterCount || 0) > 0 ? 8 : 0) + (Number(knowledge.verifiedIncidentCount || 0) > 0 ? 12 : 0) + (Number(knowledge.projectCount || 0) > 0 ? 7 : 0) + (knowledge.mode?.mode === 'safe-auto-repair' ? 5 : 0) + (Number(knowledge.repairCount || 0) > 0 ? 10 : 0);
  const projectData = 62 + (activeProject ? 10 : 0) + (activeProject?.bin ? 14 : 0) + (activeProject?.xdf ? 14 : 0);
  const betaRelease = 40 + (beta?.agreementAccepted ? 5 : 0) + (beta?.preferences?.improvementOptIn ? 3 : 0) + (Number(beta?.queueCount || 0) >= 0 ? 5 : 0) + (version ? 5 : 0) + (identityComplete ? 5 : 0) + (readCount >= 1 ? 12 : 0) + (testWrite ? 25 : 0);

  const areas = [
    area('p01-commissioning', 'P01 commissioning', commissioning, testWrite ? 'verified' : identityComplete ? 'in-progress' : 'blocked', testWrite ? 'Validate the next controller/OS combination.' : readCount < 1 ? 'Complete the first protected 512 KB read.' : readCount < 2 ? 'Complete the second independent matching read.' : !exactDefinition ? 'Bind the exact OS definition.' : 'Complete Test Write.'),
    area('hardware-bridge', 'Hardware bridge & PCM Hammer', bridge, identityComplete ? 'in-progress' : 'blocked', testWrite ? 'Expand verified adapter coverage.' : 'Preserve the proven COM session through both reads and Test Write.', [flash?.lastSuccessfulDevice ? `Last proven port ${flash.lastSuccessfulDevice}` : '', identity.os ? `OS ${identity.os}` : '']),
    area('calibration', 'Calibration, definitions & revisions', calibration, writableDefinition ? 'in-progress' : 'blocked', writableDefinition ? 'Validate real VATS/fan edits on a second P01.' : 'Obtain a trustworthy writable exact-OS XDF; commissioning-only definitions cannot tune.'),
    area('ai-learning', 'AI learning & safe self-repair', ai, 'in-progress', 'Add reviewed forum ingestion, incident resolution feedback, and more approved low-risk repairs.', [`${Number(knowledge.incidentClusterCount || 0)} incident clusters`, `${Number(knowledge.verifiedIncidentCount || 0)} verified patterns`]),
    area('project-data', 'Garage, projects & evidence', projectData, activeProject ? 'in-progress' : 'blocked', activeProject?.bin && activeProject?.xdf ? 'Expand maintenance, build-history, and multi-controller evidence views.' : 'Finish binding protected project files.'),
    area('public-beta', 'Public beta readiness', betaRelease, testWrite ? 'in-progress' : 'blocked', 'Complete repeatable real-hardware reads/Test Writes, installer signing, documentation, and outside tester feedback.')
  ];
  const weights = { 'p01-commissioning': 0.24, 'hardware-bridge': 0.22, calibration: 0.18, 'ai-learning': 0.14, 'project-data': 0.1, 'public-beta': 0.12 };
  const overall = clamp(areas.reduce((sum, item) => sum + item.percent * (weights[item.id] || 0), 0));
  return {
    version,
    generatedAt: new Date().toISOString(),
    overall,
    label: overall >= 85 ? 'late beta' : overall >= 70 ? 'public-beta candidate' : overall >= 50 ? 'active beta development' : 'foundation',
    note: 'Percentages are evidence-weighted readiness estimates, not guarantees. Real hardware proof carries more weight than software simulations.',
    areas,
    nextPriorities: areas.filter(item => item.percent < 100).sort((a, b) => a.percent - b.percent).slice(0, 4).map(item => ({ id: item.id, label: item.label, percent: item.percent, next: item.next }))
  };
}
module.exports = { buildBetaProgress };
