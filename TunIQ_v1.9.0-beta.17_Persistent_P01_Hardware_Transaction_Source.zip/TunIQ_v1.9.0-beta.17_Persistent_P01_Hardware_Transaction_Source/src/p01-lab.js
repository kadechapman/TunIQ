const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { parseIdentityText, classifyPcmHammerResult, validateP01ReadFile } = require('./flash');
const { classifyConnectionError } = require('./connection-doctor');
const { P01AutoManager } = require('./p01-auto');

const P01_SIZE = 524288;
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function now() { return new Date().toISOString(); }
function step(id, status, message, evidence = {}) { return { id, status, message, evidence, at: now() }; }

class P01LabManager {
  constructor(options) { this.dataRoot = options.dataRoot; this.appendActivity = options.appendActivity || (() => {}); }
  root() { return ensureDir(path.join(this.dataRoot(), 'Labs', 'P01Recovery')); }
  latestFile() { return path.join(this.root(), 'latest.json'); }
  status() { return readJson(this.latestFile(), null); }
  scenarioRoot(runId, scenario) { return ensureDir(path.join(this.root(), runId, scenario)); }
  writeRead(folder, name, seed, size = P01_SIZE) {
    const file = path.join(folder, name); const buffer = Buffer.alloc(size);
    for (let index = 0; index < size; index += 1) buffer[index] = (seed + index * 17 + Math.floor(index / 4096)) & 0xff;
    fs.writeFileSync(file, buffer); return file;
  }
  parseProperties() {
    const text = [
      'PCM Hammer 2.0', 'Reading properties...', 'OSID: 12212156', 'Description: 2001 LM7 P01 Service No 09354896',
      'Hardware ID: 9386530', 'Controller: P01', 'Voltage: 13.4V', 'Read Properties complete.'
    ].join('\n');
    const result = classifyPcmHammerResult('readProperties', text, 0); const identity = parseIdentityText(text);
    return { text, result, identity };
  }
  runScenario(runId, scenario) {
    const folder = this.scenarioRoot(runId, scenario); const steps = [];
    const properties = this.parseProperties();
    if (!properties.result.success || properties.identity.os !== '12212156' || properties.identity.controller !== 'P01') throw new Error('Lab property parser did not produce complete P01 identity.');
    steps.push(step('read-properties', 'passed', 'Real-format PCM Hammer 2.0 properties were parsed.', properties.identity));

    if (scenario === 'clean-success') {
      const first = this.writeRead(folder, 'read-1.bin', 31); const second = this.writeRead(folder, 'read-2.bin', 31);
      const one = validateP01ReadFile(first, { success: true }); const two = validateP01ReadFile(second, { success: true });
      if (!one.valid || !two.valid || one.sha256 !== two.sha256) throw new Error('Clean lab reads did not validate as a matching pair.');
      steps.push(step('read-1', 'passed', 'First complete 524,288-byte read accepted.', { size: one.size, sha256: one.sha256 }));
      steps.push(step('read-2', 'passed', 'Second complete read matched SHA-256.', { size: two.size, sha256: two.sha256 }));
      steps.push(step('resume-ledger', 'passed', 'Workflow reached definition binding with no recovery stop.'));
    } else if (scenario === 'adapter-lock-resume') {
      const locked = classifyConnectionError('Access to COM4 is denied because it is being used by another process.');
      const active = { id: `lab-${runId}`, name: 'Offline P01 Recovery Lab', folder, controller: 'P01', os: '12212156' };
      const firstProcess = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'offline-lab-process-a' });
      firstProcess.begin({ request: 'offline recovery validation', voltage: 13.4, exactXdfAuthorization: true, autoMapAuthorized: true, autoRevisionAuthorized: true, testWriteAuthorized: true, confirmations: {} });
      firstProcess.completeStep('preflight', 'read-properties', 8, 'Offline lab preflight complete.');
      firstProcess.pause(locked.code, locked.message, { resumePhase: 'read-properties' });
      const restarted = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'offline-lab-process-b' });
      const persistedStop = restarted.load();
      if (persistedStop.stop?.code !== 'adapter-locked' || persistedStop.resumePhase !== 'read-properties') throw new Error('Adapter-lock stop did not persist at the exact step.');
      const resumed = restarted.resume();
      if (resumed.phase !== 'read-properties') throw new Error('Adapter-lock restart did not resume at Read Properties.');
      restarted.advance('waiting-read-1', 20, 'First read started.');
      const duringStepRestart = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'offline-lab-process-c' }).load();
      if (duringStepRestart.status !== 'resume-ready' || duringStepRestart.phase !== 'read-1' || duringStepRestart.resumePhase !== 'read-1') throw new Error('Waiting-step restart did not become ready to resume at Read 1.');
      steps.push(step('adapter-lock', 'passed', 'The production ledger persisted one named adapter-lock stop.', { code: persistedStop.stop.code, resumePhase: persistedStop.resumePhase }));
      steps.push(step('exact-step-resume', 'passed', 'The production ledger resumed at Read Properties, then converted an interrupted Read 1 into a user-controlled Ready to Resume state.', { resumedPhase: resumed.phase, restartStatus: duringStepRestart.status, restartResumePhase: duringStepRestart.resumePhase }));
      const first = this.writeRead(folder, 'read-1.bin', 41); const second = this.writeRead(folder, 'read-2.bin', 41);
      const one = validateP01ReadFile(first, { success: true }); const two = validateP01ReadFile(second, { success: true });
      if (!one.valid || !two.valid || one.sha256 !== two.sha256) throw new Error('Recovery lab reads did not validate.');
      steps.push(step('recovered-read-pair', 'passed', 'The resumed run produced two complete matching reads.', { sha256: one.sha256 }));
    } else if (scenario === 'read-integrity-recovery') {
      const partial = this.writeRead(folder, 'partial.bin', 51, 131072); const partialResult = validateP01ReadFile(partial, { success: true });
      if (partialResult.valid || partialResult.code !== 'read-size-partial') throw new Error('Partial read was not rejected by exact size.');
      steps.push(step('partial-read', 'passed', 'A 131,072-byte partial read was rejected.', partialResult));
      const mismatchA = this.writeRead(folder, 'mismatch-a.bin', 61); const mismatchB = this.writeRead(folder, 'mismatch-b.bin', 62);
      const a = validateP01ReadFile(mismatchA, { success: true }); const b = validateP01ReadFile(mismatchB, { success: true });
      if (!a.valid || !b.valid || a.sha256 === b.sha256) throw new Error('Mismatch scenario did not produce two different complete reads.');
      steps.push(step('hash-mismatch', 'passed', 'Two complete reads with different SHA-256 hashes were preserved and rejected as a pair.', { first: a.sha256, second: b.sha256 }));
      const failureText = 'Block 0x004000 failed. Retrying. Block 0x004000 failed. Retrying. Block 0x004000 failed. Read operation failed.';
      const classified = classifyPcmHammerResult('read', failureText, 1);
      if (classified.stopCode !== 'repeated-block-read-failures') throw new Error('Repeated block-read failure was not classified.');
      steps.push(step('block-read-failure', 'passed', 'Repeated block failures produced one actionable stop.', classified));
      const goodA = this.writeRead(folder, 'recovery-1.bin', 71); const goodB = this.writeRead(folder, 'recovery-2.bin', 71);
      if (sha256(goodA) !== sha256(goodB)) throw new Error('Recovery pair did not match.');
      steps.push(step('fresh-read-pair', 'passed', 'A fresh two-read pair matched after the integrity stops.', { sha256: sha256(goodA) }));
    } else throw new Error(`Unknown P01 lab scenario: ${scenario}`);

    const passed = steps.every(item => item.status === 'passed');
    return { scenario, passed, steps, folder };
  }
  runAll() {
    const runId = new Date().toISOString().replace(/[:.]/g, '-');
    const scenarios = ['clean-success', 'adapter-lock-resume', 'read-integrity-recovery'].map(name => {
      try { return this.runScenario(runId, name); }
      catch (error) { return { scenario: name, passed: false, steps: [step('scenario-error', 'failed', error.message)], error: error.message }; }
    });
    const report = { type: 'tuniq-p01-offline-recovery-lab', version: 1, runId, startedAt: now(), finishedAt: now(), passed: scenarios.every(item => item.passed), scenarios };
    const file = path.join(this.root(), `p01-lab-${runId}.json`); report.reportFile = file; writeJson(file, report); writeJson(this.latestFile(), report);
    this.appendActivity('p01-offline-lab-complete', { passed: report.passed, reportFile: file, scenarios: scenarios.map(item => ({ scenario: item.scenario, passed: item.passed })) });
    return report;
  }
}


module.exports = { P01LabManager, P01_SIZE };
