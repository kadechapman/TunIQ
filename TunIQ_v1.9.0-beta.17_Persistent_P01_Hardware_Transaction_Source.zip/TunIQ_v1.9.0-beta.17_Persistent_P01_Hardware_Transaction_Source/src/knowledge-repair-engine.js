const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const SAFE_REPAIRS = new Set([
  'clear-stale-hardware-status',
  'remove-stale-com-cache',
  'rebuild-missing-folders',
  'repair-ui-preferences',
  'reconcile-project-metadata'
]);
const FORBIDDEN_AUTO_AREAS = ['flash','write','kernel','checksum','xdf-address','controller-identity','bin-byte'];

function now(){ return new Date().toISOString(); }
function idFor(value){ return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex').slice(0,20); }
function readJson(file,fallback){ try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return fallback;} }
function writeJson(file,value){ fs.mkdirSync(path.dirname(file),{recursive:true}); fs.writeFileSync(file,JSON.stringify(value,null,2)); }
function sanitize(value){
  const text=JSON.stringify(value??{}).replace(/[A-Z0-9]{17}/gi,'[REDACTED_VIN]').replace(/[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}/g,'[REDACTED_EMAIL]');
  return JSON.parse(text);
}
function compact(value,max=240){return String(value??'').replace(/\s+/g,' ').trim().slice(0,max);}
function extractIncidentContext(report={}){
  const replay=report.incidentReplay||{};
  const summary=replay.summary||report.aiIncidentAnalysis||{};
  const hardware=report.hardwareSession||{};
  const flash=report.flash||{};
  const project=report.activeProject||{};
  const stopCode=summary.stopCode||hardware.stopCode||hardware.recoveryCode||flash.stopCode||flash.lastStopCode||null;
  const inferredLayer=summary.inferredLayer||'application-workflow';
  const symptom=compact(summary.likelyCause||hardware.summary||flash.message||report.userDescription||`TunIQ incident in ${inferredLayer}`);
  return {
    stopCode:stopCode?compact(stopCode,120):null,
    inferredLayer:compact(inferredLayer,80),
    symptom,
    lastUserAction:compact(summary.lastUserAction||'',180)||null,
    controller:project.controller||null,
    os:project.os||null,
    adapter:report.device?.connection?.adapter||report.connectionProfile?.adapterName||null,
    port:report.device?.connection?.port||report.connectionProfile?.lastWorkingPort||null,
    appVersion:report.appVersion||null,
    projectId:project.id||null,
    eventCount:Number(summary.eventCount||replay.events?.length||0),
    confidence:Number(summary.confidence||0)
  };
}
class KnowledgeRepairEngine{
  constructor({dataRoot,getActiveProject=()=>null,appendActivity=()=>{}}){this.dataRoot=dataRoot;this.getActiveProject=getActiveProject;this.appendActivity=appendActivity;}
  root(){return path.join(this.dataRoot(),'AI','Knowledge');}
  globalFile(){return path.join(this.root(),'verified-knowledge.json');}
  repairFile(){return path.join(this.root(),'repair-history.json');}
  incidentFile(){return path.join(this.root(),'incident-clusters.json');}
  projectFile(project=this.getActiveProject()){if(!project?.folder)return null;return path.join(project.folder,'AI','learning-memory.json');}
  settings(){return readJson(path.join(this.root(),'settings.json'),{mode:'recommend',forumImport:false,communityLearning:false});}
  incidentClusters(){const value=readJson(this.incidentFile(),[]);return Array.isArray(value)?value:[];}
  state(){const project=this.getActiveProject();const clusters=this.incidentClusters();return {mode:this.settings(),globalCount:readJson(this.globalFile(),[]).length,projectCount:this.projectFile(project)?readJson(this.projectFile(project),[]).length:0,repairCount:readJson(this.repairFile(),[]).length,incidentClusterCount:clusters.length,verifiedIncidentCount:clusters.filter(item=>item.status==='verified').length,totalIncidentOccurrences:clusters.reduce((n,item)=>n+Number(item.occurrences||0),0),safeRepairs:[...SAFE_REPAIRS],forbiddenAutoAreas:FORBIDDEN_AUTO_AREAS};}
  setMode(mode){if(!['observe','recommend','safe-auto-repair'].includes(mode))throw new Error('Invalid learning mode.');const settings={...this.settings(),mode,updatedAt:now()};writeJson(path.join(this.root(),'settings.json'),settings);return this.state();}
  recordProjectLearning(event){const project=this.getActiveProject();if(!project?.folder)throw new Error('Create or activate a project first.');const file=this.projectFile(project);const list=readJson(file,[]);const clean=sanitize(event);const item={id:idFor({projectId:project.id,event:clean}),projectId:project.id,controller:project.controller||null,os:project.os||null,at:now(),...clean};if(!list.some(x=>x.id===item.id))list.push(item);writeJson(file,list.slice(-1000));return item;}
  submitKnowledge(entry){const clean=sanitize(entry);if(!clean.source||!clean.symptom||!clean.confirmedFix)throw new Error('Source, symptom, and confirmed fix are required.');const item={id:idFor(clean),status:clean.status==='verified'?'verified':'candidate',confidence:Math.max(0,Math.min(1,Number(clean.confidence||0))),at:now(),...clean};const list=readJson(this.globalFile(),[]);const idx=list.findIndex(x=>x.id===item.id);if(idx>=0)list[idx]=item;else list.push(item);writeJson(this.globalFile(),list.slice(-5000));return item;}
  findMatches(context={}){const all=readJson(this.globalFile(),[]);const hay=JSON.stringify(sanitize(context)).toLowerCase();return all.map(item=>{const terms=[item.symptom,item.code,item.controller,item.os,item.hardware].filter(Boolean).map(String);const score=terms.reduce((n,t)=>n+(hay.includes(t.toLowerCase())?1:0),0)+(item.status==='verified'?1:0);return {...item,matchScore:score};}).filter(x=>x.matchScore>0).sort((a,b)=>b.matchScore-a.matchScore||b.confidence-a.confidence).slice(0,10);}
  incidentInsights(context={}){const clean=sanitize(context);const hay=JSON.stringify(clean).toLowerCase();return this.incidentClusters().map(item=>{const terms=[item.stopCode,item.inferredLayer,item.controller,item.os,item.adapter,item.lastUserAction].filter(Boolean).map(String);const matchScore=terms.reduce((score,term)=>score+(hay.includes(term.toLowerCase())?1:0),0)+(item.status==='verified'?2:0);return {...item,matchScore};}).filter(item=>item.matchScore>0).sort((a,b)=>b.matchScore-a.matchScore||Number(b.confidence||0)-Number(a.confidence||0)).slice(0,10);}
  ingestIncidentReport(report={}){
    const context=extractIncidentContext(sanitize(report));
    const signatureFields={stopCode:context.stopCode,inferredLayer:context.inferredLayer,controller:context.controller,os:context.os,adapter:context.adapter,lastUserAction:context.lastUserAction};
    const signature=idFor(signatureFields);
    const clusters=this.incidentClusters();
    const index=clusters.findIndex(item=>item.signature===signature);
    const previous=index>=0?clusters[index]:null;
    const occurrences=Number(previous?.occurrences||0)+1;
    const confidence=Math.min(0.95,Math.max(Number(previous?.confidence||0),0.25+(context.stopCode?0.18:0)+(context.eventCount>=3?0.12:0)+Math.min(0.3,occurrences*0.06)));
    const projectIds=[...(previous?.projectIds||[]),context.projectId].filter(Boolean).filter((value,i,array)=>array.indexOf(value)===i).slice(-25);
    const item={
      id:previous?.id||`incident-${signature}`,
      signature,
      status:previous?.status||'candidate',
      firstSeenAt:previous?.firstSeenAt||now(),
      lastSeenAt:now(),
      occurrences,
      fixedCount:Number(previous?.fixedCount||0),
      failedRepairCount:Number(previous?.failedRepairCount||0),
      confidence,
      ...signatureFields,
      symptom:context.symptom,
      appVersions:[...(previous?.appVersions||[]),context.appVersion].filter(Boolean).filter((value,i,array)=>array.indexOf(value)===i).slice(-12),
      projectIds,
      lastPort:context.port,
      evidence:{eventCount:context.eventCount,reportCreatedAt:report.createdAt||now(),reportSchema:report.schemaVersion||null}
    };
    if(index>=0)clusters[index]=item;else clusters.push(item);
    writeJson(this.incidentFile(),clusters.slice(-5000));
    const active=this.getActiveProject();
    if(active?.folder){try{this.recordProjectLearning({type:'diagnostic-incident',incidentSignature:signature,stopCode:context.stopCode,inferredLayer:context.inferredLayer,symptom:context.symptom,confidence});}catch{}}
    this.appendActivity('ai-incident-learned',{signature,occurrences,stopCode:context.stopCode,inferredLayer:context.inferredLayer,confidence});
    return item;
  }
  recordIncidentResolution({signature='',outcome='',repairId='',notes=''}={}){
    const normalized=String(outcome||'').toLowerCase();
    if(!['fixed','not-fixed','unknown'].includes(normalized))throw new Error('Outcome must be fixed, not-fixed, or unknown.');
    const clusters=this.incidentClusters();const index=clusters.findIndex(item=>item.signature===signature||item.id===signature);if(index<0)throw new Error('Incident learning record was not found.');
    const item={...clusters[index]};
    if(normalized==='fixed')item.fixedCount=Number(item.fixedCount||0)+1;
    if(normalized==='not-fixed')item.failedRepairCount=Number(item.failedRepairCount||0)+1;
    item.lastResolution={at:now(),outcome:normalized,repairId:repairId||null,notes:compact(notes,500)};
    if(item.fixedCount>=2&&item.failedRepairCount===0){item.status='verified';item.confidence=Math.max(Number(item.confidence||0),0.86);}
    clusters[index]=item;writeJson(this.incidentFile(),clusters);
    this.appendActivity('ai-incident-resolution-recorded',{signature:item.signature,outcome:normalized,repairId:repairId||null,status:item.status});
    return item;
  }
  proposeRepair(context={}){const matches=this.findMatches(context);const incidents=this.incidentInsights(context);const requested=context.repairId;const repairId=requested||matches.find(x=>SAFE_REPAIRS.has(x.repairId))?.repairId||incidents.find(x=>SAFE_REPAIRS.has(x.repairId))?.repairId||null;if(!repairId)return {available:false,matches,incidents,reason:'No approved safe repair matches this failure.'};if(!SAFE_REPAIRS.has(repairId))return {available:false,matches,incidents,reason:'This repair is not approved for automatic execution.'};const lower=JSON.stringify(context).toLowerCase();if(FORBIDDEN_AUTO_AREAS.some(x=>lower.includes(x)))return {available:false,matches,incidents,reason:'Automatic repair is blocked around flashing, calibration bytes, identity, kernels, or checksums.'};return {available:true,repairId,matches,incidents,requiresConfirmation:this.settings().mode!=='safe-auto-repair'};}
  applySafeRepair(repairId,context={}){if(!SAFE_REPAIRS.has(repairId))throw new Error('Repair is not approved for automatic execution.');const proposal=this.proposeRepair({...context,repairId});if(!proposal.available)throw new Error(proposal.reason);const project=this.getActiveProject();const changed=[];
    if(repairId==='rebuild-missing-folders'){for(const name of ['Logs','Reports','AI','Backups']){const folder=project?.folder?path.join(project.folder,name):path.join(this.dataRoot(),name);if(!fs.existsSync(folder)){fs.mkdirSync(folder,{recursive:true});changed.push(folder);}}}
    if(repairId==='clear-stale-hardware-status'&&project?.folder){for(const name of ['hardware-session-status.json','p01-live-operation.json']){const f=path.join(project.folder,'Reports',name);if(fs.existsSync(f)){fs.renameSync(f,`${f}.stale-${Date.now()}`);changed.push(f);}}}
    if(repairId==='remove-stale-com-cache'){const f=path.join(this.dataRoot(),'Tools','obdlink-adapter-profile.json');if(fs.existsSync(f)){const value=readJson(f,{});delete value.lastWorkingPort;delete value.recommendedPort;writeJson(f,value);changed.push(f);}}
    if(repairId==='repair-ui-preferences'){const f=path.join(this.dataRoot(),'Settings','ui.json');writeJson(f,{detailLevel:'beginner',sidebarCollapsed:false,updatedAt:now()});changed.push(f);}
    if(repairId==='reconcile-project-metadata'&&project?.folder){const manifest=path.join(project.folder,'project.json');const value=readJson(manifest,{});writeJson(manifest,{...value,id:project.id,name:project.name,controller:project.controller||value.controller||null,os:project.os||value.os||null,updatedAt:now()});changed.push(manifest);}
    const history=readJson(this.repairFile(),[]);const record={id:idFor({repairId,at:now(),projectId:project?.id}),repairId,projectId:project?.id||null,at:now(),changed,context:sanitize(context),rollbackAvailable:true};history.push(record);writeJson(this.repairFile(),history.slice(-1000));this.appendActivity('ai-safe-repair',{message:`Applied ${repairId}`,detail:changed.join(', ')});return record;
  }
}
module.exports={KnowledgeRepairEngine,SAFE_REPAIRS,FORBIDDEN_AUTO_AREAS,extractIncidentContext};
