const fs = require('fs');
const path = require('path');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function clean(value, max = 240) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max); }
function normalizePort(value) { const match = clean(value, 40).toUpperCase().match(/^COM\d+$/); return match ? match[0] : ''; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0))); }

class P01HardwareTransactionManager {
  constructor(options = {}) {
    this.dataRoot = options.dataRoot || (() => process.cwd());
    this.platform = options.platform || process.platform;
    this.now = options.now || (() => Date.now());
    this.sleep = options.sleep || sleep;
    this.interOperationCooldownMs = Math.max(0, Number(options.interOperationCooldownMs ?? (this.platform === 'win32' ? 4000 : 15)));
    this.reopenRecoveryDelayMs = Math.max(0, Number(options.reopenRecoveryDelayMs ?? (this.platform === 'win32' ? 5000 : 20)));
  }

  file() { return path.join(this.dataRoot(), 'Devices', 'p01-hardware-transaction.json'); }
  blank() {
    return {
      version: 1,
      transactionId: '',
      projectId: '',
      controller: '',
      os: '',
      port: '',
      state: 'idle',
      currentOperation: '',
      lastSuccessfulOperation: '',
      lastSessionId: '',
      lastWorkflowAttemptId: '',
      recoveryCount: 0,
      openedAt: null,
      processStartedAt: null,
      processClosedAt: null,
      updatedAt: new Date(this.now()).toISOString(),
      history: []
    };
  }
  load() { return { ...this.blank(), ...(readJson(this.file(), null) || {}) }; }
  save(patch = {}, event = null) {
    const current = this.load();
    const history = Array.isArray(current.history) ? current.history.slice(-39) : [];
    if (event) history.push({ at: new Date(this.now()).toISOString(), ...event });
    const next = { ...current, ...patch, history, updatedAt: new Date(this.now()).toISOString() };
    writeJson(this.file(), next);
    return next;
  }
  begin({ projectId = '', controller = 'P01', os = '', port = '', operation = '', sessionId = '', workflowAttemptId = '' } = {}) {
    const normalizedPort = normalizePort(port);
    const current = this.load();
    const sameTransaction = Boolean(
      current.transactionId &&
      current.projectId === clean(projectId, 160) &&
      current.port === normalizedPort
    );
    const transactionId = sameTransaction ? current.transactionId : `${this.now()}-${clean(projectId || 'p01', 80)}-${normalizedPort || 'auto'}`;
    return this.save({
      transactionId,
      projectId: clean(projectId, 160),
      controller: clean(controller || 'P01', 40).toUpperCase(),
      os: clean(os, 40),
      port: normalizedPort,
      state: 'preparing',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      lastWorkflowAttemptId: clean(workflowAttemptId, 160),
      recoveryCount: sameTransaction && current.currentOperation === operation ? Number(current.recoveryCount || 0) : 0,
      openedAt: sameTransaction ? current.openedAt : new Date(this.now()).toISOString()
    }, { type: 'operation-preparing', operation: clean(operation, 80), port: normalizedPort });
  }
  requiredCooldown(port = '') {
    const current = this.load();
    const normalizedPort = normalizePort(port);
    if (!normalizedPort || current.port !== normalizedPort || !current.processClosedAt) return 0;
    const closedAt = Date.parse(current.processClosedAt);
    if (!Number.isFinite(closedAt)) return 0;
    return Math.max(0, this.interOperationCooldownMs - (this.now() - closedAt));
  }
  async settleBeforeOpen(port = '', onWait = null) {
    const waitMs = this.requiredCooldown(port);
    if (waitMs > 0) {
      this.save({ state: 'settling' }, { type: 'inter-operation-cooldown', port: normalizePort(port), waitMs });
      if (typeof onWait === 'function') onWait(waitMs);
      await this.sleep(waitMs);
    }
    this.save({ state: 'ready-to-open' }, { type: 'port-ready-to-open', port: normalizePort(port), waitedMs: waitMs });
    return waitMs;
  }
  markProcessStarted({ port = '', operation = '', sessionId = '', workflowAttemptId = '' } = {}) {
    return this.save({
      port: normalizePort(port) || this.load().port,
      state: 'process-running',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      lastWorkflowAttemptId: clean(workflowAttemptId, 160),
      processStartedAt: new Date(this.now()).toISOString(),
      processClosedAt: null
    }, { type: 'pcmhammer-process-started', operation: clean(operation, 80), port: normalizePort(port) });
  }
  markProcessClosed({ port = '', operation = '', sessionId = '', success = false, stopCode = '' } = {}) {
    return this.save({
      port: normalizePort(port) || this.load().port,
      state: success ? 'operation-complete' : 'process-closed',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      processClosedAt: new Date(this.now()).toISOString(),
      lastSuccessfulOperation: success ? clean(operation, 80) : this.load().lastSuccessfulOperation,
      recoveryCount: success ? 0 : Number(this.load().recoveryCount || 0)
    }, { type: 'pcmhammer-process-closed', operation: clean(operation, 80), port: normalizePort(port), success: Boolean(success), stopCode: clean(stopCode, 120) });
  }
  canAttemptControlledReopen({ port = '', operation = '', communicationStarted = false, stopCode = '' } = {}) {
    const current = this.load();
    return Boolean(
      normalizePort(port) && current.port === normalizePort(port) &&
      ['read', 'testWrite'].includes(clean(operation, 80)) &&
      !communicationStarted &&
      ['adapter-open-timeout', 'adapter-open-failed', 'adapter-locked', 'adapter-handoff-failed'].includes(clean(stopCode, 120)) &&
      Number(current.recoveryCount || 0) < 1
    );
  }
  async controlledReopen({ port = '', operation = '', stopCode = '', onWait = null } = {}) {
    const normalizedPort = normalizePort(port);
    const nextCount = Number(this.load().recoveryCount || 0) + 1;
    this.save({ state: 'controlled-reopen', recoveryCount: nextCount, processClosedAt: new Date(this.now()).toISOString() }, {
      type: 'controlled-same-port-reopen', port: normalizedPort, operation: clean(operation, 80), stopCode: clean(stopCode, 120), waitMs: this.reopenRecoveryDelayMs
    });
    if (typeof onWait === 'function') onWait(this.reopenRecoveryDelayMs);
    await this.sleep(this.reopenRecoveryDelayMs);
    this.save({ state: 'ready-to-open' }, { type: 'controlled-reopen-ready', port: normalizedPort, operation: clean(operation, 80) });
    return { port: normalizedPort, waitMs: this.reopenRecoveryDelayMs, recoveryCount: nextCount };
  }
  snapshot() { return this.load(); }
  reset(reason = 'manual reset') { return this.save(this.blank(), { type: 'transaction-reset', reason: clean(reason, 240) }); }
}

module.exports = { P01HardwareTransactionManager, normalizePort };
