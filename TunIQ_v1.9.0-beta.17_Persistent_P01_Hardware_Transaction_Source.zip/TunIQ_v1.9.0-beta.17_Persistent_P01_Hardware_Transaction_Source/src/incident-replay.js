const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DEFAULT_WINDOW_MS = 60_000;
const MAX_EVENTS = 1200;
const PRIVATE_KEYS = new Set([
  'vin','email','password','token','secret','apikey','apiKey','rawbin','binbytes','filebytes','content',
  'bluetoothaddress','macaddress','pairkey','identitykey','instanceid','containerid','parentid'
].map(value => value.toLowerCase()));

function now() { return new Date().toISOString(); }
function idFor(value) { return crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex').slice(0, 24); }
function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); }
function cleanText(value, max = 500) {
  return String(value ?? '')
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, '[email redacted]')
    .replace(/\b(?![IOQ])[A-HJ-NPR-Z0-9]{17}\b/gi, '[VIN redacted]')
    .replace(/(?:[A-Z]:\\Users\\|\/Users\/|\/home\/)[^\\/\s]+/gi, match => match.replace(/[^\\/]+$/, '[user]'))
    .slice(0, max);
}
function sanitize(value, key = '', depth = 0) {
  if (depth > 8) return '[depth limited]';
  if (PRIVATE_KEYS.has(String(key || '').toLowerCase())) return '[redacted]';
  if (Buffer.isBuffer(value)) return `[buffer ${value.length} bytes omitted]`;
  if (Array.isArray(value)) return value.slice(0, 100).map(item => sanitize(item, '', depth + 1));
  if (value && typeof value === 'object') {
    const output = {};
    for (const [childKey, childValue] of Object.entries(value)) {
      if (PRIVATE_KEYS.has(childKey.toLowerCase())) { output[childKey] = '[redacted]'; continue; }
      output[childKey] = sanitize(childValue, childKey, depth + 1);
    }
    return output;
  }
  if (typeof value === 'string') return cleanText(value);
  if (['number','boolean'].includes(typeof value) || value == null) return value;
  return cleanText(value);
}
function extractStopCode(events) {
  for (const event of [...events].reverse()) {
    const text = JSON.stringify(event).toLowerCase();
    const explicit = event?.details?.stopCode || event?.details?.code || event?.details?.recoveryCode;
    if (explicit) return cleanText(explicit, 120);
    const match = text.match(/(?:recovery code|stop code|stopped)[^a-z0-9-]*([a-z][a-z0-9-]{3,})/i);
    if (match) return match[1];
  }
  return null;
}
function inferLayer(stopCode, events) {
  const hay = `${stopCode || ''} ${JSON.stringify(events)}`.toLowerCase();
  if (/bluetooth|spp|rfcomm|serial|com\d|adapter-open|port/.test(hay)) return 'adapter-connection';
  if (/definition|xdf|universal patcher|os mismatch/.test(hay)) return 'definition-resolution';
  if (/read properties|readproperties|controller identity|osid/.test(hay)) return 'controller-identification';
  if (/test write|flash|write calibration|recovery kernel/.test(hay)) return 'pcm-operation';
  if (/renderer|button|navigation|page|ui/.test(hay)) return 'user-interface';
  return 'application-workflow';
}
function summarize(events, context = {}) {
  const lastEvent = events[events.length - 1] || null;
  const lastUiAction = [...events].reverse().find(event => event.source === 'renderer' && ['click','navigate','change'].includes(event.type)) || null;
  const errorEvents = events.filter(event => /error|stopped|failed|timeout|exception|rejection/i.test(`${event.type} ${JSON.stringify(event.details || {})}`));
  const stopCode = extractStopCode(events);
  const layer = inferLayer(stopCode, events);
  const action = lastUiAction?.details?.label || lastUiAction?.details?.targetId || lastUiAction?.details?.page || lastUiAction?.type || null;
  const likelyCause = {
    'adapter-connection': 'The failure occurred before reliable adapter communication was established.',
    'definition-resolution': 'The workflow reached calibration-definition resolution without enough verified controller or OS evidence.',
    'controller-identification': 'The controller identity step did not produce complete accepted evidence.',
    'pcm-operation': 'A managed PCM operation stopped before TunIQ accepted a proven result.',
    'user-interface': 'The visible workflow state or navigation did not match the latest operation.',
    'application-workflow': 'The operation stopped inside the application workflow and needs the captured timeline for diagnosis.'
  }[layer];
  return {
    capturedSeconds: Math.round(Number(context.windowMs || DEFAULT_WINDOW_MS) / 1000),
    eventCount: events.length,
    firstEventAt: events[0]?.at || null,
    lastEventAt: lastEvent?.at || null,
    currentPage: cleanText(context.currentPage || lastUiAction?.details?.page || '', 80),
    lastUserAction: action ? cleanText(action, 180) : null,
    stopCode,
    inferredLayer: layer,
    likelyCause,
    errorEventCount: errorEvents.length,
    confidence: stopCode ? 0.82 : errorEvents.length ? 0.64 : 0.42
  };
}

class IncidentReplayRecorder {
  constructor({ dataRoot, windowMs = DEFAULT_WINDOW_MS, maxEvents = MAX_EVENTS } = {}) {
    this.dataRoot = dataRoot;
    this.windowMs = Math.max(10_000, Math.min(120_000, Number(windowMs || DEFAULT_WINDOW_MS)));
    this.maxEvents = Math.max(100, Math.min(5000, Number(maxEvents || MAX_EVENTS)));
    this.events = [];
    this.snapshots = new Map();
  }
  root() { return path.join(this.dataRoot(), 'Beta', 'IncidentReplay'); }
  prune(reference = Date.now()) {
    const cutoff = reference - Math.max(this.windowMs * 2, 180_000);
    this.events = this.events.filter(event => Date.parse(event.at) >= cutoff).slice(-this.maxEvents);
  }
  record(type, details = {}, meta = {}) {
    const event = {
      id: idFor({ at: now(), type, nonce: Math.random() }),
      at: now(),
      source: cleanText(meta.source || 'main', 40),
      type: cleanText(type || 'event', 80),
      details: sanitize(details)
    };
    this.events.push(event);
    this.prune();
    return event;
  }
  recordUi(payload = {}) {
    const allowed = {
      action: cleanText(payload.action || payload.type || 'ui', 50),
      targetId: cleanText(payload.targetId || '', 120),
      label: cleanText(payload.label || '', 180),
      page: cleanText(payload.page || '', 80),
      controlType: cleanText(payload.controlType || '', 50),
      checked: typeof payload.checked === 'boolean' ? payload.checked : undefined,
      selectedIndex: Number.isInteger(payload.selectedIndex) ? payload.selectedIndex : undefined,
      error: payload.error ? cleanText(payload.error, 300) : undefined
    };
    return this.record(allowed.action, allowed, { source: 'renderer' });
  }
  recent(windowMs = this.windowMs) {
    const normalized = Math.max(10_000, Math.min(120_000, Number(windowMs || this.windowMs)));
    const cutoff = Date.now() - normalized;
    this.prune();
    return this.events.filter(event => Date.parse(event.at) >= cutoff).map(event => sanitize(event));
  }
  capture(context = {}) {
    const windowMs = Math.max(10_000, Math.min(120_000, Number(context.windowMs || this.windowMs)));
    const events = this.recent(windowMs);
    const capturedAt = now();
    const snapshot = {
      id: idFor({ capturedAt, events: events.map(event => event.id), currentPage: context.currentPage || '' }),
      schemaVersion: 1,
      capturedAt,
      windowMs,
      privacy: { inputValuesIncluded: false, rawBinIncluded: false, rawXdfIncluded: false, credentialsIncluded: false },
      context: sanitize({ currentPage: context.currentPage || '', reason: context.reason || 'report-bug' }),
      summary: summarize(events, { ...context, windowMs }),
      events
    };
    this.snapshots.set(snapshot.id, snapshot);
    ensureDir(this.root());
    fs.writeFileSync(path.join(this.root(), `${snapshot.id}.json`), JSON.stringify(snapshot, null, 2));
    fs.writeFileSync(path.join(this.root(), 'latest.json'), JSON.stringify(snapshot, null, 2));
    return snapshot;
  }
  get(id = '') {
    if (id && this.snapshots.has(id)) return this.snapshots.get(id);
    const file = id ? path.join(this.root(), `${id}.json`) : path.join(this.root(), 'latest.json');
    try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return null; }
  }
  current(context = {}) {
    const events = this.recent(context.windowMs || this.windowMs);
    return { schemaVersion: 1, capturedAt: now(), windowMs: context.windowMs || this.windowMs, privacy: { inputValuesIncluded: false }, context: sanitize(context), summary: summarize(events, context), events };
  }
  status() {
    const events = this.recent();
    return { windowSeconds: Math.round(this.windowMs / 1000), eventCount: events.length, oldestAt: events[0]?.at || null, newestAt: events[events.length - 1]?.at || null, latestSnapshot: this.get()?.id || null };
  }
}

module.exports = { IncidentReplayRecorder, DEFAULT_WINDOW_MS, sanitize, summarize, inferLayer };
