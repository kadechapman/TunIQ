function clean(value, max = 400) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}
function normalizePort(value) {
  const match = clean(value, 40).toUpperCase().match(/^COM\d+$/);
  return match ? match[0] : '';
}
function identityMatchesProject(session = {}, p01 = {}) {
  const identity = session.identity || session.result?.identity || {};
  const controller = clean(identity.controller || p01.identity?.controller || '', 40).toUpperCase();
  const expectedOs = clean(p01.identity?.os || '', 40);
  const sessionOs = clean(identity.os || identity.osid || '', 40);
  if (controller && controller !== 'P01') return false;
  if (expectedOs && sessionOs && expectedOs !== sessionOs) return false;
  return true;
}
function sessionProvesCommunication(session = {}, { projectId = '', p01 = {} } = {}) {
  if (!session || (projectId && session.projectId !== projectId)) return false;
  const operation = clean(session.operation, 40);
  if (!['readProperties', 'read', 'testWrite'].includes(operation)) return false;
  if (!['complete', 'complete-unverified'].includes(clean(session.state, 60))) return false;
  if (!normalizePort(session.device)) return false;
  if (operation === 'readProperties') {
    const identity = session.identity || session.result?.identity || {};
    if (clean(identity.controller, 40).toUpperCase() !== 'P01') return false;
    if (!clean(identity.os || identity.osid, 40)) return false;
  }
  if (operation === 'read' && session.outputValidation && session.outputValidation.valid === false) return false;
  if (!identityMatchesProject(session, p01)) return false;
  return true;
}
function proofFromSession(session = {}, source = 'flash-history') {
  const identity = session.identity || session.result?.identity || {};
  return {
    port: normalizePort(session.device),
    projectId: clean(session.projectId, 160),
    operation: clean(session.operation, 40),
    sessionId: clean(session.id, 180),
    provenAt: clean(session.completedAt || session.finishedAt || session.startedAt || new Date().toISOString(), 80),
    controller: clean(identity.controller, 40).toUpperCase() || 'P01',
    os: clean(identity.os || identity.osid, 40),
    hardwareId: clean(identity.hardwareId, 80),
    serviceNumber: clean(identity.serviceNumber, 80),
    source
  };
}
function findLatestProvenPort({ history = [], projectId = '', p01 = {}, state = {} } = {}) {
  const currentPort = normalizePort(state?.provenHardwareSession?.port || state?.pcmHammerProvenPort);
  if (currentPort && (!state?.provenHardwareSession?.projectId || state.provenHardwareSession.projectId === projectId)) {
    const proof = {
      ...(state.provenHardwareSession || {}),
      port: currentPort,
      projectId,
      provenAt: state.provenHardwareSession?.provenAt || state.pcmHammerProvenAt || null,
      source: state.provenHardwareSession?.source || 'guided-state'
    };
    if (!proof.os || !p01.identity?.os || String(proof.os) === String(p01.identity.os)) return proof;
  }
  const candidate = (Array.isArray(history) ? history : []).find(session => sessionProvesCommunication(session, { projectId, p01 }));
  return candidate ? proofFromSession(candidate) : null;
}
function shouldReuseProof(operation = '', proof = null) {
  return Boolean(proof?.port && ['read', 'testWrite'].includes(clean(operation, 40)));
}
module.exports = { normalizePort, sessionProvesCommunication, proofFromSession, findLatestProvenPort, shouldReuseProof };
