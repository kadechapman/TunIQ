# P01 Proven-Port Continuity

TunIQ v1.9.0-beta.14 treats a successful PCM Hammer hardware operation as project-bound evidence.

When Read Properties successfully identifies a P01, OS, hardware ID, and service number, TunIQ records the exact PCM Hammer COM port and session. The first full read, second full read, and Test Write inherit that exact port. They do not restart adapter discovery or scan generic alternates such as COM1.

The proof is recovered after an app restart from the active project's PCM Hammer session history. A proof from another project or a failed/partial read is rejected.

The direct continuity path remains restricted to Read, Read Properties, and Test Write. Calibration Write, Full Write, and Recovery continue to require the verified connection broker and all existing safety gates.
