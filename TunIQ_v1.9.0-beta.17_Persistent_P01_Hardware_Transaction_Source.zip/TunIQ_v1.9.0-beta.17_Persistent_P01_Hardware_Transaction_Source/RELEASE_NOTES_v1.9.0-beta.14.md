# TunIQ v1.9.0-beta.14 — Proven-Port Continuity & Readiness Center

## Main fix

The first full read no longer throws away a successful Read Properties connection and restart COM discovery.

- A successful Read Properties session records a project-bound hardware proof.
- Both protected full reads and Test Write inherit the exact PCM Hammer-proven port.
- Generic COM1 and unrelated alternate ports are not scanned after proof exists.
- The TunIQ virtual adapter is disconnected before every physical P01 operation.
- Proven-port evidence is recovered from the active project's successful PCM Hammer history after restart.
- Failed, partial, other-project, or OS-mismatched sessions cannot become proof.

## Readiness center

The Public Beta Center now shows evidence-weighted progress percentages, supporting evidence, blockers, and next priorities for every major TunIQ area.

## Safety boundary

No actual PCM write was performed or enabled by this update. Direct proven-port reuse remains limited to Read Properties, full reads, and Test Write. Real writes retain the verified broker, validation, snapshot, voltage, checksum, and typed-confirmation gates.
