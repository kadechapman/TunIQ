# P01 Full-Read Progress & Watchdog

TunIQ v1.9.0-beta.13 fixes a Guided P01 state where Read Properties completed and full read 1 began, but the P01 screen remained at its starting percentage with no explanation.

## Live monitoring

During a full read TunIQ now reports:

- PCM Hammer process-alive state
- elapsed time
- seconds since the last PCM Hammer/file update
- current read-file size versus the required 524,288 bytes
- mapped progress in the Guided P01 progress bar
- whether the expected file size has been reached while completion proof is still pending

The Flash Center and Guided P01 screen are driven by the same live PCM Hammer session.

## Stall boundary

A quiet read is not treated as failed. TunIQ continues showing a heartbeat even when PCM Hammer does not print a new line. The non-destructive read is stopped only after the process remains alive with no PCM Hammer output and no read-file activity for the full watchdog window (15 minutes by default).

Any incomplete output is renamed as rejected evidence and cannot satisfy either required 524,288-byte read. Completed Read Properties and any previously verified evidence remain preserved. Real writes are unaffected by this read watchdog.
