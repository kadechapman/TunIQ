# TunIQ v1.9.0-beta.17 — Persistent P01 Hardware Transaction

## Rebuilt connection handoff

- Read Properties, Full Read 1, Full Read 2, and Test Write now share one project-bound hardware transaction.
- A proven COM port remains authoritative for the exact P01 project and OS.
- Windows receives a four-second RFCOMM cooldown between PCM Hammer processes.
- A pre-communication open failure receives one controlled same-port reopen after a five-second settle.
- No COM1, COM3, or alternate-port scan is allowed inside the proven transaction.
- A repeated failure stops with `proven-port-reopen-failed` while retaining controller identity, OS, reads, and commissioning evidence.
- Hardware Session Doctor now gives recovery instructions specific to this failure.

## Retained behavior

- Startup resume-state reconciliation
- Live full-read progress and watchdog
- AI incident replay and learning memory
- Read-only direct handoff protections
- Dual 524,288-byte matching-read requirement
- Test Write and actual-write safety gates

## Hardware truth boundary

This release was verified through source tests, mock PCM Hammer processes, filesystem persistence, clean-archive extraction, and retained recovery simulations. Physical Full Read 1 and Test Write are not claimed until confirmed on the real bench setup.
