# TunIQ 1.9.0-beta.96 — Reconciled Cancelled Read Evidence Guard

**October 17, 2026. Source-only checkpoint, not a Windows installer or public release.**

Starting from the latest verified beta.95 Serial-Open Retry Guard Library source (rather than the older beta.94 baseline), this checkpoint retains the positive serial-open evidence check that blocks unsafe CLI fallback after the port was opened.

A separate defect reproduced against beta.94: cancelling a Full Read before child close still invoked the backup import callback when the child raced to exit 0 with a complete-size BIN and success text. Beta.96 now marks cancelled read-only results unsuccessful, skips both backup and identity import callbacks, and preserves the output as rejected evidence. A cancelled Read Properties result cannot promote OSID evidence. Tests use synthetic child events and local files; no physical COM/ECU access occurred.

Public launch remains blocked by the missing dependency lockfile, unverified Windows install and CLI/kernel behavior, no physical read-only qualification, unresolved license/update/signing/privacy/redistribution/incident response, and exact-OS/checksum/AI review requirements. No ECU writes or public release.
