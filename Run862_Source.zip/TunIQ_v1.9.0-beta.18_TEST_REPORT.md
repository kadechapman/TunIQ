# TunIQ v1.9.0-beta.18 Test Report

Release: **PCM Hammer Exclusive OBDLink Device Lease**  
Base: **v1.9.0-beta.17 Persistent P01 Hardware Transaction**  
Verification: source syntax, PCM Hammer CLI mocks, exclusive-port ownership assertions, typed-device selection, project persistence, complete automated suite, retained recovery chain, and clean archive extraction.

## Repeated physical failure modeled

The reported sequence was reproduced as:

1. Read Properties proves P01 OS 9373372 through OBDLink MX+ on COM4.
2. Full Read 1 begins from the same project.
3. The operation fails before PCM communication with `adapter-open-failed`.

Beta.18 removes TunIQ from the COM4 open/release path after proof and gives PCM Hammer the known OBDLink device family directly.

## New focused verification — 4/4 passed

- Authoritative OBDLink proof builds the typed device specification `COM4:elm`.
- A non-authoritative port remains plain COM4.
- Explicit typed-device rejection is detected for same-port fallback.
- A complete simulated protected read proves zero TunIQ port-release calls, PCM Hammer-exclusive ownership, physical COM4 state, and `COM4:elm` launch arguments.

## Complete verification

- Source syntax checks: **passed**
- Focused exclusive-device lease: **4/4 passed**
- Full automated suite: **51/51 groups passed**
- Complete retained recovery chain: **passed**
- Clean extracted archive: **passed**
- Source manifest: **297/297 verified**

## Development progress

| Area | Progress | Remaining priority |
|---|---:|---|
| Overall TunIQ beta | **54%** | Confirm repeatable physical reads and Test Write, then begin outside tester validation |
| P01 commissioning | **36%** | Complete two matching physical 512 KB reads, exact definition binding, and physical Test Write |
| Hardware bridge and PCM Hammer | **78%** | Confirm the PCM Hammer-exclusive COM4 lease on the real Windows Bluetooth stack |
| Calibration, definitions and revisions | **35%** | Add trustworthy writable exact-OS definitions and verify real VATS/fan changes |
| AI learning and safe self-repair | **64%** | Add reviewed forum ingestion, resolution feedback, and more approved repair actions |
| Garage, projects and evidence | **73%** | Finish migration/usability testing and evidence views across more controller projects |
| Public beta readiness | **64%** | Installer signing, documentation, multi-PC testing, and outside tester feedback |

Percentages are conservative evidence-weighted estimates. Physical proof is weighted more heavily than simulation coverage.

## Safety boundary

No physical Full Read 1, Test Write, or actual PCM write was performed or claimed in the build environment. Existing BIN validation, exact-XDF, checksum, dual-read, Test Write, recovery, and final-write confirmation gates remain unchanged.
