# TunIQ 1.9.0-beta.74 — Read Digest Binding Guard

Source-only development checkpoint, **not a Windows installer or public release**.

- P01 commissioning rejects a BIN whose current SHA-256 differs from the earlier Full Read validation proof, even if both files have the expected 512 KiB length.
- Rejects inconsistent claimed size and malformed SHA-256 evidence.
- Adds four filesystem-only regression checks, including a baseline failure reproduction.
- Preserves read-only restrictions. No ECU Test Write, write, flash, or physical hardware test performed.
- The existing nine public-release blockers and Windows/OBDLink/PCM Hammer hardware qualification remain outstanding.
