# Run58 — Contained deletion of imported P01 evidence

Source-only reliability change. No physical ECU, adapter, Test Write, flash, or calibration changes.

## Reproduced defect

`P01EvidenceManager.deleteImport()` selected its recursive deletion target from the `normalizedPath` field in the persisted `P01Evidence/imported.json` index. That field is metadata and can be malformed or edited. A temporary-directory regression set `normalizedPath` to a file outside `P01Evidence/Imported`; the original implementation removed the external directory and silently removed the index entry. The regression failed before this correction.

## Correction

- Derive the deletion target **only** from the imported item's single-segment `id` under `P01Evidence/Imported`.
- Reject traversal/separator/control-character IDs, non-directory import entries, and symlink/junction directory redirects.
- Verify each ancestor of the imported folder is a direct directory rather than a symlink.
- If the owned folder is already missing, permit removal of its stale index entry.
- Do not discard the index entry when filesystem removal fails.
- Never interpret `normalizedPath` as authority to delete files.

## Limits

These filesystem guards are not an atomic sandbox against a hostile concurrent local process that can rename directory entries between checks and deletion. Do not treat them as authorization to delete arbitrary paths. This change does not certify the Windows installer, dependency lockfile, hardware, or ECU operations.

## Regression

`npm run test:p01-evidence-delete` exercises forged external paths, traversal IDs, missing owned folders, failed deletion, and redirected import directories using only temporary local files. The same checks run inside the existing 76-group suite's P01 evidence integration group.
