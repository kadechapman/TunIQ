# Root JSON launch-snapshot freshness — bounded offline development pass

**Scope:** Source-only launch snapshot integrity; no ECU communication, Test Write, flash, or physical hardware validation.

## Defect and reproduction

`tools/launch-snapshot.js` fingerprinted selected JSON inputs (`package.json`, `VERSION.json`, npm lockfiles) but not other root JSON files. A newly added or edited `RELEASE_ATTESTATION.template.json` or root release-policy JSON could leave `LAUNCH_READINESS_CURRENT.json` reporting a valid source fingerprint despite a changed release artifact. The new regression assertion failed against the unmodified Run31 source; the fix was then reconciled onto the newer Run32 ancestor-ledger guard: adding an attestation template left `verifySnapshot(root).valid === true`.

## Correction

The critical-source fingerprint now includes root-level `*.json` files except `package.json` and `VERSION.json` (already included), and generated `SOURCE_MANIFEST.json` and `LAUNCH_READINESS_CURRENT.json` (excluded to prevent self-reference). This covers release-attestation templates and future root JSON policy/configuration files without inventing hardware evidence. Tests assert addition, modification, and a new root JSON policy invalidate a prior snapshot; generated source-manifest changes do not.

## Limitations

A fresh source-only snapshot **does not** prove that a policy is correct, that release attestations are genuine, that dependencies install, or that physical OBDLink/PCM Hammer communication is safe. No physical reads or writes were performed. The Windows clean-install, dependency lockfile, exact-OS calibration, code signing, secure updates, licensing, privacy, recovery, and hardware evidence gates remain unresolved. Do not promote this source checkpoint to a public beta on snapshot freshness alone.
