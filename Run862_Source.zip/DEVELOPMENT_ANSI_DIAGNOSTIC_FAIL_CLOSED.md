# Run38 — ANSI-colored PCM Hammer diagnostics: fail-closed read evidence

**Scope:** Offline, source-only safety fix for PCM Hammer read/read-properties result classification and read-only CLI profile/typed-device retry admission. No ECU communication, physical Test Write, write, or flash.

## Reproduced against Run37

A nominal CLI exit 0 plus `Read completed successfully` could override colored diagnostics such as `CRC \x1b[31merrors: 2\x1b[0m`, `Kernel upload: \x1b[31mfalse\x1b[0m`, and `Checksum \x1b[31mverification failed\x1b[0m`. These messages were missed by the safety regexes because ANSI SGR escape codes split safety-relevant tokens. A later parser `Unknown option` footer could also authorize a second CLI profile or a typed COM-to-plain-COM fallback despite the colored error. Colored `Opened serial port COM4` could likewise be missed by typed-device fallback.

## Correction

- Strip **only** well-formed ANSI SGR (`ESC [ digits/semicolons m`) formatting before interpreting safety diagnostics. Do not broadly discard arbitrary terminal escape sequences.
- Treat unrecognized ESC or C1 CSI/OSC controls as **unverifiable CLI evidence**: read/read-properties success is rejected and automatic read-only CLI profile/typed-device retries are denied.
- Apply normalization consistently to result classification, runtime-error detection, COM-open/activity detection, syntax-only admission, and typed-device fallback.
- Preserve clean zero-error and positive kernel statuses, including those wrapped in normal ANSI color formatting.

## Boundaries and limitations

Synthetic diagnostics prove software decisions only; they do **not** verify actual PCM Hammer log dialects, Windows CLI/kernel compatibility, physical COM-port exclusivity, or safe recovery after a real interrupted Full Read. This change does not implement atomic interprocess COM locking or qualify calibration/checksum/write behavior. Unknown terminal control codes deliberately block read-only automation until reviewed. No write or Test Write was initiated.
