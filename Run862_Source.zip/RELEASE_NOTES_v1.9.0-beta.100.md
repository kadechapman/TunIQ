# TunIQ v1.9.0-beta.100 — Read-Only Result Evidence Consistency

Source-only development checkpoint; **not** a verified Windows installer, user-testing build, or public release.

## Fixed

After PCM Hammer reported CLI exit 0, TunIQ could correctly mark a Full Read as failed (partial BIN or failed project backup import) while retaining `session.result.success: true`. Failed Read Properties identity-import callbacks could also leave contradictory successful CLI metadata. This inconsistency could mislead consumers that inspect the result object rather than the final session state.

`src/flash.js` now forces `result.success: false` and synchronizes `result.stopCode` with the final session stop code whenever a read-only operation ends without an admitted `complete` state. The guard runs after validation/import/cancellation/identity admission and before profile promotion or session-completion callbacks. The CLI exit code remains separately recorded for diagnostics.

Offline synthetic regressions cover partial Full Reads, backup-import failure, failed Read Properties and failed identity import, while successful read-only operations still retain successful evidence. No ECU write path was changed.

## Boundaries

- No real COM/OBDLink/PCM hardware tests or writes were performed.
- The guard does not undo partial side effects of a project import callback; transactional imports remain a separate requirement.
- No dependency lockfile is present. Clean Windows installation, signed build, real Full Read recovery, exact-OS definitions, update security, license, privacy, redistribution and incident response remain unverified.
- No public release is authorized by this checkpoint.
