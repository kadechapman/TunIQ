# TunIQ v1.9.0-beta.54 — Source-only Development Checkpoint

This merges the **verified beta.53 Windows Full Read output path alias guard** with a separate per-attempt CLI executable integrity fix developed against verified beta.52. The beta.53 read-output safety source and tests are retained unchanged.

In restricted read-only mode, a previously pinned PCM Hammer CLI is rehashed immediately before each command-profile launch, including syntax-only retries and same-port recovery, and before each CLI capture subprocess. An executable changed after the first attempt now stops with `cli-executable-integrity-changed` and cannot silently become a new pinned executable during probe(). Two synthetic POSIX executable-swap regressions exercise these boundaries; Windows fixture execution is skipped.

**No physical hardware testing, Test Write, PCM write, or flash occurred.** This source archive is not a runnable Windows installer or a public release. CLI publisher/kernel provenance, exact-OS calibration safety, dependency lockfile, Windows installation, signing, licensing, secure updates, privacy and hardware evidence remain blocked.
