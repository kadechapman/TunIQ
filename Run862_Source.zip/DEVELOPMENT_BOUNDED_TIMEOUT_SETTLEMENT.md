# Bounded test-suite timeout settlement (source-only)

This checkpoint addresses a false assurance and liveness problem in the **offline automated-test verifier**, not ECU communication. The newest verified Run29 source was used; its COM ownership protections and release restrictions remain unchanged.

## Reproduced failure

`tools/verify-test-suite.js` killed the direct test process when its deadline expired but waited for Node's `close` event before settling its Promise. If a descendant inherited the test process's stdout/stderr pipe descriptors, `close` could be delayed after the direct child had been killed. An offline reproduction against unchanged Run29 waited about 1,356 ms despite a 150 ms deadline. No adapter, COM port, or PCM was involved.

## Change

The verifier now resolves a **failure** immediately when the deadline fires, attempts to kill the direct child, and closes its own stdout/stderr pipe handles. A late `close` event cannot replace the timeout result. `tests/verify-test-suite-simulations.js` adds an inherited-pipe regression that requires a 150 ms timeout to settle within 1,000 ms, while still rejecting a success banner printed by the killed suite.

This bounds **verifier reporting**, not every descendant process. Windows process-tree termination, clean Windows installation, physical PCM Hammer/OBDLink compatibility, and any physical Full Read recovery remain unverified. Do not use this source-only checkpoint for physical Test Write, PCM write, or flash.

## Safety and release status

No production PCM Hammer, COM-port, checksum, calibration, backup, AI tuning, or write-path files were modified. The app remains 1.9.0-beta.108 and **NOT READY FOR USER TESTING** or **PUBLIC RELEASE**. A missing dependency lockfile prevents reproducible clean Windows installation. A limited supervised read-only beta is the next appropriate target once independent hardware evidence and Windows build evidence exist.
