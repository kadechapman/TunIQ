# TunIQ beta.108 — zero-padded read-integrity counter guard (Run34)

**Scope:** Offline software safety fix only. No physical PCM Hammer launch, serial connection, Test Write, ECU write, or flash. Not a Windows or hardware qualification.

## Reproduced defect

PCM Hammer CLI result classification previously recognized `CRC errors: 2` but not `CRC errors: 02`, `Checksum failures: 0002`, or `0004 CRC errors`. With a later `Read completed successfully` line and a zero exit status, `classifyPcmHammerResult('read', ...)` returned `success: true`, permitting untrusted Full Read completion evidence. The same counter format could also be ignored by read-only CLI syntax-retry and typed OBDLink fallback guards.

## Fix

`src/pcmhammer-integrated.js` treats **zero-padded nonzero** CRC/checksum/hash error, failure, or mismatch counts as read-integrity failures. All-zero counts such as `CRC errors: 000` remain nonfatal. The shared parser feeds Full Read/Read Properties completion classification and both automatic retry admission guards. Regression fixtures cover both fail-closed decisions and clean zero-count controls. This is text classification, not proof of physical read integrity, cross-process COM ownership, or reliable Windows CLI/kernel compatibility.

## Release limitations

Still missing: genuine npm lockfile and clean Windows install, native PCM Hammer/OBDLink verification, exclusive physical COM ownership, two independent matching physical Full Reads, interrupted-read recovery, exact-OS calibration/checksum qualification, protected backups, explicit human review of any AI tuning, licensing, secure updates, signing, privacy, redistribution permissions, and recovery documentation. Remain read-only and source-only. Do not publish an installer or public beta from this checkpoint.
