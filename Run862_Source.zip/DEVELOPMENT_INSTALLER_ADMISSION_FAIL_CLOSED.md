# Run44 — fail-closed Windows installer admission

The Run43 source-only checkpoint exposes `npm run dist:win`, `npm run dist:win:unsigned`, `npm run pack:win`, and `BUILD_WINDOWS_INSTALLER.bat` as build paths without production release admission. The batch script additionally ran unpinned `npm install`. An unsigned ECU-capable installer could be produced without a reviewed release gate.

This development checkpoint places a fail-closed Node admission check ahead of every npm packaging script and disables installer generation in the convenience batch file. The gate verifies the source-only launch snapshot and always rejects source-only provenance. An edited snapshot claiming `fullLaunchReady` cannot override the source audit. A separately reviewed, signed, evidence-backed release workflow must replace this temporary barrier; no environment variable bypass is supported.

The source-only GitHub Actions workflow remains available for syntax and simulation tests when a genuine reviewed dependency lockfile is present. The release gate is a convenience-script safety guard, **not** a security sandbox against a developer invoking electron-builder directly or changing the source. No installer, physical ECU communication, ECU write, or flash was attempted.

Verification: `npm run test:installer-admission`, `npm run check`, and `npm test` on Linux, plus static inspection of Windows batch syntax. Native Windows batch execution and clean Windows dependency installation remain unverified. Release and user-testing readiness are blocked.
