# Run61 — Bounded, identity-checked phone-log snapshot

Date: 2026-10-19. Source version: 1.9.0-beta.108. Scope: read-only local log imports. No physical ECU, serial/COM, Test Write, or flash operations.

## Reproduced defect

In Run60, `normalizeFile()` used an unrestricted `fs.readFileSync(sourceFile, 'utf8')` before applying the parser's 16 MiB text cap. It also followed symlinks. `importPhoneLog()` separately reopened the source for SHA-256 *after* writing normalized output, so a source changed after parsing could produce metadata identifying bytes other than those parsed. The new regression initially failed on the accepted symlink (before the fix).

## Changes

- `src/log-import.js`: inspect the input with `lstat`, reject non-regular, symbolic-linked and hardlinked files, and reject files above 16 MiB *before* allocating or reading. Open once read-only (using `O_NOFOLLOW` when supported); verify file identity and size before and after the bounded read, detect extra bytes and premature EOF, and close the descriptor in `finally`.
- Bind `importPhoneLog()`'s SHA-256 provenance to the exact buffer used for normalization. No second read of the source path occurs.
- `tests/phone-log-file-snapshot-simulations.js`: 14 local-only checks cover accepted logs and VIN removal, oversized sparse files, symlink rejection, growth, truncation, replacement, and post-parse source mutation with unchanged import digest. The new checks run in the existing evidence test group, retaining 76 expected groups.
- `package.json`: `npm run test:phone-log-snapshot`.

## Limitations and safety

A 16 MiB source may still consume more memory during JSON/CSV normalization. This is not a streaming parser, and a process with write access to an open file could theoretically alter bytes and restore metadata before post-read checks; this snapshot is not a cryptographic guarantee against a malicious same-host writer. Parent-directory alias policy and atomic output creation are separate review topics. The pre-existing CSV multiline-quoted-cell limitation remains.

This is source-only/offline verification. It does not establish a runnable Windows application, installer, physical read-only qualification, or release readiness.
