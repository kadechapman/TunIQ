# Optional real Chromium smoke of the inert browser demo

This is **not** a full TunIQ or Electron runtime test and does not validate the
Windows executable. It verifies the single-file, hardware-disconnected browser
preview in an actual Chromium DOM, without npm or an ECM. Python Playwright and
Chromium are optional **test-only** tools; they are not TunIQ dependencies.

From a clean source checkout, generate the standalone HTML **outside** the
checkout and run:

```sh
node tools/build-standalone-browser-preview.js /tmp/tuniq-preview.html
TUNIQ_CHROMIUM_PATH=/usr/bin/chromium python3 tools/browser-preview-chromium-smoke.py \
  /tmp/tuniq-preview.html --evidence /tmp/tuniq-preview-chromium.json
```

The test checks all nine primary sidebar routes, the visible no-ECU warning on
every route, a strict read-only browser bridge, blocked synthetic button clicks
and form submissions, and JavaScript runtime errors. It also verifies actual Chromium CSP
behavior using a separate, isolated page: an injected inline script must not
execute and a synthetic fetch to an invalid example domain must be rejected
before any network request. All browser routes are intercepted and aborted,
including if the CSP were accidentally weakened. The negative fixture replaces
the script policy with `unsafe-inline` and must be rejected by the smoke.
It deliberately injects
the HTML with Playwright `page.set_content()` to support locked-down environments
that deny `file://` navigation. That is a **real browser DOM execution test**,
not an end-to-end launch test. It makes no claim about the Windows PE loader,
Electron, package installation, physical PCM, checksum validation, VATS, fans,
cam calibration, or knock sensors. The evidence JSON records these exclusions.

Never connect a vehicle or treat the browser demo as a tuning application.
