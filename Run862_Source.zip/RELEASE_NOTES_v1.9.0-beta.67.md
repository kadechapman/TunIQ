# TunIQ v1.9.0-beta.67 — OBD IPC Serial Admission Guard

**Source-only development checkpoint; NOT READY FOR USER TESTING or PUBLIC RELEASE.**

The `device:connect`, `device:doctor-run`, `device:sample`, and `logger:start` Electron handlers now acquire the existing PCM Hammer external-port admission latch with `requestRecovery: false`. A live or terminating PCM Hammer process blocks those calls without cancellation, while a pending OBD IPC call blocks a new PCM Hammer start. Admission is released after completion or error.

Tests are synthetic Linux Node.js simulations only. No physical ECU Test Write, write, flash, or read was attempted. Hardware verification, Windows CLI/kernel compatibility, lockfile, licensing, signing, update security, privacy review and clean Windows installation remain blocked.
