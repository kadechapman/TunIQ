# TunIQ Full Launch Readiness Gate

TunIQ now separates **feature progress** from **full-launch permission**. A high feature percentage does not mean a build is ready for unrestricted public release.

The in-app Release Center audits launch blockers including:
- synchronized version metadata;
- reproducible dependency locking;
- final software license;
- secure HTTPS update feed;
- at least one real flashing combination marked **Verified**, with private controller-specific integrity-checked read/Test Write/recovery evidence;
- Windows installer signing attestation;
- reviewed privacy documentation;
- reviewed third-party redistribution terms;
- incident/rollback procedure;
- clean Windows installation verification;
- Windows release workflow and support documentation.

`RELEASE_ATTESTATION.template.json` is intentionally all false. Copy it to `RELEASE_ATTESTATION.json` only after those items have actually been reviewed. Simulations are not acceptable evidence for physical hardware, signing, recovery, or clean-install claims.

Beta builds may continue while the full-launch gate is blocked. A stable/full launch should not.

Hardware evidence requirements: see `HARDWARE_EVIDENCE_REQUIREMENTS.md`. A matrix status alone never clears hardware verification. Private BIN files and logs must never be shipped.

## Beta.22 source snapshot integrity

`npm run release:snapshot` regenerates `LAUNCH_READINESS_CURRENT.json` as a conservative source-only audit.
`npm run check` rejects a stale, tampered, or mis-versioned snapshot, including nested version proof.
This report is not a live hardware verification or public-release approval; the application recomputes its live gate from runtime evidence.

## beta.23 exact hardware qualification
A Verified flashing matrix entry must include `verifiedCombinations: [{controller, os, interface}]`. Controller-only Verified status does not qualify an OS or adapter. The private evidence record must match all three values. Evidence hashes and human signoff remain necessary; these checks do not prove a physical test occurred.

## beta.25 P01 proven-session continuity
A Full Read without an OSID may retain the identity from a prior successful Read Properties session only if the project and COM port match, the read output passed validation, and any reported identifiers do not conflict. Missing identity provenance and unverified Test Write claims are not promoted to proven-port status. These are internal evidence-consistency checks, not physical ECU certification.

## beta.27 restart provenance validation
Persisted guided P01 state is not trusted as an independent hardware-communication claim. Recovery derives proven-port identity from the newest successful recorded PCM Hammer session and its earlier matching Read Properties lineage. A saved session can be recognized only when its session ID and identity-source ID match that history. Unknown active OS IDs block authoritative COM-port reuse. This is a software fail-closed safeguard, not proof that the historical log describes a physical test.

## beta.28 stale COM authority revocation
When latest session history is absent or contains a completed conflicting P01 identity, guided-state COM proof is cleared (session object, proven port, timestamp, and operation). This check is repeated before each guided hardware payload, not only at application startup. It preserves the selected COM port for a new Read Properties attempt. The guard does not authenticate physical ECU identity or qualify a real PCM write.

## beta.29 failed identity recheck revocation
A newer finalized failed, cancelled, interrupted, or unverified P01 Read Properties attempt invalidates older COM-port authority for the same project. This is intentionally fail-closed because a different ECU can appear on the same COM port. Failed Full Reads retain previous Read Properties evidence for safe read-only diagnosis. Only a later successful matching Read Properties may re-establish COM authority. Software simulation only; physical hardware qualification remains blocked.


**beta.30:** In-flight or failed identity rechecks revoke stale COM proof, and Full Read cannot inherit identity across an unsuccessful recheck. Automatic tagged installer publishing is disabled until release attestations and hardware qualification are complete.

### Beta.31 source snapshot integrity

The source-only launch snapshot now contains a deterministic SHA-256 fingerprint of application source, web code, tooling, regression tests, release workflows, and version metadata. `npm run check` fails when those files change without a regenerated snapshot. This is a stale-source detection mechanism, **not** proof of hardware qualification or safe ECU flashing. Physical write paths remain unqualified.

### Beta.32 Full Read output preservation

Integrated Full Read refuses any existing destination, including an original BIN, a partial/interrupted BIN, and a dangling symlink. Checks occur before COM handoff and after asynchronous Bluetooth settle, before PCM Hammer is launched. Existing backups are never silently overwritten or renamed by this guard. This is software simulation only; real Windows hardware and TOCTOU race hardening are outstanding.
