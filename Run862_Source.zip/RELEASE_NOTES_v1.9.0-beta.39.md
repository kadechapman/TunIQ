# TunIQ v1.9.0-beta.39 — Combined Hardware Evidence Gate Guards

**Source-only safety checkpoint; not a Windows-qualified installer or public release.**

Two independent beta.38 Library archives were created from beta.37, each with a different safety improvement. This checkpoint starts from the later All Verified Scopes archive and incorporates the Private Evidence Manifest Integrity Guard without discarding either regression suite.

- Every Verified controller/OS/interface combination must have matching integrity-checked private evidence; one evidenced scope cannot authorize another.
- The private hardware-verification JSON manifest must be a nonempty, single-link regular file at most 1 MiB, with its opened file identity and metadata stable during parsing. Symbolic links and hard links are rejected.
- Synthetic records and self-asserted reviewer flags **cannot prove physical testing**. A successful integrity check is not hardware certification.
- No physical PCM tests or writes were attempted in this source-only development pass.
- All public flashing release blockers remain subject to Windows/OBDLink bench evidence and independent review.
