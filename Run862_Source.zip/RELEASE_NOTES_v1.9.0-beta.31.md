# TunIQ v1.9.0-beta.31 — Critical Source Snapshot Binding

Source-only development checkpoint, **not a public flashing release**.

- Fixed stale launch snapshots that previously passed after source/CI/test changes which did not alter the nine blocker flags.
- Deterministic SHA-256 digest covers `src/`, `web/`, `tools/`, `tests/`, `.github/workflows/`, `package.json` and `VERSION.json`; excludes generated evidence and snapshot itself.
- Added regression tests for changed flash source, CI release workflow and safety test files.
- Hardware qualification unchanged; no PCM Hammer binaries, COM handling, calibration tables, checksum algorithms, or PCM writes changed.
