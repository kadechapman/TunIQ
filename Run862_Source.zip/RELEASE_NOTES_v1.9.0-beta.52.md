# TunIQ v1.9.0-beta.52 — Complete CLI Pin Metadata Guard

**Source-only checkpoint, not a public release.**

- A stored PCM Hammer CLI SHA-256 digest without a valid saved original executable path now blocks read-only preflight and discovery. A non-string digest is also rejected.
- Preserves beta.51 hash-drift, re-probe and post-COM-handoff protections.
- No Windows build, hardware qualification, publisher signature, physical PCM Test Write, write or flash.
