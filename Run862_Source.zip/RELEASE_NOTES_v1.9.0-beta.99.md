# TunIQ 1.9.0-beta.99 — Failed Read Identity Admission Guard

Source-only development checkpoint; not a public or user-testable Windows build.

## Safety correction
- Fail closed on OSID/hardware identity promotion when PCM Hammer Read Properties fails or exits nonzero, even if a plausible OSID appears in the log.
- A Full Read that fails BIN validation or backup import cannot call `onIdentifyComplete` based on incidental CLI text.
- A successfully completed Read Properties command can still promote identity.
- No ECU writing functionality changed. No hardware or Windows verification was performed.

## Remaining launch blockers
Dependency lockfile, license, secure update feed, code signing, privacy/redistribution review, incident/rollback readiness, clean Windows install, and supervised physical read-only OBDLink/PCM Hammer COM-port and Full Read recovery qualification. Exact-OS definitions/checksum binding and AI tuning restrictions require independent review.
