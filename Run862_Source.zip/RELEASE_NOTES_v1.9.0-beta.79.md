# TunIQ v1.9.0-beta.79 — Read Recovery Alias Guard

**Source-only development checkpoint. Not a Windows installer or public release.**

## Change

- `src/p01-commissioning.js`: a damaged `readPair` pointer can no longer be reconstructed from two saved session records whose BIN paths are hard links, symlinks, aliases, or files whose identity cannot be inspected. Recovery now requires two separately addressable regular files with single-link metadata, distinct resolved paths and independent saved sessions, in addition to the existing SHA-256 and identity checks.
- `tests/p01-read-recovery-alias-simulations.js`: offline regression for hardlink replacement, symlink replacement (when host permits symlink creation), missing saved read and valid independent recovery.
- Updated regression-suite wiring and release-promotion source guard.

## Evidence and limits

The new test reproduces an unsafe alias promotion in beta.78 and passes against beta.79. All testing uses synthetic files and simulated workflows. Two saved session IDs **cannot establish two actual ECU reads**; physical read-only qualification is still required. Windows filesystem and PCM Hammer/OBDLink compatibility have not been tested. No physical PCM Test Write, write, or flash was performed.

Public launch remains blocked by missing dependency lockfile, licensing, secure updates, Windows signing/installation, privacy and redistribution review, incident response, and physical hardware evidence. Do not release or enable ECU writing on this evidence.
