# TunIQ v1.9.0-beta.53 — Windows Read Output Path Alias Guard

**Source-only development checkpoint. Not an installer, hardware qualification or public release.**

## Safety fix

Full Read output validation now rejects Win32 reserved device names, including `NUL.bin`, `CON.bin`, `COM1.bin` and `LPT9.bin`; NTFS alternate data stream syntax (`read.bin:stream`); and trailing-dot or trailing-space aliases in destination names or parent folders. These names could otherwise evade a conventional `lstat` existence check or refer to a device rather than a new BIN. The check is platform-independent to allow Linux simulation tests and runs before output-directory creation, after async COM ownership inspection and again after COM handoff.

No existing files are deleted or overwritten by this change. This is not an atomic filesystem reservation; external filesystem changes during a read remain a residual risk.

## Evidence and limitations

Regression was reproduced against verified beta.52 source on Linux. The fix and existing synthetic tests are source-level evidence only. Windows clean install, OBDLink MX+ and PCM Hammer CLI/kernel compatibility, physical read recovery, exact-OS calibration coverage, backup/checksum verification and signing remain unverified. No physical PCM Test Write, write or flash was performed.

## Recovery guidance

See `WINDOWS_READ_OUTPUT_PATH_RECOVERY.md`. Do not retry a partial Full Read into an existing filename. Preserve the partial read and choose a fresh ordinary `.bin` filename on a local non-junction directory.
