# Run74 — Electron startup IPC and renderer contract (offline)

**Scope:** Dependency-free, source-only preflight. This is NOT a runnable Electron build, an actual Windows test, or ECU communication. No writes/flashes are authorized.

## Why

The Electron renderer calls IPC methods through `src/preload.js`. Missing `ipcMain.handle()` registrations or renderer calls to nonexistent preload methods can break UI functionality at runtime, but syntax checks do not catch these mismatches. This pass adds a bounded static cross-check before dependency installation.

## What the checker covers

`node tools/electron-startup-contract-preflight.js --require-safe` validates:

- The expected Electron package entrypoint and local preload/index paths.
- The literal `ipcRenderer.invoke('channel')` channels have matching literal `ipcMain.handle('channel')` registrations.
- Duplicate handler and preload method names are rejected; dynamic/unparseable invoke/handle calls are rejected.
- Literal renderer `tuniq.method` references exist in the exposed preload methods.
- The local renderer scripts and stylesheet exist and are not symbolic/hard links.
- Electron isolation flags are present and navigation guard installation precedes renderer loading.

The checker reads only project source files; it never starts Electron, opens COM, or touches calibration files. `--report` returns diagnostics with exit 0 even when blockers exist; `--require-safe` exits 2 on blockers.

## Verified regression fixtures

`node tests/electron-startup-contract-preflight-simulations.js` checks a valid source snapshot and intentional mismatches: unhandled/dynamic/duplicate IPC, missing renderer methods, disabled isolation, unsafe remote or linked renderer resources, missing files, incorrect package entrypoint, and CLI exit behavior.

Windows source-only CI runs the contract and its tests independently of the missing dependency lockfile. The Windows locked-dependency job runs the contract before `npm ci`.

## Limits

This is literal-source pattern checking, **not** a JavaScript parser or runtime IPC attestation. It can miss computed renderer API access, dynamically registered handlers, indirect calls, and bugs in Electron startup itself. The real Windows runtime must be tested after an authentic npm lockfile and reproducible dependency installation are available. No release/readiness status is promoted by this check.
