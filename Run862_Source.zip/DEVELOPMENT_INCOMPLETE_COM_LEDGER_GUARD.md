# TunIQ beta.108 — incomplete PCM Hammer ledger rejection

**Source-only development checkpoint. Not an ECU hardware qualification, runnable Windows installer, or release.**

## Reproduced problem

The prior atomic ledger guard rejected invalid JSON and malformed top-level structure, but accepted valid JSON containing only `{ "version": 1, "state": "preparing", "history": [] }`. `load()` then filled in absent ownership fields from `blank()`, allowing `begin()` to overwrite an unknown prior COM-port owner. This was reproduced against the verified Run23 source without opening any adapter or ECU.

## Change

`src/p01-hardware-transaction.js` now fails closed on incomplete ownership records, unsupported states, invalid preparation counters, and process-running/closed/completed/reopening records lacking proof of a child started in the same preparation. The existing `stopped` state may intentionally clear `currentOperation` during a pre-spawn failure; this case remains supported. A missing file remains valid on first launch. Existing invalid bytes are not rewritten during a denied admission.

`tests/p01-hardware-transaction-simulations.js` adds five incomplete/contradictory ledger cases, verifying denial of `begin()` and `assertCanStartProcess()` and byte-for-byte preservation of the damaged record. No real ECU write, test write, flash, or adapter communication was performed.

## Operator recovery

Stop TunIQ and confirm all PCM Hammer processes have exited. Disconnect the adapter and preserve the ledger and logs for incident analysis. Do not automatically delete or reset a damaged ledger to force COM access. A reviewed, manual recovery process is required.

## Remaining launch gates

The on-disk ledger is not a cross-process lock and does not prove Windows COM ownership. Native clean Windows installation, dependency lockfile, pinned PCM Hammer CLI/kernel, exclusive physical OBDLink ownership, two independent matching Full Reads, interrupted-read recovery, exact-OS calibration and checksum/backups, human approval boundaries for AI tuning, licensing, signed updates, privacy, redistribution permissions, and incident response remain unverified. No public release or unsupervised user testing is authorized by this source-only change.
