# Run126 — Windows lockfile provenance independence

This is a **source-only, hardware-disconnected** verification change. It does not
prove that npm dependencies installed on Windows or that Electron started.

## Reproduced failures in Run125

- The CLI accepted the working `package-lock.json` itself as the supposed
  independent candidate when its bytes matched. This defeated the intended
  separation between the disposable npm working tree and the per-run preserved
  candidate file.
- The CLI accepted additional JSON keys in a provenance report. A forged
  `readyForUserTesting: true` field could coexist with the expected false
  runtime flags and still pass verification.

## Correction

- Candidate and working lockfile must resolve to **different real filesystem
  paths**. Identical SHA-256 digests remain required, but are not sufficient.
- Verification accepts only the eight fields in the defined evidence schema.
  Extra readiness claims and unknown fields fail closed.
- Three new actual Node CLI regression assertions cover these cases. They run
  without Windows, npm downloads, Electron, or ECU hardware.

## Limitations

This does not make the candidate tamper-proof against a privileged local
attacker, certify the npm registry, or establish Windows execution. A genuine
npm-generated lockfile, native Windows installation and Electron launch, and
full ECU-capable app tests remain outstanding. VATS and fan configuration
require exact-OS definitions and wiring checks; the physical LSX Stage 2 cam
requires the user's cam card and logs. Knock protection must not be silently
removed. No ECU read, Test Write, write, or flash was performed.
