# TunIQ v1.9.0-beta.33 — Zero-Byte Read Retry Guard

Source-only safety checkpoint. Not a hardware-qualified release or public installer.

- Integrated Full Read now treats **any existing output path** (including zero-byte partial files, directories, and dangling symlinks) as evidence that the destination cannot safely be reused for command-profile fallback.
- Same-port, alternate-port, typed-device fallback, and controlled proven-port reopen are suppressed after a Full Read output path appears, even when PCM Hammer reports a serial-port open failure.
- Added a mock CLI scenario creating a zero-byte output before reporting an adapter-open failure, with an assertion that only one CLI attempt occurs and the zero-byte file is preserved as rejected evidence.
- No change to write authorization, checksum coverage, calibration definitions, or real PCM communications. The final existence check and process launch are not atomic; a competing process could still create the destination in that window. Windows physical read-only validation remains required.

No physical PCM Test Write or PCM write was attempted. This is not permission to flash.
