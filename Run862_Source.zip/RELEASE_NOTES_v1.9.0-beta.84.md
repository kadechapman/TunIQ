# TunIQ v1.9.0-beta.84 — Reconciled Full Read Proof and Path Guards

Source-only development checkpoint. This is **not** a Windows installer or a hardware-qualified release.

- Preserves beta.83's explicit `result.success === true` requirement before a completed PCM Hammer Full Read can be accepted; missing/nonboolean success evidence fails closed. This does not authenticate arbitrary caller-supplied success flags.
- P01 commissioning now applies the same Win32-safe backup path policy as the Full Read CLI validator, rejecting Windows device aliases, alternate-data-stream syntax, trailing-dot aliases, and unsafe parents before ledger admission or saved-pair recovery.
- Retains beta.82 evidence ancestor checks, read alias safeguards, and restricted assisted-import guard.
- Extends filesystem-only regressions; no COM port or ECU operations.

Remaining blockers: no reviewed dependency lockfile; no clean Windows build/install; no physical OBDLink/PCM Hammer qualification; licensing, signing, updates, privacy, redistribution, incident-response, exact-OS/checksum and AI-tuning release reviews incomplete. No public release.
