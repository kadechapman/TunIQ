# Run57 — bounded PCM Hammer Full Read verification

Scope: `src/pcmhammer.js` / `validateP01ReadFile` (read-only, offline verification).

## Reproduced defect

The verifier inspected an exactly 524,288-byte BIN using `lstat` and `fstat`,
but then used `fs.readFileSync(fd)` to hash it. A file can grow after the
initial size check. `readFileSync(fd)` would allocate memory for all bytes
before the later size/identity check could reject it. The Run56 version was
observed calling `readFileSync` on a numeric file descriptor after a test
fixture grew the file from 512 KiB to 16.5 MiB between `fstat` and reading.

## Correction

Read through the already-verified file descriptor into one fixed 512 KiB
buffer, tolerate short `readSync` returns, then probe one additional byte to
reject growth. Unexpected EOF and any appended data reject the read with
`read-file-changed`. Existing no-follow, parent identity, inode/link count,
mtime/ctime, structured completion-evidence and SHA-256 checks remain in place.

## Offline tests

`tests/read-file-parent-safety-simulations.js` adds deterministic growth,
short-read and mid-read truncation scenarios. The growth scenario asserts
that no unbounded numeric-fd `readFileSync` call occurs. No serial ports,
physical ECUs, PCM Hammer commands, or ECU write operations are used.

## Limits

This does not make a filesystem path an atomic reservation against hostile
concurrent mutation; parent and file identities are rechecked before accepting
read evidence. This does not establish physical ECU read integrity, native
Windows installation, or production release readiness.
