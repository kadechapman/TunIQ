# Run49 — Required Suite Progress Evidence

**Scope:** Offline test-verification reliability; no ECU, COM port, PCM Hammer, flash, or calibration changes.

## Reproduced defect

The Run48 `tools/verify-test-suite.js` accepted a child that emitted 76 invented lines beginning with `✓ `, followed by a matching 76-group success banner and exit code 0. It returned `{ "ok": true, "reason": "passed" }` even though none of the actual TunIQ test milestones had run. This was reproduced using a synthetic Node child; no ECU hardware was used.

## Bounded correction

- Added `tests/suite-progress-required.json` containing the 73 static, named milestones actually emitted through `pass('...')` in `tests/run-tests.js`.
- `tools/verify-test-suite.js` now requires all 73 named milestones, **at least** 76 distinct completed progress lines, a subsequent success banner on stdout, a zero exit status, and no timeout/signal.
- Missing required milestones are diagnosed as `missing-required-groups` rather than a verified pass. The first three missing labels and total count are included in the failure diagnostics.
- Added regressions for 76 fabricated groups, one missing mandatory milestone despite 76 total groups, and consistency between the manifest and the named milestones in the runner. The existing stdout-only, premature-banner, UTF-8 chunking, duplicate, timeout, and exit-code guards remain in place.

## Limitations

The manifest is an explicit *test runner integrity check*, not cryptographic attestation or proof of physical ECU safety. A malicious or compromised test runner could deliberately forge its own named progress lines. Future intentional changes to `pass('...')` labels require updating the manifest and its regression tests. The source-only Windows installer admission gate remains blocked. No runnable Windows build, dependency lockfile, or physical OBDLink qualification is provided by this change.
