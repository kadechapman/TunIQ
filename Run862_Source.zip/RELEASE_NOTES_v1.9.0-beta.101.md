# TunIQ v1.9.0-beta.101 — Conflicting CLI Completion Proof Guard

Source-only development checkpoint; **NOT READY FOR USER TESTING OR PUBLIC RELEASE**.

- `src/pcmhammer.js`: a reported missing kernel or serial-open timeout is now a hard failure even when a CLI also prints a successful read or OSID and exits zero.
- `validateP01ReadFile`: rejects internally contradictory `{ success: true, stopCode: <failure> }` evidence instead of promoting a full-size BIN.
- `tests/pcmhammer-exit-proof-simulations.js`: synthetic tests for both read-only operations, contradictory evidence, and successful controls.
- No ECU write code was changed. No physical adapter or PCM operation was attempted.

Remaining blockers: reviewed npm lockfile, clean Windows build/install, Windows CLI/kernel and exclusive COM ownership, interrupted physical Full Read recovery, two matching physical reads, exact-OS definitions/checksums, licensing, secure updates, privacy, signing, and redistribution/incident-response review.
