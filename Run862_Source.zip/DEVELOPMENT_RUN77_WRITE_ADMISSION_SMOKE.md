# Run77 — Offline production write-admission preflight

This bounded pass strengthens the urgent development smoke gate. It checks the actual
production `FlashManager` construction and the two direct write-capable IPC entrypoints,
and instantiates an in-memory, production-shaped `FlashManager` to confirm that Test Write,
calibration write, full write, and recovery are denied before any hardware call.

Commands (dependency-free):

- `npm run check:dev-readonly-admission`
- `npm run test:dev-readonly-admission`
- `npm run check:dev-readonly-smoke`

The Windows source-only workflow runs all three. Regression fixtures remove or move
guards to demonstrate fail-closed behavior.

## Explicit limitations

- This is an **offline source and in-memory check**, not a real Electron startup.
- Source-pattern validation cannot prove all dynamic execution paths or actual COM behavior.
- `package-lock.json` is still absent. The npm registry was unreachable in this environment
  (`EAI_AGAIN` on October 20, 2026), so no genuine lockfile or Windows installer was created.
- No physical ECU communication, Test Write, ECU write, or flash was performed.
- No release readiness claim is made; a Windows runnable build and runtime smoke checks
  are still required before supervised user testing.
