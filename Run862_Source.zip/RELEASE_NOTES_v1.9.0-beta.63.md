# TunIQ v1.9.0-beta.63 — PCM Hammer Protocol Traffic Retry Guard

**Source-only development checkpoint. Not approved for user testing or public release.**

## Read-only reliability fix

`src/pcmhammer-integrated.js` now treats specific evidence of adapter/ECU traffic (ELM327/STN initialization, diagnostic request/response, hex TX/RX frames and successful kernel load) as communication activity, even if PCM Hammer subsequently prints a generic CLI Usage/Unknown option footer. `looksLikeCliUsageOnly`, `isSyntaxFailure`, and `safeToRetryProfile` agree to stop instead of cycling command profiles after traffic. Pure syntax errors retain bounded read-only fallback.

## Regression evidence

The new protocol-traffic regression failed on the verified beta.62 source before the fix. The corrected local test exercises seven log patterns, both read-only operations, a positive pure-syntax control, and a synthetic mock CLI Full Read with one attempt and no output BIN. This is **not** evidence of native Windows, PCM Hammer kernel, OBDLink MX+, or physical PCM behavior.

## Safety and release blockers

No physical Test Write, ECU write or flash was performed. No dependency lockfile, Windows installer, signed binary, hardware qualification, exact-OS calibration verification, checksum/backup qualification, secure updater, privacy/legal release review or public release is provided. Restricted read-only behavior and prior output-path/COM ownership guards remain. Prefer a limited read-only beta only after Windows and hardware verification.
