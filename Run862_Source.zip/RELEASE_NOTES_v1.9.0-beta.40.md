# TunIQ v1.9.0-beta.40 — Source-only hardware evidence independence guard

**Change:** The full-launch evidence validator now rejects reused Full Read BIN paths, read session IDs, Test Write logs, or recovery logs across distinct Verified controller/OS/interface scopes. The guard prevents a single set of integrity-valid simulated files from qualifying multiple advertised hardware combinations by merely changing an adapter label. Existing per-file SHA-256, linked-file, manifest integrity, and all-scope coverage checks remain.

**Limitations:** No physical Windows/PCM Hammer/OBDLink testing performed; no PCM writes initiated. Self-asserted evidence can still be fabricated; independently reviewed real bench testing remains mandatory. This is not a runnable Windows release.
