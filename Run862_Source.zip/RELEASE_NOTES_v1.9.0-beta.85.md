# TunIQ v1.9.0-beta.85 — Explicit CLI Exit Proof

Source-only development checkpoint, **not** a runnable Windows beta or public release.

## Reproduced safety defect

In beta.84, `classifyPcmHammerResult('read', 'Read entire PCM complete', null)` incorrectly returned `success: true`. Node.js reports a null process exit code when a child exits due to a signal. An absent or coercible string exit code also passed the classifier. A full-size synthetic BIN plus completion text could therefore be promoted despite no proven normal process exit.

## Correction

`src/pcmhammer.js` now requires **strict numeric `exitCode === 0`**. Null, undefined, string `'0'`, NaN, and nonzero codes fail closed, including when completion text exists. Existing explicit boolean Full Read completion, path, SHA-256, independent read, COM ownership, and restricted read-only safeguards remain unchanged.

`tests/pcmhammer-exit-proof-simulations.js` contains 10 offline assertions covering process exit status, Read Properties, and Full Read file admission. It is included in `tests/run-tests.js` and release-promotion checks.

## Unverified release requirements

No Windows clean install, dependency lockfile, real OBDLink/PCM Hammer run, hardware Full Read, or interrupted read/recovery has been verified. No physical ECU Test Write, write, or flash was performed. Do not claim hardware qualification or publish an installer.
