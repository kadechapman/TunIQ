# Run59 — Bounded evidence import snapshot (source-only)

Date: 2026-10-19. TunIQ version: 1.9.0-beta.108. No physical ECU, COM-port, PCM Test Write, ECU write or flash.

## Defect and scope

The Run58 P01 evidence importer checked the source file size with `statSync()` but later used separate, unbounded `readFileSync()` calls for hashing, log normalization and XDF inspection. A file could grow, be replaced, or be redirected between the initial check and these later reads. A symlink to a CSV was accepted in a local Run58 reproduction and persisted as an imported record. The existing size check did not cap the bytes subsequently read.

## Change

`src/p01-evidence.js` now opens a regular, non-symlink input with `O_NOFOLLOW` where supported, checks file identity and timestamps around one descriptor-based read, caps the snapshot at the existing 100 MB limit, rejects unexpected EOF/extra bytes and file replacement, and computes the SHA-256 from the same bytes used for parsing. The importer does not re-open the user's path for hashing, CSV/JSON parsing, or XDF metadata. `src/log-import.js` exposes `normalizeText()` so the evidence importer can normalize its verified snapshot while preserving the existing `normalizeFile()` API for other callers.

The local-only regression tests cover CSV/JSON/XDF behavior, deduplication, over-limit files, leaf symlinks, file growth, truncation and pathname replacement. Existing evidence deletion containment checks remain in place.

## Limits

This is not an atomic filesystem snapshot against a malicious process with privileged write access to the *same open file descriptor*. Filesystem timestamp granularity and malicious modification/reversion remain residual risks. A 100 MB text import can still require substantial parser memory; the change bounds raw input bytes but does not impose a row/column or parse-time budget. No physical read-only hardware workflow has been verified. No Windows build or installer has been produced.

## Release state

Source-only. Keep ECU writes/flashes prohibited. No claim of user-testing or public-release readiness. The nine source-only launch blockers remain until a reproducible Windows build, locked dependencies, supervised read-only qualification and release controls are verified.
