# Run63 — Read-only phone-log interrupted-publication audit

## Scope

This development pass adds a **read-only**, bounded audit for the three files
produced by `importPhoneLog()` in a project's `Logs` directory:
`*-Imported-<timestamp>.csv`, `.meta.json`, and `.import.json`.
The Run62 publisher stages outputs, then publishes them one by one. A process
crash between publications can leave a partial set, even though synchronous
exceptions attempt rollback. The audit detects missing members without
opening log contents, modifying evidence, or touching ECU hardware.

## Usage

`node tools/audit-phone-log-imports.js "/path/to/TunIQ/project"`

Exit codes: `0` for a complete/empty inventory, `2` for partial, unsafe,
leftover-staging or truncated inventory, `1` for invalid input/IO failure.
The output is JSON. An absent `Logs` directory is considered clean and is not
created. The command does not delete or repair anything.

## Safety and limitations

- Inspects **at most 10,000** directory entries; an incomplete scan never
  reports `clean`. No recursive scan, log-content reads, or writes.
- Flags partial groups, symlink/hardlink/non-file outputs, and leftover
  `.phone-log-stage-*` entries. The audit does not follow output symlinks.
- A complete three-file set means **names and file types** were found, not
  that their contents are consistent or cryptographically verified.
- Does not remove orphan files, stage folders, or user data. A future recovery
  flow needs explicit ownership proof and user confirmation before deletion.
- The filesystem can change during scanning; this inventory is not an atomic
  snapshot and is not a physical ECU or Windows/NTFS validation.

## Verification

`node tests/phone-log-recovery-audit-simulations.js` exercises complete,
interrupted, symlinked, staging-leftover, truncated and CLI paths on synthetic
local files only. The full suite also invokes the regression checks.
