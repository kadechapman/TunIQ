# TunIQ v1.9.0-beta.81 — Read Evidence Alias Admission Guard

**Source-only development checkpoint. Not a runnable Windows installer or a public beta release.**

- Reject symbolic-link read files and files with multiple hard links before adding Full Read evidence to P01 commissioning.
- Reject files beneath symbolic-link or junction parent directories before adding evidence.
- Require separate direct regular files when accepting the second matching read; this no longer depends on inode-only alias detection.
- Add offline filesystem regression coverage for first/second read aliases, redirected parents, hardlinks, and legitimate independent files.
- Preserve the beta.80 live verification of saved read-pair evidence.

These checks are not atomic filesystem locks and do not attest to physical ECU reads. Hardware, Windows CLI/kernel, clean installer, signing, licensing, privacy, redistribution, updates, and recovery qualification remain outstanding. No PCM write or Test Write was performed.
