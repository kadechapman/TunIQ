# Run75 — Fail-closed active renderer HTML source audit

**Scope:** Offline, read-only Electron startup source contract. No Electron launch, hardware access, ECU communication, writes, or flashes.

## Reproduced issue

Run74 checked the `src`/`href` of quoted `<script>` and `<link>` elements, but it did not reject an extra inline `<script>` without `src`. A controlled fixture injected an inline script and Run74's source preflight incorrectly accepted it. This is a **source-check coverage gap**, not a demonstrated runtime exploit.

## Changes

The existing `tools/electron-startup-contract-preflight.js` now rejects unexpected active HTML via `unsafe-active-renderer-html`:

- Inline scripts, script bodies, unquoted or unexpected script sources, duplicate script sources, and missing script closures.
- Unexpected stylesheet links and unquoted stylesheet URLs.
- Embedded frames, objects, embeds, and base URL overrides.
- HTML refresh redirects, inline HTML event handlers, and explicit form actions.

The expected static renderer assets remain exactly `engine-catalog.js`, `app.js`, and `styles.css`. Seven offline regression cases were added to `tests/electron-startup-contract-preflight-simulations.js` and are exercised by the existing Windows source-only workflow.

## Limits

This is a conservative pattern-based **source audit**, not a complete HTML parser, CSP, runtime content-security policy, or proof of Electron security. It does not inspect dynamically generated HTML, CSS URLs, JS `eval`, network activity, runtime IPC, or the actual Windows build. The checks intentionally require updating when legitimate startup assets change. Windows runtime and dependency-installation checks remain blocked until a verified lockfile and runnable write-disabled build are available.

**Release:** NOT READY FOR USER TESTING; NOT READY FOR PUBLIC RELEASE.
