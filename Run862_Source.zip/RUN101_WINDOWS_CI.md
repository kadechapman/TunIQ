# Run101 — Windows CI execution route for isolated offline preview

This checkpoint adds `.github/workflows/windows-offline-preview-build.yml`.
After the full Run101 source has been reviewed and pushed to a `dev/**` branch,
GitHub Actions will attempt a **real Windows** Node/Electron install and two
native renderer smoke tests using `tools/windows-build-offline-preview.ps1`.
The workflow requires separate evidence of staged and packaged renderer
startup before uploading the unsigned, unpacked **offline UI preview**.
Failure diagnostics are uploaded even if npm DNS, dependency resolution,
Electron startup, or packaging fails. This is not an ECU-capable installer.

The workflow has read-only repository permissions and retains no checkout
credentials. No physical OBD/ECU device, ECU read, write, Test Write, or flash
is permitted. The workflow's existence is NOT proof it ran. It will not run
until this source is pushed; it does not automatically migrate older GitHub
repository content.

## Manual Windows fallback

Extract the Run101 source on Windows 10/11, open PowerShell at the extracted
source root, and disconnect all vehicle/OBD hardware:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output/Run97-Diagnostics-<guid>/build-outcome.json`, the
transcript, staged/packaged smoke evidence and native stdout/stderr. A successful
run creates `dev-build-output/Offline-UI-Preview-<guid>/TunIQ Offline UI Preview.exe`.
The `Run97` diagnostics prefix is historical, not the source version.
Inspect logs for personal filesystem paths before sharing.

A successful native Windows offline preview is not proof of full TunIQ
readiness, ECU safety, or public release readiness.
