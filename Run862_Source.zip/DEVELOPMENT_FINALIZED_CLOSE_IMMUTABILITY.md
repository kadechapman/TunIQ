# TunIQ beta.108 — finalized PCM Hammer child-close evidence immutability

**October 17, 2026. Source-only development checkpoint; not approved for user testing or public release.** No physical ECU, COM/OBDLink session, PCM Test Write, ECU write, or flash was used.

## Latest verified source

This pass uses the **newest verified TunIQ Library source available at development start**, `TunIQ_beta108_dev_Reconciled_Child_Close_Guard_Source_v2.zip`, SHA-256 `d8e801fa7966d80e59afb0f64a852fce6899decaf4e0f0f7a166416450329226`, with 558/558 source-manifest files verified and 561 ZIP entries passing CRC. The preceding `TunIQ_beta108_dev_Monotonic_Close_Evidence_Source.zip` had SHA-256 `b54b85b0865ebb4ae4f512ad77ea2c8ec4f06cdeb6450f83f33f1a8db1341cb6`, 557/557 verified. Actual `src/p01-hardware-transaction.js` and its tests were inspected and compared, not inferred from prior reports.

## Reproduced defect

After a successful Full Read had reached `operation-complete`, the newest source still admitted another `markProcessClosed()` callback with the same session and `success: true`. A delayed callback could rewrite `lastStopCode` to `adapter-open-failed`, refresh `processClosedAt`, and append a misleading close event even though the operation had already finalized. The before-fix reproduction changed a completed operation's stop code and history. This is an evidence-integrity defect, not a claim of physical ECU harm.

## Change

`src/p01-hardware-transaction.js` now accepts a child-close callback only while the matching child is `process-running` or `process-closed`. It rejects any further close once `operation-complete`, while retaining the existing monotonic downgrade checks and allowing a legitimate same-child `process-closed` to `operation-complete` finalizer transition. `tests/p01-hardware-transaction-simulations.js` adds regression assertions that both a contradictory and an identical duplicate success close are denied without changing finalized evidence or history. The old hand-maintained assertion count was removed because it was not a reliable measured count.

No production ECU write/flash path was changed or enabled. Existing synthetic Test Write fixtures do not authorize physical writes.

## Boundaries and remaining gates

Linux/Node.js simulations cannot establish native Windows CLI/kernel compatibility, real exclusive COM ownership, OBDLink behavior, two independent matching physical Full Reads, or interrupted physical Full Read recovery. The dependency lockfile is missing; Windows clean install/build, signing, licensing, secure updates, privacy, redistribution, incident response, exact-OS calibration/checksum qualification, protected backups and approval-gated AI tuning remain release blockers. Source-only launch snapshot must remain current. No October 17 public release is justified; supervised read-only beta only after runnable Windows and relevant hardware evidence.
