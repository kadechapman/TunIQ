# TunIQ v1.9.0-beta.30 — Identity Recheck Boundary and Release Freeze

**Source-only checkpoint. No Windows installer and no hardware tests.**

- Prevent saved COM-port proof from being reused while a newer Read Properties attempt is running, queued, or has an unrecognized state.
- Prevent successful Full Read records from inheriting a prior OS identity across a newer failed Read Properties attempt; require a fresh successful identity check.
- Remove tag-triggered public installer build and GitHub prerelease publication from the Windows workflow. Restrict workflow to manually dispatched source validation with read-only repository permissions and `npm ci`. Because `package-lock.json` is not yet present, the workflow intentionally fails closed before installation. No signed or public release is generated.
- Added regression assertions for in-flight identity checks, failed-recheck identity lineage, and the public-release workflow freeze.

**Safety:** No physical PCM communication, Test Write, PCM write, or ECU calibration change was performed. Source simulations do not establish hardware qualification. Public flashing remains blocked.
