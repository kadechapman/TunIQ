# TunIQ 1.9.0-beta.27 — Hardware Identity Conflict Guard

Base: 1.9.0-beta.26. Source-only Linux/mock testing; no physical PCM tests or writes.

## Change

- P01 recorded sessions must not conflict with the active project hardware ID or service number when both values are known, even when controller, OS and COM port match.
- A newer completed Read Properties observation with invalid or conflicting identity prevents recovery from silently falling back to older COM-port evidence. A newer completed Full Read or Test Write explicitly identifying different hardware also invalidates old proof.
- The FlashManager preflight rejects a proof with known hardware/service identity that conflicts with the active project before touching the adapter.
- Existing incomplete identity handling is retained: absence of a hardware/service field is not independently authenticated, and actual hardware qualification is still required.

This is an internal evidence consistency check, not proof of real ECU identity or physical read success. Unrestricted public flashing remains blocked.
