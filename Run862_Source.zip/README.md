> **v1.9.0-beta.108 source-only checkpoint:** Rejects explicit structured `CRC check: FAILED`, `Checksum validation: FAILED`, and `Hash verification: FAILED` diagnostics during Full Read and Read Properties, even when a CLI prints a success footer or OSID and exits zero. Prevents automatic read-only CLI retry after these failures. Preserves beta.107 sector/page protection. Offline synthetic verification only; no physical PCM/OBDLink or Windows qualification. No ECU writes or public release.

> **v1.9.0-beta.107 source-only checkpoint:** Preserves beta.106 Read Properties block-error identity protection and also rejects explicit failed sector/page memory reads despite a successful PCM Hammer CLI footer. Prevents automatic read-only CLI retry after these runtime failures. Offline synthetic verification only, not physical OBDLink/PCM or Windows qualification. No ECU writes or public release.

> **v1.9.0-beta.106 source-only checkpoint:** A Read Properties OSID is no longer admitted if PCM Hammer reported even one failed memory block. A nominal CLI exit 0 and OSID text cannot override block-failure evidence. Retains beta.105 Full Read block protections. Offline simulation only; no Windows/hardware qualification or ECU writes.

> **v1.9.0-beta.105 source-only checkpoint:** Reconciles beta.104 read-integrity counter and CLI retry protections with a new fail-closed Full Read block-error rule. One or two explicitly failed blocks now reject the entire read even if the CLI exits zero and prints success; the existing three-or-more-failures stop code is retained. This is offline software testing only, not Windows or physical ECU qualification. No ECU writes or public release.

> **v1.9.0-beta.104 source-only checkpoint:** Extends the beta.103 read-integrity guard to explicit nonzero CRC/checksum/hash error counters and does-not-match diagnostics, blocking both read-only evidence admission and automatic CLI retry when contradictory syntax/usage output appears. This is offline log classification only; no Windows installer, physical ECU validation, or calibration checksum certification is claimed.

> **v1.9.0-beta.102 source-only checkpoint:** Read-only PCM Hammer results now reject kernel upload, load, execution, startup, or transfer failure diagnostics even if the CLI exits zero and later prints a success footer or OSID. Existing missing-kernel and BIN proof guards remain in place. Verification is offline; no Windows installer or physical ECU qualification is claimed.

> **v1.9.0-beta.100 source-only checkpoint:** PCM Hammer Full Reads and Read Properties operations that fail evidence admission (partial/cancelled reads, failed backup or identity import) now revoke `result.success` and bind `result.stopCode` to the final failure state. Previous identity and rejected-BIN safeguards remain. This is offline-only source, not a verified Windows build or physical ECU qualification.

> **v1.9.0-beta.99 source-only checkpoint:** Failed PCM Hammer Read Properties and Full Read operations cannot promote incidental OSID or hardware identity text into a project. Full Read identity admission additionally requires a validated and successfully imported backup. Prior cancelled-read and nonclobber quarantine guards remain. Offline simulation only; no physical hardware, Windows installation, ECU write, or public release verified.

> **v1.9.0-beta.98 source-only checkpoint:** Failed, cancelled, and import-rejected PCM Hammer Full Reads now quarantine without replacing a previous rejected BIN. Exclusive destination creation and source-identity checks fail closed when a file changes or cannot be moved. This is offline source testing only; no physical hardware or Windows installation was verified, no ECU writes occurred, and no release was published.

> **v1.9.0-beta.97 source-only checkpoint:** If a PCM Hammer Full Read passes file checks but project import throws, TunIQ now revokes accepted output evidence and quarantines the original BIN when possible. Previous cancellation and serial-open retry guards remain. Offline simulations only; no Windows or physical hardware verification, no ECU writes, and no public release.

> **Previous beta.96 checkpoint:** Preserves beta.95 serial-open retry blocking and adds cancelled read-only evidence guards: Full Read and Read Properties cannot import or promote a success result after cancellation, even with exit 0 and valid-looking output. Synthetic tests only, no Windows or physical hardware verification, no ECU writes, and no public release.

> **v1.9.0-beta.95 source-only checkpoint:** A confirmed `Opened serial port COM4` (or `Serial port COM4 opened`) log prevents another PCM Hammer read-only command profile or typed-device retry, even if the CLI subsequently prints a parser error and Usage footer. Offline regressions only. No physical COM/ECU, Windows installation, writes, or public release verified.

> **v1.9.0-beta.94 source-only checkpoint:** PCM Hammer CLI read-only profile and typed-device retries now reject negative or large unsigned Windows native process statuses (including crash-like NTSTATUS values) and unsafe integers. Offline regressions added. No Windows/hardware verification, no ECU writes, and no public release.

> **v1.9.0-beta.93 source-only checkpoint:** Typed-device CLI fallback now rejects parser logs mentioning a different plain COM port or conflicting serial type, even if they also contain an `elm` error. Five offline regression cases added. No Windows or physical ECU validation, no writes, and no public release.

> **v1.9.0-beta.92 source-only checkpoint:** Reconciles beta.91 typed-device diagnostic binding with a new strict unused Full Read destination recheck before plain-COM fallback. Offline software verification only; no Windows build or physical ECU qualification.

> **v1.9.0-beta.91 source-only checkpoint:** PCM Hammer typed `COMx:elm` fallback now requires an explicit rejection of the *same* ELM type/COM port requested; unrelated type and different-port errors cannot authorize a second attempt. Numeric nonzero exit and no-communication guards remain. No Windows or physical ECU verification.

## Beta.89 Full Read existing-parent guard (2026-10-17)

Before PCM Hammer Full Read admission or read-only command-profile fallback, TunIQ now rejects backup paths with missing parent/ancestor directories. A nonexistent folder cannot be treated as a verified, unused local destination. TunIQ does not create directories during validation; the user must select or create a real local folder first. Offline regressions cover direct and nested missing parents and a syntax-only CLI retry. This does **not** atomically reserve a filename, establish physical COM ownership, or verify Windows/ECU hardware. No ECU writes or flashes were performed.

## Beta.87 Full Read retry destination guard (2026-10-17)

A failed PCM Hammer Full Read may try another read-only command-line profile only after a genuine nonzero syntax-rejection exit **and** an explicitly named, still-unused, locally safe backup destination. Missing output paths, redirected/symlink/junction parents, Windows reserved/alias names and UNC/device namespaces block retry. Read Properties syntax-only discovery remains unchanged. Tested offline with synthetic files; **not** physical COM, PCM or Windows verification. No ECU write or flash.

## Beta.78 reconciled read-only evidence safeguards (2026-10-16)

Preserves beta.77's restriction on untrusted assisted GUI BIN/log evidence in read-only mode and adds a fail-closed independence gate for P01 Full Read commissioning. Two matching disk-only BIN filenames cannot reconstruct independent ECU sessions after a ledger loss; same-file/hardlink reuse and changed first-read files are rejected. A saved pair pointer can be restored only from separately recorded, digest-matched read evidence. Synthetic tests only; no Windows/physical ECU qualification or writes/flashes.

## Beta.76 source-only Full Read integration regression (2026-10-16)

Adds a combined filesystem-only test covering the beta.75 Win32 import path guard and beta.74 commissioning SHA-256 proof, plus failed CLI results and partial reads. No production ECU/flash code was changed. This is **not** a Windows installer or physical ECU verification.

## Beta.75 reconciled Full Read backup safety (2026-10-16)

This source-only checkpoint combines both independently verified beta.74 branches. Existing/assisted Full Read BIN validation rejects Win32 reserved aliases, unsafe parent names, device namespaces, UNC shares and drive-relative paths before filesystem access. Commissioning also re-hashes the BIN and refuses size/digest changes after the prior Full Read validation. Both regressions run together. These checks do not prove physical read independence, prevent every filesystem race, or establish Windows/OBDLink compatibility. PCM writes remain disabled; no physical ECU operation was performed.

## Beta.74 source-only safety checkpoint

Commissioning now rejects a Full Read if its SHA-256 or size differs from the preceding verified read result. This prevents a same-size file replacement between CLI validation and commissioning ledger import from becoming a trusted original. No physical ECU testing or Windows installer qualification has been performed.

## Beta.73 combined Full Read safeguards (2026-10-16)

Reconciles two independently verified beta.72 development checkpoints. (1) PCM Hammer CLI success does not promote a Full Read profile or last-success metadata until its 524,288-byte backup is integrity-validated and successfully imported. (2) Backup validation rejects symlink/junction parents or parent identity changes during hashing. Synthetic/file-system tests only: not Windows/physical hardware qualified. No ECU writes performed.

## Beta.72 source-only read-proof promotion guard (2026-10-16)

A PCM Hammer CLI success message or zero exit code is **not** proof of a valid Full Read. TunIQ now waits until the output is a standalone 524,288-byte file with a stable SHA-256 and its import callback succeeds before recording a successful read or promoting the discovered CLI profile. A partial file or failed import does not advance last-success metadata or show 100% progress. Synthetic tests cover failure and success paths; Windows/physical OBDLink and PCM hardware have **not** been tested. No ECU writes are permitted by this checkpoint.

## Beta.71 source-only safety checkpoint (2026-10-16)

- Fixed PCM Hammer child `error` handling that released the COM lease before the child emitted `close`. The process error now fails closed: no competing OBDLink/PCM Hammer operation may start until close confirms exit.
- Full Read interrupted by a child error is never imported as a verified backup. A partial BIN is retained as rejected evidence, with no automatic CLI profile/port retry.
- Synthetic regression verifies error-before-close ownership, competing serial access refusal, and partial Full Read recovery; **no physical Windows/ECU qualification**.


Bluetooth SPP repair now refuses to continue if persistent serial-session disconnect fails. Windows `taskkill.exe` asynchronous errors are handled without treating the kill request as COM release. No physical Windows/OBDLink qualification or ECU writes were performed.

## Beta.69 — OBD bridge subprocess exit ownership (source-only)

The short-lived Windows OBD PowerShell bridge no longer treats `child.kill()` or request timeout as proof that a COM handle was released. Aborted and timed-out bridge requests remain tracked until the child `close` event; new OBD bridge requests and PCM Hammer handoff are blocked while exit remains unconfirmed. The proven-port PCM Hammer path also fails closed on pending bridge exit. Synthetic Linux regressions only; no physical COM, ECU read, write, or flash verification. The source remains **not ready for Windows user testing or public release**.

## Beta.68 — persistent OBD child exit confirmation (source-only)

The persistent Windows PowerShell OBD session no longer reports its COM port released immediately after sending a close/kill request. Shutdown now waits for the child process `close` event; a bounded timeout fails closed, preserving the connection/session state and refusing PCM Hammer handoff. The Device Disconnect IPC handler now uses the non-disruptive COM admission latch so it cannot interrupt an active Full Read or a competing OBD operation. Synthetic Linux tests only: Windows process exit, real COM-port release, ECU Full Read, and any write have **not** been verified. No installer or public beta release is ready.

## Beta.67 — guarded OBD IPC serial entrypoints (source-only)

The Electron handlers for Device Connect, Connection Doctor, live sampling, and logger startup now reserve the same in-process serial admission lane as PCM Hammer. Rejected requests never cancel an active Full Read; a concurrent OBD operation also blocks PCM Hammer start until its pending work completes. These are synthetic Linux test results, **not** evidence of physical Windows COM ownership or ECU safety. This checkpoint is not a runnable Windows beta or public release.

## beta.66 — Non-disruptive PCM Hammer CLI probe admission (source-only)

- CLI help/version probing now reserves the same exclusive COM admission latch as external serial workflows, preventing overlapping PCM Hammer starts or probes.
- If PCM Hammer is reading, starting, or terminating, the probe stops **without cancelling the read**, launching another CLI process, or changing the CLI configuration.
- Synthetic Node regression reproduced the beta.65 gap and verifies fail-closed behavior. No Windows installer, physical OBDLink/PCM testing, or ECU writes were performed.

> Current source checkpoint: **TunIQ v1.9.0-beta.86 — Fail-Closed CLI Retry Exit Status**
> Read-only CLI command-profile fallback now requires a real numeric nonzero process exit and syntax-only evidence. A signal-terminated child (exit code null), missing exit code, string exit code, or exit zero must not launch another profile. This is an offline simulation guard, not hardware qualification.
> Before reporting a verified P01 read pair, TunIQ rechecks both saved BIN files for distinct backing identity, correct size and unchanged SHA-256. This is offline source validation, not physical ECU verification.

## beta.77 — Block unverified assisted PCM Hammer evidence in read-only beta (source-only)

- The restricted read-only beta now rejects assisted/manual BIN and log imports before accepting a hardware result. A 512-KB file and user-supplied text log are not proof of a completed PCM Hammer operation, and cannot be promoted into a verified Full Read or Test Write record through this import path.
- Assisted preparation and background scans fail closed; the Electron import IPC rejects before opening the file picker. The integrated **read-only** CLI Read Properties and Full Read paths remain unchanged. A test-only synthetic legacy mode remains isolated from production.
- Offline regression reproduces beta.76 accepting an arbitrary BIN, then verifies 10 fail-closed checks. **No native Windows build or physical OBDLink/PCM tests were performed.** Do not promote to public beta without clean Windows installation, verified read-only hardware sessions, and release signoffs.


## beta.65 external COM workflow admission guard

- Bluetooth SPP repair, manual OBDLink port verification, and manual PCM Hammer handoff now use a shared asynchronous serial-admission lease. PCM Hammer cannot start while these workflows are accessing the adapter; simultaneous external workflows are rejected.
- If PCM Hammer is starting or terminating, the external workflow stops before touching the serial port and asks the operator to retry after process exit. A recovery request may initiate read-only cancellation but never treats a kill request as proof of exit.
- Synthetic regression verifies fail-closed admission and lease cleanup after success/failure. Desktop handler wiring is statically checked; native Windows and physical hardware remain untested.

## beta.64 recovery / COM ownership guard

- Recovery and stop requests no longer clear an active PCM Hammer read-only session or advertise its COM port as idle immediately after requesting process termination. The existing child close/error finalizer retains responsibility for releasing the lease.
- Recovery while a PCM Hammer start is still in asynchronous Windows preflight preserves the in-flight admission guard rather than marking the port idle.
- Synthetic child and mock CLI regressions verify pending termination and eventual finalizer cleanup. No physical Windows COM port, OBDLink, PCM or ECU write was tested.

## beta.63 protocol-activity retry guard

- A PCM Hammer CLI log can contain ELM327/STN adapter initialization, diagnostic TX/RX frames, or a request/response before an appended `Usage` or `Unknown option` footer. These lines now count as runtime adapter activity, not proof of an unused COM port.
- Command-profile fallback is refused after that activity for **Read Properties** and **Full Read**. A pure syntax rejection without communication evidence still permits bounded read-only profile discovery.
- Regression: beta.62 classified seven such examples as retryable; beta.63 rejects them and a synthetic mock Full Read stops after a single command attempt. No physical COM/ECU testing or PCM writes occurred.

## beta.62 merged read-only safety

- Preserves verified Library beta.61's runtime block-read failure classification: no command-profile fallback after ECU communication/read/checksum failures even if the CLI also prints Usage help.
- Adds local-only Full Read output destination policy: reject UNC shares, Win32 device/extended-length namespaces, and drive-relative paths **before** path normalization. This regression failed against verified beta.60 and passed with the new guard.
- Both protections remain Linux-tested software behaviors only, not Windows or physical OBDLink verification. No ECU Test Write, write or flash was performed.

## beta.61 PCM Hammer read-only retry safety

PCM Hammer CLI output reporting a failed ECU block/sector/page read, read failure at an address, or CRC/checksum mismatch is now treated as a runtime failure, **even if the CLI also prints a generic usage footer and has not created an output file**. TunIQ must not try another read-only command profile after such evidence. Synthetic tests cover classification and the integrated Full Read path. This is a source-only checkpoint: no Windows/OBDLink/PCM hardware was verified.

## beta.60 merged read-only safety

- Preserves beta.59's synchronous `startPending` latch, which prevents overlapping PCM Hammer starts during asynchronous COM handoff.
- Adds a final Full Read destination check immediately before **every** PCM Hammer CLI spawn, including profile and COM retries. A synthetic foreign-file collision now stops without spawning the CLI or quarantining the unrelated file.
- The new collision regression failed on verified beta.58 and passed after correction on top of verified beta.59. Both guards are Linux software tests only; not native Windows or physical OBDLink qualification.

## beta.59 read-only COM ownership safety

- Reproduced a race where two `FlashManager.start()` calls could both pass preflight while the first awaited Windows process inventory. No PCM Hammer session had been published yet, so the existing `this.session` check did not exclude the second caller.
- Added a synchronous `startPending` admission latch around the asynchronous preflight and COM handoff. A second request now stops with `operation-starting` before process inventory, serial release or child-process launch. The latch is cleared after success or failure; an active launched session remains protected by the existing session check.
- A deferred-inventory regression failed against verified beta.58 and passed after correction. Synthetic software verification only; no physical COM, Windows installer or ECU write was performed.

## beta.58 merged source-only reliability

- Preserves verified Library beta.57's stricter npm dependency lockfile checks, including transitive dependency metadata, registry URLs, and integrity pins. These checks do **not** replace a real `npm ci` or verify downloaded tarball bytes.
- Full Read preflight now passes the **same resolved absolute path** to PCM Hammer that it checked for existing output and symlink/junction parents. A relative user input cannot silently resolve under a different child-process working directory. Missing session subfolders can still be created after safe ancestor checks.
- The relative-path regression failed on beta.56, then passed after correction; the merge was retested against the newer transitive-lock beta.57. Both improvements are Linux software tests only, not physical Windows/OBDLink verification.

## beta.57 source-only npm dependency-tree safety

- Reproduced a release-gate bug: beta.56 accepted a synthetic lockfile with a direct dependency that declared a missing transitive package. The offline metadata gate now requires every locked registry package to have an exact version, official npm HTTPS tarball URL and SHA-512 integrity field, and checks declared transitive/optional dependency paths. Malformed lock entries and path traversal are rejected.
- This is deliberately a **metadata-only safety check**. It does not authenticate downloaded packages, prove dependency version-range satisfaction, replace `npm ci`, or establish a clean Windows installer. Alternative registries, local workspaces and bundled packages need separate provenance review.
- No actual npm lockfile was produced. No Windows build, OBDLink hardware test, physical PCM Test Write, or PCM write was performed. The existing restricted read-only and Win32 output-path guards remain in place.

## beta.56 merged source-only safety

- Preserves independently verified Library beta.55's fail-closed npm dependency lockfile launch gate and lockfile-bound source freshness fingerprint.
- Extends the existing Full Read output-path guard to Win32 superscript COM/LPT aliases (`COM¹`–`COM³`, `LPT¹`–`LPT³`), `CONIN$`/`CONOUT$` and invalid Win32 filename characters. Parent folders are also checked. Regression failed against beta.55 before correction; **33/33** local path checks passed afterward.
- Both changes remain Linux-tested, source-only. No lockfile could be generated without registry access; no Windows build, native COM test, physical read, Test Write or PCM write was attempted.

## beta.55 combined read-only safety

- Preserves verified Library beta.53's Windows reserved device name, NTFS alternate-stream, and trailing-dot/space read-output path rejection. See `WINDOWS_READ_OUTPUT_PATH_RECOVERY.md`.
- Adds per-attempt PCM Hammer executable SHA-256/path verification: if a pinned CLI changes after the first syntax-only read command, TunIQ stops before trying another profile. Rechecks before each CLI help/version/device-list capture; probe() does not silently re-pin substituted bytes.
- Two POSIX synthetic executable-swap regression scenarios passed on Linux without any COM-port access. Windows-native and physical PCM Hammer/OBDLink tests remain outstanding; hash pinning is not publisher authentication or an atomic filesystem guarantee.
- **Source-only checkpoint:** no Windows installer, Test Write, PCM write, flash, or public release.


## beta.53 source-only Windows Full Read output-path guard

- Full Read destinations now reject Windows reserved device basenames (`NUL.bin`, `COM1.bin`, etc.), NTFS alternate data stream colons (`read.bin:stream`), and trailing-dot/space aliases, including unsafe parent folder names.
- This prevents common Win32 name aliasing from bypassing the existing new-output-only checks. The guard runs before folder creation and is rechecked after COM handoff. It is **not an atomic file reservation**, and real Windows/OBDLink compatibility is still unverified.
- Read-only filesystem regressions were executed on Linux; no physical PCM reads, Test Writes, writes or flashes were attempted. See `WINDOWS_READ_OUTPUT_PATH_RECOVERY.md`.

## beta.52 source-only CLI pin metadata safety

- Builds on verified Library beta.51. If a previously probed PCM Hammer SHA-256 digest exists, the saved original executable path must also be a nonempty string. Missing/malformed paths fail closed instead of silently disabling path pinning.
- A malformed non-string digest also fails closed. This is local executable change detection, **not publisher authentication** or a substitute for real Windows CLI/kernel qualification.
- Regression tests are synthetic/Linux only; no physical PCM reads, writes or flashes were attempted.

## beta.51 source-only PCM Hammer executable drift guard

- After an integrated CLI probe records a SHA-256 and executable path, restricted read-only operations now stop when those bytes/path change. This is checked before preflight, CLI device discovery, re-probe, and again after asynchronous COM handoff before creating a session.
- A changed CLI reports `cli-executable-integrity-changed` and no longer appears configured or integrated. Invalid saved digest values also fail closed.
- **Not an authenticity or publisher-signature check.** A first-time unprobed CLI remains unpinned, and hash checks cannot eliminate all path-replacement races. Review and reinstall the official PCM Hammer package before manually resetting a changed probe. No real Windows/OBDLink test has occurred.

## beta.50 source-only CLI prefix defense-in-depth

- Builds on beta.49: in restricted mode, resolved executable metadata never exposes blocked prefix arguments to any subprocess caller, even one that omits the preflight guard.
- Rejects malformed saved or supplied prefix values (including strings), rather than silently interpreting them as an empty argument list. Unsafe probe inputs are rejected before saving configuration.
- Reports a blocked CLI as not configured/integrated, suppresses runnable read capabilities, and preserves the saved configuration for explicit review. Test-only mock CLI fixtures retain their existing scoped opt-in.
- This is **not** a Windows executable provenance check, a hardware test, or a runnable installer.

## beta.49 source-only prefix guard

- Restricted read-only beta rejects saved prefix arguments before CLI probing, device discovery and read preflight. Production explicitly overrides test-only mock CLI prefix allowances.

## beta.47 source-only restricted read-only safety changes

- The packaged Electron app creates `FlashManager` with `readOnlyBeta: true`; the manager defaults to read-only and rejects Test Write, calibration write, full write and recovery before preflight or serial-port access.
- Integrated Read Properties and Full Read remain eligible, subject to all existing validation and COM-ownership guards.
- Unrestricted PCM Hammer GUI launches through assisted mode and Tool Connections are blocked. Guided P01 automation pauses before automatic calibration revision generation and Test Write; explicit calibration write is blocked.
- Legacy synthetic tests can opt into simulated write operations only through an explicit `platform: 'test'` constructor option. This is not a UI preference or production configuration.
- **Not a verified Windows build or a security audit of every external tool path.** Other externally launched applications may have their own write capabilities. No physical PCM testing or writing occurred.

## beta.46 source-only combined safety changes

- Preserves beta.45's fail-closed Windows CIM process inventory validation (missing/duplicate process identity is rejected before COM ownership inspection).
- Adds a PCM Hammer runtime-failure guard: ECU no-response, connection failure, response timeout and kernel-upload failure cannot be treated as syntax-only even when a CLI usage footer follows. A mock read-only Read Properties process confirms only one command profile is attempted.
- Linux simulations are not Windows/OBDLink/PCM hardware verification. Write-capable paths remain present; this is not a public beta or verified runnable installer.

## beta.45 source-only safety change

- Reject Windows CIM process inventories with missing process names or PIDs, duplicate PIDs, invalid numeric identities, or unrecognized PID-zero rows even if PowerShell exited successfully and emitted valid JSON.
- Preserve Windows `System Idle Process` PID 0, so a normal CIM inventory is not rejected for including that system process.
- An untrusted inventory must stop exclusive-adapter preflight rather than be mistaken for no competing serial applications. Regression tests use mocked PowerShell on Linux, **not real Windows COM hardware**.
- See `WINDOWS_PROCESS_INVENTORY_RECOVERY.md` for safe read-only troubleshooting. Write-capable code paths remain present and **are not authorized for public beta**.

## beta.44 source-only safety change

Additional abbreviated Windows COM access-denied and locked-port errors now stop read-only PCM Hammer CLI profile retries. This is a Linux-tested source checkpoint only; native Windows and physical PCM qualification are outstanding.

## beta.43 source-only safety change

- Treat Windows/.NET missing-COM-port errors, COM access-denied errors, and Windows file-sharing violations as **runtime failures**, even when PCM Hammer appends a generic CLI usage footer. Do not cycle read-only CLI command profiles after those failures.
- Retain beta.42's fail-closed exclusive COM ownership, protected read destinations, and bounded syntax-only fallback. This does not establish that Windows drivers, kernels, or real OBDLink hardware work.
- Regression tests use synthetic Windows exception text and mock CLI processes on Linux; no physical PCM was accessed or written.

## beta.38 source-only safety change

- Hardware launch readiness now fails closed unless **every** Verified controller/OS/interface combination in the matrix has its own matching private evidence record. A single passing P01 record can no longer authorize an unevidenced P59 scope. Missing or malformed exact scopes are rejected.
- This checks local file structure, hashes, and self-declared reviewer fields; it **cannot prove** physical testing, independent review, or correct PCM operations. The public flashing launch remains blocked.
- No real PCM writes, Test Writes, or hardware tests were performed.

## beta.37 source-only safety change

The evidence gate now hashes through a pinned descriptor in 64 KiB chunks and rechecks realpath after hashing. Added linked-parent regression coverage. Retains beta.36 hard-link, empty-log and duplicate-path protections. These are software-only checks, not physical hardware validation.

## beta.36 source-only safety change

- Hardware launch-gate evidence rejects hard-linked BINs/logs, alternate spellings of the same Full Read path, empty evidence logs, and symlinked ancestors within the private evidence tree.
- Hashes are calculated through an open file descriptor with before/after identity and modification checks; this reduces, but does not eliminate, filesystem races.
- Synthetic evidence with fabricated reviewer declarations can still satisfy structural checks. **Only independent physical bench review can establish hardware provenance.**
- No physical PCM operation or write was performed. Public release remains blocked.

## beta.35 source-only safety change

- Retains beta.34 symlink/hardlink and read-file identity integrity checks after PCM Hammer completes a Full Read.
- Rejects a new Full Read destination beneath a symlink/junction directory before output creation and after COM handoff.
- Simulations are not Windows/OBDLink/PCM evidence. No physical writes or hardware testing; public release remains blocked.

# TunIQ v1.9.0-beta.30 — Identity Recheck Boundary and Release Freeze

TunIQ is a Windows automotive tuning workspace that keeps vehicles, PCM projects, protected originals, definitions, revisions, logs, diagnostics, external tuning tools, and launch-readiness evidence together.

## What changed in beta.30
- A newer Read Properties attempt now suspends old P01 COM authority **while still running**; incomplete or unknown states also fail closed.
- A Full Read cannot inherit an old OSID if a newer Read Properties attempt failed between the read and the original verified identity session.
- The Windows workflow is now **manual source validation only**: no tag-triggered installer builds or public releases. CI requires a dependency lockfile and `npm ci`; the missing lockfile remains a release blocker.
- This release contains no physical PCM verification and no write authorization.

## What changed in beta.29
- A newer **failed, cancelled, or unverified Read Properties** attempt now invalidates an older verified P01 COM-port claim for the same project, even when Windows reuses the same COM number.
- The previous identity is retained for diagnosis but is **not** permission for an automatic Full Read or Test Write. A fresh successful Read Properties is required.
- Failed Full Reads still preserve prior valid identity evidence for read-only recovery. Other projects remain isolated.
- Simulations only: no physical PCM communication or writes were performed.

## What changed in beta.28
- When a newer completed Read Properties observation conflicts with the active ECU, TunIQ now **revokes** stale persisted proven-port authority instead of leaving the saved COM claim in guided state.
- Before each guided Full Read or Test Write payload, TunIQ reconstructs proof from successful history. Saved claims cannot independently authorize the exclusive COM lane.
- A new setup with no proof does not trigger false revocation warnings; selected COM port remains available for fresh Read Properties.
- No physical PCM communication, Test Write, or flashing is claimed. This is a source-only safety improvement.

## What changed in beta.27
- On restart, a saved "proven" COM-port record must be corroborated by the latest successful, identity-consistent PCM Hammer session history. Missing, stale, or fabricated guided-state proof cannot independently authorize pinned-port reuse.
- Previously verified Read Properties identity remains recoverable through recorded Full Read lineage. The active project's OS must be a valid exact numeric match before authoritative COM-port reuse.
- This change is **not** proof of physical ECU communication. Read/flash qualification remains blocked pending real Windows OBDLink and PCM Hammer validation.

## What changed in beta.25

- Preserves the OS and controller identity from a matching verified Read Properties session after a successful full read that does not print an OSID.
- Rejects incomplete guided-state proof, unvalidated reads, and unproven Test Write claims instead of promoting them to a trusted COM-port lane.
- No physical PCM communication or write is implied by these software checks.

## What changed in beta.20

- Starts new P01 calibration requests and build notes blank instead of inserting example tune changes.
- Fresh Full AI intake no longer guesses an engine from a saved Garage vehicle.
- Phone web importer rejects rows with no real numeric sensor readings while keeping actual zero readings.
- Existing saved project and AI intake data remain intact when editing an existing project.

## Retained beta.19 launch safeguards

- Adds a separate Full Launch Gate in the Release Center so feature progress cannot be mistaken for release approval.
- Uses VERSION.json/package metadata as the runtime version authority instead of another hard-coded desktop version.
- Pins direct dependency versions and explicitly flags the still-missing npm lockfile as a launch blocker.
- Audits license, secure update feed, verified real hardware, signing, privacy review, third-party redistribution, incident response, and clean-Windows-install evidence.
- Adds an exportable launch-readiness report and a release-attestation template.
- Preserves beta.18 PCM Hammer exclusive OBDLink ownership, P01 recovery, AI incident replay, and all real-write safety gates.

## Safety boundary

TunIQ does not guess VATS raw values, fan addresses, units, or unsupported definitions. A read-only commissioning definition cannot be used for these calibration changes. Keep each physical PCM in its own project, verify two matching reads, preserve the original, validate the revision, complete Test Write, and make any real write a separate deliberate action.

See `P01_QUICK_SERVICE.md`, `RELEASE_NOTES_v1.9.0-beta.1.md`, and `TunIQ_v1.9.0-beta.1_TEST_REPORT.md`.


## v1.9.0-beta.5 connection recovery

When Windows exposes Bluetooth COM ports that TunIQ cannot open, the P01 workflow can open Windows pairing, verify a manually selected COM port, or authorize one read-only PCM Hammer Read Properties attempt on that exact port. A successful PCM Hammer result proves the port for the remaining reads and Test Write. Real PCM writes still require the normal verified connection path.

## v1.9.0-beta.7 live hardware state reconciliation

Every guided P01 hardware attempt now receives a unique attempt ID that follows it through PCM Hammer, progress events, recovery state, and the Hardware Session Doctor. Starting a new attempt clears the previous recovery code and port timeline, delayed results from cancelled attempts are ignored, and the renderer rejects older state snapshots. Verified reads and project evidence remain unchanged.


**beta.30 release freeze:** The Windows workflow is validation-only and cannot publish an installer. It intentionally requires a committed `package-lock.json`; see RELEASE_NOTES_v1.9.0-beta.30.md.

### Beta.31 source snapshot integrity

The source-only launch snapshot now contains a deterministic SHA-256 fingerprint of application source, web code, tooling, regression tests, release workflows, and version metadata. `npm run check` fails when those files change without a regenerated snapshot. This is a stale-source detection mechanism, **not** proof of hardware qualification or safe ECU flashing. Physical write paths remain unqualified.

### Beta.32 Full Read output preservation

Integrated Full Read refuses any existing destination, including an original BIN, a partial/interrupted BIN, and a dangling symlink. Checks occur before COM handoff and after asynchronous Bluetooth settle, before PCM Hammer is launched. Existing backups are never silently overwritten or renamed by this guard. This is software simulation only; real Windows hardware and TOCTOU race hardening are outstanding.

### Beta.34 Full Read evidence link integrity

A CLI-produced Full Read is not accepted as independent evidence when its output is a symlink, hard link, nonregular file, or changes during hashing. The validator binds SHA-256 to an open descriptor and compares file identity/metadata before and after reading. This does not eliminate every Windows filesystem race and is not physical PCM verification.

### Beta.41 exclusive COM ownership inspection

Before PCM Hammer launches, TunIQ now refuses the operation if its exclusive-process inspection fails or does not return a valid decision. Windows PowerShell/CIM inventory failures, timeouts, invalid JSON and abnormal exits are errors rather than silently reporting zero conflicting processes. This is a **software-only fail-closed change**, not evidence that Windows or OBDLink MX+ hardware was tested. No PCM writes were performed.


## Beta.79 saved Full Read recovery alias guard (2026-10-16)

The damaged-ledger repair path now refuses two saved read-session records if their BIN paths resolve to a symbolic link, hard link, or the same physical file. Both files must be separate regular single-link files when recovery occurs; inaccessible filesystem metadata fails closed. The new offline regression reproduces the beta.78 alias promotion defect and tests legitimate recovery. This is not proof of two physical ECU reads, Windows compatibility, or readiness to flash. No ECU writes were performed.

### Beta.81 read-evidence admission hardening

P01 commissioning now rejects symbolic-link read files, multiply-linked BINs, and read files beneath symlink/junction parent directories **before** recording a first or second read. The second read must also pass the existing independent-file check before it can be marked verified. This is a source-only filesystem safeguard, not proof of independent physical ECU sessions or an atomic filesystem lock.

### Beta.82 private hardware evidence ancestor guard

The private hardware launch-evidence verifier now rejects symlink/junction ancestor directories and rechecks directory identities after manifest parsing and evidence hashing. This was reconciled from a separate verified beta.81 Library checkpoint with the beta.81 read-admission fix. Neither simulation establishes physical hardware qualification.

### Beta.83 explicit Full Read completion evidence

A complete-size 512 KB BIN is not automatically a successful ECU read. `validateP01ReadFile` now requires an explicit boolean `success: true` completion result; missing, null, empty, string, and numeric success values fail closed. This does not authenticate external assisted imports or prove that a real ECU read occurred. The restricted read-only beta still blocks unverified assisted evidence. No hardware or Windows testing occurred.

## Beta.88 reconciled CLI retry safety (2026-10-17)

Preserves beta.87's fail-closed Full Read destination check (no missing/unsafe/linked output path) and adds a separate requirement for **explicit CLI parser rejection** before read-only command-profile fallback. A generic `Usage:` / `Operations:` footer after an unrelated runtime failure cannot authorize another attempt. Existing numeric nonzero exit, no-communication, no-output, and exclusive COM admission checks remain. These are offline software safeguards, not atomic COM ownership or physical hardware evidence. No real Test Write, ECU write, or flash occurred.
