# TunIQ 1.9.0-beta.73 — reconciled Full Read proof guards

- Reconciles two distinct beta.72 Library checkpoints without discarding either safety fix.
- A CLI success message or exit code 0 cannot promote a read profile, last-success timestamp, or 100% progress until the backup passes length/hash validation and the import succeeds.
- A 524,288-byte BIN reached through a symlink/junction parent, missing parent, or parent that changes during validation is rejected with `read-file-unsafe-parent`.
- Added regression tests for partial read, valid read, failed import, redirected parent and direct-file link. No physical Windows, OBDLink, ECU, Test Write, or write verification.
- No installer/public release; missing dependency lockfile, license, signed clean Windows build, secure updates, private physical hardware qualification, privacy/redistribution/incident reviews.
