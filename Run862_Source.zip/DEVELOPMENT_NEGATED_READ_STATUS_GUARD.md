# Development checkpoint: negated read-completion guard

**Source-only, not a runnable Windows build or hardware qualification.**

PCM Hammer CLI output can include contradictory lines (for example, `Read completed: false` followed by `Read completed successfully`). The read-only result classifier now treats an explicit negated/failed read-completion status as disqualifying, regardless of exit code or a later success footer. `read-incomplete` is the recovery stop code. Read Properties OS identity cannot override this condition. The same evidence blocks automatic CLI profile retries and typed COM fallback; it does not initiate another serial-port attempt.

This is a bounded textual diagnostic guard with synthetic regressions, not proof of PCM Hammer Windows CLI/kernel compatibility, exclusive physical COM ownership, or a complete backup. No ECU writes or physical hardware operations are part of this checkpoint. The production release gate remains closed.
