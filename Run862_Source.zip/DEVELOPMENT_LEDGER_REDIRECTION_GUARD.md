# TunIQ beta.108 — COM ownership ledger redirection guard

Source-only development checkpoint, October 18, 2026. **No physical adapter or ECU testing.**

## Reproduced issue

The previous `readLedger()` used `readFileSync(path)`. A symlink to an external, syntactically valid ledger was accepted as trusted COM ownership evidence. A dangling symlink returned `ENOENT`, which was incorrectly treated as an absent first-run ledger. An existing hardlink likewise allowed an external file to supply COM ownership state.

## Change

`src/p01-hardware-transaction.js` now uses `lstatSync` to distinguish missing files from symlinks, requires a single-link regular file, opens it with `O_NOFOLLOW` where supported, and compares `fstatSync` identity to the initial `lstatSync` identity. Failed checks throw a fail-closed COM-admission error without replacing the ledger. No PCM write path was changed.

The guard reduces filesystem redirection and swap risk. It does not establish an interprocess OS lock, eliminate all platform-specific filesystem races, or prove Windows/OBDLink compatibility. Do not manually delete a suspicious ledger until confirming the PCM Hammer child is stopped and preserving the ledger for diagnosis.

## Verification limitations

Regression tests use local temporary files only. Windows clean install, native PCM Hammer CLI/kernel pairing, physical OBDLink COM exclusivity, matching Full Reads, interrupted-read recovery, and checksum/OS-definition validation remain unverified. No ECU Test Write or write was performed.
