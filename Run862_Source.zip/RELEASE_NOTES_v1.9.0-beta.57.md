# TunIQ v1.9.0-beta.57 — Transitive Dependency Lockfile Safety Gate

**Source-only development checkpoint. Not a user-testing build or public release.**

## Reproduced regression

Beta.56 accepted a synthetic npm lockfile with matching direct dependency pins even when one of those dependencies declared a missing transitive package. This could incorrectly clear the dependency-lock launch blocker without a complete dependency tree.

## Correction

`src/launch-readiness.js` now checks the shape of all lockfile package records, rejects untrusted or malformed tarball URLs and package paths, requires SHA-512 integrity metadata for every registry package, and verifies that declared transitive and optional dependencies resolve to locked package entries. Incomplete root dependency objects fail closed without throwing.

This gate only checks lockfile **metadata**. It cannot authenticate actual tarball bytes or prove semver resolution. A trusted registry-generated lockfile, clean Windows `npm ci`, provenance review, installer validation, licensing, secure updates, privacy review, signing, and physical read-only OBDLink/PCM Hammer qualification remain blockers.

## Verification

Linux Node.js automated simulations only. No real PCM Test Write, ECU write, flash, or physical hardware qualification. See the separate test report for executed commands and outcomes.
