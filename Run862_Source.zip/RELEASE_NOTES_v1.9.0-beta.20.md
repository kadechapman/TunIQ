# TunIQ v1.9.0-beta.20 — Blank Intake and Phone Log Quality

- Removed hard-coded calibration requests from the two P01 entry forms.
- Removed auto-generated build notes from new projects, including new P01 service and vehicle-derived projects. Existing saved project notes remain intact in Edit mode.
- Fresh Full AI intake no longer silently chooses a saved Garage engine. Previously saved AI intake remains available when reopening the same project.
- Fixed mobile web CSV parser so blank sensor rows do not become valid zero-valued readings. True zero readings remain valid.
- Added six regression assertions and integrated them into the standard 53-group suite.

**Scope:** Source-level UI and phone-web-importer patch. No native mobile app has been built or validated. PCM Hammer integration remains simulated and hardware-Experimental. No physical Full Read, Test Write, or ECU flash was performed.
