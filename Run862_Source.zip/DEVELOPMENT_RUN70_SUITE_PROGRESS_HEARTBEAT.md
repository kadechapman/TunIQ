# Run70 — Offline test-suite progress diagnostics

This bounded pass addresses incomplete automated-suite evidence observed during Run69. It does not change PCM Hammer, OBD, ECU read/write, calibration, or flash behavior.

## Change

`tools/verify-test-suite.js` now emits periodic, explicitly **NOT VERIFIED** diagnostic heartbeats to stderr while its child suite remains active. Each heartbeat reports elapsed time, time since the last **new required** progress milestone, count of required milestones, success-banner state, and the last completed group. The default interval is 15 seconds; `runSuite` accepts a bounded `diagnosticIntervalMs` option for isolated tests. The heartbeat never refreshes the suite idle deadline, changes the proof counters, or certifies success. Both timers are cleared on settlement.

`tests/verify-test-suite-simulations.js` adds a synthetic child that prints one genuine milestone and then stalls. Assertions confirm intermediate diagnostic output, the retained idle timeout, and rejection of invalid diagnostic intervals. All tests are offline subprocess simulations.

## Limitations

Heartbeats improve visibility; they do not repair or establish the cause of intermittent long-running tests. A printed success banner without an actual successful child exit remains insufficient. Native Windows, physical OBDLink, and real PCM Hammer testing remain unverified. The dependency lockfile and other launch blockers are unchanged. No actual ECU write, flash, or Test Write was executed.
