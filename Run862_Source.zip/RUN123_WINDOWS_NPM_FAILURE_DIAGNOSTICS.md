# TunIQ Run123 — Windows npm failure diagnostics

Run123 closes an offline-preview build diagnostics gap, not a Windows build or ECU feature.

## Reproduced issue

`tools/windows-build-offline-preview.ps1` created a per-run diagnostics directory but invoked npm lockfile generation and `npm ci` without an explicit `--logs-dir`. npm could therefore save the detailed failure log under a user's npm cache rather than alongside the build evidence. `tools/diagnose-windows-preview.js` only classified errors visible in the PowerShell transcript or Electron stderr, so a failure recorded only in npm's debug log fell back to a generic classification.

## Correction

- Both npm commands now use the same per-run `--logs-dir` argument, with existing bounded registry retries and timeouts unchanged.
- The read-only diagnosis tool can classify failures from at most eight latest regular npm debug logs, reading at most 16 KiB from each. It still emits only allowlisted failure codes and fixed remediation guidance, never raw logs, paths or secrets.
- Regression tests require the PowerShell npm log routing, verify actual failed offline npm CLI writes a debug log, and prove DNS classification works when the transcript is empty.

This is a Linux-executed source and npm-fixture check. No PowerShell, native Windows Electron, packaged executable, production tuning app, physical ECU or OBD hardware was used. No ECU read, Test Write, write or flash occurred.

## Owner's LS 5.3 development-test scope

- VATS: exact ECM operating system, BIN, calibration definition and protected original must be verified before any authorized modification.
- Electric fans: controller output enablement and actual relay/fuse wiring must be verified separately from requested on/off thresholds. No target temperatures or pins assumed.
- LSX Stage 2 cam: no physical-cam tune until exact cam card, injectors, valvetrain and baseline logs are available.
- Knock sensors: diagnostics and sensor/wiring compatibility must be reviewed; automatic knock-protection disabling remains blocked.

## Windows operator command (hardware disconnected)

```powershell
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output\Run97-Diagnostics-<guid>\build-outcome.json`, `diagnosis.json`, `windows-build-transcript.txt`, and npm `*-debug-*.log`. Treat logs as potentially private and review before sharing. A passing isolated UI preview does not verify full TunIQ.
