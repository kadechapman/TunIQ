const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return;
    await wait(20);
  }
  throw new Error('Timed out waiting for proven-port pin simulation.');
}

async function runP01ProvenPortPinSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-proven-port-pin-'));
  const project = path.join(root, 'project');
  const portable = path.join(root, 'PCM-Hammer');
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  const executable = path.join(portable, 'PcmHammerCLI');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const active = { id: 'p01-pin', name: 'P01 Pin', folder: project, controller: 'P01', os: '9373372' };
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data'),
    getActiveProject: () => active,
    getToolPath: () => portable,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
    releasePort: async () => ({ released: true }),
    abortBridgeRequests: () => ({ aborted: 0 }),
    appendActivity: () => {},
    emit: () => {},
    onSessionComplete: async () => {}
  });
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  process.env.PCMHAMMER_MOCK_SCENARIO = 'open-failed';
  process.env.PCMHAMMER_MOCK_TIMEOUT_PORT = 'COM4';
  process.env.PCMHAMMER_MOCK_DEVICE_LIST = '0: OBDLink MX+ Incoming (COM3)\n1: Generic Communications Port (COM1)\n2: OBDLink MX+ Outgoing (COM4)';
  await manager.probe({ executable, prefixArgs: [mock] });
  manager.saveConfig({
    device: 'COM4',
    lastSuccessfulDevice: 'COM4',
    lastSuccessfulOperation: 'readProperties',
    lastDeviceCandidates: [
      { port: 'COM4', recognized: true, outgoing: true, recoveryScore: 1000 },
      { port: 'COM3', recognized: true, incoming: true, recoveryScore: 200 },
      { port: 'COM1', recognized: false, recoveryScore: 0 }
    ]
  });

  await manager.start('read', {
    device: 'COM4',
    directPortHandoffAuthorized: true,
    authoritativeProvenPort: true,
    directPortHandoffReason: 'Read Properties already proved COM4 for this exact P01 project.'
  });
  await waitFor(() => !manager.session);
  const history = manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'failed pinned full read must be recorded');
  assert.equal(history.state, 'failed');
  assert.equal(history.device, 'COM4');
  assert.equal(history.portLease?.pinnedProvenPort, true);
  assert.deepEqual(history.deviceAttempts.map(item => item.device), ['COM4'], 'pinned proven port must be attempted exactly once');
  assert.deepEqual(history.deviceCandidates.map(item => item.port), ['COM4'], 'COM1/COM3 must not enter the pinned session');
  assert.equal((history.deviceDiscoveryPasses || []).length, 0, 'pinned session must not rescan alternate ports');
  assert.equal(history.technicalDetails?.pinnedProvenPort, true);
  assert(/will not retry the same port or scan COM1\/alternate ports/i.test((history.log || []).map(item => item.text).join('\n')));

  const flashSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'flash.js'), 'utf8');
  const mainSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  assert(flashSource.includes('!portLease.pinnedProvenPort'));
  assert(mainSource.includes('authoritativeProvenPort: pcmHammerProven'));

  if (!quiet) console.log('✓ Proven P01 port pin: one COM4 attempt, no duplicate retry, no COM1/COM3 fallback (1/1)');
  return { passed: 1, total: 1 };
}

if (require.main === module) runP01ProvenPortPinSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01ProvenPortPinSimulations };
