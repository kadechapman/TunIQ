const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { findLatestProvenPort, sessionProvesCommunication, shouldReuseProof } = require('../src/p01-proven-port');
const { buildBetaProgress } = require('../src/beta-progress');

function runP01ProvenPortReadinessSimulations({ quiet = false } = {}) {
  const projectId = 'p01-service';
  const p01 = { identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' } };
  const history = [
    { id: 'failed-read', projectId, operation: 'read', state: 'failed', device: 'COM3' },
    { id: 'other-project', projectId: 'other', operation: 'readProperties', state: 'complete', device: 'COM8', identity: { controller: 'P01', os: '9373372' } },
    { id: 'properties-ok', projectId, operation: 'readProperties', state: 'complete', device: 'COM4', completedAt: '2026-08-04T00:00:00Z', identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' } }
  ];
  const recovered = findLatestProvenPort({ history, projectId, p01, state: {} });
  assert.equal(recovered.port, 'COM4');
  assert.equal(recovered.sessionId, 'properties-ok');

  const current = findLatestProvenPort({ history, projectId, p01, state: { pcmHammerProvenPort: 'COM6', pcmHammerProvenAt: 'now', provenHardwareSession: { port: 'COM6', projectId, os: '9373372', source: 'guided-state' } } });
  assert.equal(current.port, 'COM6', 'current project proof must outrank historical candidates');

  assert.equal(sessionProvesCommunication({ projectId, operation: 'read', state: 'complete', device: 'COM4', outputValidation: { valid: true } }, { projectId, p01 }), true);
  assert.equal(sessionProvesCommunication({ projectId, operation: 'read', state: 'complete', device: 'COM4', outputValidation: { valid: false } }, { projectId, p01 }), false);
  assert.equal(shouldReuseProof('read', recovered), true);
  assert.equal(shouldReuseProof('testWrite', recovered), true);
  assert.equal(shouldReuseProof('writeCalibration', recovered), false);

  const progress = buildBetaProgress({
    version: '1.9.0-beta.14',
    activeProject: { id: projectId, controller: 'P01', os: '9373372' },
    p01: { ...p01, readPair: { first: { sha256: 'a' } }, dualReadVerified: false, definition: null, testWrite: null },
    flash: { configured: true, integrated: true, lastSuccessfulDevice: 'COM4', lastSuccessfulOperation: 'readProperties' },
    knowledge: { mode: { mode: 'recommend' }, incidentClusterCount: 4, verifiedIncidentCount: 1, projectCount: 2, repairCount: 1 },
    beta: { agreementAccepted: true, queueCount: 0, preferences: { improvementOptIn: false } }
  });
  assert(progress.overall > 0 && progress.overall < 100);
  assert.equal(progress.areas.length, 6);
  assert(progress.nextPriorities.length > 0);
  assert(progress.areas.find(item => item.id === 'p01-commissioning').next.includes('second independent matching read'));

  const root = path.join(__dirname, '..');
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'src', 'renderer', 'index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(root, 'src', 'renderer', 'app.js'), 'utf8');
  assert(main.includes('recoverP01ProvenHardwareSession'));
  assert(main.includes('releaseVirtualAdapterBeforeP01Operation'));
  assert(main.includes('does not rescan alternate COM ports'));
  assert(main.includes('provenHardwareSession'));
  assert(html.includes('id="betaOverallProgress"'));
  assert(html.includes('id="betaProgressGrid"'));
  assert(renderer.includes('function renderBetaProgress'));

  if (!quiet) console.log('✓ P01 proven-port continuity and beta readiness simulations: 8/8 passed');
  return { passed: true, scenarios: 8, overall: progress.overall };
}

if (require.main === module) runP01ProvenPortReadinessSimulations();
module.exports = { runP01ProvenPortReadinessSimulations };
