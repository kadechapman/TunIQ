let state={profile:null,settings:{},tools:{},vehicles:[],projects:[],activity:[],activeProject:null,editingProjectId:null,calibration:null,calHistory:[],workspace:null};let demoTimer=null;
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const CONTROLLER_CATALOG=[
  ['GM OBD-I / Legacy',['1227747','1228746','16168625','16197427','16196395','16188051 LT1','16214399 LT1']],
  ['GM Gen III PCM',['P01','P59','P04','P06','P08','P10','P11','P12']],
  ['GM Gas ECM',['E37','E38','E39','E39A','E40','E55','E60','E67','E69','E77','E78','E80','E82','E84','E88','E90','E92','E92A','E99']],
  ['GM Diesel ECM',['E35A','E35B','E41','E46','E54','E86','E93']],
  ['GM Transmission',['T42','T43','T76','T77','T87','T87A','T93','T93A']],
  ['GM Marine / Industrial',['MEFI-1','MEFI-2','MEFI-3','MEFI-4','MEFI-4B','MEFI-5','MEFI-6','Delphi E67 Marine']],
  ['Holley EFI',['Terminator X','Terminator X Max','Holley HP EFI','Holley Dominator EFI','Sniper EFI','Sniper 2 EFI']],
  ['FuelTech',['FT450','FT550','FT550LITE','FT600','FT700','FT700PLUS']],
  ['Haltech',['Elite 550','Elite 750','Elite 1500','Elite 2000','Elite 2500','Nexus R3','Nexus R5','Nexus VCU']],
  ['MegaSquirt',['MS1','MS2','MS3','MS3X','MS3Pro Mini','MS3Pro EVO','MS3Pro Ultimate','Gold Box']],
  ['AEM',['EMS Series 1','EMS Series 2','Infinity 506','Infinity 508','Infinity 710']],
  ['Ford',['EEC-IV','EEC-V','Spanish Oak','Black Oak','PowerPC','Copperhead','Continental EMS24xx','Bosch MG1 Ford']],
  ['Mopar',['SBEC','JTEC','JTEC+','NGC3','NGC4','GPEC2','GPEC2A','GPEC3','GPEC4','GPEC5']],
  ['Bosch / European',['ME7','MED9','MED17','EDC15','EDC16','EDC17','MG1','MD1','MSD80','MSD81','MEVD17']],
  ['Other / Custom',['Motec M1','Motec M4','Motec M8','Link G4+','Link G4X','ECUMaster EMU Black','MaxxECU Street','MaxxECU Race','Speeduino','Custom / Unknown']]
];
function populateControllerCatalog(){const list=$('#controllerOptions');if(!list)return;list.innerHTML=CONTROLLER_CATALOG.flatMap(([family,items])=>items.map(value=>`<option value="${safe(value)}" label="${safe(family)}"></option>`)).join('')}
const safe=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function showPage(id){$$('.page').forEach(x=>x.classList.toggle('active',x.id===id));$$('.app-sidebar button').forEach(x=>x.classList.toggle('active',x.dataset.page===id));if(id==='sandbox')ensureCalibrationInitialized().catch(showCalibrationFailure);if(['flash','patches','revisions','ai','files'].includes(id))refreshWorkspace(true).catch(()=>{});}
function modeName(v){return v==='full-ai'?'Full AI':v==='manual'?'Manual':'Guided'}
function updateHeader(){const m=state.settings.aiMode||'guided';$('#modeBtn').textContent=modeName(m).toUpperCase();$('#modeSelect').value=m;$('#profileSummary').textContent=state.profile?`${state.profile.name} • ${state.profile.email}`:'Not configured';$('#settingsProfile').textContent=state.profile?`${state.profile.name} — ${state.profile.email}`:'No profile configured';$('#dashMode').textContent=modeName(m);document.body.classList.remove('mode-guided','mode-manual','mode-full-ai');document.body.classList.add(`mode-${m}`);updateModeDescription();updateActiveProject();renderTunePath();}
function updateModeDescription(){const m=$('#modeSelect').value;$('#modeDescription').textContent={guided:'Guided mode explains each step, shows safety checks, and recommends the next action.',manual:'Manual mode keeps prompts minimal and leaves workflow choices to you.','full-ai':'Full AI mode proactively reviews TunIQ project context, suggests next steps, and raises warnings.'}[m]||''}
function updateActiveProject(){const text=state.activeProject?`Active project: ${state.activeProject.name}`:'No active project selected';$('#activeProjectBridge').textContent=text;$('#activeProjectCard').innerHTML=state.activeProject?`<b>● ACTIVE: ${safe(state.activeProject.name)}</b><small>${safe(state.activeProject.vehicle||'No vehicle')} • ${safe(state.activeProject.controller||'Unknown controller')}${state.activeProject.os?` • OS ${safe(state.activeProject.os)}`:''}</small>${state.activeProject.notes?`<p>${safe(state.activeProject.notes)}</p>`:''}<button id="editActiveProject" class="ghost">Edit Active Project</button>`:'No active project';const edit=$('#editActiveProject');if(edit)edit.onclick=()=>beginProjectEdit(state.activeProject);renderWorkspaceStrip();}
const toolsMeta={pcmHammer:{name:'PCM Hammer',icon:'🔨',desc:'Read and write supported GM PCMs',url:'https://github.com/PcmHammer/PcmHammer/releases'},tunerPro:{name:'TunerPro',icon:'📊',desc:'Edit BIN files with XDF definitions',url:'https://www.tunerpro.net/downloadApp.htm'},universalPatcher:{name:'Universal Patcher',icon:'🧩',desc:'Inspect, patch, and generate definitions',url:'https://universalpatcher.net/download/'}};
function renderTools(){
  const container=$('#toolCards');
  container.innerHTML='';
  let count=0;
  for(const key of Object.keys(toolsMeta)){
    const meta=toolsMeta[key],toolPath=typeof state.tools[key]==='string'&&state.tools[key].trim()?state.tools[key]:null;
    if(toolPath)count++;
    const card=document.createElement('article');
    card.className=`tool-card ${toolPath?'found':''}`;
    card.innerHTML=`<div class="tool-icon">${meta.icon}</div><h3>${meta.name}</h3><div class="tool-status ${toolPath?'ok':'bad'}">${toolPath?'● READY':'○ NOT FOUND'}</div><p>${meta.desc}</p><div class="tool-path">${safe(toolPath||'No valid executable path detected')}</div><div class="tool-actions"><button class="download" data-download="${key}">⇩ Download</button><button class="ghost" data-browse="${key}">Browse</button><button class="ghost" data-verify="${key}">Verify</button><button class="launch" data-launch="${key}" ${toolPath?'':'disabled'}>↗ Open Compatibility Mode</button></div>`;
    container.appendChild(card);
  }
  $('#toolCount').textContent=`${count} of 3`;
  $$('[data-download]').forEach(button=>button.onclick=async()=>{
    try{await window.tuniq.openExternal(toolsMeta[button.dataset.download].url)}catch(error){status(error.message,true)}
  });
  $$('[data-browse]').forEach(button=>button.onclick=async()=>{
    try{
      const selected=await window.tuniq.chooseTool(button.dataset.browse);
      if(selected){state.tools[button.dataset.browse]=selected;renderTools();await refreshWorkspace(true);status(`${toolsMeta[button.dataset.browse].name} verified and configured.`)}
    }catch(error){status(error.message,true)}
  });
  $$('[data-verify]').forEach(button=>button.onclick=async()=>{
    const key=button.dataset.verify;
    try{
      const result=await window.tuniq.verifyTool(key);
      state.tools[key]=result.path;
      renderTools();
      await refreshWorkspace(true);
      status(result.valid?`${toolsMeta[key].name} path verified.`:`${toolsMeta[key].name} was not found at the saved path. Use Scan or Browse.`,!result.valid);
    }catch(error){status(error.message,true)}
  });
  $$('[data-launch]').forEach(button=>button.onclick=async()=>{
    const key=button.dataset.launch;
    button.disabled=true;
    try{
      const result=await window.tuniq.launchTool(key);
      state.activity=await window.tuniq.listActivity();
      status(`Launched ${toolsMeta[key].name}.${result.activeProject?` TunIQ attached the session to ${result.activeProject.name}.`:' No active project was attached.'}`);
    }catch(error){
      try{state.tools=await window.tuniq.scanTools();renderTools()}catch{}
      status(error.message,true);
    }finally{
      const current=document.querySelector(`[data-launch="${key}"]`);
      if(current&&state.tools[key])current.disabled=false;
    }
  });
}
function status(t,bad=false){$('#bridgeStatus').textContent=t;$('#bridgeStatus').className=bad?'bad':''}

function formatBytes(value){const n=Number(value)||0;if(n<1024)return `${n} B`;if(n<1024*1024)return `${(n/1024).toFixed(1)} KB`;return `${(n/1024/1024).toFixed(1)} MB`}
function renderWorkspaceStrip(){
  const active=state.workspace?.activeProject||state.activeProject;
  $('#workspaceProject').textContent=active?.name||'No project selected';
  $('#workspaceController').textContent=active?.controller?`${active.controller}${active.os?` / ${active.os}`:''}`:'Not configured';
  $('#workspaceBin').textContent=active?.binInfo?.name||'Not loaded';
  $('#workspaceXdf').textContent=active?.xdfInfo?.name||'Not loaded';
}
function renderTunePath(){
  const panel=$('#tunePathPanel'),steps=state.workspace?.tunePath?.steps||[];
  if(!panel)return;
  const progress=state.workspace?.tunePath?.progress||0;
  $('#tunePathProgress').textContent=`${progress}%`;
  const current=steps.find(step=>step.status==='current');
  $('#tunePathSummary').textContent=current?`Current: ${current.title}`:steps.length?'Required setup complete. Review validation and flash preparation.':'Create or activate a project to begin.';
  $('#tunePathSteps').innerHTML=steps.length?steps.map(step=>`<button class="tune-step ${step.status}" data-tune-step="${safe(step.id)}"><span class="step-star">${step.status==='complete'?'✓':step.status==='locked'?'🔒':'★'}</span><span><strong>${safe(step.title)}</strong><small>${safe(step.description)}</small></span><em>${step.status.toUpperCase()}</em></button>`).join(''):'<p class="muted">Workspace steps are loading…</p>';
  $$('[data-tune-step]').forEach(button=>button.onclick=()=>{const step=steps.find(item=>item.id===button.dataset.tuneStep);if(step)goToTuneStep(step)});
  $$('[data-guide-nav]').forEach(button=>button.classList.toggle('guide-current',button.dataset.guideNav===current?.id||((current?.id==='original'||current?.id==='definition')&&button.dataset.page==='files')));
}
function goToTuneStep(step){showPage(step.page);setTimeout(()=>{const target=document.querySelector(step.target);if(target){target.scrollIntoView({behavior:'smooth',block:'center'});target.classList.remove('guided-target');void target.offsetWidth;target.classList.add('guided-target');setTimeout(()=>target.classList.remove('guided-target'),2400)}},180)}
function renderFlashWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,tool=workspace.integrations?.pcmHammer;
  $('#flashProjectState').textContent=active?'Ready':'Missing';$('#flashProjectDot').className=active?'green':'amber';
  $('#flashBinState').textContent=active?.binInfo?.name||'Missing';$('#flashBinDot').className=active?.bin?'green':'amber';
  $('#flashAdapterState').textContent=tool?.configured?'Configured / native adapter pending':'Not configured';$('#flashToolDot').className=tool?.configured?'green':'amber';
  $('#flashToolState').textContent=tool?.configured?'PCM Hammer found':'PCM Hammer needs setup';
  $('#flashPrepareIdentify').disabled=!active||!active.controller||!tool?.configured;
  $('#flashPrepareRead').disabled=!active||!active.controller||!tool?.configured;
  if(!active)$('#flashConsole').textContent='TunIQ Flash Center ready. Create or activate a project to begin.';
  else if(!tool?.configured)$('#flashConsole').textContent='Configure PCM Hammer in Tool Setup. TunIQ will keep the actual operation inside Flash Center as the native adapter is completed.';
}
function renderPatchWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,tool=workspace.integrations?.universalPatcher;
  $('#patchProjectBadge').textContent=active?.name||'NO PROJECT';
  $('#patchBinState').textContent=active?.binInfo?.sha256?'Fingerprint ready':'Missing';$('#patchBinDot').className=active?.bin?'green':'amber';
  $('#patchToolState').textContent=tool?.configured?'Configured / report adapter pending':'Not configured';$('#patchToolDot').className=tool?.configured?'green':'amber';
  $('#patchFileSummary').innerHTML=active?.binInfo?`<b>${safe(active.binInfo.name)}</b><br>${formatBytes(active.binInfo.size)}<br>SHA-256: ${safe(active.binInfo.sha256)}`:'Import an original BIN to begin.';
  $('#patchAnalyze').disabled=!active?.binInfo;
}
function activityLabel(item){const labels={'project-created':'Project created','project-updated':'Project updated','project-activated':'Project activated','bin-imported':'Original BIN imported','xdf-imported':'XDF imported','xdf-mapping-loaded':'Calibration mapping loaded','bin-exported':'Revision BIN exported','workspace-action-prepared':'Integrated action prepared','calibration-revision':'Calibration snapshot saved','tool-launched':'Compatibility tool launched'};return labels[item.type]||String(item.type||'Activity').replace(/-/g,' ')}
function renderRevisionWorkspace(){
  const workspace=state.workspace||{},files=workspace.files?.revisions||[],activity=workspace.activity||[];
  $('#revisionCount').textContent=`${files.length} file${files.length===1?'':'s'}`;
  $('#revisionList').innerHTML=files.length?files.map(file=>`<article><div><b>${safe(file.name)}</b><small>${formatBytes(file.size)} · ${new Date(file.modifiedAt).toLocaleString()}</small></div><span>${safe((file.extension||'file').replace('.','').toUpperCase())}</span></article>`).join(''):'<p class="muted">No exported revisions yet.</p>';
  $('#workspaceActivity').innerHTML=activity.length?activity.slice(0,30).map(item=>`<article><div><b>${safe(activityLabel(item))}</b><small>${new Date(item.at).toLocaleString()}</small></div><span>${safe(item.details?.name||item.details?.projectName||'')}</span></article>`).join(''):'<p class="muted">No project activity recorded.</p>';
}
function renderAiContext(){const workspace=state.workspace||{},active=workspace.activeProject;$('#aiContext').innerHTML=active?[`Project: ${active.name}`,`Vehicle: ${active.vehicle||'Unassigned'}`,`Controller: ${active.controller||'Unknown'}`,`OS: ${active.os||'Unknown'}`,`BIN: ${active.binInfo?.name||'Missing'}`,`XDF: ${active.xdfInfo?.name||'Missing'}`,`Revisions: ${workspace.files?.revisions?.length||0}`].map(text=>`<span>${safe(text)}</span>`).join(''):'<span>No active project context.</span>'}
async function refreshWorkspace(silent=false){
  try{
    const workspace=await window.tuniq.getWorkspaceSummary();
    state.workspace=workspace;state.activeProject=workspace.activeProject||null;state.tools=workspace.tools||state.tools;
    renderWorkspaceStrip();renderTunePath();renderFlashWorkspace();renderPatchWorkspace();renderRevisionWorkspace();renderAiContext();updateActiveProject();renderTools();
    return workspace;
  }catch(error){if(!silent)status(error.message,true);throw error}
}
async function prepareWorkspaceAction(action){
  const messages={
    'identify-controller':'Controller identification preflight prepared. Confirm ignition state, interface selection, battery support, and controller family before native communication is enabled.',
    'read-original':'Original-read plan prepared. TunIQ will place the result in the protected Originals folder and fingerprint it before any edits are allowed.',
    'analyze-bin':'BIN analysis prepared. The current dev build verifies project identity and fingerprint; Universal Patcher checksum report ingestion is the next adapter milestone.'
  };
  const result=await window.tuniq.planWorkspaceAction({action});
  await refreshWorkspace(true);
  return {result,message:messages[action]||'Action prepared.'};
}
function renderVehicles(){const c=$('#garageContent');$('#projectVehicle').innerHTML='<option value="">Choose a Garage vehicle</option>'+state.vehicles.map(v=>`<option value="${safe(v.name)}">${safe(v.name)}${v.engine?` — ${safe(v.engine)}`:''}</option>`).join('');if(!state.vehicles.length){c.innerHTML='<div class="empty-card"><div class="empty-icon">▣</div><h2>No vehicles saved yet</h2><p>Add the Tahoe, OBS, or any LS-powered project. Vehicle profiles carry into future versions and can be selected in Tune Workflow.</p><button id="garageAdd">Create First Vehicle</button></div>';$('#garageAdd').onclick=()=>openVehicleModal();return}c.innerHTML=`<div class="vehicle-grid">${state.vehicles.map(v=>`<article class="vehicle-card"><div class="vehicle-icon">🚘</div><div><p class="eyebrow">${safe(v.controller||'CONTROLLER UNKNOWN')}</p><h3>${safe(v.name)}</h3><p>${safe([v.year,v.make,v.model].filter(Boolean).join(' ')||'Vehicle details not entered')}</p><div class="vehicle-tags"><span>${safe(v.engine||'Engine unknown')}</span>${v.vin?`<span>VIN saved</span>`:''}</div></div><div class="vehicle-actions"><button class="ghost" data-edit-vehicle="${v.id}">Edit</button><button class="danger-btn" data-delete-vehicle="${v.id}">Delete</button></div></article>`).join('')}</div>`;$$('[data-edit-vehicle]').forEach(b=>b.onclick=()=>openVehicleModal(state.vehicles.find(v=>v.id===b.dataset.editVehicle)));$$('[data-delete-vehicle]').forEach(b=>b.onclick=async()=>{const v=state.vehicles.find(x=>x.id===b.dataset.deleteVehicle);if(confirm(`Delete ${v?.name||'this vehicle'}?`)){await window.tuniq.deleteVehicle(b.dataset.deleteVehicle);state.vehicles=await window.tuniq.listVehicles();renderVehicles()}})}
function openVehicleModal(v=null){$('#vehicleForm').reset();$('#vehicleId').value=v?.id||'';$('#vehicleModalTitle').textContent=v?'Edit Vehicle':'Add Vehicle';for(const [id,key] of [['vehicleYear','year'],['vehicleMake','make'],['vehicleName','name'],['vehicleModel','model'],['vehicleEngine','engine'],['vehicleController','controller'],['vehicleVin','vin'],['vehicleNotes','notes']])$('#'+id).value=v?.[key]||'';$('#vehicleError').textContent='';$('#vehicleModal').classList.remove('hidden')}
function closeVehicleModal(){$('#vehicleModal').classList.add('hidden')}
function offlineAnswer(q){
  const lower=q.toLowerCase();
  const workspace=state.workspace||{};
  const active=workspace.activeProject||state.activeProject;
  const current=workspace.tunePath?.steps?.find(step=>step.status==='current');
  const context=active?` Active TunIQ project: ${active.name}, vehicle ${active.vehicle||'unspecified'}, controller ${active.controller||'unspecified'}${active.os?`, OS ${active.os}`:''}.`:'';
  if(lower.includes('next')||lower.includes('what should i do'))return current?`Your current Tune Path step is <b>${safe(current.title)}</b>. ${safe(current.description)} Open the glowing star beside that step and TunIQ will take you to the correct control.${context}`:`Your required project steps are complete up to the current 1.3 safety lock. Review Patches & Checksums before preparing a flash.${context}`;
  if(lower.includes('file')||lower.includes('loaded')){const bin=active?.binInfo?.name||'no original BIN';const xdf=active?.xdfInfo?.name||'no XDF';return `The shared workspace currently has <b>${safe(bin)}</b> and <b>${safe(xdf)}</b>. Calibration, Patches, Revisions, Flash preparation, and AI context all use this same pair.${context}`}
  if(lower.includes('what')&&lower.includes('tool'))return `TunIQ has recorded ${state.activity.filter(x=>x.type==='tool-launched').length} compatibility-mode tool launches. PCM Hammer, TunerPro, and Universal Patcher setup is visible in Tool Setup, while the 1.3 native workspace is being moved into TunIQ tabs.${context}`;
  if(lower.includes('fuel trim'))return 'Positive fuel trims mean the PCM is adding fuel. Before editing VE or MAF tables, check vacuum leaks, exhaust leaks ahead of the O₂ sensors, fuel pressure, injector data, and MAF cleanliness. Compare both banks: one-bank-only trim usually points to a bank-specific issue.'+context;
  if(lower.includes('fan'))return 'Verify coolant-temperature accuracy first. Use enough separation between fan-on and fan-off temperatures to prevent rapid cycling, confirm thermostat temperature, and verify relay and wiring current capacity.'+context;
  if(lower.includes('knock'))return 'Do not desensitize knock protection first. Verify fuel octane, commanded spark, AFR, coolant temperature, mechanical noise, sensor torque, and harness condition. Log RPM, load, spark, AFR, and knock retard together.'+context;
  if(lower.includes('injector'))return 'Injector tuning needs flow rate versus pressure, offset versus voltage, short-pulse adder, and minimum pulse data. A single lb/hr value is not enough for accurate idle and transient fueling.'+context;
  if(lower.includes('p01')||lower.includes('p59'))return 'P01 and P59 are common Gen III GM PCMs. Support depends on the exact operating system and hardware ID. Preserve a verified original BIN before editing, and match the XDF to the operating system—not just the vehicle year.'+context;
  return `Offline AI now follows TunIQ's active project, controller, OS, BIN, XDF, Tune Path, revision files, and recent project actions.${context} Live vehicle values and direct flashing actions are still being connected behind controlled native adapters.`
}
function resetProjectForm(){
  state.editingProjectId=null;
  $('#projectForm').reset();
  $('#projectId').value='';
  $('#projectFormTitle').textContent='New Project';
  $('#projectFormMode').textContent='CREATE';
  $('#projectSubmit').textContent='＋ Create Protected Project';
  $('#projectCancelEdit').classList.add('hidden');
  $('#projectFormStatus').textContent='New projects receive protected Originals, Definitions, Revisions, Logs, and Backups folders.';
}
function beginProjectEdit(project){
  if(!project)return;
  state.editingProjectId=project.id;
  $('#projectId').value=project.id||'';
  $('#projectName').value=project.name||'';
  $('#projectVehicle').value=project.vehicle||'';
  $('#projectController').value=project.controller||'';
  $('#projectOs').value=project.os||'';
  $('#projectNotes').value=project.notes||'';
  $('#projectFormTitle').textContent='Edit Project';
  $('#projectFormMode').textContent='EDITING';
  $('#projectSubmit').textContent='Save Project Changes';
  $('#projectCancelEdit').classList.remove('hidden');
  $('#projectFormStatus').textContent='Saving updates changes the project manifest only. Existing BINs, XDFs, logs, backups, and revisions stay in place.';
  showPage('workflow');
  $('#projectName').focus();
}
async function loadProjects(){
  const items=await window.tuniq.listProjects();
  state.projects=Array.isArray(items)?items:[];
  $('#projectCount').textContent=`${state.projects.length} saved`;
  $('#projects').innerHTML=state.projects.length?state.projects.map(project=>`<article class="project-card"><div class="project-card-main"><b>⚙ ${safe(project.name)}</b><p>${safe(project.vehicle||'No vehicle')} • ${safe(project.controller||'Controller unknown')}${project.os?` • OS ${safe(project.os)}`:''}</p>${project.notes?`<small class="project-notes">${safe(project.notes)}</small>`:''}<small>${project.updatedAt?`Updated ${new Date(project.updatedAt).toLocaleString()}`:project.createdAt?new Date(project.createdAt).toLocaleString():'Date unavailable'}</small></div><div class="project-card-actions"><button class="edit-project ghost" data-project-id="${safe(project.id)}">Edit</button><button class="activate-project ghost" data-project-id="${safe(project.id)}">${state.activeProject?.id===project.id?'✓ Active':'Set Active'}</button></div></article>`).join(''):'<div class="empty-card compact"><div class="empty-icon">⚙</div><h3>No projects yet</h3><p>Create one on the left. TunIQ will build protected Originals, Definitions, Revisions, Logs, and Backups folders.</p></div>';
  $$('.edit-project').forEach(button=>button.onclick=()=>beginProjectEdit(state.projects.find(project=>project.id===button.dataset.projectId)));
  $$('.activate-project').forEach(button=>button.onclick=async()=>{
    try{
      state.activeProject=await window.tuniq.setActiveProject(button.dataset.projectId);
      updateActiveProject();
      await loadProjects();
      await refreshProjectFiles();
      invalidateCalibration('The active project changed. Load its BIN and XDF before editing or exporting.');
      status(`Active project set to ${state.activeProject.name}. Every tuning workspace tab now uses this project.`);
      await refreshWorkspace(true);
    }catch(error){status(error.message,true)}
  });
}



let calSelection=new Set(),calAnchor=null,calUndo=[],calRedo=[],calClipboard=[];
let calibrationInitialized=false,calibrationInitializing=null,calibrationControlsBound=false;
function clone(v){return JSON.parse(JSON.stringify(v))}
function calKey(r,c){return `${r}:${c}`}
function currentCal(){return state.calibration?.tables?.[state.calibration.activeTable]||null}
function normalizeCalibration(workspace){
  if(!workspace||typeof workspace!=='object'||!workspace.tables||typeof workspace.tables!=='object')throw new Error('Calibration workspace is missing or invalid.');
  const keys=Object.keys(workspace.tables);
  if(!keys.length)throw new Error('Calibration workspace does not contain any tables.');
  if(!workspace.activeTable||!workspace.tables[workspace.activeTable])workspace.activeTable=keys[0];
  workspace.modified=workspace.modified&&typeof workspace.modified==='object'?workspace.modified:{};
  workspace.stock=workspace.stock&&typeof workspace.stock==='object'?workspace.stock:clone(workspace.tables);
  for(const key of keys){
    const table=workspace.tables[key];
    if(!table||!Array.isArray(table.values)||!table.values.length)throw new Error(`Calibration item ${key} does not contain a readable value grid.`);
    if(table.values.length>256)throw new Error(`Calibration item ${key} exceeds the supported 256-row display limit.`);
    const columns=Array.isArray(table.values[0])?table.values[0].length:0;
    if(!columns||columns>256)throw new Error(`Calibration item ${key} has an unsupported column count.`);
    table.values=table.values.map(row=>{
      if(!Array.isArray(row)||row.length!==columns)throw new Error(`Calibration item ${key} contains a non-rectangular value grid.`);
      return row.map(value=>{const numeric=Number(value);if(!Number.isFinite(numeric))throw new Error(`Calibration item ${key} contains a non-numeric value.`);return numeric});
    });
    table.rowHeaders=Array.isArray(table.rowHeaders)&&table.rowHeaders.length===table.values.length?table.rowHeaders:table.values.map((_,i)=>String(i));
    table.colHeaders=Array.isArray(table.colHeaders)&&table.colHeaders.length===columns?table.colHeaders:Array.from({length:columns},(_,i)=>String(i));
  }
  return workspace;
}
function pushCalUndo(){if(!state.calibration)return;calUndo.push(clone(state.calibration));if(calUndo.length>30)calUndo.shift();calRedo=[]}
function markModified(tableKey,r,c){const table=state.calibration?.tables?.[tableKey];if(!table)return;const stock=state.calibration.stock?.[tableKey]?.values?.[r]?.[c];const value=table.values?.[r]?.[c];const key=`${tableKey}:${r}:${c}`;if(Number(value)===Number(stock))delete state.calibration.modified[key];else state.calibration.modified[key]=true}
function validateCalibration(){const table=currentCal(),el=$('#labValidation');if(!table){el.textContent='⚠ No table loaded';el.className='validation-bad';return false}let invalid=0;const min=Number(table.min),max=Number(table.max),hasMin=table.min!==null&&table.min!==undefined&&table.min!==''&&Number.isFinite(min),hasMax=table.max!==null&&table.max!==undefined&&table.max!==''&&Number.isFinite(max);for(const row of table.values)for(const value of row){const numeric=Number(value);if(!Number.isFinite(numeric)||(hasMin&&numeric<min)||(hasMax&&numeric>max))invalid++}const range=hasMin||hasMax?` (${hasMin?min:'−∞'}–${hasMax?max:'∞'})`:'';el.textContent=invalid?`⚠ ${invalid} invalid value${invalid===1?'':'s'}${range}`:'✓ Values within defined range';el.className=invalid?'validation-bad':'validation-ok';return invalid===0}
async function persistCalibration(){if(!state.calibration)return;state.calibration=normalizeCalibration(await window.tuniq.saveCalibration(state.calibration));$('#labSaveState').textContent=`Saved ${new Date().toLocaleTimeString()}`}
function renderCalTables(){const list=$('#calTableList');if(!state.calibration){list.innerHTML='<p class="muted">Open the Calibration Lab to load tables.</p>';return}const active=state.calibration.activeTable,entries=Object.entries(state.calibration.tables),visible=entries.slice(0,500);list.innerHTML=visible.map(([key,t])=>{const rows=Array.isArray(t.values)?t.values.length:0,cols=rows&&Array.isArray(t.values[0])?t.values[0].length:0;return `<button class="cal-table-btn ${key===active?'active':''}" data-cal-table="${safe(key)}"><span>${safe(t.name||key)}</span><small>${rows} × ${cols}</small></button>`}).join('')+(entries.length>visible.length?`<p class="muted">Showing the first ${visible.length} of ${entries.length} mappings. A searchable mapping browser is next.</p>`:'');$$('[data-cal-table]').forEach(b=>b.onclick=()=>{state.calibration.activeTable=b.dataset.calTable;calSelection.clear();calAnchor=null;renderCalibration()})}
function renderCalGrid(){
  const table=currentCal(),grid=$('#calGrid');
  if(!table){grid.innerHTML='<tbody><tr><td style="padding:24px">No calibration table is loaded.</td></tr></tbody>';return}
  $('#labTableTitle').textContent=table.name||'Calibration Table';
  $('#labUnit').textContent=table.unit||'TABLE';
  let html='<thead><tr><th class="corner">Row / Axis</th>'+table.colHeaders.map(value=>`<th>${safe(value)}</th>`).join('')+'</tr></thead><tbody>';
  table.values.forEach((row,r)=>{
    html+=`<tr><th>${safe(table.rowHeaders[r]??r)}</th>`+row.map((value,c)=>{
      const selected=calSelection.has(calKey(r,c));
      const modified=state.calibration.modified[`${state.calibration.activeTable}:${r}:${c}`];
      return `<td><input class="cal-cell ${selected?'selected':''} ${modified?'modified':''}" data-r="${r}" data-c="${c}" type="number" step="0.01" value="${safe(value)}"></td>`;
    }).join('')+'</tr>';
  });
  grid.innerHTML=html+'</tbody>';
  $$('.cal-cell').forEach(cell=>{
    cell.onmousedown=event=>selectCalCell(event.target,event.shiftKey);
    cell.onfocus=event=>{
      const key=calKey(+event.target.dataset.r,+event.target.dataset.c);
      if(!calSelection.has(key))selectCalCell(event.target,false);
    };
    cell.onchange=async event=>{
      const value=Number(event.target.value);
      if(!Number.isFinite(value)){event.target.value=currentCal().values[+event.target.dataset.r][+event.target.dataset.c];return}
      pushCalUndo();
      const r=+event.target.dataset.r,c=+event.target.dataset.c;
      currentCal().values[r][c]=value;
      markModified(state.calibration.activeTable,r,c);
      validateCalibration();
      renderCalGrid();
      updateCalCount();
      try{await persistCalibration()}catch(error){showCalibrationFailure(error)}
    };
  });
  validateCalibration();
}
function selectCalCell(cell,extend=false){const r=+cell.dataset.r,c=+cell.dataset.c;if(!extend||!calAnchor){calSelection.clear();calAnchor={r,c};calSelection.add(calKey(r,c))}else{calSelection.clear();for(let rr=Math.min(r,calAnchor.r);rr<=Math.max(r,calAnchor.r);rr++)for(let cc=Math.min(c,calAnchor.c);cc<=Math.max(c,calAnchor.c);cc++)calSelection.add(calKey(rr,cc))}$$('.cal-cell').forEach(x=>x.classList.toggle('selected',calSelection.has(calKey(+x.dataset.r,+x.dataset.c))))}
function updateCalCount(){const count=Object.keys(state.calibration?.modified||{}).length;$('#labModifiedCount').textContent=`${count} modified`}
function renderCalHistory(){const items=state.calHistory||[];$('#calHistory').innerHTML=items.length?items.slice(0,8).map(x=>`<article><b>${safe(x.name)}</b><small>${new Date(x.at).toLocaleString()}</small></article>`).join(''):'<p class="muted">No saved revisions yet.</p>'}
function renderCalibration(){
  if(!state.calibration)return;
  normalizeCalibration(state.calibration);
  renderCalTables();
  renderCalGrid();
  updateCalCount();
  renderCalHistory();
  const isXdf=state.calibration.mode==='xdf';
  const sameProject=!isXdf||!state.calibration.projectId||state.calibration.projectId===state.activeProject?.id;
  $('#labSourceBadge').textContent=isXdf?(sameProject?'XDF MAPPED':'OTHER PROJECT WORKSPACE'):'LOCAL WORKSPACE';
  $('#labSourceBadge').classList.toggle('source-warning',!sameProject);
  $('#labExportBin').disabled=!isXdf||!sameProject;
  const summary=state.calibration.mappingSummary;
  if(!sameProject)$('#labSaveState').textContent='Reload BIN + XDF for the active project before exporting';
  else if(summary&&summary.skipped)$('#labSaveState').textContent=`Loaded ${summary.loaded}; ${summary.skipped} oversized mappings skipped for stability`;
}
function invalidateCalibration(message='Reload the active project BIN and XDF to continue.'){
  calibrationInitialized=false;
  calibrationInitializing=null;
  state.calibration=null;
  calSelection.clear();calAnchor=null;calUndo.length=0;calRedo.length=0;
  $('#labSourceBadge').textContent='RELOAD REQUIRED';
  $('#labSourceBadge').classList.add('source-warning');
  $('#labExportBin').disabled=true;
  $('#labTableTitle').textContent='Calibration workspace needs reloading';
  $('#labUnit').textContent='PROJECT CHANGED';
  $('#labValidation').textContent='⚠ Reload BIN + XDF';
  $('#labValidation').className='validation-bad';
  $('#calTableList').innerHTML='<p class="muted">No active mapping loaded.</p>';
  $('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal">${safe(message)}</td></tr></tbody>`;
  $('#labModifiedCount').textContent='0 modified';
}
function showCalibrationFailure(error){console.error(error);$('#labTableTitle').textContent='Calibration recovery mode';$('#labUnit').textContent='STARTUP PROTECTED';$('#labValidation').textContent='⚠ Workspace could not be loaded';$('#labValidation').className='validation-bad';$('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal"><b>TunIQ stayed open.</b><br>${safe(error?.message||error)}<br><br>The original workspace is preserved in AppData if recovery was required.</td></tr></tbody>`}
async function applyCalOperation(){if(!calSelection.size)return alert('Select one or more cells first.');const table=currentCal();if(!table)return;const amount=Number($('#labAmount').value);if(!Number.isFinite(amount))return;pushCalUndo();const op=$('#labOperation').value;for(const key of calSelection){const [r,c]=key.split(':').map(Number);let v=Number(table.values[r][c]);if(op==='add')v+=amount;if(op==='subtract')v-=amount;if(op==='multiply')v*=amount;if(op==='percent')v*=1+amount/100;table.values[r][c]=Number(v.toFixed(3));markModified(state.calibration.activeTable,r,c)}renderCalibration();await persistCalibration()}
function bindCalibrationControls(){
  if(calibrationControlsBound)return;
  calibrationControlsBound=true;
  $('#labApply').onclick=()=>applyCalOperation().catch(error=>alert(error.message));
  $('#labUndo').onclick=async()=>{try{if(!calUndo.length)return;calRedo.push(clone(state.calibration));state.calibration=calUndo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labRedo').onclick=async()=>{try{if(!calRedo.length)return;calUndo.push(clone(state.calibration));state.calibration=calRedo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labCopy').onclick=()=>{
    const table=currentCal();if(!table||!calSelection.size)return;
    calClipboard=[...calSelection].map(key=>{const [r,c]=key.split(':').map(Number);return table.values[r][c]});
    navigator.clipboard?.writeText(calClipboard.join('\t')).catch(()=>{});
  };
  $('#labPaste').onclick=async()=>{try{
    const table=currentCal();if(!table||!calSelection.size||!calClipboard.length)return;
    pushCalUndo();let index=0;
    for(const key of calSelection){const [r,c]=key.split(':').map(Number);table.values[r][c]=Number(calClipboard[index%calClipboard.length]);markModified(state.calibration.activeTable,r,c);index++}
    renderCalibration();await persistCalibration();
  }catch(error){alert(error.message)}};
  $('#labSaveRevision').onclick=async()=>{try{
    if(!state.calibration)return;
    const name=prompt('Revision name',`Revision ${(state.calHistory||[]).length+1}`);if(!name)return;
    await persistCalibration();await window.tuniq.createCalibrationRevision({name});state.calHistory=await window.tuniq.listCalibrationHistory();renderCalHistory();
  }catch(error){alert(error.message)}};
  $('#labReset').onclick=async()=>{try{
    if(!state.calibration)return;
    const label=state.calibration.mode==='xdf'?'original imported BIN values':'stock practice values';
    if(!confirm(`Reset every calibration table to the ${label}?`))return;
    pushCalUndo();
    if(state.calibration.mode==='xdf'){
      state.calibration.tables=clone(state.calibration.stock);
      state.calibration.modified={};
      state.calibration.activeTable=Object.keys(state.calibration.tables)[0];
      await persistCalibration();
    }else{
      state.calibration=normalizeCalibration(await window.tuniq.resetCalibration());
    }
    calSelection.clear();calAnchor=null;renderCalibration();
  }catch(error){alert(error.message)}};
}
async function initCalibration(){bindCalibrationControls();state.calibration=normalizeCalibration(await window.tuniq.loadCalibration());state.calHistory=await window.tuniq.listCalibrationHistory();state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];renderCalibration();calibrationInitialized=true}
async function ensureCalibrationInitialized(){if(calibrationInitialized)return state.calibration;if(calibrationInitializing)return calibrationInitializing;$('#labTableTitle').textContent='Loading calibration workspace…';calibrationInitializing=initCalibration().finally(()=>{calibrationInitializing=null});return calibrationInitializing}

async function refreshProjectFiles(){
  const card=$('#projectFilesCard');
  if(!card)return;
  try{
    const files=await window.tuniq.getProjectFiles();
    state.activeProject=files.active||null;
    updateActiveProject();
    if(!files.active){
      card.className='empty-card compact';
      card.innerHTML='<div class="empty-icon">▤</div><h2>No active project</h2><p>Create or activate a project before importing a BIN or XDF.</p><button id="filesGoWorkflow">Go to Tune Workflow</button>';
      $('#filesGoWorkflow').onclick=()=>showPage('workflow');
      return;
    }
    const binHash=files.bin?.sha256?`${safe(files.bin.sha256.slice(0,16))}…`:'Unavailable';
    const xdfDetail=files.xdf?.error?`Definition warning: ${safe(files.xdf.error)}`:`${Number(files.xdf?.tableCount||0).toLocaleString()} mapped items · ${safe(files.xdf?.title||'')}`;
    card.className='panel project-files';
    card.innerHTML=`<div class="panel-title"><h3>${safe(files.active.name)}</h3><span>${safe(files.active.controller||'Controller unknown')}</span></div><div class="file-status-row"><div><b>Original BIN</b><span>${files.bin?safe(files.bin.name):'Not imported'}</span>${files.bin?`<small>${Number(files.bin.size||0).toLocaleString()} bytes · SHA-256 ${binHash}</small>`:''}</div><i class="${files.bin?'green':'amber'}"></i></div><div class="file-status-row"><div><b>TunerPro XDF</b><span>${files.xdf?safe(files.xdf.name):'Not imported'}</span>${files.xdf?`<small>${xdfDetail}</small>`:''}</div><i class="${files.xdf&&!files.xdf.error?'green':'amber'}"></i></div>${files.bin&&files.xdf&&!files.xdf.error?'<button id="filesLoadLab">Open Mapping in Calibration Lab</button>':''}`;
    const openButton=$('#filesLoadLab');
    if(openButton)openButton.onclick=loadRealCalibration;
  }catch(error){
    card.className='empty-card compact';
    card.innerHTML=`<div class="empty-icon">⚠</div><h2>Project files unavailable</h2><p>${safe(error.message)}</p>`;
  }
}
async function loadRealCalibration(){
  try{
    bindCalibrationControls();
    $('#labTableTitle').textContent='Loading BIN + XDF mapping…';
    state.calibration=normalizeCalibration(await window.tuniq.loadXdfCalibration());
    state.calHistory=await window.tuniq.listCalibrationHistory();
    state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];
    calibrationInitialized=true;
    calUndo.length=0;calRedo.length=0;calSelection.clear();calAnchor=null;
    renderCalibration();
    await refreshWorkspace(true);
    showPage('sandbox');
    const summary=state.calibration.mappingSummary;
    status(`Loaded ${Object.keys(state.calibration.tables).length} XDF items from ${state.activeProject?.name||'the active project'}.${summary?.skipped?` ${summary.skipped} oversized items were skipped for stability.`:''}`);
  }catch(error){
    showCalibrationFailure(error);
    alert(error.message);
  }
}



async function init(){
  if(!window.tuniq)throw new Error('TunIQ desktop bridge did not load. Run the startup recovery file and try again.');
  state=await window.tuniq.getBootstrap();
  state.vehicles=Array.isArray(state.vehicles)?state.vehicles:[];
  state.activity=Array.isArray(state.activity)?state.activity:[];
  state.tools=state.tools&&typeof state.tools==='object'?state.tools:{};
  state.settings=state.settings&&typeof state.settings==='object'?state.settings:{};
  state.activeProject=state.activeProject||null;
  $('#version').textContent=`v${state.version}`;
  $('#dataRoot').textContent=state.dataRoot;
  populateControllerCatalog();renderTools();renderVehicles();updateHeader();bindCalibrationControls();
  await loadProjects();
  await refreshProjectFiles();
  await refreshWorkspace(true);
  setTimeout(()=>{
    $('#splash').classList.add('hidden');
    $('#app').classList.remove('hidden');
    if(!state.profile||!state.settings.aiMode)$('#wizard').classList.remove('hidden');
  },300);
}
$$('.app-sidebar button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));$$('[data-jump]').forEach(b=>b.onclick=()=>showPage(b.dataset.jump));$('#modeBtn').onclick=()=>showPage('settings');$('#openData').onclick=()=>window.tuniq.openDataFolder();
$('#wizardForm').onsubmit=async e=>{e.preventDefault();try{const aiMode=$('input[name="aiMode"]:checked').value;const result=await window.tuniq.saveProfile({name:$('#name').value,email:$('#email').value,units:$('#units').value,aiMode});state.profile=result.profile;state.settings=result.settings;updateHeader();$('#wizard').classList.add('hidden')}catch(err){$('#wizardError').textContent=err.message}};
$('#resetWizard').onclick=()=>{$('#name').value=state.profile?.name||'';$('#email').value=state.profile?.email||'';$('#units').value=state.settings.units||'US';const r=$(`input[name="aiMode"][value="${state.settings.aiMode||'guided'}"]`);if(r)r.checked=true;$('#wizard').classList.remove('hidden')};
$('#modeSelect').onchange=async()=>{state.settings=await window.tuniq.setAiMode($('#modeSelect').value);updateHeader();renderTunePath()};
$('#scanTools').onclick=async event=>{const button=event.currentTarget;button.disabled=true;status('Scanning common install folders, LocalAppData, Desktop, and Downloads...');try{state.tools=await window.tuniq.scanTools();renderTools();await refreshWorkspace(true);const found=Object.values(state.tools).filter(Boolean).length;status(`Scan complete: ${found} of 3 tools ready. Use Browse for any portable copy TunIQ did not find.`)}catch(e){status(e.message,true)}finally{button.disabled=false}};
async function exportDiag(){try{const p=await window.tuniq.exportDiagnostics();status(`Diagnostics saved to:\n${p}`);$('#diagText').textContent=`Latest report:\n${p}`}catch(e){status(e.message,true)}}$('#exportDiag').onclick=exportDiag;$('#diagExport2').onclick=exportDiag;
$('#projectForm').onsubmit=async e=>{
  e.preventDefault();
  const payload={id:$('#projectId').value||null,name:$('#projectName').value,vehicle:$('#projectVehicle').value,controller:$('#projectController').value,os:$('#projectOs').value,notes:$('#projectNotes').value};
  $('#projectSubmit').disabled=true;
  try{
    if(payload.id){
      const updated=await window.tuniq.updateProject(payload);
      if(updated.active)state.activeProject=updated.active;
      await loadProjects();
      updateActiveProject();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      $('#projectFormStatus').textContent=`Saved ${updated.name}. Project files and revision history were preserved.`;
      status(`Updated project ${updated.name}.`);
      beginProjectEdit(updated.active||updated);
    }else{
      const created=await window.tuniq.createProject(payload);
      state.activeProject=created.active||await window.tuniq.setActiveProject(created.id);
      resetProjectForm();
      await loadProjects();
      updateActiveProject();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      invalidateCalibration('A new project is active. Import and load its BIN and XDF before editing.');
      status(`Created and activated ${state.activeProject.name}. Import its original BIN and matching XDF next.`);
      showPage('files');
    }
  }catch(err){
    $('#projectFormStatus').textContent=err.message;
    alert(err.message);
  }finally{$('#projectSubmit').disabled=false}
};
$('#projectCancelEdit').onclick=resetProjectForm;
$('#newProjectTop').onclick=resetProjectForm;
$('#projectVehicle').onchange=()=>{const vehicle=state.vehicles.find(item=>item.name===$('#projectVehicle').value);if(vehicle?.controller&&!$('#projectController').value.trim())$('#projectController').value=vehicle.controller};
$('#vehicleForm').onsubmit=async e=>{e.preventDefault();try{await window.tuniq.saveVehicle({id:$('#vehicleId').value||null,year:$('#vehicleYear').value,make:$('#vehicleMake').value,name:$('#vehicleName').value,model:$('#vehicleModel').value,engine:$('#vehicleEngine').value,controller:$('#vehicleController').value,vin:$('#vehicleVin').value,notes:$('#vehicleNotes').value});state.vehicles=await window.tuniq.listVehicles();renderVehicles();closeVehicleModal()}catch(err){$('#vehicleError').textContent=err.message}};$('#addVehicleBtn').onclick=()=>openVehicleModal();$('#cancelVehicle').onclick=closeVehicleModal;
$('#demoToggle').onclick=()=>{if(demoTimer){clearInterval(demoTimer);demoTimer=null;$('#demoToggle').textContent='▶ Start Demo';$('#scanState').textContent='IGNITION OFF';$('#scanDot').style.background='#71837b';return}$('#demoToggle').textContent='■ Stop Demo';$('#scanState').textContent='ENGINE RUNNING';$('#scanDot').style.background='#62f1b1';let t=0;demoTimer=setInterval(()=>{t+=.18;$('#rpm').textContent=Math.round(780+Math.max(0,Math.sin(t))*2600+Math.random()*80);$('#ect').textContent=Math.round(Math.min(205,70+t*2));$('#tps').textContent=Math.round(Math.max(0,Math.sin(t))*64);$('#volt').textContent=(13.7+Math.sin(t/2)*.25).toFixed(1);$('#stft').textContent=(Math.sin(t*1.3)*4.5).toFixed(1);$('#kr').textContent=(Math.random()>.94?Math.random()*2.2:0).toFixed(1);$('#dtcCount').textContent=t>35&&t<45?'1':'0'},350)};
function ask(q){if(!q)return;$('#messages').insertAdjacentHTML('beforeend',`<div class="msg user">${safe(q)}</div>`);setTimeout(()=>{$('#messages').insertAdjacentHTML('beforeend',`<div class="msg ai"><b>✦ TunIQ Coach</b><br>${offlineAnswer(q)}</div>`);$('#messages').scrollTop=$('#messages').scrollHeight},state.settings.aiMode==='manual'?250:650)}
$('#aiForm').onsubmit=e=>{e.preventDefault();const q=$('#aiInput').value.trim();$('#aiInput').value='';ask(q)};$$('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
$('#importBin').onclick=async()=>{try{
  const result=await window.tuniq.importBin();
  if(result){invalidateCalibration('The original BIN changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported protected original ${result.name}. Load BIN + XDF again before exporting.`)}
}catch(error){alert(error.message)}};
$('#importXdf').onclick=async()=>{try{
  const result=await window.tuniq.importXdf();
  if(result){invalidateCalibration('The XDF changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported ${result.name} with ${result.tableCount} mapped items. Open the mapping in Calibration Lab to verify it.`)}
}catch(error){alert(error.message)}};
$('#openProjectFolder').onclick=async()=>{try{await window.tuniq.openProjectFolder()}catch(error){alert(error.message)}};
$('#workspaceRefresh').onclick=()=>refreshWorkspace().catch(error=>alert(error.message));
$('#tunePathToggle').onclick=()=>$('#tunePathPanel').classList.toggle('collapsed');
$('#flashGoTools').onclick=()=>showPage('bridge');
$('#flashPrepareIdentify').onclick=async()=>{try{const {message,result}=await prepareWorkspaceAction('identify-controller');$('#flashSessionState').textContent='PREFLIGHT READY';$('#flashConsole').textContent=`[${new Date(result.at).toLocaleTimeString()}] ${message}\n\nProject: ${result.projectName}\nController: ${result.controller||'Not entered'}\nOS: ${result.os||'Not entered'}\n\nNo controller command was sent in dev.1.`}catch(error){$('#flashSessionState').textContent='BLOCKED';$('#flashConsole').textContent=error.message}};
$('#flashPrepareRead').onclick=async()=>{try{const {message,result}=await prepareWorkspaceAction('read-original');$('#flashSessionState').textContent='READ PLAN READY';$('#flashConsole').textContent=`[${new Date(result.at).toLocaleTimeString()}] ${message}\n\nDestination: Active Project / Originals\nController: ${result.controller||'Not entered'}\n\nDirect PCM reading remains locked until the native adapter validates communication and recovery behavior.`}catch(error){$('#flashSessionState').textContent='BLOCKED';$('#flashConsole').textContent=error.message}};
$('#patchAnalyze').onclick=async()=>{try{const {result}=await prepareWorkspaceAction('analyze-bin');const active=state.workspace?.activeProject;$('#patchConsole').textContent=`Analysis preflight recorded ${new Date(result.at).toLocaleString()}.\n\nProject: ${result.projectName}\nController: ${result.controller||'Not entered'}\nOS: ${result.os||'Not entered'}\nBIN: ${active?.binInfo?.name||'No original BIN attached'}\nSHA-256: ${active?.binInfo?.sha256||'Unavailable'}\n\nNative Universal Patcher checksum-report ingestion is the next adapter milestone. No BIN bytes were changed.`}catch(error){$('#patchConsole').textContent=error.message}};
$('#openRevisionsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('revisions')}catch(error){alert(error.message)}};
$('#openLogsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('logs')}catch(error){alert(error.message)}};
$('#labLoadXdf').onclick=loadRealCalibration;
$('#labExportBin').onclick=async()=>{try{
  if(state.calibration?.mode!=='xdf')throw new Error('Load a BIN and XDF mapping first.');
  if(state.calibration.projectId!==state.activeProject?.id)throw new Error('Reload the BIN and XDF for the active project before exporting.');
  if(!validateCalibration())throw new Error('Fix out-of-range values before exporting.');
  await persistCalibration();
  const result=await window.tuniq.exportBin(state.calibration);
  alert(`Revision BIN exported safely:\n${result.path}\n\nModified cells: ${result.modifiedCells}\nSHA-256: ${result.sha256}`);
  await refreshProjectFiles();
  await refreshWorkspace(true);
}catch(error){alert(error.message)}};
init().catch(e=>{document.body.innerHTML=`<pre style="padding:30px;color:#ffb18d">Startup error: ${safe(e.stack||e.message)}</pre>`});
