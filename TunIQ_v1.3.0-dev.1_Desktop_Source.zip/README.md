# TunIQ v1.3.0-dev.1

Built directly on `v1.2.2-dev.10` while preserving all data stored in `%APPDATA%\TunIQ`.

## What changed in the first 1.3 build

- Added a unified project bar shared across every tuning page.
- Added native TunIQ pages for Flash, Calibration, Patches, Scanner, and Logs & Revisions.
- Added the Guided Mode Tune Path panel with glowing current-step stars.
- Tune Path steps open the correct page, scroll to the correct control, and highlight it.
- Added project-aware Flash and Universal Patcher integration foundations without opening another program window.
- Added a shared workspace summary containing the active project, controller, OS, BIN, XDF, revisions, logs, tools, calibration state, and recent activity.
- Added project-aware AI context and “What should I do next?” guidance.
- Kept PCM Hammer, TunerPro, and Universal Patcher external launching only under Tool Setup as Compatibility Mode.
- Preserved the dev.10 Garage, project editor, 129-controller catalog, BIN/XDF mapping, calibration editing, and revision export.

## Current integration status

The user-facing workspace is now inside TunIQ, but direct PCM Hammer communication and Universal Patcher checksum/patch execution are intentionally locked in this first 1.3 development build. The native pages prepare and record operations without sending controller commands or changing BIN bytes.

TunerPro-compatible XDF/BIN editing continues natively in Calibration. External application launching remains available only as a fallback from Tool Setup.

## Safety limits

- Direct PCM writing is locked.
- Flash preparation does not send commands to a controller.
- Patch analysis does not change BIN bytes.
- Protected original BIN files are never overwritten.
- Exported revision BINs should still be independently verified before flashing.

## Windows

1. Extract the complete ZIP into a new local folder.
2. Run `INSTALL_AND_RUN_WINDOWS.bat` once.
3. Use `START_TUNIQ_WINDOWS.bat` afterward.
4. Existing projects and settings remain in `%APPDATA%\TunIQ`.

See `README_DEV13.md` for the exact 1.3 milestone details.
