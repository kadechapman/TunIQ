# TunIQ v1.9.0-beta.78 — Reconciled Read Evidence Safety

Source-only checkpoint rebased on the independently verified beta.77 read-only assisted evidence gate.

- Retains beta.77's fail-closed restriction on untrusted assisted GUI BIN/log imports in read-only mode; integrated read-only CLI remains unchanged.
- Prevents reconstruction of a verified P01 read pair from two matching disk-only filenames when saved session evidence was lost.
- Requires different read sessions and different physical output files (including hardlink identity checks), and verifies the first file's SHA-256 again before accepting the second.
- Keeps saved, digest-matched session ledger recovery available when only the read-pair pointer was damaged.
- New filesystem-only regression verifies seven scenarios. No real PCM communication, Test Write, write or flash.

Known limitations: separate file paths and ledger entries alone do not prove two physical ECU reads. A lost ledger requires two new supervised read-only Full Reads. Windows/OBDLink/PCM Hammer qualification, interrupted-read recovery, reviewed lockfile, licensing, signing, secure updates, privacy and clean installation remain release blockers. Do not publish.
