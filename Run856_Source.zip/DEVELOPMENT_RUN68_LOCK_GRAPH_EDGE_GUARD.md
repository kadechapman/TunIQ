# TunIQ Run68 — Offline dependency-edge verification

**Scope:** Read-only metadata checks for the Windows source-validation preflight. No dependency installation, ECU connection, calibration write, Test Write, or flash.

## Reproduced failure

Run67 verified each transitive lockfile entry's version, integrity metadata, and registry URL, but it did not verify whether a transitive package's declared dependencies were present in `packages`. A synthetic `a-package` declaring a missing `nested-required` dependency incorrectly passed. A new regression test failed against the unchanged Run67 implementation.

## Change

`tools/windows-dependency-preflight.js` now checks required and optional dependency targets in the lockfile package graph, including root direct and development dependency edges. Resolution follows the nearest nested `node_modules` directory, then ancestor package directories, then the root. It rejects malformed dependency maps, unsafe package names, invalid or local/remote source specifications, and missing lock entries. A valid nested, hoisted, scoped, or ancestor-resolved target is accepted.

Ten new offline assertions in `tests/windows-dependency-preflight-simulations.js` cover missing required/optional targets, nested/hoisted/scoped/ancestor resolution, and malformed maps, names, and specifications.

## Boundaries and release implications

This check verifies only the *presence* of required/optional lockfile dependency targets and existing metadata. It does not verify semver range satisfaction, peer dependency constraints, npm alias behavior, registry authenticity, downloaded tarballs, `npm ci`, native Windows execution, or installation. The project still has no `package-lock.json`; the strict preflight must continue to fail closed. Windows builds and physical ECU tests remain unverified.

No release readiness or physical hardware verification is implied by passing these offline simulations.
