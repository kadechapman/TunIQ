# Run73 — Premature test-suite banner must remain disqualifying

## Scope

Offline verification only. No Electron runtime, serial port, ECU, Test Write, or flash was accessed.

## Reproduced defect

The Run72 `tools/verify-test-suite.js` verifier accepted a synthetic child that printed the exact success banner **before** running any of the 76 required groups, then printed all required progress groups and a second success banner. It returned `ok: true` and `reason: passed` because `prematureBanner` was not included in the final success predicate.

## Correction

The verifier now rejects a run if **any** premature success banner appeared, even if a later banner is correctly positioned. The result is `ok: false`, `reason: premature-success-banner`. The existing proof requirements (zero exit code, exact banner, 76 distinct groups, all named required milestones, no trailing output, no timeout) remain in force.

Two synthetic regressions exercise one and two early banners followed by all required groups and a final banner. These tests are offline and do not interact with hardware.

## Verification limitations

Passing offline suite verification does not prove Electron starts on Windows or any physical ECU operation is safe. `package-lock.json` is still missing, and release promotion remains blocked. Native Windows build, dependency installation, hardware Full Reads, and production readiness remain unverified.
