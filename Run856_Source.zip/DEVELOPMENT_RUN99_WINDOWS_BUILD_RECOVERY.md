# Run99: bounded Windows offline-preview build recovery

This is a **source-level development checkpoint**, not a tested Windows build.
The isolated preview contains no ECU/OBD/PCM Hammer code and must not be used on a vehicle.

## Build reliability changes

- Fail quickly if npm cannot resolve a genuine lockfile: no registry retries and a 15-second fetch timeout. This avoids spending the build window on an unavailable registry.
- Move the complete offline test suite *after* dependency installation, retaining it as a mandatory gate before staging and packaging. Source integrity and read-only safety checks still run before dependency installation.
- Launch the staged preview using the installed `electron.exe` directly, quote the disposable project path (Windows user paths can contain spaces), and enforce a 30-second process timeout. A hung staged Electron startup fails closed instead of leaving the script stuck.
- Preserve both staged and packaged renderer evidence checks. Do not interpret a successful process exit as proof of renderer startup.

## Windows 10/11 x64 validation (Node.js 20+)

With all ECU and OBD hardware disconnected, extract the source ZIP and open PowerShell in its root directory:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect the newly created `dev-build-output/Run97-Diagnostics-<guid>/build-outcome.json`, transcript, lockfile candidate, staged evidence, and packaged evidence. The Run97 folder prefix is historical naming only.

An offline UI preview, even if it launches successfully, is **not** a verified full TunIQ tuning application or public release. No physical ECU Test Writes, writes, or flashes are authorized.
