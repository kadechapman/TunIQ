# TunIQ v1.9.0-beta.77 — Restricted Assisted Evidence Import Gate

**Source-only development checkpoint. Not a runnable Windows installer or public release.**

## Reproduced and fixed

On beta.76, a default restricted read-only `FlashManager` accepted a user-supplied 524,288-byte `.bin` through `importAssistedEvidence`, called `onReadComplete`, and returned `accepted: true` without any PCM Hammer CLI execution. Assisted text logs could also reach result classification. This permitted unverified manual files to be presented as hardware read evidence.

Beta.77 rejects assisted/manual evidence at the manager boundary for restricted read-only mode. It blocks assisted preparation, background scans, and IPC import **before** opening a file dialog. Existing integrated read-only CLI workflows are unchanged. Legacy synthetic test-only assisted imports remain available only when explicitly constructed with `platform: 'test'` and `allowSimulatedWrites: true`; that constructor is not used by production Electron.

## Safety and limits

- No physical ECU read, Test Write, write, flash, or COM-port access was performed.
- Regression tests use fabricated BIN/log files and callbacks only; they do not certify hardware safety or every other project-import path.
- The source-only launch gate continues to report unresolved dependency lock, license, secure update, physical hardware qualification, signing, privacy, redistribution, incident response, and clean Windows install requirements.
- Windows PCM Hammer CLI/kernel compatibility, interrupted Full Read recovery, exact-OS definitions, checksum and backup safety, and AI tuning restrictions still require qualification.

## Verification

See the accompanying beta.77 development report and test evidence. A runnable Windows build and production readiness have not been established.
