# Development checkpoint — hexadecimal read-integrity counters (Run35)

Date: October 18, 2026. Source-only, offline development against the verified Run34 Library ZIP (`09ba2c4172d29d5b8dea77505417572376529a63a7d78977233acbde9b580d01`). Previous Run33 ZIP was independently verified and compared.

## Reproduced issue

The PCM Hammer diagnostic classifier rejected nonzero decimal and zero-padded CRC/checksum/hash error counters, but did not recognize hexadecimal counters. With a nominal CLI exit status of zero, `CRC errors: 0x02\nRead completed successfully` was classified as a successful Full Read. With a syntax/usage footer, the same diagnostic could permit another automatic read-only CLI profile or typed-device attempt. This was reproduced with synthetic strings and no hardware connection.

## Change

`src/pcmhammer-integrated.js` now rejects nonzero hexadecimal counters (for example `0x02`, `0x0A`, `0X10`) in both label-first and count-first forms. All-zero hexadecimal counters remain nonfatal. Regression fixtures cover Full Read, Read Properties, CLI profile retry and typed-device fallback. This changes only read-only diagnostic classification; no physical PCM Test Write, ECU write or flash is performed.

## Limits

This is not a verified PCM Hammer log format or a Windows CLI/kernel compatibility claim. The parser is intentionally conservative when a failure counter is explicit. It does not establish cross-process COM locking, physical OBDLink ownership, successful independent physical Full Reads or interrupted-read recovery. Source-only tests do not qualify the application for a public release.

## Remaining release blockers

Genuine reviewed dependency lockfile; reproducible clean Windows install; signed build; Windows PCM Hammer/kernel/OBDLink validation; two independent matching physical Full Reads; interrupted-read recovery; exact-OS definitions and checksum/backups; human approval of AI changes; licensing, redistribution, privacy, secure updates and incident/recovery procedures. Recommend a supervised read-only beta only after the read-only hardware gates pass.
