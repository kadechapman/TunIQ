# Run64 — optional read-only phone-log consistency verification

Scope: offline phone-log artifacts only. No COM access, ECU commands, write, flash, or installer changes.

## New behavior

`node tools/audit-phone-log-imports.js <project-folder> --verify-contents` checks complete imports in a bounded, opt-in pass. The default audit still inventories file names only. Content verification reads the three owned files through individually checked, read-only descriptors, rejects linked or changing files, limits CSV input to 64 MiB and each JSON input to 1 MiB, checks canonical CSV header and row count, compares metadata/report identity fields, and verifies the SHA-256 digest of the published CSV.

New phone-log imports include `normalizedCsvSha256` in both metadata and report, calculated from exactly the CSV text published. Older imports without this field are **unverified**, not silently certified. Invalid or inconsistent imports are reported with error codes, not file contents; no files are repaired, deleted, overwritten, or modified. A successful consistency audit does not prove that original phone sensor readings were authentic or that all metadata was truthful.

## Limits

- Filesystem verification is not a transactional snapshot across three files; concurrent changes between separately checked reads remain possible. Each individual read detects replacement, growth, and truncation before completion.
- This is a post-import audit, not a security boundary against a hostile process with simultaneous write access to the project directory. A coordinated rewrite of CSV and metadata can forge a matching digest; no signatures are used.
- The CSV audit counts canonical single-line rows emitted by TunIQ; it is not a general-purpose CSV parser.
- Native Windows filesystem behavior, dependencies, installers, and physical ECU reads remain unverified.
- Existing read-only audit reports remain unchanged except for an added `verifyContents` boolean. CLI exit code is 0 for clean, 2 for attention/incomplete, 1 for invalid invocation/error.
