# TunIQ beta.108 — Ledger parent redirection guard (development only)

**Scope:** Offline software change; no ECU connection, Test Write, PCM write, or flash. This is not a Windows or physical-hardware qualification.

## Verified baseline and reproduced defect

Started from the newest TunIQ Library Run27 Mid-Read Orphan Guard archive (SHA-256 `5b3af77c3601bd7f776124a4522ed1ac622936047c1af045e67da30e05c5e3ad`, 568/568 manifest entries verified), compared with Run26 Reconciled Ledger Integrity. A valid `Devices` **directory symlink** could redirect the transaction manager to a different physical ownership ledger. The old implementation only rejected a symlink/hardlink on the ledger **file**, and accepted `begin()` through the redirected parent. Reproduced with a temporary Linux filesystem; no adapter attached.

## Change

`src/p01-hardware-transaction.js` now checks that the immediate `Devices` ledger parent is a real directory and not a symlink/junction before read/admission and before writing or renaming a ledger. A genuinely missing directory remains allowed for first launch and is created normally. A redirected parent fails closed; no evidence is deleted or replaced. `tests/p01-hardware-transaction-simulations.js` verifies blocked preparation, snapshot, and CLI admission, external ledger byte preservation, and legitimate first-launch recovery.

**Residual risk:** Filesystem inspection is not an atomic OS-level lock and does not prevent all directory-swap races, cross-process writers, or Windows reparse-point variants. Native Windows junction/CLI tests, physical OBDLink COM ownership, and interrupted Full Read recovery are unverified. Do not treat simulation results as hardware safety evidence.

## Release gate

Do not promote a public release from this checkpoint. A clean, pinned Windows build and native read-only Full Read qualification are required. PCM writes remain prohibited by this development pass; no write/flash functionality was changed.
