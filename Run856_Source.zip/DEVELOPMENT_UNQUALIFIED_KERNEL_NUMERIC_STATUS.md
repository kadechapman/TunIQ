# Run39 — Unqualified numeric PCM Hammer kernel statuses

**Scope:** Source-only, offline read/read-properties classification and read-only CLI retry admission. No physical ECU communication, Test Write, write, or flash.

## Baseline reproduction (Run38)

A nominal CLI exit code `0` and `Read completed successfully` were accepted even after diagnostics such as `Kernel upload: 0`, `Kernel upload status: 0`, `Loader execution: 1`, or `Kernel handshake: 0x00`. When an unrelated `Unknown option` or typed-device parser rejection followed, the same unqualified numeric kernel status permitted an automatic second CLI attempt. The original source produced `success=true`, `retry=true`, and `fallback=true` for the four synthetic examples; see `BASELINE_REPRODUCTION.txt` in the evidence archive.

## Change

Treat numeric kernel/loader upload, load, execute, start, transfer, handshake, or initialization result/status fields as **ambiguous, not positive success evidence**. A `0` might be a false boolean, a successful process return code, or a byte count; a `1` might be true or an error code. Without a verified CLI/kernel version-specific schema, TunIQ cannot interpret either safely. The existing fail-closed kernel-status detector now rejects these fields for both read-result promotion and read-only profile/typed-device retry admission. Named positive statuses such as `true`, `success`, and `completed` remain supported.

The existing stop code `kernel-transfer-failed` is a conservative safety stop category; it does **not** prove a real kernel failure occurred. This patch does not change write/flash behavior.

## Limitations

Tests use synthetic CLI text only. The numeric format has not been confirmed on physical PCM Hammer/OBDLink hardware. The application is not qualified for physical COM exclusivity, native Windows kernel/CLI behavior, interrupted Full Read recovery, or public release. Missing npm lockfile and native Windows installation remain blockers.
