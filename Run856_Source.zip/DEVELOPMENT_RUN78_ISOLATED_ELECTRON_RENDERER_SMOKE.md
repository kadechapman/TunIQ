# Run78 — Isolated Electron Renderer Startup Smoke

This bounded change adds a real Electron renderer smoke test **for later Windows CI use**. It does **not** claim that a Windows build has been run or that TunIQ is ready for user testing.

## Purpose and safety boundary

- `npm run test:renderer-smoke-contract` uses Node only; it verifies 24 simulated renderer/URL-admission checks and source isolation assertions. It does not start Electron or access hardware.
- `npm run test:renderer-runtime` requires installed Electron and a graphical desktop session. It starts an **isolated Electron main process**, not TunIQ's production `src/main.js`. It loads the real `src/renderer/index.html`, `src/preload.js`, JavaScript and CSS under context isolation, sandboxing, and popup/navigation denial.
- The isolated harness registers **no IPC handlers**, imports no FlashManager or OBD module, denies remote requests and local files outside the renderer asset directory, and uses a temporary Chromium user-data directory. It cannot exercise ECU reads or writes.
- The runtime smoke checks DOM, preload bridge availability, exact CSP, stylesheets and expected scripts. It does **not** prove the production main process bootstraps correctly or that the UI completes data initialization.
- The runtime smoke is integrated **after** `npm ci` and the complete suite in the existing Windows locked-dependency job. It cannot run there until a genuine reviewed `package-lock.json` exists.

## Verification still required

1. Generate/review `package-lock.json` on a trusted machine with npm registry access and commit it.
2. Run Windows CI `npm ci`, full tests and `npm run test:renderer-runtime` on an interactive runner.
3. Verify actual production Electron startup separately with hardware disconnected and writes disabled, then package an unsigned internal development build for supervised testing.
4. Never label the project READY FOR USER TESTING without a verified runnable build and relevant tests; public release additionally requires release attestations.
