# Run120 — P01 request safety-fact negation and OS admission

Source-only development change. This is **not** proof of ECU hardware compatibility, verified ECM operating-system identity, or an approved calibration.

## Reproduced safety defect

`parseP01SafetyFacts` previously matched the words `verified`, `rated`, `closed-course`, and `accept` inside negative statements such as `Valvetrain not verified`, `Tires not rated 200 MPH`, `Not closed-course testing`, and `I do not accept ghost idle risks`. Such text could incorrectly satisfy safety confirmations for a high-RPM, high-speed, or ghost-cam request. The new regression failed on Run119 and passed after the fix.

## Run120 correction

Safety confirmations are evaluated within separate text clauses and require affirmative, non-negated wording. Uncertain and negative wording does not satisfy safety confirmations. Contradictory claims about the same safety domain also fail closed. A tire speed rating in a negated clause is not accepted. This remains a textual admission check only: a user's statement is not physical proof of component ratings or mechanical safety.

P01 request review now refuses to mark a request ready when the active project's OS identifier is missing, placeholder, or not in the expected numeric identifier format. A numeric OS identifier **does not establish** that a real PCM, BIN, or XDF is matched. Exact-OS mapping, original-BIN provenance, checksum, fan output wiring, and separate physical hardware testing are still required.

## Owner's LS 5.3 development scope

- VATS: exact controller OS and compatible BIN/XDF definition must be independently verified before considering a revision.
- Electric fans: temperature threshold editing is separate from ECM output enablement and relay/fuse/wiring verification; no temperatures or pin assignments invented.
- LSX Stage 2 cam: no physical cam tune until exact cam-card data, injectors, valvetrain, and baseline logs are available.
- Knock sensors: automatic knock protection deletion remains blocked; diagnose the sensors and harness and preserve engine protection.

No physical ECU read, Test Write, write, flash, or live OBD session occurred. Offline fixtures and Linux tests cannot certify Windows Electron startup or a full tuning application.
