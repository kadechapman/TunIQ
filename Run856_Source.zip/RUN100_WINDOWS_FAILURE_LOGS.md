# Run100 — Windows offline-preview failure diagnostics

This source-only checkpoint preserves the **existing fail-closed build gates**. It does not produce or verify a Windows executable. The full TunIQ app and ECU-capable code are never launched by this preview script.

## What changed

`tools/windows-build-offline-preview.ps1` now redirects native staged and packaged Electron stdout/stderr into the unique `dev-build-output/Run97-Diagnostics-<guid>/` folder. Previously a PowerShell transcript could omit GUI-subsystem child-process output. Each successful preview now uses a unique `dev-build-output/Offline-UI-Preview-<guid>/` directory, avoiding collisions with previous runs while refusing to overwrite. Both smoke evidence JSON files are now copied to diagnostics **even when the process reports failure**; their presence alone never satisfies the startup gate. The exit-code and nonce-bound `passed` checks remain mandatory.

## Windows execution

From the extracted source directory on Windows 10/11, with Node.js 20+ installed and **all ECU/OBD hardware disconnected**:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

On failure inspect `dev-build-output/Run97-Diagnostics-<guid>/build-outcome.json`, `windows-build-transcript.txt`, and when Electron was reached, `staged-electron.stderr.log`, `staged-electron.stdout.log`, `packaged-electron.stderr.log`, `packaged-electron.stdout.log`, and the corresponding `*-smoke-evidence.json`. Logs may include local file paths; review before sharing. A failed/missing evidence file is not a pass.

If the npm registry cannot be resolved, dependency installation and native Electron/Windows packaging remain unverified. **No claim of readiness is authorized by source-level tests.**
