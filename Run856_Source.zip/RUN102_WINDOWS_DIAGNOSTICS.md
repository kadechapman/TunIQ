# Run102 — Windows offline preview diagnostics (no ECU access)

This checkpoint adds a dependency-free diagnostics classifier to the isolated UI preview workflow. It **does not** enable the full TunIQ application, an ECU connection, or a write/flash path.

## Run on Windows 10/11

Install Node.js 20+ and disconnect all OBD/ECU hardware. Extract the complete Run102 source ZIP and open PowerShell **in the extracted source root**:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

The script generates a unique `dev-build-output/Run97-Diagnostics-<32hex>` folder. The historical Run97 prefix is intentional. It attempts `npm install --package-lock-only` if needed, validates the lockfile, runs `npm ci`, executes offline tests, then launches staged and packaged **hardware-isolated** Electron smoke tests. The packaged executable is copied to `dev-build-output/Offline-UI-Preview-<32hex>` only after successful native smoke evidence.

New in Run102: `diagnosis.json` summarizes the last verified step, a bounded failure category, whether two distinct smoke proofs exist, and an actionable next step. The classifier never copies raw logs, environment variables, usernames, or paths into the summary. The full `windows-build-transcript.txt`, `staged-electron.stderr.log`, and `packaged-electron.stderr.log` remain local for debugging. **Review raw logs for personal paths before sharing.**

To regenerate a safe summary (without modifying the directory):

```powershell
node .\tools\diagnose-windows-preview.js '.\dev-build-output\Run97-Diagnostics-<32hex>'
```

The GitHub Actions workflow now adds the same safe JSON diagnosis to the job summary even after build failure, when the diagnostics directory exists. Its actual Windows runner has **not** executed until the complete source is reviewed and pushed to `dev/**`.

## Scope and limitations

- `npm run test:windows-preview-diagnostics` exercises offline fixtures only.
- `npm run test:windows-preview-ci` statically checks the workflow only.
- The Linux development environment cannot resolve the npm registry (`EAI_AGAIN`) and cannot execute native Windows Electron.
- The generated `diagnosis.json` is a troubleshooting aid, **not** a substitute for the Windows process exit, staged/packaged nonce-bound renderer proofs, or the actual executable.
- Even a verified offline UI preview is **not** full TunIQ user-testing or public-release approval. No ECU reads, Test Writes, writes, or flashes are permitted in this preview.
