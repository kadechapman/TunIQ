# TunIQ v1.9.0-beta.58 — Merged Transitive Lock and Absolute Read Path Guards

**Source-only development checkpoint. Not approved for Windows user testing or public release.**

## Preserved and added

Based on the newer independently verified beta.57 Transitive Lockfile Safety Gate source, preserving its dependency-graph metadata checks, tests and source snapshot. Added the independently developed Full Read path-consistency fix: `FlashManager.preflight('read')` passes PCM Hammer the same absolute destination previously checked for overwrite and symlink risks, rather than an unchecked relative string. A new regression tests relative output and preserves safe creation of missing subfolders.

This is not an atomic filesystem reservation and does not authenticate PCM Hammer or its kernels. No physical read, Test Write, PCM write, or flash was performed. Windows installer, dependency lockfile, licensing, signing, updates, privacy and hardware qualification remain blocked.
