# TunIQ v1.9.0-beta.45 — Windows Process Inventory Identity Guard

**Source-only development checkpoint; not approved for user testing or public release.**

## Fixed

A syntactically valid but incomplete Windows PowerShell/CIM process inventory (for example `{}` or duplicate PIDs) could previously be interpreted as no external COM-port conflicts. Windows inventory parsing now rejects malformed rows, missing or duplicate process identities, invalid PID values, and empty names, while accepting the legitimate PID 0 System Idle Process. This makes PCM Hammer preflight fail closed when ownership cannot be assessed.

## Verification scope

Regression scenarios run using mocked PowerShell process output on Linux. No physical Windows/OBDLink/PCM validation or ECU write was performed. Source manifest and release gate are regenerated from the actual changed source. The application still includes write-capable functionality; public release remains blocked.
