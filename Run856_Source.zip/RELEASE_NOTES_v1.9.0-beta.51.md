# TunIQ v1.9.0-beta.51 — Pinned PCM Hammer CLI Digest Drift Guard

**Source-only checkpoint. NOT a qualified Windows build or public beta.**

## Safety change

Previously, PCM Hammer `probe()` recorded a SHA-256 in saved backend metadata, but subsequent Read Properties / Full Read preflight and device discovery did not check that the executable still matched. A replaced binary could be run while status still appeared configured. The restricted read-only path now checks the saved SHA-256 and executable path at preflight, discovery, and probe; `start()` rechecks after asynchronous port handoff/settling and before starting a session. Invalid saved digests fail closed, and the UI status suppresses capabilities and integration while blocked.

**Important limitations:** A SHA-256 captured during probing only detects drift relative to that probe. It does not prove official PCM Hammer provenance, Windows compatibility, publisher signing, kernel authenticity, or COM-port exclusivity. Previously unprobed installations have no pinned digest and are not authenticated by this check. A filesystem race between the final check and OS process launch remains possible. Never use this checkpoint for physical PCM writes.

## Recovery

If `cli-executable-integrity-changed` appears, do not keep retrying the adapter or launch a PCM operation. Stop, inspect the selected CLI path and installation, re-extract a trusted official PCM Hammer portable package, and review any previous read evidence. Only after manual inspection should a new CLI probe baseline be established. This source checkpoint does not automatically reset a changed fingerprint.

## Testing scope

Regression coverage includes modified bytes, malformed pinned SHA-256, changed executable path, blocked re-probe and discovery, status suppression, and a simulated executable change during asynchronous ownership inspection. Linux Node tests and ZIP hash checks do not qualify real Windows/OBDLink hardware or a runnable installer.
