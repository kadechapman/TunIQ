# TunIQ v1.9.0-beta.41 — Fail-Closed Windows Adapter Ownership Inspection

Source-only development checkpoint. Before launching PCM Hammer, TunIQ now fails closed if the exclusive Windows process inventory fails, times out, exits abnormally, emits malformed data, or yields no valid ownership decision. This prevents a missing inspection from being interpreted as an available COM port.

Regression: beta.40 accepted a thrown inspection error and started a mocked Read Properties process. The new test requires an `adapter-conflict-check-failed` stop before COM handoff. A null inspection result is also rejected.

This does **not** guarantee exclusive COM ownership on Windows; a process may race after inspection, and PowerShell/CIM reliability requires real Windows testing. No real OBDLink, PCM Hammer or PCM hardware test, Test Write, flash or write was performed. Public release remains blocked.
