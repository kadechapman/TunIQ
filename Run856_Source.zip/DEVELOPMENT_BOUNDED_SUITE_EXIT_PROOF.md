# Bounded automated-suite exit proof — October 18, 2026

Development checkpoint for TunIQ `1.9.0-beta.108`; **source only, not a runnable Windows build or release**.

## Baseline

The newest verified Library source was Run28 Ledger Parent Redirection (SHA-256 `6199e9ad1aa27bbac2f40553e96d7caed252f0da93f37046f7f59a2bf98f052e`, 569/569 source-manifest entries). It was compared with Run27 Mid-Read Orphan Guard (SHA-256 `5b3af77c3601bd7f776124a4522ed1ac622936047c1af045e67da30e05c5e3ad`). The Run28 local Git bundle was cloned. Existing ledger-parent redirection, orphan-ledger, file redirection, and mid-read guards were preserved unchanged.

## Problem and bounded improvement

Earlier full-suite runs sometimes printed the 76-group success banner without a captured process exit. A printed banner alone is insufficient evidence for release qualification. The exact cause of earlier missing exit records is not established. In this pass, an unchanged Run27 full suite **did exit 0** in a separately captured execution.

- `tools/verify-test-suite.js` adds a cross-platform subprocess wrapper for the offline suite. It requires a real zero exit status **and** the final 76-group success banner; it fails on timeout, missing banner, nonzero exit, spawn failure, or signal. Default timeout is 300 seconds, configurable by `TUNIQ_TEST_TIMEOUT_MS` (1–600000 ms). A timeout kills only the test subprocess; no hardware process is started by this wrapper.
- `package.json` routes `npm test` through the wrapper and adds `test:direct` and `test:suite-verifier` for diagnosis.
- `tests/verify-test-suite-simulations.js` tests genuine success, missing banner, nonzero exit after a false success banner, a hanging process after the banner, missing banner with exit zero, and invalid timeout rejection. Six assertions pass.
- `.github/workflows/windows-public-beta.yml` adds a Windows source-only verifier self-test step before the simulation suite. The workflow's existing mandatory dependency-lockfile gate and no-installer restriction remain in place.
- `LAUNCH_READINESS_CURRENT.json` refreshed with `npm run release:snapshot`. Nine launch blockers remain.

No production PCM Hammer, OBD, checksum, calibration, AI tuning, or ECU write code changed. No physical ECU communication or PCM write/flash occurred.

## Executed verification

Linux, Node 22.16.0, npm 10.9.2. Original Run27 `node tests/run-tests.js` **exit 0**, 76/76 groups (separate baseline). Reconciled Run28-derived source `npm test` **exit 0**, 76/76 groups with subprocess exit confirmed. No physical hardware testing occurred. `npm run test:suite-verifier` **6/6 exit 0**. `npm run check` and `npm run release:snapshot` **exit 0**. Focused offline tests: transaction passed; exclusive lease **13/13**; Full Read watchdog **14/14**; read-only beta guard passed; launch readiness **12/12**. All hardware-related tests are offline simulations.

Attempted `npm install --package-lock-only --ignore-scripts --no-audit --no-fund --fetch-retries=0` **failed** with `EAI_AGAIN` DNS resolution for `registry.npmjs.org`; no lockfile was generated. `npm ci --offline --ignore-scripts` failed with `EUSAGE` because the lockfile is absent. Native Windows install/build, real PCM Hammer CLI/kernel, physical OBDLink and interrupted Full Read recovery were **not** tested.

## Release decision

NOT READY FOR USER TESTING and NOT READY FOR PUBLIC RELEASE. This test-runner change increases reliability of automated evidence, but does not qualify hardware. Next: obtain a genuine dependency lockfile on a trusted networked Windows build host, verify `npm ci` and a clean read-only Windows build, then conduct supervised hardware-only Full Read qualification with explicit evidence. Never initiate PCM Test Write or a PCM write/flash as part of automated validation.
