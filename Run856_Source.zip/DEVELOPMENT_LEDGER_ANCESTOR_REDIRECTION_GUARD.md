# TunIQ read-only development: ancestor ledger redirection guard

**October 18, 2026. Source-only safety hardening. Not hardware verified.**

## Reproduced defect

The previous `assertLedgerParent()` inspected only the immediate `Devices` directory. If `dataRoot` or a higher ancestor was a symlink/junction, `Devices` itself could still be a regular directory, and the transaction manager accepted and overwrote the redirected ledger. An offline regression reproduced this: a valid external COM8 ownership record was read through a symlinked `dataRoot`, and `begin()` replaced it.

## Correction

`src/p01-hardware-transaction.js` now walks every directory component from the volume root through `Devices` using `lstatSync`, rejecting symlinks, junction-like redirections, non-directories, and unreadable ancestors. Missing components are permitted for legitimate first-launch directory creation. Existing checks still run before ledger read and before/after creating the directory for writes. A rejected path blocks both COM preparation and CLI admission and does not alter external evidence.

## Offline regression coverage

`tests/p01-hardware-transaction-simulations.js` now covers a redirected `dataRoot`, a redirected higher ancestor above a missing project directory, CLI admission rejection, external ledger byte preservation, and successful normal first-launch nested directory creation.

## Limitations and recovery

This is best-effort path validation, **not atomic cross-process COM ownership**. A concurrent filesystem rename can still race a path check. No physical OBDLink/PCM Hammer tests, Windows-native junction tests, physical Full Reads, Test Writes, ECU writes, or flashes were performed. On a suspicious path, do not delete or rewrite ownership records; verify the real directory path and process state offline before any supervised read-only hardware test.

**Launch remains blocked:** missing npm lockfile and clean Windows install; physical exclusive COM ownership, CLI/kernel compatibility, interrupted Full Read recovery, exact-OS calibration/checksum/backup review, AI approval gates, licensing, updates, signing, privacy, redistribution, and incident response require separate evidence.
