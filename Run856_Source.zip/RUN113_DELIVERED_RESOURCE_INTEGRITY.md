# Run113 — Verify the complete delivered Windows UI preview tree

**Scope:** hardware-free, isolated Electron UI preview only. This does not verify the production TunIQ application, ECU reads, Test Write, writes, or flashing.

## Reproduced defect

The Run112 independent reviewer verified the copied executable's SHA-256 and four nonce-bound Electron startup reports, but it did not verify files beside the EXE. In an offline regression fixture, changing `resources/app.asar` *after* the delivered smoke test still passed independent review. The red regression exited 1 with `Missing expected exception`.

## Correction

Run113 adds `tools/windows-preview-tree-integrity.js`, a read-only, bounded file-tree hashing verifier. The Windows build records every delivered file, including `resources/app.asar`, Electron DLLs, locale data, and the EXE, **after** the final delivered smoke. It records relative names, sizes, and SHA-256 digests in `delivered-preview-tree-integrity.json`. The independent reviewer and Windows CI re-enumerate and re-hash the delivered folder, rejecting missing, changed, added, symlinked, hardlinked, oversized, or ambiguous files. It fails closed when the executable or `resources/app.asar` is absent.

The check is bounded to 5,000 files, 1 GiB total, 512 MiB per file and 1 MiB evidence JSON. A larger legitimate preview must be reviewed and the bounds changed deliberately, not bypassed. This verification does not prove a Windows process launched; the four existing independent native smoke proofs remain mandatory.

## Native Windows handoff

Disconnect all ECU/OBD devices. On Windows 10/11 with Node.js 20+, extract the source ZIP and open PowerShell in the extracted source directory:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run check
npm run test:windows-preview-tree-integrity
npm run test:windows-preview-evidence-review
npm run test:windows-preview-ci
npm run test:windows-preview-diagnostics
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

If the build succeeds, locate the newest `dev-build-output/Run97-Diagnostics-<guid>` and its `Offline-UI-Preview-<guid>` folder **from the same build run** and run:

```powershell
$diag = Get-ChildItem .\dev-build-output -Directory -Filter 'Run97-Diagnostics-*' |
  Sort-Object LastWriteTime -Descending | Select-Object -First 1
$outcome = Get-Content (Join-Path $diag.FullName 'build-outcome.json') -Raw | ConvertFrom-Json
$exe = Join-Path (Join-Path .\dev-build-output $outcome.deliveredPreviewDirectory) 'TunIQ Offline UI Preview.exe'
node .\tools\windows-preview-tree-integrity.js --verify (Split-Path $exe -Parent) (Join-Path $diag.FullName 'delivered-preview-tree-integrity.json')
if ($LASTEXITCODE -ne 0) { throw 'Delivered preview tree integrity FAILED' }
node .\tools\windows-preview-evidence-review.js $diag.FullName $exe
if ($LASTEXITCODE -ne 0) { throw 'Independent Windows preview review FAILED' }
```

The reviewer must return `passed: true`, `deliveredTreeIntegrityVerified: true`, and `fullTunIQVerified: false`. If the build fails, inspect `diagnosis.json`, `build-outcome.json`, and local native Electron stdout/stderr logs; check them for private paths before sharing. Do not substitute an isolated preview for a complete runnable application.
