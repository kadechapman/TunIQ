# TunIQ v1.9.0-beta.80 — Verified Read Evidence Recheck

**Source-only checkpoint. Not a Windows installer or hardware-qualified release.**

A previously verified P01 Full Read pair could remain marked verified after a saved BIN was replaced by a hard link, modified, or deleted. The previous beta.79 recovery guard protected *reconstruction* of damaged pair pointers, but not the normal already-verified status path.

Beta.80 rechecks two surviving independent regular files, their identity and digest, before reporting dual-read verification or allowing original calibration binding. The cached canonical digest alone cannot substitute for the two files. Five new filesystem-only regression assertions cover this behavior.

No PCM Hammer process, serial COM port, physical ECU read, Test Write, write, or flash was initiated. Windows/NTFS, clean installation, dependency locking, hardware COM ownership, CLI/kernel compatibility and interrupted hardware read recovery remain unverified.
