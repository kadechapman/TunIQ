# Run60 — Read-only log parser resource limits

Date: 2026-10-19. Source version: 1.9.0-beta.108. No ECU, COM, Test Write, flash or hardware activity.

## Reproduced defect

Run59 `parseCsvText()` accepted a synthetic 150,000-row CSV, then failed with `RangeError: Maximum call stack size exceeded` while calculating duration via `Math.max(...times)` and `Math.min(...times)`. It also split all input lines and allocated every row without a row or column budget. `.tuniqlog` JSON parsing similarly had no explicit row or column limit. The prior 100 MB evidence file cap bounded raw bytes, not parsing allocations.

## Changes

- `src/log-import.js`: fail closed before CSV splitting or JSON normalization for text larger than 16 MiB; CSV files are limited to 50,000 data rows, 128 fields per row, and 65,536 characters per line. JSON/TunIQ packages are limited to 50,000 rows and 128 columns. The CSV line scan enforces the bound before allocating the `split()` arrays.
- Replaced the variable-length `Math.max(...times)` argument expansion with a bounded loop, so valid large logs do not hit the JavaScript argument limit.
- `tests/log-import-limits-simulations.js`: 13 offline checks for boundary conditions, normal parsing, private VIN removal, CSV and JSON limits, and the large-log duration calculation. Wired into the existing evidence-import test group without changing the expected 76 groups.
- Added `npm run test:log-import-limits` for independent testing.

## Compatibility and residual risk

Logs exceeding the limits are rejected with a clear error; split long sessions before importing. These are defensive resource caps, not a time or memory guarantee: `JSON.parse()` and normalization still allocate objects within the permitted 16 MiB source size. The current CSV parser is line-based and does not support embedded newlines inside quoted CSV cells; this pre-existing limitation is unchanged. `normalizeFile()` still performs a whole-file read before applying the 16 MiB text limit; the evidence manager's verified snapshot is capped at 100 MB. Further work should bound `normalizeFile()` input *before* reading and add a true streaming parser if larger log files are required.

## Release gate

Source-only regression verification does not establish a runnable Windows installer or any physical read-only hardware qualification. No public-release or user-testing readiness is claimed.
