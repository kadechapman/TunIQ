# Run124 — Per-run Windows lockfile candidate isolation

This is a source-only operator safety improvement, **not** a native Windows run.

## Reproduced problem

The Windows read-only operator script previously copied its genuine npm-generated
`package-lock.json` to the fixed path `dev-build-output/package-lock.candidate.json`
using `-Force`. A later run could silently overwrite the previous candidate,
while the npm debug logs and renderer proof were preserved under a different,
unique `Readonly-Validation-<guid>` diagnostics directory. This broke the
operator's ability to reliably associate a lockfile candidate with the run
that produced it.

## Correction

`tools/windows-readonly-dev-validation.ps1` now places
`package-lock.candidate.json` in that run's unique
`dev-build-output/Readonly-Validation-<guid>/` directory beside the npm logs.
The script refuses to overwrite an existing candidate in the same directory.
The source checkout remains unchanged; dependencies are resolved in a disposable
copy, and the candidate is retained for manual inspection. An npm success code
without a genuine lockfile still fails closed.

## Verification limits

The new regression first failed against the prior operator script and passed
after the fix. This verifies PowerShell source structure only: **native
PowerShell execution, Electron startup, dependency installation, and full TunIQ
application operation remain unverified** until run on Windows. The online
npm registry is unavailable in the Linux environment; no lockfile was
fabricated.

## Operator steps (Windows 10/11, Node.js 20+)

Keep all ECU/OBD hardware disconnected. From the extracted source folder:

```powershell
npm run check
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1 -PrepareOnly
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Review the candidate and npm logs in the **same** `Readonly-Validation-<guid>`
directory. Preserve `Run97-Diagnostics-<guid>` for the separate hardware-free
preview. A preview is not a full ECU-capable application.

VATS changes still require exact P01 operating-system/definition matching.
Electric fan output enablement is separate from temperature thresholds. The
LSX Stage 2 cam requires exact cam-card data and baseline logs. Knock-sensor
removal is not automatically approved; knock protection must not be silently
disabled. No ECU read, Test Write, write, or flash was performed.
