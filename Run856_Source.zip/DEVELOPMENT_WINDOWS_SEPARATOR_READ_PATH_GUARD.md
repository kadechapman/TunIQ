# TunIQ Run46 — Windows Separator Read-Path Guard

Date: 2026-10-18. Version: 1.9.0-beta.108 (source-only checkpoint).

## Reproduced issue

`checkSafeReadPath()` and `checkUnusedReadDestination()` accepted POSIX filenames
containing embedded backslashes, such as `/tmp/backups\\NUL.bin`. On Windows,
backslashes are directory separators, and the same spelling can designate a
reserved device filename, an alternate data stream, or a different path.
Consequently Linux/macOS preflight and regression tests could report a path
safe despite differing Windows semantics.

## Change

`unsafeWindowsPathComponent()` now rejects a backslash inside a resolved
component. Windows `path.basename()` treats ordinary backslashes as path
separators, so valid Windows directory separators remain supported there.
On POSIX, embedded backslashes fail closed instead of silently passing the
Windows-oriented backup policy. Both initial destination admission and later
path-policy validation use this shared check.

Twelve additional offline assertions cover six ambiguous spellings for both
path-policy validation and destination preflight. The new regression was
observed failing before the fix and passing afterward. This change does not
make path validation an atomic reservation; callers must still recheck before
launching the CLI and must not overwrite an existing output.

## Release limitations

No COM port, ECU, PCM Test Write, ECU write, or flash was accessed. This is an
offline path-safety fix, not physical Windows/PCM Hammer validation. No
Windows installer, runnable app, or dependency lockfile has been verified.
Installer admission remains blocked; do not announce user-testing or public
release readiness from these tests alone.
