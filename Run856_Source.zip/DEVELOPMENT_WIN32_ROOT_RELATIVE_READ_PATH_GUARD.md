# TunIQ beta.108 — Win32 root-relative Full Read destination guard

**Scope:** Offline source-only development checkpoint. No ECU or COM hardware used.

## Reproduced defect

The prior `src/read-output-safety.js` accepted a single-leading-backslash
Win32 current-drive-rooted path, for example `\Temp\read.bin`, as an ordinary
backup destination. Win32 interprets this spelling relative to the current
drive root rather than a selected absolute backup directory. On a POSIX test
runner the same string can be treated as an ordinary filename, masking the
Windows behavior. Both `checkSafeReadPath` and `checkUnusedReadDestination`
returned `{ ok: true }` in the original source when run in an existing folder.

## Correction

Reject single-leading-backslash Win32 paths before normalization, on every
platform, using the existing `read-output-unsafe-namespace` stop code. Reject
single-leading-forward-slash paths on Windows, while retaining valid POSIX
absolute paths for Linux/macOS tests. The change covers Full Read destination
preflight and subsequent read/import path validation through the shared policy.
It does not reserve a filename atomically or prove Windows handle ownership.

## Qualification limits

The new assertions are filesystem-only simulations. They do not verify a
runnable Windows build, OBDLink hardware, real PCM Hammer CLI/kernel behavior,
physical read recovery, or any ECU write/flash. A genuine dependency lockfile,
clean Windows installation, hardware qualification, and the existing public
release blockers remain required. Do not promote this source-only checkpoint
as a public beta on the strength of these tests.
