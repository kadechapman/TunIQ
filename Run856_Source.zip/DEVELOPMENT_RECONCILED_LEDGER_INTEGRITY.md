# TunIQ beta.108 — Reconciled COM ownership ledger integrity (development only)

This source-only pass starts from the newest verified Run25 Ledger Redirection Guard archive (SHA-256 `3c8e54d225223214a21e7e413d052648b73417538b65e05276c4aa7b56965c93`) and reconciles the independently verified Run25 Orphan Atomic Ledger guard (SHA-256 `a145c7273270d0f2a570b6457bebee89e1123bf073696d126bf3c99be715e1ae`). Both sibling branches started from Run24, so neither contained the other's fix. The remote GitHub `main` still contains a beta.17 ZIP rather than the beta.108 tree.

## Defect and change

The newer redirection-guard source rejected symbolic and hardlinked ownership records, but could still trust an older valid ledger when a newer interrupted atomic-write `.tmp` file existed. An offline reproduction confirmed `begin()` accepted a replacement COM8 preparation despite the orphan. The reconciled `readLedger()` now rejects writer-named orphan temporary files **before** reading an existing or missing ledger. No orphan is deleted automatically; an operator must inspect the files and independently confirm PCM Hammer has exited before manual recovery. Existing symlink/hardlink protections remain.

The new regression tests cover a valid older ledger, missing ledger, denied process admission, evidence preservation, and unrelated temporary files. No physical COM device, PCM Hammer CLI, Test Write, PCM write, or flash was used. This is not a cross-process OS lock, not a verified Windows build, and not hardware qualification.

## Outstanding blockers

Reproducible Windows dependency lockfile and clean install; full-suite process termination; PCM Hammer Windows CLI/kernel pairing; physical OBDLink exclusive ownership; independent matching Full Reads and interrupted-read recovery; exact-OS definitions, checksum and protected backups; human-reviewed AI tuning; licensing, secure updates, privacy, signing, redistribution permissions and incident response. No public or user-testing readiness claim is justified.
