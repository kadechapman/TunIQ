# TunIQ Run117 — LS swap ECM dev-test coverage (read-only admission)

## Target requested by owner

An LS-swapped vehicle, donor described as a 2002 Tahoe 5.3L with a physical LSX Stage 2 camshaft. The user intends to test theft-deterrent/VATS configuration, electric fan control, knock sensor removal, and camshaft-related drivability calibration. These are **requests**, not evidence that the ECM supports an operation.

## Verified source capabilities versus remaining evidence

| Request | Observed in source | Conditions before an actual calibration | Current admission result |
|---|---|---|---|
| VATS / theft-deterrent change | P01 goal executor can propose labeled, exact-OS VATS changes | Lawful ownership; positively identified P01 OS; protected original BIN; independently confirmed controller reads; exact writable XDF; correct enable/disable polarity; checksum verification; separate review and hardware write gate | Candidate source path only, **not hardware verified** |
| Electric fan on/off temperatures | P01 request parser and goal executor handle explicit on/off temperature pairs and mapped fan cells | Actual on/off targets and units; thermostat; relay/fuse/pin wiring and hardware state; exact-OS definition; temperature sensor verification; staged testing | Candidate source path only, **not fan-output enablement** |
| Electric fan output enablement | No verified auto-map for output/relay mode merely from temperatures | Confirm output pins, PCM hardware capability and exact-OS enable-mode table before designing this change | **Pending separate definition**, blocks combined quick-service request |
| Physical LSX Stage 2 cam tune | AI intake/tune engine have cam/logging support, but not a complete automatic P01 quick-service cam table mapping | Cam card (intake/exhaust duration @ .050, valve lift, LSA, installed centerline); spring and injector specs; exact OS/XDF; baseline warm idle/airflow/fuel-trim logs; review of idle, MAF/VE, fueling, spark and transmission interactions | **Pending supplied specs and reviewed calibration**, no guessed cells |
| Knock-sensor delete | Diagnostic logging recommends retaining knock protection | Verify wiring/sensors, physical setup and knock-retard data; do not silence knock protection as part of an unvalidated cam tune | **Not automatically supported**; request is blocked for safety review |

## Fail-closed mixed request behavior

`src/calibration-request-coverage.js`, `src/goal-executor.js`, and `src/p01-request-review.js` now identify unsupported or incomplete elements of a mixed request. TunIQ must not silently create just the VATS revision when the same request also asks for unverified fan enablement, knock sensor deletion, or a physical cam tune. The quick-service review shows all unresolved items and disables confirmation; direct goal-proposal generation also rejects the mixed plan. A standalone invalid fan-temperature proposal retains its existing blocked-action preview.

## Required dev-test order

1. Verify actual controller/OS identity. Do not assume a P01 solely because the donor was a 2002 Tahoe. Verify genuine read-only recovery, backups, and exact-OS definitions first.
2. Inspect supported VATS and fan-temperature mappings in a **copy** of the calibration. Confirm fan hardware output separately from temperature thresholds.
3. Collect the precise LSX Stage 2 cam specs when available; do not invent target idle, spark, fueling, or RPM settings.
4. Preserve working knock feedback, verify knock sensor circuitry and engine health, and review logs rather than auto-disabling knock protection.
5. Validate checksums, project binding, before/after change set and recovery prerequisites offline. **Do not flash** during development verification.

## Current limitations

This pass tests only parser completeness, review gates, and offline proposals. It does not establish physical ECM read/write support, a runnable Windows build, a validated OS definition, emissions compliance, or a safe calibration. A source-only green test is not permission for Test Write or flash.
