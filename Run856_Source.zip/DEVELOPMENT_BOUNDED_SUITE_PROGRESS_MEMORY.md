# Run55 — Bounded automated-suite progress memory

**Scope:** offline test-verifier reliability only. This does not change ECU communications, reads, writes, flashes, calibration, or release admission.

## Reproduction

The Run54 suite verifier accepted a synthetic child process that printed the 73 required milestone labels, three additional labels, **129 unrelated unique checkmarks**, and a matching success banner, with exit code 0. It returned `ok: true`, `reason: passed`, and retained 205 distinct progress labels. Because the verifier accepted and retained any unique label, a noisy or compromised test child could grow its progress set without bound during the permitted runtime.

## Change

`tools/verify-test-suite.js` now retains at most **128 distinct progress labels** and rejects labels longer than **512 characters**. Excess output fails verification with `excessive-group-progress` or `oversized-group-label`. The real Run54 suite emitted 91 distinct progress labels, so the bound preserves headroom while preventing unbounded progress-set growth. The original 76-group threshold, 73 required named milestones, successful exit code, success banner, and idle/total deadlines remain mandatory.

`tests/verify-test-suite-simulations.js` adds regressions for overflow, the accepted boundary, and an oversized label. This is a verifier robustness measure, not a security guarantee against a child that deliberately fabricates valid named progress.

## Limitations

- Tests are synthetic and offline; no physical ECU, adapter, COM port, Test Write, write, or flash was used.
- A legitimate future suite emitting more than 128 distinct progress labels must deliberately update this cap and its regression coverage.
- Dependency locking, native Windows execution, physical read-only qualification, and public release remain blocked/unverified.
