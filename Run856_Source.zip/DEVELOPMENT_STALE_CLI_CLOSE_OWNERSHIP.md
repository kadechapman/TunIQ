# TunIQ beta.108 development checkpoint — stale PCM Hammer close ownership

**Scope:** source-only, read-only reliability and COM-port ownership. This is not a hardware qualification or a Windows installer release.

## Reproduced failure in the verified Pinned COM Admission source

A delayed PCM Hammer child `close` callback could rewrite the hardware transaction record after a replacement project had already started. With project A on COM4 and a newer project B on COM9 (`process-running`), invoking `markProcessClosed({port:'COM4', operation:'read', sessionId:'session-A'})` changed project B's recorded port to COM4, operation to read, and state to `process-closed`. This is not evidence that the newer child released its COM handle.

## Bounded correction

`src/p01-hardware-transaction.js` now checks the recorded transaction identity before persisting a child close. A mismatched COM port, operation, or nonempty session ID throws without mutating the transaction ledger. Normal matching closes remain permitted, including the two-phase close/finalization path used by `src/flash.js`. No ECU-writing path was modified or enabled.

`tests/p01-hardware-transaction-simulations.js` now exercises the stale cross-port callback, same-port stale session, wrong operation, unchanged ledger on rejection, and a successful matching close. These are offline simulations, not physical OBDLink or Windows COM-port tests.

## Remaining limitations and required qualification

The transaction record is a local JSON ledger, not a Windows kernel handle lease. Callback identity cannot be proven when the caller omits identity fields. The FlashManager still needs independent validation of process start/close ordering and error recovery on real Windows hardware. Confirm exclusive COM ownership, clean PCM Hammer CLI/kernel launch, interrupted Full Read recovery, and two independent matching reads before a supervised read-only beta. Never infer hardware safety from these simulations. Do not enable PCM Test Write or any ECU write/flash.
