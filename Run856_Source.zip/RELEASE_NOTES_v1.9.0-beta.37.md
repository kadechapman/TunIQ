# TunIQ 1.9.0-beta.37 — Evidence Hash Streaming and Parent Guard

Source-only checkpoint built on the separately verified Library beta.36 `Private_Hardware_Evidence_Integrity_Guard` source. `src/launch-readiness.js` streams SHA-256 from a pinned file descriptor in 64 KiB chunks rather than allocating a whole evidence file, and rechecks the resolved realpath before acceptance. `tests/launch-readiness-simulations.js` adds a symlink/junction-parent regression. All beta.36 hard-link, zero-byte-log, path-normalization, file-identity and source snapshot checks remain.

**Limitations:** Physical provenance remains self-declared; Windows junction and real OBDLink/PCM Hammer operations were not tested. No PCM writes or flashes were performed. Do not promote to a public release.
