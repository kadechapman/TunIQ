# Run121 — Negated VATS request admission guard

**Scope:** Source-only P01 natural-language calibration request review. This is not a controller-specific calibration definition, executable Windows validation, or hardware write approval.

## Reproduced defect

In Run120, a request such as **"Do not disable VATS; just set fans on at 210 F and off at 190 F"** could be parsed as an affirmative `vats-disable` action because the VATS parser matched the substring `disable VATS`. The P01 review could report `ready: true` and the proposal builder could offer a VATS-disable action even though the operator explicitly instructed the opposite.

## Change

`src/calibration-request-coverage.js` now flags explicit negative/preservation statements about VATS (for example, *do not disable*, *never remove*, *keep enabled*, *must remain on*, *don't want disabled*) as `vats-intent-contradiction`. Any such statement blocks the **entire** automatic P01 plan, including when another clause requests VATS disable. `buildGoalProposal()` independently recomputes coverage from the request text to prevent callers from stripping the unresolved list in a pre-parsed object.

`tests/p01-universal-request-simulations.js` reproduces the original defect (red regression), checks additional negative and contradictory forms, verifies a pre-parsed bypass attempt is rejected, and confirms a simple affirmative VATS request is not falsely blocked.

## Owner's first development test scope

- **VATS:** This fix prevents intent inversion. A reviewed P01 request still requires trusted controller/OS identification, matching BIN/XDF/parameter-map evidence, backups, and separate explicit approval. No VATS addresses or values were generated here.
- **Electric fans:** Fan output enablement is **not** fan-temperature mapping. Verify exact OS output controls, relay/fuse/wiring, and independently reviewed fan-on/off values. No guessed thresholds or pin assignments.
- **Physical LSX Stage 2 cam:** Wait for the exact cam card, engine hardware details, and baseline logs; do not apply a generic ghost-cam preset as a physical cam tune.
- **Knock sensors:** Diagnose physical sensors/harness and knock-control behavior. Automatic knock-protection disable remains blocked.

## Verification limitations

Tests are Linux/offline source-level checks only. No genuine npm lockfile, native Windows Electron launch, staged/packaged/delivered executable, full tuning application, physical ECU/OBD read, Test Write, write, or flash was verified. Do not call this user-testing-ready or release-ready.
