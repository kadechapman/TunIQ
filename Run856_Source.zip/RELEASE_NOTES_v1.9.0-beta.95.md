# TunIQ v1.9.0-beta.95 — Serial-Open Retry Guard

Source-only development checkpoint, October 17, 2026. No physical ECU communication, Test Write, write, or flash.

## Reproduced defect

Beta.94 accepted `Opened serial port COM4` or `Serial port COM4 opened` followed by `Unknown option --device` and a Usage footer as permission for another read-only CLI profile. The typed `COM4:elm` fallback also accepted the same serial-open evidence followed by `Unknown serial device type "elm"`. Both were reproduced using offline fixtures. Opening a COM handle is not evidence that it was never owned.

## Fix

`src/pcmhammer-integrated.js` now classifies affirmative serial-port-open logs as COM activity, even if a Usage footer follows. The shared activity classifier blocks both `safeToRetryProfile()` and `safeTypedDeviceFallback()`. Added six offline regression cases (three per retry path), including Read Properties and Full Read. No write path changed.

## Release boundary

This is **not** a verified Windows build, physical OBDLink/PCM Hammer test, or public release. The guard is text-based and does not prove physical handle release. Retain the nine launch blockers, especially the missing reviewed npm lockfile, clean Windows install, and physical read-only hardware evidence. No physical writes or flashes.
