# Run72 — Electron renderer navigation lockdown (offline verification)

## Scope

The Electron `BrowserWindow` in `src/main.js` loads TunIQ's local renderer with
`contextIsolation: true`, `nodeIntegration: false`, and `sandbox: true`, but
previously had no explicit renderer-navigation or popup restrictions.
An unexpected renderer-initiated navigation or popup could expose the preload
bridge outside the intended local UI. No exploit or real Electron navigation
was performed; this is a source-observed defense-in-depth gap.

## Change

- `src/renderer-navigation-guard.js` installs fail-closed `will-navigate`,
  `will-frame-navigate`, `will-redirect`, and `will-attach-webview` handlers,
  plus a popup handler that always returns `{ action: 'deny' }`.
- `src/main.js` installs the guard immediately after `BrowserWindow` creation,
  before the local `index.html` is loaded. No renderer-initiated top-level
  navigation is needed for TunIQ's single-document UI.
- The guard never launches external URLs. The application's existing explicit
  main-process IPC allowlist remains responsible for approved external links.
- Added dependency-free EventEmitter-based regression tests and wired them into
  the installer admission tests and offline Windows CI workflow.

## Verification boundaries

- Tests use fake Electron `webContents`; they do **not** prove native Electron
  runtime behavior or Windows compatibility.
- No dependency installation, native Windows build, installer, ECU connection,
  calibration write, Test Write, or flash was attempted.
- `npm test` may be incomplete due to the pre-existing long-running suite;
  the per-run test report records the actual outcome and exit evidence.
- A real Windows/Electron smoke test must confirm that `loadFile` succeeds,
  that internal UI navigation still works, and that popup/navigation denial
  does not disrupt legitimate actions.

**Release status:** source-only, NOT READY FOR USER TESTING or PUBLIC RELEASE.
