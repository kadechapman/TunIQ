# Run106: Packaged Windows preview executable integrity

This checkpoint adds an independent, offline AMD64 Windows GUI PE image check.
The Windows preview build now records `packaged-executable-integrity.json` after
copying the packaged EXE. The GitHub Windows CI job independently verifies the
copied executable against that evidence before uploading the preview artifact.

The check rejects missing/short/placeholder executables, invalid PE headers,
wrong architecture or subsystem, symlinks, and SHA-256/size mismatches. The
JSON includes only fixed fields, byte count and digest, not private user paths.

**Limit:** a syntactically valid PE and matching digest do not prove a runnable
Electron process. Separate native isolated renderer, staged preview, and
packaged preview startup evidence remain mandatory. A preview is not the full
TunIQ application. ECU hardware must remain disconnected; no writes or flashes.

To run the offline synthetic test: `npm run test:windows-pe-integrity`.
On Windows, run `powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1`.
After a successful run, review `dev-build-output/Run97-Diagnostics-*/` for the
three native smoke proofs, the build outcome, `diagnosis.json`, and the new PE
integrity JSON. Keep raw logs private until checked for sensitive paths.
