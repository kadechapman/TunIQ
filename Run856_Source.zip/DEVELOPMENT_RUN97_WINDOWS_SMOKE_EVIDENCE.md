# Run97 — Windows packaged preview smoke evidence and failure diagnostics

The Windows-only build remains unverified in this Linux environment. This change improves proof collection rather than claiming a Windows executable exists.

- `tools/readonly-preview-main.js` emits a **one-shot nonce-bound JSON smoke report** only when the trusted Windows build script requests it. The report is written with exclusive creation inside the disposable `TunIQ-preview-<guid>` temporary folder. If writing requested evidence fails, the Electron smoke process exits nonzero. No ECU, flash, device, or production main-process code was added.
- `tools/windows-build-offline-preview.ps1` requires **both** successful packaged process exit and matching smoke evidence before copying a Windows executable. The evidence must attest `offline-renderer-ready`, `hardwareAvailable: false`, and `writeHandlersRegistered: false`. It preserves a PowerShell transcript and a reviewed genuine npm-generated lockfile candidate in `dev-build-output/Run97-Diagnostics-<guid>/` before dependency installation. If npm or Electron fails, the diagnostics path is printed. The script never overwrites an earlier output folder.
- `tests/readonly-preview-build-simulations.js` covers the evidence path, exclusive creation, nonce, rejection of outside paths, and Windows script's fail-closed contract. These are **offline simulations**, not Windows execution.

## Windows run instructions

On Windows 10/11 x64, Node.js 20+, with official npm registry access, extract the complete source and run from its root in PowerShell (vehicle hardware disconnected):

```powershell
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

On failure, inspect `dev-build-output/Run97-Diagnostics-<guid>/windows-build-transcript.txt` and, if dependency resolution completed, `package-lock.candidate.json`. Review the transcript for private machine paths before sharing. On success, the **offline UI-only** executable is in `dev-build-output/Run97-Offline-UI-Preview/`, alongside `PACKAGED_SMOKE_EVIDENCE.json`. The preview cannot tune, read, write, or flash an ECU. A passing preview is **not** a verified full TunIQ Windows application.

## Unverified gates

No actual Windows build, packaged executable launch, native Electron runtime, npm lockfile installation, or full-app startup was verified in this development environment. Do not label the full application ready for user testing or public release.
