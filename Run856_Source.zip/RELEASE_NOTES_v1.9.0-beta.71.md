# TunIQ 1.9.0-beta.71 — source-only safety checkpoint

- PCM Hammer child-process `error` no longer clears session/PID ownership, marks the hardware transaction closed, or releases the COM lease before the child emits `close`.
- A failed child is finalized once after confirmed `close` with `cli-process-error`, without retrying a different CLI profile or COM port.
- An interrupted Full Read is rejected and any partial output is retained as `.rejected-*` evidence rather than imported as a verified backup.
- Added synthetic child error-before-close and partial Full Read regressions. No ECU, adapter, Windows native CLI, or physical write was tested.

**Not a Windows-tested installer, user-test-ready build, or public release.** Dependency lockfile, clean Windows installation, signed installer, verified PCM Hammer CLI/kernel distribution, physical read-only hardware qualification, licensing, secure updates, privacy, third-party redistribution, and recovery procedures remain release blockers.
