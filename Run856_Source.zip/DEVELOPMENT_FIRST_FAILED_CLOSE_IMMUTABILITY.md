# TunIQ beta.108 — first failed child-close evidence immutability

**Scope:** Offline read-only PCM Hammer COM transaction accounting. Source-only development checkpoint; **not** a user beta, Windows certification, or hardware qualification. No physical ECU access, Test Write, write, or flash.

## Baseline and reproduced defect

Based on the newest verified TunIQ Library source, `TunIQ_beta108_dev_Preparation_Token_Spawn_Guard_Source.zip` (SHA-256 `e0a4530c421b3289d706b7ec136de5f378e0c432e127a44945180ce7158ba3ba`, 561/561 manifest entries). Compared with the preceding `TunIQ_beta108_dev_Late_Child_Start_Immutability_Source.zip` checkpoint.

Before the fix, after a child was recorded closed with `stopCode: cli-syntax-rejected`, a second failure close for the same port, operation and session could replace the first stop code with `adapter-open-failed`. That changed `canAttemptControlledReopen()` from false to true without a new child process, creating a false software basis for automatic COM reopening. Reproduced with a temporary offline transaction ledger; **no actual serial port opened**.

## Fix

- `src/p01-hardware-transaction.js`: once a child is `process-closed`, reject any further **failed** child-close callback without modifying the first stop code, timestamp, communication flag or history. A verified finalizer success may still promote that same closed child.
- `src/flash.js`: finalization no longer emits a redundant failed child-close event after the child handler already recorded the first failed close; successful finalization remains allowed. This preserves the production CLI lifecycle while keeping the first failure authoritative.
- `tests/p01-hardware-transaction-simulations.js`: regression assertions reject forged adapter-open failure, duplicate identical failure, evidence mutation and reopen eligibility.

## Verification limits

The regression and selected recovery/lease/watchdog simulations are offline only. A complete `npm test` run was attempted but did not complete within the bounded execution window; it is **not** counted as passed. Run a clean-extracted full suite and a clean Windows installer test before any user-testing declaration. A missing npm lockfile, licensing, secure updates, signing, privacy/redistribution reviews, physical OBDLink evidence, independent matching Full Reads, interrupted-read recovery, exact-OS calibration/checksum qualification and AI approval boundaries still block public release.
