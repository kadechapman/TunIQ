# Inter-operation COM cooldown ownership guard — development checkpoint

This unpromoted beta.108 change hardens the *ordinary* Windows PCM Hammer
inter-operation cooldown (`settleBeforeOpen`). It does not modify or enable
ECU-writing functionality.

## Reproduced failure

The previous implementation awaited the COM cooldown and then unconditionally
persisted `ready-to-open`. If a different project/port replaced the transaction
while the timer was pending, the stale timer changed the new transaction's state
and could authorize a subsequent COM open. This was reproduced with an offline,
controlled promise: project A/COM8 began a cooldown; project B/COM9 replaced it;
the old timer marked B `ready-to-open`.

## Fail-closed behavior

- A new `begin` cannot overwrite a `process-running` PCM Hammer child record.
- Each preparation receives a monotonic per-transaction sequence, including
  repeated attempts for the same project, port, and operation.
- Only the matching `preparing` state can enter an ordinary cooldown; a second
  concurrent settle or a mismatched port is denied.
- After asynchronous cooldown, the transaction ID, preparation sequence,
  project, operation, port, and expected state must still match. A changed
  transaction throws instead of modifying the replacement record.
- Normal uninterrupted cooldowns continue to reach `ready-to-open`.

## Qualification boundaries

Regression coverage uses injected clocks and promise-based sleeps. No real
COM port, OBDLink, Windows kernel, PCM, read, Test Write, write, or flash was
accessed. The ledger is not a cross-process atomic lock; physical exclusive
ownership and Windows child-process shutdown still require separate supervised
read-only qualification. No claim of hardware verification or runnable Windows
build is made.

## Recovery

On a cancelled cooldown, preserve the current transaction and do not retry a
stale operation. Re-run the read-only preflight and exclusive-process check
for the currently selected project/port. Never automatically switch to another
COM port or initiate a PCM write.
