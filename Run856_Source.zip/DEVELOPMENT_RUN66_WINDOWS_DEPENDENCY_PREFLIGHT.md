# Run66 — Offline Windows Dependency Lock Preflight

## Scope

Source-only development on `dev/run66-windows-dependency-preflight`, based on the verified Run65 Git bundle. No ECU device access, write, flash, dependency installation, Windows executable, or installer was attempted.

## Actual issue

The Windows source-validation workflow had a `Test-Path package-lock.json` check, which proves only that a file exists. It does not reject an invalid, mismatched, symlinked, or oversized lockfile before attempting `npm ci`. The current source checkpoint has **no package-lock.json**, so its locked Windows dependency job remains blocked.

## Changes

- `tools/windows-dependency-preflight.js`: dependency-free, read-only bounded JSON inspection of `package.json` and `package-lock.json`, rejecting unsafe files, unsupported lock format, stale root/dependency versions, unpinned direct dependencies, missing direct resolutions/integrity, and conflicting npm shrinkwrap. Emits machine-readable blockers and explicitly marks Windows/native/hardware verification false.
- `tests/windows-dependency-preflight-simulations.js`: synthetic filesystem regressions; no network, hardware, or installer.
- `.github/workflows/windows-public-beta.yml`: run preflight fixtures and nonblocking blocker report in the independent Windows offline job; enforce strict preflight **before** `npm ci` in the locked dependency job.
- `tests/installer-release-gate-simulations.js`: assert the preflight is present and correctly ordered, and run the new fixtures as part of the existing 76-group suite without weakening the installer release gate.
- `package.json`: add a targeted offline test command and syntax checks.

### CLI

```
node tools/windows-dependency-preflight.js --report
node tools/windows-dependency-preflight.js --require-lock
npm run test:windows-dependency-preflight
```

`--report` returns exit 0 while explicitly reporting blockers; strict mode returns exit 2 when lock metadata is not acceptable. Neither mode installs anything.

## Limits and release status

A valid metadata result does **not** verify transitive dependencies, npm install reproducibility, Windows compatibility, signing, physical ECU hardware, or a runnable app. The existing installer admission barrier remains fail-closed. The current real checkpoint reports `lockfile-missing`. The next prerequisite is obtaining a real npm-generated lockfile in a network-enabled environment, then validating it using `npm ci` on Windows and running the full test suite. Do not generate a synthetic production lockfile.
