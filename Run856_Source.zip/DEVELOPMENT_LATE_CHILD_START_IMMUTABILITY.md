# TunIQ beta.108 — late PCM Hammer child-start immutability guard

October 17, 2026 (America/Chicago). Bounded source-only safety change. **No physical ECU access or write operation was attempted.**

## Verified starting point

Latest TunIQ Library archive: `TunIQ_beta108_dev_Finalized_Close_Immutable_Source.zip` (SHA-256 `2d61cd7b12e29451d445a5cace98780171a8d88f6adb247ecc75c5c6d1a16273`). Its 559-file source manifest and ZIP CRC were checked before editing. Compared against the prior reconciled child-close archive (`d8e801fa7966d80e59afb0f64a852fce6899decaf4e0f0f7a166416450329226`).

## Reproduced failure

A delayed `markProcessStarted()` callback after `markProcessClosed({ success: true })` could change `operation-complete` to `process-running` and append a new process-start event. A stale child-start callback could also revive a preparation explicitly stopped before spawning the CLI. Both would corrupt evidence of Full Read completion or refusal. The first was reproduced on the unchanged Library source using a temporary, offline Windows-platform transaction manager. This is not physical COM verification.

## Correction

`src/p01-hardware-transaction.js` rejects child-start callbacks when the recorded transaction is `operation-complete` or `stopped`, before calling `save()`. Existing live-child rejection remains. `tests/p01-hardware-transaction-simulations.js` asserts both refusals and byte-equivalent snapshot/history preservation. A new `begin()` remains the path to prepare another operation. No ECU write/flash code was changed.

## Limitations and release blockers

This only guards the local transaction ledger against stale callbacks. It does **not** provide atomic process-spawn/COM ownership on Windows or demonstrate that a physical adapter is free. Windows PCM Hammer CLI/kernel compatibility, a reproducible lockfile and clean Windows installer, two matching independent physical Full Reads, interruption/recovery testing, exact-OS calibration/checksum/backup qualification, licensing, signing, privacy, secure updates, third-party rights and incident response remain outstanding. No public release or user-testing readiness claim is warranted.
