# Safe Full Read output path and interrupted-read recovery

This is source-only guidance for a **restricted read-only beta**. It does not establish physical PCM recovery safety.

1. Save a new Full Read to a local, real directory with a new ordinary `.bin` filename. Avoid Windows device names (`NUL`, `CON`, `PRN`, `AUX`, `COM1`–`COM9`, `LPT1`–`LPT9`, superscript `COM¹`/`COM²`/`COM³` and `LPT¹`/`LPT²`/`LPT³`, `CONIN$`, `CONOUT$`) even with `.bin` suffix, colons or other invalid Win32 filename characters, trailing spaces or dots, and junction/symlink folders. Network/UNC shares (`\\server\share`), Win32 device or extended-length namespaces (`\\.\`, `\\?\`, `\??\`) and drive-relative paths (`C:read.bin`) are not supported as protected backup destinations.
2. If a read stops, do not rename, overwrite, or treat the incomplete BIN as a verified backup. Preserve it for diagnostics, along with the read log and session ID.
3. Confirm that PCM Hammer and TunIQ have released the adapter; close conflicting serial applications. Do not use a Test Write, calibration write, full write or recovery flash to troubleshoot a failed read.
4. Before retrying, re-identify the exact COM port and ECU OS using read-only steps, then select a **new** output filename. Never reuse the partial file path.
5. Require two independent complete Full Reads with matching SHA-256 and consistent ECU identity before treating the backup as validated. Physical tests must be supervised and logged separately.

The output-path checks are repeated but are **not atomic**; a concurrent external process can still change filesystem state between checks. The Windows installer, kernel provenance, hardware ownership and interrupted-read behavior have not been qualified.

The beta.57 read-only path guard passes an absolute, preflight-checked destination to PCM Hammer even when the user originally entered a relative filename. Confirm the final path displayed in the session log before interpreting any output as a verified backup.

Beta.60 adds a final unused-destination check before every PCM Hammer CLI attempt, including command-profile and COM retries. A file created by another process after preflight is preserved and is not quarantined. The check is not atomic; avoid shared output directories and concurrent writers.

Beta.61 checks raw Windows device/UNC namespace syntax before path normalization. This is a conservative destination policy, not a guarantee against filesystem races or loss of power during a read.

Beta.63 adds a conservative command-profile retry stop when PCM Hammer logs adapter initialization, diagnostic traffic or a loaded kernel before an error/help footer. Treat these failures as possible live-communication interruptions: preserve any partial BIN, release the COM port and re-identify using read-only steps before a new filename/read attempt. This is simulated logic only, not verified physical recovery.

Beta.64: A recovery or stop request may take time to terminate PCM Hammer. TunIQ now retains the active session and COM ownership until the child process reports exit; do not open a new serial session or run Bluetooth repair while termination is pending. If process termination is not confirmed, close conflicting tools and resolve the process state before retrying. This is a software safety guard, not a physical Windows COM ownership test.

Beta.65: Bluetooth SPP repair, manual COM verification and manual PCM Hammer handoff now refuse to proceed while a PCM Hammer process is still running, terminating or preparing. Wait for the child process to exit before retrying; never force a Bluetooth repair or manual COM probe into a live Full Read. The external serial lease also blocks a new PCM Hammer start until repair/probe completes. This is a Linux-tested software guard, not physical Windows qualification.

## beta.66: CLI probe during an active read

A help/version probe is not a recovery action. If TunIQ reports that PCM Hammer still owns or is preparing the adapter, wait for the current read or termination to finish before retrying the probe. The probe must not cancel the read, replace the executable pin, or start another CLI process. Preserve partial read output; restart any failed Full Read only into a new unused local path. This is source-tested only, not Windows hardware-verified.
