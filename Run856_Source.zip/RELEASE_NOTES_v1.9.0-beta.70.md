# TunIQ 1.9.0-beta.70 — source-only checkpoint

- Refuse Bluetooth repair when persistent serial-session disconnect fails; no silent COM handoff.
- Handle asynchronous Windows `taskkill.exe` errors without crashing the process. The PowerShell child `close` event remains required before declaring the bridge released.
- Add synthetic regressions for failed disconnect and taskkill failure, without real serial hardware or PCM writes.

Not a runnable or hardware-verified Windows release. Do not promote to public beta without clean Windows installation, physical read-only qualification, dependency lockfile, signing, licensing, privacy and update security reviews.
