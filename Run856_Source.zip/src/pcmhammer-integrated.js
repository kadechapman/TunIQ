const fs = require('fs');
const path = require('path');
const { checkUnusedReadDestination } = require('./read-output-safety');

const INTEGRATED_PROFILES = Object.freeze([
  {
    id: 'official-2x-cli-flags-device', label: 'PCM Hammer 2.x CLI operation flags (--device)',
    templates: {
      readProperties: ['--get-properties', '--device', '{device}'],
      read: ['--read', '{output}', '--device', '{device}'],
      testWrite: ['--test-write', '{input}', '--device', '{device}'],
      writeCalibration: null,
      writeFull: ['--write', '{input}', '--device', '{device}'],
      recovery: null
    }
  },
  {
    id: 'official-2x-long-port', label: 'PCM Hammer 2.x long options (--port)',
    templates: {
      readProperties: ['read-properties', '--port', '{device}'],
      read: ['read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-device', label: 'PCM Hammer 2.x long options (--device)',
    templates: {
      readProperties: ['read-properties', '--device', '{device}'],
      read: ['read-full', '--device', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--device', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--device', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--device', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--device', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-long-interface', label: 'PCM Hammer 2.x long options (--interface)',
    templates: {
      readProperties: ['read-properties', '--interface', '{device}'],
      read: ['read-full', '--interface', '{device}', '--output', '{output}'],
      testWrite: ['test-write', '--interface', '{device}', '--input', '{input}'],
      writeCalibration: ['write-calibration', '--interface', '{device}', '--input', '{input}'],
      writeFull: ['write-full', '--interface', '{device}', '--input', '{input}'],
      recovery: ['recovery', '--interface', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-short', label: 'PCM Hammer 2.x short options',
    templates: {
      readProperties: ['read-properties', '-p', '{device}'],
      read: ['read-full', '-p', '{device}', '-o', '{output}'],
      testWrite: ['test-write', '-p', '{device}', '-i', '{input}'],
      writeCalibration: ['write-calibration', '-p', '{device}', '-i', '{input}'],
      writeFull: ['write-full', '-p', '{device}', '-i', '{input}'],
      recovery: ['recovery', '-p', '{device}', '-i', '{input}']
    }
  },
  {
    id: 'official-2x-flags', label: 'PCM Hammer 2.x operation flags',
    templates: {
      readProperties: ['--read-properties', '--port', '{device}'],
      read: ['--read-full', '--port', '{device}', '--output', '{output}'],
      testWrite: ['--test-write', '--port', '{device}', '--input', '{input}'],
      writeCalibration: ['--write-calibration', '--port', '{device}', '--input', '{input}'],
      writeFull: ['--write-full', '--port', '{device}', '--input', '{input}'],
      recovery: ['--recovery', '--port', '{device}', '--input', '{input}']
    }
  },
  {
    id: 'official-2x-positional', label: 'PCM Hammer 2.x positional arguments',
    templates: {
      readProperties: ['read-properties', '{device}'],
      read: ['read-full', '{device}', '{output}'],
      testWrite: ['test-write', '{device}', '{input}'],
      writeCalibration: ['write-calibration', '{device}', '{input}'],
      writeFull: ['write-full', '{device}', '{input}'],
      recovery: ['recovery', '{device}', '{input}']
    }
  }
]);

function profileById(id) { return INTEGRATED_PROFILES.find(profile => profile.id === id) || null; }
function profileMatchingTemplate(operation, template) {
  const encoded = JSON.stringify(Array.isArray(template) ? template : []);
  return INTEGRATED_PROFILES.find(profile => JSON.stringify(profile.templates?.[operation] || null) === encoded) || null;
}
function isRecognizedPcmHammerExecutable(executable = '', backend = null) {
  const name = path.basename(String(executable || '')).toLowerCase();
  return /pcm\s*hammer|pcmhammer/.test(String(backend?.product || '')) || /pcmhammer.*(?:cli|console)|(?:cli|console).*pcmhammer/.test(name);
}
// Terminal color formatting can split otherwise fatal PCM Hammer diagnostics
// (for example, "CRC <SGR>errors: 2"). Remove ONLY ordinary ANSI SGR color
// sequences before making safety decisions. Other C0/C1 controls (including
// backspace, NUL and DEL) can hide or overwrite an error counter in rendered
// logs. A bare carriage return can overwrite a progress line or split an
// error keyword (e.g. CRC err\rors: 2). Only paired CRLF is unambiguous.
// Unicode default-ignorable format characters (zero-width joiners, bidi
// overrides, variation selectors, BOM, etc.) can also split fatal keywords;
// Unicode U+2028/U+2029 line separators evade the CRLF/LF line parser.
// Reject ambiguous diagnostics before accepting a read or retrying a CLI
// profile. Preserve ordinary printable Unicode, TAB, LF, and paired CRLF.
function normalizeCliDiagnosticText(text = '') {
  return String(text || '').replace(/\x1b\[[0-9;]*m/g, '');
}
function hasUnrecognizedCliEscape(text = '') {
  const source = normalizeCliDiagnosticText(text);
  return /\r(?!\n)|[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]/.test(source) ||
    /[\p{Default_Ignorable_Code_Point}\u2028\u2029]/u.test(source);
}
// Explicit read-data integrity failures must block BOTH evidence promotion
// and CLI retry. Counted errors can be printed without 'mismatch' or 'failed'
// (e.g. 'CRC errors: 2'); zero counters are not failure evidence.
// A counter is only safe when its complete value is explicitly zero (or
// "none"). Unknown/malformed counter values are not proof of a clean read.
// In particular, +2, -1, 0b10 and malformed 0xG2 must not be interpreted as
// harmless by a narrower decimal/hex regex. This is offline log parsing only.
function unsafeIntegrityCounter(token) {
  const value = String(token || '').replace(/[.,;:)\]]+$/, '');
  return !/^(?:\+?0+|0x0+|0b0+|none)$/i.test(value);
}
function hasReadIntegrityFailure(text = '') {
  return String(text || '').split(/\r?\n/).some(line => {
    // Inspect EVERY counter on the line: a clean CRC count cannot mask a
    // later failing hash count in a combined status message.
    const forward = [...line.matchAll(/\b(?:crc|checksum|hash)\s+(?:errors?|failures?|mismatches?)\s*(?:(?:count|total)\s*)?[:=]\s*(\S*)/gi)];
    const reverse = [...line.matchAll(/(?:^|\s)([+-]?(?:0[xb][0-9a-z]+|\d[\d,._]*))\s+(?:crc|checksum|hash)\s+(?:errors?|failures?|mismatches?)\b/gi)];
    return forward.some(match => unsafeIntegrityCounter(match[1])) ||
      reverse.some(match => unsafeIntegrityCounter(match[1])) ||
      /\b(?:(?:crc|checksum|hash)(?:\s+(?:check|verification))?\s+(?:mismatch|failed|failure|error|invalid)|(?:mismatched|invalid|incorrect|failed)\s+(?:crc|checksum|hash))\b/i.test(line) ||
      /\b(?:crc|checksum|hash)\s+(?:does|did)\s+not\s+match\b/i.test(line) ||
      // CLI builds may emit structured status fields rather than a sentence.
      // A failed CRC/checksum/hash check defeats a later success footer.
      /\b(?:crc|checksum|hash)(?:\s+(?:check|verification|validation|comparison|result))?\s*[:=-]\s*(?:fail(?:ed|ure)?|error|mismatch|invalid|bad)\b/i.test(line);
  });
}
// Different PCM Hammer CLI builds describe failed memory chunks as blocks,
// sectors or pages. Treat explicit failed chunk access as fatal even if a
// later success footer appears. This is diagnostic classification only.
function hasReadUnitFailure(text = '') {
  return String(text || '').split(/\r?\n/).some(line =>
    /\b(?:failed|unable|could\s+not)\s+(?:to\s+)?read\s+(?:block|sector|page)\b/i.test(line) ||
    /\b(?:read\s+)?(?:block|sector|page)\s+(?:0x[0-9a-f]+|\d+)\b[^\r\n]{0,100}\b(?:read\s+)?(?:failed|failure|error|timeout|timed\s*out|aborted)\b/i.test(line));
}
// Negated or explicitly failed read completion is never positive read proof.
// Some CLI wrappers print a generic success footer or Usage after an earlier
// `Read completed: false` status. The former must not certify a backup and
// the latter must not authorize another automatic COM-port attempt.
function hasReadCompletionFailure(text = '') {
  return String(text || '').split(/\r?\n/).some(line =>
    /\b(?:full\s+)?read(?:\s+operation)?\s+(?:not\s+(?:complete(?:d)?|successful)|(?:complete(?:d)?|successful)\s*[:=]\s*(?:false|no|0|failed|failure)|(?:complete(?:d)?\s+)?unsuccessful(?:ly)?|(?:status|result)\s*[:=]\s*(?:failed|failure|incomplete|aborted|cancelled|canceled|false)|(?:was\s+)?(?:aborted|cancelled|canceled|incomplete))\b/i.test(line) ||
    /\b(?:full\s+)?read\s+(?:did\s+not|could\s+not|couldn't)\s+(?:complete|finish|succeed)\b/i.test(line));
}
// Kernel/loader transfer or startup failures are runtime evidence, even when
// the CLI prints a successful read footer or a parser Usage message afterward.
// Share one detector between result classification and retry/fallback gates:
// otherwise a failed kernel status can reject the read but still launch a
// second CLI process against an adapter whose ownership is uncertain.
function hasKernelTransferFailure(text = '') {
  return String(text || '').split(/\r?\n/).some(line => {
    if (!/\b(?:kernel|loader)\b/i.test(line)) return false;
    const action = /\b(?:upload(?:ing)?|load(?:ing)?|execut(?:e|ion|ing)|start(?:up|ing)?|run(?:ning)?|transfer(?:ring)?|handshake|initializ(?:e|ation|ing))\b/i;
    if (!action.test(line)) return false;
    if (/\b(?:failed|failure|error|timed\s*out|timeout|aborted|cancelled|canceled)\b/i.test(line)) return true;
    // Numeric statuses are not portable between CLI/kernel builds: 0 can
    // mean a boolean false, an OS-style success code, or zero bytes sent.
    // Until the exact CLI/kernel version has been qualified, NONE of these
    // values is affirmative proof of a completed kernel operation. Reject
    // both read evidence and any automatic command-profile/type fallback.
    return /\b(?:upload(?:ing)?|load(?:ing)?|execut(?:e|ion|ing)|start(?:up|ing)?|run(?:ning)?|transfer(?:ring)?|handshake|initializ(?:e|ation|ing))(?:\s+(?:status|result))?\s*[:=]\s*(?:false|no|[+-]?(?:0x[0-9a-f]+|0b[01]+|\d+(?:\.\d+)?))\b/i.test(line);
  });
}
// Runtime ECU/adapter failures sometimes arrive with a generic CLI help
// footer, even before an "Opening COM" log line. Treat these as runtime
// failures, not as permission to try another command profile on the adapter.
function isPcmRuntimeFailure(text = '') {
  if (hasUnrecognizedCliEscape(text)) return true;
  const source = normalizeCliDiagnosticText(text);
  return [
    /\b(?:failed|unable|could\s+not|cannot|can't)\s+(?:to\s+)?(?:connect\s+to|communicate\s+with)\s+(?:the\s+)?(?:PCM|ECM|ECU|controller|adapter|device)\b/i,
    /\b(?:no\s+response\s+from\s+(?:the\s+)?(?:PCM|ECM|ECU|controller|adapter|device)|(?:timed\s+out|timeout)\s+waiting\s+for\s+(?:a\s+)?response)\b/i,
    // Some CLI builds print usage after an ECU block-read failure without
    // writing any output bytes. No file + a usage footer is NOT proof that
    // the adapter/PCM was untouched, so do not try another command profile.
    /\b(?:(?:failed|unable|could\s+not)\s+to\s+read\s+(?:block|sector|page)\b|(?:block|sector|page)\s+(?:0x[0-9a-f]+|\d+)\s+(?:read\s+)?(?:failed|timed\s+out)\b|(?:PCM\s+)?read\s+(?:operation\s+)?failed\s+at\s+(?:address|offset)\b)/i,
    /\b(?:checksum|CRC)\s+(?:mismatch|failed|error)\b/i
  ].some(pattern => pattern.test(source)) || hasKernelTransferFailure(source) || hasReadIntegrityFailure(source) || hasReadUnitFailure(source) || hasReadCompletionFailure(source);
}
// A successful serial-open message means the CLI may have owned the COM port.
// A later syntax/usage footer cannot prove that the adapter was untouched.
// Keep this separate from generic "Opening" messages, which may precede a
// failed open, but both forms prohibit automatic profile/type fallback.
function hasSerialPortOpenedProof(text = '') {
  return /\b(?:opened\s+(?:serial\s+)?port\s+COM\d+|(?:serial\s+)?port\s+COM\d+\s+(?:successfully\s+)?opened)\b/i.test(normalizeCliDiagnosticText(text));
}
function looksLikeCliUsageOnly(text = '') {
  if (hasUnrecognizedCliEscape(text)) return false;
  const source = normalizeCliDiagnosticText(text);
  // A Windows COM-open error is runtime failure even when the CLI appends
  // generic usage text. Never classify that mixed output as syntax-only.
  if (isPortOpenFailure(source) || isPcmRuntimeFailure(source) || hasSerialPortOpenedProof(source)) return false;
  const hasUsage = /\bUsage\s*:/i.test(source) && /\bOperations\s*:/i.test(source);
  const explicitSyntaxStop = /(?:No operation specified|unknown|invalid|unrecognized|unsupported)\s+(?:command|option|argument|verb)?/i.test(source)
    || /(?:required|missing)\s+(?:option|argument|operation)/i.test(source);
  const runtimeProof = hasStrongCommunicationProof(source) || /(?:Opening\s+(?:serial\s+)?port\s+COM\d+|Connected\s+to\s+(?:PCM|ECM|device)|Using\s+(?:device|interface)\s*[:=]|Battery\s+Voltage\s+(?:is\s*)?:|Voltage\s*:\s*\d+(?:\.\d+)?\s*V|Reading\s+block\s+\d+|Uploading\s+kernel|Unlock(?:ed|ing)\s+(?:PCM|ECM)|Erasing\s+flash|Writing\s+flash)/i.test(source);
  return hasUsage && (explicitSyntaxStop || !runtimeProof) && !runtimeProof;
}
function isSyntaxFailure(text = '', exitCode = null) {
  if (hasUnrecognizedCliEscape(text)) return false;
  const source = normalizeCliDiagnosticText(text);
  // Preserve adapter ownership: COM-open failures must not cause command
  // profile cycling, even when the CLI also prints help/usage text.
  if (isPortOpenFailure(source) || isPcmRuntimeFailure(source) || hasStrongCommunicationProof(source)) return false;
  if (looksLikeCliUsageOnly(source)) return true;
  if (/(?:no\s+operation\s+specified|unknown|invalid|unrecognized|unsupported)\s+(?:command|option|argument|verb)|no\s+such\s+(?:command|option)|unexpected\s+(?:argument|option)|required\s+(?:option|argument|operation).*missing|usage\s*:/i.test(source)) return true;
  return Number(exitCode) !== 0 && /(?:help|usage|command line|arguments?|options?)/i.test(source) && !hasCommunicationActivity(source);
}
function isPortOpenFailure(text = '') {
  const source = normalizeCliDiagnosticText(text);
  // Windows/.NET serial exceptions may quote the COM port or report a
  // Windows sharing violation before the CLI prints a generic usage footer.
  // These are runtime I/O failures: command-profile discovery must stop.
  if (/(?:\b(?:the\s+)?(?:serial\s+)?port\s+['"]?COM\d+['"]?\s+(?:does\s+not\s+exist|was\s+not\s+found|is\s+(?:unavailable|denied|busy|in\s+use))\b|\baccess\s+to\s+(?:the\s+)?(?:serial\s+)?port\s+['"]?COM\d+['"]?\s+is\s+denied\b|\b(?:the\s+)?process\s+cannot\s+access\s+the\s+file\s+because\s+it\s+is\s+being\s+used\s+by\s+another\s+process\b)/i.test(source)) return true;
  // Additional Windows driver wording omits "port" or "is" in access
  // denials, or reports a locked COM handle. These must not trigger a second
  // read-only CLI command profile after an adapter ownership failure.
  if (/\baccess\s+to\s+(?:(?:serial\s+)?port\s+)?['"]?COM\d+['"]?\s+(?:is\s+)?denied\b|\b(?:serial\s+)?port\s+['"]?COM\d+['"]?\s+(?:is\s+)?locked\b/i.test(source)) return true;
  return /(?:could\s+not\s+open\s+(?:the\s+selected\s+device|(?:serial\s+)?port|COM\d+)|(?:unable|failed|failure|error|cannot|can't|couldn't)\s+(?:to\s+)?open\s+(?:the\s+selected\s+device|(?:serial\s+)?port|COM\d+)|(?:serial\s+)?port\s+COM\d+[^\n]*(?:failed|failure|could\s+not|unable|cannot|can't|timed\s*out|timeout|does\s+not\s+exist|not\s+found|unavailable)|timed\s+out\s+(?:while|trying)\s+to\s+open\s+(?:the\s+selected\s+device|(?:serial\s+)?port|COM\d+)|open(?:ing)?\s+(?:the\s+selected\s+device|(?:serial\s+)?port|COM\d+)[^\n]*(?:timed\s*out|timeout|failed|failure|denied|busy|in\s+use)|no\s+such\s+(?:serial\s+)?port|port\s+COM\d+\s+(?:does\s+not\s+exist|was\s+not\s+found|is\s+unavailable)|access\s+(?:to\s+the\s+port\s+)?is\s+denied|unauthorizedaccessexception|resource\s+busy|another\s+(?:program|process)[^\n]*(?:using|owns|locked))/i.test(source);
}
// Treat observed adapter initialization, diagnostic requests/responses and
// actual TX/RX frames as COM/ECU activity, even if the CLI subsequently emits
// a generic "Unknown option" or Usage footer. False negatives could cause a
// second profile launch on an adapter that has already been contacted.
function hasStrongCommunicationProof(text = '') {
  const source = normalizeCliDiagnosticText(text);
  if (/\b(?:ELM327|STN\d{3,5})\b[^\n]{0,80}\b(?:initialized|ready|connected)\b/i.test(source) ||
      /\b(?:adapter|interface)\s+(?:initialized|connected|ready)\b/i.test(source) ||
      /^\s*(?:TX|RX)\s*:\s*(?:[0-9a-f]{2}[\s,]*){2,}\s*$/im.test(source) ||
      /\b(?:received|receiving)\s+(?:a\s+)?(?:diagnostic\s+)?response\s+from\s+(?:ECU|PCM|ECM|controller)\b/i.test(source) ||
      /\b(?:sending|sent)\s+(?:a\s+)?(?:diagnostic|OBD|UDS|CAN)\s+(?:request|frame|message)\b/i.test(source) ||
      /\b(?:kernel|loader)\s+(?:loaded|started|running)\b/i.test(source)) return true;
  return /(?:Connected\s+to\s+(?:PCM|ECM|device)|Battery\s+Voltage\s+(?:is\s*)?:|Voltage\s*:\s*\d+(?:\.\d+)?\s*V|VIN\s*:\s*[A-HJ-NPR-Z0-9]{17}|OSID\s*:\s*\d+|Hardware\s+ID\s*:|Service\s+(?:No|Number)\s*:|Controller\s*:\s*(?:P\d+|E\d+)|Reading\s+block\s+\d+|Reading\s+(?:entire\s+)?PCM|Uploading\s+kernel|Kernel\s+(?:uploaded|running)|Unlock(?:ed|ing)\s+(?:PCM|ECM)|Security\s+key\s+(?:accepted|unlocked)|Erasing\s+flash|Writing\s+flash|Programming\s+flash|Verification\s+(?:passed|started))/i.test(source);
}
function hasCommunicationActivity(text = '') {
  if (hasUnrecognizedCliEscape(text)) return true;
  const source = normalizeCliDiagnosticText(text);
  if (looksLikeCliUsageOnly(source)) return false;
  // PCM Hammer can print “Opening serial port COMx” immediately before Windows rejects
  // the handle. That line alone is not proof that PCM communication began.
  if (isPortOpenFailure(source) && !hasStrongCommunicationProof(source)) return false;
  if (hasStrongCommunicationProof(source) || hasSerialPortOpenedProof(source)) return true;
  return /(?:Opening\s+(?:serial\s+)?port\s+COM\d+|Opened\s+(?:serial\s+)?port\s+COM\d+|Connecting\s+to\s+(?:PCM|ECM|device)|Connected\s+to\s+(?:PCM|ECM|device)|Using\s+(?:device|interface)\s*[:=]|Selected\s+(?:device|interface)\s*[:=]|Battery\s+Voltage\s+(?:is\s*)?:|Voltage\s*:\s*\d+(?:\.\d+)?\s*V|VIN\s*:\s*[A-HJ-NPR-Z0-9]{17}|OSID\s*:\s*\d+|Hardware\s+ID\s*:|Service\s+(?:No|Number)\s*:|Controller\s*:\s*(?:P\d+|E\d+)|Reading\s+block\s+\d+|Reading\s+(?:entire\s+)?PCM|Uploading\s+kernel|Kernel\s+(?:uploaded|running)|Unlock(?:ed|ing)\s+(?:PCM|ECM)|Security\s+key\s+(?:accepted|unlocked)|Erasing\s+flash|Writing\s+flash|Programming\s+flash|Verification\s+(?:passed|started))/i.test(source);
}
// A zero-byte partial read, directory, or dangling symlink still owns the path.
// Fail closed on filesystem errors other than ENOENT: retries must never reuse
// an output name that PCM Hammer (or another process) may already have touched.
function outputWasCreated(file) {
  if (!file) return false;
  try { fs.lstatSync(file); return true; }
  catch (error) { return error?.code !== 'ENOENT'; }
}
function safeToRetryProfile({ operation, text, exitCode, output }) {
  if (hasUnrecognizedCliEscape(text)) return false;
  const source = normalizeCliDiagnosticText(text);
  // Node's child `close` reports code=null for signal termination. A usage
  // footer from an interrupted CLI is not proof the adapter was untouched.
  // Retry only after a positive, safe integer syntax-rejection exit.
  // Native Windows exception statuses can be negative or large unsigned values.
  // Only conventional 1..255 parser exits qualify; other exits fail closed.
  if (!Number.isSafeInteger(exitCode) || exitCode <= 0 || exitCode > 255) return false;
  if (!['readProperties', 'read'].includes(String(operation || ''))) return false;
  // A Full Read fallback is safe only for a known, still-unused ordinary
  // destination. A symlink/junction parent, Windows alias, or missing path
  // cannot be treated as evidence that the first CLI attempt touched nothing.
  if (operation === 'read' && !checkUnusedReadDestination(output).ok) return false;
  if (isPcmRuntimeFailure(source) || !isSyntaxFailure(source, exitCode)) return false;
  // A generic Usage/Operations footer can follow an unrelated runtime error.
  // Only an affirmative parser rejection permits another read-only CLI profile.
  const explicitSyntaxRejection = /(?:no\s+operation\s+specified|(?:unknown|invalid|unrecognized|unsupported|unexpected|no\s+such)\s+(?:command|option|argument|verb)|(?:missing|missing\s+required|required|expected)\s+(?:option|argument|operation|port)|(?:option|argument|operation)\s+[^\n]{0,80}\s+(?:missing|required))/i.test(source);
  if (!explicitSyntaxRejection) return false;
  if (hasCommunicationActivity(source)) return false;
  if (outputWasCreated(output)) return false;
  return true;
}
function profilesForOperation(operation, cachedProfileId = '', customTemplate = null) {
  const configured = customTemplate ? [{ id: 'configured-template', label: 'Configured command template', templates: { [operation]: customTemplate } }] : [];
  const cached = profileById(cachedProfileId);
  if (cached?.templates?.[operation]) return [...configured, ...(configured.some(item => JSON.stringify(item.templates[operation]) === JSON.stringify(cached.templates[operation])) ? [] : [cached])];
  const discovered = INTEGRATED_PROFILES.filter(profile => profile.templates?.[operation]);
  if (!configured.length) return discovered;
  if (!['readProperties', 'read'].includes(String(operation || ''))) return configured;
  return [...configured, ...discovered.filter(profile => JSON.stringify(profile.templates[operation]) !== JSON.stringify(customTemplate))];
}
function profileCapabilities(profileId) {
  const profile = profileById(profileId);
  return Object.fromEntries(['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].map(operation => [operation, Boolean(profile?.templates?.[operation])]));
}

module.exports = {
  INTEGRATED_PROFILES,
  profileById,
  profileMatchingTemplate,
  profilesForOperation,
  profileCapabilities,
  isRecognizedPcmHammerExecutable,
  isSyntaxFailure,
  isPcmRuntimeFailure,
  normalizeCliDiagnosticText,
  hasUnrecognizedCliEscape,
  hasKernelTransferFailure,
  isPortOpenFailure,
  hasCommunicationActivity,
  looksLikeCliUsageOnly,
  hasReadIntegrityFailure,
  hasReadUnitFailure,
  hasReadCompletionFailure,
  safeToRetryProfile,
  outputWasCreated
};
