'use strict';

// Request coverage is a read-only admission check, not a calibration definition.
// Do not silently execute the recognized subset of a request containing other
// physical modifications; no guessed BIN addresses or ECM writes belong here.
// An explicit OS identifier in the user's request is a consistency check,
// NOT proof of controller compatibility or a verified BIN/XDF definition.
// Never prepare a partial VATS/fan proposal for a different OS than the
// active project. Only bounded, explicit OS/OS ID syntax is interpreted.
function explicitRequestOsConflict(text = '', activeOs = '') {
  const source = String(text ?? '').slice(0, 2000);
  // Explicit OS labels are consistency claims, not controller evidence. The
  // earlier numeric-only pattern silently ignored malformed values (for
  // example OS ID: 1258760300, OS ID: unknown, or OSID: 12587603A), allowing
  // a VATS/fan request to appear consistent with a different active project.
  // Capture the entire bounded token after an explicit OS label and reject
  // anything other than the exact 7-9 digit active-project identifier.
  // A matching text label still does NOT prove the BIN/XDF/OS relationship.
  const labels = String.raw`(?:os[\s_-]*(?:identifier|number|id)|operating[\s-]+system(?:[\s_-]+(?:identifier|number|id))?|os[\s-]+is|operating[\s-]+system[\s-]+is|os[\s]*[:=#]|os(?=\s+\d))`;
  const explicit = new RegExp(String.raw`\b${labels}\s*(?:is\s*)?(?:[:=#]\s*)?([A-Za-z0-9][A-Za-z0-9._/-]*)`, 'gi');
  const projectOs = String(activeOs ?? '').trim();
  // Run360: An OS can be stated without the literal `OS ID` label, e.g.
  // `my PCM actually runs 12212156`. Previously that contradictory
  // controller-reported claim was ignored and a VATS/fan request appeared
  // ready for the active project. Require a controller subject and a run/use
  // verb (or an explicit OS after a report/read verb). A displacement such as
  // `PCM runs 5.3 liters` and fan counts are NOT OS claims. This is only a
  // consistency check; matching text is never trusted ECU/BIN evidence.
  const controllerClaim = /\b(?:(?:the|my)\s+)?(?:pcm|ecm|ecu|controller)\s+(?:(?:actually|really|currently|now)\s+)?(?:(?:runs?|uses?|(?:is\s+)?running)\s+(?:(?:the\s+)?(?:os|operating\s+system)(?:\s+(?:id|number))?\s*(?:is|[:=#])?\s*)?|(?:reports?|reads?|says?)\s+(?:(?:the\s+)?(?:os|operating\s+system)(?:\s+(?:id|number))?\s*(?:is|[:=#])?\s*))([A-Za-z0-9][A-Za-z0-9._/-]*)/gi;
  for (const match of source.matchAll(controllerClaim)) {
    const candidate = match[1].replace(/\.$/, '');
    if (/^\d{7,9}$/.test(candidate) && candidate !== projectOs) return true;
    // Explicit uncertainty in a controller-reported OS is not an exact match.
    if (/^(?:unknown|pending|unsure|tbd)$/i.test(candidate)) return true;
  }
  for (const match of source.matchAll(explicit)) {
    const id = match[1].replace(/\.$/, '');
    if (!/^\d{7,9}$/.test(id) || id !== projectOs) return true;

    // Run247: A matching first identifier does not establish consistency if
    // the same label offers an unlabelled alternative ("OS ID: 12345678 or
    // 87654321", "OS ID: 12345678, unknown"). Previously the second value
    // disappeared, allowing a partial VATS/fan proposal. Do not interpret an
    // ordinary conjunction like "OS ID: 12345678 and set the fans" as an OS.
    const tail = source.slice(match.index + match[0].length);
    // Run248: A separated slash, "vs"/"versus", or bare parenthesized
    // candidate is also an alternative. Only a numeric/placeholder token
    // triggers a conflict; ordinary explanatory annotations stay allowed.
    // An uncertain alternate is still a conflicting OS claim. Previously
    // "or maybe 12212156", "and/or 12212156", and "(possibly 12212156)"
    // were read as harmless prose because the first token was not numeric.
    // Restrict this to the immediate alternative after the matching OS so
    // ordinary "and inspect the fan wiring" instructions remain valid.
    // Run317: Natural-language uncertainty can put "it might be" or "I
    // think" between the separator and the alternate identifier. Treat that
    // as an unresolved OS conflict, not an authorized exact-OS match.
    // A short number followed by "fans" is a fan count, not another OS.
    // Run318: A comma/semicolon can precede a conversational separator:
    // "OS ID: 12587603, or it could be 12212156". The earlier parser
    // consumed only the comma, then treated "or" as harmless text. Likewise
    // "or I think it is 12212156" must reach the candidate, not stop at
    // "it". Neither form is evidence of an exact-OS match.
    // Run319: An alternative matching the active OS does not terminate the
    // claim. A later candidate in the SAME bounded chain may contradict it:
    // "OS ID: 12587603 or 12587603 or 12212156". Stop at ordinary prose,
    // fan counts or a bounded number of candidates; do not scan unrelated
    // request text for unlabelled numbers.
    const alternativePattern = /^\s*(?:\(\s*)?(?:(?:[,;]\s*)?(?:and\s*\/\s*or|or|and|but|vs\.?|versus|&|\||\/|[,;])\s*)?(?:(?:maybe|possibly|perhaps|probably)\s+)?(?:(?:it\s+(?:(?:might|could|may)\s+be|is)|i\s+think(?:\s+it\s+is)?|a|an|os\s+(?:(?:might|could|may)\s+be|is))\s+)?(?:(?:os[\s_-]*(?:identifier|number|id)?|operating[\s-]+system(?:[\s_-]+(?:identifier|number|id))?)\s*(?:[:=#]\s*)?)?([A-Za-z0-9][A-Za-z0-9._/-]*)/i;
    let remaining = tail;
    let index = 0;
    for (; index < 12; index++) {
      const alternative = alternativePattern.exec(remaining);
      if (!alternative) break;
      const candidate = alternative[1].replace(/\.$/, '');
      const afterCandidate = remaining.slice(alternative[0].length);
      const fanCount = /^\d{1,2}$/.test(candidate) &&
        /^\s+(?:(?:electric|cooling|radiator)\s+)?(?:fans?|relays?)\b/i.test(afterCandidate);
      if (fanCount) break;
      if (/\d/.test(candidate) || /^(?:unknown|tbd|n\/?a|pending|unsure)$/i.test(candidate)) {
        if (!/^\d{7,9}$/.test(candidate) || candidate !== projectOs) return true;
        remaining = afterCandidate;
        continue;
      }
      break;
    }
    // Do not silently ignore an excessive chain after the bounded scan.
    if (index === 12 && alternativePattern.test(remaining)) return true;
    // Run350: A controller-reported correction can be written as a short
    // parenthetical without "or" or a second explicit OS label:
    // "OS ID: 12587603 (the PCM actually runs 12212156)". The earlier
    // alternative parser stopped at "the" and accepted the conflicting
    // request. Only inspect the immediately adjacent parenthetical; do not
    // interpret unrelated engine displacement or fan-count prose as an OS.
    const controllerCorrection = /^\s*\(\s*(?:(?:but|however)\s+)?(?:(?:the|my)\s+)?(?:pcm|ecm|ecu|controller)\s+(?:(?:actually|really|currently)\s+)?(?:runs?|uses?|reports?|has)\s+(?:(?:os|operating\s+system)\s*(?:id\s*)?[:=#]?\s*)?([A-Za-z0-9][A-Za-z0-9._/-]*)\s*\)/i.exec(tail);
    if (controllerCorrection) {
      const corrected = controllerCorrection[1].replace(/\.$/, '');
      if ((/\d/.test(corrected) || /^(?:unknown|tbd|n\/?a|pending|unsure)$/i.test(corrected)) &&
          (!/^\d{7,9}$/.test(corrected) || corrected !== projectOs)) return true;
    }
    // Run355: A controller-reported correction can also follow the first OS
    // claim as contrasting prose, rather than a parenthetical or repeated
    // OS label: "OS ID: 12587603, but the PCM actually runs 12212156".
    // Require an immediate contrast + controller subject; don't scan later
    // unrelated numbers, and don't confuse "PCM has 2 fan outputs" with an OS.
    // This is an inconsistency check, never evidence of a verified ECM OS.
    const contrastedController = /^\s*(?:\(\s*)?(?:[,;]\s*)?(?:but|though|however|although)\s+(?:(?:the|my)\s+)?(?:pcm|ecm|ecu|controller)\s+(?:(?:actually|really|currently)\s+)?(?:runs?|uses?|reports?|has|is|reads?|says?)\s+(?:(?:os|operating\s+system)\s*(?:id\s*)?[:=#]?\s*)?([A-Za-z0-9][A-Za-z0-9._/-]*)/i.exec(tail);
    if (contrastedController) {
      const corrected = contrastedController[1].replace(/\.$/, '');
      const after = tail.slice(contrastedController[0].length);
      const countOrDisplacement = /^(?:\d{1,2}|\d\.\d)$/.test(corrected) &&
        /^\s+(?:fans?|relays?|outputs?|cylinders?|liters?|engine)\b/i.test(after);
      if (!countOrDisplacement &&
          (/\d/.test(corrected) || /^(?:unknown|tbd|n\/?a|pending|unsure)$/i.test(corrected)) &&
          (!/^\d{7,9}$/.test(corrected) || corrected !== projectOs)) return true;
    }
  }
  return false;
}

function unresolvedCalibrationRequests(text = '', recognizedIntents = []) {
  const source = String(text ?? '').slice(0, 2000);
  const intents = Array.isArray(recognizedIntents) ? recognizedIntents : [];
  const hasIntent = type => intents.some(item => item?.type === type);
  const unresolved = [];

  // A negative VATS instruction is not consent to disable theft deterrence.
  // The goal parser recognizes "disable VATS" even inside "do not disable
  // VATS"; fail closed on a negative/preservation clause, including when
  // another clause contradicts it. The caller must clarify the whole request.
  const vatsName = '(?:vats|vtd|vehicle\\s+anti[- ]?theft|anti[- ]?theft|theft\\s+deterrent)';
  const vatsOffVerb = '(?:disabl(?:e|ing)|delet(?:e|ing)|remov(?:e|ing)|turn(?:ing)?\\s+off|shut(?:ting)?\\s+off)';
  const vatsNegation = new RegExp(
    `\\b(?:do\\s+not|don['’]?t|dont|never|without|avoid)\\s+(?:(?:ever|the|my|any|please)\\s+){0,3}${vatsOffVerb}\\s+(?:the\\s+)?${vatsName}\\b` +
    `|\\b(?:keep|leave|retain|preserve)\\s+(?:the\\s+)?${vatsName}\\s+(?:enabled|on|active|intact)\\b` +
    `|\\b${vatsName}\\s+(?:(?:should|must|will|is|was|to)\\s+){0,3}not\\s+(?:be\\s+)?(?:disabled|deleted|removed|turned\\s+off)\\b` +
    `|\\b${vatsName}\\s+(?:(?:should|must|will)\\s+)?(?:stays?|remains?)\\s+(?:enabled|on|active)\\b` +
    `|\\b(?:do\\s+not|don['’]?t|dont|never)\\s+want\\s+(?:to\\s+)?${vatsOffVerb}\\s+(?:the\\s+)?${vatsName}\\b` +
    `|\\b(?:do\\s+not|don['’]?t|dont|never|without|avoid)\\s+(?:(?:ever|please)\\s+){0,2}(?:turn|shut|switch)\\s+(?:(?:the|my)\\s+)?${vatsName}\\s+off\\b` +
    `|\\b(?:do\\s+not|don['’]?t|dont|never)\\s+want\\s+to\\s+(?:turn|shut|switch)\\s+(?:(?:the|my)\\s+)?${vatsName}\\s+off\\b` +
    `|\\b(?:do\\s+not|don['’]?t|dont|never)\\s+want\\s+(?:the\\s+)?${vatsName}\\s+(?:disabled|deleted|removed|off|turned\\s+off)\\b`, 'i'
  );
  // Run196: Assignment-style preservation contradicts a parsed VATS-disable
  // request too. An observed/desired "VATS = enabled" or "VATS enable flag
  // = true" cannot be treated as consent to turn theft deterrence off.
  // The assignment is ambiguous, so require clarification rather than
  // guessing a controller OS flag or applying only the first instruction.
  const vatsEnabledAssignment = new RegExp(
    String.raw`\b${vatsName}\s+(?:enable(?:d|ment)?(?:\s+(?:flags?|bits?|states?))?|status|state|active)?\s*(?:=|:)\s*(?:true|1|on|enabled|active)\b`, 'i'
  );
  // Run197: "leave VATS alone" and "don't touch VATS" preserve the
  // existing theft-deterrent configuration even though they contain no
  // "disable" verb. In a combined request, the goal parser may still accept
  // an earlier VATS-delete clause; never let that conflicting instruction
  // silently disappear. This is text triage, not an OS flag or bit mapping.
  const vatsPreservationInstruction = new RegExp(
    String.raw`\b(?:leave|keep|retain|preserve)\s+(?:(?:the|my|factory|stock|existing|current)\s+){0,3}${vatsName}\s+(?:(?:settings?|configuration|calibration|state|flags?)\s+)?(?:alone|unchanged|as[-\s]?is|stock|factory|original|intact)\b` +
    String.raw`|\b(?:leave|keep|retain|preserve)\s+(?:(?:the|my|factory|stock|existing|current)\s+){0,3}${vatsName}\s+(?:settings?|configuration|calibration|state|flags?)\b` +
    String.raw`|\b(?:do\s+not|don['’]?t|dont|never|avoid)\s+(?:(?:ever|please)\s+){0,2}(?:touch|change|modify|alter|adjust|reprogram|mess\s+with)\s+(?:(?:the|my|factory|stock)\s+){0,2}${vatsName}\b` +
    String.raw`|\b${vatsName}\s+(?:(?:should|must|will|needs?\s+to|is|are)\s+){0,3}(?:be\s+)?(?:left|kept|remain|stay)\s+(?:alone|unchanged|as[-\s]?is|stock|factory|original|on|enabled|active)\b`, 'i'
  );
  if (vatsNegation.test(source) || vatsEnabledAssignment.test(source) || vatsPreservationInstruction.test(source)) {
    unresolved.push({
      type: 'vats-intent-contradiction',
      label: 'VATS instruction requires clarification',
      status: 'needs-review',
      requirement: 'The request says to retain VATS or not disable it. No VATS-disable action may be proposed from a negated or contradictory instruction; submit an unambiguous authorized request for separate review.'
    });
  }

  // Include knock-retard/control/detection requests, not just the physical
  // sensor wording. A VATS request must never silently drop an instruction
  // to remove engine knock protection, regardless of verb order or tense.
  // Generic protection/monitoring/response language is also an explicit
  // request to defeat knock safeguards, even without sensor terminology.
  const knockProtection = /\bknock[\s-]*(?:sensors?|retard|control|detection|feedback|correction|protection|monitoring|response)\b/i;
  const knockNearbyAction = /(?:\b(?:delet(?:e|ed|ing)|disabl(?:e|ed|ing)|remov(?:e|ed|ing)|bypass(?:ed|ing)?|turn\s*off|shut\s*off|switch\s*off)\s+(?:(?:the|my|all|both|any|factory|stock|engine|pcm|ecm|physical)\s+){0,4}knock[\s-]*(?:sensors?|retard|control|detection|feedback|correction|protection|monitoring|response)\b|\bknock[\s-]*(?:sensors?|retard|control|detection|feedback|correction|protection|monitoring|response)\b\s+(?:(?:are|is|was|were|have\s+been|should\s+be|will\s+be|to\s+be|set\s+to)\s+)?(?:delet(?:e|ed|ing)|disabl(?:e|ed|ing)|remov(?:e|ed|ing)|bypass(?:ed|ing)?|off)\b)/i;
  // Setting knock retard/control to zero is also a knock-protection bypass.
  // A VATS/fan request must not silently discard this wording merely because
  // the user did not say "disable" or "delete". This is request triage only.
  // KR is a common short form for knock retard in tuning/logging requests.
  // Treat explicit KR-zeroing as a protection change, not as a harmless log.
  // Scalar knock gain/multiplier/sensitivity can also suppress the response;
  // these names are triage clues, not proof of any OS-specific calibration.
  const knockZeroTarget = '(?:knock[\\s-]*(?:retard|control|detection|feedback|correction)|KR)';
  const knockZeroAction = new RegExp(
    `\\b(?:set|make|force|reduce|drop|limit)\\s+(?:(?:the|my|all|maximum|max)\\s+){0,3}${knockZeroTarget}\\s+(?:(?:tables?|limit|maximum|max|threshold|value|gain|multiplier|sensitivity|factor|scale|scaling)\\s+)?(?:(?:to|at)\\s+|[=:]\\s*)(?:0+(?:\\.0+)?|zero)\\b` +
    `|\\b(?:zero(?:\\s+out)?|clear|erase)\\s+(?:(?:the|my|all)\\s+){0,3}${knockZeroTarget}\\b` +
    `|\\b${knockZeroTarget}\\s+(?:(?:tables?|limit|maximum|max|threshold|value|gain|multiplier|sensitivity|factor|scale|scaling)\\s+)?(?:to\\s+|[=:]\\s*)(?:0+(?:\\.0+)?|zero)\\b`, 'i'
  );
  // A passive description of zeroed knock-retard calibration is still a
  // protection-bypass diagnostic. Do not treat it as permission to proceed
  // with unrelated VATS/fan work or assume a verified OS-specific address.
  const knockPassiveZeroed = /\b(?:knock[\s-]*(?:retard|control|correction|feedback)|KR)\s+(?:(?:tables?|limits?|values?|gain|multiplier|sensitivity)\s+)?(?:(?:has|had|have)\s+been\s+|(?:is|are|was|were|got)\s+)(?:zeroed(?:\s+out)?|set\s+to\s+(?:0|zero))\b/i;
  // A reported zero-valued KR/knock-retard table is a diagnostic safety
  // concern even without an action verb ("KR tables are all zeros"). This
  // does not establish an OS-specific address or authorize any calibration.
  const knockPassiveZeroValue = /\b(?:knock[\s-]*(?:retard|control|correction|feedback)|KR)\s+(?:(?:tables?|limits?|values?|gain|multiplier|sensitivity)\s+)?(?:is|are|was|were|remain|remains|read|reads)\s+(?:(?:all|at|just|only)\s+)?(?:zeros?|0+(?:\.0+)?)\b/i;
  // Run785: Reported zero-filled KR tables are a protection diagnostic even
  // when phrased as contents rather than a numeric assignment. This only
  // blocks partial request admission; it never changes ECU data.
  const knockZeroFilledTables = /\b(?:knock[\s-]*(?:retard|control|correction|feedback)|KR)\s+(?:tables?|values?)\s+(?:(?:contain|contains|consist\s+of|are\s+filled\s+with|were\s+filled\s+with)\s+)(?:(?:only|all|entirely|nothing\s+but)\s+)?(?:zeros?|0+(?:\.0+)?)\b/i;
  // A knock-control enable flag set to OFF is a protection-state request,
  // even if it does not mention zeroing a table or removing a sensor.
  const knockEnableFlagOff = new RegExp(
    `\\b(?:set|switch|turn|make|force|mark)\\s+(?:(?:the|my|all)\\s+){0,3}${knockZeroTarget}\\s+(?:enable(?:ment)?|enabled|active)\\s*(?:flag|switch|state)?\\s+(?:to\\s+)?(?:off|false|disabled|0)\\b`, 'i'
  );
  // Assignment-style OFF states are also protection changes. A combined
  // VATS/fan request must not silently drop "KR enable flag = 0" or
  // "knock control enabled: false". This is only request triage: it does
  // not assume any controller-specific flag address or polarity.
  const knockEnableFlagAssignmentOff = new RegExp(
    `\\b${knockZeroTarget}\\s+(?:enable(?:ment|d)?|active)\\s*(?:flags?|bits?|switch(?:es)?|states?|settings?)?\\s*(?:=|:)\\s*(?:0|false|off|disabled|inactive)\\b`, 'i'
  );
  // Physical disconnection also removes sensor feedback even if the request
  // never says "delete" or "disable". This is triage, not a wiring instruction.
  // Run220: "pulled the knock sensors out" / "took out both knock sensors"
  // describe physical removal without using remove/delete/disconnect. Never
  // silently omit them from a combined VATS/fan proposal. Limit the target to
  // physical sensors so "pull knock sensor codes" stays diagnostic-only.
  const knockSensorPulled = /\b(?:pull(?:ed|ing)?|tak(?:e|ing)|took)\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}knock[\s-]*sensors?\s+(?:out|off)\b|\b(?:pull(?:ed|ing)?|tak(?:e|ing)|took)\s+(?:out|off)\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}knock[\s-]*sensors?\b/i;
  // Run256: Physical removal is also described as "pulled both knock sensors"
  // without "out/off", "yanked", "extracted", or "the sensors are gone".
  // Never silently keep only a companion VATS/fan proposal when knock
  // feedback may be missing. Exclude requests to pull diagnostic codes/data
  // and questions asking WHETHER the sensors were removed. No DTC or OS
  // compatibility is inferred; this is text-only diagnostic triage.
  const physicalKnockTarget = String.raw`knock[\s-]*sensors?(?!\s+(?:(?:(?:diagnostic|fault|trouble|error)\s+)?(?:codes?|dtcs?)|data|logs?|readings?|values?|signals?|counts?|faults?|history)\b)`;
  const physicalKnockRemoval = new RegExp(
    String.raw`\b(?:pull(?:ed|ing)?|yank(?:ed|ing)?|extract(?:ed|ing)?)\s+(?:(?:the|my|both|all|two|stock|factory|old|original)\s+){0,4}${physicalKnockTarget}\b` +
    String.raw`|\b${physicalKnockTarget}\s+(?:(?:are|were|was|is|have|has|had)\s+(?:been\s+)?)?(?:pulled|yanked|extracted|gone)\b`, 'gi'
  );
  const knockPhysicalRemovalReview = [...source.matchAll(physicalKnockRemoval)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    return !/\b(?:check|inspect|verify|diagnose|test|determine)\b[^.!?;,]*\b(?:whether|if)\b/i.test(clausePrefix);
  });
  // Run257: Passive "taken out" and "out of the block" reports also
  // describe physical removal, even without a remove/delete/pull verb.
  // Treat this as diagnostic triage only; no ECU or knock-map assumptions.
  // Direct questions, "check whether" inspections, and explicit "not taken
  // out" statements must not become claims that hardware is missing.
  const knockPassiveRemoval = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:(?:have|has|had|are|is|were|was)\s+(?:been\s+)?|(?:got)\s+)?taken\s+out\b` +
    String.raw`|\b${physicalKnockTarget}\s+(?:(?:are|is|were|was)\s+)?out\s+of\s+(?:(?:the|my|an?)\s+)?(?:engine|block|motor)\b`, 'gi'
  );
  const knockPassiveRemovalReview = [...source.matchAll(knockPassiveRemoval)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(clausePrefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(clausePrefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  });
  // Run324: A physical sensor loss can be described as a passive state with
  // an adverb ("knock sensors are physically removed/missing"). Earlier
  // patterns covered "were removed" and "missing" assignments but missed
  // this common statement. This is diagnostic triage only, not permission
  // to suppress knock retard or DTCs. Questions and explicit negations are
  // not affirmative evidence that a sensor is absent.
  const knockPhysicalState = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:(?:are|is|were|was|have|has|had)\s+(?:been\s+)?)?(?:still\s+)?(?:physically\s+)?(?:removed|missing|absent)\b`, 'gi'
  );
  const knockPhysicalStateReview = [...source.matchAll(knockPhysicalState)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const punctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(prefix) && punctuation === '?';
    return !diagnostic && !question;
  });
  // Run328: Passive physical loss can also be reported as "physically
  // disconnected", "no longer installed", or simply "the sensors are out".
  // Those reports cannot be silently dropped from a VATS/fan-only proposal.
  // Keep direct questions and "check whether/if" investigations diagnostic;
  // these are text-only clues, not proof of missing hardware or an OS mapping.
  const knockPhysicalAbsentState = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:(?:are|is|were|was|have|has|had)\s+(?:been\s+)?)?(?:still\s+)?physically\s+(?:disconnected|unplugged|detached|unhooked)\b` +
    String.raw`|\b${physicalKnockTarget}\s+(?:(?:are|is|were|was|have|has|had)\s+(?:been\s+)?)?no\s+longer\s+(?:installed|connected|present|fitted)\b` +
    String.raw`|\b${physicalKnockTarget}\s+(?:are|is|were|was)\s+(?:still\s+)?out(?=\s*(?:[.!?;,]|$))`, 'gi'
  );
  const knockPhysicalAbsentReview = [...source.matchAll(knockPhysicalAbsentState)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const punctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(prefix) && punctuation === '?';
    return !diagnostic && !question;
  });
  // Run266: On an engine rebuild the sensors may be "left out" or "never
  // reinstalled" without a remove/delete command. A combined VATS/fan plan
  // must not silently omit the loss of physical knock feedback. This is
  // diagnostic triage, not a controller/OS-specific knock-delete operation.
  const knockLeftOut = new RegExp(
    String.raw`\bleft\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}${physicalKnockTarget}\s+out\b` +
    String.raw`|\b${physicalKnockTarget}\s+(?:(?:are|were|was|is|have|has|had)\s+(?:been\s+)?)?left\s+out\b`, 'gi'
  );
  const knockNotReinstalled = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:(?:are|is|were|was|have|has|had)\s+)?(?:not|never)\s+(?:been\s+)?(?:reinstalled|installed|put\s+back(?:\s+in)?)\b` +
    String.raw`|\b(?:did\s+not|didn['’]?t|never)\s+(?:reinstall|install|put\s+back)\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}${physicalKnockTarget}\b`, 'gi'
  );
  const knockNotInstalledReview = [...source.matchAll(knockLeftOut), ...source.matchAll(knockNotReinstalled)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(clausePrefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had|did)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(clausePrefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  });
  // Run233: The previous imperative-only prefix missed ordinary past-tense
  // physical removal ("I unplugged both knock sensors") and passive states
  // ("knock sensors were unplugged"). Never allow a combined VATS/fan plan
  // to proceed while an unreviewed loss of knock feedback is silently dropped.
  // This is syntax-only triage, not a sensor diagnosis or OS calibration map.
  const knockSensorDisconnect = /\b(?:unplug(?:ged|ging)?|disconnect(?:ed|ing)?|unhook(?:ed|ing)?|detach(?:ed|ing)?)\s+(?:(?:the|my|both|all|two|factory|stock)\s+){0,4}knock[\s-]*sensors?\b|\bknock[\s-]*sensors?\s+(?:(?:are|were|was|is|have|has|had)\s+(?:been\s+)?|(?:got|came)\s+)?(?:unplugged|disconnected|unhooked|detached)\b/gi;
  const knockSensorDisconnectReview = [...source.matchAll(knockSensorDisconnect)].some(match => {
    // A diagnostic question ('diagnose disconnected knock sensors' or
    // 'check whether knock sensors were unplugged') is not a statement
    // that a sensor was physically disconnected.
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    // Questions about wiring *to* the sensors can include more words before
    // the sensor-state match; they still do not assert disconnection.
    return !(/\b(?:inspect|diagnose|check|verify|log|monitor|test|measure|review)\s+(?:(?:whether|if|the|my|both|all|two|those|these)\s+){0,4}$/i.test(prefix) ||
      /\b(?:inspect|diagnose|check|verify|log|monitor|test|measure|review)\b[^.!?;,]{0,100}\b(?:whether|if)\b/i.test(prefix));
  });
  // Run268: "still unplugged" and "forgot to reconnect" are affirmative
  // descriptions of missing physical knock feedback. Earlier disconnected
  // patterns skipped the intervening "still" and the failure-to-connect
  // wording. Never silently keep only VATS/fan changes. Questions asking
  // whether a fault exists are diagnostic requests, not confirmed faults.
  // These text clues do not establish a controller OS, pin, DTC, or repair.
  const knockConnectionStillMissing = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:(?:are|is|were|was|have|has|had)\s+(?:been\s+)?)?(?:still\s+)?(?:unplugged|disconnected|unhooked|detached|not\s+(?:reconnected|connected|plugged[\s-]*in|hooked[\s-]*up))\b`, 'gi'
  );
  const knockForgotConnection = new RegExp(
    String.raw`\b(?:i|we)\s+(?:(?:forgot|failed)\s+to|never|did\s+not|didn['’]?t)\s+(?:plug\s+in|reconnect|connect|hook\s+up|reinstall|plugged\s+in|reconnected|connected|hooked\s+up|reinstalled)\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}${physicalKnockTarget}\b`, 'gi'
  );
  const knockConnectionOmissionReview = [...source.matchAll(knockConnectionStillMissing), ...source.matchAll(knockForgotConnection)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(clausePrefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(clausePrefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  });
  // Run348: Contractions in physical connection reports ("knock sensors
  // aren't plugged in", "weren't reinstalled") previously bypassed the
  // expanded "not connected" patterns. Treat affirmative loss of knock
  // feedback as a diagnostic blocker, never a knock-protection delete.
  // Explicit "aren't missing/unplugged" preservation and inspection-only
  // questions must not be converted into an asserted hardware fault.
  const knockContractedAbsent = new RegExp(
    String.raw`\b${physicalKnockTarget}\s+(?:aren['’]?t|isn['’]?t|weren['’]?t|wasn['’]?t|haven['’]?t|hasn['’]?t|hadn['’]?t)\s+(?:been\s+)?(?:connected|reconnected|plugged[\s-]*in|hooked[\s-]*up|installed|reinstalled|fitted|present)\b`, 'gi'
  );
  const knockContractedAbsentReview = [...source.matchAll(knockContractedAbsent)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const directQuestion = /^\s*\?/.test(remainder);
    return !diagnostic && !directQuestion;
  });
  // Run299: Numbered sensor labels ("knock sensor #2", "knock sensor 1",
  // "knock sensor bank 2") were omitted by unnumbered physical-fault
  // patterns. A VATS/fan-only proposal must not hide a reported missing,
  // unplugged, replaced, or damaged numbered sensor/circuit. These are
  // syntax clues, not verified sensor-bank assignments or OS/DTC mappings.
  const numberedKnockSensor = String.raw`knock[\s-]*sensor\s*(?:#\s*[12]|\b[12]\b|\bbank\s*[12]\b)`;
  const numberedKnockFault = new RegExp(
    String.raw`\b${numberedKnockSensor}\s+(?:(?:is|are|was|were|has|have|had)\s+(?:been\s+)?|(?:still|got)\s+)*(?:missing|absent|unplugged|disconnected|unhooked|removed|deleted|damaged|failed|broken|shorted|not\s+(?:installed|connected|plugged[\s-]*in)|replaced\s+(?:with|by)\s+(?:(?:a|an|the|dummy)\s+)?(?:resistor|dummy\s+plug|emulator|simulator))\b` +
    String.raw`|\b(?:cut|sever(?:ed)?|snip(?:ped)?|unplug(?:ged)?|disconnect(?:ed)?|remov(?:e|ed))\s+(?:(?:the|my|both|stock|factory)\s+){0,3}${numberedKnockSensor}(?:\s+(?:harness|wiring|wires?|connectors?))?\b` +
    String.raw`|\b${numberedKnockSensor}\s+(?:harness|wiring|wires?|connectors?)\s+(?:(?:is|are|was|were|has|have|had)\s+(?:been\s+)?)?(?:cut|severed|snipped|unplugged|disconnected|missing|broken)\b`, 'gi'
  );
  const numberedKnockFaultReview = [...source.matchAll(numberedKnockFault)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if|for)\b/i.test(clausePrefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(clausePrefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  });
  // Run300: A numbered sensor's future/desired OFF state can be expressed
  // without a removal verb before the sensor ("knock sensor #1 should be
  // disabled"). Do not silently approve companion VATS/fan changes. This
  // only requires independent diagnostic review; it never maps a controller
  // bit or authorizes knock protection removal. Inspection questions are
  // not statements that the sensor is disabled.
  const numberedKnockDisableDirective = new RegExp(
    String.raw`\b${numberedKnockSensor}\s+(?:(?:should|must|will|needs?\s+to|has\s+to|is\s+to|are\s+to)\s+(?:be\s+)?|(?:is|was|are|were)\s+to\s+be\s+)(?:disabled|deleted|removed|bypassed|ignored|suppressed|masked|off)\b` +
    String.raw`|\b${numberedKnockSensor}\s+(?:should|must|will|needs?\s+to)\s+(?:stay|remain|be\s+set)\s+(?:off|disabled)\b`, 'gi'
  );
  const numberedKnockDisableReview = [...source.matchAll(numberedKnockDisableDirective)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    return !/\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(clausePrefix);
  });
  // Run301: Numbered knock sensors can be assigned an OFF/absent state
  // without a verb ("knock sensor #1 = disabled", "sensor bank 2 enable
  // flag = 0"). Never silently drop that request from a VATS/fan proposal.
  // These are text-only triage labels, not a physical bank/ECM bit mapping.
  const numberedKnockStateAssignment = new RegExp(
    String.raw`\b${numberedKnockSensor}(?:\s+(?:enable(?:d|ment)?(?:\s+(?:flags?|bits?|states?))?|status|state|connection))?\s*(?:=|:)\s*(?:0|false|off|disabled|removed|unplugged|disconnected|absent|none|missing|not\s+(?:installed|connected|present))\b`, 'gi'
  );
  const numberedKnockAssignmentReview = [...source.matchAll(numberedKnockStateAssignment)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    return !/\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
  });
  // Run222: A disconnected/cut knock-sensor harness or connector can remove
  // physical knock feedback even when the sensors remain fitted. A combined
  // VATS/fan request must require diagnostic review rather than dropping this
  // condition. This is text admission only; it does not establish ECM wiring.
  const knockWiringCompromised = /\bknock[\s-]*sensors?\s+(?:harness|wiring|wires?|connectors?)\s*(?:(?:is|are|was|were|has|have)\s+(?:been\s+)?)?(?:=|:)?\s*(?:unplugged|disconnected|detached|cut|severed|removed|missing)\b|\b(?:both|all)\s+knock[\s-]*sensors?\s+(?:have|has)\s+been\s+(?:unplugged|disconnected|detached)\b|\b(?:i|we)\s+(?:unplugged|disconnected|cut|removed)\s+(?:(?:the|my)\s+)?knock[\s-]*sensors?\s+(?:harness|wiring|wires?|connectors?)\b|\bknock[\s-]*sensors?\s+connectors?\s+came\s+unplugged\b/gi;
  // Run234: Active/past-tense damage to physical knock wiring may have
  // determiners between the verb and sensor target ("cut both knock sensor
  // wires", "severed the knock sensor harness"). Such a fault cannot be
  // silently omitted from an otherwise valid VATS/fan request. No bypass,
  // OS-specific DTC, or wiring assumption is authorized by this text check.
  const knockWiringDamageAction = /\b(?:cut|sever(?:ed)?|snip(?:ped)?)\s+(?:(?:the|my|both|all|two|factory|stock|original|left|right)\s+){0,4}knock[\s-]*sensors?\s+(?:harness|wiring|wires?|connectors?)\b/gi;
  // Run235: Physical wire damage can be described with the wiring noun
  // before the sensor ("cut the wires to the knock sensors" or "wires to
  // knock sensors were cut"). The planner must not silently admit only
  // companion VATS/fan actions. This remains diagnostic triage, never an
  // OS-specific sensor/knock-protection calibration instruction.
  const knockWiringReverseDamage = /\b(?:cut|sever(?:ed)?|snip(?:ped)?|disconnect(?:ed)?|unplug(?:ged)?)\s+(?:(?:the|my|both|all|two|factory|stock|original)\s+){0,3}(?:wires?|wiring|harness|connectors?)\s+(?:(?:going|running|leading)\s+)?(?:to|for|from|on)\s+(?:(?:the|my|both|all|two|factory|stock)\s+){0,3}knock[\s-]*sensors?\b|\b(?:wires?|wiring|harness|connectors?)\s+(?:(?:going|running|leading)\s+)?(?:to|for|from|on)\s+(?:(?:the|my|both|all|two|factory|stock)\s+){0,3}knock[\s-]*sensors?\s+(?:(?:are|were|is|was|have|has|had|got)\s+(?:been\s+)?)?(?:cut|severed|snipped|disconnected|unplugged)\b/gi;
  // Run236: "knock sensors are not plugged in" and "knock sensor harness
  // is not connected" describe absent physical feedback without an affirmative
  // unplug/disconnect verb. They require independent diagnostics before any
  // partial VATS/fan proposal. Exclude questions asking WHETHER this is true.
  // This is admission triage only; it does not infer pins or change protection.
  const knockConnectionNegative = /\bknock[\s-]*sensors?(?:\s+(?:harness|wiring|wires?|connectors?))?\s+(?:(?:are|is|were|was|have|has|had)\s+)?(?:not|never)\s+(?:been\s+)?(?:connected|plugged[\s-]*in|hooked[\s-]*up)\b/gi;
  const knockWiringReview = [...source.matchAll(knockWiringCompromised), ...source.matchAll(knockWiringDamageAction), ...source.matchAll(knockWiringReverseDamage), ...source.matchAll(knockConnectionNegative)].some(match => {
    // "Check whether ... is cut" is an investigation, not a statement that
    // knock feedback was physically lost. Inspect only the current clause.
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    return !/\b(?:check|inspect|verify|diagnose|test|log|monitor|measure|determine)\b[^.!?;,]*\b(?:whether|if|for)\b/i.test(clausePrefix);
  });
  // Run223: Plugging/capping the original knock-sensor ports or relocating
  // sensors changes the physical knock-feedback arrangement. The quick
  // VATS/fan planner cannot assume that protection remains functional.
  // Require diagnostics, but do not misread a "check whether" inspection as
  // a declaration that the ports were plugged. No OS/DTC mapping is inferred.
  const knockPortModification = /\b(?:plug(?:ged|ging)?|cap(?:ped|ping)?|block(?:ed|ing)?[\s-]*off|seal(?:ed|ing)?)\s+(?:(?:the|my|both|all)\s+){0,3}knock[\s-]*sensor\s+(?:holes?|ports?|openings?)\b|\bknock[\s-]*sensor\s+(?:holes?|ports?|openings?)\s+(?:(?:are|were|have|has)\s+(?:been\s+)?)?(?:plugged|capped|sealed|blocked[\s-]*off|(?:block[\s-]*off\s+)?plugs?\s+installed)\b|\b(?:install(?:ed|ing)?|put|fit(?:ted|ting)?)\s+(?:block[\s-]*off\s+)?(?:plugs?|caps?)\s+(?:in|into|on|over)\s+(?:(?:the|my)\s+)?knock[\s-]*sensor\s+(?:holes?|ports?|openings?)\b/gi;
  const knockPortReview = [...source.matchAll(knockPortModification)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    return !/\b(?:check|inspect|verify|diagnose|test|log|monitor|measure|determine)\b[^.!?;,]*\b(?:whether|if|for)\b/i.test(clausePrefix);
  });
  // Run269: replacing functional knock sensors with dummy plugs, resistors,
  // or emulators can remove actual knock feedback even if the original
  // ports and harness are otherwise present. A mixed VATS/fan request must
  // require independent knock-system diagnostics, not a partial proposal.
  // Text-only triage: no sensor electrical values, DTCs, or OS mapping.
  const knockSubstitution = /\b(?:replac(?:e|ed|ing)|swap(?:ped|ping)?)\s+(?:(?:the|my|both|all|two|stock|factory|original)\s+){0,4}knock[\s-]*sensors?\s+(?:with|for)\s+(?:(?:the|my|some|a|two)\s+)?(?:block[\s-]*off\s+)?(?:dummy\s+)?(?:plugs?|resistors?|simulators?|emulators?)\b|\bknock[\s-]*sensors?\s+(?:(?:were|are|was|is|have|has)\s+(?:been\s+)?)?(?:replaced|swapped)\s+(?:with|for)\s+(?:(?:the|my|some|a|two)\s+)?(?:block[\s-]*off\s+)?(?:dummy\s+)?(?:plugs?|resistors?|simulators?|emulators?)\b|\b(?:install(?:ed|ing)?|use[ds]?|fit(?:ted|ting)?|put)\s+(?:(?:the|my|both|two)\s+)?(?:dummy|fake|simulated)\s+knock[\s-]*sensors?\b|\b(?:use[ds]?|install(?:ed|ing)?|wire[ds]?|put)\s+(?:(?:the|my|some|two)\s+)?(?:resistors?|dummy\s+plugs?)\s+(?:in\s+place\s+of|instead\s+of)\s+(?:(?:the|my|both|two)\s+)?knock[\s-]*sensors?\b|\b(?:put|install(?:ed|ing)?)\s+(?:(?:the|my|some|two)\s+)?block[\s-]*off\s+plugs?\s+where\s+(?:(?:the|my)\s+)?knock[\s-]*sensors?\s+(?:used\s+to\s+be|were)\b/gi;
  const knockSubstitutionReview = [...source.matchAll(knockSubstitution)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    return !/\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
  });
  const knockSensorRelocation = /\b(?:relocat(?:e|ed|ing)|mov(?:e|ed|ing))\s+(?:(?:the|my|both|all|two|stock|factory)\s+){0,4}knock[\s-]*sensors?\b|\bknock[\s-]*sensors?\s+(?:were|are|have\s+been|has\s+been)\s+relocated\b/i;
  const noKnockSensors = /\b(?:run|running|operate|operating|drive|driving|tune|tuning|work|working)\s+(?:\w+\s+){0,3}without\s+(?:the\s+)?knock[\s-]*sensors?\b|\bno\s+knock[\s-]*sensors?\b(?!\s+(?:mounting\s+)?(?:holes?|ports?|bosses?|openings?|mounts?|provisions?))/i;
  // Run332: An aftermarket/smooth valley cover can eliminate the factory
  // knock-sensor mounting provision without an explicit "delete sensors"
  // command. This is a physical feedback arrangement requiring independent
  // diagnostics; no assumption about remote sensor mounting or ECM OS is made.
  // Only declarative/planned changes are blocked, not questions or statements
  // that the owner did NOT fit such a cover.
  const valleyCoverWithoutKnockProvision = /\b(?:valley\s+(?:cover|plate))\b[^.!?;,]{0,70}\b(?:without|no|lacks?|missing)\s+(?:(?:any|the|factory|stock|original)\s+)?(?:knock[\s-]*sensor\s+(?:(?:mounting)\s+)?(?:ports?|holes?|bosses?|openings?|mounts?|provisions?)|(?:ports?|holes?|bosses?|openings?|mounts?|provisions?)\s+(?:for|to\s+mount)\s+(?:the\s+)?knock[\s-]*sensors?)\b/gi;
  // Preserve the previous broad 'no knock sensor ports' coverage even when
  // the owner describes the engine/block rather than a valley cover. The
  // question filter below prevents an inspection from becoming a diagnosis.
  const knockMountProvisionAbsent = /\b(?:without|no|lacks?|missing)\s+(?:(?:any|the|factory|stock|original)\s+)?knock[\s-]*sensor\s+(?:mounting\s+)?(?:ports?|holes?|bosses?|openings?|mounts?|provisions?)\b/gi;
  const valleyCoverKnockReview = [...source.matchAll(valleyCoverWithoutKnockProvision),
    ...source.matchAll(knockMountProvisionAbsent)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const question = /\b(?:check|inspect|verify|diagnose|test|determine|review|ask)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix) ||
      (/^(?:does|did|has|have|is|was|will|would|could|can)\b/i.test(prefix) && /^\s*\?/.test(remainder));
    const negatedInstall = /\b(?:did\s+not|didn['’]?t|have\s+not|haven['’]?t|never|do\s+not|don['’]?t)\s+(?:install|fit|use|put\s+on|swap\s+to)\b[^.!?;,]*$/i.test(prefix);
    return !question && !negatedInstall;
  });
  // Assignment-style physical sensor removal is also a safety change. A
  // combined request such as "knock sensors = disabled" must not be admitted
  // as VATS/fan-only merely because it omits an imperative verb. Treat this
  // as review-needed intent, never as a verified controller state or OS bit.
  const knockSensorStateAssignment = /\bknock[\s-]*sensors?\s*(?:=|:)\s*(?:0|false|off|disabled|removed|unplugged|disconnected|absent|none)\b/i;
  // Review requests that describe missing sensor hardware or suppression of
  // the sensor input/monitoring without using the word 'delete'. These are
  // ambiguous physical/protection changes, never evidence of a safe OS map.
  const knockSensorMissingAssignment = /\bknock[\s-]*sensors?\s*(?:=|:)\s*(?:not\s+(?:installed|connected|present)|missing)\b/i;
  const knockInputSuppression = /\b(?:ignore|suppress|mask|bypass)\s+(?:(?:the|my|all|both|any|factory|stock)\s+){0,3}knock[\s-]*(?:sensors?|input|signal|monitoring|feedback)\b|\bknock[\s-]*(?:sensors?|input|signal|monitoring|feedback)\s+(?:(?:should|must|will|is|are|was|were|has|have|had)\s+(?:been\s+|be\s+)?)?(?:ignored|suppressed|masked|bypassed|spoofed|faked)\b/i;
  const knockMonitoringAssignmentOff = /\bknock[\s-]*(?:sensor\s+)?(?:monitoring|protection|detection|control)\s*(?:=|:)\s*(?:disabled|false|off|0|inactive)\b/i;
  // A missing/unfitted physical sensor is a diagnostic issue even when
  // expressed as a condition rather than an explicit delete command.
  const knockSensorUnfitted = /\bknock[\s-]*sensors?\s+(?:not\s+(?:fitted|installed|connected|present)|missing|absent)\b/i;
  // Run239: A reported failed sensor, missing feedback signal or damaged
  // knock circuit needs independent diagnosis. The quick-service planner must
  // not silently keep a companion VATS/fan request and discard this fault.
  // Do not treat an inspection asking WHETHER a fault exists as a confirmed
  // fault. This is text triage, not an exact-OS DTC map or proof of a failure.
  // Run312: Intermittent/erratic/unstable knock-circuit reports require
  // independent diagnostics; a companion VATS/fan request cannot silently
  // discard them. These are text-only fault clues, not exact-OS mappings.
  const knockReportedFault = /\bknock[\s-]*sensors?(?:\s+[12])?(?:\s+(?:harness|wiring|wires?|connectors?|signal|circuit))?\s+(?:(?:is|are|was|were|has|have|had)\s+(?:been\s+)?)?(?:faulty|bad|broken|damaged|dead|failed|failing|malfunctioning|inoperative|nonfunctional|not\s+working|missing|lost|open|shorted|intermittent|erratic|unstable)\b|\bknock[\s-]*sensors?(?:\s+[12])?\s+(?:has|have|had|is|are)\s+(?:no|lost|missing)\s+(?:signal|feedback)\b/gi;
  // Run313: The failure qualifier can precede the sensor/signal rather
  // than follow it ("intermittent knock sensor signal", "erratic knock
  // sensor readings"). These are reported conditions requiring a separate
  // diagnostic review, never proof of a particular ECM/OS fault mapping.
  // Also recognize a qualifier following a readings/feedback/voltage noun.
  const knockReportedSignalFault = /\b(?:intermittent|erratic|unstable)\s+knock[\s-]*sensors?(?:\s+(?:signal|feedback|readings?|voltage|circuit|wiring|harness))\b|\bknock[\s-]*sensors?\s+(?:feedback|readings?|voltage)\s+(?:(?:is|are|was|were|has|have|had)\s+(?:been\s+)?)?(?:intermittent|erratic|unstable)\b/gi;
  const isReportedKnockFault = match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    // Asking whether a condition exists is not a report that it exists.
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|log|monitor|measure|determine)\b[^.!?;,]*\b(?:whether|if|for)\b/i.test(clausePrefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(clausePrefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  };
  const knockFaultReview = [...source.matchAll(knockReportedFault),
    ...source.matchAll(knockReportedSignalFault)].some(isReportedKnockFault);
  // Run331: A future omission, open sensor circuit, explicit feedback defeat,
  // or installed signal simulator can leave the engine without trustworthy
  // physical knock feedback. The prior triage accepted all four descriptions
  // in a mixed VATS/fan request. Stop the whole proposal for independent
  // diagnostics; these words do not establish a DTC, pin, or OS calibration.
  const knockFutureOmission = /\bknock[\s-]*sensors?\s+(?:(?:will|would|should|must|are|is|were|was|shall)\s+)?(?:not|never)\s+(?:be\s+)?(?:installed|fitted|connected|reinstalled|plugged[\s-]*in)\b|\b(?:i|we)\s+(?:will|would|plan\s+to|intend\s+to)\s+(?:not|never)\s+(?:install|fit|connect|reinstall)\s+(?:(?:the|my|both|all|two)\s+){0,4}knock[\s-]*sensors?\b/gi;
  const knockOpenCircuit = /\bknock[\s-]*sensors?\s+(?:circuits?|wiring|harness)\s+(?:(?:are|is|were|was|have|has)\s+(?:been\s+)?)?(?:open(?:[\s-]*circuit)?|broken|shorted)\b/gi;
  const knockFeedbackDefeat = /\b(?:eliminat(?:e|ed|ing)|defeat(?:ed|ing)?|kill(?:ed|ing)?|cut\s+out)\s+(?:(?:the|my|all|both|any)\s+){0,3}knock[\s-]*(?:sensors?|feedback|input|signal|monitoring|detection|protection)\b/gi;
  const knockSimulatorInstalled = /\b(?:install(?:ed|ing)?|plug(?:ged|ging)?[\s-]*in|connect(?:ed|ing)?|wir(?:e|ed|ing)|run(?:ning)?|use[ds]?)\s+(?:(?:the|my|a|an|two|both|all|some)\s+){0,4}knock[\s-]*sensor\s+(?:simulators?|emulators?|dummy\s+plugs?)\b/gi;
  const knockAdditionalFeedbackReview = [
    ...source.matchAll(knockFutureOmission), ...source.matchAll(knockOpenCircuit),
    ...source.matchAll(knockFeedbackDefeat), ...source.matchAll(knockSimulatorInstalled)
  ].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const negatedAction = /\b(?:not|never|without|won['’]?t|don['’]?t|didn['’]?t)(?:\s+(?:want\s+to|intend\s+to|plan\s+to))?\s*$/i.test(prefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had|will|would|should|do|did)(?:\s+(?:the|my|both|all|two|factory|stock|knock|sensors?|circuits?)){0,6}$/i.test(prefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion && !negatedAction;
  });
  // Run356: Defeated knock *feedback paths* can be described without
  // saying that a physical sensor was removed ("knock signal is bypassed",
  // "knock detection has been bridged"). Such statements are not proof of
  // healthy knock control. Review the entire mixed VATS/fan request, but
  // exclude inspection questions and explicit non-defeat descriptions.
  // No controller bits, wiring values, or OS/DTC maps are inferred here.
  const knockFeedbackPathDefeated = /\bknock[\s-]*(?:sensors?\s+)?(?:signals?|inputs?|feedback|detection|monitoring|protection|circuits?)\s+(?:(?:is|are|was|were|has|have|had)\s+(?:been\s+)?)?(?:bypassed|jumpered|bridged|spoofed|faked)\b/gi;
  const knockFeedbackPathReview = [...source.matchAll(knockFeedbackPathDefeated)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const nextPunctuation = remainder.match(/[.!?;,]/)?.[0];
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const directQuestion = /^(?:is|are|was|were|has|have|had)(?:\s+(?:the|my|both|all|two|factory|stock)){0,4}$/i.test(prefix) && nextPunctuation === '?';
    return !diagnostic && !directQuestion;
  });
  if ((knockProtection.test(source) && knockNearbyAction.test(source)) || knockZeroAction.test(source) || knockPassiveZeroed.test(source) || knockPassiveZeroValue.test(source) || knockZeroFilledTables.test(source) || knockEnableFlagOff.test(source) || knockEnableFlagAssignmentOff.test(source) || noKnockSensors.test(source) || knockSensorPulled.test(source) || knockPhysicalRemovalReview || knockPassiveRemovalReview || knockPhysicalStateReview || knockPhysicalAbsentReview || knockNotInstalledReview || knockSensorDisconnectReview || knockConnectionOmissionReview || knockContractedAbsentReview || numberedKnockFaultReview || numberedKnockDisableReview || numberedKnockAssignmentReview || knockWiringReview || knockPortReview || knockSubstitutionReview || knockSensorRelocation.test(source) || valleyCoverKnockReview || knockSensorStateAssignment.test(source) || knockSensorMissingAssignment.test(source) || knockSensorUnfitted.test(source) || knockFaultReview || knockAdditionalFeedbackReview || knockFeedbackPathReview || knockInputSuppression.test(source) || knockMonitoringAssignmentOff.test(source)) {
    unresolved.push({
      type: 'knock-sensor-delete',
      label: 'Knock-sensor delete',
      status: 'unsupported',
      requirement: 'Knock-sensor deletion is not supported by the P01 automatic request planner. Do not disable knock protection or knock retard/control/detection; diagnose the sensors, harness, and knock-control system before any calibration review.'
    });
  }

  // A request to suppress knock-related fault reporting requires its own
  // diagnostic review. DTC suppression is not equivalent to proving the
  // knock sensors, harness, and controller protection are healthy.
  const knockFaultTarget = 'knock[\\s-]*(?:sensors?|detection|control)\\s+(?:diagnostics?|faults?|codes?|dtcs?|trouble\\s+codes?|fault\\s+codes?|fault\\s+reporting)';
  // Numeric zero, spelled-out zero, and `as not reported` are reporting
  // suppression requests too. Never silently accept only a companion VATS/
  // fan threshold instruction; this does not define any OS-specific DTC.
  const knockFaultSuppression = new RegExp(
    `\\b(?:ignore|suppress|mask|hide|silence|erase|disable|(?:turn|switch|shut)\\s+off)\\s+(?:(?:the|my|all|both)\\s+){0,3}${knockFaultTarget}\\b` +
    `|\\b(?:set|change|mark)\\s+(?:(?:the|my|all)\\s+){0,3}${knockFaultTarget}\\s+(?:(?:to|as)\\s+)?(?:no\\s+error|not\\s+reported|off|disabled|false|0|zero)\\b` +
    // Object-first phrasing ("turn knock sensor DTCs off") also changes
    // diagnostic reporting; never treat it as a harmless observation.
    `|\\b(?:turn|switch|shut)\\s+(?:(?:the|my|all|both)\\s+){0,3}${knockFaultTarget}\\s+off\\b`, 'i'
  );
  // Code-only knock-circuit DTC suppression can bypass the descriptive
  // "knock sensor" wording above. These generic OBD diagnostic identifiers
  // are triage hints ONLY, not proof of this ECM's OS/DTC mapping.
  // Match explicit suppression actions, not reading/logging/diagnosis.
  const knockCircuitCode = 'P03(?:2[5-9]|3[0-4])';
  const knockCircuitCodes = `${knockCircuitCode}(?:\\s*(?:\\/|,|&|and)\\s*${knockCircuitCode}){0,3}`;
  // Run249: A reported current/pending/stored knock-circuit fault must not
  // vanish from a combined VATS/fan quick-service proposal. The generic
  // P0325-P0334 identifiers are diagnostic *text* clues only; they do NOT
  // establish that any code is implemented by this exact ECM/OS. A request
  // to inspect whether a code is active is not itself a confirmed fault.
  const knockReportedDtc = new RegExp(
    `\\b${knockCircuitCode}\\s*(?:(?:is|was|remains|currently|still)\\s+|(?:=|:)\\s*)?(?:active|pending|stored|present|confirmed|current|intermittent)\\b` +
    `|\\b(?:active|pending|stored|present|confirmed|current|intermittent)\\s+(?:(?:dtc|code|fault|trouble\\s+code)\\s+)?${knockCircuitCode}\\b` +
    `|\\b(?:dtc|code|fault)\\s+${knockCircuitCode}\\s*(?:(?:is|was|remains|currently|still)\\s+|(?:=|:)\\s*)?(?:active|pending|stored|present|confirmed|current|intermittent)\\b` +
    // Run250: Compound affirmative status and grouped code lists require review.
    // Generic text clues are NOT a verified OS-specific DTC map.
    `|\\b${knockCircuitCodes}\\s+(?:(?:is|are|was|were|has|have|been|remains|currently|still)\\s+){1,4}(?:active|pending|stored|present|confirmed|current|intermittent)\\b`, 'gi'
  );
  const knockDtcFaultReview = [...source.matchAll(knockReportedDtc)].some(match => {
    const clausePrefix = source.slice(0, match.index).split(/[.!?;,]/).pop();
    return !/\b(?:check|inspect|verify|diagnose|test|determine)\b[^.!?;,]*\b(?:whether|if|for)\b/i.test(clausePrefix);
  });
  if (knockDtcFaultReview) {
    unresolved.push({
      type: 'knock-diagnostic-fault',
      label: 'Reported knock-circuit DTC requires diagnostic review',
      status: 'needs-review',
      requirement: 'A reported active, pending, or stored knock-circuit DTC requires independent sensor, wiring, and controller diagnostics. Do not suppress fault reporting or disable knock protection; these generic code clues do not establish an exact-OS DTC map.'
    });
  }
  const knockDtcCodeSuppression = new RegExp(
    `\\b(?:disable|delete|suppress|ignore|mask|hide|silence|turn\\s+off|switch\\s+off)\\s+(?:(?:the|my|all|both|knock|sensor|dtc|dtcs|code|codes|fault|faults)\\s+){0,5}${knockCircuitCodes}\\b` +
    `|\\b(?:set|change|mark)\\s+(?:(?:the|my|all|both|dtc|dtcs|code|codes)\\s+){0,4}${knockCircuitCodes}\\s+(?:(?:to|as)\\s+)?(?:no\\s+error|not\\s+reported|off|disabled|false|0|zero)\\b` +
    // "turn P0327 off" puts the DTC between the verb and "off". Without
    // this ordering the planner could silently keep only an accompanying
    // VATS change. This is a conservative triage guard, not an OS map.
    `|\\b(?:turn|switch|shut)\\s+(?:(?:the|my|all|both|knock|sensor|dtc|dtcs|code|codes|fault|faults)\\s+){0,5}${knockCircuitCodes}\\s+off\\b`, 'i'
  );
  // Assignment notation is ambiguous between an observed state and a
  // requested reporting change. In a mixed VATS/fan request, treat an OFF
  // assignment to a knock-related DTC or its descriptive reporting field as
  // requiring separate review; never silently propose only the VATS portion.
  // These code patterns are generic triage clues, not an exact-OS DTC map.
  const knockDtcAssignmentSuppression = new RegExp(
    `\\b${knockCircuitCodes}\\s*(?:=|:)\\s*(?:no\\s+error|not\\s+reported|off|disabled|false|0|zero)\\b` +
    `|\\b${knockFaultTarget}\\s*(?:=|:)\\s*(?:no\\s+error|not\\s+reported|off|disabled|false|0|zero)\\b`, 'i'
  );
  // Reporting-state assignments and declarative shutdowns must be reviewed
  // separately from physical sensor removal. Do not mistake observed values
  // such as "knock sensor DTC count = 0" for a request to disable reporting.
  const knockDtcReportingState = new RegExp(
    `\\b${knockFaultTarget}\\s+(?:(?:enabled?|reporting|state|status)\\s*)?(?:=|:)\\s*(?:0|false|off|disabled|not\\s+reported|no\\s+error)\\b` +
    `|\\b${knockFaultTarget}\\s+(?:disabled|suppressed|masked|hidden|off|not\\s+reported)\\b`, 'i'
  );
  // Explicit DTC reporting/logging suppression can be expressed as a
  // per-code reporting assignment or a negative declarative instruction.
  // Generic P03xx codes are only triage hints, not exact-OS DTC mappings.
  const knockCodeReportingOff = new RegExp(
    `\\b${knockCircuitCodes}\\s+(?:reporting|logging|diagnostics?|dtc\\s+reporting)\\s*(?:=|:)\\s*(?:disabled|off|false|0|not\\s+reported)\\b`, 'i'
  );
  const knockFaultDoNotReport = /\bknock[\s-]*(?:sensors?\s+)?(?:codes?|dtcs?|faults?)\s+(?:should|must|will|need(?:s)?\s+to)\s+not\s+(?:report|log|appear|trigger)\b/i;
  const knockCodeNoLogging = new RegExp(
    `\\b(?:do\\s+not|don['’]?t|dont|never)\\s+(?:log|report|flag|record)\\s+(?:(?:the|my|all|both|dtc|dtcs|codes?|faults?)\\s+){0,3}${knockCircuitCodes}\\b`, 'i'
  );
  // A knock-related DTC's MIL/CEL setting or "no error" classification
  // changes fault visibility even when the request never says "disable DTC".
  // These are generic syntax clues ONLY, not proof that any P03xx code maps
  // to the connected ECM/OS. Do not silently drop this from VATS/fan plans.
  const knockDtcIndicatorTarget = `(?:${knockCircuitCodes}|knock[\\s-]*(?:sensors?|detection|control)\\s+(?:dtcs?|faults?|codes?|trouble\\s+codes?))`;
  const knockIndicatorName = '(?:MIL|CEL|check[\\s-]*engine\\s+light|malfunction\\s+indicator(?:\\s+(?:lamp|light))?)';
  const knockIndicatorSuppression = new RegExp(
    `\\b${knockDtcIndicatorTarget}\\s+(?:(?:${knockIndicatorName})(?:\\s+(?:reporting|status|state|setting))?|(?:dtc\\s+)?(?:type|class|classification))\\s*(?:=|:)\\s*(?:off|disabled|false|0|no\\s+(?:mil|light|error)|not\\s+reported)\\b` +
    `|\\b(?:set|change|mark|configure|make)\\s+(?:(?:the|my|all)\\s+){0,3}${knockDtcIndicatorTarget}\\s+(?:(?:to|as)\\s+)?(?:no\\s+(?:mil|light|error)|(?:mil|cel)\\s+off|not\\s+reported)\\b` +
    // Imperative target-field-value order: 'set P0327 MIL to off' or
    // 'change P0332 DTC type to no error'. The assignment and target-only
    // guards above do not cover these forms. This is syntax triage only.
    `|\\b(?:set|change|mark|configure|make)\\s+(?:(?:the|my|all)\\s+){0,3}${knockDtcIndicatorTarget}\\s+(?:(?:${knockIndicatorName})(?:\\s+(?:reporting|status|state|setting))?|(?:dtc\\s+)?(?:type|class|classification))\\s+(?:to|as)\\s+(?:off|disabled|false|0|no\\s+(?:mil|light|error)|not\\s+reported)\\b` +
    // Object-first shutdown: "turn P0327 MIL off" is not the same as
    // "turn P0327 off" or "turn off MIL for P0327". It must receive its
    // own diagnostic review before a companion VATS/fan plan is admitted.
    `|\\b(?:turn|switch|shut)\\s+(?:(?:the|my|all)\\s+){0,3}${knockDtcIndicatorTarget}\\s+${knockIndicatorName}\\s+off\\b` +
    `|\\b(?:disable|suppress|mask|hide|turn\\s+off|switch\\s+off)\\s+(?:(?:the|my|all)\\s+){0,3}${knockIndicatorName}\\s+(?:for|on)\\s+${knockDtcIndicatorTarget}\\b` +
    // Run210: indicator-first shutdown with OFF after the indicator, e.g.
    // "turn the MIL off for P0327". This changes DTC visibility and must
    // never be silently omitted from a combined VATS/fan request. The code
    // is a syntax-only triage hint, not an OS-specific DTC mapping.
    `|\\b(?:turn|switch|shut)\\s+(?:(?:the|my|all)\\s+){0,3}${knockIndicatorName}\\s+off\\s+(?:for|on)\\s+${knockDtcIndicatorTarget}\\b`, 'i'
  );
  // A target-first DTC classification request can omit the imperative
  // "set <code>" order: "knock sensor codes set to no error" and
  // "P0327 set to no error" are still suppression requests. These are
  // syntactic triage signals, never a controller-specific DTC map.
  const knockDtcTargetFirstSuppression = new RegExp(
    `\\b(?:${knockFaultTarget}|${knockCircuitCodes})\\s+(?:(?:are|is|was|were|should|must|will|need(?:s)?\\s+to)\\s+){0,2}(?:be\\s+)?(?:set|configured|marked|classified)\\s+(?:to|as)\\s+(?:no\\s+(?:error|mil|light)|not\\s+reported|off|disabled|false|0|zero)\\b`, 'i'
  );
  // Declarative knock-code reporting changes and no-MIL classifications
  // also need diagnostic review. The shorter "knock DTCs" form was previously
  // missed by the descriptive sensor-code matcher. This does not identify
  // a controller-specific code or disable any protection.
  const knockReportingTarget = String.raw`(?:knock[\s-]*(?:dtcs?|codes?|faults?)|${knockFaultTarget})`;
  const knockReportingDeclarative = new RegExp(
    `\\b${knockReportingTarget}\\s+(?:(?:should|must|will|needs?\\s+to)\\s+){1,2}(?:be\\s+)?(?:ignored|suppressed|masked|hidden|disabled|off|not\\s+reported)\\b` +
    `|\\b${knockReportingTarget}\\s*(?:=|:)\\s*(?:no\\s+mil|no\\s+error|not\\s+reported|off|disabled)\\b`, 'i'
  );
  // Run324: "knock sensor DTC reporting should be suppressed" names a
  // reporting field, not a DTC code. The generic knock-reporting target did
  // not include this phrase, so a mixed VATS/fan request could silently
  // discard a knock-fault suppression directive. Review this separately;
  // do not infer any OS-specific DTC or change knock protection.
  const knockSensorDtcReportingDirective = /\bknock[\s-]*sensors?\s+(?:dtc|code|fault)\s+reporting\s+(?:(?:should|must|will|needs?\s+to|is|was)\s+){1,2}(?:be\s+)?(?:suppressed|disabled|masked|hidden|turned\s+off)\b/gi;
  const knockSensorDtcReportingReview = [...source.matchAll(knockSensorDtcReportingDirective)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    return !/\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
  });
  if (knockSensorDtcReportingReview || knockReportingDeclarative.test(source) || knockFaultSuppression.test(source) || knockDtcCodeSuppression.test(source) ||
      knockDtcAssignmentSuppression.test(source) || knockDtcReportingState.test(source) ||
      knockCodeReportingOff.test(source) || knockFaultDoNotReport.test(source) ||
      knockCodeNoLogging.test(source) || knockIndicatorSuppression.test(source) ||
      knockDtcTargetFirstSuppression.test(source)) {
    unresolved.push({
      type: 'knock-diagnostic-suppression',
      label: 'Knock fault-reporting change requires diagnostic review',
      status: 'needs-review',
      requirement: 'Do not suppress knock-sensor DTCs or fault reporting as part of an automatic VATS/fan request. Diagnose sensors, wiring, and controller faults separately; this check does not establish working knock protection.'
    });
  }

  const ghostOnly = hasIntent('ghost-cam');
  // Physical stage-cam descriptions also use Roman numerals ("Stage II"),
  // spelled-out stages ("Stage Two"), and reversed brand order ("Stage 2
  // LSX cam"). Do not let a VATS quick-service request silently discard
  // those unimplemented physical-cam calibration instructions.
  const stageCam = /\b(?:(?:lsx|lsxceleration)\s*)?stage\s*(?:\d+|i{1,3}|iv|v|one|two|three|four)\s+(?:(?:lsx|lsxceleration)\s+)?cam(?:shaft)?\b/i;
  // Run213: Hyphenated cam-card and cam profile/grind requests are physical
  // calibration work too. Never silently propose only VATS/fan changes when
  // the owner asks for an LSX cam tune without supplying the exact cam card.
  // A cam position sensor inspection or camera UI request is not cam tuning.
  // Run214: In a mixed quick-service request the owner may say "tune for
  // my new cam" or "adjust idle for the cam". These are physical camshaft
  // calibration requests even without the words camshaft, stage or cam-card.
  // Match a bounded tuning verb followed by a standalone "cam", not camera
  // or cam-position sensor inspection. Do not confuse a ghost-cam preset
  // with a separate physical-cam tuning instruction.
  const physicalCamAction = /\b(?:tune|calibrate|recalibrate|adjust(?:\s+idle(?:\s+airflow)?)?)\s+(?:(?:the|for|to|around|after|my|a|an|new|installed|bigger|lsx|lsxceleration|physical)\s+){0,8}cam\b(?![\s-]*(?:position|sensor)\b)/i.test(source);
  // Run267: physical cam installation may be described as "installed a
  // bigger cam", "swapped cams", or "cam is installed" rather than using
  // the compound "cam install". This is an uncommissioned engine change,
  // not permission to propose a VATS/fan-only revision. Do not infer cam
  // card data, timing, airflow, injector data, or a safe OS mapping.
  const installedPhysicalCam = /\b(?:install(?:ed|ing)?|swap(?:ped|ping)?|replac(?:e|ed|ing)|put)\s+(?:(?:a|the|my|new|different|bigger|lsx|lsxceleration|physical)\s+){0,6}cams?\b|\bcams?\s+(?:(?:has|have|was|were|is|are)\s+)?(?:been\s+)?(?:installed|swapped|replaced)\b|\b(?:new|different|bigger)\s+cam\s+(?:went|goes)\s+in\b/i.test(source);
  // A tune request can target idle airflow "for my LSX cam" without the
  // original narrow "tune cam" word order. Keep cam-position sensors and
  // camera controls out of the physical camshaft classification.
  const physicalCamIdleAction = /\b(?:tune|calibrate|recalibrate|adjust|change|modify)\s+(?:(?:the|my|new|stock|base|idle|airflow|spark|fuel|for|to|after|around|because|of|a|an|bigger|lsx|lsxceleration|physical)\s+){0,10}cam\b(?![\s-]*(?:position|sensor)\b)/i.test(source);
  // "Bumpstick" is a camshaft synonym, but simply comparing products is
  // not an installed physical cam or a tuning instruction.
  const bumpstickTune = /\b(?:tune|calibrate|recalibrate|adjust|change|modify)\b[^.!?;]{0,65}\bbump[\s-]?stick\b|\bbump[\s-]?stick\b[^.!?;]{0,40}\b(?:tune|calibrate|adjust)\b|\b(?:lsx|lsxceleration)?\s*stage\s*(?:\d+|i{1,3}|iv|v|one|two|three|four)\s+bump[\s-]?stick\b/i.test(source);
  // Run270: An engine can already be running an aftermarket cam without
  // the owner using "installed", "swapped", "stage", or "camshaft". A combined
  // VATS/fan proposal must not silently discard that uncommissioned physical
  // change. Require a running-cam statement, an engine-specific in-use
  // location, or an engine-as-subject claim. Owning an uninstalled cam in a
  // box, cam-position sensors, cameras and ghost-cam presets are not proof
  // of an installed physical cam. No specs or idle targets are inferred.
  const physicalCamTarget = String.raw`cams?\b(?![\s-]*(?:position|sensor)\b)`;
  const physicalCamInUse = new RegExp(
    String.raw`\b(?:i|we)\s+(?:(?:am|are)\s+)?(?:run|running)\s+(?:(?:a|an|the|my|new|aftermarket|performance|custom|bigger|lsx|lsxceleration)\s+){0,6}${physicalCamTarget}` +
    String.raw`|\b(?:i|we)\s+(?:have|got)\s+(?:(?:a|an|the|my|new|aftermarket|performance|custom|bigger|lsx|lsxceleration)\s+){0,6}${physicalCamTarget}\s+(?:in|inside)\s+(?:(?:my|the|our)\s+)?(?:5\.3|ls|engine|motor|truck)\b` +
    String.raw`|\b(?:my|the|our)\s+(?:5\.3|ls|engine|motor|truck)\s+(?:has|runs|is\s+running)\s+(?:(?:a|an|the|my|new|aftermarket|performance|custom|bigger|lsx|lsxceleration)\s+){0,6}${physicalCamTarget}`, 'i'
  ).test(source);
  const physicalCam = /\bcamshaft\b|\bcam[\s-]*(?:card|specs?|profile|grind|swap|upgrade|install|tune|tuning|calibration)\b/i.test(source) || stageCam.test(source) || physicalCamAction || installedPhysicalCam || physicalCamIdleAction || bumpstickTune || physicalCamInUse;
  if (physicalCam && (!ghostOnly || /\bcamshaft\b/i.test(source) || stageCam.test(source) || physicalCamAction || installedPhysicalCam || physicalCamIdleAction || bumpstickTune || physicalCamInUse)) {
    unresolved.push({
      type: 'physical-camshaft-tune',
      label: 'Physical camshaft calibration',
      status: 'needs-review',
      requirement: 'A physical camshaft tune is not an automatic P01 quick-service preset. Supply the exact cam card, valve-spring and injector details, controller OS, matching definition, and baseline idle/airflow logs for a separate reviewed calibration plan; no cam values have been generated.'
    });
  }

  // Temperature cells do not establish that the ECM output pin, relays,
  // fuses, or physical fan circuit have been commissioned.
  // An output/relay state request may be declarative rather than imperative:
  // "fan relays should be enabled" is not the same as "fans on at 210 F".
  // Reuse the same explicit output target for shutdown detection below.
  const fanOutputTarget = '(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\\s+){0,3}fans?\\s+(?:relays?(?:\\s+(?:outputs?|drivers?|controls?))?|outputs?|controls?(?:\\s+outputs?)?|drivers?)';
  const fanOutputEnableDeclarative = new RegExp(
    `\\b${fanOutputTarget}\\s+(?:(?:should|must|will|needs?\\s+to|have\\s+to|has\\s+to|is\\s+to|are\\s+to)\\s+)(?:be\\s+)?(?:enabled|activated|on|turned\\s+on|switched\\s+on)\\b`, 'i'
  );
  // A physical output's enable flag/bit/state is NOT its temperature pair.
  // "set PCM fan output enable flag to 1" previously vanished from a combined
  // VATS + fan request. These are syntax-only admission checks; they do not
  // establish the flag's OS-specific address, polarity, or supported value.
  const fanEnableFlagTarget = String.raw`(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\s+){0,3}fans?\s+(?:(?:relays?|outputs?|controls?|drivers?)\s+){0,2}enable(?:ment|d)?\s+(?:flags?|bits?|states?|settings?)`;
  const fanFlagStateRequested = values => {
    const state = `(?:${values})`;
    const action = new RegExp(
      String.raw`\b(?:set|make|change|switch|turn|mark|force|configure|write)\s+(?:(?:the|my|both|dual|two|all)\s+){0,3}${fanEnableFlagTarget}\s+(?:to\s+)?${state}\b` +
      String.raw`|\b${fanEnableFlagTarget}\s+(?:should|must|needs?\s+to|is\s+to|are\s+to|will)\s+(?:be\s+)?(?:set\s+to\s+)?${state}\b`, 'i'
    );
    // Assignment notation is ambiguous between a requested change and an
    // observed state. Refuse partial proposals until separately reviewed.
    // This never infers an OS-specific address, flag polarity, or value.
    const assignment = new RegExp(
      String.raw`\b${fanEnableFlagTarget}\s*(?:=|:)\s*${state}\b`, 'i'
    );
    return action.test(source) || assignment.test(source);
  };
  const fanEnableFlagOn = fanFlagStateRequested('1|true|on|enabled|active');
  const fanEnableFlagOff = fanFlagStateRequested('0|false|off|disabled|inactive');
  // Assignment-style relay/output states also require separate review even
  // when the request omits the word "enable flag". The quick-service parser
  // otherwise keeps only VATS + temperature instructions and silently drops
  // e.g. "ECM fan output = on" or "fan relay driver: 0". These are syntax
  // clues only: a numeric state is NOT proof of OS-specific polarity/pins.
  const fanOutputStateAssignment = values => new RegExp(
    `\\b${fanOutputTarget}\\s*(?:\\s+(?:enabled?|active|activation|state|status|setting))?\\s*(?:=|:)\\s*(?:${values})\\b`, 'i'
  ).test(source);
  // Run237: Do not assume only output indices 1 and 2 can appear in user
  // text. An unknown index (including 0, 3 or 10) is NOT evidence that
  // such a controller output exists; its request still needs independent
  // exact-OS/wiring review rather than silently dropping it.
  // Indexed physical output assignments ("fan output 1 = enabled")
  // require their own wiring/OS review; a shared temperature pair cannot
  // establish output 1/2 enablement. Treat ambiguous assignment as review.
  // Run238: The physical output index may be spoken ("relay three") or
  // prefixed with "number". This is a request-review clue only; no output
  // count, OS map, relay pin, or controller capability is inferred.
  const fanIndexToken = String.raw`(?:\d{1,3}|zero|one|two|three|four|five|six|seven|eight|nine|ten)`;
  const indexedFanOutput = String.raw`(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\s+){0,3}fans?\s+(?:relays?|outputs?|controls?|drivers?)\s*(?:#\s*|number\s+)?${fanIndexToken}\b`;
  const indexedFanState = values => new RegExp(
    String.raw`\b${indexedFanOutput}\s*(?:=|:)\s*(?:${values})\b`, 'i'
  ).test(source);
  // Run224: Indexed output status fields ("fan relay 1 enabled = false")
  // and simple declarative states ("fan relay 2 is disabled") cannot be
  // represented by the shared temperature pair. These may be observations,
  // not commands; either way require independent output/OS/wiring review.
  // Do not infer the meaning of a controller flag or a physical pin here.
  const indexedFanStatusState = values => new RegExp(
    String.raw`\b${indexedFanOutput}\s+(?:enable(?:d|ment)?|active|activation|status|state|setting)(?:\s+(?:flags?|bits?|states?|settings?))?\s*(?:=|:)\s*(?:${values})\b` +
    String.raw`|\b${indexedFanOutput}\s+(?:is|are|was|were)\s+(?:(?:currently|already)\s+)?(?:${values})\b`, 'i'
  ).test(source);
  const fanOutputStateOn = fanOutputStateAssignment('1|true|on|enabled|active') || indexedFanState('1|true|on|enabled|active') || indexedFanStatusState('1|true|on|enabled|active');
  const fanOutputStateOff = fanOutputStateAssignment('0|false|off|disabled|inactive') || indexedFanState('0|false|off|disabled|inactive') || indexedFanStatusState('0|false|off|disabled|inactive');
  // Changing the controller's fan control *mode/type* (relay, PWM,
  // electric, etc.) is output commissioning, not a coolant setpoint.
  // This is a request-coverage guard only: no OS flag, polarity or pin
  // is inferred from any of these words. An assignment is ambiguous and
  // must be reviewed rather than silently ignored in a mixed request.
  const fanModeTarget = '(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\\s+){0,3}fans?\\s+(?:(?:control|output|relay|pwm)\\s+)?(?:mode|type|strategy)';
  const fanModeValue = '(?:electric|relay|pwm|dual|two[\\s-]*speed|single[\\s-]*speed)';
  const fanModeChange = new RegExp(
    `\\b(?:set|change|configure|convert|switch|make|select)\\s+(?:(?:the|my)\\s+){0,2}${fanModeTarget}\\s+(?:to|as)\\s+${fanModeValue}\\b` +
    `|\\b${fanModeTarget}\\s+(?:(?:should|must|will|needs?\\s+to|is|are)\\s+){0,2}(?:be\\s+)?(?:set|configured|changed|converted)\\s+(?:to|as)\\s+${fanModeValue}\\b` +
    `|\\b${fanModeTarget}\\s*(?:=|:)\\s*${fanModeValue}\\b`, 'i'
  );
  // Run206: A PWM duty/frequency or relay drive-polarity request is a
  // physical output strategy change, NOT a coolant threshold. A valid VATS
  // and fan-temperature pair must not silently drop an additional output
  // strategy instruction. These words are triage only: they do not imply
  // that this ECM/OS supports PWM, a specific frequency, or any pin polarity.
  const fanStrategyTarget = String.raw`(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\s+){0,3}fans?\s+(?:(?:relay|output|control|driver|pwm)\s+){0,3}(?:duty\s+cycle|frequency|polarity|drive\s+mode)`;
  const fanStrategyDirective = new RegExp(
    String.raw`\b(?:set|change|configure|make|select|switch|invert|reverse|force|adjust|tune)\s+(?:(?:the|my)\s+){0,2}${fanStrategyTarget}\b` +
    String.raw`|\b${fanStrategyTarget}\s*(?:=|:)\s*[a-z0-9]` +
    String.raw`|\b${fanStrategyTarget}\s+(?:should|must|will|needs?\s+to|is\s+to|are\s+to)\s+(?:be\s+)?(?:active|inverted|normal|ground[-\s]*switched|power[-\s]*switched|\d{1,4})\b`, 'i'
  );
  const fanDriveTarget = String.raw`(?:(?:pcm|ecm|factory|stock|electric|cooling|radiator)\s+){0,3}fans?\s+(?:relay|output|control|driver)(?:\s+(?:output|control|driver))?`;
  const fanDriveDirective = new RegExp(
    String.raw`\b(?:set|change|configure|make|select|switch)\s+(?:(?:the|my)\s+){0,2}${fanDriveTarget}\s+(?:to|as)\s+(?:ground[-\s]*switched|power[-\s]*switched|active[-\s]*(?:low|high)|inverted|negative|positive)\b`, 'i'
  );
  // Run207: An indexed relay/driver's polarity or drive mode is not a
  // generic fan-temperature setting. "fan relay #2 to active low" and
  // "ECM fan output 1 polarity = inverted" previously passed as fully
  // covered VATS/fan requests, silently omitting a physical output change.
  // This is a conservative request classifier, NOT an OS-specific mapping.
  const indexedFanDriveTarget = indexedFanOutput;
  const indexedFanDriveValue = String.raw`(?:ground[-\s]*switched|power[-\s]*switched|active[-\s]*(?:low|high)|inverted|normal|reversed|negative|positive)`;
  const indexedFanDriveDirective = new RegExp(
    String.raw`\b(?:set|change|configure|make|select|switch|invert|reverse|force|adjust)\s+(?:(?:the|my)\s+){0,2}${indexedFanDriveTarget}\s+(?:(?:polarity|drive\s+mode|output\s+mode)\s+)?(?:to|as)\s+${indexedFanDriveValue}\b` +
    String.raw`|\b${indexedFanDriveTarget}\s+(?:(?:polarity|drive\s+mode|output\s+mode)\s*)?(?:=|:)\s*${indexedFanDriveValue}\b` +
    String.raw`|\b${indexedFanDriveTarget}\s+(?:(?:polarity|drive\s+mode|output\s+mode)\s+)?(?:should|must|will|needs?\s+to|is\s+to|are\s+to)\s+(?:be\s+)?${indexedFanDriveValue}\b`, 'i'
  );
  if (fanStrategyDirective.test(source) || fanDriveDirective.test(source) || indexedFanDriveDirective.test(source)) {
    unresolved.push({
      type: 'fan-output-strategy',
      label: 'Electric fan output drive strategy',
      status: 'needs-review',
      requirement: 'PWM duty/frequency and relay-output polarity or drive strategy are independent of fan on/off temperatures. Verify controller OS support, output pins, wiring, and hardware before proposing any strategy change; no duty, frequency, or polarity has been assumed.'
    });
  }

  // Run251: A requested fan-output pin assignment is a separate physical
  // wiring/OS-mapping decision, not a coolant threshold or proof of an
  // enabled output. Never infer a pin number or silently drop this clause
  // from an otherwise recognized VATS/fan proposal. Numbers are text-only
  // request tokens; this code contains no supported ECM pin definitions.
  const fanPinNumber = String.raw`(?:#\s*)?\d{1,3}`;
  // Run254: 'electric fan output' and 'cooling fan relay output' still
  // describe physical pin assignments. These qualifiers cannot turn a
  // hardware/OS mapping change into a temperature-only quick-service plan.
  const fanPinOutput = String.raw`(?:(?:pcm|ecm)\s+)?(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:(?:relay|control|output|driver)\s+){1,3}`;
  const fanPinMappingDirective = new RegExp(
    String.raw`\b(?:assign|map|move|route|wire|connect|reassign)\s+(?:(?:the|my|stock|factory)\s+){0,2}${fanPinOutput}(?:to|onto|on)\s+(?:(?:pcm|ecm)\s+)?pin\s*${fanPinNumber}\b` +
    String.raw`|\b${fanPinOutput}pins?\s*(?:=|:)\s*${fanPinNumber}\b` +
    String.raw`|\b(?:use|assign|map|route|wire|connect)\s+(?:(?:the|my)\s+)?(?:pcm|ecm)\s+pin\s*${fanPinNumber}\s+(?:for|as|to)\s+(?:(?:the|my)\s+)?fans?\s+(?:relay|control|output|driver)\b` +
    // Run252: Pin-property and "through ECM pin" directives were silently
    // dropped even though they change physical wiring/OS output mapping.
    // Treat all numbers as unverified request text; never infer a real pin.
    String.raw`|\b(?:set|change|configure|assign|map|move|reassign)\s+(?:(?:the|my|stock|factory)\s+){0,2}${fanPinOutput}pins?\s+(?:to|as)\s+(?:(?:pcm|ecm)\s+)?(?:pin\s*)?${fanPinNumber}\b` +
    String.raw`|\b(?:route|wire|connect|map|assign)\s+(?:(?:the|my|stock|factory)\s+){0,2}${fanPinOutput}(?:through|via|using)\s+(?:(?:the|my)\s+)?(?:pcm|ecm)\s+pin\s*${fanPinNumber}\b` +
    String.raw`|\b${fanPinOutput}(?:pins?\s+)?(?:should|must|will|needs?\s+to|has\s+to|is\s+to|are\s+to)\s+(?:be\s+)?(?:use|using|mapped\s+to|assigned\s+to)\s+(?:(?:pcm|ecm)\s+)?pin\s*${fanPinNumber}\b`, 'i'
  );
  // Run253: Connector-qualified assignments ("ECM C2 pin 42" or "C2-42")
  // were invisible to the numeric-only pin guard. These are *synthetic text*
  // patterns, not verified ECM connector labels or physical pin mappings.
  // Diagnostic questions/inspections without a requested change remain safe.
  const connectorQualifiedPin = String.raw`(?:connector\s+)?[a-z]\d{1,2}\s*(?:[-/:]\s*|\s+pin\s*)\d{1,3}`;
  const fanConnectorPinDirective = new RegExp(
    String.raw`\b(?:assign|map|move|route|wire|connect|reassign|set|change|configure)\s+(?:(?:the|my|stock|factory)\s+){0,2}${fanPinOutput}(?:pins?\s+)?(?:to|onto|on|through|via|using|as)\s+(?:(?:pcm|ecm)\s+)?${connectorQualifiedPin}\b` +
    String.raw`|\b${fanPinOutput}pins?\s*(?:=|:)\s*${connectorQualifiedPin}\b` +
    String.raw`|\b(?:use|assign|map|route|wire|connect)\s+(?:(?:the|my)\s+)?(?:pcm|ecm)\s+${connectorQualifiedPin}\s+(?:for|as|to)\s+(?:(?:the|my)\s+)?(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:relay|control|output|driver)\b`, 'i'
  );
  // Run255: Connector-first assignments ("ECM C2 pin 42 = fan output",
  // "C2-42 should drive the fan relay") also change physical output mapping.
  // Earlier guards required the fan noun to precede the connector, silently
  // admitting VATS/temperature-only proposals. Match only affirmative mapping
  // directives or assignments; read-only inspections remain nonblocking.
  // These are syntactic request tokens, NOT real connector or OS definitions.
  const connectorPinSubject = String.raw`(?:(?:pcm|ecm)\s+)?(?:connector\s+)?[a-z]\d{1,2}\s*(?:[-/:]\s*|\s+pin\s*)\d{1,3}`;
  const connectorFanTarget = String.raw`(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:(?:relay|control|output|driver)\s*){1,3}`;
  const connectorFirstFanDirective = new RegExp(
    String.raw`\b${connectorPinSubject}\s*(?:=|:)\s*(?:(?:the|my|new|stock|factory)\s+){0,3}${connectorFanTarget}\b` +
    String.raw`|\b${connectorPinSubject}\s+(?:should|must|will|needs?\s+to|is\s+to)\s+(?:drive|power|trigger|control|activate|operate)\s+(?:(?:the|my|new)\s+){0,3}${connectorFanTarget}\b` +
    String.raw`|\b${connectorPinSubject}\s+is\s+(?:(?:the|my)\s+)?(?:new|assigned|designated)\s+${connectorFanTarget}\b` +
    String.raw`|\b(?:assign|set|map|wire|route|use)\s+${connectorPinSubject}\s+(?:as|for|to)\s+(?:(?:the|my)\s+)?${connectorFanTarget}\b`, 'i'
  );
  if (fanPinMappingDirective.test(source) || fanConnectorPinDirective.test(source) || connectorFirstFanDirective.test(source)) {
    unresolved.push({
      type: 'fan-output-pin-mapping',
      label: 'Electric fan output pin mapping',
      status: 'needs-review',
      requirement: 'A fan relay/output pin assignment needs independent verification against the exact ECM hardware, OS, harness, relay/fuse wiring, and output enable state. No pin, polarity, or compatibility was inferred; fan temperatures alone do not authorize wiring changes.'
    });
  }

  // Run199: Indexed output directives such as "fan relay 1 should be
  // enabled" are physical-output commissioning, NOT a fan temperature.
  // Earlier guards recognized indexed assignments ("relay 1 = enabled")
  // but silently dropped declarative requests with should/must/is to.
  // Keep the review independent of any OS-specific pin, polarity or relay map.
  const indexedFanOutputTarget = indexedFanOutput;
  const indexedFanOutputDirective = state => new RegExp(
    String.raw`\b${indexedFanOutputTarget}\s+(?:should|must|will|needs?\s+to|has\s+to|is\s+to|are\s+to)\s+(?:be\s+)?(?:${state})\b`, 'i'
  ).test(source);
  const indexedFanOutputEnableDirective = indexedFanOutputDirective(String.raw`enabled|activated|on|turned\s+on|switched\s+on`);
  const indexedFanOutputDisableDirective = indexedFanOutputDirective(String.raw`disabled|deactivated|off|turned\s+off|switched\s+off|disconnected`);
  // Run221: Indexed relay/output enable flags are separate from fan
  // temperature setpoints. "Fan relay 1 enable flag = 0" must not vanish
  // from a mixed VATS/fan request. These are syntax-only admission guards;
  // the meaning/polarity of an actual OS flag and its pin map are unknown.
  const indexedFanEnableTarget = String.raw`${indexedFanOutputTarget}\s+enable(?:ment|d)?\s+(?:flags?|bits?|states?|settings?)`;
  const indexedFanEnableState = values => new RegExp(
    String.raw`\b${indexedFanEnableTarget}\s*(?:=|:)\s*(?:${values})\b` +
    String.raw`|\b${indexedFanEnableTarget}\s+(?:should|must|will|needs?\s+to|has\s+to|is\s+to|are\s+to)\s+(?:be\s+)?(?:${values})\b` +
    String.raw`|\b(?:set|make|change|switch|turn|mark|force|configure)\s+(?:(?:the|my)\s+){0,2}${indexedFanEnableTarget}\s+(?:to\s+)?(?:${values})\b`, 'i'
  ).test(source);
  const indexedFanEnableOn = indexedFanEnableState('1|true|on|enabled|active');
  const indexedFanEnableOff = indexedFanEnableState('0|false|off|disabled|inactive');
  // Run264: converting a clutch/mechanical fan to electric cooling is a
  // physical hardware change, even when described in the past tense rather
  // than as an imperative to enable an ECM relay. Fan-on/off temperatures do
  // not establish output pin, relay, fuse, wiring, or exact-OS compatibility.
  // Keep ordinary observations and conversion-of-temperature-units separate.
  const physicalFanConversion =
    /\b(?:converted|converting|swapped|swapping|replaced|replacing)\b[^.!?;]{0,80}\b(?:clutch|mechanical|belt[-\s]*driven|stock|factory|truck|vehicle|fans?|cooling\s+system)\b[^.!?;]{0,80}\b(?:dual\s+)?electric\s+(?:cooling\s+)?fans?\b/i.test(source) ||
    /\b(?:retrofitted|retrofitting)\s+(?:(?:the|my|a|an|new|dual|two)\s+){0,5}electric\s+(?:cooling\s+)?fans?\b/i.test(source) ||
    /\b(?:installed|installing|fitted|fitting|added|adding|mounted|mounting)\s+(?:(?:a|an|the|my|new|dual|two|aftermarket)\s+){0,5}electric\s+(?:cooling\s+)?fans?\s+(?:conversion\s+)?kit\b/i.test(source);
  // Run271: Owners often describe a completed electric-fan installation
  // without saying "conversion" or "kit". Installing/mounting the fans is
  // physical commissioning, not proof the ECM fan output is enabled. Keep
  // negative and inspection-only statements from asserting an installation.
  // This is text triage only: no OS output map, relay pin, or target is inferred.
  const installedElectricFans = /\b(?:installed|installing|added|adding|mounted|mounting|fitted|fitting)\s+(?:(?:a|an|the|my|new|dual|two|both|aftermarket|pair|of|cooling|radiator)\s+){0,6}electric\s+(?:cooling\s+)?fans?\b/gi;
  const physicalFanInstalled = [...source.matchAll(installedElectricFans)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    return !(/\b(?:not|never|haven['’]?t|hasn['’]?t|hadn['’]?t|didn['’]?t)\s*(?:(?:yet|actually|already|ever)\s*)?$/i.test(prefix) ||
      /\b(?:check|inspect|verify|determine)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix));
  });
  // Run330: Owners can report completed electric-fan wiring without using
  // "install", "enable" or "conversion". Such a report still requires an
  // independent PCM output/relay/wiring review; it cannot be represented by
  // the single parsed fan temperature pair. This detects affirmative wiring
  // statements only, not questions or explicit negations. No pin/OS mapping
  // or real fan enable state is inferred from this text.
  const fanWiringState = /\b(?:electric\s+)?fans?\s+(?:are|is|were|was|have\s+been|has\s+been)\s+(?:(?:already|fully|now|currently)\s+)?(?:wired(?:\s+(?:in|up|to|into))?|hooked\s+up|connected)\b/gi;
  const fanWiringAction = /\b(?:wired(?:\s+(?:in|up))?|connected|hooked\s+up)\s+(?:(?:the|my|our|both|dual|two|all|new)\s+){0,5}(?:electric\s+)?fans?\b/gi;
  const fanWiringReview = [...source.matchAll(fanWiringState), ...source.matchAll(fanWiringAction)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const negated = /\b(?:not|never|didn['’]?t|haven['’]?t|hasn['’]?t|hadn['’]?t|wasn['’]?t|weren['’]?t)\s*(?:(?:yet|actually|already|ever)\s*)?$/i.test(prefix);
    const directQuestion = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|electric)){0,4}$/i.test(prefix) && /\?/.test(remainder);
    return !diagnostic && !negated && !directQuestion;
  });
  // Run346: Passive statements about fan RELAY/OUTPUT wiring are separate
  // commissioning facts, not verified PCM output enablement. The older
  // fanWiringState recognized only "fans are wired" and missed "fan relays
  // are wired" / "fan output wiring is complete". Do not infer OS pins,
  // polarity, relay compatibility, or a fan-enable bit from these words.
  const fanCircuitWiringState = /\b(?:(?:pcm|ecm)\s+)?fans?\s+(?:relays?|outputs?|drivers?|controls?)(?:\s+(?:harness|wiring|wires?|connectors?))?\s+(?:are|is|were|was|have\s+been|has\s+been)\s+(?:(?:already|fully|now|currently)\s+)?(?:wired(?:\s+(?:in|up|to|into))?|hooked\s+up|connected|complete)\b/gi;
  const fanCircuitWiringReview = [...source.matchAll(fanCircuitWiringState)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)\s+(?:(?:the|my|both|all|two|pcm|ecm)\s+){0,4}$/i.test(prefix) &&
      /^\s*\?/.test(source.slice(match.index + match[0].length));
    return !diagnostic && !question;
  });
  // Run347: Passive relay/harness installation is also a physical fan-circuit
  // change. "Fan relays have been installed" and "fan relay wiring has been
  // completed" previously passed as a temperature-only request. This is
  // triage, not evidence that a PCM output, relay or fuse is compatible.
  const fanCircuitInstalled = /\b(?:(?:pcm|ecm)\s+)?fans?\s+(?:relays?|outputs?|drivers?|controls?)(?:\s+(?:harness|wiring|wires?|connectors?))?\s+(?:are|is|were|was|have|has|had)\s+(?:been\s+)?(?:(?:not|never|already|fully|now|currently|yet)\s+){0,3}(?:installed|fitted|mounted|completed)\b/gi;
  const fanCircuitInstallReview = [...source.matchAll(fanCircuitInstalled)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const statement = match[0];
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|pcm|ecm))*$/i.test(prefix) && /^\s*\?/.test(remainder);
    const negated = /\b(?:not|never|no\s+longer)\b/i.test(statement);
    return !diagnostic && !question && !negated;
  });
  // Run349: A fan circuit explicitly reported as NOT connected/installed is
  // not a verified ECM fan output. The old completed-wiring patterns ignored
  // contracted negatives ("relays aren't wired", "harness isn't complete")
  // and passive disconnected states, allowing a VATS/temperature-only plan.
  // This is diagnostic request triage, not a pin, OS, polarity or relay map.
  const fanCircuitTarget = String.raw`(?:(?:pcm|ecm)\s+)?fans?\s+(?:relays?|outputs?|drivers?|controls?)(?:\s+(?:harness|wiring|wires?|connectors?))?`;
  const fanCircuitIncomplete = new RegExp(
    String.raw`\b${fanCircuitTarget}\s+(?:aren['’]?t|isn['’]?t|weren['’]?t|wasn['’]?t|haven['’]?t|hasn['’]?t|hadn['’]?t|are\s+not|is\s+not|were\s+not|was\s+not|have\s+not|has\s+not|had\s+not|never)\s+(?:yet\s+)?(?:been\s+)?(?:wired(?:\s+(?:in|up|to|into))?|connected|installed|completed?|hooked\s+up|fitted|mounted)\b` +
    String.raw`|\b${fanCircuitTarget}\s+(?:are|is|were|was|have|has|had)\s+(?:been\s+)?(?:still\s+)?(?:disconnected|unwired|unplugged|incomplete|uninstalled)\b`, 'gi'
  );
  const fanCircuitIncompleteReview = [...source.matchAll(fanCircuitIncomplete)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|pcm|ecm))*$/i.test(prefix) && /^\s*\?/.test(remainder);
    return !diagnostic && !question;
  });
  if (fanCircuitIncompleteReview) {
    unresolved.push({
      type: 'fan-circuit-incomplete',
      label: 'Electric fan circuit connection requires diagnostic review',
      status: 'needs-review',
      requirement: 'Reported incomplete/disconnected fan relay or ECM output wiring must be diagnosed separately from temperature thresholds. Verify exact-OS output enablement, pins, relays, fuses and physical connections; do not assume the circuit is functional.'
    });
  }
  // Run357: A reported failed fuse, relay, output driver or wiring is a
  // cooling-circuit diagnostic blocker even when the owner supplies both
  // temperature thresholds. These are text-only fault reports, not evidence
  // of an exact-OS output map or a working physical cooling system. Avoid
  // converting inspection questions or explicitly negated faults into
  // affirmative hardware-failure claims.
  const fanCircuitFaultTarget = String.raw`(?:(?:pcm|ecm)\s+)?(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:(?:relays?|outputs?|drivers?|controls?)(?:\s+(?:fuses?|contacts?|wiring|harness|drivers?))?|fuses?|wiring|harness|connectors?)`;
  const fanCircuitFault = new RegExp(
    String.raw`\b${fanCircuitFaultTarget}\s+(?:is|are|was|were|has|have|had)\s+(?:been\s+)?(?:blown|failed|burnt\s+out|burned\s+out|damaged|shorted|open[\s-]*circuit|welded\s+shut)\b`, 'gi'
  );
  const fanCircuitFaultReview = [...source.matchAll(fanCircuitFault)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had)(?:\s+(?:the|my|both|all|two|pcm|ecm))*$/i.test(prefix) && /^\s*\?/.test(remainder);
    return !diagnostic && !question;
  });
  if (fanCircuitFaultReview) {
    unresolved.push({
      type: 'fan-circuit-fault',
      label: 'Reported electric-fan circuit fault requires diagnostics',
      status: 'needs-review',
      requirement: 'A reported blown fuse, failed relay, damaged ECM fan driver, or shorted fan wiring requires independent physical diagnosis. Temperature thresholds do not repair a fan circuit; verify output enablement, relays, fuses, wiring, and exact-OS definitions before any calibration proposal.'
    });
  }
  const fanHardwareAction =
    physicalFanConversion || physicalFanInstalled || fanWiringReview || fanCircuitWiringReview || fanCircuitInstallReview || fanEnableFlagOn || fanOutputStateOn || indexedFanOutputEnableDirective || indexedFanEnableOn || fanOutputEnableDeclarative.test(source) ||
    fanModeChange.test(source) ||
    // Output/relay activation and physical installation are separate from
    // temperature table changes. Include common ECM and swap terminology.
    /\b(?:enable|activate|install|convert|wire|commission|configure|hook\s*up|set\s*up)\s+(?:(?:the|my|both|dual|two|all|pcm|ecm|factory|stock)\s+){0,4}(?:(?:electric|cooling|radiator)\s+)?fans?\b/i.test(source) ||
    /\b(?:enable|activate|commission|configure|wire|hook\s*up|set\s*up)\s+(?:(?:the|my|both|dual|pcm|ecm|factory|stock)\s+){0,4}(?:fan|fans)\s+(?:relays?|outputs?|controls?|drivers?)\b/i.test(source) ||
    /\b(?:switch|convert|change)\s+(?:(?:the|my)\s+)?(?:over\s+)?to\s+(?:electric|cooling)\s+fans?\b/i.test(source) ||
    // Explicit PCM/ECM fan output/control activation is not a temperature
    // threshold. Match both "turn on PCM fan control" and "turn PCM fan
    // control on"; the temperature-only pattern below stays distinct.
    /\b(?:turn|switch|power)\s+on\s+(?:(?:the|my)\s+)?(?:pcm|ecm|factory|stock)\s+(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:relays?(?:\s+outputs?)?|outputs?|controls?|drivers?)\b/i.test(source) ||
    /\b(?:turn|switch|power)\s+(?:(?:the|my)\s+)?(?:pcm|ecm|factory|stock)\s+(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:relays?(?:\s+outputs?)?|outputs?|controls?|drivers?)\s+on\b/i.test(source) ||
    // A fan relay/output may be described without the PCM/ECM prefix.
    // Object-first "turn fan outputs on" is commissioning, whereas "turn
    // fans on at 210 F" remains a temperature-only instruction.
    /\b(?:turn|switch|power)\s+(?:(?:the|my|both|dual|two|all|pcm|ecm|factory|stock)\s+){0,4}(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:relays?(?:\s+outputs?)?|outputs?|controls?|drivers?)\s+on\b/i.test(source) ||
    // "Turn fans on at 210 F" describes a temperature threshold; it is not
    // evidence that the user asked to commission the PCM output hardware.
    /\b(?:(?:turn|switch|power)\s+on\s+(?:the\s+)?(?:(?:electric|cooling|radiator)\s+)?fans?|(?:turn|switch|power)\s+(?:the\s+)?(?:(?:electric|cooling|radiator)\s+)?fans?\s+on)\b(?!\s+(?:at|when|above|below|by)\b)/i.test(source);
  // Run552: A negated fan-output enable request is not authorization to
  // commission that output. Preserve the conflict as a separate review gate
  // even when a companion fan-temperature request was parsed successfully.
  // Text-only triage; no OS bit, output pin, or threshold is inferred.
  const fanEnableNegation = /\b(?:do\s+not|don['’]?t|dont|never|avoid)\s+(?:ever\s+|please\s+)?(?:enable|activate|commission|configure)\s+(?:(?:the|my|both|all|pcm|ecm|factory|stock)\s+){0,4}(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:outputs?|relays?|controls?|drivers?)\b/i;
  if (fanEnableNegation.test(source)) {
    unresolved.push({
      type: 'fan-output-intent-contradiction',
      label: 'Fan output enablement instruction requires clarification',
      status: 'needs-review',
      requirement: 'The request explicitly says not to enable a fan output. Do not interpret this as authorization to commission the output; clarify output intent separately from temperature targets and verify the exact OS and wiring.'
    });
  }
  if (fanHardwareAction) {
    unresolved.push({
      type: 'fan-output-enable',
      label: 'Electric fan output enablement',
      status: 'needs-review',
      requirement: 'Enabling the electric-fan output is not the same as changing fan temperatures. Confirm ECM output pins, relay/fuse wiring, and an exact-OS enable-state mapping before commissioning this separately.'
    });
  }

  // Run351: A reported inactive/unconfigured ECM fan output is NOT proof that
  // fan temperature edits can operate the relays. Earlier guards caught
  // "fan output is disabled" but silently admitted "fan output isn't
  // enabled" or "fan output enable flag is false" in a VATS/temperature
  // request. These are diagnostic blockers, not OS-specific flag mappings.
  const fanOutputNotEnabled = new RegExp(
    String.raw`\b${fanOutputTarget}\s+(?:(?:enable(?:ment|d)?\s+(?:flags?|bits?|states?|settings?))\s+)?(?:isn['’]?t|aren['’]?t|wasn['’]?t|weren['’]?t|hasn['’]?t|haven['’]?t|hadn['’]?t|is\s+not|are\s+not|was\s+not|were\s+not|has\s+not|have\s+not|had\s+not|has\s+never|have\s+never|never)\s+(?:(?:yet|ever|already)\s+)?(?:been\s+)?(?:enabled|activated|configured|active|on)\b` +
    String.raw`|\b${fanOutputTarget}\s+enable(?:ment|d)?\s+(?:flags?|bits?|states?|settings?)\s*(?:=|:|is|are|was|were)\s*(?:false|0|off|inactive|disabled)\b` +
    String.raw`|\b(?:pcm|ecm)\s+(?:isn['’]?t|aren['’]?t|is\s+not|are\s+not|was\s+not|were\s+not)\s+configured\s+for\s+(?:(?:electric|cooling|radiator)\s+)?fans?\s+(?:relays?|outputs?|drivers?|controls?)\b`, 'gi'
  );
  // Run352: Controller output state can be reported as "is set to off",
  // "are configured as disabled", or "have been switched off". Those are
  // not temperature thresholds and cannot be silently ignored in a mixed
  // VATS/fan request. This is text-only triage; no output polarity or OS
  // enable-bit location is inferred.
  const fanOutputConfiguredOff = new RegExp(
    String.raw`\b${fanOutputTarget}\s+(?:(?:enable(?:ment|d)?\s+(?:flags?|bits?|states?|settings?))\s+)?` +
    String.raw`(?:(?:is|are|was|were|has|have|had)\s+)?(?:(?:currently|already|still)\s+)?(?:been\s+)?` +
    String.raw`(?:(?:set|configured)\s+(?:to|as)\s+(?:disabled|inactive|off|false|0)|marked\s+(?:(?:to|as)\s+)?(?:disabled|inactive|off|false|0)|(?:switched|turned|powered)\s+off)\b`, 'gi'
  );
  const fanOutputNotEnabledReview = [...source.matchAll(fanOutputNotEnabled), ...source.matchAll(fanOutputConfiguredOff)].some(match => {
    const prefix = source.slice(0, match.index).split(/[.!?;,]/).pop().trim();
    const remainder = source.slice(match.index + match[0].length);
    const diagnostic = /\b(?:check|inspect|verify|diagnose|test|determine|review)\b[^.!?;,]*\b(?:whether|if)\b/i.test(prefix);
    const question = /^(?:are|were|was|is|have|has|had|isn['’]?t|aren['’]?t)(?:\s+(?:the|my|both|all|two|pcm|ecm))*$/i.test(prefix) && /^\s*\?/.test(remainder);
    return !diagnostic && !question;
  });
  if (fanOutputNotEnabledReview) {
    unresolved.push({
      type: 'fan-output-unverified',
      label: 'Electric fan output reported inactive or unconfigured',
      status: 'needs-review',
      requirement: 'Reported inactive, unconfigured, or false ECM fan-output enablement requires independent exact-OS and physical relay/driver diagnostics. Fan temperature thresholds do not enable a controller output; do not infer a flag, pin, polarity or compatibility.'
    });
  }

  // Output shutdown is a separate controller/hardware state change. A
  // request that also specifies fan-off *temperature* is not authorization
  // to disable the relay, driver, or PCM fan output. Never silently keep
  // just the recognized VATS and temperature portions of a mixed request.
  const fanOutputDisable = new RegExp(
    `\\b(?:disable|deactivate|disconnect|remove|delete|bypass|shut\\s+off|switch\\s+off|turn\\s+off)\\s+(?:(?:the|my|both|dual|two|all)\\s+){0,3}${fanOutputTarget}\\b` +
    `|\\b(?:turn|switch|shut|power)\\s+(?:(?:the|my|both|dual|two|all)\\s+){0,3}${fanOutputTarget}\\s+off\\b` +
    `|\\b${fanOutputTarget}\\s+(?:disabled|deactivated|disconnected|off)\\b` +
    // A declarative output state is still a requested physical change:
    // "fan relays should be disabled" and "fan outputs are off" must not
    // be silently dropped when a valid temperature pair was also parsed.
    `|\\b${fanOutputTarget}\\s+(?:(?:are|is|were|was|should|must|will|need(?:s)?(?:\\s+to)?|to)\\s+){0,3}(?:(?:be|remain|stay|kept)\\s+){0,2}(?:disabled|deactivated|disconnected|off|inactive)\\b`, 'i'
  );
  if (fanOutputDisable.test(source) || fanEnableFlagOff || fanOutputStateOff || indexedFanOutputDisableDirective || indexedFanEnableOff) {
    unresolved.push({
      type: 'fan-output-disable',
      label: 'Electric fan output shutdown',
      status: 'needs-review',
      requirement: 'Disabling a fan relay, driver, or ECM output is separate from fan-off temperature calibration. Verify exact OS, outputs, wiring, and cooling safety; no output state change may be silently applied or omitted.'
    });
  }

  // A contradictory instruction to retain existing fan setpoints is not
  // permission to apply the numeric thresholds parsed earlier in the same
  // request. Without this guard, "set fans on at ...; do not change fan
  // temperatures" was admitted as a complete fan/VATS proposal. Only
  // inspect a request with a parsed temperature intent; a negative instruction
  // alone is not an instruction to change an ECM calibration.
  const fanThresholdTarget = String.raw`(?:(?:(?:electric|cooling|radiator|pcm|ecm|stock|factory)\s+)?fans?\s+(?:on\s+|off\s+)?(?:temperatures?|temps?|thresholds?|setpoints?|settings?|calibrations?|tables?))`;
  const fanThresholdPreservation = new RegExp(
    String.raw`\b(?:do\s+not|don['’]?t|dont|never|without|avoid)\s+(?:(?:ever|please|the|my|any)\s+){0,3}(?:chang(?:e|ing)|modif(?:y|ying)|adjust(?:ing)?|tun(?:e|ing)|alter(?:ing)?|updat(?:e|ing)|touch(?:ing)?|reset(?:ting)?|reprogram(?:ming)?)\s+(?:(?:the|my|any)\s+)?${fanThresholdTarget}\b` +
    String.raw`|\b(?:keep|leave|retain|preserve)\s+(?:(?:the|my|all)\s+)?${fanThresholdTarget}\s+(?:unchanged|alone|as[-\s]?is|stock|factory|original|at\s+(?:stock|factory|original)\s+(?:settings?|values?|temperatures?))\b` +
    String.raw`|\b${fanThresholdTarget}\s+(?:(?:should|must|will|need\s+to|are|is)\s+)?(?:remain|stay|be\s+left|be\s+kept)\s+(?:unchanged|stock|factory|original|as[-\s]?is)\b`, 'i'
  );
  if (intents.some(item => item?.type === 'fan-control') && fanThresholdPreservation.test(source)) {
    unresolved.push({
      type: 'fan-threshold-intent-contradiction',
      label: 'Conflicting electric-fan threshold instructions',
      status: 'needs-review',
      requirement: 'The request both specifies new fan temperatures and says to preserve existing fan settings. Clarify the complete request before preparing any VATS/fan proposal; independently verify the exact OS and fan-output wiring.'
    });
  }

  // The parser consumes only the first fan-on and fan-off values. A
  // second explicit threshold (even a repeated value) cannot be silently
  // dropped from a combined VATS/fan proposal. This guard does not choose
  // which values to use, and does not commission ECM outputs.
  if (/\bfans?\b/i.test(source)) {
    // Run292: "engage at", "enabled at", and "release at" are also
    // explicit threshold assignments. The old on/off-only counter silently
    // ignored additional values expressed with these synonyms, allowing a
    // first-pair-only VATS/fan proposal. This is syntax triage, not proof of
    // the OS, fan bank count, output enable flag, or hardware wiring.
    const thresholdMentions = [...source.matchAll(/\b(on|off|engage(?:s|d)?|activat(?:e|es|ed)|enabl(?:e|es|ed)|deactivat(?:e|es|ed)|disabl(?:e|es|ed)|releas(?:e|es|ed))\s+(?:(?:at|to|around)\s+|(?:=|:)\s*)?\d{2,3}(?:\.\d+)?\s*(?:°\s*)?(?:deg(?:rees?)?\s*)?(?:fahrenheit|celsius|[fc])?\b/gi)];
    const onCount = thresholdMentions.filter(match => /^(?:on|engage|activat|enabl)/i.test(match[1])).length;
    const offCount = thresholdMentions.length - onCount;
    if (onCount > 1 || offCount > 1) {
      unresolved.push({
        type: 'fan-multiple-thresholds', label: 'Multiple electric-fan thresholds', status: 'needs-review',
        requirement: 'Multiple fan-on or fan-off instructions were provided, but the quick-service parser supports only one pair. Clarify the intended values and independently verify each exact-OS fan bank/output mapping; no first-pair-only proposal is allowed.'
      });
    }
  }

  // The quick-service parser has only one fan on/off pair. Never treat
  // separate fan-bank settings or mixed C/F values as that single pair.
  const temperatureUnits = [...source.matchAll(/\b\d{2,3}(?:\.\d+)?\s*(?:°\s*)?(?:deg(?:rees?)?\s*)?(fahrenheit|celsius|[fc])\b/gi)]
    .map(match => /^(?:c|celsius)$/i.test(match[1]) ? 'C' : 'F');
  if (temperatureUnits.includes('C') && temperatureUnits.includes('F') && /\bfans?\b/i.test(source)) {
    unresolved.push({
      type: 'fan-mixed-units', label: 'Mixed fan temperature units', status: 'needs-review',
      requirement: 'Fan temperatures contain both Celsius and Fahrenheit. Specify a single explicit unit and independently review the fan-on and fan-off setpoints; no conversion or fan calibration was prepared.'
    });
  }
  // Run292: an indexed bank is not limited to 1 or 2 in untrusted user
  // text. "fan 3 enabled at 210 F" or "fan #10 on threshold 210 F" must
  // not disappear behind the generic fan pair. The index is NOT evidence
  // that any particular ECM actually has that many fan outputs.
  if (/\bfans?\s*(?:#\s*|number\s*)?\d{1,3}\b/i.test(source)) {
    unresolved.push({
      type: 'fan-bank-specific', label: 'Individual fan bank control', status: 'needs-review',
      requirement: 'Indexed fan-bank settings require separate exact-OS calibration mappings and verified relay/output wiring. A bank index in request text does not establish ECM output compatibility; the shared fan temperature preset cannot represent separate banks.'
    });
  }

  // Run198: A shared fan temperature pair cannot express separately mapped
  // low/high-speed outputs or spelled-out fan one/two bank settings. The
  // existing numeric fan 1/2 guard above does not recognize these forms,
  // allowing a combined VATS + fan request to silently discard a second
  // physical output instruction. Match changes/assignments, not read-only
  // checks such as "inspect low-speed fan relay wiring". No OS mapping,
  // output polarity, relay topology or temperature is inferred here.
  // Run293: The quick-service parser cannot represent spelled-out fan banks
  // beyond one/two or lettered outputs (fan A, fan bank B). A separate
  // relay/threshold directive must be reviewed even when a valid shared
  // on/off pair is present. Letter labels do not establish physical outputs.
  const namedFanBank = String.raw`(?:fans?\s+(?:one|two|three|four|five|six|seven|eight|nine|ten|bank\s+[a-z]|[a-z])|(?:low|high)[-\s]*speed\s+fans?)`;
  const namedFanBankChange = new RegExp(
    String.raw`\b(?:set|change|adjust|configure|program|tune|enable|disable|activate|deactivate|switch|turn|use|make)\s+(?:(?:the|my|a|each|both|separate|individual|different|new)\s+){0,4}${namedFanBank}\b` +
    String.raw`|\b${namedFanBank}\s+(?:(?:on|off|output|relay|driver|control|enable|threshold|temp|temperature|setpoint|setting|mode|state)\w*\s*){0,3}(?:=|:)\s*(?:\d{2,3}|on|off|enabled|disabled|true|false|1|0)\b` +
    String.raw`|\b${namedFanBank}\s+(?:(?:on|off)\s+)?(?:thresholds?|temperatures?|temps?|setpoints?)\s+(?:(?:to|at|=|:)\s+)?\d{2,3}\b` +
    String.raw`|\b${namedFanBank}\s+(?:outputs?|relays?|drivers?|controls?)\s+(?:enabled|disabled|on|off)\b` +
    String.raw`|\b(?:set|use|configure|change|adjust|program|tune)\s+(?:(?:separate|individual|different|dual)\s+)?(?:low[-\s]*speed\s+(?:and|&|/)\s+high[-\s]*speed|high[-\s]*speed\s+(?:and|&|/)\s+low[-\s]*speed)\s+fans?\s+(?:thresholds?|temperatures?|temps?|setpoints?|outputs?|relays?)\b`, 'i'
  );
  if (namedFanBankChange.test(source)) {
    unresolved.push({
      type: 'fan-bank-specific', label: 'Separate electric fan bank control', status: 'needs-review',
      requirement: 'Spelled-out fan one/two or low/high-speed fan settings require separate exact-OS output and threshold mappings, relay/fuse wiring verification, and independent review. A shared fan pair cannot authorize these changes.'
    });
  }

  // A unit supplied for one threshold does not authorize assuming the same
  // unit for the other, and a unitless pair must not default silently to F.
  // The natural-language parser currently selects F when units are absent
  // and C if either value mentions C; that parser result is not proof of
  // explicitly requested units for *both* thresholds. This is request
  // admission only, not a temperature conversion or OS calibration mapping.
  const explicitFanThresholdUnit = role => {
    const direct = new RegExp(
      String.raw`\b${role}\s+(?:at\s+)?\d{2,3}(?:\.\d+)?\s*(?:°\s*)?(?:deg(?:rees?)?\s*)?(?:fahrenheit|celsius|[fc])\b`, 'i'
    );
    const reversed = new RegExp(
      String.raw`\b\d{2,3}(?:\.\d+)?\s*(?:°\s*)?(?:deg(?:rees?)?\s*)?(?:fahrenheit|celsius|[fc])\s+(?:fans?\s+)?${role}\b`, 'i'
    );
    return direct.test(source) || reversed.test(source);
  };
  const fanIntent = intents.find(item => item?.type === 'fan-control');
  if (fanIntent && Number.isFinite(fanIntent.fanOn) && Number.isFinite(fanIntent.fanOff) &&
      (!explicitFanThresholdUnit('on') || !explicitFanThresholdUnit('off'))) {
    unresolved.push({
      type: 'fan-threshold-units-unconfirmed',
      label: 'Electric fan threshold units require confirmation',
      status: 'needs-input',
      requirement: 'Specify F or C separately for both fan-on and fan-off temperatures. TunIQ must not infer missing units from a default or the other threshold; verify exact-OS thresholds and output wiring separately.'
    });
  }
  if (fanIntent && (!Number.isFinite(fanIntent.fanOn) || !Number.isFinite(fanIntent.fanOff))) {
    unresolved.push({
      type: 'fan-control-incomplete',
      label: 'Electric fan control',
      status: 'needs-input',
      requirement: 'Provide both fan-on and fan-off temperatures with units before creating a P01 quick-service revision; verify the relay/output wiring and exact controller OS.'
    });
  } else if (fanIntent) {
    const onF = fanIntent.unit === 'C' ? fanIntent.fanOn * 9 / 5 + 32 : fanIntent.fanOn;
    const offF = fanIntent.unit === 'C' ? fanIntent.fanOff * 9 / 5 + 32 : fanIntent.fanOff;
    if (offF >= onF || onF < 150 || onF > 235 || offF < 130 || offF > 225) {
      unresolved.push({
        type: 'fan-control-invalid',
        label: 'Electric fan control',
        status: 'needs-review',
        requirement: 'The fan temperature pair is outside the supported on/off range or would cycle incorrectly; fan-off must be below fan-on. Review the hardware, thermostat, and exact OS before tuning.'
      });
    }
  }

  if (/\b(?:electric\s+|cooling\s+)?fans?\b/i.test(source) && !fanIntent) {
    unresolved.push({
      type: 'fan-control-incomplete',
      label: 'Electric fan control',
      status: 'needs-input',
      requirement: 'The electric-fan request needs explicit on and off temperatures with units, confirmed fan relay/output wiring, and an exact-OS definition. Fan hardware enablement cannot be inferred from a temperature table.'
    });
  }

  return unresolved;
}

module.exports = { unresolvedCalibrationRequests, explicitRequestOsConflict };
