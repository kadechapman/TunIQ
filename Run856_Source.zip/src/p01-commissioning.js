const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { classifyPcmHammerResult } = require('./pcmhammer');
const { checkSafeReadPath } = require('./read-output-safety');
const { commissionedCellIndex } = require('./commissioned-cell-index');

const P01_BIN_SIZE = 512 * 1024;
const COMMISSIONING_VERSION = 3;

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function clean(value, max = 200) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max); }
function normalizeController(value) { return clean(value, 40).toUpperCase().replace(/\s+/g, ''); }
function osCandidates(text) { return [...new Set((String(text || '').match(/\b\d{7,9}\b/g) || []))]; }
function identityFingerprint(identity = {}) {
  return crypto.createHash('sha256').update(JSON.stringify({
    controller: normalizeController(identity.controller),
    os: clean(identity.os, 20),
    hardwareId: clean(identity.hardwareId, 80),
    serviceNumber: clean(identity.serviceNumber, 40)
  })).digest('hex');
}
// File metadata used to admit protected originals and revalidate saved read
// pairs must come from ONE opened, direct file. A stat(path) followed by
// readFile(path) follows symlinks and can hash a different file after a swap.
function directFileParents(file) {
  const chain = [];
  for (let dir = path.dirname(path.resolve(file)); ; dir = path.dirname(dir)) {
    const stat = fs.lstatSync(dir);
    if (!stat.isDirectory() || stat.isSymbolicLink()) return null;
    chain.push({ dir, dev: stat.dev, ino: stat.ino });
    if (dir === path.parse(dir).root) return chain;
  }
}
function sameDirectFile(a, b) {
  return a.isFile() && b.isFile() && a.nlink === 1 && b.nlink === 1 &&
    a.dev === b.dev && a.ino === b.ino && a.size === b.size &&
    a.mtimeMs === b.mtimeMs && a.ctimeMs === b.ctimeMs;
}
function fileInfo(file) {
  if (typeof file !== 'string' || !file.trim() || !checkSafeReadPath(file).ok) return null;
  let fd;
  try {
    const parentsBefore = directFileParents(file);
    if (!parentsBefore) return null;
    const before = fs.lstatSync(file);
    if (!before.isFile() || before.nlink !== 1 || before.size !== P01_BIN_SIZE) return null;
    fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const opened = fs.fstatSync(fd);
    if (!sameDirectFile(before, opened) || opened.size !== P01_BIN_SIZE) return null;
    // A saved project path is untrusted. readFileSync(fd) allocates for the
    // entire file and can exhaust memory if the file is oversized or grows
    // during the read. Read exactly one P01 image into a fixed-size buffer,
    // then probe EOF to reject an appended byte without reading it all.
    const bytes = Buffer.allocUnsafe(P01_BIN_SIZE);
    let offset = 0;
    while (offset < bytes.length) {
      const count = fs.readSync(fd, bytes, offset, bytes.length - offset, null);
      if (count <= 0) return null;
      offset += count;
    }
    const extra = Buffer.allocUnsafe(1);
    if (fs.readSync(fd, extra, 0, 1, null) !== 0) return null;
    const afterRead = fs.fstatSync(fd);
    const afterPath = fs.lstatSync(file);
    const parentsAfter = directFileParents(file);
    if (!sameDirectFile(opened, afterRead) || !sameDirectFile(afterRead, afterPath) ||
        !parentsAfter || parentsBefore.length !== parentsAfter.length ||
        !parentsBefore.every((entry, i) => entry.dir === parentsAfter[i].dir &&
          entry.dev === parentsAfter[i].dev && entry.ino === parentsAfter[i].ino) ||
        bytes.length !== opened.size) return null;
    return { path: file, name: path.basename(file), size: opened.size,
      sha256: crypto.createHash('sha256').update(bytes).digest('hex'),
      modifiedAt: opened.mtime.toISOString() };
  } catch { return null; }
  finally { if (fd !== undefined) fs.closeSync(fd); }
}
// A read must be a direct, singly-linked regular file beneath real directories.
// lstat() prevents file symlinks and Windows junction parents from being
// silently followed when a read enters the commissioning evidence ledger.
function directReadEvidenceFile(file) {
  try {
    if (typeof file !== 'string' || !file.trim()) return false;
    // Apply the same Win32 alias and namespace policy at ledger admission and
    // recovery as at CLI Full Read validation. This prevents a Linux-created
    // NUL.bin, ADS-like name, or drive-relative path from becoming trusted
    // cross-platform backup evidence.
    if (!checkSafeReadPath(file).ok) return false;
    const absolute = path.resolve(file);
    const entry = fs.lstatSync(absolute);
    if (!entry.isFile() || entry.isSymbolicLink() || entry.nlink !== 1) return false;
    let parent = path.dirname(absolute);
    while (true) {
      const stat = fs.lstatSync(parent);
      if (!stat.isDirectory() || stat.isSymbolicLink()) return false;
      const next = path.dirname(parent);
      if (next === parent) break;
      parent = next;
    }
    return true;
  } catch { return false; }
}

// Saved read-session records are not sufficient if their paths now refer to
// one physical file. Fail closed on links, aliases, or unavailable metadata.
function independentReadFiles(firstPath, secondPath) {
  try {
    if (!directReadEvidenceFile(firstPath) || !directReadEvidenceFile(secondPath)) return false;
    const firstLink = fs.lstatSync(firstPath);
    const secondLink = fs.lstatSync(secondPath);
    if (!firstLink.isFile() || !secondLink.isFile()) return false;
    const first = fs.statSync(firstPath);
    const second = fs.statSync(secondPath);
    // A multiply-linked BIN is not independent recovery evidence, even on a
    // filesystem that does not expose useful inode numbers.
    if (!first.isFile() || !second.isFile() || first.nlink !== 1 || second.nlink !== 1) return false;
    const firstReal = fs.realpathSync.native(firstPath).toLowerCase();
    const secondReal = fs.realpathSync.native(secondPath).toLowerCase();
    if (!firstReal || !secondReal || firstReal === secondReal) return false;
    if (first.dev === second.dev && first.ino && second.ino && first.ino === second.ino) return false;
    return true;
  } catch {
    return false;
  }
}

// A previously verified ledger is not permanent proof: saved files may be
// replaced, removed or redirected after verification. Recheck both surviving
// files before using a verified pair to authorize calibration or AI readiness.
function verifiedPairEvidenceIntact(pair, identityFingerprint) {
  if (pair?.status !== 'verified' || !pair.first || !pair.second) return false;
  const { first, second } = pair;
  if (!first.validP01Size || !second.validP01Size || first.size !== P01_BIN_SIZE || second.size !== P01_BIN_SIZE ||
      first.identityFingerprint !== identityFingerprint || second.identityFingerprint !== identityFingerprint ||
      !first.sessionId || !second.sessionId || first.sessionId === second.sessionId ||
      !/^[a-f0-9]{64}$/i.test(String(first.sha256 || '')) || first.sha256 !== second.sha256) return false;
  if (!first.path || !second.path || !independentReadFiles(first.path, second.path)) return false;
  try {
    const firstNow = fileInfo(first.path);
    const secondNow = fileInfo(second.path);
    return Boolean(firstNow && secondNow && firstNow.size === P01_BIN_SIZE && secondNow.size === P01_BIN_SIZE &&
      firstNow.sha256 === first.sha256 && secondNow.sha256 === second.sha256);
  } catch { return false; }
}

function uniqueReads(reads = []) {
  const seen = new Set();
  return reads.filter(item => {
    const key = `${item.sessionId || item.path || item.id}:${item.sha256}`;
    if (seen.has(key)) return false;
    seen.add(key); return true;
  });
}

function bestReadGroup(reads = []) {
  const groups = new Map();
  for (const read of reads) {
    const list = groups.get(read.sha256) || [];
    list.push(read); groups.set(read.sha256, list);
  }
  return [...groups.entries()].sort((a, b) => b[1].length - a[1].length || String(a[0]).localeCompare(String(b[0])))[0] || [null, []];
}

class P01CommissioningManager {
  constructor(options) {
    this.getActiveProject = options.getActiveProject;
    this.getCalibrationWorkspace = options.getCalibrationWorkspace || (() => null);
    this.getFlashStatus = options.getFlashStatus || (() => null);
    this.appendActivity = options.appendActivity || (() => {});
  }

  file(active = this.getActiveProject()) {
    if (!active?.folder) return null;
    return path.join(active.folder, 'Reports', 'p01-commissioning.json');
  }

  load(active = this.getActiveProject()) {
    const file = this.file(active);
    const existing = file ? readJson(file, null) : null;
    if (existing && existing.projectId === active?.id) {
      return { version: COMMISSIONING_VERSION, reads: [], validations: [], testWrites: [], writes: [], readPair: null, ...existing };
    }
    return {
      type: 'p01-commissioning', version: COMMISSIONING_VERSION, projectId: active?.id || null,
      projectName: active?.name || '', identity: null, reads: [], validations: [], testWrites: [], writes: [], readPair: null,
      definitionConfirmation: null, goalMap: null,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
  }

  save(state, active = this.getActiveProject()) {
    if (!active?.folder) throw new Error('Create or activate a project first.');
    const next = { ...state, version: COMMISSIONING_VERSION, projectId: active.id, projectName: active.name, updatedAt: new Date().toISOString() };
    writeJson(this.file(active), next);
    return next;
  }

  isP01(active = this.getActiveProject(), state = this.load(active)) {
    return normalizeController(active?.controller || state?.identity?.controller) === 'P01';
  }

  recordIdentity(identity = {}, session = null) {
    const active = this.getActiveProject();
    if (!active) return null;
    const normalized = {
      controller: normalizeController(identity.controller), os: clean(identity.os, 20),
      hardwareId: clean(identity.hardwareId, 80), serviceNumber: clean(identity.serviceNumber, 40), vin: clean(identity.vin, 24), voltage: Number.isFinite(Number(identity.voltage)) ? Number(identity.voltage) : null,
      description: clean(identity.description, 200),
      fingerprint: identityFingerprint(identity), identifiedAt: new Date().toISOString(),
      device: clean(session?.device, 120), sessionId: session?.id || null,
      proofSource: clean(session?.proofSource || session?.source || 'PCM Hammer', 300)
    };
    const state = this.load(active);
    const previousFingerprint = state.identity?.fingerprint;
    state.identity = normalized;
    if (previousFingerprint && previousFingerprint !== normalized.fingerprint) {
      state.reads = [];
      state.validations = [];
      state.testWrites = [];
      state.definitionConfirmation = null;
      state.goalMap = null;
      delete state.canonicalReadSha256;
      delete state.canonicalReadPath;
      delete state.dualReadVerifiedAt;
      state.readPair = null;
      state.readMismatch = false;
      state.identityChangedWarning = 'Controller identity changed. Previous read, definition, parameter-map, validation, and Test Write evidence was cleared.';
    }
    this.save(state, active);
    this.appendActivity('p01-identity-recorded', { projectId: active.id, controller: normalized.controller, os: normalized.os, hardwareId: normalized.hardwareId, serviceNumber: normalized.serviceNumber });
    return this.status(active);
  }

  beginFreshReadPair(reason = 'retry') {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const generation = Number(state.readPair?.generation || 0) + 1;
    state.readPair = { generation, status: 'awaiting-first', first: null, second: null, startedAt: new Date().toISOString(), reason: clean(reason, 300) };
    state.readMismatch = false;
    state.readResolution = 'Waiting for the first complete read in a new two-read verification pair.';
    delete state.canonicalReadSha256;
    delete state.canonicalReadPath;
    delete state.dualReadVerifiedAt;
    this.save(state, active);
    return this.status(active);
  }

  repairVerifiedReadPair(reason = 'saved evidence reconciliation') {
    const active = this.getActiveProject();
    if (!active) return { repaired: false, status: this.status(active), reason: 'no-active-project' };
    const state = this.load(active);
    const current = this.status(active);
    if (current.dualReadVerified) return { repaired: false, status: current, reason: 'already-verified' };
    if (!state.identity?.fingerprint || normalizeController(state.identity.controller) !== 'P01') return { repaired: false, status: current, reason: 'identity-incomplete' };
    const candidates = [];
    for (const saved of Array.isArray(state.reads) ? state.reads : []) {
      if (!saved?.validP01Size || Number(saved.size) !== P01_BIN_SIZE || saved.identityFingerprint !== state.identity.fingerprint) continue;
      const actual = fileInfo(saved.path);
      if (!actual || actual.size !== P01_BIN_SIZE || actual.sha256 !== saved.sha256) continue;
      candidates.push({ ...saved, ...actual });
    }
    // Matching BIN filenames and timestamps are not proof of two independent
    // ECU reads. Only separately recorded, digest-matched session evidence
    // may restore a damaged read-pair pointer. A lost ledger requires rereading.
    const groups = new Map();
    for (const item of candidates) { const list = groups.get(item.sha256) || []; list.push(item); groups.set(item.sha256, list); }
    let selected = null;
    for (const [hash, group] of [...groups.entries()].sort((a, b) => b[1].length - a[1].length)) {
      for (let i = 0; i < group.length && !selected; i += 1) {
        for (let j = i + 1; j < group.length; j += 1) {
          const first = group[i]; const second = group[j];
          const firstPath = path.resolve(String(first.path || '')).toLowerCase();
          const secondPath = path.resolve(String(second.path || '')).toLowerCase();
          const firstProof = clean(first.proofSource || first.path || '', 500).toLowerCase();
          const secondProof = clean(second.proofSource || second.path || '', 500).toLowerCase();
          const independentSession = Boolean(first.sessionId && second.sessionId && first.sessionId !== second.sessionId);
          const independentFile = firstPath && secondPath && firstPath !== secondPath;
          const independentProof = firstProof && secondProof && firstProof !== secondProof;
          if (independentSession && independentFile && independentProof && independentReadFiles(first.path, second.path)) { selected = { hash, first, second }; break; }
        }
      }
      if (selected) break;
    }
    if (!selected) return { repaired: false, status: current, reason: 'no-proven-independent-matching-pair' };
    const completedAt = new Date().toISOString();
    state.readPair = {
      generation: Number(state.readPair?.generation || 0) + 1,
      status: 'verified', first: selected.first, second: selected.second,
      startedAt: selected.first.readAt || selected.first.modifiedAt || completedAt,
      completedAt, reason: clean(reason, 300), recoveredFromSavedEvidence: true
    };
    state.canonicalReadSha256 = selected.hash;
    state.canonicalReadPath = selected.first.path;
    state.dualReadVerifiedAt = completedAt;
    state.readMismatch = false;
    state.readResolution = 'Restored two digest-matched read records with separate saved session and source-file evidence.';
    this.save(state, active);
    this.appendActivity('p01-read-pair-repaired', { projectId: active.id, sha256: selected.hash, first: selected.first.name, second: selected.second.name, reason: clean(reason, 300) });
    return { repaired: true, status: this.status(active), pair: state.readPair };
  }

  recordRead(file, info = {}, session = null) {
    const active = this.getActiveProject();
    if (!active) return null;
    const state = this.load(active);
    if (!this.isP01(active, state)) return null;
    if (!state.identity?.fingerprint || normalizeController(state.identity?.controller) !== 'P01') {
      throw new Error('Read Properties must identify this controller as P01 before a full read can be accepted.');
    }
    if (!directReadEvidenceFile(file)) {
      throw new Error('Rejected PCM read: backup must use a safe local path and a direct, singly-linked regular file beneath non-redirected directories.');
    }
    const actual = fileInfo(file);
    if (!actual) {
      // Size is only used to improve the rejection message; never admit a
      // file from this separate path lookup (which could race or redirect).
      let rejectedSize;
      try { rejectedSize = fs.lstatSync(file).size; } catch {}
      if (Number.isSafeInteger(rejectedSize) && rejectedSize !== P01_BIN_SIZE) {
        throw new Error(`Rejected PCM read: expected exactly ${P01_BIN_SIZE} bytes but received ${rejectedSize} bytes.`);
      }
      throw new Error('The completed PCM read file could not be verified as a direct, unchanged 512 KB BIN.');
    }
    if (actual.size !== P01_BIN_SIZE) throw new Error(`Rejected PCM read: expected exactly ${P01_BIN_SIZE} bytes but received ${actual.size} bytes.`);
    // A Full Read is validated before import. Re-hashing here must match that
    // earlier proof: a same-size replacement between validation and ledger
    // import must never become a verified original or contribute to a read pair.
    if (info.size !== undefined && info.size !== null &&
        (!Number.isSafeInteger(info.size) || info.size !== actual.size)) {
      throw new Error('Rejected PCM read: backup size changed after integrity validation.');
    }
    if (info.sha256 !== undefined && info.sha256 !== null) {
      if (typeof info.sha256 !== 'string' || !/^[a-f0-9]{64}$/i.test(info.sha256)) {
        throw new Error('Rejected PCM read: invalid SHA-256 integrity proof.');
      }
      if (actual.sha256 !== info.sha256.toLowerCase()) {
        throw new Error('Rejected PCM read: SHA-256 digest changed after integrity validation.');
      }
    }
    const sessionId = clean(session?.id || info.sessionId || `${actual.name}-${actual.modifiedAt}`, 200);
    const record = {
      id: `${Date.now()}-read-${Math.random().toString(16).slice(2, 8)}`, ...actual, validP01Size: true,
      identityFingerprint: state.identity.fingerprint, controller: state.identity.controller,
      os: state.identity.os || clean(active.os, 20), device: clean(session?.device, 120), sessionId,
      proofSource: clean(session?.proofSource || session?.source || info.proofSource || 'PCM Hammer full read', 300), readAt: new Date().toISOString()
    };
    state.reads = uniqueReads([record, ...(Array.isArray(state.reads) ? state.reads : [])]).slice(0, 20);
    let pair = state.readPair;
    // Once two reads are verified, an accidental restart or unnecessary extra read must never
    // replace or erase the proven pair. Preserve it until beginFreshReadPair() is explicitly
    // called after a real hash mismatch. The extra file remains in history for diagnostics.
    if (pair?.status === 'verified' && pair.first?.sha256 === pair.second?.sha256) {
      state.readResolution = 'The verified two-read pair is continuity-locked. This additional read was preserved as diagnostic evidence and did not replace the verified original.';
      this.save(state, active);
      this.appendActivity('p01-extra-read-preserved', { projectId: active.id, file: record.name, sha256: record.sha256, verifiedSha256: pair.first.sha256 });
      return { status: this.status(active), canonicalPath: state.canonicalReadPath || pair.first.path, acceptedAsOriginal: false, pairStatus: 'verified', continuityLocked: true };
    }
    if (!pair || !['awaiting-first', 'awaiting-second'].includes(pair.status)) {
      pair = { generation: Number(pair?.generation || 0) + 1, status: 'awaiting-first', first: null, second: null, startedAt: new Date().toISOString() };
    }
    let acceptedAsOriginal = false;
    if (pair.status === 'awaiting-first' || !pair.first) {
      pair.first = record;
      pair.second = null;
      pair.status = 'awaiting-second';
      state.readMismatch = false;
      state.readResolution = 'First complete 524,288-byte read recorded. A second independent full read is required.';
      delete state.canonicalReadSha256;
      delete state.canonicalReadPath;
      delete state.dualReadVerifiedAt;
    } else {
      if (pair.first.sessionId === record.sessionId) throw new Error('The second verification read must come from a separate PCM Hammer session.');
      const firstPath = path.resolve(String(pair.first.path || '')).toLowerCase();
      const secondPath = path.resolve(String(record.path || '')).toLowerCase();
      if (!firstPath || firstPath === secondPath) {
        throw new Error('The second independent verification read must use a different output file.');
      }
      // Reject links, junction-parent redirects, and physical-file aliases
      // before the pair is marked verified or a canonical digest is saved.
      if (!independentReadFiles(pair.first.path, record.path)) {
        throw new Error('The second independent verification read must use a separate direct regular file, not a link or alias.');
      }
      const firstNow = fileInfo(pair.first.path);
      if (!firstNow || firstNow.size !== P01_BIN_SIZE || firstNow.sha256 !== pair.first.sha256) {
        throw new Error('The first read file changed or disappeared before the second read was verified. Start a fresh pair.');
      }
      pair.second = record;
      pair.completedAt = new Date().toISOString();
      if (pair.first.sha256 === record.sha256) {
        pair.status = 'verified';
        state.canonicalReadSha256 = record.sha256;
        state.canonicalReadPath = pair.first.path;
        state.dualReadVerifiedAt = pair.completedAt;
        state.readMismatch = false;
        state.readResolution = 'Two independent complete 524,288-byte reads have matching SHA-256 hashes.';
        acceptedAsOriginal = true;
      } else {
        pair.status = 'mismatch';
        state.readMismatch = true;
        state.readResolution = `Read mismatch: ${pair.first.sha256.slice(0, 16)}… does not match ${record.sha256.slice(0, 16)}…. Both files were preserved; start a fresh two-read pair after correcting power/connection issues.`;
        delete state.canonicalReadSha256;
        delete state.canonicalReadPath;
        delete state.dualReadVerifiedAt;
      }
    }
    state.readPair = pair;
    this.save(state, active);
    this.appendActivity('p01-read-recorded', { projectId: active.id, file: record.name, size: record.size, sha256: record.sha256, pairGeneration: pair.generation, pairStatus: pair.status, mismatch: state.readMismatch });
    return { status: this.status(active), canonicalPath: state.canonicalReadPath || null, acceptedAsOriginal, pairStatus: pair.status };
  }


  verifiedOriginalBinding(active, state) {
    const original = fileInfo(active?.bin);
    const pair = state?.readPair || null;
    const first = pair?.first || null;
    const second = pair?.second || null;
    const pairHash = verifiedPairEvidenceIntact(pair, state?.identity?.fingerprint) ? first.sha256 : '';
    const savedHash = clean(state?.canonicalReadSha256, 80);
    // A cached canonical hash cannot override missing or altered read files.
    const verifiedSha256 = pairHash;
    const activeMatches = Boolean(original && original.size === P01_BIN_SIZE && verifiedSha256 && original.sha256 === verifiedSha256);
    return { original, pairHash, savedHash, verifiedSha256, activeMatches };
  }

  confirmCommissioningDefinitionFromDisk() {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const expected = String(state.identity?.os || active.os || '');
    const definition = this.definition(active, state, true);
    if (!expected) throw new Error('Identify the P01 operating system first.');
    if (!definition.file || !definition.sha256) throw new Error('The generated commissioning definition is missing from disk.');
    if (!definition.commissioningOnly) throw new Error('Automatic disk binding is only available for TunIQ commissioning-only definitions.');
    if (!definition.exactOs) throw new Error(`The commissioning definition does not explicitly declare OS ${expected}.`);
    if (Number(definition.writableTables || 0) !== 0) throw new Error('A commissioning-only definition must contain zero writable calibration tables.');
    if (definition.warnings?.length) throw new Error(`Resolve commissioning definition warnings before confirmation:
• ${definition.warnings.slice(0, 8).join('\n• ')}`);
    const verified = this.verifiedOriginalBinding(active, state);
    if (!verified.activeMatches) throw new Error('The protected original does not match the two verified P01 reads.');
    state.canonicalReadSha256 = verified.original.sha256;
    state.canonicalReadPath = verified.original.path;
    state.definitionConfirmation = {
      os: expected,
      xdfSha256: definition.sha256,
      sourceBinSha256: verified.original.sha256,
      confirmedAt: new Date().toISOString(),
      method: 'automatic-commissioning-disk-binding'
    };
    state.goalMap = null;
    this.save(state, active);
    this.appendActivity('p01-commissioning-definition-disk-bound', {
      projectId: active.id, os: expected, xdfSha256: definition.sha256, sourceBinSha256: verified.original.sha256
    });
    return this.status(active);
  }

  reconcileBoundCommissioningDefinition() {
    return this.confirmCommissioningDefinitionFromDisk();
  }

  confirmDefinition({ typedOs = '', acknowledged = false } = {}) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const definition = this.definition(active, state, true);
    const expected = String(state.identity?.os || active.os || '');
    if (!expected) throw new Error('Identify the P01 operating system first.');
    if (String(typedOs).trim() !== expected) throw new Error(`Type the exact identified OS ${expected} to bind this XDF.`);
    if (!acknowledged) throw new Error('Confirm that this XDF was obtained for the exact identified operating system.');
    if (!definition.file || !definition.sha256) throw new Error('Import and load an XDF before confirming it.');
    if (!definition.mappingLoaded) throw new Error('Load the protected original and XDF in Calibration before confirming the definition.');
    if (definition.warnings?.length) throw new Error(`Resolve XDF mapping warnings before confirmation:\n• ${definition.warnings.slice(0, 8).join('\n• ')}`);
    const verified = this.verifiedOriginalBinding(active, state);
    if (verified.activeMatches) {
      state.canonicalReadSha256 = verified.original.sha256;
      state.canonicalReadPath = state.canonicalReadPath || verified.original.path;
    }
    state.definitionConfirmation = {
      os: expected,
      xdfSha256: definition.sha256,
      sourceBinSha256: verified.verifiedSha256 || state.canonicalReadSha256,
      confirmedAt: new Date().toISOString(),
      method: definition.commissioningOnly ? 'automatic-commissioning-workspace-reconciliation' : 'typed-os-and-clean-mapping'
    };
    state.goalMap = null;
    this.save(state, active);
    this.appendActivity('p01-definition-confirmed', { projectId: active.id, os: expected, xdfSha256: definition.sha256 });
    return this.status(active);
  }

  confirmGoalMap(proposal, actionIds = [], proposalIds = []) {
    const active = this.getActiveProject();
    if (!active || !proposal) throw new Error('Build an AI action sheet first.');
    const state = this.load(active);
    const definition = this.definition(active, state);
    if (!definition.confirmedExact) throw new Error('Confirm the exact-OS XDF before commissioning AI parameters.');
    const selected = new Set((actionIds || []).map(String));
    const selectedProposals = new Set((proposalIds || []).map(String));
    if (!selected.size) throw new Error('Choose at least one action to commission.');
    const actions = {};
    for (const action of proposal.actions || []) {
      if (!selected.has(String(action.id))) continue;
      const actionProposals = (action.proposals || []).filter(item => !selectedProposals.size || selectedProposals.has(String(item.id)));
      const cells = actionProposals.map(item => {
        const text = `${item.id} ${item.tableName} ${item.rowLabel} ${item.colLabel}`;
        let role = /restore|resume/i.test(text) ? 'restore' : 'target';
        if (action.type === 'ghost-cam') {
          if (/spark/i.test(text)) role = 'idle-spark';
          else if (/airflow|air flow|running air/i.test(text)) role = 'idle-airflow';
          else if (/desired.*idle|idle.*speed|idle.*rpm/i.test(text)) role = 'idle-speed';
        } else if (action.type === 'fan-control') {
          role = /(?:\boff\b|turn\s*off|deactivat|release|disable|resume)/i.test(text) ? 'fan-off' : 'fan-on';
        } else if (action.type === 'vats-disable') {
          role = 'disabled-state';
        }
        const row = commissionedCellIndex(item?.row);
        const col = commissionedCellIndex(item?.col);
        if (row === null || col === null || typeof item?.tableKey !== 'string' || !item.tableKey.trim()) {
          throw new Error('Cannot commission an invalid XDF cell coordinate or table key. Rebuild and review the exact OS/XDF proposal.');
        }
        return { tableKey: item.tableKey, row, col, role,
          tableName: item.tableName, rowLabel: item.rowLabel, colLabel: item.colLabel, currentAtConfirmation: item.current };
      });
      if (!cells.length) throw new Error(`${action.label} has no exact mapped cells to commission.`);
      actions[action.type] = { actionId: action.id, label: action.label, cells, confirmedAt: new Date().toISOString() };
    }
    if (!Object.keys(actions).length) throw new Error('The selected actions did not contain commissionable exact cells.');
    state.goalMap = {
      os: String(state.identity?.os || active.os || ''), xdfSha256: definition.sha256, sourceBinSha256: state.canonicalReadSha256,
      actions: { ...(state.goalMap?.actions || {}), ...actions }, confirmedAt: new Date().toISOString(), sourceProposalId: proposal.id
    };
    this.save(state, active);
    this.appendActivity('p01-ai-parameter-map-confirmed', { projectId: active.id, os: state.goalMap.os, actionTypes: Object.keys(actions) });
    return this.status(active);
  }

  parameterMap(active = this.getActiveProject(), state = this.load(active)) {
    const definition = this.definition(active, state);
    const map = state.goalMap;
    if (!map || map.os !== String(state.identity?.os || active?.os || '') || map.xdfSha256 !== definition.sha256 || map.sourceBinSha256 !== state.canonicalReadSha256) return null;
    return map;
  }

  assertGoalProposalMapped(proposal, approvedIds = []) {
    const active = this.getActiveProject();
    if (!this.isP01(active)) return true;
    const status = this.assertAiReady();
    const map = status.parameterMap;
    if (!map) throw new Error('Confirm the P01 AI parameter map for this exact OS/XDF before applying requested changes.');
    const approved = new Set((approvedIds || []).map(String));
    const approvedItems = (proposal?.proposals || []).filter(item => approved.has(String(item.id)));
    if (!approvedItems.length) throw new Error('Approve at least one exact requested change.');
    for (const item of approvedItems) {
      const mapped = map.actions?.[item.actionType]?.cells || [];
      const row = commissionedCellIndex(item.row), col = commissionedCellIndex(item.col);
      if (row === null || col === null || !Array.isArray(mapped) ||
          !mapped.some(cell => cell?.tableKey === item.tableKey &&
            commissionedCellIndex(cell.row) === row && commissionedCellIndex(cell.col) === col)) {
        throw new Error(`${item.tableName} · ${item.rowLabel}/${item.colLabel} is not in the commissioned P01 parameter map. Rebuild and confirm the map first.`);
      }
    }
    return true;
  }

  recordValidation(report) {
    const active = this.getActiveProject();
    if (!active || !report) return null;
    const state = this.load(active);
    state.validations = [{
      targetFile: report.targetFile, targetFileName: report.targetFileName, targetFileSha256: report.targetFileSha256,
      compatible: report.compatible !== false, checksumStatus: report.checksumStatus, validatedAt: report.validatedAt || new Date().toISOString()
    }, ...(Array.isArray(state.validations) ? state.validations : []).filter(item => item.targetFileSha256 !== report.targetFileSha256)].slice(0, 30);
    this.save(state, active);
    return this.status(active);
  }

  recordManualTestWrite(input, proofText = '', source = '') {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const state = this.load(active);
    const info = fileInfo(input);
    if (!info || info.size !== P01_BIN_SIZE) throw new Error('Select the exact 512 KB P01 revision used for Test Write.');
    const text = String(proofText || '');
    const result = classifyPcmHammerResult('testWrite', text, 0);
    if (!result.success || !result.testWritePassed) throw new Error(`The selected log does not prove a successful PCM Hammer Test Write (${result.stopCode || 'result-not-proven'}).`);
    state.testWrites = [{ ...info, identityFingerprint: state.identity?.fingerprint || '', device: 'Imported PCM Hammer proof', completedAt: new Date().toISOString(), sessionId: `manual-${Date.now()}`, proofSource: clean(source, 300) }, ...(state.testWrites || []).filter(item => item.sha256 !== info.sha256)].slice(0, 20);
    this.save(state, active);
    this.appendActivity('p01-testwrite-proof-imported', { projectId: active.id, revision: info.name, sha256: info.sha256, source: clean(source, 300) });
    return this.status(active, input);
  }

  recordFlashSession(session) {
    const active = this.getActiveProject();
    if (!active || !session || !this.isP01(active)) return null;
    const state = this.load(active);
    if (session.operation === 'testWrite' && session.input && session.state === 'complete' && session.testWritePassed === true && session.result?.success !== false) {
      const info = fileInfo(session.input);
      if (info) state.testWrites = [{ ...info, identityFingerprint: state.identity?.fingerprint || '', device: clean(session.device, 120), voltage: session.voltage ?? null, completedAt: session.finishedAt || new Date().toISOString(), sessionId: session.id, backendSha256: session.backendSha256 || '' }, ...(state.testWrites || []).filter(item => item.sha256 !== info.sha256)].slice(0, 20);
    }
    if (['writeCalibration','writeFull'].includes(session.operation)) {
      const info = fileInfo(session.input);
      state.writes = [{ operation: session.operation, state: session.state, verified: Boolean(session.verified), ...(info || {}), identityFingerprint: state.identity?.fingerprint || '', completedAt: session.finishedAt || new Date().toISOString(), sessionId: session.id }, ...(state.writes || [])].slice(0, 20);
    }
    this.save(state, active);
    return this.status(active);
  }

  definition(active, state, ignoreConfirmation = false) {
    const xdfInfo = active?.xdfInfo || {};
    const metadataText = `${xdfInfo.title || ''} ${xdfInfo.description || ''}`;
    const nameText = `${xdfInfo.name || ''}`;
    const declaredMetadata = osCandidates(metadataText);
    const declaredName = osCandidates(nameText);
    const declared = [...new Set([...declaredMetadata, ...declaredName])];
    const projectOs = clean(state?.identity?.os || active?.os, 20);
    const metadataExact = Boolean(projectOs && declaredMetadata.includes(projectOs));
    const filenameExact = Boolean(projectOs && declaredName.includes(projectOs));
    let xdfHash = '';
    try { if (active?.xdf && fs.existsSync(active.xdf)) xdfHash = sha256(active.xdf); } catch {}
    let workspace = null;
    try { workspace = this.getCalibrationWorkspace(); } catch {}
    const verified = this.verifiedOriginalBinding(active, state);
    const workspaceBinHashes = [...new Set([workspace?.sourceBinSha256, workspace?.binding?.binSha256].map(value => clean(value, 80)).filter(Boolean))];
    const workspaceXdfHashes = [...new Set([workspace?.sourceXdfSha256, workspace?.binding?.xdfSha256].map(value => clean(value, 80)).filter(Boolean))];
    const commissioningOnly = Boolean(xdfInfo.commissioningOnly || workspace?.mappingSummary?.commissioningOnly);
    const writableTables = commissioningOnly ? 0 : Number(workspace?.mappingSummary?.writableTables ?? xdfInfo.writableTables ?? xdfInfo.tableCount ?? 0);
    const strictMapping = Boolean(workspace?.mode === 'xdf' && workspace.projectId === active?.id
      && workspaceXdfHashes.includes(xdfHash) && workspaceBinHashes.includes(verified.verifiedSha256));
    // Commissioning-only mappings contain no writable calibration addresses. Reconcile
    // them from the actual protected file and verified read pair when older beta fields
    // disagree. Writable definitions remain fingerprint-strict.
    const reconciledCommissioningMapping = Boolean(commissioningOnly && writableTables === 0
      && workspace?.mode === 'xdf' && workspace.projectId === active?.id
      && workspaceXdfHashes.includes(xdfHash) && verified.activeMatches
      && workspaceBinHashes.includes(verified.original?.sha256));
    // Commissioning-only definitions contain no writable addresses. Their safe binding
    // depends on the exact-OS XDF file and verified original bytes, not a renderer cache.
    const diskBoundCommissioningMapping = Boolean(commissioningOnly && writableTables === 0
      && active?.xdf && fs.existsSync(active.xdf) && xdfHash && verified.activeMatches
      && (metadataExact || filenameExact));
    const mappingLoaded = strictMapping || reconciledCommissioningMapping || diskBoundCommissioningMapping;
    const warnings = [...(xdfInfo.warnings || workspace?.mappingSummary?.warnings || [])].filter(Boolean);
    const confirmation = state.definitionConfirmation;
    const confirmationBinSha256 = clean(confirmation?.sourceBinSha256, 80);
    const confirmedExact = !ignoreConfirmation && Boolean(confirmation && confirmation.os === projectOs && confirmation.xdfSha256 === xdfHash
      && [verified.verifiedSha256, verified.original?.sha256].filter(Boolean).includes(confirmationBinSha256)
      && mappingLoaded && warnings.length === 0);
    return {
      file: active?.xdf || null, name: xdfInfo.name || '', title: xdfInfo.title || '', sha256: xdfHash,
      declaredOs: declared, metadataExact, filenameExact, projectOs, exactOs: metadataExact || filenameExact, confirmedExact, confirmation: confirmation || null, mappingLoaded,
      tableCount: Number(xdfInfo.tableCount || workspace?.mappingSummary?.loaded || 0),
      commissioningOnly, writableTables, mappingReconciled: (reconciledCommissioningMapping || diskBoundCommissioningMapping) && !strictMapping, diskBoundCommissioningMapping, warnings
    };
  }

  status(active = this.getActiveProject(), input = null) {
    if (!active) return { applicable: false, readyForAi: false, readyForWrite: false, blockers: ['Create or activate a project first.'], steps: [] };
    const state = this.load(active);
    const applicable = this.isP01(active, state);
    if (!applicable) return { applicable: false, projectId: active.id, controller: active.controller || '', readyForAi: true, readyForWrite: true, blockers: [], steps: [] };
    const identity = state.identity || {};
    const pair = state.readPair || null;
    const pairReads = [pair?.first, pair?.second].filter(Boolean);
    const validReads = pairReads.filter(item => item.validP01Size && item.size === P01_BIN_SIZE && item.identityFingerprint === identity.fingerprint);
    const dualRead = Boolean(verifiedPairEvidenceIntact(pair, identity.fingerprint) && state.canonicalReadSha256 === pair.first.sha256);
    const original = fileInfo(active.bin);
    const originalMatches = Boolean(dualRead && original && state.canonicalReadSha256 && original.sha256 === state.canonicalReadSha256 && original.size === P01_BIN_SIZE);
    const definition = this.definition(active, state);
    const selected = fileInfo(input);
    const validation = selected ? (state.validations || []).find(item => item.targetFileSha256 === selected.sha256 && item.compatible && ['valid','valid-external','valid-stock-clone'].includes(item.checksumStatus)) : null;
    const testWrite = selected ? (state.testWrites || []).find(item => item.sha256 === selected.sha256 && item.identityFingerprint === identity.fingerprint) : null;
    const parameterMap = this.parameterMap(active, state);
    const flash = this.getFlashStatus?.() || {};
    const backend = flash.backend || {};
    const backendReady = Boolean((flash.configured && backend.official && Number(backend.major || 0) >= 2) || flash.assistedAvailable);
    const blockers = [];
    if (normalizeController(identity.controller) !== 'P01') blockers.push('Run PCM Hammer Read Properties and confirm it reports P01.');
    if (!identity.os) blockers.push('PCM Hammer Read Properties did not report an operating-system number.');
    if (!identity.hardwareId) blockers.push('PCM Hammer Read Properties did not report a hardware ID.');
    if (!identity.serviceNumber) blockers.push('PCM Hammer Read Properties did not report a service number. Import the Read Properties log if the CLI omitted it.');
    if (active.os && identity.os && String(active.os) !== String(identity.os)) blockers.push(`Project OS ${active.os} does not match identified PCM OS ${identity.os}.`);
    if (!dualRead) blockers.push(state.readMismatch ? 'The two complete P01 reads do not match. Correct the connection or power issue, then start a fresh two-read verification pair.' : 'Complete two independent 524,288-byte P01 reads with matching SHA-256 hashes.');
    if (!originalMatches) blockers.push('The protected original must be the verified matching P01 read.');
    if (!definition.exactOs) blockers.push(definition.declaredOs.length ? `The XDF declares OS ${definition.declaredOs.join(', ')}, not identified OS ${identity.os || active.os || 'unknown'}.` : 'The XDF metadata or filename must declare the exact identified OS.');
    if (!definition.mappingLoaded) blockers.push('Load the verified original and exact-OS XDF in Calibration after dual-read verification.');
    if (!definition.confirmedExact) blockers.push('Confirm the exact OS/XDF binding after reviewing a clean mapping with no address warnings.');
    const aiBlockers = [...blockers];
    if (definition.commissioningOnly) aiBlockers.push('The bound definition is commissioning-only and contains zero writable calibration tables. Install a trustworthy writable exact-OS definition before AI or manual tuning.');
    const writeBlockers = [...blockers];
    if (definition.commissioningOnly) writeBlockers.push('Commissioning-only mode permits Test Write of the unchanged verified stock clone, but it cannot authorize Calibration Write, Full Write, or OS conversion.');
    if (!backendReady) writeBlockers.push('Configure the official PCM Hammer 2.x CLI or use Assisted PCM Hammer before Test Write or Calibration Write.');
    if (selected) {
      if (selected.size !== P01_BIN_SIZE) writeBlockers.push(`Selected revision is ${selected.size} bytes; a P01 image must be ${P01_BIN_SIZE} bytes.`);
      if (!validation) writeBlockers.push('Analyze this exact revision and obtain a valid checksum/layout report.');
      if (!testWrite) writeBlockers.push('Run a successful Test Write on this exact revision and PCM identity.');
    } else writeBlockers.push('Select the exact revision that will be tested or written.');
    const steps = [
      { id: 'identity', title: 'Read P01 properties', complete: normalizeController(identity.controller) === 'P01' && Boolean(identity.os) && Boolean(identity.hardwareId) && Boolean(identity.serviceNumber), detail: identity.os ? `P01 · OS ${identity.os} · HW ${identity.hardwareId || 'missing'} · Service ${identity.serviceNumber || 'missing'}` : 'Use Read Properties or import its saved Results log.' },
      { id: 'read1', title: 'Complete first full read', complete: validReads.length >= 1, detail: validReads[0]?.sha256 ? `${validReads[0].name} · ${validReads[0].sha256.slice(0, 16)}…` : 'A P01 full read must be exactly 512 KB.' },
      { id: 'read2', title: 'Complete second matching read', complete: dualRead, error: Boolean(state.readMismatch), detail: dualRead ? 'Two independent complete reads match exactly.' : state.readMismatch ? 'Mismatch stopped the workflow. Start a fresh pair after correcting the cause.' : 'Read the PCM again without changing power or connection.' },
      { id: 'backend', title: 'Verify PCM Hammer path', complete: backendReady, detail: backendReady ? `${backend.product || 'PCM Hammer'} ${backend.version || '2.x'} · ${String(backend.sha256 || '').slice(0, 12)}…` : 'Use the official PCM Hammer 2.x CLI or Assisted PCM Hammer.' },
      { id: 'definition', title: 'Bind exact OS definition', complete: definition.confirmedExact, detail: definition.confirmedExact ? (definition.commissioningOnly ? `${definition.name} is bound for read-only hardware commissioning; tuning remains locked.` : `${definition.name} is bound to OS ${definition.projectOs}.`) : definition.mappingLoaded ? 'Review the mapping and type the identified OS to confirm it.' : 'Use an XDF for the exact OS and load it in Calibration.' },
      { id: 'validation', title: 'Validate selected revision', complete: Boolean(validation), detail: validation ? `${selected.name} · ${validation.checksumStatus}` : 'Create a revision, then analyze that exact file.' },
      { id: 'testwrite', title: 'Pass Test Write', complete: Boolean(testWrite), detail: testWrite ? `Passed for ${selected.name}` : 'Test Write must pass on the exact revision before Calibration Write.' }
    ];
    return {
      applicable: true, projectId: active.id, projectName: active.name, expectedBinSize: P01_BIN_SIZE,
      identity, reads: state.reads || [], readPair: pair, dualReadVerified: dualRead, readMismatch: Boolean(state.readMismatch), readResolution: state.readResolution || '', canonicalReadSha256: state.canonicalReadSha256 || '',
      original, originalMatches, definition, parameterMap, backend, backendReady, selectedRevision: selected, validation: validation || null, testWrite: testWrite || null,
      readyForAi: aiBlockers.length === 0, readyForTestWrite: writeBlockers.filter(item => !item.startsWith('Run a successful Test Write') && !item.startsWith('Commissioning-only mode permits Test Write')).length === 0,
      readyForWrite: writeBlockers.length === 0, blockers, aiBlockers, writeBlockers, steps, stateFile: this.file(active)
    };
  }

  assertAiReady() {
    const active = this.getActiveProject();
    if (!this.isP01(active)) return this.status(active);
    const status = this.status(active);
    if (!status.readyForAi) throw new Error(`P01 commissioning is incomplete:\n• ${status.aiBlockers.join('\n• ')}`);
    return status;
  }

  assertOperationReady(operation, input) {
    const active = this.getActiveProject();
    if (!this.isP01(active) || !['testWrite','writeCalibration','writeFull'].includes(operation)) return this.status(active, input);
    const status = this.status(active, input);
    const blockers = operation === 'testWrite' ? status.writeBlockers.filter(item => !item.startsWith('Run a successful Test Write') && !item.startsWith('Commissioning-only mode permits Test Write')) : status.writeBlockers;
    if (blockers.length) throw new Error(`P01 ${operation === 'testWrite' ? 'Test Write' : 'write'} is locked:\n• ${blockers.join('\n• ')}`);
    return status;
  }

  reset() {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a project first.');
    const file = this.file(active);
    if (file && fs.existsSync(file)) fs.renameSync(file, `${file}.${Date.now()}.reset.json`);
    this.appendActivity('p01-commissioning-reset', { projectId: active.id, projectName: active.name });
    return this.status(active);
  }
}

module.exports = { P01CommissioningManager, P01_BIN_SIZE, identityFingerprint, osCandidates, fileInfo };
