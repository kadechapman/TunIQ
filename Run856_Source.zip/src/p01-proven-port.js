function clean(value, max = 400) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}
function normalizePort(value) {
  const match = clean(value, 40).toUpperCase().match(/^COM\d+$/);
  return match ? match[0] : '';
}
function identityMatchesProject(session = {}, p01 = {}) {
  const identity = session.identity || session.result?.identity || {};
  const controller = clean(identity.controller || p01.identity?.controller || '', 40).toUpperCase();
  const expectedOs = clean(p01.identity?.os || '', 40);
  const sessionOs = clean(identity.os || identity.osid || '', 40);
  if (controller && controller !== 'P01') return false;
  if (expectedOs && sessionOs && expectedOs !== sessionOs) return false;
  // Two P01s can run the same OS on the same COM port. When both sides
  // report hardware/service identifiers, they must describe the same ECU.
  for (const key of ['hardwareId', 'serviceNumber']) {
    const expected = clean(p01.identity?.[key], 80);
    const observed = clean(identity[key], 80);
    if (expected && observed && expected !== observed) return false;
  }
  return true;
}
// Session history and guided state are only continuity hints. This is not physical
// authentication; it prevents incomplete/unverified records from being promoted.
function sessionProvesCommunication(session = {}, { projectId = '', p01 = {} } = {}) {
  if (!session || (projectId && session.projectId !== projectId)) return false;
  const operation = clean(session.operation, 40);
  if (!['readProperties', 'read', 'testWrite'].includes(operation)) return false;
  if (clean(session.state, 60) !== 'complete' || !normalizePort(session.device)) return false;
  if (operation === 'readProperties') {
    const identity = session.identity || session.result?.identity || {};
    if (clean(identity.controller, 40).toUpperCase() !== 'P01') return false;
    if (!/^\d{7,9}$/.test(clean(identity.os || identity.osid, 40))) return false;
  }
  if (operation === 'read' && session.outputValidation?.valid !== true) return false;
  if (operation === 'testWrite' && session.testWritePassed !== true && session.result?.testWritePassed !== true) return false;
  if (!identityMatchesProject(session, p01)) return false;
  return true;
}
function proofFromSession(session = {}, source = 'flash-history', previousProof = null) {
  if (!session || clean(session.state, 60) !== 'complete') return null;
  const operation = clean(session.operation, 40);
  if (!['readProperties', 'read', 'testWrite'].includes(operation)) return null;
  if (!normalizePort(session.device) || !clean(session.projectId, 160)) return null;
  if (operation === 'read' && session.outputValidation?.valid !== true) return null;
  if (operation === 'testWrite' && session.testWritePassed !== true && session.result?.testWritePassed !== true) return null;
  const identity = session.identity || session.result?.identity || {};
  const controller = clean(identity.controller, 40).toUpperCase();
  const os = clean(identity.os || identity.osid, 40);
  let provenIdentity;
  let identitySourceSessionId = '';
  if (operation === 'readProperties') {
    if (controller !== 'P01' || !/^\d{7,9}$/.test(os)) return null;
    provenIdentity = identity;
    identitySourceSessionId = clean(session.id, 180);
  } else {
    // Full Read output often has no OSID. Keep the exact *prior* Read Properties
    // identity, but never invent one or borrow it from another project/port.
    const prior = validateProvenPortBinding({ proof: previousProof, port: session.device,
      project: { id: session.projectId, controller: 'P01', os: previousProof?.os || '' } });
    if (!prior.valid) return null;
    if ((controller && controller !== 'P01') || (os && os !== clean(previousProof.os, 40))) return null;
    const hw = clean(identity.hardwareId, 80);
    const svc = clean(identity.serviceNumber, 80);
    if (hw && previousProof.hardwareId && hw !== clean(previousProof.hardwareId, 80)) return null;
    if (svc && previousProof.serviceNumber && svc !== clean(previousProof.serviceNumber, 80)) return null;
    provenIdentity = previousProof;
    identitySourceSessionId = clean(previousProof.identitySourceSessionId || previousProof.sessionId, 180);
  }
  return {
    port: normalizePort(session.device),
    projectId: clean(session.projectId, 160),
    operation,
    sessionId: clean(session.id, 180),
    provenAt: clean(session.completedAt || session.finishedAt || session.startedAt || '', 80),
    controller: 'P01',
    os: clean(provenIdentity.os || provenIdentity.osid, 40),
    hardwareId: clean(provenIdentity.hardwareId, 80),
    serviceNumber: clean(provenIdentity.serviceNumber, 80),
    identitySourceSessionId,
    source
  };
}
function findLatestProvenPort({ history = [], projectId = '', p01 = {}, state = {} } = {}) {
  const project = { id: projectId, controller: clean(p01.identity?.controller || '', 40), os: clean(p01.identity?.os || '', 40) };
  const sessions = Array.isArray(history) ? history : [];
  // Flash history is newest-first. A persisted guided-state object is only a
  // hint: never let it create proof that is absent from successful session
  // history, or override a newer verified session after an application restart.
  for (let i = 0; i < sessions.length; i++) {
    const session = sessions[i];
    // A newer completed identity observation for this project that conflicts
    // with the active ECU invalidates older COM proof. Never silently fall back
    // to a prior P01 that shares the same OS/serial adapter. A completed but
    // malformed Read Properties result is also not a safe reuse boundary.
    // A finalized failed/cancelled identity check is a new identity boundary.
    // The old P01 may have been unplugged or replaced while retaining COM4;
    // never silently fall back to its older successful Read Properties record.
    // Failed *Full Reads* are different: they preserve the prior verified
    // identity so the operator can safely diagnose and retry the read.
    // Any newer identity recheck suspends old COM authority until it completes
    // with a valid P01/OS identity. This includes an in-flight attempt and an
    // unfamiliar future state; do not let a restart reuse an older ECU proof.
    if (session?.projectId === projectId && session.operation === 'readProperties' &&
        normalizePort(session.device) && clean(session.state, 60) !== 'complete') return null;
    if (session?.projectId === projectId && session.state === 'complete' &&
        normalizePort(session.device) &&
        (session.operation === 'readProperties' ||
          (['read', 'testWrite'].includes(session.operation) && !identityMatchesProject(session, p01))) &&
        !sessionProvesCommunication(session, { projectId, p01 })) return null;
    if (!sessionProvesCommunication(session, { projectId, p01 })) continue;
    let previous = null;
    if (session.operation !== 'readProperties') {
      // Do not skip over an unsuccessful or mismatched Read Properties to
      // borrow an older OSID. Only the immediately preceding identity attempt
      // for this project can establish lineage for a later read/Test Write.
      const priorSession = sessions.slice(i + 1).find(item =>
        item.projectId === projectId && item.operation === 'readProperties' && normalizePort(item.device));
      if (priorSession && normalizePort(priorSession.device) === normalizePort(session.device) &&
          sessionProvesCommunication(priorSession, { projectId, p01 })) previous = proofFromSession(priorSession);
    }
    const proof = proofFromSession(session, 'flash-history', previous);
    if (!proof || !validateProvenPortBinding({ proof, port: proof.port, project }).valid) continue;
    const saved = state?.provenHardwareSession;
    // Compare IDs and identity lineage with the actual reconstructed history,
    // rather than trusting mutable guided-state fields. An older saved session
    // is never preferred over the latest valid history entry.
    if (saved && clean(saved.sessionId, 180) && clean(saved.sessionId, 180) === proof.sessionId &&
        clean(saved.identitySourceSessionId, 180) === proof.identitySourceSessionId &&
        normalizePort(saved.port) === proof.port && clean(saved.projectId, 160) === proof.projectId &&
        clean(saved.controller, 40).toUpperCase() === proof.controller &&
        clean(saved.os, 40) === proof.os && clean(saved.operation, 40) === proof.operation) {
      return { ...proof, source: 'guided-state-validated-against-history' };
    }
    return proof;
  }
  return null;
}
// A persisted guided-state claim must never outlive the successful history that
// supported it. Clearing authority does NOT clear the user's selected COM port:
// a fresh Read Properties can still be attempted without inheriting old proof.
function reconcileProvenHardwareState(state = {}, proof = null) {
  const hasProof = Boolean(proof && proof.port && proof.sessionId);
  const patch = hasProof ? {
    device: proof.port,
    pcmHammerProvenPort: proof.port,
    pcmHammerProvenAt: proof.provenAt || null,
    pcmHammerProvenOperation: proof.operation || null,
    provenHardwareSession: proof
  } : {
    pcmHammerProvenPort: '',
    pcmHammerProvenAt: null,
    pcmHammerProvenOperation: null,
    provenHardwareSession: null
  };
  const changed = !hasProof ? Boolean(state.provenHardwareSession || state.pcmHammerProvenPort ||
    state.pcmHammerProvenAt || state.pcmHammerProvenOperation) : Object.keys(patch).some(key => {
    if (key !== 'provenHardwareSession') return state[key] !== patch[key];
    const prior = state.provenHardwareSession;
    const next = patch.provenHardwareSession;
    if (!prior || !next) return prior !== next;
    // Same COM/project is insufficient: the session/identity lineage may have
    // changed since the last saved guided-state snapshot.
    return ['sessionId', 'identitySourceSessionId', 'port', 'projectId', 'controller',
      'os', 'hardwareId', 'serviceNumber', 'operation', 'provenAt'].some(field => prior[field] !== next[field]);
  });
  return { patch, changed, cleared: !hasProof };
}
// Binding check only: project and hardware session must describe the same ECU.
function validateProvenPortBinding({ proof = null, port = '', project = null } = {}) {
  if (!proof || typeof proof !== 'object' || Array.isArray(proof)) return { valid: false, reason: 'missing-proof' };
  const selectedPort = normalizePort(port);
  if (!selectedPort || normalizePort(proof.port) !== selectedPort) return { valid: false, reason: 'port-mismatch' };
  if (!project?.id || clean(proof.projectId, 160) !== clean(project.id, 160)) return { valid: false, reason: 'project-mismatch' };
  const controller = clean(proof.controller, 40).toUpperCase();
  const projectController = clean(project.controller, 40).toUpperCase();
  if (controller !== 'P01' || projectController !== controller) return { valid: false, reason: 'controller-mismatch' };
  const proofOs = clean(proof.os, 40);
  const projectOs = clean(project.os, 40);
  if (!/^\d{7,9}$/.test(proofOs) || !/^\d{7,9}$/.test(projectOs) || proofOs !== projectOs) return { valid: false, reason: 'os-mismatch' };
  for (const key of ['hardwareId', 'serviceNumber']) {
    const expected = clean(project[key], 80);
    const observed = clean(proof[key], 80);
    if (expected && observed && expected !== observed) return { valid: false, reason: `${key}-mismatch` };
  }
  if (!['readProperties', 'read', 'testWrite'].includes(clean(proof.operation, 40))) return { valid: false, reason: 'operation-not-proven' };
  return { valid: true, reason: 'matching-claimed-session' };
}
function shouldReuseProof(operation = '', proof = null) {
  return Boolean(proof?.port && ['read', 'testWrite'].includes(clean(operation, 40)));
}
module.exports = { normalizePort, sessionProvesCommunication, proofFromSession, findLatestProvenPort, shouldReuseProof, validateProvenPortBinding, reconcileProvenHardwareState };
