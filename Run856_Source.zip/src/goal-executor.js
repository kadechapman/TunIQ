const fs = require('fs');
const path = require('path');
const { unresolvedCalibrationRequests, explicitRequestOsConflict } = require('./calibration-request-coverage');
const { commissionedCellIndex } = require('./commissioned-cell-index');

function finite(value) { const n = Number(value); return Number.isFinite(n) ? n : null; }
// Decoded XDF cells are evidence, not user-entered numeric strings. Coercing
// null/false/empty arrays/strings to zero fabricated VATS and fan proposals
// before the later approval guard could reject the corrupted workspace.
function finiteCalibrationCell(value) {
  return typeof value === 'number' && Number.isFinite(value) ? value : null;
}
function round(value, digits = 3) { return Number.isFinite(value) ? Number(value.toFixed(digits)) : null; }
function safe(value, max = 1000) { return String(value ?? '').trim().slice(0, max); }
function tableText(table) { return `${table?.name || ''} ${table?.description || ''} ${table?.category || ''} ${table?.unit || ''} ${(table?.rowHeaders || []).join(' ')} ${(table?.colHeaders || []).join(' ')}`.toLowerCase(); }
function tableCells(table) {
  const output = [];
  for (let row = 0; row < (table?.values?.length || 0); row += 1) {
    for (let col = 0; col < (table.values[row]?.length || 0); col += 1) {
      const value = finiteCalibrationCell(table.values[row][col]);
      if (value != null) output.push({ row, col, value, rowLabel: table.rowHeaders?.[row] ?? String(row), colLabel: table.colHeaders?.[col] ?? String(col) });
    }
  }
  return output;
}
function requestId() { return `${Date.now()}-goal-${Math.random().toString(16).slice(2,8)}`; }

function extractNear(text, keywords, unitPattern = '', digits = '{2,3}') {
  const patterns = keywords.map(keyword => new RegExp(`${keyword}[^0-9]{0,24}(\\d${digits}(?:\\.\\d+)?)\\s*${unitPattern}`, 'i'));
  for (const pattern of patterns) { const match = text.match(pattern); if (match) return Number(match[1]); }
  return null;
}

function parseTuneRequest(input) {
  // Never silently discard trailing instructions (e.g. a knock delete after VATS).
  if (String(input ?? '').trim().length > 2000) {
    throw new Error('Tune request exceeds 2,000 characters. Split it into shorter, complete requests for separate review; no partial calibration was prepared.');
  }
  const text = safe(input, 2000);
  const lower = text.toLowerCase();
  const intents = [];
  const ghost = /ghost\s*-?\s*cam|fake\s*cam|lopey?\s*idle|choppy?\s*idle/.test(lower);
  if (ghost) intents.push({ type: 'ghost-cam', label: 'Ghost-cam idle', requested: true });

  let rpm = extractNear(lower, ['(?:max(?:imum)?\\s*)?rev(?:\\s*limit)?','rpm(?:\\s*limit)?','redline','fuel\\s*cut'], '(?:rpm)?', '{4,5}');
  if (rpm == null) {
    const match = lower.match(/(?:raise|set|change).*?(\d{4,5})\s*rpm/); if (match) rpm = Number(match[1]);
  }
  if (rpm != null) intents.push({ type: 'rev-limit', label: 'Engine RPM limit', target: rpm, unit: 'RPM' });

  let speed = extractNear(lower, ['(?:max(?:imum)?\\s*)?speed(?:\\s*limit)?','vehicle\\s*speed','speed\\s*limiter'], '(?:mph|mi/h|km/h|kph)?');
  const speedUnit = /(?:km\/h|kph|kilomet)/i.test(lower) ? 'km/h' : 'mph';
  if (speed != null) intents.push({ type: 'speed-limit', label: 'Vehicle speed limiter', target: speed, unit: speedUnit });

  if (/remove\s+(?:the\s+)?speed\s+limit|disable\s+(?:the\s+)?speed\s+limiter/.test(lower) && !intents.some(item => item.type === 'speed-limit')) {
    intents.push({ type: 'speed-limit', label: 'Vehicle speed limiter', target: 255, unit: 'mph', interpretedAs: 'remove limiter' });
  }

  const vats = /(?:disable|remove|delete|turn\s*off|shut\s*off)\s+(?:the\s+)?(?:vats|vehicle\s+anti[- ]?theft|anti[- ]?theft|theft\s+deterrent|vtd)|(?:vats|vehicle\s+anti[- ]?theft|anti[- ]?theft|theft\s+deterrent|vtd)[^.!?]{0,30}(?:disable|remove|delete|off)/i.test(lower);
  if (vats) intents.push({ type: 'vats-disable', label: 'Disable VATS / theft deterrent', target: 'disabled' });

  const fanMention = /(?:electric\s+)?fans?|cooling\s+fans?/.test(lower);
  if (fanMention) {
    const explicitUnits = [...lower.matchAll(/\b\d{2,3}(?:\.\d+)?\s*(?:°\s*)?(?:deg(?:rees?)?\s*)?(fahrenheit|celsius|[fc])\b/gi)].map(match => /^(?:c|celsius)$/i.test(match[1]) ? 'C' : 'F');
    // Explicit F and C in one fan request are not interchangeable. The old
    // parser silently chose C for BOTH thresholds, so 95 F on / 80 C off
    // became 95 C on / 80 C off and could pass range/hysteresis checks.
    const mixedUnits = new Set(explicitUnits).size > 1;
    const unit = mixedUnits ? null : explicitUnits.includes('C') ? 'C' : 'F';
    const onMatch = lower.match(/(?:fan(?:s)?[^0-9]{0,28})?(?:on|turn\s*on|enable|engage|activate)[^0-9]{0,18}(\d{2,3}(?:\.\d+)?)/i)
      || lower.match(/(\d{2,3}(?:\.\d+)?)\s*(?:°?[fc])?[^.!?]{0,18}(?:fan(?:s)?\s+)?(?:on|turn\s*on|enable|engage|activate)/i);
    const offMatch = lower.match(/(?:fan(?:s)?[^0-9]{0,28})?(?:off|turn\s*off|disable|release|deactivate)[^0-9]{0,18}(\d{2,3}(?:\.\d+)?)/i)
      || lower.match(/(\d{2,3}(?:\.\d+)?)\s*(?:°?[fc])?[^.!?]{0,18}(?:fan(?:s)?\s+)?(?:off|turn\s*off|disable|release|deactivate)/i);
    const on = onMatch ? Number(onMatch[1]) : null;
    const off = offMatch ? Number(offMatch[1]) : null;
    if (on != null || off != null) intents.push({ type: 'fan-control', label: 'Set electric-fan temperatures', fanOn: on, fanOff: off, unit, ...(mixedUnits ? { mixedUnits: true } : {}) });
  }

  const unresolvedRequests = unresolvedCalibrationRequests(text, intents);
  return {
    text,
    intents,
    unresolvedRequests,
    recognized: intents.length > 0 || unresolvedRequests.length > 0,
    unrecognizedText: intents.length || unresolvedRequests.length ? '' : text,
    warnings: [
      ...(ghost ? ['Ghost-cam behavior requires a verified controller/OS rule pack. TunIQ will not invent idle-spark values.'] : []),
      ...(speed != null && ((speedUnit === 'mph' && speed > 130) || (speedUnit === 'km/h' && speed > 210)) ? ['The requested speed limiter is high risk and requires tire, driveline, brake, and closed-course confirmations.'] : []),
      ...(rpm != null && rpm > 5800 ? ['The requested RPM limit requires confirmed valvetrain capability.'] : [])
    ]
  };
}

function matchTables(workspace, patterns, excludes = []) {
  return Object.entries(workspace?.tables || {}).filter(([, table]) => {
    const text = tableText(table);
    return patterns.some(pattern => pattern.test(text)) && !excludes.some(pattern => pattern.test(text));
  });
}

function valueForUnit(target, unit, table) {
  const tableUnit = String(table?.unit || '').toLowerCase();
  if (unit === 'mph' && /(km\/h|kph|kmh)/.test(tableUnit)) return target / 0.621371;
  if (unit === 'km/h' && /(mph|mi\/h)/.test(tableUnit)) return target * 0.621371;
  return target;
}

function mappedCellEntries(workspace, parameterMap, actionType) {
  const cells = parameterMap?.actions?.[actionType]?.cells || [];
  const output = [];
  for (const mapping of cells) {
    const row = commissionedCellIndex(mapping?.row);
    const col = commissionedCellIndex(mapping?.col);
    // A malformed saved map must not silently alias row/col zero, nor let
    // the otherwise valid VATS/fan subset appear fully commissioned.
    if (row === null || col === null || typeof mapping?.tableKey !== 'string' ||
        !mapping.tableKey.trim()) {
      throw new Error('Commissioned calibration map contains an invalid cell coordinate or table key. Reconfirm the exact OS/XDF map; no proposal was prepared.');
    }
    const table = workspace?.tables?.[mapping.tableKey];
    const value = finiteCalibrationCell(table?.values?.[row]?.[col]);
    if (!table || value == null) continue;
    output.push({ tableKey: mapping.tableKey, table, mapping, cell: {
      row, col, value,
      rowLabel: table.rowHeaders?.[row] ?? mapping.rowLabel ?? String(row),
      colLabel: table.colHeaders?.[col] ?? mapping.colLabel ?? String(col)
    }});
  }
  return output;
}

function cellProposal(prefix, action, tableKey, table, cell, proposed, reason, risk = 'moderate', blocked = false) {
  return {
    id: `${prefix}:${tableKey}:${cell.row}:${cell.col}`,
    actionId: action.id,
    actionType: action.type,
    tableKey,
    tableName: table.name,
    row: cell.row,
    col: cell.col,
    rowLabel: cell.rowLabel,
    colLabel: cell.colLabel,
    current: round(cell.value, 6),
    proposed: round(proposed, 6),
    delta: round(proposed - cell.value, 6),
    percent: cell.value ? round((proposed / cell.value - 1) * 100, 2) : null,
    reason,
    confidence: action.confidence || 'medium',
    risk,
    blocked,
    approvalRequired: true
  };
}

function buildRevAction(intent, workspace, confirmations, parameterMap = null) {
  const target = finite(intent.target);
  const commissioned = mappedCellEntries(workspace, parameterMap, 'rev-limit');
  const action = { id: `rev-${target}`, type: 'rev-limit', label: `Set RPM limit to ${target} RPM`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: [], mapCommissioned: commissioned.length > 0 };
  if (target == null || target < 3000 || target > 8500) { action.status = 'blocked'; action.requirements.push('Enter an RPM target between 3,000 and 8,500.'); return action; }
  if (target > 5800 && !confirmations.valvetrainVerified) { action.status = 'blocked'; action.requirements.push('Confirm the camshaft, valve springs, pushrods, lifters, oiling, and rotating assembly are suitable for this RPM.'); }
  const entries = commissioned.length ? commissioned : matchTables(workspace, [/rev/i,/engine.*speed.*limit/i,/fuel.*cut.*rpm/i,/rpm.*cut/i,/max.*rpm/i], [/fan/i,/speedometer/i,/input.*shaft/i,/output.*shaft/i,/trans.*rpm/i]).flatMap(([tableKey, table]) => tableCells(table).filter(item => item.value >= 2500 && item.value <= 10000).map(cell => ({ tableKey, table, mapping: {}, cell })));
  if (!entries.length) { action.status = 'blocked'; action.requirements.push('No RPM limiter parameter was found in the loaded XDF.'); return action; }
  let restoreFound = false;
  for (const { tableKey, table, mapping, cell } of entries) {
    const cellText = `${tableText(table)} ${cell.rowLabel} ${cell.colLabel}`.toLowerCase();
    if (!commissioned.length && !/(rev|rpm|engine.*speed|fuel.*cut)/i.test(cellText)) continue;
    const isRestore = mapping.role === 'restore' || /(resume|restore|hysteresis|re-enable)/i.test(`${cell.rowLabel} ${cell.colLabel}`);
    const proposed = isRestore ? target - 200 : target;
    if (isRestore) restoreFound = true;
    action.proposals.push(cellProposal(isRestore ? 'goal-rev-restore' : 'goal-rev', action, tableKey, table, cell, proposed, isRestore ? `Commissioned limiter restore/resume value set 200 RPM below the requested ${target} RPM cutoff.` : `Requested ${target} RPM maximum.`, target > 6500 ? 'high' : 'moderate', action.status === 'blocked'));
  }
  if (!commissioned.length) action.warnings.push('These are XDF mapping candidates. Confirm this action once for the exact P01 OS/XDF before applying it.');
  if (!restoreFound) action.warnings.push('No separate RPM restore/resume value is commissioned. Review the XDF for a companion hysteresis parameter.');
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The RPM mapping did not contain plausible limiter values.'); }
  return action;
}

function buildSpeedAction(intent, workspace, confirmations, parameterMap = null) {
  const target = finite(intent.target);
  const mph = intent.unit === 'km/h' ? target * 0.621371 : target;
  const commissioned = mappedCellEntries(workspace, parameterMap, 'speed-limit');
  const action = { id: `speed-${target}`, type: 'speed-limit', label: `Set speed limiter to ${target} ${intent.unit}`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Changing a limiter does not make the vehicle capable of safely reaching that speed.'], mapCommissioned: commissioned.length > 0 };
  if (target == null || mph < 30 || mph > 255) { action.status = 'blocked'; action.requirements.push('Enter a speed-limiter target between 30 and 255 MPH equivalent.'); return action; }
  if (mph > 130) {
    const tire = finite(confirmations.tireRatingMph);
    if (!(tire >= mph)) { action.status = 'blocked'; action.requirements.push(`Confirm a tire speed rating of at least ${Math.ceil(mph)} MPH.`); }
    if (!confirmations.drivelineVerified) { action.status = 'blocked'; action.requirements.push('Confirm driveshaft critical speed, U-joints, differential, and transmission output components.'); }
    if (!confirmations.brakesVerified) { action.status = 'blocked'; action.requirements.push('Confirm braking, wheel bearings, suspension, and vehicle stability are appropriate.'); }
    if (!confirmations.closedCourse) { action.status = 'blocked'; action.requirements.push('Confirm closed-course or controlled test use.'); }
  }
  const entries = commissioned.length ? commissioned : matchTables(workspace, [/vehicle.*speed/i,/speed.*limit/i,/top.*speed/i,/engine.*speed.*limits/i], [/fan/i,/shift/i,/speedometer.*cal/i,/output.*shaft/i]).flatMap(([tableKey, table]) => tableCells(table).filter(item => item.value >= 20 && item.value <= 450).map(cell => ({ tableKey, table, mapping: {}, cell })));
  if (!entries.length) { action.status = 'blocked'; action.requirements.push('No vehicle-speed limiter parameter was found in the loaded XDF.'); return action; }
  for (const { tableKey, table, cell } of entries) {
    const cellText = `${tableText(table)} ${cell.rowLabel} ${cell.colLabel}`.toLowerCase();
    if (!commissioned.length && !/(vehicle.*speed|speed.*limit|top.*speed)/i.test(cellText)) continue;
    const stored = valueForUnit(target, intent.unit, table);
    action.proposals.push(cellProposal('goal-speed', action, tableKey, table, cell, stored, `Requested vehicle-speed limiter of ${target} ${intent.unit}.`, mph > 130 ? 'high' : 'moderate', action.status === 'blocked'));
  }
  if (!commissioned.length) action.warnings.push('These are XDF mapping candidates. Confirm this action once for the exact P01 OS/XDF before applying it.');
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The speed-limiter mapping did not contain a plausible value.'); }
  return action;
}

function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function loadRulePacks(folders = []) {
  const packs = [];
  for (const folder of folders) {
    if (!folder || !fs.existsSync(folder)) continue;
    for (const name of fs.readdirSync(folder)) {
      if (!name.toLowerCase().endsWith('.json')) continue;
      const pack = readJson(path.join(folder, name), null);
      if (pack && typeof pack === 'object') packs.push({ ...pack, file: path.join(folder, name) });
    }
  }
  return packs;
}
function matchesPack(pack, active) {
  if (!pack?.verified || pack.goal !== 'ghost-cam') return false;
  const controller = String(active?.controller || '').toUpperCase();
  const os = String(active?.os || '');
  const controllers = Array.isArray(pack.controllers) ? pack.controllers.map(item => String(item).toUpperCase()) : ['*'];
  const operatingSystems = Array.isArray(pack.operatingSystems) ? pack.operatingSystems.map(String) : ['*'];
  return (controllers.includes('*') || controllers.includes(controller)) && (operatingSystems.includes('*') || operatingSystems.includes(os));
}
function applyRuleOperation(current, rule, index = 0) {
  const amount = finite(rule.value);
  if (amount == null) return null;
  if (rule.operation === 'set') return amount;
  if (rule.operation === 'add') return current + amount;
  if (rule.operation === 'percent') return current * (1 + amount / 100);
  if (rule.operation === 'alternating-add') return current + (index % 2 === 0 ? amount : -amount);
  return null;
}

function disabledEnumValue(table) {
  const labels = Array.isArray(table?.enumLabels) ? table.enumLabels : [];
  // Enum labels are evidence only when they unambiguously describe one
  // disabled state. Substring matching used to accept "Not Disabled" and
  // "Disabled / Enabled" as if they proved a numeric target. Reject
  // contradictory, uncertain, or multiple different disabled indexes.
  const candidates = [];
  for (const item of labels) {
    if (!item || typeof item.index !== 'number' || !Number.isFinite(item.index)) continue;
    const label = String(item.value ?? '').trim().toLowerCase();
    if (!label || /[?]/.test(label) ||
        /\b(?:not|never)\s+(?:be\s+)?(?:disabled?|off)\b/.test(label) ||
        /\b(?:enabled|active|on)\b/.test(label)) continue;
    if (/\b(?:disabled?|none|not\s+used|not\s+present|no\s+vats|off)\b/.test(label)) {
      candidates.push(item.index);
    }
  }
  return candidates.length && candidates.every(value => value === candidates[0])
    ? candidates[0] : null;
}

function vatsTargetForCell(table, cell, mapping = {}) {
  // Number(null), Number('') and Number(false) are all zero. None is an
  // explicitly commissioned VATS disabled state; accepting them can silently
  // override a verified XDF enum with an invented zero. Only finite JSON
  // numbers are authoritative. Null/undefined mean no override; malformed
  // non-null overrides block this cell rather than falling back silently.
  if (Object.prototype.hasOwnProperty.call(mapping, 'disabledValue') &&
      mapping.disabledValue != null) {
    if (typeof mapping.disabledValue !== 'number' || !Number.isFinite(mapping.disabledValue)) return null;
    return { value: mapping.disabledValue, evidence: 'commissioned disabled value' };
  }
  const enumValue = disabledEnumValue(table);
  if (enumValue != null) return { value: enumValue, evidence: 'XDF enum label identifies the disabled state' };
  // An enum that exists but does not identify ONE unambiguous disabled state
  // is contradictory or incomplete evidence. Do not bypass it using a broad
  // flag-name heuristic, even when the table is named 'VATS Enable Flag'.
  if (Array.isArray(table?.enumLabels) && table.enumLabels.length > 0) return null;
  const text = `${tableText(table)} ${cell.rowLabel || ''} ${cell.colLabel || ''}`.toLowerCase();
  // Without a verified enum, infer only from a single affirmative flag label.
  // 'VATS Not Enabled' and 'VATS Enable / Disable' are not proofs of which
  // numeric state disables theft deterrence. Fail closed, never guess 0/1.
  if (/\b(?:not|never|no)\s+(?:(?:currently|actually|fully|yet)\s+)?(?:enable(?:d)?|disable(?:d)?|active|inactive|on|off)\b/i.test(text)) return null;
  const mentionsEnable = /\b(?:enable|enabled|active)\b/i.test(text);
  const mentionsDisable = /\b(?:disable|disabled|inactive)\b/i.test(text);
  if (mentionsEnable && mentionsDisable) return null;
  const current = finite(cell.value);
  if (current != null && [0, 1].includes(current)) {
    if (/(?:vats|anti.?theft|theft.?deterrent|vtd).*(?:enable|enabled|active)|(?:enable|enabled).*(?:vats|anti.?theft|theft.?deterrent|vtd)/i.test(text)) return { value: 0, evidence: 'explicit enable flag' };
    if (/(?:vats|anti.?theft|theft.?deterrent|vtd).*(?:disable|disabled)|(?:disable|disabled).*(?:vats|anti.?theft|theft.?deterrent|vtd)/i.test(text)) return { value: 1, evidence: 'explicit disable flag' };
  }
  return null;
}
function buildVatsAction(intent, workspace, confirmations, parameterMap = null) {
  const commissioned = mappedCellEntries(workspace, parameterMap, 'vats-disable');
  const action = { id: 'vats-disable', type: 'vats-disable', label: 'Disable VATS / theft deterrent', status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['VATS removal is intended for a lawful engine swap or authorized vehicle repair. It does not bypass physical security and must not be used on a vehicle you do not own or have permission to modify.'], mapCommissioned: commissioned.length > 0 };
  const candidates = commissioned.length ? commissioned : matchTables(workspace,
    [/\bvats\b/i,/vehicle.*anti.?theft/i,/anti.?theft/i,/theft.*deterrent/i,/\bvtd\b/i,/fuel.*enable.*password/i],
    [/diagnostic/i,/dtc/i,/history/i]).flatMap(([tableKey, table]) => tableCells(table).map(cell => ({ tableKey, table, mapping: {}, cell })));
  const seen = new Set();
  for (const entry of candidates) {
    const key = `${entry.tableKey}:${entry.cell.row}:${entry.cell.col}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const combined = `${tableText(entry.table)} ${entry.cell.rowLabel} ${entry.cell.colLabel}`;
    if (!commissioned.length && !/(?:\bvats\b|vehicle.*anti.?theft|anti.?theft|theft.*deterrent|\bvtd\b|fuel.*enable.*password)/i.test(combined)) continue;
    const target = vatsTargetForCell(entry.table, entry.cell, entry.mapping);
    if (!target) continue;
    action.proposals.push(cellProposal('goal-vats-disable', action, entry.tableKey, entry.table, entry.cell, target.value, `Set the mapped theft-deterrent parameter to its disabled state (${target.evidence}).`, 'moderate', false));
  }
  if (!action.proposals.length) {
    action.status = 'blocked';
    action.requirements.push('No unambiguous VATS disable value was found. Use an exact writable XDF or Universal Patcher definition that labels the disabled state; TunIQ will not guess a security value or address.');
  } else if (!commissioned.length) {
    action.warnings.push('These are exact XDF mapping candidates. Verify and commission the cells for this specific P01 OS, XDF hash, and protected original before applying them.');
  }
  return action;
}
function temperatureUnit(table) {
  // XDF metadata can contradict itself (e.g. unit="deg F" but description
  // says "deg C"). The former parser preferred C silently. Refuse to
  // prepare or approve fan thresholds until the definition is corrected;
  // this is metadata triage, not proof of the physical ECM's unit encoding.
  const text = `${table?.unit || ''} ${table?.description || ''}`.toLowerCase();
  const celsius = /(?:°\s*c|deg(?:rees?)?\s*c|celsius|\bdegc\b)/i.test(text);
  const fahrenheit = /(?:°\s*f|deg(?:rees?)?\s*f|fahrenheit|\bdegf\b)/i.test(text);
  if (celsius === fahrenheit) return '';
  return celsius ? 'C' : 'F';
}
// Cell-level temperature annotations are stronger evidence than a shared
// table unit. An XDF may say deg F at table level while a specific ON/OFF
// row says °C. Do not write Fahrenheit numbers into a Celsius-labeled cell.
// This checks metadata consistency only; it does not prove ECU scaling.
function fanCellUnitConflict(table, cell = {}) {
  const labels = `${cell.rowLabel || ''} ${cell.colLabel || ''}`;
  const celsius = /(?:°\s*c\b|deg(?:rees?)?\s*c\b|\bcelsius\b)/i.test(labels);
  const fahrenheit = /(?:°\s*f\b|deg(?:rees?)?\s*f\b|\bfahrenheit\b)/i.test(labels);
  if (!celsius && !fahrenheit) return false;
  const unit = temperatureUnit(table);
  return celsius === fahrenheit || !unit || (celsius ? unit !== 'C' : unit !== 'F');
}
function requestedTemperature(value, requestUnit, tableUnit) {
  const number = finite(value);
  if (number == null) return null;
  if (requestUnit === tableUnit || !tableUnit) return number;
  if (requestUnit === 'F' && tableUnit === 'C') return (number - 32) * 5 / 9;
  if (requestUnit === 'C' && tableUnit === 'F') return number * 9 / 5 + 32;
  return null;
}
function fanRole(entry) {
  // Row/column labels are the nearest evidence of the target cell's role.
  // A shared table title such as "Fan On/Off Temperatures" must not turn
  // every ON cell into an OFF proposal. Likewise, a commissioned map that
  // contradicts explicit CURRENT labels is not authority to swap thresholds.
  const cell = entry?.cell || {};
  const labelRole = fanRoleFromCellLabels(cell);
  const mappedRole = ['fan-on', 'fan-off'].includes(entry?.mapping?.role) ? entry.mapping.role : '';
  if (mappedRole) return labelRole && labelRole !== mappedRole ? '' : mappedRole;
  if (labelRole) return labelRole;
  // Ambiguous or missing labels are not resolved by a mixed-role table title.
  const text = `${entry?.table?.name || ''} ${entry?.table?.description || ''}`.toLowerCase();
  const off = /(?:\boff\b|turn\s*off|deactivat|release|disable|resume)/i.test(text);
  const on = /(?:\bon\b|turn\s*on|activat|engage|enable)/i.test(text);
  if (on === off) return '';
  return on ? 'fan-on' : 'fan-off';
}
// Approval must establish one role from the CURRENT cell labels alone.
// A label such as "Fan 1 On / Off" or a row/column disagreement is not
// evidence of an OFF threshold merely because "off" appears first in a
// heuristic. Do not use table descriptions or a saved proposal ID to decide.
function fanRoleFromCellLabels(cell = {}) {
  const text = `${cell.rowLabel || ''} ${cell.colLabel || ''}`.toLowerCase();
  const off = /\b(?:off|deactivat\w*|releas\w*|disabl\w*)\b/i.test(text);
  const on = /\b(?:on|activat\w*|engag\w*|enabl\w*)\b/i.test(text);
  if (on === off) return '';
  return on ? 'fan-on' : 'fan-off';
}
// Temperature thresholds and output/relay enablement are different ECM
// parameters. A table merely named "Electric Fan Enable" is not evidence of
// a coolant-temperature threshold, even if a broken XDF labels it deg F.
// Do not write a temperature into a boolean output-enable cell.
function isFanTemperatureCell(table, cell = {}) {
  const text = `${table?.name || ''} ${table?.description || ''} ${cell?.rowLabel || ''} ${cell?.colLabel || ''}`;
  // A row/column named merely "Fan 1 Enable" or "Fan 1 Disable" identifies
  // a possible boolean output state, NOT an ON/OFF temperature threshold.
  // A temperature-related table title or an erroneous deg F unit cannot
  // resolve that ambiguity. Require an explicitly labeled ON/OFF threshold
  // instead; this check also runs again during delayed approval.
  const cellLabels = `${cell?.rowLabel || ''} ${cell?.colLabel || ''}`;
  if (/\b(?:enable(?:d|ment)?|disable(?:d|ment)?)\b/i.test(cellLabels)) return false;
  // Even temperature-related descriptions can belong to a relay-enable bit.
  // Output/relay *enabled status* is a boolean state, not a fan-on
  // temperature. The earlier singular "output enable" check missed
  // "output enabled" / "relay enablement" and proposed 210 for a 0/1 bit.
  if (/\b(?:enable(?:d|ment)?|disable(?:d|ment)?|activation)\s+(?:flag|bit|state|switch|status)\b|\b(?:output|relay)\s+(?:is\s+)?(?:enable(?:d|ment)?|disable(?:d|ment)?|active|inactive|status)\b/i.test(text)) return false;
  return /\b(?:temp(?:erature)?s?|coolant|ect|thresholds?|setpoints?)\b/i.test(text);
}
function buildFanAction(intent, workspace, confirmations, parameterMap = null) {
  const fanOn = finite(intent.fanOn), fanOff = finite(intent.fanOff), requestUnit = intent.unit === 'C' ? 'C' : 'F';
  const commissioned = mappedCellEntries(workspace, parameterMap, 'fan-control');
  const action = { id: `fan-${fanOn ?? 'x'}-${fanOff ?? 'x'}-${requestUnit}`, type: 'fan-control', label: `Set electric fans ${fanOn ?? '?'}°${requestUnit} on / ${fanOff ?? '?'}°${requestUnit} off`, status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Fan-output enablement is a separate exact-OS and wiring verification; threshold proposals do not enable or verify the physical output.', 'Verify coolant-temperature sensor accuracy, thermostat choice, relay/fuse capacity, fan wiring, and airflow direction before relying on PCM fan control.'], mapCommissioned: commissioned.length > 0 };
  if (fanOn == null || fanOff == null) { action.status = 'blocked'; action.requirements.push('Provide both a fan-on and fan-off temperature.'); return action; }
  const onF = requestUnit === 'F' ? fanOn : fanOn * 9 / 5 + 32;
  const offF = requestUnit === 'F' ? fanOff : fanOff * 9 / 5 + 32;
  if (onF < 150 || onF > 235 || offF < 130 || offF > 225) { action.status = 'blocked'; action.requirements.push('Fan temperatures must be within a plausible 150–235°F on and 130–225°F off range.'); }
  if (offF >= onF) { action.status = 'blocked'; action.requirements.push('Fan-off temperature must be lower than fan-on temperature to prevent rapid cycling.'); }
  const candidates = commissioned.length ? commissioned : matchTables(workspace,
    [/fan.*(?:temp|temperature|coolant|ect)/i,/(?:temp|temperature|coolant|ect).*fan/i,/electric.*fan/i],
    [/diagnostic/i,/dtc/i,/minimum.*speed/i,/maximum.*speed/i,/ac.*pressure/i]).flatMap(([tableKey, table]) => tableCells(table).map(cell => ({ tableKey, table, mapping: {}, cell })));
  let onCount = 0, offCount = 0;
  let conflictingCellUnits = false;
  const seen = new Set();
  for (const entry of candidates) {
    const role = fanRole(entry);
    if (!role || !isFanTemperatureCell(entry.table, entry.cell)) continue;
    if (fanCellUnitConflict(entry.table, entry.cell)) {
      conflictingCellUnits = true;
      continue;
    }
    const key = `${entry.tableKey}:${entry.cell.row}:${entry.cell.col}`;
    if (seen.has(key)) continue;
    seen.add(key);
    const unit = temperatureUnit(entry.table);
    if (!unit) continue;
    const target = requestedTemperature(role === 'fan-on' ? fanOn : fanOff, requestUnit, unit);
    if (target == null) continue;
    if (Number.isFinite(Number(entry.table.min)) && target < Number(entry.table.min)) continue;
    if (Number.isFinite(Number(entry.table.max)) && target > Number(entry.table.max)) continue;
    if (role === 'fan-on') onCount += 1; else offCount += 1;
    action.proposals.push(cellProposal(`goal-${role}`, action, entry.tableKey, entry.table, entry.cell, target, `${role === 'fan-on' ? 'Turn the mapped fan output on' : 'Turn the mapped fan output off'} at ${role === 'fan-on' ? fanOn : fanOff}°${requestUnit}${unit !== requestUnit ? ` (${round(target, 3)}°${unit} in this XDF)` : ''}.`, 'low', action.status === 'blocked'));
  }
  if (conflictingCellUnits) {
    action.status = 'blocked';
    action.requirements.push('Fan XDF row/column temperature units contradict the table unit. Review and correct the exact definition before approving any fan thresholds.');
    action.proposals.forEach(item => { item.blocked = true; });
  }
  if (!onCount || !offCount) {
    action.status = 'blocked';
    action.requirements.push(!onCount && !offCount ? 'No labeled fan-on or fan-off temperature cells were found in the exact writable XDF.' : !onCount ? 'A fan-off cell was found, but no labeled fan-on temperature cell was found.' : 'A fan-on cell was found, but no labeled fan-off temperature cell was found.');
    action.requirements.push('TunIQ requires labeled engineering units (°F or °C) and will not guess raw fan-temperature addresses.');
    action.proposals.forEach(item => { item.blocked = true; });
  } else if (!commissioned.length) {
    action.warnings.push('Verify and commission these exact fan cells once for this P01 OS/XDF before applying the quick-service preset.');
  }
  return action;
}

function buildGhostAction(intent, workspace, activeProject, confirmations, ruleFolders, parameterMap = null) {
  const commissioned = mappedCellEntries(workspace, parameterMap, 'ghost-cam');
  const action = { id: 'ghost-cam', type: 'ghost-cam', label: 'Create ghost-cam idle profile', status: 'ready', confidence: commissioned.length ? 'commissioned-os-map' : 'mapping-candidate', requirements: [], proposals: [], warnings: ['Ghost-cam calibrations can reduce idle quality, manifold vacuum, brake assist, emissions compliance, and accessory performance.'], mapCommissioned: commissioned.length > 0 };
  if (!confirmations.ghostCamRisksAccepted) { action.status = 'blocked'; action.requirements.push('Accept the idle-quality, vacuum, brake-assist, emissions, and drivability risks.'); }
  const pack = loadRulePacks(ruleFolders).find(item => matchesPack(item, activeProject));
  if (pack && !commissioned.length) {
    action.rulePack = { id: pack.id, name: pack.name, version: pack.version, source: pack.source || 'verified package' };
    action.confidence = 'verified-rule';
    for (const rule of pack.rules || []) {
      const regexes = (rule.tablePatterns || []).map(value => new RegExp(value, 'i'));
      const tables = matchTables(workspace, regexes.length ? regexes : [/$a/]);
      if (!tables.length) { action.status = 'blocked'; action.requirements.push(`Rule ${rule.id || 'unnamed'} could not find its required table.`); continue; }
      for (const [tableKey, table] of tables) {
        const cells = tableCells(table).filter(cell => {
          if (rule.rowLabels?.length && !rule.rowLabels.some(value => new RegExp(value, 'i').test(String(cell.rowLabel)))) return false;
          if (rule.colLabels?.length && !rule.colLabels.some(value => new RegExp(value, 'i').test(String(cell.colLabel)))) return false;
          return true;
        });
        cells.forEach((cell, index) => {
          const proposed = applyRuleOperation(cell.value, rule, index);
          if (!Number.isFinite(proposed)) return;
          action.proposals.push(cellProposal(`goal-ghost-${rule.id || 'rule'}`, action, tableKey, table, cell, proposed, rule.reason || `Verified ghost-cam rule ${rule.id || ''}.`, 'high', action.status === 'blocked'));
        });
      }
    }
  } else if (commissioned.length) {
    let sparkIndex = 0;
    for (const { tableKey, table, mapping, cell } of commissioned) {
      let proposed = cell.value;
      if (mapping.role === 'idle-spark') { proposed = cell.value + (sparkIndex++ % 2 === 0 ? 3 : -3); }
      else if (mapping.role === 'idle-airflow') proposed = cell.value * 1.05;
      else if (mapping.role === 'idle-speed') proposed = Math.max(700, Math.min(850, cell.value + 50));
      else continue;
      action.proposals.push(cellProposal(`goal-ghost-${mapping.role}`, action, tableKey, table, cell, proposed, `Mild reversible ghost-cam profile using the commissioned ${mapping.role} cell for this exact P01 OS/XDF.`, 'high', action.status === 'blocked'));
    }
  } else {
    const candidates = [];
    const addCandidates = (patterns, role, predicate, transform, limit = 8) => {
      for (const [tableKey, table] of matchTables(workspace, patterns)) {
        for (const cell of tableCells(table).filter(predicate).slice(0, limit)) {
          candidates.push({ tableKey, table, cell, role, proposed: transform(cell.value, candidates.length) });
        }
      }
    };
    addCandidates([/idle.*spark/i,/spark.*idle/i], 'idle-spark', cell => cell.value >= -30 && cell.value <= 60, (value, index) => value + (index % 2 === 0 ? 3 : -3));
    addCandidates([/base.*running.*air/i,/idle.*airflow/i,/airflow.*idle/i], 'idle-airflow', cell => cell.value >= 0 && cell.value <= 40, value => value * 1.05);
    addCandidates([/desired.*idle.*speed/i,/idle.*rpm/i,/idle.*speed/i], 'idle-speed', cell => cell.value >= 400 && cell.value <= 1200, value => Math.max(700, Math.min(850, value + 50)), 4);
    for (const item of candidates.slice(0, 20)) action.proposals.push(cellProposal(`goal-ghost-${item.role}`, action, item.tableKey, item.table, item.cell, item.proposed, `Candidate ${item.role} cell. Confirm it once for this exact P01 OS/XDF before use.`, 'high', true));
    action.status = 'blocked';
    action.requirements.push(candidates.length ? 'Review these exact candidate cells and commission the P01 parameter map, then rebuild the request.' : `No ghost-cam candidate tables were found for ${activeProject?.controller || 'unknown controller'} / OS ${activeProject?.os || 'unknown'}.`);
    action.warnings.push('TunIQ will not apply candidate idle cells until they are commissioned for this exact XDF hash.');
  }
  if (!action.proposals.length) { action.status = 'blocked'; action.requirements.push('The ghost-cam mapping produced no exact calibration cells.'); }
  return action;
}

// A saved approval is meaningful only for the exact BIN/XDF and OS used to
// prepare it. The real workspace manager supplies these fingerprints. Legacy
// unbound in-memory test fixtures remain supported; a bound workspace must
// never accept an unbound (or differently bound) saved approval.
function goalWorkspaceBinding(workspace, activeProject = null) {
  if (workspace?.binding == null) return null;
  const source = workspace.binding;
  const hash = value => typeof value === 'string' && /^[a-f0-9]{64}$/i.test(value);
  if (!source || typeof source !== 'object' ||
      source.projectId !== workspace.projectId ||
      !hash(source.binSha256) || !hash(source.xdfSha256) ||
      typeof source.os !== 'string' || !source.os.trim() ||
      typeof source.controller !== 'string' || !source.controller.trim()) {
    throw new Error('The calibration workspace lacks an exact project/OS/BIN/XDF binding. Reload verified definitions before approval.');
  }
  const binding = {
    projectId: source.projectId,
    controller: source.controller.trim().toUpperCase(),
    os: source.os.trim(),
    binSha256: source.binSha256.toLowerCase(),
    xdfSha256: source.xdfSha256.toLowerCase()
  };
  if (activeProject && (activeProject.id !== binding.projectId ||
      String(activeProject.controller || '').trim().toUpperCase() !== binding.controller ||
      String(activeProject.os || '').trim() !== binding.os)) {
    throw new Error('The active project controller/OS differs from the bound calibration workspace. Reload the exact BIN/XDF.');
  }
  return binding;
}

function buildGoalProposal({ request, workspace, activeProject, confirmations = {}, ruleFolders = [], parameterMap = null }) {
  if (!workspace || workspace.mode !== 'xdf' || !workspace.tables) throw new Error('Load the active project BIN and XDF before executing tune requests.');
  if (!activeProject?.id || workspace.projectId !== activeProject.id) throw new Error('The calibration workspace does not match the active project.');
  const binding = goalWorkspaceBinding(workspace, activeProject);
  // Parsed objects are transport data, not authority to change calibration
  // intent. A stale/modified object could previously propose VATS or fan
  // cells that the current request text never authorized. Re-parse the text
  // and reject mismatched intents instead of trusting supplied target values.
  const suppliedParsed = typeof request === 'string' ? null : request;
  const parsed = parseTuneRequest(suppliedParsed ? suppliedParsed.text : request);
  if (suppliedParsed && (!Array.isArray(suppliedParsed.intents) ||
      JSON.stringify(suppliedParsed.intents) !== JSON.stringify(parsed.intents))) {
    throw new Error('Pre-parsed tune request intents do not match the current text; review the complete request again.');
  }
  // Reject the complete request, including otherwise valid VATS work. Never
  // let a mixed-unit fan error turn a combined request into partial approval.
  if (parsed.intents.some(intent => intent.type === 'fan-control' && intent.mixedUnits)) {
    throw new Error('The full tune request is not supported as one automatic plan: mixed Fahrenheit/Celsius fan temperatures require separate review. State both fan-on and fan-off targets in the same explicit temperature unit; no calibration proposal was created.');
  }
  if (!parsed?.recognized) throw new Error('TunIQ could not identify a supported tune action in that request. Try “disable VATS and set fans on at 210°F and off at 190°F,” “set rev limiter to 6000 RPM,” or “set speed limiter to 120 MPH.”');
  if (explicitRequestOsConflict(parsed.text, activeProject.os)) {
    throw new Error('Explicit request OS conflicts with active project OS. Verify the actual controller/BIN OS and matching definition before any proposal.');
  }
  // Recompute coverage from the text even if a caller supplies a pre-parsed object.
  // Never silently apply VATS/fan cells while ignoring a knock or physical cam request.
  const unresolved = unresolvedCalibrationRequests(parsed.text, parsed.intents);
  // A lone invalid fan-temperature request retains the legacy blocked-action
  // preview; a mixed request cannot silently apply only its VATS subset.
  const onlyInvalidFan = unresolved.length === 1 && unresolved[0].type === 'fan-control-invalid' &&
    parsed.intents.length === 1 && parsed.intents[0].type === 'fan-control';
  if (unresolved.length && !onlyInvalidFan) throw new Error(`The full tune request is not supported as one automatic plan: ${unresolved.map(item => item.requirement).join(' ')}`);
  const actions = [];
  for (const intent of parsed.intents) {
    if (intent.type === 'rev-limit') actions.push(buildRevAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'speed-limit') actions.push(buildSpeedAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'ghost-cam') actions.push(buildGhostAction(intent, workspace, activeProject, confirmations, ruleFolders, parameterMap));
    else if (intent.type === 'vats-disable') actions.push(buildVatsAction(intent, workspace, confirmations, parameterMap));
    else if (intent.type === 'fan-control') actions.push(buildFanAction(intent, workspace, confirmations, parameterMap));
  }
  const proposals = actions.flatMap(action => action.proposals || []);
  const blockedActions = actions.filter(action => action.status === 'blocked');
  return {
    id: requestId(), kind: 'goal-request', projectId: activeProject.id, projectName: activeProject.name, binding,
    requestText: parsed.text, parsed, confirmations, generatedAt: new Date().toISOString(), actions, proposals,
    blocked: proposals.length === 0 || actions.every(action => action.status === 'blocked'),
    partiallyBlocked: blockedActions.length > 0 && actions.some(action => action.status !== 'blocked'),
    summary: { actions: actions.length, readyActions: actions.filter(action => action.status !== 'blocked').length, blockedActions: blockedActions.length, proposedCells: proposals.filter(item => !item.blocked).length, approvalRequired: true, automaticFlash: false },
    warnings: [
      'Natural-language requests are converted to exact mapped parameters; unidentified tables are never guessed.',
      'Every proposed cell requires approval and creates a new revision.',
      'Applying the revision does not flash the PCM. Flash Center still requires validation and a separate typed write confirmation.'
    ]
  };
}

function applyGoalApproved(workspace, proposal, approvedIds = []) {
  if (!workspace || workspace.mode !== 'xdf') throw new Error('Load an XDF calibration workspace first.');
  if (!proposal || proposal.projectId !== workspace.projectId || proposal.kind !== 'goal-request') throw new Error('The tune-request proposal does not match this calibration workspace.');
  const currentBinding = goalWorkspaceBinding(workspace);
  if (Boolean(currentBinding) !== Boolean(proposal.binding) ||
      (currentBinding && JSON.stringify(currentBinding) !== JSON.stringify(proposal.binding))) {
    throw new Error('The approved tune request is not bound to this exact OS/BIN/XDF. Build and review a fresh proposal.');
  }
  if (!Array.isArray(approvedIds) || !Array.isArray(proposal.proposals)) throw new Error('Invalid tune-request approval list.');
  const approved = new Set(approvedIds.map(String));
  if (!approved.size) throw new Error('Approve at least one requested calibration change.');
  if (approved.size !== approvedIds.length) throw new Error('Duplicate tune-request approvals are not permitted.');

  // Approval happens later than proposal generation. Treat requestText and
  // parsed intents as untrusted transport fields: an appended physical cam,
  // removed knock sensor, or DTC-suppression request must invalidate the
  // entire previously approved VATS/fan subset. Re-parse the FULL request;
  // never silently discard newly unresolved work at apply time.
  const approvalRequest = parseTuneRequest(proposal.requestText);
  // Run297: the OS consistency check at proposal creation is not enough.
  // The saved request text and its parsed intents are editable transport
  // fields, so a conflicting/malformed OS label can be appended to BOTH
  // after generation. Recheck against the CURRENT bound workspace OS before
  // applying any cell. This is only consistency admission, never proof that
  // the OS, BIN or XDF is compatible with a physical controller.
  if (currentBinding && explicitRequestOsConflict(approvalRequest.text, currentBinding.os)) {
    throw new Error('Explicit approval request OS conflicts with the current bound workspace OS. Reload and review the exact controller/BIN/XDF before any changes.');
  }
  if (!proposal.parsed || proposal.parsed.text !== approvalRequest.text ||
      JSON.stringify(proposal.parsed.intents) !== JSON.stringify(approvalRequest.intents) ||
      approvalRequest.unresolvedRequests.length || !approvalRequest.recognized) {
    throw new Error('Full tune request changed or has unresolved safety requirements. Build and review a fresh proposal; no cells were applied.');
  }
  // IDs and action types are also editable transport data. An attacker must
  // not rename a VATS cell to a generic action to bypass its disabled-state
  // validation. This is structural admission, not cryptographic authenticity.
  const approvalIdPrefixes = {
    'vats-disable': /^goal-vats-disable:/,
    'fan-control': /^goal-fan-(?:on|off):/,
    'rev-limit': /^goal-rev(?:-restore)?:/,
    'speed-limit': /^goal-speed:/,
    'ghost-cam': /^goal-ghost-[^:]+:/
  };

  // Preflight EVERY selected cell before changing even the first value. The
  // previous loop could change VATS, then discover a stale/blocked fan cell
  // and throw, leaving the caller's workspace partly modified on failure.
  // This is an in-memory admission safeguard, not an ECU write transaction.
  const selected = [];
  const seenIds = new Set();
  const seenCells = new Set();
  for (const item of proposal.proposals) {
    if (!item || typeof item.id !== 'string' || seenIds.has(item.id)) {
      throw new Error('Invalid or duplicate tune-request proposal ID.');
    }
    seenIds.add(item.id);
    if (!approved.has(item.id)) continue;
    if (item.blocked) throw new Error(`${item.tableName} is blocked by an unmet safety requirement.`);
    if (!Number.isSafeInteger(item.row) || item.row < 0 ||
        !Number.isSafeInteger(item.col) || item.col < 0 ||
        typeof item.proposed !== 'number' || !Number.isFinite(item.proposed) ||
        typeof item.current !== 'number' || !Number.isFinite(item.current)) {
      throw new Error('Invalid or non-finite tune-request cell value.');
    }
    const cellKey = JSON.stringify([item.tableKey, item.row, item.col]);
    if (seenCells.has(cellKey)) throw new Error('Multiple approved changes target the same calibration cell.');
    seenCells.add(cellKey);
    const table = workspace.tables?.[item.tableKey];
    if (!Array.isArray(table?.values?.[item.row]) ||
        !Object.prototype.hasOwnProperty.call(table.values[item.row], item.col)) {
      throw new Error(`${item.tableName} no longer has the reviewed calibration cell.`);
    }
    // XDF decoded cells must remain finite numeric values. Number(null),
    // Number(false), Number('') and Number([]) all coerce to zero, so a
    // corrupted/missing zero-valued VATS cell previously passed the stale
    // approval check and could be overwritten as if it were reviewed data.
    const current = table.values[item.row][item.col];
    if (typeof current !== 'number' || !Number.isFinite(current) ||
        Math.abs(current - item.current) > 1e-5) {
      throw new Error(`${item.tableName} changed after the request was generated or is not a finite numeric XDF cell. Build a fresh action sheet.`);
    }
    // Approval payloads are editable transport data. A changed proposed value
    // must not bypass the currently loaded XDF's explicit engineering bounds
    // or enumeration. This is a local admission check, not authenticity proof
    // of the XDF or a substitute for exact-OS parameter commissioning.
    const bound = value => value == null || value === '' ? null :
      (typeof value === 'number' || (typeof value === 'string' && value.trim()) ? Number(value) : NaN);
    const minimum = bound(table.min), maximum = bound(table.max);
    if ((minimum != null && !Number.isFinite(minimum)) ||
        (maximum != null && !Number.isFinite(maximum)) ||
        (minimum != null && maximum != null && minimum > maximum)) {
      throw new Error(`${item.tableName} has invalid XDF calibration limits. Reload and review the definition.`);
    }
    if ((minimum != null && item.proposed < minimum) ||
        (maximum != null && item.proposed > maximum)) {
      throw new Error(`${item.tableName} proposed value exceeds the loaded XDF calibration limits.`);
    }
    if (Array.isArray(table.enumLabels) && table.enumLabels.length &&
        !table.enumLabels.some(label => label && typeof label.index === 'number' &&
          Number.isFinite(label.index) && label.index === item.proposed)) {
      throw new Error(`${item.tableName} proposed value is not an XDF enumerated state.`);
    }
    // A VATS approval must still mean the explicitly requested DISABLED state.
    // An edited proposal could previously replace 0 with 1 (both valid XDF
    // enum states) and pass the bounds/enum checks, or relabel the XDF after
    // review. Re-derive the disabled state from the CURRENT XDF instead of
    // trusting editable approval fields. A commissioned-only state that cannot
    // be re-established from the loaded definition fails closed here.
    if (/^goal-vats-disable:/.test(item.id)) {
      const vatsIntents = parseTuneRequest(proposal.requestText).intents.filter(intent => intent.type === 'vats-disable');
      if (item.actionType !== 'vats-disable' || vatsIntents.length !== 1) {
        throw new Error('VATS approval lacks an unambiguous disable request and action. Review a fresh proposal.');
      }
      // An unchanged disabled enum is not proof that the XDF still describes
      // the same theft-deterrent parameter. A delayed approval previously
      // accepted a renamed table/row/column and changed an unrelated cell.
      // Compare against the currently loaded definition before any mutation.
      // This is stale-definition admission, not cryptographic XDF provenance.
      const currentRowLabel = table.rowHeaders?.[item.row] ?? String(item.row);
      const currentColLabel = table.colHeaders?.[item.col] ?? String(item.col);
      if (typeof table.name !== 'string' || !table.name.trim() ||
          typeof item.tableName !== 'string' || table.name !== item.tableName ||
          typeof item.rowLabel !== 'string' || item.rowLabel !== currentRowLabel ||
          typeof item.colLabel !== 'string' || item.colLabel !== currentColLabel) {
        throw new Error('VATS approval XDF table or cell identity changed after review. Reload the exact OS definition and prepare a fresh proposal; no changes were applied.');
      }
      const expected = vatsTargetForCell(table, {
        value: current,
        rowLabel: table.rowHeaders?.[item.row] ?? String(item.row),
        colLabel: table.colHeaders?.[item.col] ?? String(item.col)
      });
      if (!expected || item.proposed !== expected.value) {
        throw new Error('VATS approval no longer matches the disabled state identified by the current XDF. Review a fresh proposal.');
      }
    }
    // Fan temperatures must still match the owner's reviewed request and the
    // CURRENT XDF engineering units. A transport-edited proposal within the
    // XDF min/max (or a table relabeled from F to C) previously passed and
    // could apply a different temperature. Do not infer any real fan target:
    // compare only against the explicit request's on/off values.
    if (item.actionType === 'fan-control' || /^goal-fan-(?:on|off):/.test(item.id)) {
      const role = /^goal-fan-(on|off):/.exec(item.id)?.[1];
      const intents = parseTuneRequest(proposal.requestText).intents.filter(intent => intent.type === 'fan-control');
      const unit = temperatureUnit(table);
      if (!isFanTemperatureCell(table, {
        rowLabel: table.rowHeaders?.[item.row], colLabel: table.colHeaders?.[item.col]
      })) {
        throw new Error('Fan approval points to an output-enable or non-temperature XDF cell. Review the separately verified fan-output enablement and temperature mapping.');
      }
      if (fanCellUnitConflict(table, {
        rowLabel: table.rowHeaders?.[item.row], colLabel: table.colHeaders?.[item.col]
      })) {
        throw new Error('Fan approval XDF cell temperature units contradict the table unit. Review the exact fan-temperature definition; no changes were applied.');
      }
      if (item.actionType !== 'fan-control' || !role || intents.length !== 1 || !unit) {
        throw new Error('Fan approval lacks an unambiguous request, role, or XDF temperature unit. Review a fresh proposal.');
      }
      // The ON/OFF role alone does not identify the physical fan bank.
      // For example, a delayed Fan 1 On proposal must not apply to a cell
      // subsequently relabeled Fan 2 On. Require the exact reviewed row and
      // column labels to remain present in the CURRENT XDF before approval.
      // This is stale-definition admission, not proof of a real output map.
      const currentRowLabel = table.rowHeaders?.[item.row] ?? String(item.row);
      const currentColLabel = table.colHeaders?.[item.col] ?? String(item.col);
      // Run305: the table identity is also part of the reviewed XDF cell.
      // A delayed approval previously accepted a renamed fan table whenever
      // its row/column labels, units and description still looked plausible.
      // Recheck the CURRENT table name, not just the saved row/column labels.
      // This is stale-definition admission, not XDF authenticity proof.
      if (typeof table.name !== 'string' || !table.name.trim() ||
          typeof item.tableName !== 'string' || table.name !== item.tableName ||
          typeof item.rowLabel !== 'string' || typeof item.colLabel !== 'string' ||
          currentRowLabel !== item.rowLabel || currentColLabel !== item.colLabel) {
        throw new Error('Fan approval ON/OFF role or XDF table/cell identity changed after review. Review the exact fan-bank temperature mapping; no changes were applied.');
      }
      // The saved proposal ID does not prove that the CURRENT XDF cell is
      // still an ON or OFF threshold. A row relabeled from Fan On to Fan Off
      // previously accepted the ON value and could overwrite an OFF cell.
      // Require the present row/column labels to independently identify the
      // requested role. Do not infer it from a generic table name or from
      // editable proposal metadata; an unlabeled cell needs separate review.
      const currentRole = fanRoleFromCellLabels({
        rowLabel: table.rowHeaders?.[item.row] ?? '',
        colLabel: table.colHeaders?.[item.col] ?? ''
      });
      if (currentRole !== `fan-${role}`) {
        throw new Error('Fan approval ON/OFF role no longer matches the current XDF cell labels. Review the exact fan-temperature mapping; no changes were applied.');
      }
      const intent = intents[0];
      const expected = requestedTemperature(role === 'on' ? intent.fanOn : intent.fanOff, intent.unit, unit);
      if (expected == null || Math.abs(item.proposed - round(expected, 6)) > 1e-5) {
        throw new Error('Fan approval no longer matches the reviewed on/off request or XDF temperature unit. Review a fresh proposal.');
      }
    }
    const idPattern = approvalIdPrefixes[item.actionType];
    if (!idPattern || !idPattern.test(item.id) ||
        !item.id.endsWith(`:${item.tableKey}:${item.row}:${item.col}`) ||
        !approvalRequest.intents.some(intent => intent.type === item.actionType) ||
        !Array.isArray(proposal.actions) ||
        !proposal.actions.some(action => action.id === item.actionId &&
          action.type === item.actionType && action.status === 'ready')) {
      throw new Error('Tune-request approval action identity or owner request does not match. Build and review a fresh proposal.');
    }
    selected.push({ item, table });
  }
  if (selected.length !== approved.size) throw new Error('An approved tune-request cell is missing from the proposal.');
  // All known validation failures have been checked before mutating the
  // in-memory workspace. No BIN/ECU operation is performed by this function.
  const applied = [];
  for (const { item, table } of selected) {
    table.values[item.row][item.col] = item.proposed;
    workspace.modified = workspace.modified && typeof workspace.modified === 'object' ? workspace.modified : {};
    workspace.modified[`${item.tableKey}:${item.row}:${item.col}`] = true;
    applied.push({ ...item, appliedAt: new Date().toISOString() });
  }
  workspace.updatedAt = new Date().toISOString();
  workspace.goalRequestApplied = { proposalId: proposal.id, requestText: proposal.requestText, applied, at: workspace.updatedAt };
  return { workspace, applied };
}

module.exports = { parseTuneRequest, buildGoalProposal, applyGoalApproved, loadRulePacks, matchesPack };
