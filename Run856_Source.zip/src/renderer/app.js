let state={profile:null,settings:{},tools:{},vehicles:[],projects:[],activity:[],activeProject:null,editingProjectId:null,calibration:null,calHistory:[],workspace:null,aiIntake:null,aiPlan:null,tuneLibrary:[],communityPosts:[],devices:[],device:null,liveLogs:[],logSession:null,logAnalysis:null,sensorProfiles:{},flash:null,validation:null,patchPreview:null,aiProposals:[],currentProposal:null,goalRequests:[],goalProposal:null,quickServiceReview:null,quickServiceProposal:null,quickServicePlanConfirmed:false,p01AutoRequestReview:null,p01AutoConfirmedFingerprint:null,tuneEngine:null,tuneEngineProposal:null,tuneEngineHandoff:null,autonomousTune:null,closedLoop:null,p01:null,p01Auto:null,p01Evidence:null,connectionDoctor:null,p01Lab:null,definitionCenter:null,tunerProRoundtrip:null,beta:null,updates:null,knowledge:null,incidentReplay:null,lastCompletedLog:null};let livePollTimer=null;let livePolling=false;const livePoints=[];
const $=s=>document.querySelector(s);const $$=s=>[...document.querySelectorAll(s)];
const CONTROLLER_CATALOG=[
  ['GM OBD-I / Legacy',['1227747','1228746','16168625','16197427','16196395','16188051 LT1','16214399 LT1']],
  ['GM Gen III PCM',['P01','P59','P04','P06','P08','P10','P11','P12']],
  ['GM Gas ECM',['E37','E38','E39','E39A','E40','E55','E60','E67','E69','E77','E78','E80','E82','E84','E88','E90','E92','E92A','E99']],
  ['GM Diesel ECM',['E35A','E35B','E41','E46','E54','E86','E93']],
  ['GM Transmission',['T42','T43','T76','T77','T87','T87A','T93','T93A']],
  ['GM Marine / Industrial',['MEFI-1','MEFI-2','MEFI-3','MEFI-4','MEFI-4B','MEFI-5','MEFI-6','Delphi E67 Marine']],
  ['Holley EFI',['Terminator X','Terminator X Max','Holley HP EFI','Holley Dominator EFI','Sniper EFI','Sniper 2 EFI']],
  ['FuelTech',['FT450','FT550','FT550LITE','FT600','FT700','FT700PLUS']],
  ['Haltech',['Elite 550','Elite 750','Elite 1500','Elite 2000','Elite 2500','Nexus R3','Nexus R5','Nexus VCU']],
  ['MegaSquirt',['MS1','MS2','MS3','MS3X','MS3Pro Mini','MS3Pro EVO','MS3Pro Ultimate','Gold Box']],
  ['AEM',['EMS Series 1','EMS Series 2','Infinity 506','Infinity 508','Infinity 710']],
  ['Ford',['EEC-IV','EEC-V','Spanish Oak','Black Oak','PowerPC','Copperhead','Continental EMS24xx','Bosch MG1 Ford']],
  ['Mopar',['SBEC','JTEC','JTEC+','NGC3','NGC4','GPEC2','GPEC2A','GPEC3','GPEC4','GPEC5']],
  ['Bosch / European',['ME7','MED9','MED17','EDC15','EDC16','EDC17','MG1','MD1','MSD80','MSD81','MEVD17']],
  ['Other / Custom',['Motec M1','Motec M4','Motec M8','Link G4+','Link G4X','ECUMaster EMU Black','MaxxECU Street','MaxxECU Race','Speeduino','Custom / Unknown']]
];
function populateControllerCatalog(){const list=$('#controllerOptions');if(!list)return;list.innerHTML=CONTROLLER_CATALOG.flatMap(([family,items])=>items.map(value=>`<option value="${safe(value)}" label="${safe(family)}"></option>`)).join('')}
const safe=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function uiIncidentLabel(target){const text=String(target?.getAttribute?.('aria-label')||target?.title||target?.innerText||target?.textContent||'').replace(/\s+/g,' ').trim();return text.slice(0,180)}
function recordUiIncident(action,target=null,extra={}){if(!window.tuniq?.recordIncidentUi)return;const control=target?.closest?.('button,a,input,select,textarea,[data-page],[data-jump]')||target;window.tuniq.recordIncidentUi({action,targetId:control?.id||control?.dataset?.page||control?.dataset?.jump||'',label:uiIncidentLabel(control),page:currentPage,controlType:control?.tagName?.toLowerCase?.()||'',checked:typeof control?.checked==='boolean'?control.checked:undefined,selectedIndex:Number.isInteger(control?.selectedIndex)?control.selectedIndex:undefined,...extra}).catch(()=>{})}

const PAGE_META={dashboard:{title:'Dashboard',icon:'⌂',group:'Main'},garage:{title:'Garage',icon:'▣',group:'Main'},workflow:{title:'Projects',icon:'◆',group:'Project'},files:{title:'Project Files',icon:'▤',group:'Project'},revisions:{title:'History',icon:'↺',group:'Project'},flash:{title:'Tune Center',icon:'↯',group:'Tune'},sandbox:{title:'Calibration',icon:'⌗',group:'Tune'},patches:{title:'Patches & Checksums',icon:'✚',group:'Tune'},devices:{title:'Device Manager',icon:'⌁',group:'Tune'},scanner:{title:'Live Data',icon:'◉',group:'Live'},fullai:{title:'AI Studio',icon:'✦',group:'AI'},ai:{title:'AI Coach',icon:'✦',group:'AI'},tunes:{title:'Tune Library',icon:'★',group:'Library'},community:{title:'Community',icon:'◫',group:'Library'},settings:{title:'Settings',icon:'⚙',group:'System'},bridge:{title:'Tools & Modules',icon:'⌘',group:'Tools'},diagnostics:{title:'Diagnostics',icon:'◉',group:'System'},beta:{title:'Release Center',icon:'◎',group:'System'}};
const PRIMARY_NAV_PARENT={files:'workflow',revisions:'workflow',sandbox:'flash',patches:'flash',devices:'flash',ai:'fullai',community:'tunes',diagnostics:'settings',beta:'settings'};
const CONTEXT_GROUPS={workflow:['workflow','files','revisions'],flash:['flash','sandbox','patches','devices'],fullai:['fullai','ai'],tunes:['tunes','community'],settings:['settings','diagnostics','beta']};
let appReady=false,currentPage='dashboard',navigationHistory=['dashboard'],navigationIndex=0,quickSelection=0,quickActionCache=[],uiSaveTimer=null,scrollSaveTimer=null;
function uiPreferences(){const value=state.settings?.uiPreferences;return value&&typeof value==='object'?value:{sidebarCollapsed:false,tunePathCollapsed:false,compactDensity:false,reduceMotion:false,restoreLastPage:true,lastPage:'dashboard',recentPages:['dashboard'],scrollPositions:{}}}
function saveUiPreferences(patch,immediate=false){if(!appReady||!window.tuniq?.setUiPreferences)return;const next={...uiPreferences(),...(patch||{})};state.settings.uiPreferences=next;clearTimeout(uiSaveTimer);const save=async()=>{try{state.settings=await window.tuniq.setUiPreferences(next)}catch(error){notify(`Could not save workspace preference: ${error.message}`,'error')}};if(immediate)save();else uiSaveTimer=setTimeout(save,180)}
function applyUiPreferences(){const prefs=uiPreferences();document.body.classList.toggle('sidebar-collapsed',Boolean(prefs.sidebarCollapsed));document.body.classList.toggle('density-compact',Boolean(prefs.compactDensity));document.body.classList.toggle('reduce-motion',Boolean(prefs.reduceMotion));$('#tunePathPanel')?.classList.toggle('collapsed',Boolean(prefs.tunePathCollapsed));if($('#qolRestorePage'))$('#qolRestorePage').checked=Boolean(prefs.restoreLastPage);if($('#qolCompactDensity'))$('#qolCompactDensity').checked=Boolean(prefs.compactDensity);if($('#qolReduceMotion'))$('#qolReduceMotion').checked=Boolean(prefs.reduceMotion);if($('#qolCollapseSidebar'))$('#qolCollapseSidebar').checked=Boolean(prefs.sidebarCollapsed);if($('#qolCollapseTunePath'))$('#qolCollapseTunePath').checked=Boolean(prefs.tunePathCollapsed);const toggle=$('#sidebarToggle');if(toggle){toggle.textContent=prefs.sidebarCollapsed?'☷':'☰';toggle.title=`${prefs.sidebarCollapsed?'Expand':'Collapse'} sidebar (Ctrl+B)`}}
function notify(message,type='info',timeout=4300){const stack=$('#toastStack');if(!stack||!message)return;const text=String(message).trim();if(!text)return;const title=type==='error'?'Action stopped':type==='warning'?'Attention':type==='success'?'Done':'TunIQ';const toast=document.createElement('article');toast.className=`app-toast ${type}`;toast.innerHTML=`<div><b>${safe(title)}</b><small>${safe(text.split(/\r?\n/)[0])}</small></div><button aria-label="Dismiss notification">×</button>`;toast.querySelector('button').onclick=()=>toast.remove();stack.prepend(toast);while(stack.children.length>4)stack.lastElementChild.remove();if(timeout)setTimeout(()=>toast.remove(),timeout)}
function renderSafely(section,renderer,...args){try{return renderer(...args)}catch(error){const detail=error?.stack||error?.message||String(error);console.error(`[TunIQ renderer:${section}]`,detail);if(appReady)notify(`${section} could not refresh. The rest of TunIQ is still available. ${error?.message||error}`,'warning',7000);return null}}
function updateNavigationButtons(){if($('#navBack'))$('#navBack').disabled=navigationIndex<=0;if($('#navForward'))$('#navForward').disabled=navigationIndex>=navigationHistory.length-1}
function rememberCurrentScroll(){if(!currentPage||!appReady)return;const prefs=uiPreferences(),positions={...(prefs.scrollPositions||{}),[currentPage]:Math.max(0,Math.round(window.scrollY||0))};state.settings.uiPreferences={...prefs,scrollPositions:positions};saveUiPreferences({scrollPositions:positions})}
function renderRecentWork(){const box=$('#recentWorkList');if(!box)return;const recent=(uiPreferences().recentPages||[]).filter(page=>PAGE_META[page]).slice(0,8);box.innerHTML=recent.length?recent.map(page=>{const meta=PAGE_META[page];return `<button class="recent-work-item" data-recent-page="${safe(page)}"><i>${meta.icon}</i><span><b>${safe(meta.title)}</b><small>${safe(meta.group)}</small></span></button>`}).join(''):'<p class="muted">Your recently opened workspaces will appear here.</p>';$$('[data-recent-page]').forEach(button=>button.onclick=()=>showPage(button.dataset.recentPage))}
function closeQuickSwitcher(){const overlay=$('#quickSwitcher');if(overlay)overlay.classList.add('hidden')}
function renderContextDock(page){const dock=$('#contextDock');if(!dock)return;const parent=PRIMARY_NAV_PARENT[page]||page;const pages=CONTEXT_GROUPS[parent]||[];dock.classList.toggle('hidden',pages.length<2);dock.innerHTML=pages.map(id=>{const meta=PAGE_META[id];return `<button type="button" data-context-page="${safe(id)}" class="${id===page?'active':''}"><i>${safe(meta.icon)}</i>${safe(meta.title)}</button>`}).join('');$$('[data-context-page]').forEach(button=>button.onclick=()=>showPage(button.dataset.contextPage))}
function showPage(id,options={}){if(!PAGE_META[id]||!document.getElementById(id))return false;if(currentPage&&currentPage!==id)rememberCurrentScroll();$$('.page').forEach(x=>x.classList.toggle('active',x.id===id));const primaryPage=PRIMARY_NAV_PARENT[id]||id;$$('.app-sidebar button').forEach(x=>x.classList.toggle('active',x.dataset.page===primaryPage));renderContextDock(id);currentPage=id;recordUiIncident('navigate',null,{targetId:id,label:`Open ${PAGE_META[id]?.title||id}`,page:id});if(options.record!==false){navigationHistory=navigationHistory.slice(0,navigationIndex+1);if(navigationHistory[navigationHistory.length-1]!==id)navigationHistory.push(id);if(navigationHistory.length>30)navigationHistory.shift();navigationIndex=navigationHistory.length-1}updateNavigationButtons();if(options.persist!==false){const prefs=uiPreferences(),recent=[id,...(prefs.recentPages||[]).filter(page=>page!==id)].slice(0,8);saveUiPreferences({lastPage:id,recentPages:recent});state.settings.uiPreferences={...prefs,lastPage:id,recentPages:recent};renderRecentWork()}closeQuickSwitcher();const saved=Number(uiPreferences().scrollPositions?.[id]||0);requestAnimationFrame(()=>window.scrollTo({top:options.restoreScroll===false?0:saved,behavior:'auto'}));if(id==='sandbox')ensureCalibrationInitialized().catch(showCalibrationFailure);if(['flash','patches','revisions','ai','files','fullai','devices','scanner'].includes(id))refreshWorkspace(true).catch(()=>{});if(id==='fullai')loadAiWorkspace().catch(error=>showFullAiError(error));if(id==='tunes')loadTuneLibrary().catch(error=>notify(error.message,'error'));if(id==='community')loadCommunityPosts().catch(error=>notify(error.message,'error'));if(id==='devices')loadDeviceManager().catch(error=>showDeviceMessage(error.message,true));if(id==='scanner')loadLiveWorkspace().catch(error=>showLogMessage(error.message,true));if(id==='beta')loadBetaCenter().catch(error=>showBetaMessage(error.message,true));if(id!=='scanner'&&!state.logSession)stopLivePolling();return true}
function navigateHistory(direction){const next=navigationIndex+direction;if(next<0||next>=navigationHistory.length)return;navigationIndex=next;showPage(navigationHistory[navigationIndex],{record:false});updateNavigationButtons()}
function toggleSidebar(){const collapsed=!document.body.classList.contains('sidebar-collapsed');saveUiPreferences({sidebarCollapsed:collapsed},true);state.settings.uiPreferences={...uiPreferences(),sidebarCollapsed:collapsed};applyUiPreferences()}
function renderHeaderProjectSwitcher(){const select=$('#headerProjectSwitcher');if(!select)return;select.innerHTML='<option value="">No active project</option>'+(state.projects||[]).map(project=>`<option value="${safe(project.id)}">${safe(project.name)}${project.controller?` · ${safe(project.controller)}`:''}</option>`).join('');select.value=state.activeProject?.id||''}
function quickActions(){const pages=Object.entries(PAGE_META).map(([page,meta],index)=>({id:`page:${page}`,icon:meta.icon,title:meta.title,subtitle:`${meta.group} module`,group:'Pages',keywords:`open go find module ${page}`,priority:80-index,run:()=>showPage(page)}));const projects=(state.projects||[]).map(project=>({id:`project:${project.id}`,icon:'⚙',title:project.name,subtitle:`Switch project · ${project.controller||'controller not set'}`,group:'Projects',keywords:`project vehicle ${project.vehicle||''} ${project.os||''}`,priority:95,run:()=>switchActiveProject(project.id)}));const actions=[{id:'continue',icon:'★',title:'Continue next guided step',subtitle:$('#dashNextTitle')?.textContent||'Tune Path',group:'Actions',keywords:'next resume continue p01 setup test write',priority:150,run:()=>$('#dashContinue')?.click()},{id:'all-tools',icon:'⌘',title:'Open Tools & All Modules',subtitle:'Search every TunIQ feature and integration',group:'Actions',keywords:'tools modules find everything all pages',priority:149,run:()=>showPage('bridge')},{id:'report-bug',icon:'⚑',title:'Report a bug',subtitle:'Create a privacy-safe diagnostic package with no BIN contents',group:'Beta',keywords:'feedback issue error diagnostic support beta',priority:148,run:()=>openBugReport()},{id:'doctor',icon:'✚',title:'Run Connection Doctor',subtitle:'Diagnose OBDLink, Bluetooth, COM port, baud, and voltage',group:'Actions',keywords:'obd mx com adapter connection',priority:145,run:()=>{showPage('devices');setTimeout(()=>$('#deviceDoctor')?.click(),120)}},{id:'p01-setup',icon:'↯',title:'Continue / Finish P01 Setup',subtitle:'Open the evidence-based commissioning continuation screen',group:'Tune',keywords:'p01 pcm hammer test write commission setup',priority:142,run:()=>showPage('flash')},{id:'p01-quick-service',icon:'⚡',title:'Universal P01 Request',subtitle:'Type any supported P01 change and confirm it twice',group:'Tune',keywords:'universal p01 natural language request vats fans rpm speed limiter service',priority:141,run:()=>{showPage('workflow',{restoreScroll:false});setTimeout(()=>document.querySelector('#p01QuickServicePanel')?.scrollIntoView({behavior:'smooth',block:'start'}),80)}},{id:'calibration',icon:'⌗',title:'Open Calibration',subtitle:'Edit the active BIN through its bound XDF',group:'Tune',keywords:'tunerpro xdf tables parameters edit',priority:138,run:()=>showPage('sandbox')},{id:'revisions',icon:'↺',title:'Open Revision History',subtitle:'Compare and restore project revisions',group:'Project',keywords:'history compare backup revision',priority:136,run:()=>showPage('revisions')},{id:'patches',icon:'✚',title:'Open Patches & Checksums',subtitle:'Managed Universal Patcher validation',group:'Tune',keywords:'checksum universal patcher validate',priority:134,run:()=>showPage('patches')},{id:'new-project',icon:'＋',title:'Create a new project',subtitle:'Open Tune Workflow with a clean project form',group:'Actions',keywords:'new tune vehicle',priority:130,run:()=>{showPage('workflow');$('#newProjectTop')?.click();$('#projectName')?.focus()}},{id:'add-vehicle',icon:'▣',title:'Add a Garage vehicle',subtitle:'Create a reusable vehicle profile',group:'Actions',keywords:'garage car truck vehicle',priority:125,run:()=>{showPage('garage');setTimeout(()=>$('#addVehicleBtn')?.click(),80)}},{id:'import-bin',icon:'⇧',title:'Import protected original BIN',subtitle:'Open Project Files and choose the stock read',group:'Actions',keywords:'bin original file',priority:115,run:()=>{showPage('files');setTimeout(()=>$('#importBin')?.click(),80)}},{id:'import-xdf',icon:'⇧',title:'Import matching XDF',subtitle:'Open Project Files and choose the definition',group:'Actions',keywords:'xdf definition tunerpro',priority:110,run:()=>{showPage('files');setTimeout(()=>$('#importXdf')?.click(),80)}}];return [...actions,...projects,...pages]}
function rankQuickActions(actions,query){const terms=String(query||'').toLowerCase().trim().split(/\s+/).filter(Boolean);return actions.map((action,index)=>{const hay=[action.title,action.subtitle,action.group,action.keywords].join(' ').toLowerCase();if(terms.some(term=>!hay.includes(term)))return null;let score=Number(action.priority||0)-index;for(const term of terms)score+=String(action.title).toLowerCase().startsWith(term)?120:String(action.title).toLowerCase().includes(term)?70:25;return {action,score,index}}).filter(Boolean).sort((a,b)=>b.score-a.score||a.index-b.index).slice(0,16).map(item=>item.action)}
function renderQuickSwitcher(){const input=$('#quickSwitcherInput'),box=$('#quickSwitcherResults');if(!input||!box)return;quickActionCache=rankQuickActions(quickActions(),input.value);if(quickSelection>=quickActionCache.length)quickSelection=0;box.innerHTML=quickActionCache.length?quickActionCache.map((action,index)=>`<button class="quick-action ${index===quickSelection?'selected':''}" data-quick-index="${index}"><i>${safe(action.icon||'•')}</i><span><b>${safe(action.title)}</b><small>${safe(action.subtitle||'')}</small></span><em>${safe(action.group||'')}</em></button>`).join(''):'<div class="quick-empty">No matching TunIQ page, project, or action.</div>';$$('[data-quick-index]').forEach(button=>{button.onmouseenter=()=>{quickSelection=Number(button.dataset.quickIndex);$$('[data-quick-index]').forEach(item=>item.classList.toggle('selected',Number(item.dataset.quickIndex)===quickSelection))};button.onclick=()=>runQuickAction(Number(button.dataset.quickIndex))});box.querySelector('.selected')?.scrollIntoView({block:'nearest'})}
function runQuickAction(index=quickSelection){const action=quickActionCache[index];if(!action)return;closeQuickSwitcher();Promise.resolve(action.run()).catch(error=>notify(error.message,'error'))}
function openQuickSwitcher(query=''){const overlay=$('#quickSwitcher'),input=$('#quickSwitcherInput');if(!overlay||!input)return;overlay.classList.remove('hidden');input.value=query;quickSelection=0;renderQuickSwitcher();setTimeout(()=>input.focus(),0)}
function modeName(v){return v==='full-ai'?'Full AI':v==='manual'?'Manual':'Guided'}
function detailName(v){return v==='advanced'?'Advanced':'Beginner'}
function supportLabel(status){return status==='verified'?'Verified':status==='experimental'?'Experimental':'Unsupported'}
function supportClass(status){return status==='verified'?'verified':status==='experimental'?'experimental':'unsupported'}
function updateHeader(){const m=state.settings.aiMode||'guided',detail=state.settings.detailLevel||'beginner';$('#modeBtn').textContent=modeName(m).toUpperCase();$('#modeSelect').value=m;if($('#detailSelect'))$('#detailSelect').value=detail;if($('#detailBadge'))$('#detailBadge').textContent=`${detailName(detail).toUpperCase()} VIEW`;$('#settingsProfile').textContent=state.profile?`${state.profile.name} — ${state.profile.email}`:'No profile configured';document.body.classList.remove('mode-guided','mode-manual','mode-full-ai','detail-beginner','detail-advanced');document.body.classList.add(`mode-${m}`,`detail-${detail}`);applyUiPreferences();updateModeDescription();updateDetailDescription();updateActiveProject();renderTunePath();renderRecentWork();}
function updateModeDescription(){const m=$('#modeSelect').value;$('#modeDescription').textContent={guided:'Guided mode explains each step, shows safety checks, and recommends the next action.',manual:'Manual mode keeps prompts minimal and leaves workflow choices to you.','full-ai':'Full AI mode collects the complete build, creates a project-specific diagnostic and tuning plan, and executes only changes you approve. Controller writing always requires confirmation.'}[m]||''}
function updateDetailDescription(){const el=$('#detailDescription');if(!el)return;const d=$('#detailSelect')?.value||state.settings.detailLevel||'beginner';el.textContent=d==='advanced'?'Shows backend commands, raw validation data, checksum tools, enhanced PID setup, and expert controls.':'Recommended. Uses plain language, hides expert-only controls, and keeps the next safe action visible.'}
function updateActiveProject(){const text=state.activeProject?`Active project: ${state.activeProject.name}`:'No active project selected';$('#activeProjectBridge').textContent=text;$('#activeProjectCard').innerHTML=state.activeProject?`<b>● ACTIVE: ${safe(state.activeProject.name)}</b><small>${safe(state.activeProject.vehicle||'No vehicle')} • ${safe(state.activeProject.controller||'Unknown controller')}${state.activeProject.os?` • OS ${safe(state.activeProject.os)}`:''}</small>${state.activeProject.notes?`<p>${safe(state.activeProject.notes)}</p>`:''}<button id="editActiveProject" class="ghost">Edit Active Project</button>`:'No active project';const edit=$('#editActiveProject');if(edit)edit.onclick=()=>beginProjectEdit(state.activeProject);renderHeaderProjectSwitcher();renderWorkspaceStrip();}
const MODULE_DESCRIPTIONS={dashboard:'Project status and the next guided action',garage:'Vehicle profiles, modifications, and maintenance',workflow:'Create and manage tune projects',files:'Protected original BIN and XDF files',revisions:'Compare, restore, and track revisions',flash:'P01 commissioning, Test Write, and controlled flashing',sandbox:'Native calibration tables and XDF editing',patches:'Checksums, patches, and Universal Patcher validation',devices:'OBDLink, COM ports, and Connection Doctor',scanner:'Live gauges, logging, and log analysis',fullai:'Project-aware tuning plans and automation',ai:'Ask questions about the active project',tunes:'Saved tune packages and favorites',community:'Local help posts, guides, and builds',bridge:'Every module plus backend integration setup',diagnostics:'Desktop health and diagnostic export',beta:'Beta agreement, compatibility, feedback, and updates',settings:'Interface, data, and assistance preferences'};
function renderAllModules(query=''){const grid=$('#allModulesGrid'),count=$('#moduleCount');if(!grid)return;const terms=String(query||'').toLowerCase().trim().split(/\s+/).filter(Boolean);const entries=Object.entries(PAGE_META).filter(([id,meta])=>{const hay=`${id} ${meta.title} ${meta.group} ${MODULE_DESCRIPTIONS[id]||''}`.toLowerCase();return terms.every(term=>hay.includes(term))});if(count)count.textContent=`${entries.length} module${entries.length===1?'':'s'}`;grid.innerHTML=entries.map(([id,meta])=>`<button type="button" class="module-card" data-module-page="${safe(id)}"><i>${safe(meta.icon)}</i><span><b>${safe(meta.title)}</b><small>${safe(MODULE_DESCRIPTIONS[id]||meta.group)}</small></span><em>${safe(meta.group)}</em></button>`).join('')||'<div class="quick-empty">No matching module. Try a broader search or press Ctrl+K.</div>';$$('[data-module-page]').forEach(button=>button.onclick=()=>showPage(button.dataset.modulePage))}
async function openBugReport(){
  try{state.incidentReplay=await window.tuniq.captureIncidentReplay({currentPage,reason:'report-bug-button',windowMs:Number(state.beta?.preferences?.incidentReplaySeconds||60)*1000})}catch{state.incidentReplay=null}
  showPage('beta');
  setTimeout(()=>{const field=$('#betaReportDescription');field?.scrollIntoView({behavior:'smooth',block:'center'});const status=$('#betaReplayStatus');if(status){const summary=state.incidentReplay?.summary;status.textContent=summary?`Captured the last ${summary.capturedSeconds} seconds: ${summary.eventCount} events${summary.stopCode?` • ${summary.stopCode}`:''}. Description is optional.`:'Replay capture was unavailable; normal diagnostics are still included.'}},100)
}
const toolsMeta={pcmHammer:{name:'PCM Hammer',icon:'🔨',desc:'Backend connection for controller identification, reads, and future controlled writes',url:'https://github.com/PcmHammer/PcmHammer/releases',page:'flash',openLabel:'Open TunIQ Flash'},tunerPro:{name:'TunerPro / XDF',icon:'📊',desc:'XDF-compatible definitions and calibration editing inside TunIQ',url:'https://www.tunerpro.net/downloadApp.htm',page:'sandbox',openLabel:'Open TunIQ Calibration'},universalPatcher:{name:'Universal Patcher',icon:'🧩',desc:'Checksum and patch analysis routed through TunIQ Patches',url:'https://universalpatcher.net/download/',page:'patches',openLabel:'Open TunIQ Patches'}};
function renderTools(){
  renderAllModules($('#moduleSearch')?.value||'');
  const container=$('#toolCards');
  container.innerHTML='';
  for(const key of Object.keys(toolsMeta)){
    const meta=toolsMeta[key],toolPath=typeof state.tools[key]==='string'&&state.tools[key].trim()?state.tools[key]:null;
    const card=document.createElement('article');
    card.className=`tool-card ${toolPath?'found':''}`;
    card.innerHTML=`<div class="tool-icon">${meta.icon}</div><h3>${meta.name}</h3><div class="tool-status ${toolPath?'ok':'bad'}">${toolPath?'● ADAPTER READY':'○ ADAPTER NOT FOUND'}</div><p>${meta.desc}</p><div class="tool-path">${safe(toolPath||'No valid executable path detected')}</div><div class="tool-actions"><button class="download" data-download="${key}">⇩ Download</button><button class="ghost" data-browse="${key}">Browse</button><button class="ghost" data-verify="${key}">Verify</button><button class="launch native-open" data-open-native="${key}">${meta.openLabel}</button></div><small class="native-route-note">Stays inside the TunIQ window.</small>`;
    container.appendChild(card);
  }
  $$('[data-download]').forEach(button=>button.onclick=async()=>{
    try{await window.tuniq.openExternal(toolsMeta[button.dataset.download].url)}catch(error){status(error.message,true)}
  });
  $$('[data-browse]').forEach(button=>button.onclick=async()=>{
    try{
      const selected=await window.tuniq.chooseTool(button.dataset.browse);
      if(selected){state.tools[button.dataset.browse]=selected;renderTools();await refreshWorkspace(true);status(`${toolsMeta[button.dataset.browse].name} verified and configured.`)}
    }catch(error){status(error.message,true)}
  });
  $$('[data-verify]').forEach(button=>button.onclick=async()=>{
    const key=button.dataset.verify;
    try{
      const result=await window.tuniq.verifyTool(key);
      state.tools[key]=result.path;
      renderTools();
      await refreshWorkspace(true);
      status(result.valid?`${toolsMeta[key].name} path verified.`:`${toolsMeta[key].name} was not found at the saved path. Use Scan or Browse.`,!result.valid);
    }catch(error){status(error.message,true)}
  });
  $$('[data-open-native]').forEach(button=>button.onclick=()=>{
    const key=button.dataset.openNative;
    const meta=toolsMeta[key];
    showPage(meta.page);
    status(`${meta.name} routed to ${meta.openLabel.replace('Open ','')}. No external application window was opened.`);
  });
}
function status(t,bad=false){const target=$('#bridgeStatus');if(target){target.textContent=t;target.className=bad?'bad':''}if(appReady)notify(t,bad?'error':'success')}

function formatBytes(value){const n=Number(value)||0;if(n<1024)return `${n} B`;if(n<1024*1024)return `${(n/1024).toFixed(1)} KB`;return `${(n/1024/1024).toFixed(1)} MB`}
function renderWorkspaceStrip(){
  const active=state.workspace?.activeProject||state.activeProject;
  $('#workspaceProject').textContent=active?.name||'No project selected';
  $('#workspaceController').textContent=active?.controller?`${active.controller}${active.os?` / OS ${active.os}`:' / OS auto-detect'}`:'Not configured';
  const files=state.workspace?.files||{};
  const recoveredBin=active?.binInfo?.name||files.bin?.name||files.original?.name||state.p01?.canonicalRead?.name||state.p01?.read1?.name||'';
  const recoveredXdf=active?.xdfInfo?.name||files.xdf?.name||state.p01?.definition?.name||state.p01Auto?.definition?.name||'';
  $('#workspaceBin').textContent=recoveredBin||'Not loaded';
  $('#workspaceXdf').textContent=recoveredXdf||'Not loaded';
  const support=state.beta?.support?.flashing;const supportEl=$('#workspaceSupport');if(supportEl){supportEl.textContent=support?supportLabel(support.status):'Not evaluated';supportEl.className=support?`support-${supportClass(support.status)}`:'';}
}
function compactTunePathSteps(steps){
  if(!steps.length)return [];
  let currentIndex=steps.findIndex(step=>step.status==='current');
  if(currentIndex<0){
    const firstIncomplete=steps.findIndex(step=>step.status!=='complete');
    currentIndex=firstIncomplete>=0?firstIncomplete:steps.length-1;
  }
  const previous=[...steps.slice(0,currentIndex)].reverse().find(step=>step.status==='complete')||{id:'desktop-ready',title:'TunIQ workspace ready',description:'Desktop core and project storage are online',page:'dashboard',target:'#dashboard',status:'complete',synthetic:true};
  const current={...steps[currentIndex],status:'current'};
  const nextSource=steps.slice(currentIndex+1).find(step=>step.status!=='complete')||steps[Math.min(steps.length-1,currentIndex+1)];
  const next=nextSource&&nextSource.id!==current.id?{...nextSource,status:'locked'}:{id:'safety-lock',title:'Verify the result and record a follow-up log',description:'After a confirmed flash, re-identify the controller and record the same test conditions',page:'flash',target:'#flashWriteCalibration',status:'locked',synthetic:true};
  return [previous,current,next];
}
function renderDashboard(){
  const workspace=state.workspace||{},active=workspace.activeProject||state.activeProject;
  const current=workspace.tunePath?.steps?.find(step=>step.status==='current')||workspace.tunePath?.steps?.find(step=>step.status!=='complete');
  $('#dashProjectTitle').textContent=active?.name||'No active project';
  $('#dashProjectSummary').textContent=active?`${active.vehicle||'Unassigned vehicle'} · ${active.controller||'Controller pending'}${active.os?` · OS ${active.os}`:' · OS will auto-detect'}`:'Create or activate a tune project to begin.';
  $('#dashVehicle').textContent=active?.vehicle||'Not assigned';
  $('#dashController').textContent=active?.controller?`${active.controller}${active.os?` / OS ${active.os}`:' / OS auto-detect'}`:'Not selected';
  const hasBin=Boolean(active?.binInfo),hasXdf=Boolean(active?.xdfInfo&&!active.xdfInfo.error);
  $('#dashFiles').textContent=hasBin&&hasXdf?'BIN + XDF ready':hasBin?'BIN ready · XDF needed':hasXdf?'XDF ready · BIN needed':'BIN and XDF not loaded';
  $('#dashReadiness').textContent=active?`${workspace.tunePath?.progress||0}% complete`:'Waiting for project';
  $('#dashNextTitle').textContent=current?.title||'Review the active workspace';
  $('#dashNextDescription').textContent=current?.description||'TunIQ will keep your next required action here.';
  const continueButton=$('#dashContinue');
  continueButton.onclick=()=>current?goToTuneStep(current):showPage('workflow');
}
function renderTunePath(){
  const panel=$('#tunePathPanel'),steps=state.workspace?.tunePath?.steps||[];
  if(!panel)return;
  const compact=compactTunePathSteps(steps);
  const current=steps.find(step=>step.status==='current');
  const currentIndex=current?steps.findIndex(step=>step.id===current.id):-1;
  $('#tunePathProgress').textContent=currentIndex>=0?`${currentIndex+1} / ${steps.length}`:`${state.workspace?.tunePath?.progress||0}%`;
  $('#tunePathSummary').textContent=current?`Current: ${current.title}`:steps.length?'Required setup complete. Review validation and flash preparation.':'Create or activate a project to begin.';
  $('#tunePathSteps').innerHTML=compact.length?compact.map(step=>`<button class="tune-step ${step.status}" ${step.status==='locked'?'disabled':''} data-tune-step="${safe(step.id)}"><span class="step-star">${step.status==='complete'?'✓':step.status==='locked'?'🔒':'★'}</span><span><strong>${safe(step.title)}</strong><small>${safe(step.description)}</small></span><em>${step.status==='current'?'DO NOW':step.status.toUpperCase()}</em></button>`).join(''):'<p class="muted">Workspace steps are loading…</p>';
  $$('[data-tune-step]').forEach(button=>button.onclick=()=>{const step=compact.find(item=>item.id===button.dataset.tuneStep);if(step&&step.status!=='locked')goToTuneStep(step)});
  $$('[data-guide-nav]').forEach(button=>button.classList.toggle('guide-current',button.dataset.guideNav===current?.id||((current?.id==='original'||current?.id==='definition')&&button.dataset.page==='files')));
  renderDashboard();
}
function goToTuneStep(step){showPage(step.page);setTimeout(()=>{const target=document.querySelector(step.target);if(target){target.scrollIntoView({behavior:'smooth',block:'center'});target.classList.remove('guided-target');void target.offsetWidth;target.classList.add('guided-target');setTimeout(()=>target.classList.remove('guided-target'),2400)}},180)}
function populateRevisionSelects(){
  const revisions=state.workspace?.files?.revisions||[];
  const options='<option value="">'+(revisions.length?'Select latest or choose a revision':'No revisions exported')+'</option>'+revisions.map(file=>`<option value="${safe(file.path)}">${safe(file.name)}</option>`).join('');
  for(const id of ['#flashRevision','#patchRevision']){const select=$(id);if(!select)continue;const previous=select.value;select.innerHTML=options;if(revisions.some(file=>file.path===previous))select.value=previous;else if(revisions[0])select.value=revisions[0].path;}
}
function flashCapabilityName(key){return {readProperties:'Read Properties',read:'Read',testWrite:'Test Write',writeCalibration:'Write Calibration',writeFull:'Write Full',recovery:'Recovery'}[key]||key}
function renderP01Commissioning(){
  const panel=$('#p01CommissionPanel'),p01=state.p01;
  if(!panel)return;
  panel.classList.toggle('hidden',!p01?.applicable);
  if(!p01?.applicable)return;
  const badge=$('#p01CommissionBadge');
  badge.className=p01.readyForWrite?'ready':p01.readMismatch?'blocked':'';
  badge.textContent=p01.readyForWrite?'WRITE PROOF COMPLETE':p01.readyForAi?'AI READY · WRITE NOT PROVEN':p01.readMismatch?'READS DO NOT MATCH':'COMMISSIONING REQUIRED';
  const blockers=p01.readyForAi?[]:(p01.aiBlockers||p01.blockers||[]);
  $('#p01CommissionSummary').innerHTML=p01.readyForWrite?`<b>This exact P01 and revision passed every commissioning gate.</b><br>OS ${safe(p01.identity?.os||'unknown')} · Service ${safe(p01.identity?.serviceNumber||'unknown')} · protected original ${safe((p01.canonicalReadSha256||'').slice(0,16))}… · Test Write verified.`:p01.readyForAi?`<b>Full AI is unlocked for this exact P01 read and confirmed OS-bound XDF.</b><br>${p01.parameterMap?'Requested parameters are commissioned.':'Build an action sheet, confirm its exact P01 parameters, then rebuild it.'} Validate the revision and pass Test Write before Calibration Write.`:`<b>TunIQ will not tune or write this P01 yet.</b><br>${blockers.map(item=>safe(item)).join('<br>')}`;
  $('#p01CommissionSteps').innerHTML=(p01.steps||[]).map((step,index)=>`<article class="p01-step ${step.complete?'complete':''} ${step.error?'error':''}"><i>${step.complete?'✓':step.error?'!':index+1}</i><div><b>${safe(step.title)}</b><small>${safe(step.detail||'Waiting')}</small></div></article>`).join('');
}

function p01AutoHasDurableEvidence(){return Boolean(state.p01?.identity?.os||state.p01?.dualReadVerified||state.p01Auto?.id||(state.p01Auto?.status&&state.p01Auto.status!=='idle'))}
function p01AutoRequestChanged(){const typed=($('#p01AutoRequest')?.value||'').trim().replace(/\s+/g,' '),saved=String(state.p01Auto?.request||'').trim().replace(/\s+/g,' ');return Boolean(saved&&typed&&typed!==saved)||Boolean(!saved&&typed&&p01AutoHasDurableEvidence())}
const P01_NO_WRITE_NOTICE='Guided setup may run Test Write, but it will not perform an actual PCM write.';
function p01AutoPayload(){const review=state.p01AutoRequestReview;return {request:review?.requestText||$('#p01AutoRequest')?.value.trim()||state.p01Auto?.request||'',confirmations:review?.confirmations||state.p01Auto?.confirmations||{},requestFingerprint:review?.requestFingerprint||state.p01Auto?.requestFingerprint||null,safetyFacts:$('#p01AutoSafetyFacts')?.value.trim()||'',device:$('#flashInterface')?.value.trim()||'',voltage:$('#flashVoltage')?.value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:Boolean($('#flashBenchPower')?.checked),exactXdfAuthorization:true,autoMapAuthorized:true,autoRevisionAuthorized:true,testWriteAuthorized:true}}
function invalidateP01AutoRequestReview(){state.p01AutoRequestReview=null;state.p01AutoConfirmedFingerprint=null;renderP01AutoRequestReview()}
function renderP01AutoRequestReview(){const box=$('#p01AutoRequestReview'),analyze=$('#p01AutoAnalyze'),confirmButton=$('#p01AutoConfirmRequest'),start=$('#p01AutoStart');if(!box||!confirmButton||!start)return;const review=state.p01AutoRequestReview,existing=p01AutoHasDurableEvidence(),requestChanged=p01AutoRequestChanged(),phase=state.p01Auto?.phase||'idle',sessionLocked=state.p01Auto?.status==='running'||['ready-to-write','commissioning-complete','write-complete'].includes(phase);if(!review){box.innerHTML=existing&&!requestChanged?'<b>Existing P01 evidence and saved request detected.</b><br>Continue resumes the exact incomplete step without repeating completed work.':existing?'<b>The request was changed.</b><br>Analyze and confirm the new request before TunIQ changes the saved P01 plan.':'Type the complete request, then analyze it. TunIQ automatically enforces exact-XDF binding, protected revisions, strict mapping, and Test Write separation.';confirmButton.disabled=true;start.disabled=sessionLocked||!existing||requestChanged;return}const actions=(review.parsed?.intents||[]).map(item=>item.label||item.type);const missing=review.missingSafetyFacts||[];box.innerHTML=`<b>${safe(review.projectName)}${review.os?` · OS ${safe(review.os)}`:''}</b><br>${actions.map(item=>`• ${safe(item)}`).join('<br>')}${missing.length?`<br><br><b>Unresolved requested changes / missing safety facts:</b><br>${missing.map(item=>`• ${safe(item)}`).join('<br>')}`:'<br><br><b>Request and required safety facts are complete.</b>'}`;confirmButton.disabled=sessionLocked||!review.ready;confirmButton.textContent=state.p01AutoConfirmedFingerprint===review.requestFingerprint?'✓ Request Plan Confirmed':'Confirm Request Plan';start.disabled=sessionLocked||(!existing&&state.p01AutoConfirmedFingerprint!==review.requestFingerprint);if(analyze){analyze.textContent='Analyze Again';analyze.disabled=sessionLocked}}
async function analyzeP01AutoRequest(){const request=$('#p01AutoRequest')?.value.trim()||'',safetyFacts=$('#p01AutoSafetyFacts')?.value.trim()||'';if(!request)return notify('Type the P01 request first.','warning');const button=$('#p01AutoAnalyze');button.disabled=true;try{state.p01AutoRequestReview=await window.tuniq.reviewP01Request({request,safetyFacts});state.p01AutoConfirmedFingerprint=null;renderP01AutoRequestReview();notify(state.p01AutoRequestReview.ready?'Request understood. Review it, then confirm the plan.':'Request reviewed, but some changes or safety requirements are unresolved.','success',6500)}catch(error){state.p01AutoRequestReview=null;state.p01AutoConfirmedFingerprint=null;renderP01AutoRequestReview();notify(error.message,'error',8000)}finally{button.disabled=false}}
function confirmP01AutoRequest(){const review=state.p01AutoRequestReview;if(!review?.ready)return notify('Analyze the request and provide every required safety fact first.','warning');state.p01AutoConfirmedFingerprint=review.requestFingerprint;renderP01AutoRequestReview();notify('Confirmation 1 of 2 complete. Press Continue / Finish P01 Setup for confirmation 2.','success',6500)}
function p01AutoPhaseLabel(phase){if(/^stopped-/.test(String(phase||'')))return `Stopped: ${String(phase).replace(/^stopped-/,'').replace(/-/g,' ')}`;return ({idle:'Waiting to start',preflight:'Checking PCM Hammer, power, and permissions','read-properties':'Preparing Read Properties','waiting-read-properties':'Reading P01 properties','assisted-readProperties':'Migrating old Read Properties step to integrated runner','read-1':'Preparing full read 1 of 2','waiting-read-1':'Running full read 1 of 2','read-2':'Preparing full read 2 of 2','waiting-read-2':'Running full read 2 of 2','assisted-read':'Migrating old full-read step to integrated runner',definition:'Finding and binding the exact OS XDF','goal-map':'Mapping requested calibration cells','create-revision':'Creating protected AI revision','test-write':'Preparing Test Write','waiting-test-write':'Running PCM Hammer Test Write','assisted-testWrite':'Migrating old Test Write step to integrated runner','stopped-recovered':'COM state cleared — ready to resume','ready-to-write':'Guided setup complete','commissioning-complete':'P01 hardware setup complete','waiting-write':'Writing calibration — do not disconnect','write-complete':'Calibration write complete',failed:'Guided setup stopped on an error',cancelled:'Setup cancelled — evidence preserved','resume-ready':'Ready to resume saved P01 step'})[phase]||String(phase||'Waiting').replace(/-/g,' ')}
function latestP01TechnicalDetails(auto=state.p01Auto){const history=auto?.flash?.history||state.flash?.history||[];const projectId=auto?.activeProject?.id||state.activeProject?.id||'';return history.find(item=>(!projectId||item.projectId===projectId)&&item.technicalDetails)?.technicalDetails||null}
async function copyP01TechnicalDetails(){const details=latestP01TechnicalDetails();if(!details)return notify('No PCM Hammer technical details are available yet.','warning');const text=JSON.stringify(details,null,2);try{await navigator.clipboard.writeText(text);notify('PCM Hammer technical details copied.','success',5000)}catch{prompt('Copy PCM Hammer technical details:',text)}}
function hardwareDoctorAttemptClass(attempt){return attempt?.verified||attempt?.communicationStarted&&Number(attempt.exitCode)===0?'complete':'failed'}
function renderHardwareSessionDoctor(report=state.p01Auto?.sessionDoctor){
  const panel=$('#p01HardwareDoctor');if(!panel)return;
  const meaningful=Boolean(report&&(report.session?.id||report.workflow?.stopCode||report.diagnosis?.severity==='ready'||report.session?.attempts?.length));
  panel.classList.toggle('hidden',!meaningful);if(!meaningful)return;
  const diagnosis=report.diagnosis||{},session=report.session||{},evidence=report.evidence||{},guard=report.exclusiveSessionGuard||null,snapshot=report.safetySnapshot||null,attempts=Array.isArray(session.attempts)?session.attempts:[];
  panel.classList.toggle('blocked',diagnosis.severity==='blocked');panel.classList.toggle('ready',diagnosis.severity==='ready');
  $('#p01HardwareDoctorTitle').textContent=diagnosis.title||'Hardware session diagnosis';
  const badge=$('#p01HardwareDoctorBadge');badge.textContent=diagnosis.severity==='ready'?'PASSED':diagnosis.category?String(diagnosis.category).toUpperCase():'REVIEW';
  $('#p01HardwareDoctorSummary').textContent=diagnosis.summary||'TunIQ preserved the project and recorded the exact hardware-session boundary.';
  const noWrite=diagnosis.noActualPcmWriteOccurred!==false;
  $('#p01HardwareDoctorFacts').innerHTML=[
    ['EVIDENCE',evidence.dualReadVerified?'Verified read pair protected':'Commissioning evidence incomplete'],
    ['PCM COMMUNICATION',session.communicationStarted?'Started':'Did not start'],
    ['RECOMMENDED PORT',diagnosis.recommendedPort||session.device||'Rescan on retry'],
    ['SESSION GUARD',guard?(guard.blocked?'Blocked conflict':'Clear'):'Not recorded'],
    ['SAFETY SNAPSHOT',snapshot?.verified?(snapshot.reused?'Verified · reused':'Verified before session'):'Not recorded'],
    ['PCM WRITE',noWrite?'No actual write occurred':'Write-related operation detected']
  ].map(([label,value])=>`<span><small>${safe(label)}</small><b>${safe(value)}</b></span>`).join('');
  $('#p01HardwareDoctorAttempts').innerHTML=attempts.length?attempts.map(attempt=>`<article class="hardware-attempt ${hardwareDoctorAttemptClass(attempt)}"><i>${attempt.verified?'✓':attempt.communicationStarted?'↯':'×'}</i><b>${safe(attempt.port||'Automatic')}</b><span>${safe(attempt.outcome||'Attempt stopped')}${attempt.adapter?` · ${safe(attempt.adapter)}`:''}</span><em>${attempt.verified?'Identity verified':attempt.exitCode==null?'No PCM Hammer launch':`Exit ${safe(attempt.exitCode)}`}</em></article>`).join(''):'<p class="muted">No adapter-verification or PCM Hammer attempt is available yet.</p>';
  const actions=Array.isArray(diagnosis.actions)?diagnosis.actions:[];
  $('#p01HardwareDoctorActions').innerHTML=`<b>${diagnosis.safeToRetryFailedStep?'Next safe action':'Session result'}</b>${actions.length?`<ul>${actions.map(item=>`<li>${safe(item)}</li>`).join('')}</ul>`:'<span class="muted">Refresh the diagnosis after the next hardware attempt.</span>'}`;
  $('#p01HardwareDoctorOpenLog').disabled=!Boolean(session.sessionLog||attempts.some(item=>item.stdoutLog||item.stderrLog));
  if($('#p01HardwareDoctorOpenSnapshot'))$('#p01HardwareDoctorOpenSnapshot').disabled=!Boolean(snapshot?.path);
}
async function refreshHardwareSessionDoctor(){try{const result=await window.tuniq.refreshHardwareSessionDoctor();const report=result?.report||result;if(state.p01Auto)state.p01Auto.sessionDoctor=report;renderHardwareSessionDoctor(report);notify('Hardware Session Doctor refreshed.','success',4000)}catch(error){notify(error.message,'error',8000)}}
async function exportHardwareSessionReport(){try{const result=await window.tuniq.exportHardwareSessionReport();if(result?.file)notify(`Hardware report saved: ${result.file}`,'success',7000)}catch(error){notify(error.message,'error',8000)}}
async function openHardwareSessionLog(){try{await window.tuniq.openHardwareSessionLog()}catch(error){notify(error.message,'error',8000)}}
async function openHardwareSessionReports(){try{await window.tuniq.openHardwareSessionReports()}catch(error){notify(error.message,'error',8000)}}
async function openHardwareSessionSnapshot(){try{await window.tuniq.openHardwareSessionSnapshot()}catch(error){notify(error.message,'error',8000)}}
function renderP01Auto(auto=state.p01Auto){
  const box=$('#p01AutoBadge');if(!box)return;
  auto=auto||{status:'idle',phase:'idle',progress:0,messages:[]};state.p01Auto=auto;
  if(auto.p01){state.p01=auto.p01;if(state.workspace)state.workspace.p01=auto.p01}
  const phase=auto.phase||'idle',progress=Math.max(0,Math.min(100,Number(auto.progress)||0));
  const livePhase=String(auto.liveOperationPhase||'').trim();
  const displayPhase=livePhase||p01AutoPhaseLabel(phase);
  const running=auto.status==='running',resumeReady=auto.status==='resume-ready',ready=phase==='ready-to-write',commissioned=phase==='commissioning-complete',written=phase==='write-complete',done=written||commissioned;
  const blocked=auto.status==='paused'||['failed','cancelled'].includes(auto.status)||/^stopped-/.test(phase);
  const stopped=blocked&&!running&&!resumeReady&&!done;const displayProgress=done?100:stopped?Math.min(progress,92):progress;
  const canResume=Boolean(auto.canResume||(blocked&&!ready&&!done&&phase!=='idle'));
  const stopCode=auto.stop?.code||auto.portRecovery?.code||'';
  const port=auto.portRecovery?.device||auto.stopDetails?.device||auto.device||'';
  const attempts=auto.portRecovery?.attempts||auto.stopDetails?.attempts||[];
  box.textContent=commissioned?'SETUP COMPLETE':written?'WRITE COMPLETE':ready?'READY TO WRITE':running?'RUNNING':resumeReady?'READY TO RESUME':blocked?'PAUSED':'IDLE';
  box.className=ready||done||resumeReady?'ready':blocked?'blocked':'';
  $('#p01AutoPhase').textContent=displayPhase;$('#p01AutoPercent').textContent=stopped?'STOPPED':`${Math.round(displayProgress)}%`;$('#p01AutoProgressBar').style.width=`${displayProgress}%`;$('#p01AutoProgressBar')?.closest?.('.p01-auto-progress')?.classList.toggle('stopped',stopped);
  const revision=auto.revision?.name||auto.revision?.path?.split(/[\\/]/).pop()||'';
  const blocker=auto.blocker?`<br><b>Stopped:</b> ${safe(auto.blocker)}`:'';
  const recoveryCandidates=auto.portRecovery?.candidates||auto.stopDetails?.candidates||[];
  const recovery=stopCode?`<br><b>Recovery code:</b> ${safe(stopCode)}${port?` · last port ${safe(port)}`:''}${attempts.length?` · tested ${safe(attempts.map(item=>item.port).filter(Boolean).join(', '))}`:''}${recoveryCandidates.length?` · candidates ${safe(recoveryCandidates.map(item=>item.port).filter(Boolean).join(', '))}`:''}`:'';
  const recoveredAtFinalStep=Boolean(state.p01?.dualReadVerified&&!done&&(auto.revision?.path||progress>=48));
  const continuityStatus=recoveredAtFinalStep?'<b>Verified reads recovered — continuing at Test Write.</b><br>':'';
  const heartbeat=auto.liveOperationHeartbeat;const heartbeatText=heartbeat?`<br>Process: ${heartbeat.processAlive?'running':'stopped'} · elapsed ${Number(heartbeat.elapsedSeconds||0)}s · read file ${formatBytes(Number(heartbeat.outputBytes||0))}${heartbeat.quietSeconds?` · ${Number(heartbeat.quietSeconds)}s since update`:''}`:'';
  $('#p01AutoSummary').innerHTML=`${continuityStatus}<b>${safe(displayPhase)}</b>${heartbeatText}${revision?`<br>Revision: ${safe(revision)}`:''}${auto.appliedCells?`<br>Applied mapped cells: ${safe(auto.appliedCells)}`:''}${blocker}${recovery}`;
  const messages=Array.isArray(auto.messages)?auto.messages.slice(-12):[];
  $('#p01AutoMessages').innerHTML=messages.length?messages.map(item=>`<article class="${safe(item.level||'info')}"><b>${safe(new Date(item.at||Date.now()).toLocaleTimeString())}</b><span>${safe(item.text||item.message||'')}</span></article>`).join(''):'<p class="muted">No automation activity yet.</p>';
  const primary=$('#p01AutoStart');
  primary.textContent=commissioned?'✓ P01 Hardware Setup Complete':resumeReady?`Resume ${p01AutoPhaseLabel(phase).replace(/^Preparing /,'')}`:stopped&&recoveredAtFinalStep?'Retry Failed Test Write':'Continue / Finish P01 Setup';
  primary.disabled=running||ready||done;
  const legacyResume=$('#p01AutoResume');
  legacyResume.classList.add('hidden');
  legacyResume.disabled=true;
  const stopButton=$('#p01AutoCancel');
  const activeOperation=Boolean(running&&(auto.activeFlashSessionId||auto.liveFlashSessionId||auto.liveOperationHeartbeat?.processAlive||auto.runtimeBusy));
  stopButton.classList.toggle('hidden',!activeOperation);
  stopButton.disabled=!activeOperation;
  const evidenceLocked=Boolean(state.p01?.dualReadVerified);
  $('#p01IdentifyNow')?.classList.toggle('hidden',evidenceLocked);
  $('#p01ReadNow')?.classList.toggle('hidden',evidenceLocked);
  const technical=latestP01TechnicalDetails(auto);$('#p01AutoCopyDetails')?.classList.toggle('hidden',!technical);
  const bluetoothRecovery=['missing-outgoing-port','ports-unavailable','bluetooth-spp-unavailable','bluetooth-adapter-unreachable','bluetooth-pairing-required','bluetooth-spp-rebuild-failed','manual-port-unverified','adapter-open-timeout','adapter-open-failed'].includes(stopCode);
  const comRecovery=['lock-probe-timeout','bridge-timeout','adapter-locked','adapter-open-timeout','adapter-open-failed','pcmhammer-start-failed','manual-recovery'].includes(stopCode)||Boolean(auto.runtimeBusy&&blocked);
  $('#p01AutoRecover').classList.toggle('hidden',!comRecovery||bluetoothRecovery);
  $('#p01AutoBluetoothRepair')?.classList.toggle('hidden',!bluetoothRecovery);
  $('#p01AutoBluetoothPair')?.classList.toggle('hidden',!bluetoothRecovery);
  $('#p01AutoManualPort')?.classList.toggle('hidden',!bluetoothRecovery);
  $('#p01AutoManualPortVerify')?.classList.toggle('hidden',!bluetoothRecovery);
  $('#p01AutoManualPcmHammer')?.classList.toggle('hidden',!bluetoothRecovery);
  $('#p01AutoBluetoothSetup')?.classList.toggle('hidden',!['bluetooth-spp-unavailable','bluetooth-spp-rebuild-failed'].includes(stopCode));
  if(bluetoothRecovery)refreshP01ManualPorts();
  const integratedRetry = comRecovery || /^assisted-/.test(phase) || /integrated|profile|pcmhammer-cli|unsupported-cli|cli-|kernel-files-missing|adapter-open-(?:timeout|failed)/i.test(String(auto.stop?.code||''));
  $('#p01AutoAssistedBypass').classList.toggle('hidden',!integratedRetry);
  $('#p01AutoChooseXdf').classList.toggle('hidden',!(stopCode==='needs-xdf'||stopCode==='needs-definition-source'||stopCode==='xdf-warnings'));
  $('#p01AutoWriteBox').classList.toggle('hidden',!ready);
  if(ready){const project=auto.activeProject?.name||state.activeProject?.name||'Project';$('#p01AutoWriteSummary').textContent=`The exact revision passed validation and Test Write. Type WRITE ${project} to authorize the separate real Calibration Write.`;$('#p01AutoWriteConfirmation').placeholder=`WRITE ${project}`}
  renderHardwareSessionDoctor(auto.sessionDoctor);
  renderP01AutoRequestReview();
  renderP01Commissioning();
}
async function continueP01Commissioning({commissioningOnly=false}={}){
  const active=state.workspace?.activeProject||state.activeProject;
  if(!active)return notify('Create or activate a P01 project first.','warning');
  if(!/^p0?1$/i.test(String(active.controller||'').replace(/[^a-z0-9]/gi,'')))return notify('The active project must use controller P01.','warning');
  const existingEvidence=p01AutoHasDurableEvidence(),requestChanged=p01AutoRequestChanged();
  if(!commissioningOnly&&(!existingEvidence||requestChanged)){
    const review=state.p01AutoRequestReview;
    if(!review?.ready||state.p01AutoConfirmedFingerprint!==review.requestFingerprint)return notify('Analyze the request and complete confirmation 1 before changing the calibration plan.','warning');
  }
  try{
    const payload=p01AutoPayload();
    if(commissioningOnly&&!existingEvidence){payload.commissioningOnlyStart=true;payload.request='Commission this P01 safely and stop after Test Write. No calibration changes requested.';payload.requestFingerprint='commissioning-only'}
    state.p01Auto=await window.tuniq.startP01Auto(payload);
    try{state.device=await window.tuniq.getDeviceStatus();renderDeviceStatus()}catch{}
    showPage('flash',{restoreScroll:false});renderP01Auto(state.p01Auto);renderP01AutoRequestReview();
    notify(existingEvidence?'Continuing from the exact incomplete P01 step.':'P01 commissioning started with Read Controller Properties.','success',6500)
  }catch(error){notify(error.message,'error',9000)}
}
async function startP01Auto(){return continueP01Commissioning({commissioningOnly:false})}
async function resumeP01Auto(){try{state.p01Auto=await window.tuniq.resumeP01Auto(p01AutoPayload());renderP01Auto()}catch(error){alert(error.message)}}
async function recoverP01Auto(){try{state.p01Auto=await window.tuniq.recoverP01Auto();renderP01Auto();notify('Stale COM and bridge state cleared. Resume is available.','success',5000)}catch(error){alert(error.message)}}
let p01ManualPortsLoading=false;
async function refreshP01ManualPorts(){const select=$('#p01AutoManualPort');if(!select||p01ManualPortsLoading)return;p01ManualPortsLoading=true;try{const all=(await window.tuniq.listDevices()).filter(item=>!item.demo&&/^COM\d+$/i.test(item.port||''));const recognized=item=>Boolean(item.recognized)||/obdlink|stn\d+|scantool|obdx|allpro|avt|elm327/i.test(`${item.name||''} ${item.description||''} ${item.manufacturer||''} ${item.hardwareId||''}`);const devices=all.filter(item=>String(item.port).toUpperCase()!=='COM1'||recognized(item));const recovery=state.p01Auto?.portRecovery||state.p01Auto?.stopDetails||{};const desired=String(state.p01Auto?.device||recovery.device||state.p01Auto?.sessionDoctor?.diagnosis?.recommendedPort||recovery.candidates?.[0]?.port||'').toUpperCase();const current=String(select.value||'').toUpperCase();select.innerHTML=devices.length?devices.map(item=>`<option value="${safe(String(item.port).toUpperCase())}">${safe(String(item.port).toUpperCase())} — ${safe(item.name||item.transport||'Serial port')}</option>`).join(''):'<option value="">No OBDLink COM port exposed by Windows</option>';const target=[desired,current].find(port=>port&&devices.some(item=>String(item.port).toUpperCase()===port));if(target)select.value=target}catch{}finally{p01ManualPortsLoading=false}}
async function repairP01Bluetooth(){try{state.p01Auto=await window.tuniq.repairP01Bluetooth({aggressive:true,targetName:'OBDLink'});renderP01Auto();const running=state.p01Auto?.status==='running';notify(running?'OBDLink port verified. Resuming the exact P01 step.':'The repair finished but the adapter still needs power, pairing, or a verified COM port.',running?'success':'warning',8000)}catch(error){alert(error.message)}}
async function openBluetoothPairing(){try{await window.tuniq.openBluetoothPairing();notify('Windows Bluetooth pairing opened. Make sure the OBDLink is powered, remove the old pairing if needed, and pair it again.','warning',10000)}catch(error){alert(error.message)}}
async function verifyP01ManualPort(){const port=$('#p01AutoManualPort')?.value||'';if(!port)return notify('No live COM port is available to verify.','warning');try{state.p01Auto=await window.tuniq.verifyP01ManualPort({port});renderP01Auto();notify(state.p01Auto?.status==='running'?`${port} verified as the OBDLink. Resuming setup.`:`${port} did not return a verified OBDLink/STN identity.`,state.p01Auto?.status==='running'?'success':'warning',8000)}catch(error){alert(error.message)}}
async function tryP01ManualPcmHammerPort(){const port=$('#p01AutoManualPort')?.value||'';if(!port)return notify('No live COM port is available to try.','warning');if(!confirm(`TunIQ could not open ${port} with its adapter-only verifier. Try one read-only PCM Hammer Read Properties attempt directly on ${port}? This cannot write to the PCM.`))return;try{state.p01Auto=await window.tuniq.tryP01ManualPcmHammerPort({port});renderP01Auto(state.p01Auto);notify(`PCM Hammer is trying Read Properties directly on ${port}. No PCM write is authorized.`,'warning',9000)}catch(error){alert(error.message)}}
async function openBluetoothComSetup(){try{await window.tuniq.openBluetoothComSetup();notify('Legacy Bluetooth COM setup opened. Add an outgoing OBDLink Serial Port only if Windows pairing did not create one automatically.','warning',9000)}catch(error){alert(error.message)}}
async function bypassP01AutoAssisted(){try{state.p01Auto=await window.tuniq.bypassP01AutoAssisted();renderP01Auto();notify('Integrated PCM Hammer retry started inside TunIQ.','success',5000)}catch(error){alert(error.message)}}
async function chooseP01AutoXdf(){try{const result=await window.tuniq.chooseP01AutoXdf();if(result){state.p01Auto=result;renderP01Auto()}}catch(error){alert(error.message)}}
async function cancelP01Auto(){if(!confirm('Stop Guided Automatic P01 Setup? A critical erase/write phase cannot be cancelled safely.'))return;try{state.p01Auto=await window.tuniq.cancelP01Auto();renderP01Auto()}catch(error){alert(error.message)}}
async function writeP01Auto(){const project=state.p01Auto?.activeProject?.name||state.activeProject?.name||'Project';if(!confirm(`This starts a real Calibration Write to the connected P01. Keep regulated power and the interface connected. Continue only after Test Write passed for this exact revision.`))return;try{state.p01Auto=await window.tuniq.writeP01Auto({confirmation:$('#p01AutoWriteConfirmation').value.trim(),device:$('#flashInterface').value.trim(),voltage:$('#flashVoltage').value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:$('#flashBenchPower').checked});renderP01Auto()}catch(error){alert(error.message||`Type exactly WRITE ${project}.`)}}

async function refreshP01ForSelectedRevision(){
  if(!state.p01?.applicable)return;
  try{state.p01=await window.tuniq.getP01Commissioning($('#flashRevision')?.value||null);if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();renderFlashWorkspace()}catch(error){$('#p01CommissionSummary').textContent=error.message}
}
function renderFlashWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,flash=workspace.flash||workspace.integrations?.pcmHammer||state.flash||{},caps=flash.capabilities||{},validation=workspace.validation;
  state.flash=flash;state.validation=validation;state.p01=workspace.p01||state.p01;
  const betaSupport=state.beta?.support?.flashing||{status:'unsupported',note:'Support not evaluated'};const betaPrefs=state.beta?.preferences||{};const betaAccepted=Boolean(state.beta?.agreementAccepted);const experimentalWriteAllowed=betaSupport.status==='experimental'&&betaPrefs.allowExperimentalHardware&&(state.settings.detailLevel||'beginner')==='advanced';const genericWriteAllowed=betaSupport.status==='verified'||experimentalWriteAllowed;
  $('#flashProjectState').textContent=active?'Ready':'Missing';$('#flashProjectDot').className=active?'green':'amber';
  $('#flashBinState').textContent=active?.binInfo?.name||'Missing';$('#flashBinDot').className=active?.bin?'green':'amber';
  const profile=flash.integratedProfileId?` / ${flash.integratedProfileId}`:flash.integrationMode==='runtime-profile-discovery'?' / discovering command profile':''; const owner=flash.portOwner?.owner&&flash.portOwner.owner!=='idle'?` / COM owner: ${flash.portOwner.owner}${flash.portOwner.port?` ${flash.portOwner.port}`:''}`:''; $('#flashAdapterState').textContent=flash.integrated?`Integrated runner ready${profile}${owner}`:flash.configured?'PCM Hammer CLI needs verification':'Not configured';$('#flashToolDot').className=flash.integrated?'green':'amber';
  $('#flashToolState').textContent=flash.configured?(flash.executable?.split(/[\\/]/).pop()||'PCM Hammer CLI configured'):'PCM Hammer CLI needs setup';
  const valid=validation&&validation.compatible!==false&&['valid','valid-external'].includes(validation.checksumStatus);
  $('#flashValidationState').textContent=valid?`${validation.checksumStatus} / ${validation.targetFileName}`:'Not validated';$('#flashValidationDot').className=valid?'green':'amber';
  $('#flashSafetyBadge').textContent=flash.session?'OPERATION RUNNING':!betaAccepted?'BETA AGREEMENT REQUIRED':state.p01?.readyForWrite?'P01 COMMISSIONED · WRITE CONFIRMATION REQUIRED':state.p01?.readyForTestWrite?'P01 READY FOR TEST WRITE':betaSupport.status==='unsupported'?'UNSUPPORTED CONTROLLER':betaSupport.status==='experimental'&&!experimentalWriteAllowed?'EXPERIMENTAL · COMMISSION FIRST':valid?'VALIDATED · CONFIRMATION REQUIRED':flash.configured?'READ/PROPERTIES READY':'CAPABILITY CHECK REQUIRED';
  $('#flashInterface').value=flash.device||state.device?.connection?.port||$('#flashInterface').value||'';
  if(state.device?.connection?.voltage&&!$('#flashVoltage').value)$('#flashVoltage').value=Number(state.device.connection.voltage).toFixed(2);
  $('#flashCapabilities').innerHTML=Object.keys(caps).length?Object.entries(caps).map(([key,value])=>`<span class="${value?'ready':'missing'}">${value?'✓':'×'} ${safe(flashCapabilityName(key))}</span>`).join(''):'<span>Probe the CLI to discover supported commands.</span>';
  const templates=flash.templates||{};const templateFields={readProperties:'#flashTemplateIdentify',read:'#flashTemplateRead',testWrite:'#flashTemplateTest',writeCalibration:'#flashTemplateWriteCal',writeFull:'#flashTemplateWriteFull',recovery:'#flashTemplateRecovery'};for(const [key,selector] of Object.entries(templateFields)){const element=$(selector);if(element&&document.activeElement!==element)element.value=Array.isArray(templates[key])?templates[key].join(' '):(templates[key]||'')}
  populateRevisionSelects();renderP01Commissioning();
  const running=Boolean(flash.session);
  for(const [id,key] of [['#flashIdentify','readProperties'],['#flashRead','read'],['#flashTestWrite','testWrite'],['#flashWriteCalibration','writeCalibration'],['#flashWriteFull','writeFull'],['#flashRecovery','recovery']]){const button=$(id);if(button){const isWrite=['testWrite','writeCalibration','writeFull','recovery'].includes(key);let p01Locked=false;let locallyCommissioned=false;if(state.p01?.applicable){if(key==='testWrite'){p01Locked=!state.p01.readyForTestWrite;locallyCommissioned=state.p01.readyForTestWrite}else if(key==='writeCalibration'){p01Locked=!state.p01.readyForWrite;locallyCommissioned=state.p01.readyForWrite}else if(key==='writeFull')p01Locked=!state.p01.readyForWrite;}const operationAllowed=genericWriteAllowed||locallyCommissioned;const needsRevision=['testWrite','writeCalibration','writeFull','recovery'].includes(key);button.disabled=running||!active||!flash.configured||!caps[key]||!betaAccepted||(isWrite&&((needsRevision&&!(state.workspace?.files?.revisions||[]).length)||!operationAllowed||p01Locked));button.title=p01Locked?(state.p01?.writeBlockers||[]).join('\n'):isWrite&&!operationAllowed?betaSupport.note||'This combination is not enabled for public-beta writing.':'';}}
  $('#flashCancel').disabled=!running;
  if(flash.session)renderFlashProgress(flash.session);
  else if(!active)$('#flashConsole').textContent='Create or activate a project first.';
  else if(!flash.configured)$('#flashConsole').textContent='Configure PCM Hammer or PcmHammerCLI.exe in Tool Connections, then probe capabilities.';
}
function renderFlashProgress(session){
  state.flash={...(state.flash||{}),session};
  $('#flashSessionState').textContent=String(session.state||'running').toUpperCase();
  $('#flashPhase').textContent=[session.phase,Number.isFinite(Number(session.voltage))?`${Number(session.voltage).toFixed(2)} V`:null,session.voltageWarning].filter(Boolean).join(' · ');
  $('#flashProgressBar').style.width=`${Math.max(0,Math.min(100,Number(session.progress)||0))}%`;
  const lines=(session.log||[]).slice(-120).map(item=>`[${new Date(item.at).toLocaleTimeString()}] ${item.stream}: ${item.text}`);
  if(session.identity)lines.push('',`Identity: ${JSON.stringify(session.identity,null,2)}`);
  if(session.outputInfo)lines.push('',`Protected read: ${session.outputInfo.name}`,`SHA-256: ${session.outputInfo.sha256}`);
  if(session.verified)lines.push('Verification reported successful by PCM Hammer.');if(session.verificationWarning)lines.push(`SAFETY: ${session.verificationWarning}`);
  $('#flashConsole').textContent=lines.join('\n')||`${session.operation} started…`;
  $('#flashConsole').scrollTop=$('#flashConsole').scrollHeight;
  if(['complete','complete-unverified','failed','cancelled'].includes(session.state))refreshWorkspace(true).catch(()=>{});
}
function renderPatchWorkspace(){
  const workspace=state.workspace||{},active=workspace.activeProject,tool=workspace.integrations?.universalPatcher,validation=workspace.validation;
  $('#patchProjectBadge').textContent=active?.name||'NO PROJECT';
  $('#patchBinState').textContent=active?.binInfo?.sha256?'Fingerprint ready':'Missing';$('#patchBinDot').className=active?.bin?'green':'amber';
  $('#patchToolState').textContent=tool?.configured?'Configured':'Optional / report import works without launch';$('#patchToolDot').className=tool?.configured?'green':'amber';
  $('#patchFileSummary').innerHTML=active?.binInfo?`<b>${safe(active.binInfo.name)}</b><br>${formatBytes(active.binInfo.size)}<br>SHA-256: ${safe(active.binInfo.sha256)}<br>XDF checksums: ${Number(workspace.calibration?.mappingSummary?.checksumCount||0)}`:'Import an original BIN to begin.';
  $('#patchAnalyze').disabled=!active?.binInfo;$('#patchCompare').disabled=!active?.binInfo||!(workspace.files?.revisions||[]).length;$('#patchPreviewBin').disabled=!active?.binInfo;$('#patchImportBin').disabled=!state.patchPreview?.compatible;$('#patchCorrect').disabled=!(workspace.calibration?.mappingSummary?.checksumCount>0)||(workspace.files?.revisions||[]).length===0;$('#patchRunUniversal').disabled=!active?.binInfo||!tool?.configured;$('#patchCheckUniversal').disabled=!active?.binInfo;
  populateRevisionSelects();
  const checksum=validation?.checksumStatus||'not analyzed',compatible=validation?.compatible;
  $('#patchChecksumState').textContent=checksum;$('#patchChecksumDot').className=['valid','valid-external'].includes(checksum)?'green':checksum==='invalid'?'red':'amber';
  $('#patchLayoutState').textContent=compatible===true?'Compatible':compatible===false?'Mismatch':'Unknown';$('#patchLayoutDot').className=compatible===true?'green':compatible===false?'red':'amber';
  $('#patchReportState').textContent=validation?new Date(validation.validatedAt).toLocaleString():'WAITING';
}
function activityLabel(item){const labels={'project-created':'Project created','project-updated':'Project updated','project-activated':'Project activated','bin-imported':'Original BIN imported','xdf-imported':'XDF imported','xdf-mapping-loaded':'Calibration mapping loaded','bin-exported':'Revision BIN exported','workspace-action-prepared':'Integrated action prepared','calibration-revision':'Calibration snapshot saved','tool-launched':'Compatibility tool launched','device-connected':'Vehicle interface connected','device-disconnected':'Vehicle interface disconnected','live-log-started':'Live log started','live-log-stopped':'Live log analyzed'};return labels[item.type]||String(item.type||'Activity').replace(/-/g,' ')}
function renderRevisionWorkspace(){
  const workspace=state.workspace||{},files=workspace.files?.revisions||[],activity=workspace.activity||[];
  $('#revisionCount').textContent=`${files.length} file${files.length===1?'':'s'}`;
  $('#revisionList').innerHTML=files.length?files.map(file=>`<article><div><b>${safe(file.name)}</b><small>${formatBytes(file.size)} · ${new Date(file.modifiedAt).toLocaleString()}</small></div><span>${safe((file.extension||'file').replace('.','').toUpperCase())}</span></article>`).join(''):'<p class="muted">No exported revisions yet.</p>';
  const snapshots=state.calHistory||[];const timeline=$('#snapshotTimeline');if(timeline)timeline.innerHTML=snapshots.length?snapshots.slice(0,30).map(item=>`<article><div><b>${safe(item.name)}</b><small>${Number(item.modifiedCells||0)} changed cells · ${new Date(item.at).toLocaleString()}</small></div><button class="ghost revision-snapshot-open" data-id="${safe(item.id)}">Compare</button></article>`).join(''):'<p class="muted">No project snapshots yet.</p>';
  $$('.revision-snapshot-open').forEach(button=>button.onclick=()=>{showPage('sandbox');setTimeout(()=>compareCalibrationSnapshot(button.dataset.id),50)});
  $('#workspaceActivity').innerHTML=activity.length?activity.slice(0,30).map(item=>`<article><div><b>${safe(activityLabel(item))}</b><small>${new Date(item.at).toLocaleString()}</small></div><span>${safe(item.details?.name||item.details?.projectName||'')}</span></article>`).join(''):'<p class="muted">No project activity recorded.</p>';
}
function renderAiContext(){const workspace=state.workspace||{},active=workspace.activeProject,device=state.device?.connection;$('#aiContext').innerHTML=active?[`Project: ${active.name}`,`Vehicle: ${active.vehicle||'Unassigned'}`,`Controller: ${active.controller||'Unknown'}`,`OS: ${active.os||'Auto-detect pending'}`,`BIN: ${active.binInfo?.name||'Missing'}`,`XDF: ${active.xdfInfo?.name||'Missing'}`,`Adapter: ${device?.adapter||'Disconnected'}`,`Logs: ${(state.liveLogs||[]).length}`,`Revisions: ${workspace.files?.revisions?.length||0}`].map(text=>`<span>${safe(text)}</span>`).join(''):'<span>No active project context.</span>'}
async function refreshWorkspace(silent=false){
  try{
    const workspace=await window.tuniq.getWorkspaceSummary();
    state.workspace=workspace;state.activeProject=workspace.activeProject||null;state.tools=workspace.tools||state.tools;state.device=workspace.device||state.device;state.liveLogs=Array.isArray(workspace.liveLogs)?workspace.liveLogs:state.liveLogs;state.sensorProfiles=workspace.sensorProfiles||state.sensorProfiles;state.flash=workspace.flash||state.flash;state.validation=workspace.validation||null;state.calHistory=Array.isArray(workspace.calibrationHistory)?workspace.calibrationHistory:(state.calHistory||[]);state.aiProposals=workspace.aiProposals||[];state.beta=workspace.beta||state.beta;state.updates=workspace.updates||state.updates;state.p01=workspace.p01||null;state.p01Auto=workspace.p01Auto||state.p01Auto;state.definitionCenter=workspace.definitionCenter||state.definitionCenter;
    if(workspace.ai){state.aiIntake=workspace.ai.intake||null;state.aiPlan=workspace.ai.plan||null;}
    renderSafely('Workspace strip',renderWorkspaceStrip);renderSafely('Definition Center',renderDefinitionCenter);renderSafely('Tune Path',renderTunePath);renderSafely('Guided P01 Setup',renderP01Auto);renderSafely('P01 commissioning',renderP01Commissioning);renderSafely('Flash Center',renderFlashWorkspace);renderSafely('Patches',renderPatchWorkspace);renderSafely('Revisions',renderRevisionWorkspace);renderSafely('Device status',renderDeviceStatus);renderSafely('Live logs',renderLiveLogHistory);renderSafely('AI context',renderAiContext);renderSafely('AI plan',renderAiPlan);renderSafely('AI proposals',renderAiProposalWorkspace);renderSafely('AI goal',renderAiGoalRequest);renderSafely('P01 Quick Service',renderQuickService);renderSafely('Beta Center',renderBetaCenter);renderSafely('Active project',updateActiveProject);renderSafely('Tool setup',renderTools);
    return workspace;
  }catch(error){if(!silent)status(error.message,true);throw error}
}
async function prepareWorkspaceAction(action){
  const messages={
    'identify-controller':'Controller identification preflight prepared. Confirm ignition state, interface selection, battery support, and controller family before native communication is enabled.',
    'read-original':'Original-read plan prepared. TunIQ will place the result in the protected Originals folder and fingerprint it before any edits are allowed.',
    'analyze-bin':'BIN analysis prepared. TunIQ compares every changed byte and segment, verifies supported XDF checksums, and accepts a Universal Patcher report only when it is bound to this exact BIN fingerprint.'
  };
  const result=await window.tuniq.planWorkspaceAction({action});
  await refreshWorkspace(true);
  return {result,message:messages[action]||'Action prepared.'};
}
function localFileUrl(value){if(!value)return'';const normalized=String(value).replace(/\\/g,'/');return normalized.startsWith('/')?`file://${encodeURI(normalized)}`:`file:///${encodeURI(normalized)}`}
function vehicleDisplayName(vehicle){return [vehicle.year,vehicle.make,vehicle.model,vehicle.trim].filter(Boolean).join(' ')||'Vehicle details not entered'}
function maintenanceText(items){return(Array.isArray(items)?items:[]).map(item=>[item.date,item.mileage,item.description].filter(Boolean).join(' | ')).join('\n')}
function renderProjectVehicleOptions(selected=null){const select=$('#projectVehicle');if(!select)return;const current=selected??select.value;select.innerHTML='<option value="">Choose a Garage vehicle or leave unassigned</option>'+state.vehicles.map(v=>`<option value="${safe(v.id)}">${v.favorite?'★ ':''}${safe(v.name)}${v.engine?` — ${safe(v.engine)}`:''}</option>`).join('');select.value=state.vehicles.some(v=>v.id===current)?current:''}
function filteredVehicles(){const query=($('#garageSearch')?.value||'').trim().toLowerCase(),favorites=Boolean($('#garageFavoritesOnly')?.checked);return state.vehicles.filter(vehicle=>{if(favorites&&!vehicle.favorite)return false;if(!query)return true;const haystack=[vehicle.name,vehicle.year,vehicle.make,vehicle.model,vehicle.trim,vehicle.engine,vehicle.transmission,vehicle.controller,vehicle.os,vehicle.vin,vehicle.notes,...(vehicle.modifications||[])].join(' ').toLowerCase();return haystack.includes(query)})}
async function reloadGarage(){state.vehicles=await window.tuniq.listVehicles();renderVehicles();await loadProjects();await refreshWorkspace(true)}
function renderVehicles(){
  const c=$('#garageContent');renderProjectVehicleOptions();const vehicles=filteredVehicles();
  if($('#garageSummary'))$('#garageSummary').textContent=`${vehicles.length} shown · ${state.vehicles.length} saved · ${state.vehicles.reduce((total,v)=>total+Number(v.projectCount||0),0)} linked project${state.vehicles.reduce((total,v)=>total+Number(v.projectCount||0),0)===1?'':'s'}`;
  if(!state.vehicles.length){c.innerHTML='<div class="empty-card"><div class="empty-icon">▣</div><h2>No vehicles saved yet</h2><p>Create a durable vehicle profile once, then reuse it across projects without breaking the link when the vehicle is renamed.</p><button id="garageAdd">Create First Vehicle</button></div>';$('#garageAdd').onclick=()=>openVehicleModal();return}
  if(!vehicles.length){c.innerHTML='<div class="empty-card compact"><div class="empty-icon">⌕</div><h3>No matching vehicles</h3><p>Clear the Garage search or Favorites-only filter.</p></div>';return}
  c.innerHTML=`<div class="vehicle-grid garage-v2">${vehicles.map(v=>{const vinState=v.vinStatus?.status||'',photo=v.photoPath?`<img src="${safe(localFileUrl(v.photoPath))}" alt="${safe(v.name)}">`:'<span>🚘</span>',mods=(v.modifications||[]).slice(0,5),hardware=[v.controller,v.os?`OS ${v.os}`:'',v.serviceNumber?`Service ${v.serviceNumber}`:''].filter(Boolean).join(' · ');return `<article class="vehicle-card ${v.favorite?'favorite':''}"><div class="vehicle-photo">${photo}</div><div class="vehicle-card-body"><div class="vehicle-card-title"><div><p class="eyebrow">${safe(hardware||'CONTROLLER NOT VERIFIED')}</p><h3>${v.favorite?'★ ':''}${safe(v.name)}</h3></div><span class="project-link-count">${Number(v.projectCount||0)} project${Number(v.projectCount||0)===1?'':'s'}</span></div><p>${safe(vehicleDisplayName(v))}</p><div class="vehicle-spec-grid"><span><small>Powertrain</small><b>${safe([v.engine,v.transmission].filter(Boolean).join(' · ')||'Not entered')}</b></span><span><small>Chassis</small><b>${safe([v.drivetrain,v.rearGear&&`${v.rearGear} gear`,v.tireSize].filter(Boolean).join(' · ')||'Not entered')}</b></span><span><small>Fuel / mileage</small><b>${safe([v.fuel,v.mileage&&`${v.mileage} mi`].filter(Boolean).join(' · ')||'Not entered')}</b></span><span><small>VIN</small><b class="vin-${safe(vinState)}">${v.vin?safe(v.vin.slice(-8)):`Not saved`}${vinState==='check-digit-mismatch'?' · REVIEW':''}</b></span></div>${mods.length?`<div class="vehicle-tags">${mods.map(mod=>`<span>${safe(mod)}</span>`).join('')}</div>`:''}${v.projectNames?.length?`<small class="linked-projects">Linked: ${safe(v.projectNames.join(', '))}</small>`:''}</div><div class="vehicle-actions"><button class="ghost" data-favorite-vehicle="${safe(v.id)}">${v.favorite?'Unfavorite':'☆ Favorite'}</button><button data-project-vehicle="${safe(v.id)}">Create Project</button><button class="ghost" data-edit-vehicle="${safe(v.id)}">Edit</button><button class="ghost" data-photo-vehicle="${safe(v.id)}">${v.photoPath?'Change Photo':'Add Photo'}</button>${v.photoPath?`<button class="ghost" data-remove-photo="${safe(v.id)}">Remove Photo</button>`:''}<button class="ghost" data-duplicate-vehicle="${safe(v.id)}">Duplicate</button><button class="danger-btn" data-delete-vehicle="${safe(v.id)}">Delete</button></div></article>`}).join('')}</div>`;
  $$('[data-edit-vehicle]').forEach(button=>button.onclick=()=>openVehicleModal(state.vehicles.find(v=>v.id===button.dataset.editVehicle)));
  $$('[data-favorite-vehicle]').forEach(button=>button.onclick=async()=>{try{await window.tuniq.favoriteVehicle(button.dataset.favoriteVehicle);await reloadGarage();notify('Garage favorite updated.','success')}catch(error){notify(error.message,'error')}});
  $$('[data-duplicate-vehicle]').forEach(button=>button.onclick=async()=>{try{const created=await window.tuniq.duplicateVehicle(button.dataset.duplicateVehicle);await reloadGarage();notify(`Created ${created.name}.`,'success')}catch(error){notify(error.message,'error')}});
  $$('[data-photo-vehicle]').forEach(button=>button.onclick=async()=>{try{const updated=await window.tuniq.chooseVehiclePhoto(button.dataset.photoVehicle);if(updated){await reloadGarage();notify('Vehicle photo saved inside TunIQ AppData.','success')}}catch(error){notify(error.message,'error')}});
  $$('[data-remove-photo]').forEach(button=>button.onclick=async()=>{try{await window.tuniq.removeVehiclePhoto(button.dataset.removePhoto);await reloadGarage();notify('Vehicle photo removed.','success')}catch(error){notify(error.message,'error')}});
  $$('[data-project-vehicle]').forEach(button=>button.onclick=()=>{const vehicle=state.vehicles.find(v=>v.id===button.dataset.projectVehicle);if(!vehicle)return;resetProjectForm();renderProjectVehicleOptions(vehicle.id);$('#projectName').value=`${vehicle.name} Tune`;$('#projectController').value=vehicle.controller||'';$('#projectOs').value=vehicle.os||'';$('#projectNotes').value='';showPage('workflow');$('#projectName').focus()});
  $$('[data-delete-vehicle]').forEach(button=>button.onclick=async()=>{const vehicle=state.vehicles.find(v=>v.id===button.dataset.deleteVehicle);if(!confirm(`Delete ${vehicle?.name||'this vehicle'}? Linked projects are protected and will block deletion.`))return;try{await window.tuniq.deleteVehicle(button.dataset.deleteVehicle);await reloadGarage();notify('Vehicle deleted.','success')}catch(error){notify(error.message,'error',8000)}})
}
function openVehicleModal(v=null){
  $('#vehicleForm').reset();$('#vehicleId').value=v?.id||'';$('#vehicleModalTitle').textContent=v?'Edit Vehicle':'Add Vehicle';
  const fields=[['vehicleName','name'],['vehicleYear','year'],['vehicleMake','make'],['vehicleModel','model'],['vehicleTrim','trim'],['vehicleMileage','mileage'],['vehicleEngine','engine'],['vehicleTransmission','transmission'],['vehicleDrivetrain','drivetrain'],['vehicleFuel','fuel'],['vehicleTireSize','tireSize'],['vehicleRearGear','rearGear'],['vehicleController','controller'],['vehicleOs','os'],['vehicleHardwareId','hardwareId'],['vehicleServiceNumber','serviceNumber'],['vehicleVin','vin'],['vehicleNotes','notes']];
  for(const[id,key]of fields)$('#'+id).value=v?.[key]||'';$('#vehicleModifications').value=(v?.modifications||[]).join('\n');$('#vehicleMaintenance').value=maintenanceText(v?.maintenance);$('#vehicleVinHelp').textContent=v?.vinStatus?.message||'TunIQ validates VIN format and check digit locally.';$('#vehicleError').textContent='';$('#vehicleModal').classList.remove('hidden');$('#vehicleName').focus()
}
function closeVehicleModal(){$('#vehicleModal').classList.add('hidden')}
function offlineAnswer(q){
  const lower=q.toLowerCase();
  const workspace=state.workspace||{};
  const active=workspace.activeProject||state.activeProject;
  const current=workspace.tunePath?.steps?.find(step=>step.status==='current');
  const context=active?` Active TunIQ project: ${active.name}, vehicle ${active.vehicle||'unspecified'}, controller ${active.controller||'unspecified'}${active.os?`, OS ${active.os}`:', OS auto-detect pending'}.`:'';
  if(lower.includes('next')||lower.includes('what should i do'))return current?`Your current Tune Path step is <b>${safe(current.title)}</b>. ${safe(current.description)} Open the glowing star beside that step and TunIQ will take you to the correct control.${context}`:`Your required project steps are complete up to the current validation and confirmation gates. Review Patches & Checksums before preparing a flash.${context}`;
  if(lower.includes('file')||lower.includes('loaded')){const bin=active?.binInfo?.name||'no original BIN';const xdf=active?.xdfInfo?.name||'no XDF';return `The shared workspace currently has <b>${safe(bin)}</b> and <b>${safe(xdf)}</b>. Calibration, Patches, Revisions, Flash preparation, and AI context all use this same pair.${context}`}
  if(lower.includes('what')&&lower.includes('tool'))return `TunIQ has recorded ${state.activity.filter(x=>x.type==='tool-launched').length} compatibility-mode legacy tool launches. Standard PCM Hammer, TunerPro/XDF, and Universal Patcher work now routes to native TunIQ tabs without opening separate windows.${context}`;
  if(lower.includes('fuel trim'))return 'Positive fuel trims mean the PCM is adding fuel. Before editing VE or MAF tables, check vacuum leaks, exhaust leaks ahead of the O₂ sensors, fuel pressure, injector data, and MAF cleanliness. Compare both banks: one-bank-only trim usually points to a bank-specific issue.'+context;
  if(lower.includes('fan'))return 'Verify coolant-temperature accuracy first. Use enough separation between fan-on and fan-off temperatures to prevent rapid cycling, confirm thermostat temperature, and verify relay and wiring current capacity.'+context;
  if(lower.includes('knock'))return 'Do not desensitize knock protection first. Verify fuel octane, commanded spark, AFR, coolant temperature, mechanical noise, sensor torque, and harness condition. Log RPM, load, spark, AFR, and knock retard together.'+context;
  if(lower.includes('injector'))return 'Injector tuning needs flow rate versus pressure, offset versus voltage, short-pulse adder, and minimum pulse data. A single lb/hr value is not enough for accurate idle and transient fueling.'+context;
  if(lower.includes('p01')||lower.includes('p59'))return 'P01 and P59 are common Gen III GM PCMs. Support depends on the exact operating system and hardware ID. Preserve a verified original BIN before editing, and match the XDF to the operating system—not just the vehicle year.'+context;
  if(lower.includes('log')||lower.includes('live data')){const latest=(state.liveLogs||[])[0],analysis=state.logAnalysis||latest?.analysis;if(!latest)return `No saved live log is attached to the active project yet. Connect the vehicle interface, open Live Log, choose a profile, and record the exact problem area.${context}`;if(!analysis)return `The latest log is <b>${safe(latest.name||'unnamed')}</b> with ${Number(latest.samples||0)} samples. Open Live Log and analyze it before changing calibration tables.${context}`;const top=(analysis.findings||[])[0];return `The latest AI log review has <b>${safe(analysis.confidence||'limited')}</b> confidence from ${Number(analysis.sampleCount||0)} samples. ${top?`Top finding: <b>${safe(top.title)}</b>. ${safe(top.detail)} ${safe(top.action)}`:'No repeatable problem was identified.'}${context}`;}
  if(lower.includes('full ai')||lower.includes('build plan'))return state.aiPlan?`Your Full AI plan is for <b>${safe(state.aiPlan.goal)}</b> and contains ${state.aiPlan.steps.length} steps. Open Full AI Tuner to review the build intake, safety blocks, and exact sequence.${context}`:`Open Full AI Tuner and enter the engine, transmission, modifications, symptoms, and tune goal. TunIQ will ask for cam specifications when a cam or ghost-cam goal is selected.${context}`;
  if(lower.includes('saved tune')||lower.includes('library'))return `Your local Tune Library currently contains ${(state.tuneLibrary||[]).length} tune package(s). Controller and OS mismatches are blocked before a tune can be copied into an active project's Revisions folder.${context}`;
  if(lower.includes('forum')||lower.includes('community'))return `The Community Hub currently has ${(state.communityPosts||[]).length} local guide or draft post(s). Filters are available for engine, transmission, controller, category, and search terms. Online accounts and cloud moderation are not enabled in this development build.${context}`;
  return `Offline AI now follows TunIQ's active project, controller, OS, BIN, XDF, Tune Path, revision files, and recent project actions.${context} Live vehicle values and direct flashing actions are still being connected behind controlled native adapters.`
}
function resetProjectForm(){
  state.editingProjectId=null;
  $('#projectForm').reset();
  $('#projectId').value='';
  $('#projectFormTitle').textContent='New Project';
  $('#projectFormMode').textContent='CREATE';
  $('#projectSubmit').textContent='＋ Create Protected Project';
  $('#projectCancelEdit').classList.add('hidden');
  $('#projectFormStatus').textContent='New projects receive protected Originals, Definitions, Revisions, Logs, and Backups folders.';
}
function beginProjectEdit(project){
  if(!project)return;
  state.editingProjectId=project.id;
  $('#projectId').value=project.id||'';
  $('#projectName').value=project.name||'';
  renderProjectVehicleOptions(project.vehicleId||state.vehicles.find(vehicle=>vehicle.name===project.vehicle)?.id||'');
  $('#projectController').value=project.controller||'';
  $('#projectOs').value=project.os||'';
  $('#projectNotes').value=project.notes||'';
  $('#projectFormTitle').textContent='Edit Project';
  $('#projectFormMode').textContent='EDITING';
  $('#projectSubmit').textContent='Save Project Changes';
  $('#projectCancelEdit').classList.remove('hidden');
  $('#projectFormStatus').textContent='Saving updates changes the project manifest only. Existing BINs, XDFs, logs, backups, and revisions stay in place.';
  showPage('workflow');
  $('#projectName').focus();
}

function invalidateQuickServiceRequest(){state.quickServiceReview=null;state.quickServiceProposal=null;state.quickServicePlanConfirmed=false;renderQuickService()}
function quickServiceRequestText(){return $('#quickServiceRequest')?.value.trim()||''}
function renderQuickService(){
  const panel=$('#p01QuickServicePanel');if(!panel)return;
  const badge=$('#p01QuickServiceBadge'),summary=$('#quickServiceSummary'),safety=$('#quickServiceSafety'),changes=$('#quickServiceChanges'),confirmButton=$('#quickServiceConfirmPlan'),applyButton=$('#quickServiceApply');
  const active=state.activeProject,isP01=/^p0?1$/i.test(String(active?.controller||'').replace(/[^a-z0-9]/gi,''));
  badge.textContent=!active?'NO ACTIVE PROJECT':!isP01?'ACTIVE PROJECT IS NOT P01':`ACTIVE: ${active.name}`;badge.className=!active||!isP01?'bad':'good';
  const review=state.quickServiceReview,proposal=state.quickServiceProposal;
  if(!review){summary.textContent=active?`Active project: ${active.name}. Type any supported P01 request and press Analyze Request.`:'Create or activate a P01 project first.';safety.innerHTML='';changes.innerHTML='';confirmButton.classList.add('hidden');applyButton.classList.add('hidden');return}
  const missing=review.missingSafetyFacts||[];safety.innerHTML=missing.length?`<article class="quick-service-change blocked"><span><b>Unresolved request or safety requirements</b><small>${missing.map(item=>safe(item)).join(' ')}</small></span><em>TYPE FACTS</em></article>`:`<article class="quick-service-change"><span><b>Request review complete</b><small>${safe(review.protections.join(' · '))}</small></span><em>READY</em></article>`;
  if(!proposal){summary.innerHTML=`<b>${safe(review.projectName)}</b> · request understood${review.os?` · OS ${safe(review.os)}`:''}`;changes.innerHTML='';confirmButton.classList.add('hidden');applyButton.classList.add('hidden');return}
  const actions=proposal.actions||[],items=proposal.proposals||[];
  summary.innerHTML=`<b>${safe(proposal.projectName)}</b>${review.os?` · OS ${safe(review.os)}`:''} · ${actions.length} action(s) · ${items.filter(item=>!item.blocked).length} exact cell change(s)<br><small>No flash occurs here. The protected original is never overwritten.</small>`;
  changes.innerHTML=actions.map(action=>`<article class="quick-service-change ${action.status==='blocked'?'blocked':''}"><span><b>${safe(action.label)}</b><small>${safe(action.status==='blocked'?(action.requirements||[]).join(' '):`${(action.proposals||[]).length} mapped cell(s) · ${action.confidence}`)}</small></span><em>${safe(action.status.toUpperCase())}</em></article>`).join('');
  const needsMap=actions.some(action=>action.status!=='blocked'&&!action.mapCommissioned&&(action.proposals||[]).some(item=>!item.blocked));
  const ready=review.ready&&items.length>0&&items.every(item=>!item.blocked)&&actions.every(action=>action.status!=='blocked');
  confirmButton.classList.toggle('hidden',!ready);confirmButton.disabled=!ready||state.quickServicePlanConfirmed;confirmButton.textContent=state.quickServicePlanConfirmed?'✓ Exact Plan Confirmed':needsMap?'Confirm Exact Plan + Bind Map':'Confirm Exact Plan';
  applyButton.classList.toggle('hidden',!state.quickServicePlanConfirmed);applyButton.disabled=!state.quickServicePlanConfirmed;
}
function prepareQuickServiceProject(){
  resetProjectForm();showPage('workflow',{restoreScroll:false});const stamp=new Date().toISOString().slice(0,10),request=quickServiceRequestText();
  $('#projectName').value=`P01 Service ${stamp}`;$('#projectController').value='P01';$('#projectOs').value='';
  $('#projectNotes').value='';
  $('#projectFormStatus').textContent='Review the name and vehicle, then create this protected P01 project. Every PCM keeps its own evidence and revisions.';$('#projectName').focus();
}
async function buildQuickServicePlan(){
  const active=state.activeProject;if(!active)return notify('Create and activate a P01 project first.','error');
  if(!/^p0?1$/i.test(String(active.controller||'').replace(/[^a-z0-9]/gi,'')))return notify('The active project is not identified as a P01.','error');
  const request=quickServiceRequestText(),safetyFacts=$('#quickServiceSafetyFacts')?.value.trim()||'';if(!request)return notify('Type the calibration request first.','warning');
  const button=$('#quickServiceBuild');button.disabled=true;$('#quickServiceStatus').textContent='Interpreting the request and checking this P01 project, OS, XDF, and protected original…';
  try{const review=await window.tuniq.reviewP01Request({request,safetyFacts});state.quickServiceReview=review;state.quickServicePlanConfirmed=false;const proposal=await window.tuniq.buildAiGoalRequest({request,confirmations:review.confirmations});state.quickServiceProposal=proposal;state.goalProposal=proposal;state.goalRequests=[proposal,...(state.goalRequests||[]).filter(item=>item.id!==proposal.id)];renderQuickService();renderAiGoalRequest();$('#quickServiceStatus').textContent=!review.ready?'Request reviewed. Resolve every missing or unsupported change before continuing.':proposal.blocked?'Plan stopped. Read the exact requirement shown above.':'Exact plan built. Confirmation 1 binds this plan; confirmation 2 creates the revision.'}
  catch(error){state.quickServiceProposal=null;state.quickServicePlanConfirmed=false;renderQuickService();$('#quickServiceStatus').textContent=error.message;notify(error.message,'error',8000)}finally{button.disabled=false}
}
async function confirmQuickServicePlan(){
  const proposal=state.quickServiceProposal,review=state.quickServiceReview;if(!proposal||!review?.ready)return;
  const actions=proposal.actions||[],needsMap=actions.some(action=>action.status!=='blocked'&&!action.mapCommissioned&&(action.proposals||[]).some(item=>!item.blocked));
  const button=$('#quickServiceConfirmPlan');button.disabled=true;
  try{if(needsMap){const actionIds=actions.filter(action=>action.status!=='blocked'&&(action.proposals||[]).some(item=>!item.blocked)).map(action=>action.id);const proposalIds=(proposal.proposals||[]).filter(item=>!item.blocked).map(item=>item.id);if(!actionIds.length)throw new Error('The plan has no commissionable exact cells.');state.p01=await window.tuniq.confirmP01GoalMap({proposalId:proposal.id,actionIds,proposalIds});const refreshed=await window.tuniq.buildAiGoalRequest({request:review.requestText,confirmations:review.confirmations});state.quickServiceProposal=refreshed;state.goalProposal=refreshed;const stillNeeds=(refreshed.actions||[]).some(action=>action.status!=='blocked'&&!action.mapCommissioned);if(stillNeeds)throw new Error('The exact parameter map did not remain commissioned after refresh.');}
    state.quickServicePlanConfirmed=true;renderQuickService();$('#quickServiceStatus').textContent='Confirmation 1 of 2 complete. Review once more, then confirm revision creation.';notify('Exact P01 plan confirmed. No BIN was changed yet.','success',6500)}
  catch(error){state.quickServicePlanConfirmed=false;renderQuickService();$('#quickServiceStatus').textContent=error.message;notify(error.message,'error',8000)}finally{button.disabled=false}
}
async function applyQuickServiceRevision(){
  const proposal=state.quickServiceProposal;if(!proposal||!state.quickServicePlanConfirmed)return;
  const approvedIds=(proposal.proposals||[]).filter(item=>!item.blocked).map(item=>item.id);if(!approvedIds.length)return;
  const button=$('#quickServiceApply');button.disabled=true;
  try{const result=await window.tuniq.applyAiGoalRequest({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration();$('#quickServiceStatus').textContent=`Confirmation 2 of 2 complete. Revision created: ${result.revision.name}. Validate and Test Write separately.`;notify(`Created ${result.revision.name}. No PCM write occurred.`,'success',8000);state.quickServicePlanConfirmed=false;await refreshWorkspace(true)}
  catch(error){$('#quickServiceStatus').textContent=error.message;notify(error.message,'error',8000)}finally{button.disabled=false;renderQuickService()}
}

async function startNewP01Service(){
  if(state.p01Auto?.status==='running')return notify('A P01 hardware operation is already running.','warning');
  const active=state.workspace?.activeProject||state.activeProject;
  if(active&&/^p0?1$/i.test(String(active.controller||'').replace(/[^a-z0-9]/gi,''))){
    return continueP01Commissioning({commissioningOnly:true});
  }
  showPage('workflow',{restoreScroll:false});resetProjectForm();$('#projectController').value='P01';$('#projectName').value='New P01 Service';$('#projectNotes').value='';$('#projectName').focus();notify('Create the P01 project once. After creation, Begin P01 Setup starts Read Controller Properties in that same project.','success',7000);
}
async function resetCurrentP01Commissioning(){
  if(!state.activeProject)return notify('No active project is selected.','warning');
  if(!confirm('Reset only the current project commissioning workflow? Protected BIN files, matching reads, revisions, logs, and reports will remain on disk.'))return;
  try{
    const reset=await window.tuniq.resetP01Commissioning();
    state.p01=reset?.p01||reset;state.p01Auto=reset?.auto||null;state.p01AutoRequestReview=null;state.p01AutoConfirmedFingerprint=null;
    if(state.workspace){state.workspace.p01=state.p01;state.workspace.p01Auto=state.p01Auto}
    await refreshWorkspace(true);await refreshProjectFiles();
    renderWorkspaceStrip();renderP01Commissioning();renderFlashWorkspace();
    notify('Commissioning state reset. Protected project files were preserved.','success',7000);
  }catch(error){notify(error.message,'error',9000)}
}
async function archiveCurrentP01Project(){
  const active=state.workspace?.activeProject||state.activeProject;
  if(!active)return notify('No active project is selected.','warning');
  if(state.p01Auto?.status==='running')return notify('Stop the current hardware operation before archiving this project.','warning');
  if(!confirm(`Archive ${active.name}? All protected files stay in its project folder.`))return;
  try{
    await window.tuniq.updateProject({id:active.id,name:active.name,vehicleId:active.vehicleId||'',vehicle:active.vehicle||'',controller:active.controller||'',os:active.os||'',notes:active.notes||'',archived:true});
    const alternatives=(state.projects||[]).filter(item=>item.id!==active.id&&!item.archived);
    if(alternatives[0])await switchActiveProject(alternatives[0].id);else{showPage('workflow',{restoreScroll:false});resetProjectForm();}
    await loadProjects();await refreshWorkspace(true);
    notify(`${active.name} archived. Its BINs, evidence, revisions, and reports were preserved.`,'success',8000);
  }catch(error){notify(error.message,'error',9000)}
}

async function switchActiveProject(projectId){
  if(!projectId||projectId===state.activeProject?.id)return state.activeProject;
  try{
    state.activeProject=await window.tuniq.setActiveProject(projectId);
    state.quickServiceReview=null;state.quickServiceProposal=null;state.quickServicePlanConfirmed=false;state.p01AutoRequestReview=null;state.p01AutoConfirmedFingerprint=null;
    updateActiveProject();
    renderQuickService();renderP01AutoRequestReview();
    await loadProjects();
    await refreshProjectFiles();
    invalidateCalibration('The active project changed. Load its BIN and XDF before editing or exporting.');
    await refreshWorkspace(true);
    notify(`Active project: ${state.activeProject.name}`,'success');
    return state.activeProject;
  }catch(error){renderHeaderProjectSwitcher();notify(error.message,'error');throw error}
}
async function loadProjects(){
  const items=await window.tuniq.listProjects();
  state.projects=Array.isArray(items)?items:[];
  state.archivedProjects=state.projects.filter(item=>item.archived);
  state.projects=state.projects.filter(item=>!item.archived||item.id===state.activeProject?.id);
  renderHeaderProjectSwitcher();
  $('#projects').innerHTML=state.projects.length?state.projects.map(project=>`<article class="project-card"><div class="project-card-main"><b>⚙ ${safe(project.name)}</b><p>${safe(project.vehicle||'No vehicle')} • ${safe(project.controller||'Controller unknown')}${project.os?` • OS ${safe(project.os)}`:''}</p>${project.notes?`<small class="project-notes">${safe(project.notes)}</small>`:''}<small>${project.updatedAt?`Updated ${new Date(project.updatedAt).toLocaleString()}`:project.createdAt?new Date(project.createdAt).toLocaleString():'Date unavailable'}</small></div><div class="project-card-actions"><button class="edit-project ghost" data-project-id="${safe(project.id)}">Edit</button><button class="activate-project ghost" data-project-id="${safe(project.id)}">${state.activeProject?.id===project.id?'✓ Active':'Set Active'}</button></div></article>`).join(''):'<div class="empty-card compact"><div class="empty-icon">⚙</div><h3>No projects yet</h3><p>Create one on the left. TunIQ will build protected Originals, Definitions, Revisions, Logs, and Backups folders.</p></div>';
  $$('.edit-project').forEach(button=>button.onclick=()=>beginProjectEdit(state.projects.find(project=>project.id===button.dataset.projectId)));
  $$('.activate-project').forEach(button=>button.onclick=()=>switchActiveProject(button.dataset.projectId).catch(()=>{}));
}



let calSelection=new Set(),calAnchor=null,calUndo=[],calRedo=[],calClipboard=[];
let calibrationInitialized=false,calibrationInitializing=null,calibrationControlsBound=false;
function clone(v){return JSON.parse(JSON.stringify(v))}
function calKey(r,c){return `${r}:${c}`}
function currentCal(){return state.calibration?.tables?.[state.calibration.activeTable]||null}
function normalizeCalibration(workspace){
  if(!workspace||typeof workspace!=='object'||!workspace.tables||typeof workspace.tables!=='object')throw new Error('Calibration workspace is missing or invalid.');
  const keys=Object.keys(workspace.tables);
  if(!keys.length)throw new Error('Calibration workspace does not contain any tables.');
  if(!workspace.activeTable||!workspace.tables[workspace.activeTable])workspace.activeTable=keys[0];
  workspace.modified=workspace.modified&&typeof workspace.modified==='object'?workspace.modified:{};
  workspace.stock=workspace.stock&&typeof workspace.stock==='object'?workspace.stock:clone(workspace.tables);
  for(const key of keys){
    const table=workspace.tables[key];
    if(!table||!Array.isArray(table.values)||!table.values.length)throw new Error(`Calibration item ${key} does not contain a readable value grid.`);
    if(table.values.length>256)throw new Error(`Calibration item ${key} exceeds the supported 256-row display limit.`);
    const columns=Array.isArray(table.values[0])?table.values[0].length:0;
    if(!columns||columns>256)throw new Error(`Calibration item ${key} has an unsupported column count.`);
    table.values=table.values.map(row=>{
      if(!Array.isArray(row)||row.length!==columns)throw new Error(`Calibration item ${key} contains a non-rectangular value grid.`);
      return row.map(value=>{const numeric=Number(value);if(!Number.isFinite(numeric))throw new Error(`Calibration item ${key} contains a non-numeric value.`);return numeric});
    });
    table.rowHeaders=Array.isArray(table.rowHeaders)&&table.rowHeaders.length===table.values.length?table.rowHeaders:table.values.map((_,i)=>String(i));
    table.colHeaders=Array.isArray(table.colHeaders)&&table.colHeaders.length===columns?table.colHeaders:Array.from({length:columns},(_,i)=>String(i));
  }
  return workspace;
}
function pushCalUndo(){if(!state.calibration)return;calUndo.push(clone(state.calibration));if(calUndo.length>30)calUndo.shift();calRedo=[]}
function markModified(tableKey,r,c){const table=state.calibration?.tables?.[tableKey];if(!table)return;const stock=state.calibration.stock?.[tableKey]?.values?.[r]?.[c];const value=table.values?.[r]?.[c];const key=`${tableKey}:${r}:${c}`;if(Number(value)===Number(stock))delete state.calibration.modified[key];else state.calibration.modified[key]=true}
function validateCalibration(){const table=currentCal(),el=$('#labValidation');if(!table){el.textContent='⚠ No table loaded';el.className='validation-bad';return false}if(table.unsupportedReason){el.textContent=`READ ONLY · ${table.unsupportedReason}`;el.className='validation-bad';return true}let invalid=0;const min=Number(table.min),max=Number(table.max),hasMin=table.min!==null&&table.min!==undefined&&table.min!==''&&Number.isFinite(min),hasMax=table.max!==null&&table.max!==undefined&&table.max!==''&&Number.isFinite(max);for(const row of table.values)for(const value of row){const numeric=Number(value);if(!Number.isFinite(numeric)||(hasMin&&numeric<min)||(hasMax&&numeric>max))invalid++}const range=hasMin||hasMax?` (${hasMin?min:'−∞'}–${hasMax?max:'∞'})`:'';el.textContent=invalid?`⚠ ${invalid} invalid value${invalid===1?'':'s'}${range}`:'✓ Values within defined range';el.className=invalid?'validation-bad':'validation-ok';return invalid===0}
async function persistCalibration(){if(!state.calibration)return;state.calibration=normalizeCalibration(await window.tuniq.saveCalibration(state.calibration));$('#labSaveState').textContent=`Saved ${new Date().toLocaleTimeString()}`}
function renderCalTables(){
  const list=$('#calTableList');if(!state.calibration){list.innerHTML='<p class="muted">Open the Calibration Lab to load tables.</p>';return}
  const active=state.calibration.activeTable,query=String($('#calTableSearch')?.value||'').trim().toLowerCase();
  const entries=Object.entries(state.calibration.tables).filter(([key,t])=>!query||[key,t.name,t.category,t.description,t.unit].some(value=>String(value||'').toLowerCase().includes(query))).slice(0,800);
  const groups=new Map();for(const entry of entries){const category=entry[1].category||'Uncategorized';if(!groups.has(category))groups.set(category,[]);groups.get(category).push(entry)}
  list.innerHTML=entries.length?[...groups.entries()].map(([category,items])=>`<div class="cal-category"><b>${safe(category)}</b>${items.map(([key,t])=>{const rows=Array.isArray(t.values)?t.values.length:0,cols=rows&&Array.isArray(t.values[0])?t.values[0].length:0;return `<button class="cal-table-btn ${key===active?'active':''}" data-cal-table="${safe(key)}"><span>${safe(t.name||key)}</span><small>${rows} × ${cols}${t.unit?` · ${safe(t.unit)}`:''}</small></button>`}).join('')}</div>`).join(''):'<p class="muted">No mapped parameters match this search.</p>';
  $$('[data-cal-table]').forEach(b=>b.onclick=()=>{state.calibration.activeTable=b.dataset.calTable;calSelection.clear();calAnchor=null;renderCalibration()})
}
function renderCalGrid(){
  const table=currentCal(),grid=$('#calGrid');
  if(!table){grid.innerHTML='<tbody><tr><td style="padding:24px">No calibration table is loaded.</td></tr></tbody>';return}
  $('#labTableTitle').textContent=table.name||'Calibration Table';
  $('#labUnit').textContent=table.unit||'TABLE';
  let html='<thead><tr><th class="corner">Row / Axis</th>'+table.colHeaders.map(value=>`<th>${safe(value)}</th>`).join('')+'</tr></thead><tbody>';
  table.values.forEach((row,r)=>{
    html+=`<tr><th>${safe(table.rowHeaders[r]??r)}</th>`+row.map((value,c)=>{
      const selected=calSelection.has(calKey(r,c));
      const modified=state.calibration.modified[`${state.calibration.activeTable}:${r}:${c}`];
      return `<td><input class="cal-cell ${selected?'selected':''} ${modified?'modified':''}" data-r="${r}" data-c="${c}" type="number" step="0.01" value="${safe(value)}" ${table.unsupportedReason?'disabled title="Read-only unsupported XDF definition"':''}></td>`;
    }).join('')+'</tr>';
  });
  grid.innerHTML=html+'</tbody>';
  $$('.cal-cell').forEach(cell=>{
    cell.onmousedown=event=>selectCalCell(event.target,event.shiftKey);
    cell.onfocus=event=>{
      const key=calKey(+event.target.dataset.r,+event.target.dataset.c);
      if(!calSelection.has(key))selectCalCell(event.target,false);
    };
    cell.onchange=async event=>{
      const value=Number(event.target.value);
      if(!Number.isFinite(value)){event.target.value=currentCal().values[+event.target.dataset.r][+event.target.dataset.c];return}
      pushCalUndo();
      const r=+event.target.dataset.r,c=+event.target.dataset.c;
      currentCal().values[r][c]=value;
      markModified(state.calibration.activeTable,r,c);
      validateCalibration();
      renderCalGrid();
      updateCalCount();
      try{await persistCalibration()}catch(error){showCalibrationFailure(error)}
    };
  });
  validateCalibration();
}
function selectCalCell(cell,extend=false){const r=+cell.dataset.r,c=+cell.dataset.c;if(!extend||!calAnchor){calSelection.clear();calAnchor={r,c};calSelection.add(calKey(r,c))}else{calSelection.clear();for(let rr=Math.min(r,calAnchor.r);rr<=Math.max(r,calAnchor.r);rr++)for(let cc=Math.min(c,calAnchor.c);cc<=Math.max(c,calAnchor.c);cc++)calSelection.add(calKey(rr,cc))}$$('.cal-cell').forEach(x=>x.classList.toggle('selected',calSelection.has(calKey(+x.dataset.r,+x.dataset.c))))}
function updateCalCount(){const count=Object.keys(state.calibration?.modified||{}).length;$('#labModifiedCount').textContent=`${count} modified`}
function renderCalHistory(){
  const items=state.calHistory||[],list=$('#calHistory');
  list.innerHTML=items.length?items.slice(0,12).map(x=>`<article class="snapshot-item"><div><b>${safe(x.name)}</b><small>${new Date(x.at).toLocaleString()} · ${Number(x.modifiedCells||0)} changed cell${Number(x.modifiedCells||0)===1?'':'s'}</small></div><div class="snapshot-actions"><button class="ghost cal-snapshot-compare" data-id="${safe(x.id)}">Compare</button><button class="ghost cal-snapshot-restore" data-id="${safe(x.id)}">Restore</button></div></article>`).join(''):'<p class="muted">No project snapshots yet.</p>';
  $$('.cal-snapshot-compare').forEach(button=>button.onclick=()=>compareCalibrationSnapshot(button.dataset.id));
  $$('.cal-snapshot-restore').forEach(button=>button.onclick=()=>restoreCalibrationSnapshot(button.dataset.id));
}
async function compareCalibrationSnapshot(id){
  try{
    const result=await window.tuniq.compareCalibrationSnapshot(id),box=$('#calSnapshotCompare');
    const details=(result.details||[]).slice(0,20).map(item=>`<li><b>${safe(item.table)}</b> · ${safe(item.rowLabel)} / ${safe(item.columnLabel)}: ${safe(item.from)} → ${safe(item.to)}</li>`).join('');
    box.innerHTML=`<button class="snapshot-close" aria-label="Close">×</button><b>${safe(result.snapshot?.name||'Snapshot comparison')}</b><span>${Number(result.changedCells||0)} changed cells · ${Number(result.addedTables||0)} added tables · ${Number(result.removedTables||0)} removed tables</span>${details?`<ul>${details}</ul>`:'<p>No cell differences from the current workspace.</p>'}${result.truncated?'<small>Only the first 20 changes are shown here.</small>':''}`;
    box.classList.remove('hidden');box.querySelector('.snapshot-close').onclick=()=>box.classList.add('hidden');
  }catch(error){alert(error.message)}
}
async function restoreCalibrationSnapshot(id){
  const item=(state.calHistory||[]).find(entry=>entry.id===id);if(!item)return;
  if(!confirm(`Restore ${item.name} into the current project workspace?\n\nTunIQ will preserve the current workspace as the automatic backup. No BIN file will be written.`))return;
  try{
    state.calibration=normalizeCalibration(await window.tuniq.restoreCalibrationSnapshot(id));
    state.calHistory=await window.tuniq.listCalibrationHistory();calUndo.length=0;calRedo.length=0;calSelection.clear();calAnchor=null;renderCalibration();notify(`Restored ${item.name} to the project workspace.`,'success');
  }catch(error){alert(error.message)}
}
function renderCalibration(){
  if(!state.calibration)return;
  normalizeCalibration(state.calibration);
  renderCalTables();
  renderCalGrid();
  updateCalCount();
  renderCalHistory();
  const isXdf=state.calibration.mode==='xdf';
  const sameProject=!isXdf||!state.calibration.projectId||state.calibration.projectId===state.activeProject?.id;
  const binding=state.calibration.binding||{};$('#labSourceBadge').textContent=isXdf?(sameProject?`BOUND · ${(binding.binSha256||'').slice(0,8)}`:'OTHER PROJECT WORKSPACE'):'PROJECT PRACTICE';
  $('#labSourceBadge').classList.toggle('source-warning',!sameProject);
  $('#labExportBin').disabled=!isXdf||!sameProject;
  const summary=state.calibration.mappingSummary;
  if(!sameProject)$('#labSaveState').textContent='Reload BIN + XDF for the active project before exporting';
  else if(summary&&summary.skipped)$('#labSaveState').textContent=`Loaded ${summary.loaded}; ${summary.skipped} oversized mappings skipped for stability`;
}
function invalidateCalibration(message='Reload the active project BIN and XDF to continue.'){
  calibrationInitialized=false;
  calibrationInitializing=null;
  state.calibration=null;
  calSelection.clear();calAnchor=null;calUndo.length=0;calRedo.length=0;
  $('#labSourceBadge').textContent='RELOAD REQUIRED';
  $('#labSourceBadge').classList.add('source-warning');
  $('#labExportBin').disabled=true;
  $('#labTableTitle').textContent='Calibration workspace needs reloading';
  $('#labUnit').textContent='PROJECT CHANGED';
  $('#labValidation').textContent='⚠ Reload BIN + XDF';
  $('#labValidation').className='validation-bad';
  $('#calTableList').innerHTML='<p class="muted">No active mapping loaded.</p>';
  $('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal">${safe(message)}</td></tr></tbody>`;
  $('#labModifiedCount').textContent='0 modified';
}
function showCalibrationFailure(error){console.error(error);$('#labTableTitle').textContent='Calibration recovery mode';$('#labUnit').textContent='STARTUP PROTECTED';$('#labValidation').textContent='⚠ Workspace could not be loaded';$('#labValidation').className='validation-bad';$('#calGrid').innerHTML=`<tbody><tr><td style="padding:24px;white-space:normal"><b>TunIQ stayed open.</b><br>${safe(error?.message||error)}<br><br>The original workspace is preserved in AppData if recovery was required.</td></tr></tbody>`}
async function applyCalOperation(){if(!calSelection.size)return alert('Select one or more cells first.');const table=currentCal();if(!table)return;const amount=Number($('#labAmount').value);if(!Number.isFinite(amount))return;pushCalUndo();const op=$('#labOperation').value;for(const key of calSelection){const [r,c]=key.split(':').map(Number);let v=Number(table.values[r][c]);if(op==='add')v+=amount;if(op==='subtract')v-=amount;if(op==='multiply')v*=amount;if(op==='percent')v*=1+amount/100;table.values[r][c]=Number(v.toFixed(3));markModified(state.calibration.activeTable,r,c)}renderCalibration();await persistCalibration()}
function bindCalibrationControls(){
  if(calibrationControlsBound)return;
  calibrationControlsBound=true;
  $('#calTableSearch').oninput=renderCalTables;
  $('#labApply').onclick=()=>applyCalOperation().catch(error=>alert(error.message));
  $('#labUndo').onclick=async()=>{try{if(!calUndo.length)return;calRedo.push(clone(state.calibration));state.calibration=calUndo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labRedo').onclick=async()=>{try{if(!calRedo.length)return;calUndo.push(clone(state.calibration));state.calibration=calRedo.pop();renderCalibration();await persistCalibration()}catch(error){alert(error.message)}};
  $('#labCopy').onclick=()=>{
    const table=currentCal();if(!table||!calSelection.size)return;
    calClipboard=[...calSelection].map(key=>{const [r,c]=key.split(':').map(Number);return table.values[r][c]});
    navigator.clipboard?.writeText(calClipboard.join('\t')).catch(()=>{});
  };
  $('#labPaste').onclick=async()=>{try{
    const table=currentCal();if(!table||!calSelection.size||!calClipboard.length)return;
    pushCalUndo();let index=0;
    for(const key of calSelection){const [r,c]=key.split(':').map(Number);table.values[r][c]=Number(calClipboard[index%calClipboard.length]);markModified(state.calibration.activeTable,r,c);index++}
    renderCalibration();await persistCalibration();
  }catch(error){alert(error.message)}};
  $('#labSaveRevision').onclick=async()=>{try{
    if(!state.calibration)return;
    const name=prompt('Snapshot name',`Snapshot ${(state.calHistory||[]).length+1}`);if(!name)return;
    const note=prompt('Optional note describing what changed','')||'';
    await persistCalibration();await window.tuniq.createCalibrationRevision({name,note});state.calHistory=await window.tuniq.listCalibrationHistory();renderCalHistory();renderRevisionWorkspace();notify(`Saved ${name} for ${state.activeProject?.name||'the active project'}.`,'success');
  }catch(error){alert(error.message)}};
  $('#labReset').onclick=async()=>{try{
    if(!state.calibration)return;
    const label=state.calibration.mode==='xdf'?'original imported BIN values':'stock practice values';
    if(!confirm(`Reset every calibration table to the ${label}?`))return;
    pushCalUndo();
    if(state.calibration.mode==='xdf'){
      state.calibration.tables=clone(state.calibration.stock);
      state.calibration.modified={};
      state.calibration.activeTable=Object.keys(state.calibration.tables)[0];
      await persistCalibration();
    }else{
      state.calibration=normalizeCalibration(await window.tuniq.resetCalibration());
    }
    calSelection.clear();calAnchor=null;renderCalibration();
  }catch(error){alert(error.message)}};
}
async function initCalibration(){bindCalibrationControls();state.calibration=normalizeCalibration(await window.tuniq.loadCalibration());state.calHistory=await window.tuniq.listCalibrationHistory();state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];renderCalibration();renderRevisionWorkspace();calibrationInitialized=true}
async function ensureCalibrationInitialized(){if(calibrationInitialized)return state.calibration;if(calibrationInitializing)return calibrationInitializing;$('#labTableTitle').textContent='Loading calibration workspace…';calibrationInitializing=initCalibration().finally(()=>{calibrationInitializing=null});return calibrationInitializing}


function definitionStatusLabel(status){return ({bound:'BOUND','commissioning-only-bound':'SETUP-ONLY BOUND', 'exact-xdf-found':'EXACT XDF FOUND','up-xml-found':'UP XML FOUND','job-output-ready':'OUTPUT READY','job-waiting':'JOB WAITING','multiple-xdfs':'REVIEW REQUIRED','multiple-up-xml':'REVIEW REQUIRED','universal-patcher-incomplete':'UP INCOMPLETE','missing-definition':'DEFINITION MISSING','no-project':'NO PROJECT'}[status]||String(status||'not scanned').replace(/-/g,' ').toUpperCase())}
function renderDefinitionCenter(center=state.definitionCenter){
  const panel=$('#definitionCenter');if(!panel)return;
  center=center||{status:'no-project',message:'Create or activate a project first.',xdfs:[],universalXml:[]};state.definitionCenter=center;
  $('#definitionStatus').textContent=definitionStatusLabel(center.status);
  $('#definitionSummary').textContent=center.message||'Definition Center is waiting.';
  const up=center.universalPatcher||{};
  $('#definitionFacts').innerHTML=[
    `Project OS: ${center.os||'not identified'}`,
    `Exact XDF candidates: ${(center.xdfs||[]).length}`,
    `Exact Universal Patcher XML: ${(center.universalXml||[]).length}`,
    `Universal Patcher: ${up.complete?'complete folder ready':up.installed?'incomplete install':'not configured'}`,
    `Scanned definition files: ${Number(center.scannedFiles||0).toLocaleString()}`,
    center.bound?`Bound definition: ${center.bound.name}`:'Bound definition: none'
  ].map(text=>`<span>${safe(text)}</span>`).join('');
  const candidates=[...(center.xdfs||[]).map(item=>({...item,sourceLabel:'TunerPro XDF'})),...(center.universalXml||[]).map(item=>({...item,sourceLabel:'Universal Patcher XML'})),...((center.job?.accepted)||[]).map(item=>({...item,sourceLabel:'Managed job output'}))];
  $('#definitionCandidates').innerHTML=candidates.length?candidates.map(item=>`<article class="doctor-issue"><div><b>${safe(item.name||item.path?.split(/[\\/]/).pop())}</b><small>${safe(item.sourceLabel)} · OS ${safe((item.osCandidates||[]).join(', ')||center.os)} · ${Number(item.tableCount||item.usableTables?.length||0).toLocaleString()} items${item.warnings?.length?` · ${item.warnings.length} warning(s)`:''}</small></div><button class="ghost definition-bind" data-source="${safe(item.path)}">Bind Exact Source</button></article>`).join(''):`<article class="doctor-issue"><div><b>No exact source found yet</b><small>${safe(center.job?.folder?'A managed job exists. Universal Patcher can generate/export an exact definition into its Output folder.':'Run a deep scan or create a managed Universal Patcher job.')}</small></div></article>`;
  $$('.definition-bind').forEach(button=>button.onclick=async()=>{button.disabled=true;try{const result=await window.tuniq.bindDefinitionCandidate(button.dataset.source);state.definitionCenter=result.center;invalidateCalibration('The exact definition changed. Reload the active BIN and definition before tuning.');await refreshProjectFiles();await refreshWorkspace(true);notify('Exact OS definition bound to the project.','success')}catch(error){notify(error.message,'error')}finally{button.disabled=false}});
  $('#definitionUniversal').disabled=!center.active||!up.complete;
  $('#definitionTunerPro').disabled=!center.active||!center.bound||!center.tools?.tunerPro;
  $('#definitionCheckTunerPro').disabled=!center.active||!center.bound||!center.tools?.tunerPro;
  $('#definitionImportTunerPro').disabled=!(state.tunerProRoundtrip?.readyBins?.length===1);
  $('#definitionOpenJob').disabled=!center.active;
  $('#definitionActionStatus').textContent=center.job?.error?center.job.error:center.job?.folder?`Managed job: ${center.job.folder}`:'TunIQ accepts only an exact OS match with explicit table addresses.';
}
async function refreshDefinitionCenter(deep=false){const center=await window.tuniq.scanDefinitions({deep});state.definitionCenter=center;renderDefinitionCenter(center);return center}
async function resolveDefinitionCenter(){const button=$('#definitionResolve');button.disabled=true;if(!(state.p01?.identity?.os||state.activeProject?.os)){button.disabled=false;$('#definitionActionStatus').textContent='Controller identity is missing. Starting Read Controller Properties first…';notify('TunIQ must identify the PCM before resolving an OS-matched definition. Starting P01 setup now.','warning',6500);return continueP01Commissioning({commissioningOnly:true})}$('#definitionActionStatus').textContent='Scanning XDF sources and the Universal Patcher definition database…';try{const result=await window.tuniq.resolveDefinition({deep:true});state.definitionCenter=result.center;renderDefinitionCenter(result.center);if(result.resolved){invalidateCalibration('The definition binding changed. Reload the active BIN and definition before tuning.');await refreshProjectFiles();await refreshWorkspace(true);notify(result.limited?'P01 hardware-setup definition bound. Setup can finish; tuning stays locked.':'Definition Center resolved and bound the exact OS definition.',result.limited?'warning':'success',7000)}else{notify('No exact definition could be bound automatically. A managed definition job is ready.','warning')}}catch(error){notify(error.message,'error');$('#definitionActionStatus').textContent=error.message}finally{button.disabled=false}}
async function importDefinitionSources(){try{const result=await window.tuniq.importDefinitionSources();state.definitionCenter=result.center;renderDefinitionCenter(result.center);if(result.imported?.length){notify(`Imported ${result.imported.length} definition source file(s).`,'success');await resolveDefinitionCenter()}}catch(error){notify(error.message,'error')}}
async function launchUniversalDefinitionJob(){const button=$('#definitionUniversal');button.disabled=true;try{const result=await window.tuniq.launchUniversalPatcherDefinitionJob();state.definitionCenter=result.center;renderDefinitionCenter(result.center);notify('Universal Patcher opened with the protected job BIN. TunIQ will accept only exact-OS output from the managed job.','info',7000)}catch(error){notify(error.message,'error')}finally{button.disabled=false}}
async function launchTunerProRoundtrip(){try{const result=await window.tuniq.launchTunerProRoundtrip();state.tunerProRoundtrip=result.status||null;renderDefinitionCenter();notify(`Managed TunerPro workspace created in ${result.folder}. Save only the working BIN; the protected original remains untouched.`,'info',8000)}catch(error){notify(error.message,'error')}}
async function inspectTunerProRoundtrip(){try{const result=await window.tuniq.inspectTunerProRoundtrip();state.tunerProRoundtrip=result;renderDefinitionCenter();if(!result)$('#definitionActionStatus').textContent='No managed TunerPro roundtrip exists yet.';else if(result.readyBins?.length===1)$('#definitionActionStatus').textContent=`TunerPro change ready: ${result.readyBins[0].name} · ${result.readyBins[0].comparison.changedBytes} changed bytes.`;else if(result.readyBins?.length>1)$('#definitionActionStatus').textContent='Multiple changed TunerPro BINs were found. Keep only the intended output.';else $('#definitionActionStatus').textContent='Managed TunerPro roundtrip is waiting for a changed compatible working BIN.';return result}catch(error){notify(error.message,'error');return null}}
async function importTunerProRoundtrip(){if(!confirm('Import the changed TunerPro working BIN as a NEW project revision? The protected original remains unchanged.'))return;try{const result=await window.tuniq.importTunerProRoundtrip();state.tunerProRoundtrip=result.job;renderDefinitionCenter();await refreshProjectFiles();await refreshWorkspace(true);notify(`Imported ${result.revision.name}. Run managed Universal Patcher checksum validation before Test Write.`,'success',8000)}catch(error){notify(error.message,'error')}}

async function refreshProjectFiles(){
  const card=$('#projectFilesCard');
  if(!card)return;
  try{
    const files=await window.tuniq.getProjectFiles();
    state.activeProject=files.active||null;
    updateActiveProject();
    if(!files.active){
      card.className='empty-card compact';
      card.innerHTML='<div class="empty-icon">▤</div><h2>No active project</h2><p>Create or activate a project before importing a BIN or XDF.</p><button id="filesGoWorkflow">Go to Tune Workflow</button>';
      $('#filesGoWorkflow').onclick=()=>showPage('workflow');
      return;
    }
    const binHash=files.bin?.sha256?`${safe(files.bin.sha256.slice(0,16))}…`:'Unavailable';
    const xdfDetail=files.xdf?.error?`Definition warning: ${safe(files.xdf.error)}`:`${Number(files.xdf?.tableCount||0).toLocaleString()} mapped items · ${safe(files.xdf?.title||'')}`;
    card.className='panel project-files';
    card.innerHTML=`<div class="panel-title"><h3>${safe(files.active.name)}</h3><span>${safe(files.active.controller||'Controller unknown')}</span></div><div class="file-status-row"><div><b>Original BIN</b><span>${files.bin?safe(files.bin.name):'Not imported'}</span>${files.bin?`<small>${Number(files.bin.size||0).toLocaleString()} bytes · SHA-256 ${binHash}</small>`:''}</div><i class="${files.bin?'green':'amber'}"></i></div><div class="file-status-row"><div><b>TunerPro XDF</b><span>${files.xdf?safe(files.xdf.name):'Not imported'}</span>${files.xdf?`<small>${xdfDetail}</small>`:''}</div><i class="${files.xdf&&!files.xdf.error?'green':'amber'}"></i></div>${files.bin&&files.xdf&&!files.xdf.error?'<button id="filesLoadLab">Open Mapping in Calibration Lab</button>':''}`;
    const openButton=$('#filesLoadLab');
    if(openButton)openButton.onclick=loadRealCalibration;
  }catch(error){
    card.className='empty-card compact';
    card.innerHTML=`<div class="empty-icon">⚠</div><h2>Project files unavailable</h2><p>${safe(error.message)}</p>`;
  }
}
async function loadRealCalibration(){
  try{
    bindCalibrationControls();
    $('#labTableTitle').textContent='Loading BIN + XDF mapping…';
    state.calibration=normalizeCalibration(await window.tuniq.loadXdfCalibration());
    state.calHistory=await window.tuniq.listCalibrationHistory();
    state.calHistory=Array.isArray(state.calHistory)?state.calHistory:[];
    calibrationInitialized=true;
    calUndo.length=0;calRedo.length=0;calSelection.clear();calAnchor=null;
    renderCalibration();
    await refreshWorkspace(true);
    showPage('sandbox');
    const summary=state.calibration.mappingSummary;
    status(`Loaded ${Object.keys(state.calibration.tables).length} XDF items from ${state.activeProject?.name||'the active project'}.${summary?.skipped?` ${summary.skipped} oversized items were skipped for stability.`:''}`);
  }catch(error){
    showCalibrationFailure(error);
    alert(error.message);
  }
}



// TunIQ AI/community surfaces plus 1.6 controlled tuning and connected diagnostics rendering.
function selectedAiMods(){return $$('.ai-mod:checked').map(input=>input.value)}
function needsCamDetails(){const goal=($('#aiTuneGoal')?.value||'').toLowerCase();return selectedAiMods().includes('Aftermarket camshaft')||goal.includes('camshaft')}
function updateAiCamVisibility(){const card=$('#aiCamFields');if(card)card.classList.toggle('hidden',!needsCamDetails())}
const engineCatalogApi=window.TunIQEngineCatalog||null;
function engineOption(value,label=value){const option=document.createElement('option');option.value=value;option.textContent=label;return option}
function engineSelectionFromControls(){return {family:$('#aiEngineFamily')?.value||'',displacement:$('#aiEngineDisplacement')?.value||'',code:$('#aiEngineCode')?.value||'',custom:$('#aiEngineCustom')?.value||''}}
function syncEngineSelection(){
  const selection=engineSelectionFromControls();
  const label=engineCatalogApi?.composeEngineLabel(selection)||selection.custom||[selection.family,selection.displacement,selection.code].filter(Boolean).join(' / ');
  setValue('#aiEngine',label);
  const summary=$('#aiEngineSummary');
  if(summary){
    const complete=selection.family==='Custom / Other'?Boolean(selection.custom.trim()):Boolean(selection.family&&selection.displacement&&selection.code);
    summary.classList.toggle('ready',complete);
    summary.textContent=complete?`Selected engine: ${label}`:'Choose the family, displacement, and engine code. Example: LS → 5.3L → LM7.';
  }
  return {...selection,label};
}
function populateEngineCodes(family,displacement,selected=''){
  const code=$('#aiEngineCode');if(!code)return;
  code.innerHTML='';code.append(engineOption('','Choose engine code'));
  const group=engineCatalogApi?.groupEntry(family,displacement);
  (group?.codes||[]).forEach(item=>code.append(engineOption(item)));
  code.disabled=!(group?.codes?.length);
  if(selected&&[...code.options].some(option=>option.value===selected))code.value=selected;
  else if(group?.codes?.length===1)code.value=group.codes[0];
}
function populateEngineDisplacements(family,selectedDisplacement='',selectedCode=''){
  const displacement=$('#aiEngineDisplacement');if(!displacement)return;
  displacement.innerHTML='';displacement.append(engineOption('','Choose displacement'));
  const entry=engineCatalogApi?.familyEntry(family);
  (entry?.groups||[]).forEach(group=>displacement.append(engineOption(group.displacement)));
  displacement.disabled=!(entry?.groups?.length);
  if(selectedDisplacement&&[...displacement.options].some(option=>option.value===selectedDisplacement))displacement.value=selectedDisplacement;
  else if(entry?.groups?.length===1)displacement.value=entry.groups[0].displacement;
  populateEngineCodes(family,displacement.value,selectedCode);
}
function applyEngineSelection(selection={}){
  const family=$('#aiEngineFamily');if(!family)return;
  const wantedFamily=selection.family||'';
  if(wantedFamily&&[...family.options].some(option=>option.value===wantedFamily))family.value=wantedFamily;else family.value='';
  populateEngineDisplacements(family.value,selection.displacement||'',selection.code||'');
  const customWrap=$('#aiEngineCustomWrap');
  const custom=family.value==='Custom / Other';
  customWrap?.classList.toggle('hidden',!custom);
  setValue('#aiEngineCustom',selection.custom||'');
  syncEngineSelection();
}
function initializeEngineSelector(){
  const family=$('#aiEngineFamily');if(!family||family.dataset.ready==='1')return;
  family.innerHTML='';family.append(engineOption('','Choose engine family'));
  (engineCatalogApi?.catalog||[]).forEach(item=>family.append(engineOption(item.family)));
  family.dataset.ready='1';
  family.onchange=()=>{populateEngineDisplacements(family.value);const custom=family.value==='Custom / Other';$('#aiEngineCustomWrap')?.classList.toggle('hidden',!custom);syncEngineSelection()};
  $('#aiEngineDisplacement').onchange=()=>{populateEngineCodes(family.value,$('#aiEngineDisplacement').value);syncEngineSelection()};
  $('#aiEngineCode').onchange=syncEngineSelection;
  $('#aiEngineCustom').oninput=syncEngineSelection;
}
function optionalSpecInputs(){return [['gearRatio','#aiGearRatio'],['tireSize','#aiTireSize'],['converterStall','#aiConverterStall'],['desiredIdle','#aiDesiredIdle']]}
function updateOptionalSpecState(){
  const values=optionalSpecInputs().filter(([,selector])=>$(selector)?.value.trim()).map(([key])=>key);
  const box=$('#aiOptionalSpecState');if(!box)return;
  box.classList.toggle('has-values',values.length>0);box.classList.toggle('blank-values',values.length===0);
  box.textContent=values.length?`Saved details available: ${values.map(key=>({gearRatio:'gear ratio',tireSize:'tire size',converterStall:'converter stall',desiredIdle:'desired idle'}[key])).join(', ')}. Blank items remain unknown.`:'Blank optional values remain unknown. TunIQ will not silently treat them as stock specifications.';
}
function knownVehicleContext(){
  const active=state.activeProject;
  return state.vehicles.find(vehicle=>vehicle.id===active?.vehicleId)||state.vehicles.find(vehicle=>vehicle.name===active?.vehicle)||state.vehicles.find(vehicle=>vehicle.name===($('#aiVehicle')?.value||''))||null;
}
function extractKnownOptionalSpecs(text=''){
  const value=String(text||'');
  const first=(regex)=>value.match(regex)?.[1]||'';
  return {
    gearRatio:first(/(?:gear(?:\s+ratio)?|rear\s+gear|axle)\s*(?:is|:|=|-)?\s*(\d\.\d{2})/i),
    tireSize:first(/\b(\d{3}\/\d{2}R\d{2}|\d{2,3}x\d{1,2}(?:\.\d+)?R?\d{2})\b/i),
    converterStall:first(/(?:converter\s+stall|stall)\s*(?:is|:|=|-)?\s*(\d{3,4})(?:\s*rpm)?/i),
    desiredIdle:first(/(?:desired\s+idle|idle)\s*(?:is|:|=|-)?\s*(\d{3,4})(?:\s*rpm)?/i)
  };
}
function useKnownOptionalSpecs(){
  const vehicle=knownVehicleContext();
  const active=state.activeProject;
  const found=extractKnownOptionalSpecs([vehicle?.notes,active?.notes].filter(Boolean).join(' | '));
  let filled=0;
  for(const [key,selector] of optionalSpecInputs())if(!$(selector).value.trim()&&found[key]){$(selector).value=found[key];filled++}
  updateOptionalSpecState();
  const box=$('#aiOptionalSpecState');
  if(filled)box.textContent=`Filled ${filled} confirmed value${filled===1?'':'s'} from saved Garage/project notes. Review them before generating the plan.`;
  else box.textContent='No confirmed gear, tire, converter, or idle values were found in the saved vehicle/project. They were left blank.';
}
function collectAiPayload(){
  const engine=syncEngineSelection();
  return {
    vehicle:$('#aiVehicle').value,engine:engine.label,engineFamily:engine.family,engineDisplacement:engine.displacement,engineCode:engine.code,engineCustom:engine.custom,transmission:$('#aiTransmission').value,fuel:$('#aiFuel').value,aspiration:$('#aiAspiration').value,tuneGoal:$('#aiTuneGoal').value,drivingUse:$('#aiDrivingUse').value,
    modifications:selectedAiMods(),injectorData:$('#aiInjectorData').value,gearRatio:$('#aiGearRatio').value,tireSize:$('#aiTireSize').value,converterStall:$('#aiConverterStall').value,desiredIdle:$('#aiDesiredIdle').value,symptoms:$('#aiSymptoms').value,notes:$('#aiBuildNotes').value,
    controller:state.activeProject?.controller||'',operatingSystem:state.activeProject?.os||'',cam:{brand:$('#aiCamBrand').value,partNumber:$('#aiCamPart').value,durationIntake:$('#aiCamDurationI').value,durationExhaust:$('#aiCamDurationE').value,liftIntake:$('#aiCamLiftI').value,liftExhaust:$('#aiCamLiftE').value,lsa:$('#aiCamLsa').value,icl:$('#aiCamIcl').value}
  }
}
function setValue(id,value){const el=$(id);if(el)el.value=value||''}
function fillAiForm(intake){
  const active=state.activeProject;
  initializeEngineSelector();
  setValue('#aiVehicle',intake?.vehicle||active?.vehicle||'');setValue('#aiTransmission',intake?.transmission||'');setValue('#aiFuel',intake?.fuel||'93 octane gasoline');setValue('#aiAspiration',intake?.aspiration||'Naturally aspirated');setValue('#aiTuneGoal',intake?.tuneGoal||'');setValue('#aiDrivingUse',intake?.drivingUse||'');
  const legacyEngine=intake?.engine||'';
  const parsed=intake?.engineFamily?{family:intake.engineFamily,displacement:intake.engineDisplacement||'',code:intake.engineCode||'',custom:intake.engineCustom||''}:(legacyEngine?(engineCatalogApi?.findEngineSelection(legacyEngine)||{family:'Custom / Other',displacement:'Custom',code:'Custom engine',custom:legacyEngine}):{family:'',displacement:'',code:'',custom:''});
  applyEngineSelection(parsed);
  setValue('#aiInjectorData',intake?.injectorData||'');setValue('#aiGearRatio',intake?.gearRatio||'');setValue('#aiTireSize',intake?.tireSize||'');setValue('#aiConverterStall',intake?.converterStall||'');setValue('#aiDesiredIdle',intake?.desiredIdle||'');setValue('#aiSymptoms',intake?.symptoms||'');setValue('#aiBuildNotes',intake?.notes||'');
  setValue('#aiCamBrand',intake?.cam?.brand||'');setValue('#aiCamPart',intake?.cam?.partNumber||'');setValue('#aiCamDurationI',intake?.cam?.durationIntake||'');setValue('#aiCamDurationE',intake?.cam?.durationExhaust||'');setValue('#aiCamLiftI',intake?.cam?.liftIntake||'');setValue('#aiCamLiftE',intake?.cam?.liftExhaust||'');setValue('#aiCamLsa',intake?.cam?.lsa||'');setValue('#aiCamIcl',intake?.cam?.icl||'');
  const mods=new Set(intake?.modifications||[]);$$('.ai-mod').forEach(input=>input.checked=mods.has(input.value));updateAiCamVisibility();updateOptionalSpecState();
}
function showFullAiError(error){const box=$('#fullAiError');if(box){box.textContent=error.message||String(error);box.classList.add('bad')}}
function engineNumber(id){const value=$(id)?.value?.trim();if(!value)return null;const number=Number(value);return Number.isFinite(number)?number:null}
function collectTuneEngineTargets(){return {profile:$('#tuneEngineProfile').value,aggressiveness:Number($('#tuneEngineAggressiveness').value||2),selectedLog:$('#tuneEngineLog').value,desiredIdle:engineNumber('#tuneTargetIdle'),revLimit:engineNumber('#tuneTargetRev'),speedLimit:engineNumber('#tuneTargetSpeed'),shiftRpm:engineNumber('#tuneTargetShift'),fan1On:engineNumber('#tuneTargetFan1On'),fan1Off:engineNumber('#tuneTargetFan1Off'),fan2On:engineNumber('#tuneTargetFan2On'),fan2Off:engineNumber('#tuneTargetFan2Off'),targetAfr:engineNumber('#tuneTargetAfr'),targetLambda:engineNumber('#tuneTargetLambda'),fuelType:$('#aiFuel').value,octane:$('#aiFuel').value,confirmations:{protectedOriginal:$('#tuneConfirmOriginal').checked,mechanicalHealth:$('#tuneConfirmMechanical').checked,injectorData:$('#tuneConfirmInjectors').checked,fuelPressure:$('#tuneConfirmFuelPressure').checked,wideband:$('#tuneConfirmWideband').checked,valvetrain:$('#tuneConfirmValvetrain').checked,driveline:$('#tuneConfirmDriveline').checked,controlledTest:$('#tuneConfirmControlled').checked}}}
function fillTuneEngineTargets(plan){if(!plan)return;const targets=plan.targets||{};setValue('#tuneEngineProfile',plan.profile||targets.profile||'street');setValue('#tuneEngineAggressiveness',String(plan.aggressiveness||targets.aggressiveness||2));setValue('#tuneTargetIdle',targets.desiredIdle);setValue('#tuneTargetRev',targets.revLimit);setValue('#tuneTargetSpeed',targets.speedLimit);setValue('#tuneTargetShift',targets.shiftRpm);setValue('#tuneTargetFan1On',targets.fan1On);setValue('#tuneTargetFan1Off',targets.fan1Off);setValue('#tuneTargetFan2On',targets.fan2On);setValue('#tuneTargetFan2Off',targets.fan2Off);setValue('#tuneTargetAfr',targets.targetAfr);setValue('#tuneTargetLambda',targets.targetLambda);if($('#tuneEngineLog'))$('#tuneEngineLog').value=targets.selectedLog||'';const c=targets.confirmations||{};$('#tuneConfirmOriginal').checked=Boolean(c.protectedOriginal);$('#tuneConfirmMechanical').checked=Boolean(c.mechanicalHealth);$('#tuneConfirmInjectors').checked=Boolean(c.injectorData);$('#tuneConfirmFuelPressure').checked=Boolean(c.fuelPressure);$('#tuneConfirmWideband').checked=Boolean(c.wideband);$('#tuneConfirmValvetrain').checked=Boolean(c.valvetrain);$('#tuneConfirmDriveline').checked=Boolean(c.driveline);$('#tuneConfirmControlled').checked=Boolean(c.controlledTest)}
function renderTuneEngineLogs(){const select=$('#tuneEngineLog');if(!select)return;const selected=select.value||state.tuneEngine?.plan?.targets?.selectedLog||'';const logs=Array.isArray(state.liveLogs)?state.liveLogs:[];select.innerHTML='<option value="">Choose a saved CSV log</option>'+logs.map(log=>`<option value="${safe(log.path||log.csvPath||'')}">${safe(log.name||log.fileName||String(log.path||'').split(/[\/]/).pop()||'Saved log')}</option>`).join('');if([...select.options].some(option=>option.value===selected))select.value=selected}
function renderTuneEngineProposal(){const box=$('#tuneEngineProposal'),proposal=state.tuneEngineProposal;if(!box)return;const badge=$('#tuneEngineProposalState'),apply=$('#tuneEngineApply');if(!proposal){badge.textContent='NONE';box.innerHTML='<p class="muted">Choose Generate Proposal on a ready calibration stage.</p>';apply.disabled=true;return}badge.textContent=proposal.blocked?'BLOCKED':`${proposal.summary?.proposedCells||0} CELLS`;badge.className=proposal.blocked?'bad':'';if(proposal.blocked){box.innerHTML=`<div class="goal-requirements"><b>Stage stopped</b><ul>${(proposal.blockers||['No applicable exact cells were produced.']).map(item=>`<li>${safe(item)}</li>`).join('')}</ul></div>`;apply.disabled=true;return}box.innerHTML=(proposal.warnings?.length?`<div class="goal-warnings"><ul>${proposal.warnings.map(item=>`<li>${safe(item)}</li>`).join('')}</ul></div>`:'')+`<div class="engine-proposal-list">${(proposal.proposals||[]).map(item=>`<label class="engine-proposal-item"><input class="tune-engine-approve" type="checkbox" value="${safe(item.id)}" ${item.risk==='high'?'':'checked'}><span><b>${safe(item.tableName)} · ${safe(item.rowLabel)} / ${safe(item.colLabel)}</b><small>${safe(item.role)} · ${safe(String(item.current))} → ${safe(String(item.proposed))}${item.percent!=null?` · ${safe(String(item.percent))}%`:''}</small><p>${safe(item.reason)}</p></span><em>${safe(item.risk||'moderate')}</em></label>`).join('')}</div>`;apply.disabled=false}
function renderTuneEngine(){const status=state.tuneEngine||{},plan=status.plan,active=state.activeProject;$('#tuneEnginePanel')?.classList.toggle('hidden',!active);if(!active)return;renderTuneEngineLogs();const stateBadge=$('#tuneEngineState');if(stateBadge)stateBadge.textContent=status.stale?'STALE — REBUILD':plan?'PLAN ACTIVE':'NO PLAN';$('#tuneEngineReadiness').textContent=`${plan?.readiness?.score||0}%`;$('#tuneEngineReadinessLabel').textContent=plan?.readiness?.label?.replaceAll('-',' ')||'Load a project BIN/XDF';$('#tuneEngineCoverage').textContent=plan?`${plan.coverage?.availableRoles||0} / ${plan.coverage?.totalRoles||0}`:'0 / 0';const next=plan?.stages?.find(stage=>stage.id===plan.nextStageId);$('#tuneEngineNext').textContent=next?.title||'Not planned';$('#tuneEngineNextDetail').textContent=next?.summary||'Build a plan to begin';const foundationBlocked=Boolean(plan?.readiness?.projectBlockers?.length||plan?.health?.blockers?.length);$('#tuneEngineSafety').textContent=!plan?'BLOCKED':foundationBlocked?'STOPPED':'GATED';$('#tuneEngineSafetyDetail').textContent=!plan?'Recovery and health proof required':foundationBlocked?[...(plan.readiness?.projectBlockers||[]),...(plan.health?.blockers||[])][0]:'Exact-cell approvals and validation required';$('#tuneEngineStageCount').textContent=`${plan?.stages?.length||0} stages`;$('#tuneEnginePlanSummary').textContent=status.stale?status.staleReason:plan?`${plan.profile.replaceAll('-',' ')} profile · ${plan.readiness.readyStages} stage(s) ready · ${plan.coverage.percent}% table-role coverage. Unknown mappings remain blocked.`:'The engine will identify supported tables, score readiness, and block unknown or unsafe work instead of guessing.';$('#tuneEngineStages').innerHTML=plan?.stages?.length?plan.stages.map(stage=>`<article class="tune-engine-stage ${safe(stage.status)}"><span>${stage.status==='complete'?'✓':stage.status==='locked'?'🔒':stage.order}</span><div><b>${safe(stage.title)}</b><p>${safe(stage.summary)}</p>${stage.blockers?.length?`<small>${safe(stage.blockers[0])}${stage.blockers.length>1?` (+${stage.blockers.length-1} more)`:''}</small>`:`<small>${safe(stage.group)} · ${safe(stage.status)}</small>`}</div>${stage.proposalSupported?`<button class="ghost tune-engine-generate" data-engine-stage="${safe(stage.id)}" ${stage.status!=='ready'?'disabled':''}>Generate Proposal</button>`:''}</article>`).join(''):'<p class="muted">Build a plan to see the project-specific tune stages.</p>';$$('[data-engine-stage]').forEach(button=>button.onclick=()=>buildTuneEngineStage(button.dataset.engineStage));$('#tuneEngineHandoff').disabled=!plan;fillTuneEngineTargets(plan);renderTuneEngineProposal()}
function collectAutonomousAuthorization(){const targets=collectTuneEngineTargets();return {allowAutomaticCalibration:Boolean($('#autonomousAuthorizeCalibration')?.checked),allowHighRiskMappedChanges:Boolean($('#autonomousAuthorizeHighRisk')?.checked),finalFlashSeparate:true,confirmedFacts:{...(targets.confirmations||{})}}}
function renderAutonomousTune(){const status=state.autonomousTune||{},run=status.run;const badge=$('#autonomousTuneState');if(!badge)return;badge.textContent=status.stale?'STALE':run?String(run.status||'unknown').replaceAll('-',' ').toUpperCase():'NOT STARTED';badge.className=status.stale||run?.status==='stopped'?'bad':run?.status==='ready-for-flash-confirmation'?'good':'';$('#autonomousTunePhase').textContent=run?String(run.phase||run.status||'idle').replaceAll('-',' '):'Idle';$('#autonomousTuneMessage').textContent=status.stale?status.staleReason:run?.blockers?.[0]||run?.message||'Ready when the project evidence is complete.';$('#autonomousTuneCells').textContent=`${run?.totalAppliedCells||0} cells`;$('#autonomousTuneStages').textContent=`${run?.completedStages?.length||0} stages complete`;$('#autonomousTuneRevision').textContent=run?.finalRevision?.name||'None';const rows=[...(run?.stageResults||[]),...(run?.skippedStages||[]).map(item=>({...item,status:'skipped'}))];$('#autonomousTuneTimeline').innerHTML=rows.length?rows.map((item,index)=>`<article class="autonomous-step ${safe(item.status||'applied')}"><span>${item.status==='applied'?'✓':item.status==='no-change'?'—':item.status==='skipped'?'↷':index+1}</span><div><b>${safe(item.title||item.stageId)}</b><small>${item.appliedCells!=null?`${item.appliedCells} cells${item.revision?.name?` · ${item.revision.name}`:''}`:safe(item.reason||item.blockers?.[0]||'No mapped change required')}</small></div><em>${safe(item.status||'complete')}</em></article>`).join(''):'<p class="muted">No autonomous stages have run yet.</p>';$('#autonomousTuneResume').disabled=!run||!['stopped','waiting-for-log','running'].includes(run.status);$('#autonomousTuneStart').disabled=Boolean(run?.status==='running');}
async function loadAutonomousTune(){if(!state.activeProject){state.autonomousTune=null;renderAutonomousTune();return}state.autonomousTune=await window.tuniq.getAutonomousTuneStatus();renderAutonomousTune()}
function renderClosedLoop(){const status=state.closedLoop||{},session=status.session,evaluation=status.latestEvaluation||status.evaluations?.[0]||null,readiness=status.readiness||session?.readiness||null;const badge=$('#closedLoopState');if(!badge)return;const current=status.stale?'STALE':session?String(session.status||'unknown').replaceAll('-',' ').toUpperCase():'NOT STARTED';badge.textContent=current;badge.className=status.stale||['safety-stop','rollback-required','correction-stopped','max-cycles-reached'].includes(session?.status)?'bad':['converged','rolled-back'].includes(session?.status)?'good':'';$('#closedLoopConfidence').textContent=`${evaluation?.confidence?.score||0}%`;$('#closedLoopConfidenceDetail').textContent=evaluation?`${evaluation.confidence.label} · ${evaluation.rows||0} rows · ${evaluation.sampleRateHz||'?' } Hz`:'Analyze a validation log';$('#closedLoopCoverage').textContent=`${evaluation?.coverage?.overall||0}%`;const zones=evaluation?.coverage?.zones||{};$('#closedLoopCoverageDetail').textContent=evaluation?`Idle ${zones.idle?.score||0} · Cruise ${zones.cruise?.score||0} · WOT ${zones.wot?.score||0} · Shifts ${zones.shifts?.score||0}`:'Idle, cruise, acceleration, WOT, shifts';$('#closedLoopSafety').textContent=(evaluation?.safety?.status||'unknown').toUpperCase();$('#closedLoopSafetyDetail').textContent=evaluation?.safety?.critical?.[0]||evaluation?.safety?.warnings?.[0]||'No critical validation finding';const comparison=evaluation?.comparison;$('#closedLoopConvergence').textContent=comparison?.converged?'CONVERGED':comparison?.improvementPercent!=null?`${comparison.improvementPercent>0?'+':''}${comparison.improvementPercent}%`:'NOT MEASURED';$('#closedLoopConvergenceDetail').textContent=comparison?.summary||'Baseline comparison required';$('#closedLoopReadiness').textContent=`${readiness?.score||0}%`;$('#closedLoopReadinessDetail').textContent=readiness?`${String(readiness.label||'blocked').replaceAll('-',' ')}${readiness.missing?.length?` · missing ${readiness.missing[0]}`:''}`:'2.0 tune workflow readiness';const findings=[...(session?.blockers||[]),...(evaluation?.safety?.critical||[]),...(evaluation?.safety?.warnings||[]),...(evaluation?.quality?.warnings||[])];$('#closedLoopFindings').innerHTML=findings.length?`<ul>${[...new Set(findings)].slice(0,8).map(item=>`<li>${safe(item)}</li>`).join('')}</ul>`:`<p>${safe(session?.status==='converged'?'The tune meets the current closed-loop confidence, safety, and convergence thresholds.':session?'Record the requested drive, import the newest log, and let TunIQ choose the next action.':'Complete AI Autopilot, then start a closed-loop session.')}</p>`;const evaluations=status.evaluations||[],cycles=session?.cycles||[];const rows=[...evaluations.map(item=>({kind:'log',at:item.createdAt,title:item.csvName,status:item.safety?.status==='critical'?'stopped':item.comparison?.converged?'validated':'analyzed',detail:`${item.confidence?.score||0}% confidence · error ${item.metrics?.compositeError??'n/a'}${item.comparison?.improvementPercent!=null?` · ${item.comparison.improvementPercent}% change`:''}`})),...cycles.map(item=>({kind:'cycle',at:item.completedAt,title:`Correction cycle ${item.number}`,status:item.status,detail:`${item.appliedCells||0} cells · ${item.revision?.name||'no revision'}`}))].sort((a,b)=>String(b.at||'').localeCompare(String(a.at||'')));$('#closedLoopTimeline').innerHTML=rows.length?rows.slice(0,20).map(item=>`<article class="closed-loop-step ${safe(item.status)}"><span>${item.kind==='log'?'◉':'↻'}</span><div><b>${safe(item.title)}</b><small>${safe(item.detail)}</small></div><em>${safe(item.status)}</em></article>`).join(''):'<p class="muted">No log evaluations or correction cycles yet.</p>';$('#closedLoopCycleCount').textContent=`${session?.cycleCount||0} / ${session?.maxCycles||5} cycles`;$('#closedLoopStart').disabled=Boolean(session&&!['rolled-back'].includes(session.status));$('#closedLoopAnalyze').disabled=!session;$('#closedLoopRun').disabled=!session||session.status!=='ready-for-correction';$('#closedLoopRollback').disabled=!session||!(session.rollbackSnapshotId||session.lastStableSnapshotId);$('#closedLoopReport').disabled=!session;}
async function loadClosedLoop(){if(!state.activeProject){state.closedLoop=null;renderClosedLoop();return}state.closedLoop=await window.tuniq.getClosedLoopStatus();renderClosedLoop()}
async function runClosedLoopAction(action){const buttons={start:'#closedLoopStart',analyze:'#closedLoopAnalyze',run:'#closedLoopRun',rollback:'#closedLoopRollback',report:'#closedLoopReport',reset:'#closedLoopReset'},button=$(buttons[action]);if(button)button.disabled=true;try{const selectedLog=$('#tuneEngineLog')?.value||null;let result;if(action==='start')result=await window.tuniq.startClosedLoop({maxCycles:5,autoProcessNewLogs:Boolean($('#closedLoopAutoProcess')?.checked),autoRunCorrections:Boolean($('#closedLoopAutoProcess')?.checked),targets:collectTuneEngineTargets()});else if(action==='analyze')result=await window.tuniq.analyzeClosedLoopLatest({selectedLog,targets:collectTuneEngineTargets()});else if(action==='run')result=await window.tuniq.runClosedLoopCycle({selectedLog,targets:collectTuneEngineTargets()});else if(action==='rollback')result=await window.tuniq.rollbackClosedLoop({reason:'Manual rollback from Tune Studio.'});else if(action==='report')result=await window.tuniq.exportClosedLoopReport();else if(action==='reset')result=await window.tuniq.resetClosedLoop();if(action==='report'){notify(`Closed-loop validation report exported to ${result.path}`,'success',8000);return}if(action==='reset'){state.closedLoop=await window.tuniq.getClosedLoopStatus();renderClosedLoop();notify(result.reset?'Closed-loop session archived.':'No closed-loop session existed.','success');return}state.closedLoop=result.status||result;if(result.workspace){state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration()}if(result.autonomousTune)state.autonomousTune=result.autonomousTune;if(result.tuneEngine)state.tuneEngine=result.tuneEngine;renderClosedLoop();renderAutonomousTune();renderTuneEngine();const session=state.closedLoop?.session;if(result.rolledBack)notify(`Validation failed and TunIQ automatically restored the rollback snapshot. Revision: ${result.revision?.name||'created'}.`,'warning',9000);else if(result.validated||session?.status==='converged')notify('Closed-loop validation converged. The tune is ready for final review and Flash Center confirmation.','success',9000);else if(action==='run')notify(result.corrected?`Automatic correction cycle ${result.cycle?.number||session?.cycleCount||''} completed. Record a fresh validation drive before the next decision.`:session?.blockers?.[0]||'The correction cycle stopped.','success',9000);else notify(session?.blockers?.[0]||`Closed-loop action completed: ${String(session?.status||action).replaceAll('-',' ')}.`,'success',7000);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){notify(error.message,'error',9000)}finally{renderClosedLoop()}}
async function runAutonomousTune(mode='complete',resume=false){const button=resume?$('#autonomousTuneResume'):mode==='log-cycle'?$('#autonomousTuneCycle'):$('#autonomousTuneStart');if(button)button.disabled=true;try{let result;if(resume)result=await window.tuniq.resumeAutonomousTune();else{const payload={mode,intake:collectAiPayload(),targets:collectTuneEngineTargets(),authorization:collectAutonomousAuthorization()};result=mode==='log-cycle'?await window.tuniq.runAutonomousLogCycle(payload):await window.tuniq.startAutonomousTune(payload)}state.autonomousTune=result.status;state.tuneEngine=result.tuneEngine||state.tuneEngine;if(result.workspace){state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration()}renderAutonomousTune();renderTuneEngine();const run=result.state||result.status?.run;if(run?.status==='ready-for-flash-confirmation')notify(`Autonomous Tune completed ${run.totalAppliedCells||0} mapped cell changes. Final revision: ${run.finalRevision?.name||'created'}. Open Flash Center when ready.`,'success',8000);else notify(run?.blockers?.[0]||`Autonomous Tune stopped at ${run?.phase||'a safety gate'}.`,'warning',8000);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){notify(error.message,'error',8000)}finally{renderAutonomousTune()}}
async function loadTuneEngine(){if(!state.activeProject){state.tuneEngine=null;state.tuneEngineProposal=null;renderTuneEngine();return}state.tuneEngine=await window.tuniq.getTuneEngineStatus();state.tuneEngineProposal=state.tuneEngine?.proposals?.[0]||null;renderTuneEngine()}
async function buildTuneEngineStage(stageId){const button=$(`[data-engine-stage="${stageId}"]`);if(button)button.disabled=true;try{state.tuneEngineProposal=await window.tuniq.buildTuneEngineStage({stageId,csvPath:$('#tuneEngineLog').value||null});renderTuneEngineProposal();notify(state.tuneEngineProposal.blocked?`${state.tuneEngineProposal.stageTitle} stopped: ${state.tuneEngineProposal.blockers?.[0]||'No safe cells.'}`:`Built ${state.tuneEngineProposal.summary.proposedCells} exact-cell proposal(s) for ${state.tuneEngineProposal.stageTitle}.`,state.tuneEngineProposal.blocked?'warning':'success')}catch(error){notify(error.message,'error')}finally{if(button)button.disabled=false}}
function renderAiPlan(){
  const active=state.activeProject,plan=state.aiPlan,intake=state.aiIntake;
  $('#fullAiNoProject').classList.toggle('hidden',Boolean(active));$('#fullAiWorkspace').classList.toggle('hidden',!active);$('#tuneEnginePanel')?.classList.toggle('hidden',!active);
  if(!active)return;
  $('#fullAiProjectContext').innerHTML=`<b>${safe(active.name)}</b><span>${safe(active.vehicle||'Vehicle not assigned')}</span><span>${safe(active.controller||'Controller pending')}${active.os?` · OS ${safe(active.os)}`:' · OS auto-detect pending'}</span>`;
  $('#fullAiSaveState').textContent=intake?.updatedAt?`Saved ${new Date(intake.updatedAt).toLocaleString()}`:'Not saved';
  $('#aiPlanCount').textContent=`${plan?.steps?.length||0} steps`;
  $('#aiPlanSummary').innerHTML=plan?`<b>${safe(plan.goal)}</b><br>${safe(intake?.engine||'Engine pending')} · ${safe(intake?.transmission||'Transmission pending')} · ${safe(intake?.fuel||'Fuel pending')}<br><small>Created ${new Date(plan.generatedAt).toLocaleString()}</small>`:'Complete the intake to generate a project-specific plan.';
  $('#aiPlanList').innerHTML=plan?.steps?.length?plan.steps.map((step,index)=>`<article class="ai-plan-step ${step.locked?'locked':''} ${step.complete?'complete':''}"><span>${step.complete?'✓':step.locked?'🔒':index+1}</span><div><b>${safe(step.title)}</b><p>${safe(step.reason)}</p><small>${safe(step.type.toUpperCase())}</small></div></article>`).join(''):'<div class="empty-card compact"><div class="empty-icon">✦</div><h3>No AI plan yet</h3><p>Enter the build and goal. Cam, boost, transmission, fuel, and diagnosis steps are added only when they apply.</p></div>';
}
async function loadAiWorkspace(){
  if(!state.activeProject){state.aiIntake=null;state.aiPlan=null;state.goalRequests=[];state.goalProposal=null;state.tuneEngine=null;state.tuneEngineProposal=null;state.autonomousTune=null;state.closedLoop=null;renderAiPlan();renderAiGoalRequest();renderTuneEngine();renderAutonomousTune();renderClosedLoop();return}
  const [bundle,goals,engine,autonomous,closedLoop,logs]=await Promise.all([window.tuniq.getAiIntake(),window.tuniq.listAiGoalRequests(),window.tuniq.getTuneEngineStatus(),window.tuniq.getAutonomousTuneStatus(),window.tuniq.getClosedLoopStatus(),window.tuniq.listLiveLogs()]);state.aiIntake=bundle?.intake||null;state.aiPlan=bundle?.plan||null;state.goalRequests=Array.isArray(goals)?goals.filter(item=>item.kind==='goal-request'):[];state.goalProposal=state.goalRequests[0]||null;state.tuneEngine=engine;state.tuneEngineProposal=engine?.proposals?.[0]||null;state.autonomousTune=autonomous;state.closedLoop=closedLoop;state.liveLogs=Array.isArray(logs)?logs:[];fillAiForm(state.aiIntake);renderAiPlan();renderAiGoalRequest();renderTuneEngine();renderAutonomousTune();renderClosedLoop();
}
function tuneLibraryFilters(){return {q:$('#tuneSearch').value.toLowerCase(),engine:$('#tuneEngineFilter').value.toLowerCase(),transmission:$('#tuneTransmissionFilter').value.toLowerCase(),controller:$('#tuneControllerFilter').value.toLowerCase(),favorites:$('#tuneFavoritesOnly').checked}}
function renderTuneLibrary(){
  const filters=tuneLibraryFilters();
  const items=(state.tuneLibrary||[]).filter(item=>{const hay=[item.name,item.description,item.engine,item.transmission,item.controller,item.os,item.fuel,item.tuneGoal,...(item.modifications||[]),...(item.tags||[])].join(' ').toLowerCase();return (!filters.q||hay.includes(filters.q))&&(!filters.engine||String(item.engine||'').toLowerCase().includes(filters.engine))&&(!filters.transmission||String(item.transmission||'').toLowerCase().includes(filters.transmission))&&(!filters.controller||String(item.controller||'').toLowerCase().includes(filters.controller))&&(!filters.favorites||item.favorite)});
  const grid=$('#tuneLibraryGrid');
  grid.innerHTML=items.length?items.map(item=>`<article class="tune-card"><div class="tune-card-head"><div><p class="eyebrow">${safe(item.tuneGoal||'SAVED TUNE')}</p><h3>${safe(item.name)}</h3></div><button class="favorite-tune ghost" data-id="${safe(item.id)}">${item.favorite?'★':'☆'}</button></div><p>${safe(item.description||'No description added.')}</p><div class="tune-meta"><span>${safe(item.engine||'Engine unspecified')}</span><span>${safe(item.transmission||'Transmission unspecified')}</span><span>${safe(item.controller||'Controller unspecified')}${item.os?` / OS ${safe(item.os)}`:''}</span><span>${safe(item.fuel||'Fuel unspecified')}</span></div><div class="tune-tags">${[...(item.modifications||[]),...(item.tags||[])].slice(0,8).map(tag=>`<span>${safe(tag)}</span>`).join('')}</div><small>SHA-256 ${safe((item.sourceSha256||'').slice(0,16))}… · ${new Date(item.createdAt).toLocaleString()}</small><div class="tune-actions"><button class="apply-tune" data-id="${safe(item.id)}">Use as Revision</button><button class="export-tune ghost" data-id="${safe(item.id)}">Export</button><button class="delete-tune danger-btn" data-id="${safe(item.id)}">Delete</button></div></article>`).join(''):'<div class="empty-card"><div class="empty-icon">★</div><h2>No matching saved tunes</h2><p>Save the active project’s latest revision or import a .tuniqtune package.</p></div>';
  $$('.favorite-tune').forEach(button=>button.onclick=async()=>{await window.tuniq.favoriteTune(button.dataset.id);await loadTuneLibrary()});
  $$('.apply-tune').forEach(button=>button.onclick=async()=>{try{const result=await window.tuniq.applyTune(button.dataset.id);alert(`Tune imported as a new project revision:\n${result.path}\n\nSHA-256: ${result.sha256}`);await refreshWorkspace(true)}catch(error){alert(error.message)}});
  $$('.export-tune').forEach(button=>button.onclick=async()=>{try{const out=await window.tuniq.exportTune(button.dataset.id);if(out)alert(`Tune package exported:\n${out}`)}catch(error){alert(error.message)}});
  $$('.delete-tune').forEach(button=>button.onclick=async()=>{if(confirm('Delete this tune from the local library?')){await window.tuniq.deleteTune(button.dataset.id);await loadTuneLibrary()}});
}
async function loadTuneLibrary(){state.tuneLibrary=await window.tuniq.listTuneLibrary();state.tuneLibrary=Array.isArray(state.tuneLibrary)?state.tuneLibrary:[];renderTuneLibrary()}
function renderCommunityPosts(){
  const q=$('#communitySearch').value.toLowerCase(),category=$('#communityCategory').value.toLowerCase(),engine=$('#communityEngine').value.toLowerCase(),trans=$('#communityTransmission').value.toLowerCase(),controller=$('#communityController').value.toLowerCase();
  const posts=(state.communityPosts||[]).filter(post=>{const hay=[post.title,post.body,post.engine,post.transmission,post.controller,...(post.tags||[])].join(' ').toLowerCase();return (!q||hay.includes(q))&&(!category||String(post.category||'').toLowerCase()===category)&&(!engine||String(post.engine||'').toLowerCase().includes(engine))&&(!trans||String(post.transmission||'').toLowerCase().includes(trans))&&(!controller||String(post.controller||'').toLowerCase().includes(controller))});
  $('#communityPosts').innerHTML=posts.length?posts.map(post=>`<article class="community-post"><div class="community-post-head"><div><span class="status-badge">${safe(post.category||'POST')}</span><h3>${safe(post.title)}</h3></div>${post.official?'<b class="official-badge">TunIQ Official</b>':`<button class="delete-post danger-btn" data-id="${safe(post.id)}">Delete</button>`}</div><p>${safe(post.body)}</p><div class="tune-meta"><span>${safe(post.engine||'Engine unspecified')}</span><span>${safe(post.transmission||'Transmission unspecified')}</span><span>${safe(post.controller||'Controller unspecified')}</span></div>${post.projectContext?`<div class="attached-context"><b>Attached project:</b> ${safe(post.projectContext.projectName)} · ${safe(post.projectContext.controller||'Controller pending')}${post.projectContext.os?` · OS ${safe(post.projectContext.os)}`:''}</div>`:''}<div class="tune-tags">${(post.tags||[]).map(tag=>`<span>${safe(tag)}</span>`).join('')}</div><small>By ${safe(post.author||'Unknown')} · ${new Date(post.createdAt).toLocaleString()}</small></article>`).join(''):'<div class="empty-card compact"><h3>No matching posts</h3><p>Clear a filter or create a local draft post.</p></div>';
  $$('.delete-post').forEach(button=>button.onclick=async()=>{if(confirm('Delete this local post draft?')){await window.tuniq.deleteCommunityPost(button.dataset.id);await loadCommunityPosts()}})
}
async function loadCommunityPosts(){state.communityPosts=await window.tuniq.listCommunityPosts();state.communityPosts=Array.isArray(state.communityPosts)?state.communityPosts:[];state.beta=state.beta||null;state.updates=state.updates||null;state.devices=Array.isArray(state.devices)?state.devices:[];state.device=state.device||{connected:false,connection:null,preferred:{}};state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];state.sensorProfiles=state.sensorProfiles||{};state.logSession=state.device.logging||null;state.flash=state.flash||null;state.validation=state.validation||null;state.aiProposals=Array.isArray(state.aiProposals)?state.aiProposals:[];state.currentProposal=state.aiProposals[0]||null;state.goalRequests=Array.isArray(state.goalRequests)?state.goalRequests:[];state.goalProposal=state.goalRequests[0]||null;state.p01Auto=state.p01Auto||null;state.p01Evidence=state.p01Evidence&&typeof state.p01Evidence==='object'?state.p01Evidence:null;renderCommunityPosts()}


function valueText(value,digits=1,fallback='--'){const number=Number(value);return Number.isFinite(number)?number.toFixed(digits).replace(/\.0$/,''):fallback}
function showDeviceMessage(message,bad=false){const box=$('#deviceHelp');if(box){box.textContent=message;box.classList.toggle('bad',bad)}}
function showLogMessage(message,bad=false){const box=$('#logSessionStatus');if(box){box.textContent=message;box.classList.toggle('bad',bad)}}
function renderDeviceList(){
  const container=$('#deviceList');if(!container)return;
  const preferred=state.device?.preferred?.port||'';
  const selected=$('#devicePort')?.value||preferred;
  const devices=Array.isArray(state.devices)?state.devices:[];
  $('#deviceScanState').textContent=`${devices.filter(item=>!item.demo).length} physical port(s)`;
  $('#devicePort').innerHTML='<option value="">Select a port</option>'+devices.map(item=>`<option value="${safe(item.port)}">${safe(item.name)}</option>`).join('');
  if(devices.some(item=>item.port===selected))$('#devicePort').value=selected;else if(devices.some(item=>item.port===preferred))$('#devicePort').value=preferred;
  container.innerHTML=devices.length?devices.map(item=>`<button class="device-row ${item.port===($('#devicePort').value||preferred)?'selected':''}" data-device-port="${safe(item.port)}"><span class="device-port-icon">${item.demo?'◉':item.transport.includes('Bluetooth')?'⌁':'⇄'}</span><span><b>${safe(item.name)}</b><small>${safe(item.port)} · ${safe(item.transport)}${item.manufacturer?` · ${safe(item.manufacturer)}`:''}</small></span><em>${item.recommended?'OBDLINK':'SELECT'}</em></button>`).join(''):'<p class="muted">No serial devices were found. Pair the MX+ in Windows Bluetooth settings, then scan again.</p>';
  $$('[data-device-port]').forEach(button=>button.onclick=()=>{$('#devicePort').value=button.dataset.devicePort;renderDeviceList();showDeviceMessage(`Selected ${button.dataset.devicePort}. Press Connect & Identify.`)});
}
function renderDeviceStatus(){
  const device=state.device||{},connection=device.connection,connected=Boolean(device.connected&&connection),preferred=device.preferred||{};
  const badge=$('#deviceStatusBadge');if(badge){badge.textContent=connected?'CONNECTED':'DISCONNECTED';badge.className=`device-badge ${connected?'online':'offline'}`}
  $('#deviceConnect').disabled=connected;$('#deviceDisconnect').disabled=!connected;
  $('#deviceAdapter').textContent=connection?.adapter||preferred.adapter||'Not connected';
  $('#deviceFirmware').textContent=connection?.firmware||preferred.firmware||'Firmware unavailable';
  $('#deviceTransport').textContent=connection?.transport||preferred.transport||'Bluetooth / serial';
  $('#devicePortInfo').textContent=connection?.port?`${connection.port}${connection.baud?` at ${connection.baud} baud`:''}`:preferred.port?`${preferred.port} saved`:'No port selected';
  $('#deviceProtocol').textContent=connection?.protocol||preferred.protocol||'Not detected';
  $('#deviceVoltage').textContent=Number.isFinite(Number(connection?.voltage))?`${Number(connection.voltage).toFixed(2)} V`:'-- V';
  $('#deviceVin').textContent=connection?.vin||preferred.vin||'Not read';
  $('#deviceCapabilities').textContent=(connection?.capabilities||['Diagnostics','Live logging']).join(' · ');
  $('#liveDeviceState').textContent=connection?.adapter||'None';$('#scanProtocol').textContent=connection?.protocol||'Unknown';
  $('#scanState').textContent=connected?(state.logSession?'RECORDING':'CONNECTED'):'DISCONNECTED';$('#scanDot').style.background=connected?'#62f1b1':'#71837b';
  const header=$('#headerDeviceState');if(header)header.innerHTML=`<i></i>${connected?safe(connection.adapter):preferred.port?`${safe(preferred.port)} ready`:'Adapter offline'}`;
  const diag=$('#diagDeviceState');if(diag)diag.textContent=connected?`${connection.adapter} on ${connection.port}`:preferred.port?`${preferred.port} configured`:'Not connected';
  const dot=$('#diagDeviceDot');if(dot)dot.className=connected?'green':'amber';
  $('#logStart').disabled=!connected||!state.activeProject||Boolean(state.logSession);$('#logStop').disabled=!state.logSession;$('#logMarker').disabled=!state.logSession;
}
async function scanDevices(){const button=$('#deviceScan');button.disabled=true;$('#deviceScanState').textContent='Scanning Windows ports…';try{state.devices=await window.tuniq.listDevices();renderDeviceList();showDeviceMessage(state.devices.some(item=>!item.demo)?'Select the OBDLink or Bluetooth serial COM port, then connect.':'No physical ports were returned. Confirm the adapter is paired in Windows; the virtual adapter is available for testing.')}catch(error){showDeviceMessage(error.message,true)}finally{button.disabled=false}}
async function loadDeviceManager(){const [device,doctor,lab]=await Promise.all([window.tuniq.getDeviceStatus(),window.tuniq.getConnectionDoctor(),window.tuniq.getP01LabStatus()]);state.device=device;state.connectionDoctor=doctor?.latest||doctor||null;state.p01Lab=lab||null;if(!state.devices.length)await scanDevices();else{renderDeviceList();renderDeviceStatus()}renderConnectionDoctor();renderP01Lab()}
async function connectSelectedDevice(portOverride=null){const port=portOverride||$('#devicePort').value;if(!port)return showDeviceMessage('Select a detected port first.',true);$('#deviceConnect').disabled=true;showDeviceMessage(`Connecting to ${port} and identifying the adapter…`);try{state.device=await window.tuniq.connectDevice({port,baud:Number($('#deviceBaud').value||0)});renderDeviceStatus();renderDeviceList();showDeviceMessage(`Connected to ${state.device.connection.adapter}. Protocol: ${state.device.connection.protocol||'automatic'}.`);await refreshWorkspace(true);if($('#scanner').classList.contains('active'))startLivePolling()}catch(error){showDeviceMessage(error.message,true);renderDeviceStatus()}finally{$('#deviceConnect').disabled=Boolean(state.device?.connected)}}
async function disconnectDevice(){try{stopLivePolling();state.device=await window.tuniq.disconnectDevice();state.logSession=null;renderDeviceStatus();showDeviceMessage('Adapter disconnected. Your preferred COM port remains saved.');await refreshWorkspace(true)}catch(error){showDeviceMessage(error.message,true)}}
function renderConnectionDoctor(){
  const report=state.connectionDoctor;const badge=$('#connectionDoctorBadge'),summary=$('#connectionDoctorSummary'),stages=$('#connectionDoctorStages'),issues=$('#connectionDoctorIssues'),attempts=$('#connectionDoctorAttempts'),connect=$('#deviceDoctorConnect'),pathBox=$('#connectionDoctorReportPath');if(!badge||!summary||!stages||!issues||!attempts||!connect)return;
  if(!report){badge.textContent='NOT RUN';badge.className='device-badge offline';summary.textContent='Runs a staged Windows port scan, exclusive-lock test, baud fallback, adapter handshake, voltage check, and vehicle protocol check. No PCM read or write is performed.';stages.innerHTML='';issues.innerHTML='';attempts.innerHTML='<span class="muted">No attempts recorded.</span>';connect.disabled=true;if(pathBox)pathBox.textContent='';return}
  const good=report.status==='ready',warning=report.status==='warning';badge.textContent=String(report.status||'unknown').toUpperCase();badge.className=`device-badge ${good?'online':warning?'warning':'offline'}`;summary.textContent=report.summary||report.issues?.[0]?.title||'Connection Doctor completed.';
  stages.innerHTML=(report.stages||[]).map(item=>`<article class="doctor-stage ${safe(item.status)}"><i>${item.status==='passed'?'✓':item.status==='warning'?'!':'×'}</i><div><b>${safe(item.title)}</b><small>${safe(item.message)}</small></div></article>`).join('')||'<span class="muted">No stage results were recorded.</span>';
  issues.innerHTML=(report.issues||[]).filter(item=>item.severity!=='info'||!item.resolvedByAlternate).map(item=>`<article class="doctor-issue ${safe(item.severity||'warning')}"><b>${safe(item.title||item.code)}</b><small>${safe(item.message||'')}</small>${(item.actions||[]).length?`<ol>${item.actions.map(action=>`<li>${safe(action)}</li>`).join('')}</ol>`:''}</article>`).join('');
  attempts.innerHTML=(report.attempts||[]).map(item=>`<div><b>${safe(item.port||'Port')}</b><span>${item.baud?`${safe(item.baud)} baud · `:''}${safe(item.status||'unknown')}${item.adapter?` · ${safe(item.adapter)}`:''}</span>${item.message?`<small>${safe(item.message)}</small>`:''}</div>`).join('')||'<span class="muted">No port/baud attempts were needed.</span>';
  connect.disabled=!report.recommendedConnection||report.status==='blocked';if(pathBox)pathBox.textContent=report.reportFile?`Report: ${report.reportFile}`:'';
  if(report.recommendedConnection){const rec=report.recommendedConnection;if(state.devices.some(item=>item.port===rec.port))$('#devicePort').value=rec.port;if([...$('#deviceBaud').options].some(option=>Number(option.value)===Number(rec.baud)))$('#deviceBaud').value=String(rec.baud);renderDeviceList()}
}
async function runConnectionDoctor(){const button=$('#deviceDoctor');button.disabled=true;const port=$('#devicePort').value||state.device?.preferred?.port||'';showDeviceMessage('Connection Doctor is testing Windows ports, locks, baud rates, adapter identity, and vehicle power…');try{state.connectionDoctor=await window.tuniq.runConnectionDoctor({port,baud:Number($('#deviceBaud').value||0),tryAlternates:true});renderConnectionDoctor();const rec=state.connectionDoctor.recommendedConnection;if(rec)showDeviceMessage(`${state.connectionDoctor.summary} Press Connect Using Proven Settings.`);else showDeviceMessage(state.connectionDoctor.summary||state.connectionDoctor.issues?.[0]?.message||'No working adapter route was proven.',true)}catch(error){showDeviceMessage(error.message,true)}finally{button.disabled=false}}
async function connectDoctorResult(){const rec=state.connectionDoctor?.recommendedConnection;if(!rec)return;$('#devicePort').value=rec.port;$('#deviceBaud').value=String(rec.baud||0);await connectSelectedDevice(rec.port)}
function renderP01Lab(){const report=state.p01Lab,badge=$('#p01LabBadge'),box=$('#p01LabResults'),pathBox=$('#p01LabReportPath');if(!badge||!box)return;if(!report){badge.textContent='NOT RUN';badge.className='device-badge offline';box.innerHTML='<span class="muted">Use this while the MX+ or truck is unavailable.</span>';if(pathBox)pathBox.textContent='';return}badge.textContent=report.passed?'ALL PASSED':'FAILED';badge.className=`device-badge ${report.passed?'online':'offline'}`;box.innerHTML=(report.scenarios||[]).map(item=>`<article class="p01-lab-card ${item.passed?'passed':'failed'}"><div><b>${safe(item.scenario.replaceAll('-',' '))}</b><span>${item.passed?'PASSED':'FAILED'}</span></div><small>${safe((item.steps||[]).map(step=>step.message).join(' '))}</small></article>`).join('');if(pathBox)pathBox.textContent=report.reportFile?`Report: ${report.reportFile}`:''}
async function runP01Lab(){const button=$('#p01LabRun');button.disabled=true;button.textContent='Running recovery scenarios…';try{state.p01Lab=await window.tuniq.runP01Lab();renderP01Lab();showDeviceMessage(state.p01Lab.passed?'Offline P01 Recovery Lab passed all three scenarios. No hardware was accessed.':'One or more offline lab scenarios failed. Review the report.',!state.p01Lab.passed)}catch(error){showDeviceMessage(error.message,true)}finally{button.disabled=false;button.textContent='Run All Three Lab Scenarios'}}
function drawLiveChart(){const canvas=$('#liveChart');if(!canvas)return;const ctx=canvas.getContext('2d');const width=canvas.width,height=canvas.height;ctx.clearRect(0,0,width,height);ctx.strokeStyle='#1e362d';ctx.lineWidth=1;for(let y=0;y<=4;y++){ctx.beginPath();ctx.moveTo(0,y*height/4);ctx.lineTo(width,y*height/4);ctx.stroke()}for(let x=0;x<=10;x++){ctx.beginPath();ctx.moveTo(x*width/10,0);ctx.lineTo(x*width/10,height);ctx.stroke()}if(livePoints.length<2)return;const series=[{key:'rpm',max:6500,color:'#62f1b1'},{key:'tps',max:100,color:'#f4c85c'},{key:'trim',max:40,min:-40,color:'#78bdf2'}];for(const item of series){ctx.strokeStyle=item.color;ctx.lineWidth=2;ctx.beginPath();let started=false;livePoints.forEach((point,index)=>{const raw=item.key==='trim'?(Number(point.stft1)||0)+(Number(point.ltft1)||0):Number(point[item.key]);if(!Number.isFinite(raw))return;const min=item.min??0;const x=index/(Math.max(1,livePoints.length-1))*width;const y=height-(Math.max(0,Math.min(1,(raw-min)/(item.max-min)))*height);if(!started){ctx.moveTo(x,y);started=true}else ctx.lineTo(x,y)});ctx.stroke()}}
function renderSensorFrame(sample){const rows=[['RPM',sample.rpm,'rpm'],['Speed',sample.speed,'mph'],['Coolant',sample.ect,'°F'],['Intake air',sample.iat,'°F'],['Throttle',sample.tps,'%'],['MAP',sample.map,'kPa'],['MAF',sample.maf,'g/s'],['MAF frequency',sample.mafFrequency,'Hz'],['STFT Bank 1',sample.stft1,'%'],['LTFT Bank 1',sample.ltft1,'%'],['Commanded EQ',sample.commandedEqRatio,'EQ'],['Wideband AFR',sample.widebandAfr,'AFR'],['Spark advance',sample.spark,'°'],['Knock retard',sample.knockRetard,'°'],['Injector duty',sample.injectorDuty,'%'],['Desired idle',sample.desiredIdle,'rpm'],['Misfire total',sample.misfireTotal,''],['Commanded gear',sample.commandedGear,''],['Actual gear',sample.actualGear,''],['Input shaft',sample.inputShaftSpeed,'rpm'],['Output shaft',sample.outputShaftSpeed,'rpm'],['Transmission slip',sample.transSlip,'rpm'],['Shift time',sample.shiftTime,'ms'],['TCC slip',sample.tccSlip,'rpm'],['Torque management',sample.torqueManagement,'%'],['Calculated load',sample.load,'%'],['Voltage',sample.voltage,'V']].filter(([,value])=>value!=null);$('#liveSensorRows').innerHTML=rows.map(([name,value,unit])=>`<div class="sensor-row"><span>${name}</span><b>${valueText(value,1)} ${unit}</b></div>`).join('');$('#liveFrameTime').textContent=new Date(sample.timestamp).toLocaleTimeString()}
function updateLiveSample(sample,statusPayload){
  if(statusPayload)state.device=statusPayload;
  const set=(id,value,digits=1)=>{$(id).textContent=valueText(value,digits)};
  set('#rpm',sample.rpm,0);set('#speed',sample.speed,1);set('#ect',sample.ect,1);set('#tps',sample.tps,1);set('#map',sample.map,1);set('#maf',sample.maf,2);set('#stft',sample.stft1,1);set('#ltft',sample.ltft1,1);set('#spark',sample.spark,1);set('#kr',sample.knockRetard,1);set('#volt',sample.voltage,2);
  livePoints.push({...sample,trim:(Number(sample.stft1)||0)+(Number(sample.ltft1)||0)});while(livePoints.length>140)livePoints.shift();drawLiveChart();renderSensorFrame(sample);renderDeviceStatus();
  if(state.logSession){state.logSession.samples=(state.logSession.samples||0)+1;$('#scanSamples').textContent=state.logSession.samples;showLogMessage(`Recording ${state.logSession.profileName} · ${state.logSession.samples} samples · ${state.device?.connection?.adapter||'adapter'}`)}
}
async function pollLiveSample(){if(livePolling||!state.device?.connected)return;livePolling=true;try{const result=await window.tuniq.sampleDevice();updateLiveSample(result.sample,result.status)}catch(error){showLogMessage(error.message,true);if(/disconnect|COM port|use|access/i.test(error.message))stopLivePolling()}finally{livePolling=false}}
function startLivePolling(){if(livePollTimer||!state.device?.connected)return;pollLiveSample();livePollTimer=setInterval(pollLiveSample,state.device?.connection?.demo?500:state.device?.connection?.persistent?450:1200)}
function stopLivePolling(){if(livePollTimer){clearInterval(livePollTimer);livePollTimer=null}livePolling=false}
function renderLogAnalysis(analysis){state.logAnalysis=analysis||null;const box=$('#logAnalysis');if(!analysis){$('#logAnalysisConfidence').textContent='NO ANALYSIS';box.innerHTML='<p class="muted">Stop a recording or select Analyze on a saved log.</p>';return}$('#logAnalysisConfidence').textContent=`${String(analysis.confidence||'limited').toUpperCase()} · ${Number(analysis.sampleCount||0)} SAMPLES`;box.innerHTML=(analysis.findings||[]).map(item=>`<article class="analysis-finding ${safe(item.severity||'info')}"><b>${safe(item.title)}</b><p>${safe(item.detail)}</p><small>Next: ${safe(item.action)}</small></article>`).join('')||'<p class="muted">No findings were generated.</p>';renderAiContext()}
function renderLiveLogHistory(){
  const box=$('#liveLogHistory');if(!box)return;const logs=Array.isArray(state.liveLogs)?state.liveLogs:[];
  box.innerHTML=logs.length?logs.map((log,index)=>`<article class="live-log-item"><div><b>${safe(log.name||'Live log')}</b><small>${safe(log.profileName||'Profile')} · ${Number(log.samples||0)} samples · ${log.startedAt?new Date(log.startedAt).toLocaleString():'Unknown date'}</small></div><div><button class="ghost analyze-log" data-log-index="${index}">${log.analysis?'Review':'Analyze'}</button><button class="ghost outcome-log" data-log-index="${index}">Result</button></div></article>`).join(''):'<p class="muted">No project logs yet.</p>';
  $$('.analyze-log').forEach(button=>button.onclick=async()=>{const log=logs[Number(button.dataset.logIndex)];if(!log)return;try{const analysis=log.analysis||await window.tuniq.analyzeLiveLog(log.csvPath);log.analysis=analysis;renderLogAnalysis(analysis);renderLiveLogHistory()}catch(error){showLogMessage(error.message,true)}});
  $$('.outcome-log').forEach(button=>button.onclick=()=>{const log=logs[Number(button.dataset.logIndex)];if(log)openOutcomeForm(log)});
  updateProposalLogOptions();
}
function updateProposalLogOptions(){const select=$('#aiProposalLog');if(!select)return;const previous=select.value;const logs=Array.isArray(state.liveLogs)?state.liveLogs:[];select.innerHTML='<option value="">Choose a saved CSV log</option>'+logs.map(log=>`<option value="${safe(log.csvPath)}">${safe(log.name||'Live log')} · ${Number(log.samples||0)} samples</option>`).join('');if(logs.some(log=>log.csvPath===previous))select.value=previous;else if(logs[0])select.value=logs[0].csvPath;}
function renderAiProposalWorkspace(){
  const proposal=state.currentProposal||state.aiProposals?.[0]||null;state.currentProposal=proposal;
  updateProposalLogOptions();
  const stateEl=$('#aiProposalState'),summary=$('#aiProposalSummary'),list=$('#aiProposalList'),apply=$('#aiApplyProposal');if(!stateEl||!summary||!list||!apply)return;
  if(!proposal){stateEl.textContent='NO PROPOSAL';summary.textContent='Load a BIN/XDF mapping and select a saved log.';list.innerHTML='';apply.disabled=true;return;}
  stateEl.textContent=proposal.blocked?'BLOCKED':`${proposal.summary?.proposedCells||0} CELL${proposal.summary?.proposedCells===1?'':'S'}`;
  summary.innerHTML=`<b>AI calibration cycle ${Number(proposal.iteration||1)} · ${safe(proposal.sourceLogName)}</b><br>${Number(proposal.sampleCount||0)} samples · ${safe(proposal.summary?.tables?.join(', ')||'No mapped target table')}<br>${proposal.blocked?'Safety findings must be resolved before changes can be applied.':'Every cell below requires approval.'}`;
  const safety=(proposal.safetyFindings||[]).map(item=>`<article class="proposal-safety ${safe(item.severity)}"><b>${safe(item.title)}</b><small>${safe(item.detail)}</small></article>`).join('');
  const changes=(proposal.proposals||[]).map(item=>`<label class="ai-proposal-item ${item.blocked?'blocked':''}"><input type="checkbox" class="ai-proposal-approve" value="${safe(item.id)}" ${item.blocked?'disabled':''}><span><b>${safe(item.tableName)} · ${safe(item.rowLabel)} / ${safe(item.colLabel)}</b><small>${safe(item.current)} → ${safe(item.proposed)} (${Number(item.percent)>=0?'+':''}${safe(item.percent)}%)</small><small>${safe(item.reason)}</small><em>${safe(item.confidence)} confidence · ${safe(item.risk)} risk</em></span></label>`).join('');
  list.innerHTML=safety+(changes||'<p class="muted">No repeatable log regions could be mapped to supported calibration tables.</p>');
  $$('.ai-proposal-approve').forEach(box=>box.onchange=()=>{apply.disabled=proposal.blocked||!$$('.ai-proposal-approve:checked').length});
  apply.disabled=proposal.blocked||!$$('.ai-proposal-approve:checked').length;
}
function goalConfirmations(){return {valvetrainVerified:$('#aiGoalValvetrain').checked,tireRatingMph:Number($('#aiGoalTireRating').value)||null,drivelineVerified:$('#aiGoalDriveline').checked,brakesVerified:$('#aiGoalBrakes').checked,closedCourse:$('#aiGoalClosedCourse').checked,ghostCamRisksAccepted:$('#aiGoalGhostRisks').checked}}
function renderAiGoalRequest(){
  const proposal=state.goalProposal;const stateEl=$('#aiGoalState'),summary=$('#aiGoalSummary'),box=$('#aiGoalActions'),apply=$('#aiApplyGoalRequest'),mapButton=$('#aiConfirmGoalMap');if(!stateEl||!summary||!box||!apply)return;
  if(!proposal){stateEl.textContent='NO REQUEST';summary.textContent='Describe the exact outcome. TunIQ will identify supported actions, required hardware checks, and exact mapped cells.';box.innerHTML='';apply.disabled=true;if(mapButton)mapButton.disabled=true;return}
  stateEl.textContent=proposal.blocked?'BLOCKED':proposal.partiallyBlocked?'PARTIAL':`${proposal.summary?.readyActions||0} READY`;
  const p01NeedsMap=Boolean(state.p01?.applicable);
  summary.innerHTML=`<b>${safe(proposal.requestText)}</b><br>${Number(proposal.summary?.readyActions||0)} ready action(s) · ${Number(proposal.summary?.blockedActions||0)} blocked action(s) · ${Number(proposal.summary?.proposedCells||0)} mapped cell(s)<br><small>${p01NeedsMap?'P01 requires one exact parameter-map confirmation for this verified OS/XDF before applying. ':''}Applying creates a revision only. Flashing remains separate.</small>`;
  box.innerHTML=(proposal.actions||[]).map(action=>{const requirements=(action.requirements||[]).map(item=>`<li>${safe(item)}</li>`).join('');const warnings=(action.warnings||[]).map(item=>`<li>${safe(item)}</li>`).join('');const changes=(action.proposals||[]).map(item=>`<label class="ai-proposal-item ${item.blocked?'blocked':''}"><input type="checkbox" class="ai-goal-approve" value="${safe(item.id)}" ${item.blocked?'disabled':''}><span><b>${safe(item.tableName)} · ${safe(item.rowLabel)} / ${safe(item.colLabel)}</b><small>${safe(item.current)} → ${safe(item.proposed)}</small><small>${safe(item.reason)}</small><em>${safe(item.confidence)} confidence · ${safe(item.risk)} risk</em></span></label>`).join('');const mapChoice=p01NeedsMap&&changes?`<label class="inline-check p01-map-choice"><input type="checkbox" class="ai-goal-map-action" value="${safe(action.id)}">I verified these are the correct ${safe(action.label)} parameters for OS ${safe(state.p01?.identity?.os||'')}</label>`:'';return `<article class="ai-goal-action ${safe(action.status)}"><div class="panel-title"><h4>${safe(action.label)}</h4><span>${safe(action.status.toUpperCase())}</span></div>${requirements?`<div class="goal-requirements"><b>Needed before this can run</b><ul>${requirements}</ul></div>`:''}${warnings?`<div class="goal-warnings"><b>Important</b><ul>${warnings}</ul></div>`:''}${changes||'<p class="muted">No editable cells were produced for this action.</p>'}${mapChoice}</article>`}).join('');
  const updateButtons=()=>{apply.disabled=!$$('.ai-goal-approve:checked').length;if(mapButton)mapButton.disabled=!p01NeedsMap||!$$('.ai-goal-map-action:checked').length};
  $$('.ai-goal-approve').forEach(input=>input.onchange=updateButtons);$$('.ai-goal-map-action').forEach(input=>input.onchange=updateButtons);updateButtons();
}
async function confirmP01GoalMap(){const proposal=state.goalProposal;if(!proposal)return;const actionIds=$$('.ai-goal-map-action:checked').map(input=>input.value);if(!actionIds.length)return alert('Select the P01 actions whose exact cells you verified.');if(!confirm(`Bind the selected table cells to P01 OS ${state.p01?.identity?.os||'unknown'} and the current XDF?

This does not change or flash the BIN.`))return;const button=$('#aiConfirmGoalMap');button.disabled=true;try{state.p01=await window.tuniq.confirmP01GoalMap({proposalId:proposal.id,actionIds});if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();alert('P01 parameter map saved. Rebuild the Safe Action Sheet so TunIQ uses only those commissioned cells.')}catch(error){alert(error.message)}finally{renderAiGoalRequest()}}
async function buildAiGoalRequest(){const request=$('#aiGoalRequest').value.trim();if(!request)return alert('Describe the tune changes you want first.');$('#aiBuildGoalRequest').disabled=true;try{state.goalProposal=await window.tuniq.buildAiGoalRequest({request,confirmations:goalConfirmations()});state.goalRequests=[state.goalProposal,...(state.goalRequests||[]).filter(item=>item.id!==state.goalProposal.id)];renderAiGoalRequest();await refreshWorkspace(true)}catch(error){$('#aiGoalSummary').textContent=error.message}finally{$('#aiBuildGoalRequest').disabled=false}}
async function applyAiGoalRequest(){const proposal=state.goalProposal;if(!proposal)return;const approvedIds=$$('.ai-goal-approve:checked').map(input=>input.value);if(!approvedIds.length)return alert('Approve at least one exact requested change.');if(!confirm(`Apply ${approvedIds.length} approved requested change(s) and create a new revision?

This does not flash the PCM.`))return;$('#aiApplyGoalRequest').disabled=true;try{const result=await window.tuniq.applyAiGoalRequest({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration();alert(`Requested tune revision created:
${result.revision.path}

Applied cells: ${result.applied.length}
Checksum status: ${result.revision.checksumStatus}

Review validation, then use Flash Center separately.`);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){alert(error.message)}finally{renderAiGoalRequest()}}


function evidenceConfidenceLabel(value){return ({'explicit-p01':'EXPLICIT P01','family-unverified':'P01/P59 FAMILY','community-tested':'COMMUNITY TESTED','community-reference':'REFERENCE','primary-source':'PRIMARY SOURCE','negative-validation':'CAUTION'}[value]||String(value||'REFERENCE').toUpperCase())}
function evidenceConfidenceClass(value){if(['explicit-p01','primary-source','community-tested'].includes(value))return value;if(['family-unverified','negative-validation'].includes(value))return value;return 'community-reference'}
function renderP01Evidence(){
  const data=state.p01Evidence;if(!data)return;const summary=data.summary||{};
  const status=$('#p01EvidenceStatus'),summaryBox=$('#p01EvidenceSummary'),registryBox=$('#p01EvidenceRegistry'),importedBox=$('#p01EvidenceImported');if(!status||!summaryBox||!registryBox||!importedBox)return;
  status.textContent=`${Number(summary.publicLogSessions||0)} LOGS · ${Number(summary.definitionReferences||0)} XDFS`;
  summaryBox.innerHTML=`<b>${Number(summary.publicLogSessions||0)} public log sessions found</b><br>${Number(summary.explicitP01Logs||0)} explicitly identified as P01 · ${Number(summary.familyFormatLogs||0)} P01/P59-family sessions needing identity · ${Number(summary.importedItems||0)} locally imported item(s)<br><small>${safe(data.warning||'Public evidence is not a trusted tune rule.')}</small>`;
  const groups=[['live-log','Live logs'],['definition','P01 XDF references'],['calibration-library','BIN/XDF libraries'],['calibration-research','Calibration research'],['tool-reference','Tools and validation'],['logger-reference','Logger definitions']];
  const cards=[];for(const [type,label] of groups){const items=(data.registry||[]).filter(item=>item.type===type);if(!items.length)continue;cards.push(`<div class="evidence-group-label">${safe(label)}</div>`);cards.push(...items.map(item=>`<article class="evidence-card ${evidenceConfidenceClass(item.confidence)}"><div class="evidence-card-head"><div><b>${safe(item.title)}</b><small>${safe(item.attachmentName||item.format||'Public source')}</small></div><span class="evidence-chip ${item.confidence==='family-unverified'||item.confidence==='negative-validation'?'warn':''}">${safe(evidenceConfidenceLabel(item.confidence))}</span></div><div class="evidence-meta"><span class="evidence-chip">${safe(item.controller||'Any')}</span>${item.os?`<span class="evidence-chip">OS ${safe(item.os)}</span>`:''}<span class="evidence-chip">${safe(item.redistribution||'reference')}</span></div><small>${safe(item.notes||item.controllerEvidence||'')}</small><div class="evidence-actions"><button class="ghost p01-evidence-open" data-source-id="${safe(item.id)}">Open Source</button>${['live-log','definition','calibration-library','calibration-research'].includes(item.type)?`<button class="ghost p01-evidence-import-source" data-source-id="${safe(item.id)}">Import Downloaded File</button>`:''}</div></article>`));}
  registryBox.innerHTML=cards.join('')||'<p class="muted">No public sources are registered.</p>';
  const imported=Array.isArray(data.imported)?data.imported:[];importedBox.innerHTML=imported.length?imported.map(item=>{const compatible=item.compatibility?.controllerMatch!==false&&item.compatibility?.osMatch!==false;const blockers=(item.trainingBlockers||[]).map(value=>`<li>${safe(value)}</li>`).join('');return `<article class="evidence-card ${compatible?'':'incompatible'}"><div class="evidence-card-head"><div><b>${safe(item.sourceTitle||item.sourceFileName)}</b><small>${safe(item.sourceFileName)} · ${item.rowCount?`${Number(item.rowCount)} rows · `:''}${item.os?`OS ${safe(item.os)}`:'OS unbound'}</small></div><span class="evidence-chip ${compatible?'':'bad'}">${compatible?'MATCH':'CHECK PROJECT'}</span></div><div class="evidence-meta"><span class="evidence-chip">SHA ${safe(String(item.sourceFileSha256||'').slice(0,10))}</span>${item.normalizedFingerprint?`<span class="evidence-chip">SESSION ${safe(item.normalizedFingerprint.slice(0,10))}</span>`:''}${item.duplicateOf?'<span class="evidence-chip warn">DUPLICATE</span>':''}</div>${blockers?`<ul class="evidence-blockers">${blockers}</ul>`:''}<div class="evidence-actions"><button class="ghost p01-evidence-delete" data-evidence-id="${safe(item.id)}">Remove Local Evidence</button></div></article>`}).join(''):'<p class="muted">Download a referenced file in your browser, then import it here. TunIQ stores a fingerprint and a sanitized normalized copy of logs.</p>';
  $$('.p01-evidence-open').forEach(button=>button.onclick=()=>window.tuniq.openP01EvidenceSource(button.dataset.sourceId).catch(error=>alert(error.message)));
  $$('.p01-evidence-import-source').forEach(button=>button.onclick=()=>importP01Evidence(button.dataset.sourceId));
  $$('.p01-evidence-delete').forEach(button=>button.onclick=async()=>{if(!confirm('Remove this locally imported evidence record and its sanitized copy?'))return;try{state.p01Evidence=await window.tuniq.deleteP01Evidence(button.dataset.evidenceId);renderP01Evidence()}catch(error){alert(error.message)}});
}
async function loadP01Evidence(){state.p01Evidence=await window.tuniq.getP01Evidence();renderP01Evidence();return state.p01Evidence}
async function importP01Evidence(sourceId=''){try{const item=await window.tuniq.importP01Evidence({sourceId,profile:$('#logProfile')?.value||'baseline'});if(!item)return;state.p01Evidence=await window.tuniq.getP01Evidence();renderP01Evidence();const message=item.duplicate?`That file was already imported (${item.duplicateReason}).`:`Imported and fingerprinted ${item.sourceFileName}.${item.rowCount?` ${item.rowCount} usable rows were sanitized.`:''}`;alert(message)}catch(error){alert(error.message)}}

async function loadLiveLogs(){state.liveLogs=await window.tuniq.listLiveLogs();state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];renderLiveLogHistory();return state.liveLogs}
async function loadLiveWorkspace(){state.device=await window.tuniq.getDeviceStatus();state.logSession=state.device.logging||state.logSession;renderDeviceStatus();await Promise.all([loadLiveLogs(),loadP01Evidence()]);if(state.device.connected)startLivePolling();else showLogMessage('Connect the OBDLink MX+ or another serial adapter in Device Manager first.')}
function renderObdLinkImport(result){const status=$('#obdLinkImportStatus'),details=$('#obdLinkImportDetails');if(!result){status.textContent='No phone log imported yet.';details.textContent='Select the same logging profile you used for the drive so TunIQ can check whether the required channels were recorded.';return}const quality=result.importQuality||{};status.textContent=`Imported ${result.samples||0} samples · ${String(quality.status||'unknown').toUpperCase()} quality · ${result.privateColumnsRemoved?.length||0} private/location column(s) removed.`;details.innerHTML=`<b>${safe(result.name||result.sourceFileName||'OBDLink phone log')}</b><br>Mapped: ${safe((result.availableChannels||[]).join(', ')||'No channels')}<br>Missing for this profile: ${safe((result.missingRecommendedChannels||[]).join(', ')||'None')}<br>Sampling: ${quality.sampleRateHz||'unknown'} Hz · Duration: ${quality.durationSeconds||0} sec`;}
async function importObdLinkPhoneLog(){if(!state.activeProject)return alert('Create or activate a project before importing a phone log.');const button=$('#importObdLinkLog');if(button)button.disabled=true;try{const result=await window.tuniq.importObdLinkLog({profile:$('#logProfile').value,name:$('#logName').value});if(!result)return;renderObdLinkImport(result);renderLogAnalysis(result.analysis);await loadLiveLogs();await refreshWorkspace(true);state.lastCompletedLog=result;openOutcomeForm(result)}catch(error){$('#obdLinkImportStatus').textContent=error.message}finally{if(button)button.disabled=false}}
async function showObdLinkGuide(){try{const guide=await window.tuniq.getObdLinkImportGuide($('#logProfile').value);$('#obdLinkImportDetails').innerHTML=`<b>Recommended channels for ${safe(guide.profile)}</b><br>${safe(guide.recommendedFields.join(', '))}<br><br>${guide.instructions.map(item=>`• ${safe(item)}`).join('<br>')}`;$('#obdLinkImportStatus').textContent='Use this checklist before recording the drive in the OBDLink mobile app.'}catch(error){$('#obdLinkImportStatus').textContent=error.message}}
async function startLiveLog(){if(!state.activeProject)return showLogMessage('Create or activate a project before recording.',true);try{state.logSession=await window.tuniq.startLiveLog({profile:$('#logProfile').value,name:$('#logName').value});livePoints.length=0;$('#scanSamples').textContent='0';renderDeviceStatus();startLivePolling();showLogMessage(`Recording ${state.logSession.profileName}. Drive safely and add an event marker when the problem occurs.`);await refreshWorkspace(true)}catch(error){showLogMessage(error.message,true)}}
async function stopLiveLog(){try{const result=await window.tuniq.stopLiveLog();state.logSession=null;renderDeviceStatus();if(result?.analysis)renderLogAnalysis(result.analysis);await loadLiveLogs();await refreshWorkspace(true);if(result){state.lastCompletedLog=result;openOutcomeForm(result);}showLogMessage(result?`Saved ${result.name||result.csvPath?.split(/[\\/]/).pop()||'live log'} with ${result.samples} samples. AI review is ready.`:'No active recording.')}catch(error){showLogMessage(error.message,true)}}
async function markLiveLog(){const label=prompt('Event marker','Problem happened here');if(!label)return;try{await window.tuniq.markLiveLog(label);showLogMessage(`Marker queued: ${label}. It will be attached to the next sample.`)}catch(error){showLogMessage(error.message,true)}}
function toggleDriveMode(){document.body.classList.toggle('drive-mode');$('#logDriveMode').textContent=document.body.classList.contains('drive-mode')?'Exit Drive Mode':'Drive Mode'}


function openOutcomeForm(log){
  if(!log?.csvPath)return;state.lastCompletedLog=log;$('#outcomeLogPath').value=log.csvPath;$('#outcomeRating').value='';$('#outcomeDtcs').value='';$('#outcomeRepairs').value='';$('#outcomeNotes').value='';$('#outcomeWideband').checked=false;$('#outcomeProposalChanged').checked=false;$('#outcomeShare').checked=Boolean(state.beta?.preferences?.improvementOptIn);$('#outcomeStatus').textContent='VIN, email, raw BIN data, and exact file paths are never included.';$('#logOutcomeForm').classList.remove('hidden');$('#logOutcomeForm').scrollIntoView({behavior:'smooth',block:'center'});
}
function closeOutcomeForm(){$('#logOutcomeForm').classList.add('hidden')}
function showBetaMessage(message,bad=false){const el=$('#betaReportStatus');if(el){el.textContent=message;el.classList.toggle('bad',bad)}}
function renderUpdateState(update=state.updates){if(!update)return;state.updates=update;$('#updateState').textContent=String(update.state||'idle').toUpperCase();$('#updateMessage').textContent=update.message||'No update information.';$('#updateDownload').disabled=update.state!=='available';$('#updateInstall').disabled=!update.downloaded;}
function renderBetaProgress(progress=state.beta?.progress||state.progress){
  if(!progress)return;
  const overall=Number(progress.overall||0);$('#betaOverallProgress').textContent=`${overall}%`;$('#betaOverallProgressBar').style.width=`${Math.max(0,Math.min(100,overall))}%`;$('#betaProgressNote').textContent=progress.note||'Evidence-weighted readiness estimate.';
  $('#betaProgressGrid').innerHTML=(progress.areas||[]).map(item=>`<article class="beta-progress-item ${safe(item.status||'')}"><div><b>${safe(item.label)}</b><span>${Number(item.percent||0)}%</span></div><progress max="100" value="${Number(item.percent||0)}"></progress><small>${safe(item.next||'No next action recorded.')}</small>${item.evidence?.length?`<em>${item.evidence.map(safe).join(' · ')}</em>`:''}</article>`).join('')||'<p class="muted">No progress evidence is available yet.</p>';
  $('#betaProgressNext').innerHTML=(progress.nextPriorities||[]).map((item,index)=>`<article><span>${index+1}</span><div><b>${safe(item.label)} · ${Number(item.percent||0)}%</b><small>${safe(item.next)}</small></div></article>`).join('')||'<p class="muted">No remaining priorities were reported.</p>';
}
function renderLaunchReadiness(report=state.launchReadiness||state.beta?.launchReadiness){
  if(!report)return;
  state.launchReadiness=report;
  const score=Number(report.score||0); const blocked=!report.fullLaunchReady;
  if($('#launchReadinessScore'))$('#launchReadinessScore').textContent=`${score}%`;
  if($('#launchReadinessState')){ $('#launchReadinessState').textContent=blocked?'BLOCKED':'RELEASE-CANDIDATE READY'; $('#launchReadinessState').className=`status-badge ${blocked?'beta-blocked':'beta-ok'}`; }
  if($('#launchReadinessSummary'))$('#launchReadinessSummary').textContent=report.summary||'No launch summary.';
  if($('#launchReadinessBlockers')){
    const rows=[...(report.blockers||[]),...(report.warnings||[])];
    $('#launchReadinessBlockers').innerHTML=rows.length?rows.map(item=>`<article class="launch-readiness-item ${safe(item.severity||'warning')}"><div><b>${safe(item.label)}</b><small>${safe(item.detail||'')}</small>${item.action?`<em>${safe(item.action)}</em>`:''}</div><span>${safe(item.severity||'warning')}</span></article>`).join(''):'<p class="muted">No launch blockers or warnings are currently detected.</p>';
  }
}
function renderBetaCenter(){
  const beta=state.beta;if(!beta)return;const prefs=beta.preferences||{},flash=beta.support?.flashing||{},logging=beta.support?.logging||{};
  $('#betaBuildVersion').textContent=`v${state.version||'unknown'}`;$('#betaQueueCount').textContent=`${Number(beta.queueCount||0)} item${Number(beta.queueCount||0)===1?'':'s'}`;
  $('#betaAgreementBadge').textContent=beta.agreementAccepted?'BETA AGREEMENT ACCEPTED':'AGREEMENT NOT ACCEPTED';$('#betaAgreementBadge').className=`status-badge ${beta.agreementAccepted?'beta-ok':'beta-warn'}`;
  $('#betaFlashSupport').textContent=supportLabel(flash.status);$('#betaFlashSupport').className=`support-${supportClass(flash.status)}`;$('#betaFlashSupportNote').textContent=flash.note||'';
  $('#betaLogSupport').textContent=supportLabel(logging.status);$('#betaLogSupport').className=`support-${supportClass(logging.status)}`;$('#betaLogSupportNote').textContent=logging.note||'';
  $('#betaImprove').checked=Boolean(prefs.improvementOptIn);$('#betaShareLogs').checked=Boolean(prefs.shareSanitizedLogs);$('#betaShareCrashes').checked=Boolean(prefs.shareCrashReports);$('#betaExperimental').checked=Boolean(prefs.allowExperimentalHardware);$('#betaUpdateChannel').value=prefs.updateChannel||'beta';$('#betaUpdateFeed').value=prefs.updateFeedUrl||'';if($('#betaReplaySeconds'))$('#betaReplaySeconds').value=String(Number(prefs.incidentReplaySeconds)===30?30:60);const knowledge=state.knowledge||{};if($('#knowledgeMode'))$('#knowledgeMode').value=knowledge.mode?.mode||'recommend';if($('#knowledgeIncidentCount'))$('#knowledgeIncidentCount').textContent=String(Number(knowledge.totalIncidentOccurrences||0));if($('#knowledgeClusterCount'))$('#knowledgeClusterCount').textContent=String(Number(knowledge.incidentClusterCount||0));if($('#knowledgeVerifiedCount'))$('#knowledgeVerifiedCount').textContent=String(Number(knowledge.verifiedIncidentCount||0));
  $('#betaShareLogs').disabled=!prefs.improvementOptIn;$('#betaShareCrashes').disabled=!prefs.improvementOptIn;
  $('#betaMatrixVersion').textContent=`Matrix ${beta.supportMatrixVersion||'unknown'}`;
  $('#betaCompatibilityGrid').innerHTML=(beta.matrix||[]).map(item=>`<article class="compat-card"><span class="support-status ${supportClass(item.status)}">${supportLabel(item.status)}</span><b>${safe(item.label)}</b><small>${safe(item.note)}</small></article>`).join('')||'<p class="muted">No compatibility records loaded.</p>';
  state.progress=beta.progress||state.progress;renderBetaProgress(state.progress);
  state.launchReadiness=beta.launchReadiness||state.launchReadiness;renderLaunchReadiness(state.launchReadiness);
  renderUpdateState(state.updates);
}
async function loadBetaCenter(){state.beta=await window.tuniq.getBetaState();state.updates=await window.tuniq.getUpdateStatus();state.launchReadiness=state.beta?.launchReadiness||await window.tuniq.getLaunchReadiness();try{state.knowledge=await window.tuniq.getKnowledgeState()}catch{}renderBetaCenter();renderWorkspaceStrip();renderFlashWorkspace();}


document.addEventListener('click',event=>recordUiIncident('click',event.target),true);
document.addEventListener('change',event=>recordUiIncident('change',event.target),true);
window.addEventListener('error',event=>recordUiIncident('renderer-error',null,{error:event?.message||'Renderer error'}));
window.addEventListener('unhandledrejection',event=>recordUiIncident('renderer-rejection',null,{error:event?.reason?.message||String(event?.reason||'Unhandled rejection')}));

async function init(){
  if(!window.tuniq)throw new Error('TunIQ desktop bridge did not load. Run the startup recovery file and try again.');
  if(window.tuniq.onFlashProgress)window.tuniq.onFlashProgress(payload=>renderFlashProgress(payload));
  if(window.tuniq.onUpdateStatus)window.tuniq.onUpdateStatus(payload=>renderUpdateState(payload));
  if(window.tuniq.onP01AutoProgress)window.tuniq.onP01AutoProgress(payload=>{const incoming=Number(payload?.stateRevision||0),current=Number(state.p01Auto?.stateRevision||0);if(incoming&&current&&incoming<current)return;state.p01Auto=payload;if(payload?.p01){state.p01=payload.p01;if(state.workspace)state.workspace.p01=payload.p01}renderSafely('Guided P01 Setup',renderP01Auto,payload);renderSafely('Flash Center',renderFlashWorkspace)});
  if(window.tuniq.onClosedLoopUpdate)window.tuniq.onClosedLoopUpdate(payload=>{if(payload?.status)state.closedLoop=payload.status;if(payload?.result?.workspace){state.calibration=normalizeCalibration(payload.result.workspace);calibrationInitialized=true;renderCalibration()}renderClosedLoop();if(payload?.ok){const session=payload.status?.session;notify(session?.status==='waiting-for-validation-log'?'New log processed and an automatic correction revision was created. Record a fresh validation drive.':session?.status==='converged'?'New log processed: closed-loop validation converged.':`New log automatically processed: ${String(session?.status||'complete').replaceAll('-',' ')}.`,'success',9000)}else notify(payload?.error||'Automatic closed-loop log processing stopped.','warning',9000)});
  state=await window.tuniq.getBootstrap();
  state.vehicles=Array.isArray(state.vehicles)?state.vehicles:[];
  state.activity=Array.isArray(state.activity)?state.activity:[];
  state.tools=state.tools&&typeof state.tools==='object'?state.tools:{};
  state.settings=state.settings&&typeof state.settings==='object'?state.settings:{};state.settings.detailLevel=state.settings.detailLevel||'beginner';state.settings.uiPreferences={sidebarCollapsed:false,tunePathCollapsed:false,compactDensity:false,reduceMotion:false,restoreLastPage:true,lastPage:'dashboard',recentPages:['dashboard'],scrollPositions:{},...(state.settings.uiPreferences||{})};
  state.activeProject=state.activeProject||null;
  try{state.knowledge=await window.tuniq.getKnowledgeState()}catch{state.knowledge=null}
  state.aiIntake=state.ai?.intake||null;state.aiPlan=state.ai?.plan||null;
  state.tuneLibrary=Array.isArray(state.tuneLibrary)?state.tuneLibrary:[];
  state.communityPosts=Array.isArray(state.communityPosts)?state.communityPosts:[];state.devices=Array.isArray(state.devices)?state.devices:[];state.device=state.device||{connected:false,connection:null,preferred:{}};state.liveLogs=Array.isArray(state.liveLogs)?state.liveLogs:[];state.sensorProfiles=state.sensorProfiles||{};state.logSession=state.device.logging||null;state.flash=state.flash||null;state.validation=state.validation||null;state.aiProposals=Array.isArray(state.aiProposals)?state.aiProposals:[];state.currentProposal=state.aiProposals[0]||null;state.goalRequests=Array.isArray(state.goalRequests)?state.goalRequests:[];state.goalProposal=state.goalRequests[0]||null;state.p01Evidence=state.p01Evidence&&typeof state.p01Evidence==='object'?state.p01Evidence:null;
  $('#version').textContent=`v${state.version}`;
  populateControllerCatalog();initializeEngineSelector();renderTools();renderVehicles();updateHeader();bindCalibrationControls();
  await loadProjects();
  await refreshProjectFiles();
  await refreshWorkspace(true);
  renderSafely('AI intake',fillAiForm,state.aiIntake);renderSafely('AI plan',renderAiPlan);renderSafely('Guided P01 Setup',renderP01Auto);renderSafely('Tune Library',renderTuneLibrary);renderSafely('Community',renderCommunityPosts);renderSafely('Device status',renderDeviceStatus);renderSafely('Live logs',renderLiveLogHistory);renderSafely('P01 evidence',renderP01Evidence);renderSafely('AI proposals',renderAiProposalWorkspace);renderSafely('AI goal',renderAiGoalRequest);renderSafely('P01 Quick Service',renderQuickService);renderSafely('Beta Center',renderBetaCenter);
  const preferredPage=state.settings.uiPreferences.restoreLastPage&&PAGE_META[state.settings.uiPreferences.lastPage]?state.settings.uiPreferences.lastPage:'dashboard';
  navigationHistory=[preferredPage];navigationIndex=0;currentPage='dashboard';appReady=true;applyUiPreferences();showPage(preferredPage,{record:false,persist:false});renderRecentWork();
  setTimeout(()=>{
    $('#splash').classList.add('hidden');
    $('#app').classList.remove('hidden');
    if(preferredPage!=='dashboard')notify(`Restored ${PAGE_META[preferredPage].title}.`,'info');
    if(!state.beta?.agreementAccepted)$('#betaAgreementModal').classList.remove('hidden');else if(!state.profile||!state.settings.aiMode)$('#wizard').classList.remove('hidden');
  },300);
}
$$('.app-sidebar button').forEach(b=>b.onclick=()=>showPage(b.dataset.page));$$('[data-jump]').forEach(b=>b.onclick=()=>showPage(b.dataset.jump));$('#moduleSearch').oninput=event=>renderAllModules(event.target.value);$('#modeBtn').onclick=()=>showPage('settings');
$('#sidebarToggle').onclick=toggleSidebar;$('#reportBugButton').onclick=openBugReport;$('#navBack').onclick=()=>navigateHistory(-1);$('#navForward').onclick=()=>navigateHistory(1);$('#quickSwitcherButton').onclick=()=>openQuickSwitcher();$('#openQuickSwitcher').onclick=()=>openQuickSwitcher();$('#closeQuickSwitcher').onclick=closeQuickSwitcher;$('#quickSwitcherInput').oninput=()=>{quickSelection=0;renderQuickSwitcher()};$('#headerProjectSwitcher').onchange=event=>{if(event.target.value)switchActiveProject(event.target.value).catch(()=>{});else renderHeaderProjectSwitcher()};$('#quickSwitcher').onclick=event=>{if(event.target.id==='quickSwitcher')closeQuickSwitcher()};
window.addEventListener('scroll',()=>{clearTimeout(scrollSaveTimer);scrollSaveTimer=setTimeout(rememberCurrentScroll,180)},{passive:true});
document.addEventListener('keydown',event=>{const inputLike=['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName);if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();openQuickSwitcher();return}if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='b'){event.preventDefault();toggleSidebar();return}if(event.altKey&&event.key==='ArrowLeft'){event.preventDefault();navigateHistory(-1);return}if(event.altKey&&event.key==='ArrowRight'){event.preventDefault();navigateHistory(1);return}const paletteOpen=!$('#quickSwitcher').classList.contains('hidden');if(event.key==='Escape'&&paletteOpen){event.preventDefault();closeQuickSwitcher();return}if(!paletteOpen||inputLike&&document.activeElement!==$('#quickSwitcherInput'))return;if(event.key==='ArrowDown'){event.preventDefault();quickSelection=Math.min(quickActionCache.length-1,quickSelection+1);renderQuickSwitcher()}else if(event.key==='ArrowUp'){event.preventDefault();quickSelection=Math.max(0,quickSelection-1);renderQuickSwitcher()}else if(event.key==='Enter'){event.preventDefault();runQuickAction()}});
$('#wizardForm').onsubmit=async e=>{e.preventDefault();try{const aiMode=$('input[name="aiMode"]:checked').value;const result=await window.tuniq.saveProfile({name:$('#name').value,email:$('#email').value,units:$('#units').value,aiMode});state.profile=result.profile;state.settings=result.settings;updateHeader();await refreshWorkspace(true);$('#wizard').classList.add('hidden')}catch(err){$('#wizardError').textContent=err.message}};
$('#resetWizard').onclick=()=>{$('#name').value=state.profile?.name||'';$('#email').value=state.profile?.email||'';$('#units').value=state.settings.units||'US';const r=$(`input[name="aiMode"][value="${state.settings.aiMode||'guided'}"]`);if(r)r.checked=true;$('#wizard').classList.remove('hidden')};
$('#modeSelect').onchange=async()=>{state.settings=await window.tuniq.setAiMode($('#modeSelect').value);updateHeader();await refreshWorkspace(true)};
$('#detailSelect').onchange=async()=>{state.settings=await window.tuniq.setDetailLevel($('#detailSelect').value);updateHeader()};
function saveQolFromControls(){const patch={restoreLastPage:$('#qolRestorePage').checked,compactDensity:$('#qolCompactDensity').checked,reduceMotion:$('#qolReduceMotion').checked,sidebarCollapsed:$('#qolCollapseSidebar').checked,tunePathCollapsed:$('#qolCollapseTunePath').checked};state.settings.uiPreferences={...uiPreferences(),...patch};applyUiPreferences();saveUiPreferences(patch,true);notify('Workspace preferences saved.','success')}
['#qolRestorePage','#qolCompactDensity','#qolReduceMotion','#qolCollapseSidebar','#qolCollapseTunePath'].forEach(id=>$(id).onchange=saveQolFromControls);
$('#scanTools').onclick=async event=>{const button=event.currentTarget;button.disabled=true;status('Scanning common install folders, LocalAppData, Desktop, and Downloads...');try{state.tools=await window.tuniq.scanTools();renderTools();await refreshWorkspace(true);const found=Object.values(state.tools).filter(Boolean).length;status(`Scan complete: ${found} of 3 tools ready. Use Browse for any portable copy TunIQ did not find.`)}catch(e){status(e.message,true)}finally{button.disabled=false}};
async function exportDiag(){try{const p=await window.tuniq.exportDiagnostics({description:$('#betaReportDescription')?.value||'',steps:$('#betaReportSteps')?.value||'',currentPage});status(`Diagnostics saved to:\n${p}`);$('#diagText').textContent=`Latest report:\n${p}`}catch(e){status(e.message,true)}}$('#exportDiag').onclick=exportDiag;$('#diagExport2').onclick=exportDiag;
$('#projectForm').onsubmit=async e=>{
  e.preventDefault();
  const selectedVehicle=state.vehicles.find(vehicle=>vehicle.id===$('#projectVehicle').value);const payload={id:$('#projectId').value||null,name:$('#projectName').value,vehicleId:$('#projectVehicle').value,vehicle:selectedVehicle?.name||'',controller:$('#projectController').value,os:$('#projectOs').value,notes:$('#projectNotes').value};
  $('#projectSubmit').disabled=true;
  try{
    if(payload.id){
      const updated=await window.tuniq.updateProject(payload);
      if(updated.active)state.activeProject=updated.active;
      await loadProjects();
      updateActiveProject();
      renderQuickService();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      $('#projectFormStatus').textContent=`Saved ${updated.name}. Project files and revision history were preserved.`;
      status(`Updated project ${updated.name}.`);
      beginProjectEdit(updated.active||updated);
    }else{
      const created=await window.tuniq.createProject(payload);
      state.activeProject=created.active||await window.tuniq.setActiveProject(created.id);
      resetProjectForm();
      await loadProjects();
      updateActiveProject();
      renderQuickService();
      await refreshProjectFiles();
      await refreshWorkspace(true);
      invalidateCalibration('A new project is active. Import and load its BIN and XDF before editing.');
      status(`Created and activated ${state.activeProject.name}. Import its original BIN and matching XDF next.`);
      showPage('files');
    }
  }catch(err){
    $('#projectFormStatus').textContent=err.message;
    alert(err.message);
  }finally{$('#projectSubmit').disabled=false}
};
$('#projectCancelEdit').onclick=resetProjectForm;
$('#newProjectTop').onclick=resetProjectForm;
$('#quickServicePrepareProject').onclick=prepareQuickServiceProject;
$('#quickServiceOpenSetup').onclick=()=>showPage('flash');
$('#quickServiceBuild').onclick=buildQuickServicePlan;
$('#quickServiceConfirmPlan').onclick=confirmQuickServicePlan;
$('#quickServiceApply').onclick=applyQuickServiceRevision;
$('#quickServiceRequest').oninput=invalidateQuickServiceRequest;
$('#quickServiceSafetyFacts').oninput=invalidateQuickServiceRequest;
$('#projectVehicle').onchange=()=>{const vehicle=state.vehicles.find(item=>item.id===$('#projectVehicle').value);if(!vehicle)return;if(vehicle.controller&&!$('#projectController').value.trim())$('#projectController').value=vehicle.controller;if(vehicle.os&&!$('#projectOs').value.trim())$('#projectOs').value=vehicle.os};
$('#detectProjectOs').onclick=async()=>{try{
  const result=await window.tuniq.detectProjectOs();
  if(result.detected){
    $('#projectOs').value=result.os;
    $('#projectOsHelp').textContent=`Detected ${result.os} from ${result.source}. TunIQ saved it to the active project.`;
    $('#projectFormStatus').textContent=result.message;
    if(result.active){state.activeProject=result.active;await loadProjects();await refreshWorkspace(true)}
  }else{
    $('#projectOsHelp').textContent=result.message;
    $('#projectFormStatus').textContent=result.message;
  }
}catch(error){$('#projectOsHelp').textContent=error.message;$('#projectFormStatus').textContent=error.message}};
$('#vehicleForm').onsubmit=async e=>{e.preventDefault();try{const saved=await window.tuniq.saveVehicle({id:$('#vehicleId').value||null,name:$('#vehicleName').value,year:$('#vehicleYear').value,make:$('#vehicleMake').value,model:$('#vehicleModel').value,trim:$('#vehicleTrim').value,mileage:$('#vehicleMileage').value,engine:$('#vehicleEngine').value,transmission:$('#vehicleTransmission').value,drivetrain:$('#vehicleDrivetrain').value,fuel:$('#vehicleFuel').value,tireSize:$('#vehicleTireSize').value,rearGear:$('#vehicleRearGear').value,controller:$('#vehicleController').value,os:$('#vehicleOs').value,hardwareId:$('#vehicleHardwareId').value,serviceNumber:$('#vehicleServiceNumber').value,vin:$('#vehicleVin').value,modifications:$('#vehicleModifications').value,maintenance:$('#vehicleMaintenance').value,notes:$('#vehicleNotes').value});closeVehicleModal();await reloadGarage();notify(`Saved ${saved.name}.`,'success')}catch(err){$('#vehicleError').textContent=err.message;$('#vehicleVinHelp').textContent=err.message}};$('#addVehicleBtn').onclick=()=>openVehicleModal();$('#cancelVehicle').onclick=closeVehicleModal;$('#garageSearch').oninput=renderVehicles;$('#garageFavoritesOnly').onchange=renderVehicles;
$('#deviceScan').onclick=scanDevices;
$('#deviceDoctor').onclick=runConnectionDoctor;
$('#deviceDoctorConnect').onclick=connectDoctorResult;
$('#p01LabRun').onclick=runP01Lab;
$('#deviceImportPids').onclick=async()=>{try{const library=await window.tuniq.importPidLibrary();if(library){const count=(library.profiles||[]).reduce((total,profile)=>total+(profile.channels||[]).length,0);$('#pidProfileState').textContent=`Loaded ${library.profiles.length} controller profile(s) with ${count} enhanced PID channel(s). Reconnect the adapter to activate them.`}}catch(error){$('#pidProfileState').textContent=error.message}};
$('#devicePort').onchange=renderDeviceList;
$('#deviceConnect').onclick=()=>connectSelectedDevice();
$('#deviceDisconnect').onclick=disconnectDevice;
$('#deviceUseDemo').onclick=async()=>{if(!state.devices.some(item=>item.port==='virtual-demo'))state.devices.push({port:'virtual-demo',name:'TunIQ Virtual OBD-II Adapter',transport:'Simulation',demo:true});renderDeviceList();$('#devicePort').value='virtual-demo';await connectSelectedDevice('virtual-demo')};
$('#openDeviceManager').onclick=()=>showPage('devices');
$('#logStart').onclick=startLiveLog;
$('#logStop').onclick=stopLiveLog;
$('#logMarker').onclick=markLiveLog;
$('#logDriveMode').onclick=toggleDriveMode;
$('#refreshLiveLogs').onclick=loadLiveLogs;$('#p01EvidenceRefresh').onclick=loadP01Evidence;$('#p01EvidenceImport').onclick=()=>importP01Evidence('');$('#importObdLinkLog').onclick=importObdLinkPhoneLog;$('#importObdLinkLog2').onclick=importObdLinkPhoneLog;$('#showObdLinkGuide').onclick=showObdLinkGuide;
function ask(q){if(!q)return;$('#messages').insertAdjacentHTML('beforeend',`<div class="msg user">${safe(q)}</div>`);setTimeout(()=>{$('#messages').insertAdjacentHTML('beforeend',`<div class="msg ai"><b>✦ TunIQ Coach</b><br>${offlineAnswer(q)}</div>`);$('#messages').scrollTop=$('#messages').scrollHeight},state.settings.aiMode==='manual'?250:650)}
$('#aiForm').onsubmit=e=>{e.preventDefault();const q=$('#aiInput').value.trim();$('#aiInput').value='';ask(q)};$$('[data-question]').forEach(b=>b.onclick=()=>ask(b.dataset.question));
$('#importBin').onclick=async()=>{try{
  const result=await window.tuniq.importBin();
  if(result){if(result.active)state.activeProject=result.active;invalidateCalibration('The original BIN changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported protected original ${result.name}.${result.detectedOs?` TunIQ detected OS ${result.detectedOs} from ${result.osSource}.`:''} Load BIN + XDF again before exporting.`)}
}catch(error){alert(error.message)}};
$('#importXdf').onclick=async()=>{try{
  const result=await window.tuniq.importXdf();
  if(result){if(result.active)state.activeProject=result.active;invalidateCalibration('The XDF changed. Load the active BIN and XDF mapping again before editing or exporting.');await refreshProjectFiles();await refreshWorkspace(true);status(`Imported ${result.name} with ${result.tableCount} mapped items.${result.detectedOs?` TunIQ detected OS ${result.detectedOs} from ${result.osSource}.`:''} Open the mapping in Calibration Lab to verify it.`)}
}catch(error){alert(error.message)}};
$('#openProjectFolder').onclick=async()=>{try{await window.tuniq.openProjectFolder()}catch(error){alert(error.message)}};
$('#definitionScan').onclick=()=>refreshDefinitionCenter(true).then(()=>notify('Definition scan complete.','success')).catch(error=>notify(error.message,'error'));
$('#definitionResolve').onclick=resolveDefinitionCenter;
$('#definitionImport').onclick=importDefinitionSources;
$('#definitionUniversal').onclick=launchUniversalDefinitionJob;
$('#definitionTunerPro').onclick=launchTunerProRoundtrip;
$('#definitionCheckTunerPro').onclick=inspectTunerProRoundtrip;
$('#definitionImportTunerPro').onclick=importTunerProRoundtrip;
$('#definitionOpenJob').onclick=async()=>{try{const folder=await window.tuniq.openDefinitionJob();notify(`Definition job opened: ${folder}`,'info')}catch(error){notify(error.message,'error')}};
$('#workspaceRefresh').onclick=async()=>{const button=$('#workspaceRefresh');button.disabled=true;try{const result=await window.tuniq.reconcileWorkspace();if(result?.p01)state.p01=result.p01;if(result?.auto)state.p01Auto=result.auto;await refreshWorkspace(true);notify(result?.reconciled?'Workspace state repaired. Resume Failed Step will continue at the stock-clone revision.':'Workspace reloaded from disk.','success',7000)}catch(error){notify(error.message,'error',9000)}finally{button.disabled=false}};
$('#tunePathToggle').onclick=()=>{const collapsed=!$('#tunePathPanel').classList.contains('collapsed');$('#tunePathPanel').classList.toggle('collapsed',collapsed);state.settings.uiPreferences={...uiPreferences(),tunePathCollapsed:collapsed};saveUiPreferences({tunePathCollapsed:collapsed},true)};
$('#flashGoTools').onclick=()=>showPage('bridge');
async function openAssistedPcmHammer(operation='readProperties'){try{const input=$('#flashRevision')?.value||null;const result=await window.tuniq.startAssistedPcmHammer({operation,input,device:$('#flashInterface')?.value.trim()||''});state.flash={...(state.flash||{}),assisted:result};$('#flashConsole').textContent=[result.reason,...(result.instructions||[])].join('\n');await refreshWorkspace(true)}catch(error){$('#flashConsole').textContent=error.message}}
async function importAssistedPcmHammer(){try{const result=await window.tuniq.importAssistedPcmHammer({operation:state.flash?.assisted?.operation||'readProperties',input:$('#flashRevision')?.value||null});if(result){$('#flashConsole').textContent=`Assisted evidence import:\n${(result.imported||[]).map(item=>`${item.accepted?'✓':'×'} ${item.type}: ${item.file}${item.message?` — ${item.message}`:''}`).join('\n')||'No files selected.'}`;await refreshWorkspace(true)}}catch(error){$('#flashConsole').textContent=error.message}}
async function probeFlashCli(){try{$('#flashProbe').disabled=true;$('#flashConsole').textContent='Probing PCM Hammer CLI help and operation capabilities…';const result=await window.tuniq.probeFlashCli({});state.flash={...(state.flash||{}),...result,configured:true};$('#flashConsole').textContent=`PCM Hammer CLI: ${result.executable}\nProbed: ${new Date(result.probedAt).toLocaleString()}\n\nCapabilities:\n${Object.entries(result.capabilities).map(([key,value])=>`${value?'✓':'×'} ${flashCapabilityName(key)}`).join('\n')}\n\n${result.help||''}`;await refreshWorkspace(true)}catch(error){$('#flashConsole').textContent=error.message}finally{$('#flashProbe').disabled=false}}
function flashPayload(operation){return {operation,device:$('#flashInterface').value.trim(),voltage:$('#flashVoltage').value?Number($('#flashVoltage').value):undefined,benchPowerConfirmed:$('#flashBenchPower').checked,input:$('#flashRevision').value,confirmation:$('#flashConfirmation').value.trim()}}
async function startFlash(operation){try{const labels={readProperties:'Reading controller properties',read:'Reading protected original',testWrite:'Running test write',writeCalibration:'Writing calibration',writeFull:'Writing full PCM',recovery:'Starting recovery operation'};$('#flashConsole').textContent=`${labels[operation]||operation}…\nDo not disconnect the interface or power.`;const result=await window.tuniq.startFlashOperation(flashPayload(operation));renderFlashProgress(result);await refreshWorkspace(true)}catch(error){$('#flashSessionState').textContent='BLOCKED';$('#flashConsole').textContent=error.message}}
$('#flashProbe').onclick=probeFlashCli;
$('#flashAssistedOpen').onclick=()=>openAssistedPcmHammer(state.p01Auto?.nextStep==='test-write'?'testWrite':state.p01Auto?.nextStep?.startsWith('read-')?'read':'readProperties');
$('#flashAssistedImport').onclick=importAssistedPcmHammer;
$('#flashInterface').onchange=()=>window.tuniq.saveFlashDevice($('#flashInterface').value.trim()).catch(()=>{});
$('#flashSaveTemplates').onclick=async()=>{try{const templates={readProperties:$('#flashTemplateIdentify').value.trim()||null,read:$('#flashTemplateRead').value.trim()||null,testWrite:$('#flashTemplateTest').value.trim()||null,writeCalibration:$('#flashTemplateWriteCal').value.trim()||null,writeFull:$('#flashTemplateWriteFull').value.trim()||null,recovery:$('#flashTemplateRecovery').value.trim()||null};await window.tuniq.saveFlashTemplates(templates);state.flash=await window.tuniq.getFlashStatus();renderFlashWorkspace();$('#flashConsole').textContent='Saved PCM Hammer CLI command templates. Run Read Properties or Read first before attempting a write.'}catch(error){$('#flashConsole').textContent=error.message}};
$('#flashIdentify').onclick=()=>startFlash('readProperties');
$('#flashRead').onclick=()=>startFlash('read');
$('#p01ImportIdentity').onclick=async()=>{try{const result=await window.tuniq.importP01IdentityProof();if(result){state.p01=result;await refreshWorkspace(true)}}catch(error){alert(error.message)}};
$('#p01ImportReads').onclick=async()=>{try{const result=await window.tuniq.importP01Reads();if(result){state.p01=result;await refreshProjectFiles();await refreshWorkspace(true)}}catch(error){alert(error.message)}};
$('#p01ConfirmDefinition').onclick=async()=>{const os=state.p01?.identity?.os;if(!os)return alert('Run Read Properties for the P01 first.');const typed=prompt(`Type the identified operating system to bind the loaded XDF:\n\n${os}`,'');if(typed===null)return;if(!confirm('Confirm that this XDF came from a trusted source for this exact P01 operating system and that the Calibration page shows no mapping warnings.'))return;try{state.p01=await window.tuniq.confirmP01Definition({typedOs:typed,acknowledged:true});await refreshWorkspace(true)}catch(error){alert(error.message)}};
$('#p01ImportTestWrite').onclick=async()=>{const input=$('#flashRevision')?.value;if(!input)return alert('Select the exact revision used in PCM Hammer Test Write first.');try{state.p01=await window.tuniq.importP01TestWriteProof(input);await refreshWorkspace(true)}catch(error){alert(error.message)}};
$('#p01IdentifyNow').onclick=()=>startFlash('readProperties');
$('#p01ReadNow').onclick=()=>startFlash('read');
$('#p01OpenCalibration').onclick=()=>showPage(state.activeProject?.bin&&state.activeProject?.xdf?'sandbox':'files');
$('#p01Reset').onclick=async()=>{if(!confirm('Reset the saved P01 commissioning proof for this project? Existing BIN and revision files will not be deleted.'))return;try{state.p01=await window.tuniq.resetP01Commissioning();if(state.workspace)state.workspace.p01=state.p01;renderP01Commissioning();renderFlashWorkspace()}catch(error){alert(error.message)}};
$('#flashRevision').onchange=()=>refreshP01ForSelectedRevision();
$('#flashTestWrite').onclick=()=>{if(confirm('Run PCM Hammer Test Write with the selected exact validated revision and stable power? This should be completed before the first real write.'))startFlash('testWrite')};
$('#flashWriteCalibration').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before writing.`);if(confirm(`Write the selected calibration to ${active.name}?\n\nKeep stable 12.5–14 V power and do not disconnect the interface.`))startFlash('writeCalibration')};
$('#flashWriteFull').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`FULL WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before a full write.`);if(confirm(`FULL PCM WRITE for ${active.name}. This is higher risk than calibration-only writing. Continue only with a recovery plan and stable bench power.`))startFlash('writeFull')};
$('#flashRecovery').onclick=()=>{const active=state.activeProject;if(!active)return;const expected=`FULL WRITE ${active.name}`;if($('#flashConfirmation').value.trim()!==expected)return alert(`Type exactly ${expected} before recovery.`);if(confirm('Start the PCM Hammer recovery operation using the selected validated revision?'))startFlash('recovery')};
$('#flashCancel').onclick=async()=>{try{const result=await window.tuniq.cancelFlashOperation();if(result.session)renderFlashProgress(result.session)}catch(error){$('#flashConsole').textContent+=`\n${error.message}`}};

function patchTarget(){return $('#patchRevision').value||undefined}
function renderManagedUniversalPatcher(job){const box=$('#patchManagedStatus');if(!box)return;if(!job){box.textContent='No managed Universal Patcher job has been started.';$('#patchImportUniversal').disabled=true;return}const ready=job.readyBins?.length||0,valid=job.validReports?.length||0;box.textContent=`Managed job: ${job.folder} · compatible changed BINs ${ready} · valid reports ${valid}`;$('#patchImportUniversal').disabled=ready!==1}
async function inspectManagedUniversalPatcher(){try{const job=await window.tuniq.inspectManagedUniversalPatcher();renderManagedUniversalPatcher(job);if(job)$('#patchConsole').textContent=`Managed Universal Patcher job\n${job.folder}\n\nCompatible changed BINs: ${job.readyBins?.length||0}\nValid reports: ${job.validReports?.length||0}\n\n${(job.reportOutputs||[]).map(item=>`${item.name}: ${item.parsed?.valid?'VALID':item.error||'not valid yet'}`).join('\n')}`;return job}catch(error){$('#patchConsole').textContent=error.message;throw error}}
function showValidation(result){state.validation=result;const analysis=result.analysis||result;const diff=analysis.comparison;$('#patchConsole').textContent=[`File: ${result.targetFileName||analysis.name}`,`SHA-256: ${result.targetFileSha256||analysis.sha256}`,`Size: ${analysis.size||diff?.revised?.size||0} bytes`,`Layout: ${result.compatible===false?'MISMATCH':'Compatible'}`,`Checksum: ${result.checksumStatus||analysis.nativeChecksumStatus}`,`Changed bytes: ${diff?.changedBytes??0} (${Number(diff?.changedPercent||0).toFixed(4)}%)`,`Changed segments: ${(diff?.segmentChanges||[]).filter(item=>item.changed).map(item=>item.index).join(', ')||'None'}`,`Native checksum definitions: ${(analysis.nativeChecksums||[]).length}`,...(result.warnings||[]).map(item=>`WARNING: ${item}`),'',JSON.stringify((analysis.nativeChecksums||[]),null,2)].join('\n');renderPatchWorkspace();renderFlashWorkspace()}
$('#patchAnalyze').onclick=async()=>{try{$('#patchConsole').textContent='Analyzing BIN, explicit XDF checksums, segment layout, and imported Universal Patcher reports…';const result=await window.tuniq.analyzeChecksum(patchTarget());showValidation(result);await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchCompare').onclick=async()=>{try{const result=await window.tuniq.compareRevision(patchTarget());$('#patchConsole').textContent=`Original: ${result.original.name}\nRevision: ${result.revised.name}\nSame size: ${result.sameSize}\nChanged bytes: ${result.changedBytes}\nChanged: ${Number(result.changedPercent).toFixed(5)}%\n\nRanges:\n${result.ranges.slice(0,500).map(range=>`0x${range.start.toString(16).toUpperCase()}–0x${range.end.toString(16).toUpperCase()} (${range.length} bytes)`).join('\n')}${result.truncated?'\n…range list truncated':''}` }catch(error){$('#patchConsole').textContent=error.message}};
$('#patchPreviewBin').onclick=async()=>{try{const result=await window.tuniq.previewPatchedBin();if(!result)return;state.patchPreview=result;const diff=result.comparison;$('#patchConsole').textContent=`Patched BIN preview: ${result.sourceFileName}
SHA-256: ${result.sourceFileSha256}
Layout: ${result.compatible?'Compatible':'MISMATCH — import blocked'}
Changed bytes: ${diff.changedBytes} (${Number(diff.changedPercent||0).toFixed(5)}%)
Native checksum status: ${result.analysis.nativeChecksumStatus}
Changed segments: ${(diff.segmentChanges||[]).filter(item=>item.changed).map(item=>item.index).join(', ')||'None'}

Nothing has been copied or applied yet.`;renderPatchWorkspace()}catch(error){state.patchPreview=null;$('#patchConsole').textContent=error.message;renderPatchWorkspace()}};
$('#patchImportBin').onclick=async()=>{try{if(!state.patchPreview)return;if(!confirm(`Import ${state.patchPreview.sourceFileName} as a NEW project revision? The protected original will not be changed.`))return;const result=await window.tuniq.importPatchedBin(state.patchPreview);state.patchPreview=null;$('#patchConsole').textContent=`Imported ${result.name}
Changed bytes: ${result.comparison.changedBytes}
Checksum status: ${result.validation.checksumStatus}

Analyze this exact revision and import a matching Universal Patcher report if its checksum algorithm is not defined by the XDF.`;await refreshProjectFiles();await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchRunUniversal').onclick=async()=>{const button=$('#patchRunUniversal');button.disabled=true;try{const result=await window.tuniq.launchManagedUniversalPatcher({targetFile:patchTarget()});renderManagedUniversalPatcher(result.status);$('#patchConsole').textContent=`Universal Patcher managed validation started.\nWorking copy: ${result.job.manifest.workingFile}\nProtected source: ${result.job.manifest.sourceFile}\n\nSave corrected/exported BINs into the job Output folder and reports into Reports. TunIQ will compare and import them as a new revision.`;notify('Managed Universal Patcher validation started.','info',7000)}catch(error){$('#patchConsole').textContent=error.message}finally{button.disabled=false}};
$('#patchCheckUniversal').onclick=()=>inspectManagedUniversalPatcher().catch(()=>{});
$('#patchImportUniversal').onclick=async()=>{if(!confirm('Import the single compatible Universal Patcher output as a NEW revision and validate it? The protected original remains unchanged.'))return;try{const result=await window.tuniq.importManagedUniversalPatcher();$('#patchConsole').textContent=`Imported managed Universal Patcher output as ${result.revision.name}\nSHA-256: ${result.revision.sha256}\nChecksum status: ${result.validation.checksumStatus}`;renderManagedUniversalPatcher(result.job);await refreshProjectFiles();await refreshWorkspace(true);notify('Universal Patcher output imported as a protected revision.','success')}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchImportReport').onclick=async()=>{try{const result=await window.tuniq.importUniversalPatcherReport(patchTarget());if(result){$('#patchConsole').textContent=`Imported ${result.report.name}\nValid: ${result.report.valid}\nErrors: ${result.report.errors}\nWarnings: ${result.report.warnings}\n\n${result.report.entries.map(item=>`${item.severity.toUpperCase()}: ${item.text}`).join('\n')}`;await refreshWorkspace(true)}}catch(error){$('#patchConsole').textContent=error.message}};
$('#patchCorrect').onclick=async()=>{try{if(!confirm('Create a NEW revision with the explicit XDF checksum fields corrected? The current revision and original remain unchanged.'))return;const result=await window.tuniq.correctExplicitChecksums(patchTarget());$('#patchConsole').textContent=`Created ${result.name}\nCorrected ${result.corrections.length} checksum field(s).\nStatus: ${result.analysis.checksumStatus}`;await refreshWorkspace(true)}catch(error){$('#patchConsole').textContent=error.message}};
$('#openRevisionsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('revisions')}catch(error){alert(error.message)}};
$('#openLogsFolder').onclick=async()=>{try{await window.tuniq.openProjectSubfolder('logs')}catch(error){alert(error.message)}};
$('#labLoadXdf').onclick=loadRealCalibration;
$('#labExportBin').onclick=async()=>{try{
  if(state.calibration?.mode!=='xdf')throw new Error('Load a BIN and XDF mapping first.');
  if(state.calibration.projectId!==state.activeProject?.id)throw new Error('Reload the BIN and XDF for the active project before exporting.');
  if(!validateCalibration())throw new Error('Fix out-of-range values before exporting.');
  await persistCalibration();
  const result=await window.tuniq.exportBin(state.calibration);
  alert(`Revision BIN exported safely:\n${result.path}\n\nModified cells: ${result.modifiedCells}\nSHA-256: ${result.sha256}`);
  await refreshProjectFiles();
  await refreshWorkspace(true);
}catch(error){alert(error.message)}};

$$('.ai-mod').forEach(input=>input.onchange=updateAiCamVisibility);
$('#aiTuneGoal').onchange=updateAiCamVisibility;
optionalSpecInputs().forEach(([,selector])=>$(selector).oninput=updateOptionalSpecState);
$('#aiFindOptionalSpecs').onclick=useKnownOptionalSpecs;
$('#autonomousTuneStart').onclick=()=>runAutonomousTune('complete',false);
$('#autonomousTuneResume').onclick=()=>runAutonomousTune('complete',true);
$('#autonomousTuneCycle').onclick=()=>runAutonomousTune('log-cycle',false);
$('#autonomousTuneReset').onclick=async()=>{if(!confirm('Archive this project’s current Autonomous Tune run? Calibration snapshots and exported BIN revisions will remain.'))return;try{const result=await window.tuniq.resetAutonomousTune();state.autonomousTune=await window.tuniq.getAutonomousTuneStatus();renderAutonomousTune();notify(result.reset?'Autonomous Tune run archived.':'No Autonomous Tune run existed.','success')}catch(error){notify(error.message,'error')}};
$('#closedLoopStart').onclick=()=>runClosedLoopAction('start');
$('#closedLoopAnalyze').onclick=()=>runClosedLoopAction('analyze');
$('#closedLoopRun').onclick=()=>runClosedLoopAction('run');
$('#closedLoopRollback').onclick=()=>{if(confirm('Restore the last closed-loop rollback point and export a rollback revision?'))runClosedLoopAction('rollback')};
$('#closedLoopReport').onclick=()=>runClosedLoopAction('report');
$('#closedLoopReset').onclick=()=>{if(confirm('Archive the current closed-loop session? Logs, snapshots, revisions, and reports will remain.'))runClosedLoopAction('reset')};
$('#tuneEngineBuild').onclick=async()=>{const button=$('#tuneEngineBuild');button.disabled=true;try{const result=await window.tuniq.buildTuneEnginePlan({intake:collectAiPayload(),targets:collectTuneEngineTargets()});state.aiIntake=result.intake;state.tuneEngine=result.status;state.tuneEngineProposal=null;renderTuneEngine();renderAiPlan();notify(`Unified Tune Engine plan built at ${result.plan.readiness.score}% readiness with ${result.plan.coverage.availableRoles} recognized XDF roles.`,'success');await refreshWorkspace(true)}catch(error){notify(error.message,'error');$('#tuneEnginePlanSummary').textContent=error.message}finally{button.disabled=false}};
$('#tuneEngineReset').onclick=async()=>{if(!confirm('Archive this project’s Tune Engine plan, proposals, and audit trail, then start clean? Calibration snapshots and BIN revisions will remain.'))return;try{const result=await window.tuniq.resetTuneEngine();state.tuneEngine=null;state.tuneEngineProposal=null;renderTuneEngine();notify(result.reset?'Tune Engine archived and reset.':'No Tune Engine plan existed to reset.','success')}catch(error){notify(error.message,'error')}};
$('#tuneEngineApply').onclick=async()=>{const proposal=state.tuneEngineProposal;if(!proposal)return;const approvedIds=$$('.tune-engine-approve:checked').map(box=>box.value);if(!approvedIds.length)return notify('Approve at least one exact Tune Engine cell.','warning');if(!confirm(`Apply ${approvedIds.length} approved cell(s), create before/after snapshots, validate checksums, and export a new revision? The protected original will not be changed.`))return;const button=$('#tuneEngineApply');button.disabled=true;try{const result=await window.tuniq.applyTuneEngineStage({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;state.tuneEngine=result.status;state.tuneEngineProposal=null;renderCalibration();renderTuneEngine();notify(`${result.applied.length} Tune Engine cell(s) applied. Revision ${result.revision.name} was exported and validation-recorded.`,'success');await refreshProjectFiles();await refreshWorkspace(true)}catch(error){notify(error.message,'error')}finally{renderTuneEngineProposal()}};
$('#tuneEngineHandoff').onclick=async()=>{const button=$('#tuneEngineHandoff');button.disabled=true;try{const result=await window.tuniq.createTuneEngineHandoff({});state.tuneEngineHandoff=result;$('#tuneEngineHandoffStatus').innerHTML=`Bundle created: <b>${safe(result.folder)}</b> — click here to open it.`;$('#tuneEngineHandoffStatus').onclick=()=>window.tuniq.openTuneEngineHandoff(result.folder).catch(error=>notify(error.message,'error'));notify('Tune Engine handoff bundle created with the plan, fingerprints, change summary, and latest revision.','success')}catch(error){notify(error.message,'error');$('#tuneEngineHandoffStatus').textContent=error.message}finally{button.disabled=!state.tuneEngine?.plan}};
$('#aiSaveIntake').onclick=async()=>{try{const intake=await window.tuniq.saveAiIntake(collectAiPayload());state.aiIntake=intake;$('#fullAiError').textContent='Build intake saved to the active project. Generate the plan when the hardware and goal are complete.';$('#fullAiError').classList.remove('bad');renderAiPlan();await refreshWorkspace(true)}catch(error){showFullAiError(error)}};
$('#fullAiForm').onsubmit=async event=>{event.preventDefault();$('#aiGeneratePlan').disabled=true;try{const result=await window.tuniq.generateAiPlan(collectAiPayload());state.aiIntake=result.intake;state.aiPlan=result.plan;$('#fullAiError').textContent=`Generated ${result.plan.steps.length} project-specific steps. No calibration bytes or controller data were changed.`;$('#fullAiError').classList.remove('bad');renderAiPlan();await refreshWorkspace(true)}catch(error){showFullAiError(error)}finally{$('#aiGeneratePlan').disabled=false}};
$('#aiBuildGoalRequest').onclick=buildAiGoalRequest;
if($('#p01StartNewProject'))$('#p01StartNewProject').onclick=startNewP01Service;if($('#p01ResetCommissioning'))$('#p01ResetCommissioning').onclick=resetCurrentP01Commissioning;if($('#p01ArchiveProject'))$('#p01ArchiveProject').onclick=archiveCurrentP01Project;$('#p01AutoAnalyze').onclick=analyzeP01AutoRequest;$('#p01AutoConfirmRequest').onclick=confirmP01AutoRequest;$('#p01AutoRequest').oninput=invalidateP01AutoRequestReview;$('#p01AutoSafetyFacts').oninput=invalidateP01AutoRequestReview;$('#p01AutoStart').onclick=startP01Auto;$('#p01AutoResume').onclick=resumeP01Auto;$('#p01AutoRecover').onclick=recoverP01Auto;if($('#p01AutoBluetoothRepair'))$('#p01AutoBluetoothRepair').onclick=repairP01Bluetooth;if($('#p01AutoBluetoothPair'))$('#p01AutoBluetoothPair').onclick=openBluetoothPairing;if($('#p01AutoManualPortVerify'))$('#p01AutoManualPortVerify').onclick=verifyP01ManualPort;if($('#p01AutoManualPcmHammer'))$('#p01AutoManualPcmHammer').onclick=tryP01ManualPcmHammerPort;if($('#p01AutoBluetoothSetup'))$('#p01AutoBluetoothSetup').onclick=openBluetoothComSetup;$('#p01AutoAssistedBypass').onclick=bypassP01AutoAssisted;$('#p01AutoChooseXdf').onclick=chooseP01AutoXdf;if($('#p01AutoCopyDetails'))$('#p01AutoCopyDetails').onclick=copyP01TechnicalDetails;$('#p01AutoCancel').onclick=cancelP01Auto;$('#p01AutoWrite').onclick=writeP01Auto;$('#p01HardwareDoctorRefresh').onclick=refreshHardwareSessionDoctor;$('#p01HardwareDoctorExport').onclick=exportHardwareSessionReport;$('#p01HardwareDoctorOpenLog').onclick=openHardwareSessionLog;$('#p01HardwareDoctorOpenReports').onclick=openHardwareSessionReports;if($('#p01HardwareDoctorOpenSnapshot'))$('#p01HardwareDoctorOpenSnapshot').onclick=openHardwareSessionSnapshot;
$('#aiConfirmGoalMap').onclick=confirmP01GoalMap;$('#aiApplyGoalRequest').onclick=applyAiGoalRequest;
$('#aiGenerateProposal').onclick=async()=>{const csvPath=$('#aiProposalLog').value;if(!csvPath)return alert('Choose a saved CSV log first.');$('#aiGenerateProposal').disabled=true;try{state.currentProposal=await window.tuniq.generateAiProposal(csvPath);state.aiProposals=[state.currentProposal,...(state.aiProposals||[]).filter(item=>item.id!==state.currentProposal.id)];renderAiProposalWorkspace();await refreshWorkspace(true)}catch(error){$('#aiProposalSummary').textContent=error.message}finally{$('#aiGenerateProposal').disabled=false}};
$('#aiApplyProposal').onclick=async()=>{const proposal=state.currentProposal;if(!proposal)return;const approvedIds=$$('.ai-proposal-approve:checked').map(box=>box.value);if(!approvedIds.length)return alert('Approve at least one proposed cell.');if(!confirm(`Apply ${approvedIds.length} approved cell change(s) and export a new revision? The protected original will not be changed.`))return;$('#aiApplyProposal').disabled=true;try{const result=await window.tuniq.applyAiProposal({proposalId:proposal.id,approvedIds});state.calibration=normalizeCalibration(result.workspace);calibrationInitialized=true;renderCalibration();alert(`AI-approved revision exported:
${result.revision.path}

Applied cells: ${result.applied.length}
Checksum status: ${result.revision.checksumStatus}`);await refreshProjectFiles();await refreshWorkspace(true)}catch(error){alert(error.message)}finally{renderAiProposalWorkspace()}};
$('#showTuneSave').onclick=()=>{const form=$('#tuneSaveForm');form.classList.remove('hidden');const active=state.activeProject,intake=state.aiIntake;setValue('#tuneName',active?`${active.name} Tune`:'');setValue('#tuneGoal',intake?.tuneGoal||'');setValue('#tuneEngine',intake?.engine||'');setValue('#tuneTransmission',intake?.transmission||'');setValue('#tuneFuel',intake?.fuel||'');setValue('#tuneTags',(intake?.modifications||[]).join(', '));form.scrollIntoView({behavior:'smooth',block:'start'})};
$('#cancelTuneSave').onclick=()=>$('#tuneSaveForm').classList.add('hidden');
$('#tuneSaveForm').onsubmit=async event=>{event.preventDefault();try{const entry=await window.tuniq.saveActiveTune({name:$('#tuneName').value,tuneGoal:$('#tuneGoal').value,engine:$('#tuneEngine').value,transmission:$('#tuneTransmission').value,fuel:$('#tuneFuel').value,tags:$('#tuneTags').value,description:$('#tuneDescription').value});$('#tuneSaveStatus').textContent=`Saved ${entry.name} with SHA-256 ${entry.sourceSha256.slice(0,16)}…`;$('#tuneSaveForm').classList.add('hidden');await loadTuneLibrary();await refreshWorkspace(true)}catch(error){$('#tuneSaveStatus').textContent=error.message}};
$('#importTunePackage').onclick=async()=>{try{const entry=await window.tuniq.importTune();if(entry){await loadTuneLibrary();alert(`Imported ${entry.name} into the local Tune Library.`)}}catch(error){alert(error.message)}};
['#tuneSearch','#tuneEngineFilter','#tuneTransmissionFilter','#tuneControllerFilter'].forEach(id=>$(id).oninput=renderTuneLibrary);$('#tuneFavoritesOnly').onchange=renderTuneLibrary;
['#communitySearch','#communityEngine','#communityTransmission','#communityController'].forEach(id=>$(id).oninput=renderCommunityPosts);$('#communityCategory').onchange=renderCommunityPosts;
$('#communityPostForm').onsubmit=async event=>{event.preventDefault();try{const post=await window.tuniq.createCommunityPost({category:$('#postCategory').value,title:$('#postTitle').value,engine:$('#postEngine').value,transmission:$('#postTransmission').value,controller:$('#postController').value,tags:$('#postTags').value,body:$('#postBody').value,attachProject:$('#postAttachProject').checked});$('#postStatus').textContent=`Saved local draft: ${post.title}`;$('#communityPostForm').reset();$('#postAttachProject').checked=true;await loadCommunityPosts()}catch(error){$('#postStatus').textContent=error.message}};


$('#betaAgreementForm').onsubmit=async event=>{event.preventDefault();if(!$('#betaAgreementCheck').checked)return;try{state.beta=await window.tuniq.acceptBetaAgreement(true);$('#betaAgreementModal').classList.add('hidden');renderBetaCenter();renderFlashWorkspace();if(!state.profile||!state.settings.aiMode)$('#wizard').classList.remove('hidden')}catch(error){$('#betaAgreementError').textContent=error.message}};
$('#betaAgreementRead').onclick=()=>window.tuniq.openBetaDocument('agreement').catch(error=>$('#betaAgreementError').textContent=error.message);
$('#logOutcomeForm').onsubmit=async event=>{event.preventDefault();try{const result=await window.tuniq.saveLogOutcome({csvPath:$('#outcomeLogPath').value,rating:$('#outcomeRating').value,newDtcs:$('#outcomeDtcs').value,repairsMade:$('#outcomeRepairs').value,notes:$('#outcomeNotes').value,widebandUsed:$('#outcomeWideband').checked,aiProposalChanged:$('#outcomeProposalChanged').checked,consentToImprove:$('#outcomeShare').checked,engine:state.aiIntake?.engine||'',tuneGoal:state.aiIntake?.tuneGoal||''});state.beta=result.state;$('#outcomeStatus').textContent='Result saved. Thank you for documenting the outcome.';renderBetaCenter();setTimeout(closeOutcomeForm,700)}catch(error){$('#outcomeStatus').textContent=error.message}};
$('#outcomeCancel').onclick=closeOutcomeForm;
$('#betaImprove').onchange=()=>{$('#betaShareLogs').disabled=!$('#betaImprove').checked;$('#betaShareCrashes').disabled=!$('#betaImprove').checked;if(!$('#betaImprove').checked){$('#betaShareLogs').checked=false;$('#betaShareCrashes').checked=false}};
$('#betaPreferencesForm').onsubmit=async event=>{event.preventDefault();try{state.beta=await window.tuniq.saveBetaPreferences({improvementOptIn:$('#betaImprove').checked,shareSanitizedLogs:$('#betaShareLogs').checked,shareCrashReports:$('#betaShareCrashes').checked,allowExperimentalHardware:$('#betaExperimental').checked,updateChannel:$('#betaUpdateChannel').value,updateFeedUrl:$('#betaUpdateFeed').value,incidentReplaySeconds:Number($('#betaReplaySeconds')?.value||60)});state.updates=await window.tuniq.getUpdateStatus();$('#betaPreferenceStatus').textContent='Privacy and beta preferences saved locally.';renderBetaCenter();renderFlashWorkspace()}catch(error){$('#betaPreferenceStatus').textContent=error.message}};
if($('#knowledgeMode'))$('#knowledgeMode').onchange=async event=>{try{state.knowledge=await window.tuniq.setKnowledgeMode(event.target.value);renderBetaCenter();showBetaMessage(`AI learning mode changed to ${event.target.options[event.target.selectedIndex].text}.`)}catch(error){showBetaMessage(error.message,true)}};
$('#betaCreateReport').onclick=async()=>{try{
  if(!state.incidentReplay)state.incidentReplay=await window.tuniq.captureIncidentReplay({currentPage,reason:'create-diagnostic',windowMs:Number(state.beta?.preferences?.incidentReplaySeconds||60)*1000});
  const file=await window.tuniq.exportDiagnostics({description:$('#betaReportDescription').value,steps:$('#betaReportSteps').value,currentPage,incidentReplayId:state.incidentReplay?.id||''});
  if(file){showBetaMessage(`Privacy-safe diagnostic package created with ${state.incidentReplay?.summary?.eventCount||0} replay events:
${file}`);try{state.knowledge=await window.tuniq.getKnowledgeState();renderBetaCenter()}catch{}}
}catch(error){showBetaMessage(error.message,true)}};
$('#betaExportQueue').onclick=async()=>{try{const file=await window.tuniq.exportImprovementQueue();if(file)showBetaMessage(`Improvement package exported:\n${file}`)}catch(error){showBetaMessage(error.message,true)}};
$('#betaSubmitQueue').onclick=async()=>{try{const result=await window.tuniq.submitImprovementQueue();state.beta=result.state;showBetaMessage(`Submitted ${result.submitted} queued item(s).`);renderBetaCenter()}catch(error){showBetaMessage(error.message,true)}};
$('#betaClearQueue').onclick=async()=>{if(!confirm('Delete all locally queued improvement data?'))return;state.beta=await window.tuniq.clearImprovementQueue();showBetaMessage('Queued improvement data deleted.');renderBetaCenter()};
$('#betaResetAgreement').onclick=async()=>{if(!confirm('Reset the Public Beta Agreement? Controller operations will be blocked until it is accepted again.'))return;state.beta=await window.tuniq.acceptBetaAgreement(false);renderBetaCenter();renderFlashWorkspace();$('#betaAgreementCheck').checked=false;$('#betaAgreementModal').classList.remove('hidden')};
$$('.beta-doc').forEach(button=>button.onclick=()=>window.tuniq.openBetaDocument(button.dataset.document).catch(error=>showBetaMessage(error.message,true)));
if($('#exportLaunchReadiness'))$('#exportLaunchReadiness').onclick=async()=>{try{const file=await window.tuniq.exportLaunchReadiness();if(file)notify('Launch readiness audit exported.','success')}catch(error){notify(error.message,'error')}};
$('#updateCheck').onclick=async()=>{try{renderUpdateState({state:'checking',message:'Checking for updates…'});state.updates=await window.tuniq.checkForUpdates();renderUpdateState(state.updates)}catch(error){renderUpdateState({state:'error',message:error.message})}};
$('#updateDownload').onclick=async()=>{try{state.updates=await window.tuniq.downloadUpdate();renderUpdateState(state.updates)}catch(error){renderUpdateState({state:'error',message:error.message})}};
$('#updateInstall').onclick=async()=>{try{await window.tuniq.installUpdate()}catch(error){renderUpdateState({state:'error',message:error.message})}};

init().catch(e=>{document.body.innerHTML=`<pre style="padding:30px;color:#ffb18d">Startup error: ${safe(e.stack||e.message)}</pre>`});
