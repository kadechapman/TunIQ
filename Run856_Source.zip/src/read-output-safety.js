'use strict';
const fs = require('fs');
const path = require('path');

// Windows treats these names as devices even when an extension is present.
// ':' in a filename can address an NTFS alternate data stream, while trailing
// dots/spaces can normalize to another file. Win32 also reserves superscript
// 1/2/3 COM/LPT variants and console aliases. Invalid Win32 filename chars
// must be rejected before invoking the CLI. Check on every OS so Linux CI
// exercises the same policy as the Windows installer.
function unsafeWindowsPathComponent(name) {
  if (!name) return false;
  // A backslash inside a POSIX component is a Win32 separator. Reject it
  // before a Linux/macOS preflight can bless a name Windows interprets as
  // a different path (possibly a device or alternate data stream). On Win32
  // path.basename() already splits ordinary backslash directory separators.
  // Invisible Unicode formatting controls, bidirectional overrides and
  // line/paragraph separators can make a backup filename look different in
  // the UI, logs and filesystem. Reject them before normalization, including
  // DEL/C1 controls and lone UTF-16 surrogates; printable Unicode is fine.
  return /[\\:<>"|?*\x00-\x1f]/.test(name) ||
    /[\p{Cc}\p{Cf}\p{Cs}\p{Zl}\p{Zp}]/u.test(name) || /[. ]$/.test(name) ||
    /^(?:CON|PRN|AUX|NUL|CONIN\$|CONOUT\$|COM[1-9¹²³]|LPT[1-9¹²³])(?:\..*)?$/i.test(name);
}

// Device namespaces (\\.\, \\?\, \??\) and UNC shares must not be used
// for a protected ECU backup. The raw path must be checked BEFORE resolving
// it, because normalization can conceal its original Win32 meaning.
function unsafeReadNamespace(output) {
  // A single leading backslash is a Win32 *current-drive-rooted* path.
  // For example, \Temp\read.bin silently resolves against whichever drive
  // PCM Hammer happens to use, not the directory selected by TunIQ. Reject
  // it on every host so Linux regression tests cover Windows semantics.
  // A single leading forward slash is also drive-rooted on Windows, but is
  // a normal absolute POSIX path on Linux/macOS.
  return /^\\/.test(output) || (process.platform === 'win32' && /^\/(?!\/)/.test(output)) ||
    /^[\\/]{2}/.test(output) || /^[\\/](?:\?\?|Device|GLOBALROOT)[\\/]/i.test(output) ||
    /^[a-z]:(?![\\/])/i.test(output);
}

function namespaceStop() {
  return { ok: false, code: 'read-output-unsafe-namespace',
    message: 'Full Read output must use an ordinary local folder. Windows device namespaces, UNC/network shares, and drive-relative paths are not accepted as verified backup destinations.' };
}

function windowsAliasStop() {
  return { ok: false, code: 'read-output-windows-alias',
    message: 'The full-read filename or folder uses a Windows device name, invalid character, alternate data stream, or trailing dot/space alias. Choose an ordinary new .bin path.' };
}

// Validate the caller's ORIGINAL path components, not only path.resolve().
// Both POSIX and Win32 normalization can erase an unsafe component before
// the resolved path is checked (e.g. "NUL.bin/../read.bin"). Such a spelling
// must never be admitted as a verified ECU backup path. A leading "C:" is
// a legitimate absolute Windows drive prefix, not a filename component.
function unsafeRawWindowsPathComponent(output) {
  return output.split(/[\\/]/).some((component, index) =>
    component !== '.' && component !== '..' &&
    !(index === 0 && /^[A-Za-z]:$/.test(component)) &&
    unsafeWindowsPathComponent(component));
}

// Read-only safety: never hand PCM Hammer an existing output or a destination
// beneath a symlink/junction. This is a fail-closed path check, NOT an atomic
// reservation: callers must repeat it immediately before spawning the CLI.
// Shared policy for both new CLI destinations and already-created/assisted
// read imports. Validation must not accept Windows aliases or remote/device
// namespaces merely because a 512-KB file exists at that spelling.
function checkSafeReadPath(output) {
  if (typeof output !== 'string' || !output.trim()) {
    return { ok: false, code: 'read-output-invalid', message: 'Select a full-read BIN filename.' };
  }
  if (unsafeReadNamespace(output)) return namespaceStop();
  // Reject unsafe raw segments before path.resolve() can normalize them away.
  if (unsafeRawWindowsPathComponent(output)) return windowsAliasStop();
  const resolved = path.resolve(output);
  if (unsafeWindowsPathComponent(path.basename(resolved))) return windowsAliasStop();
  for (let folder = path.dirname(resolved); ; folder = path.dirname(folder)) {
    if (folder !== path.parse(folder).root && unsafeWindowsPathComponent(path.basename(folder))) {
      return windowsAliasStop();
    }
    if (folder === path.parse(folder).root) break;
  }
  return { ok: true, resolved };
}

function checkUnusedReadDestination(output, { allowMissingParents = false } = {}) {
  const safe = checkSafeReadPath(output);
  if (!safe.ok) return safe;
  const { resolved } = safe;
  for (let folder = path.dirname(resolved); ; folder = path.dirname(folder)) {
    if (folder !== path.parse(folder).root && unsafeWindowsPathComponent(path.basename(folder))) {
      return windowsAliasStop();
    }
    try {
      const stat = fs.lstatSync(folder);
      if (stat.isSymbolicLink()) {
        return { ok: false, code: 'read-output-symlink-parent', message: 'The full-read destination is inside a symbolic-link or junction directory. Choose a real local folder.' };
      }
      if (!stat.isDirectory()) {
        return { ok: false, code: 'read-output-unavailable', message: 'The full-read destination parent is not a directory.' };
      }
    } catch (error) {
      if (error.code === 'ENOENT' && allowMissingParents) {
        // Preflight may create a new directory only after inspecting every
        // existing ancestor. The caller MUST recheck with the strict default
        // immediately after mkdir and before launching PCM Hammer.
        if (folder === path.parse(folder).root) break;
        continue;
      }
      // A missing ancestor is not a usable output directory. Letting this
      // through can authorize a second CLI profile after an ambiguous first
      // attempt, even though no real backup destination was available.
      // Require an existing directory chain; never create folders here.
      return { ok: false, code: 'read-output-unavailable',
        message: 'The full-read destination parent does not exist. Create and verify the local backup folder before starting a read.' };
    }
    if (folder === path.parse(folder).root) break;
  }
  try {
    fs.lstatSync(resolved);
    return { ok: false, code: 'read-output-exists', message: 'The full-read destination already exists. Choose a new filename; TunIQ will not overwrite or rename an existing BIN, partial read, or symlink.' };
  } catch (error) {
    if (error.code !== 'ENOENT') {
      return { ok: false, code: 'read-output-unavailable', message: `The full-read destination cannot be checked safely: ${error.message}` };
    }
  }
  return { ok: true, resolved };
}

module.exports = { checkUnusedReadDestination, checkSafeReadPath };
