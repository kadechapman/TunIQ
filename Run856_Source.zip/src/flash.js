const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');
const {
  P01_BIN_SIZE, OPERATIONS, normalizeOperation, tokenizeTemplate, expandTemplate, parseProgress,
  parseIdentityText, parseBackendIdentity, inferTemplates, classifyPcmHammerResult,
  validateP01ReadFile, assistedInstructions, sha256File, clean
} = require('./pcmhammer');
const { IntelligentConnectionManager } = require('./intelligent-connection-manager');
const { P01HardwareTransactionManager } = require('./p01-hardware-transaction');
const { buildPcmHammerDeviceSpec, safeTypedDeviceFallback } = require('./pcmhammer-device-lease');
const { validateProvenPortBinding } = require('./p01-proven-port');
const { checkUnusedReadDestination } = require('./read-output-safety');
const {
  profilesForOperation, profileCapabilities, profileMatchingTemplate, isRecognizedPcmHammerExecutable,
  safeToRetryProfile, isPortOpenFailure, hasCommunicationActivity, looksLikeCliUsageOnly, outputWasCreated
} = require('./pcmhammer-integrated');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function safeName(value) { return String(value || 'PCM').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'PCM'; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function hardwareSettle(ms) { return process.platform === 'win32' ? ms : Math.min(ms, 25); }
function uniqueFiles(files = []) { return [...new Set(files.filter(Boolean).map(file => path.resolve(String(file))))]; }

// A failed or cancelled Full Read must not remain under an apparently usable
// backup name. Never use a timestamp-only rename: renameSync may REPLACE an
// existing rejected BIN on Windows and POSIX. Reserve a random destination
// with exclusive hardlink creation, or a bounded exclusive copy on filesystems
// without hardlink support. The source is removed only if its identity has not
// changed during quarantine. Failure leaves evidence unadmitted and reports a
// warning; no retry, ECU operation, or backup promotion is authorized here.
function quarantineRejectedReadOutput(output) {
  if (!output) return {};
  let original;
  try { original = fs.lstatSync(output); }
  catch (error) { return error.code === 'ENOENT' ? {} : { warning: clean(error.message, 500) }; }
  if (!original.isFile() || original.isSymbolicLink() || original.size > 2 * P01_BIN_SIZE)
    return { warning: 'Unverified read output is not a bounded regular file; it was not moved or accepted.' };
  for (let attempt = 0; attempt < 4; attempt++) {
    const rejected = `${output}.rejected-${Date.now()}-${crypto.randomBytes(8).toString('hex')}`;
    try {
      try { fs.linkSync(output, rejected); }
      catch (error) {
        if (error.code === 'EEXIST') continue;
        if (!['EPERM', 'EOPNOTSUPP', 'ENOTSUP', 'EXDEV', 'ENOSYS'].includes(error.code)) throw error;
        fs.copyFileSync(output, rejected, fs.constants.COPYFILE_EXCL);
      }
      const current = fs.lstatSync(output);
      if (current.dev !== original.dev || current.ino !== original.ino ||
          current.size !== original.size || current.mtimeMs !== original.mtimeMs)
        return { path: rejected, warning: 'Read output changed during quarantine; original was retained and remains unadmitted.' };
      try { fs.unlinkSync(output); }
      catch (error) { return { path: rejected, warning: `Rejected evidence was copied but original could not be removed: ${clean(error.message, 350)}` }; }
      return { path: rejected };
    } catch (error) {
      if (error.code === 'EEXIST') continue;
      return { warning: `Could not quarantine rejected read output: ${clean(error.message, 350)}` };
    }
  }
  return { warning: 'Could not reserve a unique rejected-read destination; output remains unadmitted.' };
}
function fileFingerprint(file) {
  try { const stat = fs.statSync(file); return `${path.resolve(file)}:${stat.size}:${stat.mtimeMs}`; } catch { return path.resolve(String(file)); }
}

function isKernelFileName(name = '') { return /^(?:Kernel|Loader)-.+\.bin$/i.test(String(name)); }
function kernelFilesInFolder(folder) {
  try {
    return fs.readdirSync(folder, { withFileTypes: true })
      .filter(entry => entry.isFile() && isKernelFileName(entry.name))
      .map(entry => path.join(folder, entry.name));
  } catch { return []; }
}
function findKernelFolders(root, maxDepth = 4, maxFolders = 800) {
  if (!root) return [];
  const found = []; const seen = new Set(); const queue = [{ folder: path.resolve(root), depth: 0 }];
  while (queue.length && seen.size < maxFolders) {
    const item = queue.shift();
    if (!item || seen.has(item.folder)) continue;
    seen.add(item.folder);
    const kernels = kernelFilesInFolder(item.folder);
    if (kernels.length) found.push({ folder: item.folder, files: kernels });
    if (item.depth >= maxDepth) continue;
    let entries = [];
    try { entries = fs.readdirSync(item.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      if (!entry.isDirectory() || entry.isSymbolicLink()) continue;
      if (/^(?:node_modules|dist|logs?|projects?|revisions?|originals?|reports?)$/i.test(entry.name)) continue;
      queue.push({ folder: path.join(item.folder, entry.name), depth: item.depth + 1 });
    }
  }
  return found;
}
function portOpenTimedOut(text = '') {
  return /(?:could\s+not\s+open\s+the\s+selected\s+device[^\n]*timed\s+out|timed\s+out\s+trying\s+to\s+open\s+(?:serial\s+)?port)/i.test(String(text || ''));
}
function kernelFilesMissing(text = '') {
  return /(?:no\s+\.bin\s+kernel\s+files\s+found|kernel\s+directory[^\n]*(?:missing|not\s+found|empty))/i.test(String(text || ''));
}

// A malformed persisted prefix is not proof of a safe empty command line.
// The restricted beta accepts only an absent/null value or an empty array.
function hasUnreviewedCliPrefixArgs(value) {
  return value != null && (!Array.isArray(value) || value.length > 0);
}

function allowsDirectPcmHammerHandoff(operation = '') {
  try { return ['readProperties', 'read', 'testWrite'].includes(normalizeOperation(operation)); }
  catch { return false; }
}

class FlashStopError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'FlashStopError'; this.code = code; this.details = details; }
}

class FlashManager {
  constructor(options) {
    // Public beta is read-only by default. Legacy synthetic write simulations may
    // opt out only through a test-only constructor path, never through IPC/settings.
    this.readOnlyBeta = options.readOnlyBeta === true || !(options.platform === 'test' && options.allowSimulatedWrites === true);
    // Synthetic Node mock CLI fixtures need a script-path prefix. This test-only
    // escape hatch is unavailable when the application explicitly enables read-only.
    this.allowSimulatedCliPrefixArgs = options.platform === 'test' && options.allowSimulatedCliPrefixArgs === true && options.readOnlyBeta !== true;
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.getToolPath = options.getToolPath;
    this.getDeviceStatus = options.getDeviceStatus || (() => ({}));
    this.releasePort = options.releasePort || (async () => ({ released: false }));
    this.probePortLock = options.probePortLock || (async () => ({ available: true, locked: false, supported: false }));
    this.findAlternatePorts = options.findAlternatePorts || (async () => []);
    this.abortBridgeRequests = options.abortBridgeRequests || (() => ({ aborted: 0 }));
    this.appendActivity = options.appendActivity || (() => {});
    this.emit = options.emit || (() => {});
    this.onReadComplete = options.onReadComplete || (() => {});
    this.onIdentifyComplete = options.onIdentifyComplete || (() => {});
    this.onSessionComplete = options.onSessionComplete || (() => {});
    this.inspectExclusiveSession = options.inspectExclusiveSession || (async () => ({ blocked: false, conflicts: [], warnings: [] }));
    this.createSafetySnapshot = options.createSafetySnapshot || (async reason => ({ verified: true, reused: true, reason, path: '', source: 'no-snapshot-provider' }));
    this.registerOwnedProcess = options.registerOwnedProcess || (() => null);
    this.releaseOwnedProcess = options.releaseOwnedProcess || (() => false);
    this.connectionManagerRequired = Boolean(options.connectionManager);
    this.connectionManager = options.connectionManager || new IntelligentConnectionManager({ dataRoot: this.dataRoot, listDevices: async () => [], probePort: details => this.probePortLock(details), appendActivity: this.appendActivity });
    this.session = null;
    this.startPending = false; // Synchronous admission guard across asynchronous Windows COM preflight.
    this.externalPortAccessPending = false; // Serial repair/probe must never overlap PCM Hammer.
    this.history = null;
    this.assistedWatchers = new Map();
    this.readWatchdogPollMs = Math.max(100, Number(options.readWatchdogPollMs || process.env.TUNIQ_READ_WATCHDOG_POLL_MS || 2000));
    this.readStallTimeoutMs = Math.max(this.readWatchdogPollMs * 4, Number(options.readStallTimeoutMs || process.env.TUNIQ_READ_STALL_TIMEOUT_MS || 900000));
    this.portOwner = { owner: 'idle', port: '', operation: '', leaseId: '', since: null };
    this.hardwareTransaction = options.hardwareTransaction || new P01HardwareTransactionManager({
      dataRoot: this.dataRoot,
      platform: options.platform || process.platform,
      interOperationCooldownMs: options.interOperationCooldownMs,
      reopenRecoveryDelayMs: options.reopenRecoveryDelayMs
    });
  }

  assertReadOnlyBetaOperation(operation) {
    const normalized = normalizeOperation(operation);
    if (this.readOnlyBeta && !['readProperties', 'read'].includes(normalized)) {
      throw new FlashStopError('read-only-beta-write-blocked',
        `Restricted TunIQ beta permits Read Properties and Full Read only; ${clean(normalized, 80)} is disabled. No PCM command was launched.`);
    }
    return normalized;
  }

  // Assisted imports are untrusted files, not proof of a completed hardware
  // operation. The restricted beta must never turn an arbitrary 512-KB BIN or
  // user-supplied log into a verified Full Read / Test Write ledger entry.
  assertAssistedEvidenceAllowed() {
    if (this.readOnlyBeta) throw new FlashStopError('read-only-beta-assisted-evidence-blocked',
      'Restricted TunIQ beta does not accept assisted/manual PCM Hammer evidence as verified hardware results. Use the integrated read-only CLI for Read Properties and Full Read.');
  }

  configFile() { return path.join(this.dataRoot(), 'Tools', 'pcmhammer-cli.json'); }
  sessionsRoot() { return ensureDir(path.join(this.dataRoot(), 'Logs', 'Flash')); }
  historyFile() { return path.join(this.sessionsRoot(), 'history.json'); }
  assistedStateFile(active = this.getActiveProject()) { return active?.folder ? path.join(active.folder, 'Reports', 'p01-assisted-pcmhammer.json') : null; }
  assistedFolder(active = this.getActiveProject()) { return active?.folder ? ensureDir(path.join(active.folder, 'Imports', 'PCM-Hammer-Assisted')) : null; }
  getHistory() { if (!Array.isArray(this.history)) this.history = readJson(this.historyFile(), []); return Array.isArray(this.history) ? this.history : []; }
  recordHistory(session) {
    const summary = { ...session, child: undefined, readWatchdogTimer: undefined, log: Array.isArray(session.log) ? session.log.slice(-120) : [] };
    const history = this.getHistory(); history.unshift(summary); if (history.length > 150) history.length = 150;
    this.history = history; writeJson(this.historyFile(), history); return summary;
  }
  getConfig() {
    const fallback = {
      executable: '', prefixArgs: [], device: '', mode: 'auto', probedAt: null, helpText: '',
      integratedProfileId: '', integrationMode: 'unprobed', profileAttempts: [],
      lastSuccessfulDevice: '', lastSuccessfulAt: null, lastSuccessfulOperation: '', lastSuccessfulProfileId: '',
      lastDeviceCandidates: [], lastDeviceDiscoveryAt: null,
      templates: { readProperties: null, read: null, testWrite: null, writeCalibration: null, writeFull: null, recovery: null }
    };
    const config = readJson(this.configFile(), fallback) || fallback;
    if (!config.templates?.readProperties && config.templates?.identify) config.templates.readProperties = config.templates.identify;
    delete config.templates?.identify;
    const normalized = { ...fallback, ...config, templates: { ...fallback.templates, ...(config.templates || {}) } };
    const inferred = inferTemplates(normalized.helpText || '');
    let repaired = false;
    for (const operation of Object.keys(OPERATIONS)) {
      if (!inferred[operation]) continue;
      if (JSON.stringify(normalized.templates[operation]) !== JSON.stringify(inferred[operation])) {
        normalized.templates[operation] = inferred[operation]; repaired = true;
      }
    }
    if (repaired || Number(normalized.commandSchemaVersion || 0) < 2) {
      normalized.commandSchemaVersion = 2;
      if (Object.values(inferred).some(Boolean)) normalized.integrationMode = 'help-driven';
      normalized.commandRepair = repaired ? { at: new Date().toISOString(), source: 'saved-cli-help', message: 'PCM Hammer command templates were rebuilt from the installed CLI usage text.' } : normalized.commandRepair || null;
      try { writeJson(this.configFile(), normalized); } catch {}
    }
    return normalized;
  }
  saveConfig(patch = {}) {
    const current = this.getConfig();
    const next = { ...current, ...patch, templates: { ...current.templates, ...(patch.templates || {}) }, updatedAt: new Date().toISOString() };
    delete next.templates.identify;
    writeJson(this.configFile(), next);
    return next;
  }

  resolveExecutable() {
    const config = this.getConfig();
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const candidates = [];
    if (config.executable) candidates.push(config.executable);
    if (toolPath) {
      const folder = path.extname(toolPath) ? path.dirname(toolPath) : toolPath;
      candidates.push(toolPath);
      for (const name of ['PcmHammerCLI.exe', 'PCM Hammer CLI.exe', 'pcmhammer-cli.exe', 'PcmHammer.Console.exe', 'PcmHammerCLI']) candidates.push(path.join(folder, name));
    }
    for (const candidate of candidates) {
      try {
        if (fs.statSync(candidate).isFile() && /(?:cli|console)/i.test(path.basename(candidate))) {
          const cliPrefixArgsBlocked = this.readOnlyBeta && !this.allowSimulatedCliPrefixArgs && hasUnreviewedCliPrefixArgs(config.prefixArgs);
          return {
            executable: candidate,
            // Do not expose untrusted arguments even to a future caller that
            // forgets to call assertReadOnlyCliPrefixArgs before spawning.
            prefixArgs: cliPrefixArgsBlocked ? [] : (Array.isArray(config.prefixArgs) ? config.prefixArgs : []),
            cliPrefixArgsBlocked
          };
        }
      } catch {}
    }
    return null;
  }
  // A saved prefix is executable command content, not harmless configuration.
  // Even an audited read-only profile becomes unsafe when prefixed with an
  // arbitrary write verb. Reject before ANY CLI spawn; never silently strip
  // the prefix and accidentally change a user's configured invocation.
  assertReadOnlyCliPrefixArgs(resolved) {
    if (this.readOnlyBeta && resolved?.cliPrefixArgsBlocked) {
      throw new FlashStopError('read-only-beta-prefix-args-blocked',
        'Restricted TunIQ beta cannot run PCM Hammer with custom executable prefix arguments. Clear prefixArgs in the PCM Hammer CLI configuration and re-probe; no CLI or PCM command was launched.');
    }
    return resolved;
  }

  // A probe records a SHA-256 fingerprint, not a publisher signature. Once
  // present, refuse a different executable/path instead of silently trusting
  // changed bytes during a later read or discovery. Unprobed legacy installs
  // remain unpinned and are NOT thereby verified as authentic.
  cliIntegrity(resolved, config = this.getConfig()) {
    const backend = config.backend || {};
    const expected = backend.sha256;
    if (expected == null || expected === '') return { pinned: false, blocked: false };
    // A digest without its original executable path is not a complete pin.
    // Do not let malformed metadata silently downgrade path validation.
    if (!resolved || typeof expected !== 'string' || !/^[a-f0-9]{64}$/i.test(expected) ||
        typeof backend.executable !== 'string' || !backend.executable.trim()) {
      return { pinned: true, blocked: true };
    }
    const normalizePath = value => {
      const resolvedPath = path.resolve(String(value));
      return process.platform === 'win32' ? resolvedPath.toLowerCase() : resolvedPath;
    };
    if (normalizePath(backend.executable) !== normalizePath(resolved.executable)) {
      return { pinned: true, blocked: true };
    }
    try {
      return { pinned: true, blocked: sha256File(resolved.executable).toLowerCase() !== String(expected).toLowerCase() };
    } catch { return { pinned: true, blocked: true }; }
  }

  assertPinnedCliIntegrity(resolved, config = this.getConfig()) {
    if (this.readOnlyBeta && this.cliIntegrity(resolved, config).blocked) {
      throw new FlashStopError('cli-executable-integrity-changed',
        'PCM Hammer CLI no longer matches its previously probed SHA-256/path. Stop read-only operations and inspect or reinstall the trusted CLI package before resetting the saved probe. No PCM command was launched.');
    }
    return resolved;
  }

  resolveGuiExecutable() {
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const config = this.getConfig();
    const candidates = [];
    const addFolder = folder => {
      if (!folder) return;
      for (const name of ['PcmHammer.exe', 'PCM Hammer.exe', 'pcmhammer.exe']) candidates.push(path.join(folder, name));
    };
    if (config.guiExecutable) candidates.push(config.guiExecutable);
    for (const source of [toolPath, config.executable]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      if (!/(?:cli|console)/i.test(path.basename(source))) candidates.push(source);
      addFolder(folder);
      addFolder(path.dirname(folder)); // Portable releases commonly place Cli\ beside PcmHammer.exe.
      addFolder(path.join(folder, '..', 'PcmHammer'));
      addFolder(path.join(folder, '..', 'GUI'));
    }
    for (const candidate of [...new Set(candidates.map(item => path.resolve(item)))]) {
      try { if (fs.statSync(candidate).isFile() && !/(?:cli|console)/i.test(path.basename(candidate))) return candidate; } catch {}
    }
    return null;
  }

  saveGuiExecutable(executable) {
    if (!executable) return this.saveConfig({ guiExecutable: null });
    const resolved = path.resolve(String(executable));
    if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile() || /(?:cli|console)/i.test(path.basename(resolved))) {
      throw new FlashStopError('gui-invalid', 'Select the normal PcmHammer.exe application, not a CLI or console executable.');
    }
    return this.saveConfig({ guiExecutable: resolved });
  }

  resolveKernelDirectory(executableOverride = '') {
    const config = this.getConfig();
    const resolved = executableOverride ? { executable: executableOverride } : this.resolveExecutable();
    const executable = resolved?.executable || config.executable || '';
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const gui = this.resolveGuiExecutable();
    const roots = [];
    const add = (folder, source, priority = 0) => {
      if (!folder) return;
      const resolvedFolder = path.resolve(String(folder));
      if (!roots.some(item => item.folder === resolvedFolder)) roots.push({ folder: resolvedFolder, source, priority });
    };
    add(config.kernelDir, 'configured', 500);
    for (const source of [executable, toolPath, gui]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      add(folder, 'tool-folder', 260);
      add(path.join(folder, 'Kernels'), 'kernels-subfolder', 420);
      add(path.join(folder, 'Kernel'), 'kernel-subfolder', 400);
      if (/(?:cli|console|bin)$/i.test(path.basename(folder))) {
        add(path.dirname(folder), 'tool-parent', 300);
        add(path.join(path.dirname(folder), 'Kernels'), 'parent-kernels', 450);
        add(path.join(path.dirname(folder), 'Kernel'), 'parent-kernel', 430);
      }
    }
    const results = [];
    for (const root of roots) {
      const direct = kernelFilesInFolder(root.folder);
      if (direct.length) results.push({ folder: root.folder, files: direct, source: root.source, score: root.priority + direct.length });
      if (!fs.existsSync(root.folder)) continue;
      for (const found of findKernelFolders(root.folder, root.priority >= 400 ? 1 : 3)) {
        const nameBonus = /kernels?/i.test(path.basename(found.folder)) ? 80 : 0;
        const distancePenalty = Math.max(0, found.folder.split(path.sep).length - root.folder.split(path.sep).length) * 8;
        results.push({ ...found, source: root.source, score: root.priority + nameBonus + found.files.length - distancePenalty });
      }
    }
    const best = results
      .filter(item => item.files.length > 0)
      .sort((a, b) => b.score - a.score || b.files.length - a.files.length || a.folder.localeCompare(b.folder))[0] || null;
    return best ? { folder: best.folder, files: uniqueFiles(best.files), source: best.source, fileCount: best.files.length } : null;
  }

  async discoverCliDevices() {
    const resolved = this.resolveExecutable();
    if (!resolved) return [];
    this.assertReadOnlyCliPrefixArgs(resolved);
    this.assertPinnedCliIntegrity(resolved);
    try {
      const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, '--list-devices'], 10000);
      if (Number(result.code) !== 0) return [];
      const devices = [];
      for (const line of String(result.text || '').split(/\r?\n/)) {
        if (!line || /usage|example|--device/i.test(line)) continue;
        const matches = [...line.matchAll(/\bCOM\d+\b/gi)];
        for (const match of matches) {
          const port = match[0].toUpperCase();
          if (devices.some(item => item.port === port)) continue;
          const recognized = /obdlink|scan\s*tool|stn11|stn21/i.test(line);
          const outgoing = /outgoing|client/i.test(line);
          const incoming = /incoming|server/i.test(line);
          devices.push({ port, name: clean(line, 300), recognized, recommended: recognized || outgoing, outgoing, incoming, source: 'pcmhammer-list-devices' });
        }
      }
      return devices.sort((a, b) => Number(b.recommended) - Number(a.recommended) || Number(b.outgoing) - Number(a.outgoing) || Number(a.incoming) - Number(b.incoming) || a.port.localeCompare(b.port, undefined, { numeric: true }));
    } catch { return []; }
  }

  async resolveDeviceCandidates(selectedPort = '', operation = '') {
    const candidates = [];
    const add = (port, source, metadata = {}) => {
      const cleanPort = clean(port, 40);
      if (!cleanPort || candidates.some(item => item.port.toUpperCase() === cleanPort.toUpperCase())) return;
      candidates.push({ port: cleanPort, source, ...metadata });
    };
    add(selectedPort, 'selected');
    const remembered = this.getConfig().lastSuccessfulDevice || '';
    if (remembered && String(remembered).toUpperCase() !== String(selectedPort || '').toUpperCase()) add(remembered, 'last-successful-port', { recognized: true, recommended: true, recoveryScore: 1000 });
    if (['readProperties', 'read', 'testWrite'].includes(String(operation || ''))) {
      let alternates = [];
      try { alternates = await this.findAlternatePorts(selectedPort); } catch {}
      for (const item of Array.isArray(alternates) ? alternates : []) add(item.port, 'recognized-alternate', item);
      let cliDevices = [];
      try { cliDevices = await this.discoverCliDevices(); } catch {}
      for (const item of cliDevices) add(item.port, item.source || 'pcmhammer-list-devices', item);
      // A previous successful Windows scan remains useful after an app restart or when a
      // transient PowerShell/CIM request fails. Only non-destructive operations use this list.
      for (const item of this.getConfig().lastDeviceCandidates || []) add(item.port, 'saved-device-inventory', item);
    }
    if (candidates.length) {
      try {
        this.saveConfig({
          lastDeviceCandidates: candidates.slice(0, 12).map(item => ({
            port: item.port, name: clean(item.name || '', 300), source: item.source || '',
            recognized: Boolean(item.recognized), recommended: Boolean(item.recommended),
            bluetooth: Boolean(item.bluetooth), outgoing: Boolean(item.outgoing), incoming: Boolean(item.incoming),
            pairKey: clean(item.pairKey || '', 300), recoveryScore: Number(item.recoveryScore || 0)
          })),
          lastDeviceDiscoveryAt: new Date().toISOString()
        });
      } catch {}
    }
    return candidates;
  }

  mergeDeviceCandidates(existing = [], discovered = []) {
    const merged = [];
    for (const item of [...(Array.isArray(existing) ? existing : []), ...(Array.isArray(discovered) ? discovered : [])]) {
      const port = clean(item?.port, 40);
      if (!port) continue;
      const prior = merged.find(candidate => candidate.port.toUpperCase() === port.toUpperCase());
      if (!prior) merged.push({ ...item, port });
      else Object.assign(prior, Object.fromEntries(Object.entries(item).filter(([, value]) => value !== '' && value != null && value !== false)));
    }
    return merged;
  }

  async refreshSessionDeviceCandidates(session, reason = 'runtime-rescan') {
    const before = Array.isArray(session.deviceCandidates) ? session.deviceCandidates.map(item => item.port) : [];
    let discovered = [];
    try { discovered = await this.resolveDeviceCandidates(session.initialDevice || session.device || '', session.operation); } catch {}
    session.deviceCandidates = this.mergeDeviceCandidates(session.deviceCandidates, discovered);
    const added = session.deviceCandidates.filter(item => !before.some(port => String(port).toUpperCase() === String(item.port).toUpperCase()));
    session.deviceDiscoveryPasses = [...(session.deviceDiscoveryPasses || []), {
      at: new Date().toISOString(), reason, before, discovered: discovered.map(item => item.port), added: added.map(item => item.port)
    }].slice(-12);
    return added;
  }

  async handoffPort(port, operation, leaseId, source = 'selected') {
    const bridgeBefore = this.abortBridgeRequests(`PCM Hammer direct lease ${leaseId} pre-release`) || { aborted: 0 };
    if (bridgeBefore.pendingExit) throw Object.assign(new Error('OBD bridge exit is unverified; PCM Hammer COM handoff blocked.'), { code: 'bridge-exit-pending' });
    const release = await this.releasePort({ port, operation, leaseId, owner: 'pcmhammer' });
    const bridgeAfter = this.abortBridgeRequests(`PCM Hammer direct lease ${leaseId} post-release`) || { aborted: 0 };
    if (bridgeAfter.pendingExit) throw Object.assign(new Error('OBD bridge exit is unverified after release; PCM Hammer start blocked.'), { code: 'bridge-exit-pending' });
    const bridge = { aborted: Number(bridgeBefore.aborted || 0) + Number(bridgeAfter.aborted || 0), before: bridgeBefore, after: bridgeAfter };
    // Bluetooth SPP handles can remain in a closing state after the owning PowerShell process
    // exits. Give Windows a bounded settle period before PCM Hammer opens the port.
    await sleep(hardwareSettle(750));
    this.setPortOwner('pcmhammer', { port, operation, leaseId });
    return { port, source, release, bridge, at: new Date().toISOString(), lockProbe: { skipped: true, reason: 'direct PCM Hammer lease' } };
  }

  async prepareExclusivePcmHammerLane(port, operation, leaseId, source = 'proven-pcmhammer-exclusive') {
    const bridge = this.abortBridgeRequests(`PCM Hammer exclusive lane ${leaseId}`) || { aborted: 0 };
    if (bridge.pendingExit) throw Object.assign(new Error('OBD bridge exit is unverified; exclusive PCM Hammer lane blocked.'), { code: 'bridge-exit-pending' });
    // The proven P01 path must not open, probe, disconnect, or otherwise touch the serial
    // endpoint before PCM Hammer. Only PCM Hammer is allowed to own the COM handle here.
    await sleep(hardwareSettle(1250));
    this.setPortOwner('pcmhammer', { port, operation, leaseId });
    return {
      port,
      source,
      release: { released: false, skipped: true, reason: 'PCM Hammer exclusive serial ownership' },
      bridge,
      at: new Date().toISOString(),
      lockProbe: { skipped: true, reason: 'proven P01 PCM Hammer-exclusive lane' },
      exclusivePcmHammerOwnership: true
    };
  }

  async runCapture(executable, args, timeout = 15000) {
    return new Promise((resolve, reject) => {
      // A CLI may change between help/version/list-devices probes. Recheck the
      // saved executable pin immediately before every capture subprocess.
      try { this.assertPinnedCliIntegrity({ executable }, this.getConfig()); }
      catch (error) { reject(error); return; }
      const child = spawn(executable, args, { windowsHide: true, cwd: path.dirname(executable) });
      let stdout = ''; let stderr = ''; let finished = false;
      const done = value => { if (finished) return; finished = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => { try { child.kill(); } catch {} reject(new Error('PCM Hammer CLI probe timed out.')); }, timeout);
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => done({ code, stdout, stderr, text: `${stdout}\n${stderr}`.trim() }));
    });
  }

  async probe(payload = {}) {
    // Help/version probes spawn PCM Hammer subprocesses too. Hold the same
    // exclusive admission latch used for serial repair, but do NOT cancel an
    // active read or mutate CLI config when the adapter is already owned.
    return this.withExclusiveExternalPortAccess('PCM Hammer CLI probe',
      () => this._probeWithoutLease(payload), { requestRecovery: false });
  }

  async _probeWithoutLease(payload = {}) {
    // Reject supplied prefixes before persisting the CLI configuration or
    // spawning help/version probes. Existing malformed configs are also
    // rejected by assertReadOnlyCliPrefixArgs below.
    if (this.readOnlyBeta && !this.allowSimulatedCliPrefixArgs && hasUnreviewedCliPrefixArgs(payload.prefixArgs)) {
      throw new FlashStopError('read-only-beta-prefix-args-blocked',
        'Restricted TunIQ beta cannot probe PCM Hammer with CLI prefix arguments. No CLI command was launched.');
    }
    if (payload.executable) this.saveConfig({ executable: payload.executable, prefixArgs: payload.prefixArgs || [] });
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer 2.x CLI was not found. Configure the pcmhammer-cli executable in Tool Connections.');
    this.assertReadOnlyCliPrefixArgs(resolved);
    this.assertPinnedCliIntegrity(resolved);
    let helpResult = null;
    const probeAttempts = [];
    for (const attempt of [['--help'], ['-h'], ['help'], []]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt]);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text?.length > 20) { helpResult = result; break; }
      } catch (error) {
        // A changed executable is a safety stop, not a recoverable syntax
        // probe failure. Never silently re-pin the substituted bytes.
        if (error.code === 'cli-executable-integrity-changed') throw error;
        probeAttempts.push({ args: attempt, error: clean(error.message, 500) });
      }
    }
    let versionText = '';
    for (const attempt of [['--version'], ['-v'], ['version']]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt], 8000);
        probeAttempts.push({ args: attempt, code: result.code, text: clean(result.text, 1200) });
        if (result.text) { versionText = result.text; break; }
      } catch (error) {
        // A changed executable is a safety stop, not a recoverable syntax
        // probe failure. Never silently re-pin the substituted bytes.
        if (error.code === 'cli-executable-integrity-changed') throw error;
        probeAttempts.push({ args: attempt, error: clean(error.message, 500) });
      }
    }
    const combined = `${versionText}\n${helpResult?.text || ''}`;
    const parsedBackend = parseBackendIdentity(combined, resolved.executable);
    const recognizedExecutable = isRecognizedPcmHammerExecutable(resolved.executable, parsedBackend);
    const backend = {
      ...parsedBackend,
      product: parsedBackend.product || (recognizedExecutable ? 'PCM Hammer' : ''),
      recognizedExecutable,
      sha256: sha256File(resolved.executable),
      executable: resolved.executable
    };
    const inferred = inferTemplates(helpResult?.text || '');
    const existing = this.getConfig();
    const kernel = this.resolveKernelDirectory(resolved.executable);
    const templates = {};
    for (const operation of Object.keys(OPERATIONS)) templates[operation] = inferred[operation] || existing.templates?.[operation] || null;
    const helpCapabilities = Object.fromEntries(Object.entries(templates).map(([key, value]) => [key, Boolean(value)]));
    const cachedCapabilities = profileCapabilities(existing.integratedProfileId);
    const runtimeDiscovery = recognizedExecutable && !Object.values(helpCapabilities).some(Boolean) && !Object.values(cachedCapabilities).some(Boolean);
    const capabilities = Object.fromEntries(Object.keys(OPERATIONS).map(operation => [
      operation,
      Boolean(helpCapabilities[operation] || cachedCapabilities[operation] || (runtimeDiscovery && ['readProperties','read'].includes(operation)))
    ]));
    const integrationMode = Object.values(helpCapabilities).some(Boolean) ? 'help-driven'
      : Object.values(cachedCapabilities).some(Boolean) ? 'cached-profile'
        : runtimeDiscovery ? 'runtime-profile-discovery' : 'unsupported';
    const official = Boolean(parsedBackend.official || existing.backend?.verifiedByOperation);
    const stop = !recognizedExecutable ? { code: 'unsupported-cli', message: 'The selected executable is not recognized as PCM Hammer CLI.' } : null;
    const config = this.saveConfig({
      executable: resolved.executable,
      prefixArgs: resolved.prefixArgs,
      helpText: (helpResult?.text || '').slice(0, 50000),
      versionText: versionText.slice(0, 5000),
      backend: { ...backend, official, integrationReady: integrationMode !== 'unsupported' },
      templates,
      integrationMode,
      profileAttempts: probeAttempts.slice(-12),
      kernelDir: kernel?.folder || '',
      kernelFiles: kernel?.files?.map(file => path.basename(file)) || [],
      kernelDetectedAt: kernel ? new Date().toISOString() : null,
      probedAt: new Date().toISOString(),
      lastProbeStop: stop
    });
    return {
      executable: resolved.executable,
      backend: config.backend,
      capabilities: Object.fromEntries(Object.entries(capabilities).map(([operation, enabled]) => [operation, Boolean(enabled && (!this.readOnlyBeta || ['readProperties', 'read'].includes(operation)))])),
      templates: config.templates,
      help: (helpResult?.text || '').slice(0, 16000),
      probedAt: config.probedAt,
      assistedAvailable: Boolean(this.resolveGuiExecutable()),
      mode: integrationMode,
      integratedProfileId: config.integratedProfileId || '',
      kernel: kernel ? { folder: kernel.folder, files: kernel.files.map(file => path.basename(file)), fileCount: kernel.fileCount, source: kernel.source } : null,
      stop
    };
  }

  status() {
    const resolved = this.resolveExecutable();
    const config = this.getConfig();
    const active = this.getActiveProject();
    const assisted = active ? readJson(this.assistedStateFile(active), null) : null;
    const integrity = this.cliIntegrity(resolved, config);
    const cliBlocked = Boolean(resolved?.cliPrefixArgsBlocked || (this.readOnlyBeta && integrity.blocked));
    return {
      configured: Boolean(resolved && !cliBlocked), executable: resolved?.executable || null,
      backend: config.backend || null,
      capabilities: Object.fromEntries(Object.keys(OPERATIONS).map(operation => [operation, Boolean(!cliBlocked && (!this.readOnlyBeta || ['readProperties', 'read'].includes(operation)) && (config.templates?.[operation] || profileCapabilities(config.integratedProfileId)[operation] || (config.integrationMode === 'runtime-profile-discovery' && ['readProperties','read'].includes(operation))))])),
      readOnlyBeta: this.readOnlyBeta, cliPrefixArgsBlocked: Boolean(resolved?.cliPrefixArgsBlocked),
      cliIntegrityPinned: integrity.pinned, cliIntegrityBlocked: Boolean(this.readOnlyBeta && integrity.blocked),
      templates: config.templates || {}, session: this.session ? { ...this.session, child: undefined, readWatchdogTimer: undefined } : null,
      device: config.device || '', probedAt: config.probedAt || null, history: this.getHistory().slice(0, 30),
      lastSuccessfulDevice: config.lastSuccessfulDevice || '', lastSuccessfulAt: config.lastSuccessfulAt || null,
      lastSuccessfulOperation: config.lastSuccessfulOperation || '', lastSuccessfulProfileId: config.lastSuccessfulProfileId || '',
      lastDeviceCandidates: Array.isArray(config.lastDeviceCandidates) ? config.lastDeviceCandidates : [], lastDeviceDiscoveryAt: config.lastDeviceDiscoveryAt || null,
      integrationMode: config.integrationMode || 'unprobed', integratedProfileId: config.integratedProfileId || '',
      kernel: (() => { const value = this.resolveKernelDirectory(resolved?.executable || ''); return value ? { folder: value.folder, files: value.files.map(file => path.basename(file)), fileCount: value.fileCount, source: value.source } : null; })(),
      portOwner: { ...this.portOwner }, hardwareTransaction: this.hardwareTransaction.snapshot(), integrated: Boolean(resolved && !cliBlocked && config.integrationMode !== 'unsupported'),
      assistedAvailable: !this.readOnlyBeta && Boolean(this.resolveGuiExecutable()), assisted
    };
  }

  saveDevice(device) { return this.saveConfig({ device: clean(device, 200) }); }
  saveTemplates(templates) {
    const normalized = {};
    for (const operation of Object.keys(OPERATIONS)) {
      const template = templates?.[operation] ?? (operation === 'readProperties' ? templates?.identify : null);
      if (template == null || String(Array.isArray(template) ? template.join(' ') : template).trim() === '') { normalized[operation] = null; continue; }
      const text = String(Array.isArray(template) ? template.join(' ') : template);
      if (OPERATIONS[operation].io === 'input' && !text.includes('{input}')) throw new Error(`${operation} command template must include {input}.`);
      if (OPERATIONS[operation].io === 'output' && !text.includes('{output}')) throw new Error(`${operation} command template must include {output}.`);
      normalized[operation] = tokenizeTemplate(template);
    }
    return this.saveConfig({ templates: normalized });
  }

  // Never hand an existing BIN (including a protected original or partial read) to
  // PCM Hammer as an output destination. A successful read must create a new file.
  // lstat also rejects dangling symlinks, which existsSync would miss.
  assertFreshReadOutput(output, { allowMissingParents = false } = {}) {
    const result = checkUnusedReadDestination(output, { allowMissingParents });
    if (!result.ok) throw new FlashStopError(result.code, result.message);
    // Always use the exact absolute path that passed the filesystem checks.
    // Passing a caller-supplied relative path to a child process can target a
    // different directory if its working directory differs from TunIQ's.
    return result.resolved;
  }

  preflight(operation, payload = {}) {
    const normalizedOperation = normalizeOperation(operation);
    if (!OPERATIONS[normalizedOperation]) throw new FlashStopError('unsupported-operation', `Unsupported PCM Hammer operation: ${operation}.`);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const config = this.getConfig();
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer CLI is unavailable. Guided Automatic P01 Setup can switch to the normal PCM Hammer app and import its evidence.');
    this.assertReadOnlyCliPrefixArgs(resolved);
    this.assertPinnedCliIntegrity(resolved, config);
    // Saved help-derived or user-edited command templates are not a safety
    // boundary: a template stored under "readProperties" can invoke a write.
    // In the restricted beta, only audited built-in read-only profiles may
    // reach the CLI. Preserve saved templates for future review, but never
    // execute them while readOnlyBeta is enabled.
    const template = this.readOnlyBeta ? null : (config.templates?.[normalizedOperation] || null);
    const recognized = isRecognizedPcmHammerExecutable(resolved.executable, config.backend);
    if (!recognized) throw new FlashStopError('unsupported-cli', 'The configured executable is not recognized as PCM Hammer CLI.');
    const candidateProfiles = profilesForOperation(normalizedOperation, config.integratedProfileId, template);
    if (!candidateProfiles.length) throw new FlashStopError('integrated-profile-unresolved', `TunIQ could not resolve a PCM Hammer command profile for ${OPERATIONS[normalizedOperation].label}. Run integrated Read Properties or a full read first so TunIQ can safely discover and cache the installed CLI syntax.`);
    if (!template && !config.integratedProfileId && !['readProperties','read'].includes(normalizedOperation)) throw new FlashStopError('integrated-profile-unresolved', `The PCM Hammer CLI syntax has not been proven yet. Run integrated Read Properties or a full read before ${OPERATIONS[normalizedOperation].label}.`);
    if (this.session) throw new FlashStopError('operation-running', 'Another PCM Hammer operation is already running.');
    const deviceStatus = this.getDeviceStatus() || {};
    const voltage = Number(payload.voltage ?? deviceStatus.connection?.voltage);
    const selectedDevice = payload.device || config.device || deviceStatus.connection?.port || '';
    const kernel = this.resolveKernelDirectory(resolved.executable);
    const kernelRequired = ['read', 'testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (kernelRequired && !kernel) {
      throw new FlashStopError('kernel-files-missing', `PCM Hammer ${OPERATIONS[normalizedOperation].label} requires Kernel-*.bin / Loader-*.bin files. TunIQ searched the configured PCM Hammer portable folder but could not find them. Re-extract the complete PCM Hammer package instead of copying only the CLI executable.`);
    }
    const values = {
      device: selectedDevice, port: selectedDevice, project: active.folder, controller: active.controller || '',
      input: payload.input || '', output: payload.output || '', kernelDir: kernel?.folder || ''
    };
    const directPortHandoffAuthorized = Boolean(payload.directPortHandoffAuthorized && selectedDevice && /^COM\d+$/i.test(String(selectedDevice)));
    const authoritativeProvenPort = Boolean(payload.authoritativeProvenPort && directPortHandoffAuthorized && ['read','testWrite'].includes(normalizedOperation));
    if (payload.authoritativeProvenPort && ['read', 'testWrite'].includes(normalizedOperation)) {
      const binding = validateProvenPortBinding({ proof: payload.provenHardwareSession, port: selectedDevice, project: active });
      if (!directPortHandoffAuthorized || !binding.valid) {
        throw new FlashStopError('proven-port-evidence-mismatch',
          `The claimed PCM Hammer proven port does not match this project, ECU OS, and selected COM port (${binding.reason}). Re-identify this ECU using Read Properties before requesting exclusive proven-port reuse.`);
      }
    }

    const adapterProfile = typeof this.connectionManager?.load === 'function' ? this.connectionManager.load() : {};
    const deviceLease = buildPcmHammerDeviceSpec({
      port: selectedDevice,
      authoritative: authoritativeProvenPort,
      adapterProfile,
      proof: payload.provenHardwareSession || {},
      helpText: config.helpText || '',
      forceElmHint: payload.forceElmDeviceHint !== false
    });
    if (directPortHandoffAuthorized && !allowsDirectPcmHammerHandoff(normalizedOperation)) {
      throw new FlashStopError('direct-handoff-write-prohibited', 'Manual direct COM handoff is limited to Read Properties, full reads, and Test Write. A real PCM write still requires the verified connection broker.');
    }
    const writeOperation = ['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (writeOperation) {
      if (!values.input || !fs.existsSync(values.input)) throw new FlashStopError('input-missing', 'Select an existing revision BIN before Test Write or writing.');
      if (!active.bin || !fs.existsSync(active.bin)) throw new FlashStopError('original-missing', 'A protected verified original BIN is required before any write-related operation.');
      const sourceSize = fs.statSync(values.input).size;
      const originalSize = fs.statSync(active.bin).size;
      if (sourceSize !== originalSize) throw new FlashStopError('input-size-mismatch', `Revision size (${sourceSize}) does not match the protected original (${originalSize}).`);
      if (!Number.isFinite(voltage) && !payload.benchPowerConfirmed) throw new FlashStopError('power-proof-missing', 'Live voltage is unavailable. Enter voltage or confirm a regulated bench supply.');
      if (Number.isFinite(voltage) && voltage < 12.2) throw new FlashStopError('voltage-low', `Voltage is too low for a controlled ${OPERATIONS[normalizedOperation].label} (${voltage.toFixed(2)} V).`);
      if (normalizedOperation !== 'testWrite') {
        const expected = ['writeFull', 'recovery'].includes(normalizedOperation) ? `FULL WRITE ${active.name}` : `WRITE ${active.name}`;
        if (String(payload.confirmation || '').trim() !== expected) throw new FlashStopError('confirmation-missing', `Type exactly “${expected}” to authorize this operation.`);
        if (!payload.checksumApproved) throw new FlashStopError('checksum-not-approved', 'Checksum and compatibility validation must pass before writing.');
      }
    }
    if (normalizedOperation === 'read') {
      const output = values.output || path.join(active.folder, 'Originals', `${safeName(active.name)}-P01-Full-Read-${new Date().toISOString().replace(/[:.]/g, '-')}.bin`);
      // Inspect the full parent chain BEFORE creating directories, then check
      // again after mkdir in case the path changed during preparation.
      const checkedOutput = this.assertFreshReadOutput(output, { allowMissingParents: true });
      ensureDir(path.dirname(checkedOutput));
      this.assertFreshReadOutput(checkedOutput);
      values.output = checkedOutput;
    }
    return {
      operation: normalizedOperation, active, config, resolved, template, candidateProfiles, values, kernel,
      voltage: Number.isFinite(voltage) ? voltage : null,
      directPortHandoffAuthorized,
      authoritativeProvenPort,
      directPortHandoffReason: clean(payload.directPortHandoffReason || '', 240),
      deviceLease,
      adapterProfile,
      workflowAttemptId: clean(payload.workflowAttemptId || '', 160),
      hardwareTransactionId: clean(payload.hardwareTransactionId || '', 160),
      controllerOs: clean(payload.controllerOs || active.os || '', 40)
    };
  }

  setPortOwner(owner, details = {}) {
    this.portOwner = {
      owner,
      port: clean(details.port || this.portOwner.port, 40),
      operation: clean(details.operation || '', 80),
      leaseId: clean(details.leaseId || '', 120),
      since: owner === 'idle' ? null : new Date().toISOString()
    };
    this.emit('flash:port-owner', { ...this.portOwner });
    return this.portOwner;
  }

  async preparePort(preflight) {
    const selectedPort = preflight.values.device;
    const leaseId = `${Date.now()}-${preflight.operation}-${selectedPort || 'auto'}`;
    const directPortHandoff = Boolean(
      preflight.directPortHandoffAuthorized &&
      selectedPort &&
      allowsDirectPcmHammerHandoff(preflight.operation)
    );
    const validateConnection = this.connectionManagerRequired && !directPortHandoff && ['readProperties','read','testWrite','writeCalibration','writeFull','recovery'].includes(preflight.operation);
    let intelligent = null;
    if (validateConnection) {
      try {
        intelligent = await this.connectionManager.preflight({ selectedPort, lastSuccessfulPort: preflight.config?.lastSuccessfulDevice || '' });
      } catch (error) {
        intelligent = { ready: false, verified: false, state: 'connection-broker-failed', warning: clean(error.message || error, 1200), attempts: [], repair: { title: 'TunIQ could not complete adapter verification.' } };
      }
    }
    if (validateConnection && !intelligent?.ready) {
      throw new FlashStopError(intelligent?.state || 'ports-unavailable', intelligent?.repair?.title || 'TunIQ could not positively open and identify an OBDLink/STN adapter.', { intelligentConnection: intelligent });
    }
    // When the broker is enabled, PCM Hammer receives exactly the one port that TunIQ
    // positively opened and identified. Blind COM fallbacks and duplicate same-port attempts
    // are intentionally excluded from this hardware session.
    const chosenPort = intelligent?.ready ? intelligent.port : selectedPort;
    let candidates = [];
    if (directPortHandoff) {
      candidates = [{
        port: chosenPort,
        deviceSpec: preflight.deviceLease?.spec || chosenPort,
        source: preflight.authoritativeProvenPort ? 'proven-pcmhammer-exclusive-lane' : 'user-authorized-pcmhammer-direct-handoff',
        verified: false,
        recognized: false,
        adapter: '',
        baud: null,
        reason: preflight.directPortHandoffReason || 'TunIQ serial verification was unavailable; PCM Hammer will prove communication directly.'
      }];
    } else if (intelligent?.ready) {
      candidates = [{
        port: chosenPort,
        source: 'verified-adapter-connection-broker',
        verified: true,
        recognized: true,
        adapter: intelligent.attempt?.adapter || intelligent.profile?.adapterName || '',
        baud: intelligent.attempt?.baud || intelligent.profile?.baud || null
      }];
    } else {
      candidates = await this.resolveDeviceCandidates(selectedPort, preflight.operation);
    }
    if (!chosenPort && !validateConnection) {
      this.setPortOwner('pcmhammer', { port: '', operation: preflight.operation, leaseId });
      return { port: '', released: false, mode: 'direct-handoff', lockProbeSkipped: true, verifiedByBroker: false, leaseId, attempts: [], candidates, intelligentConnection: intelligent };
    }
    if (!chosenPort) throw new FlashStopError('adapter-not-detected', 'TunIQ could not identify an available OBDLink serial port.', { intelligentConnection: intelligent });
    preflight.values.device = chosenPort;
    preflight.values.port = chosenPort;
    const handoffSource = directPortHandoff
      ? 'user-authorized-pcmhammer-direct-handoff'
      : intelligent?.ready ? 'verified-adapter-connection-broker' : 'selected';
    const handoff = preflight.authoritativeProvenPort
      ? await this.prepareExclusivePcmHammerLane(chosenPort, preflight.operation, leaseId, 'proven-pcmhammer-exclusive-lane')
      : await this.handoffPort(chosenPort, preflight.operation, leaseId, handoffSource);
    return {
      port: chosenPort,
      released: Boolean(handoff.release?.released),
      release: handoff.release,
      bridge: handoff.bridge,
      mode: preflight.authoritativeProvenPort ? 'proven-pcmhammer-exclusive-lane' : directPortHandoff ? 'manual-pcmhammer-direct-handoff' : intelligent?.ready ? 'verified-broker-handoff' : 'direct-handoff',
      lockProbeSkipped: directPortHandoff || !validateConnection,
      verifiedByBroker: Boolean(intelligent?.ready && intelligent?.verified !== false),
      directPortHandoff,
      pinnedProvenPort: Boolean(preflight.authoritativeProvenPort),
      exclusivePcmHammerOwnership: Boolean(handoff.exclusivePcmHammerOwnership),
      deviceSpec: preflight.deviceLease?.spec || chosenPort,
      deviceSpecMode: preflight.deviceLease?.mode || 'plain',
      directPortHandoffReason: preflight.directPortHandoffReason || '',
      leaseId,
      attempts: [...(intelligent?.attempts || []), handoff],
      candidates,
      intelligentConnection: intelligent
    };
  }

  clearTransientRecoveryState(reason = 'workflow recovery') {
    const bridge = this.abortBridgeRequests(reason) || { aborted: 0 };
    // Requesting recovery is not proof that PCM Hammer has exited. Previously
    // this cleared the session/COM owner immediately after child.kill(), even
    // though process termination (especially on Windows) is asynchronous.
    // Keep the lease until the existing child close/error finalizer releases it.
    if (this.session) {
      const session = this.session;
      if (!['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) &&
          !session.recoveryCancellationRequested) {
        session.recoveryCancellationRequested = true;
        session.cancelRequested = true; // Prevent read-only CLI profile/port retries.
        session.phase = 'Recovery requested; waiting for PCM Hammer to exit';
        if (session.child) {
          // Reuse the normal platform-specific cancellation path, including
          // taskkill /T on Windows. A failed kill must NOT free the COM lease.
          void this.cancel().catch(error => { session.cancelWarning = clean(error.message || error, 400); });
        }
      }
      return { bridge, activeSession: true, terminationPending: true };
    }
    // A start may still be awaiting Windows process inventory/COM handoff.
    // Its synchronous admission latch must also prevent premature idle status.
    if (this.startPending) return { bridge, activeSession: true, startPending: true };
    this.setPortOwner('idle', { port: this.portOwner.port });
    return { bridge, activeSession: false };
  }

  // Reserve exclusive COM access for manual OBDLink verification and Bluetooth
  // SPP repair. A cancellation request is NOT proof that the PCM Hammer child
  // has exited; fail closed and require a retry after its close finalizer.
  // This synchronous admission latch remains held across awaited serial work.
  async withExclusiveExternalPortAccess(reason, work, { requestRecovery = true } = {}) {
    if (typeof work !== 'function') throw new TypeError('External COM workflow requires a callback.');
    if (this.externalPortAccessPending) throw new FlashStopError('external-com-workflow-active',
      'An OBDLink repair or manual port check is already using the adapter. Wait for it to finish.');
    // Read-only CLI discovery is observational: it must never cancel an active
    // Full Read just to obtain help/version text. Manual repair retains its
    // explicit recovery-request behavior.
    const recovery = requestRecovery ? this.clearTransientRecoveryState(reason)
      : { activeSession: Boolean(this.session || this.startPending) };
    if (recovery.activeSession || this.session || this.startPending || this.portOwner.owner !== 'idle') {
      throw new FlashStopError('pcmhammer-exit-pending',
        'PCM Hammer is still starting or shutting down. Wait for its process to exit before repairing Bluetooth or opening the COM port.');
    }
    this.externalPortAccessPending = true;
    try { return await work(); }
    finally { this.externalPortAccessPending = false; }
  }

  async start(operation, payload = {}) {
    // Preflight checks this.session, but it is not populated until AFTER awaits
    // for Windows process inspection, COM handoff and Bluetooth settle. Without
    // this synchronous latch, two start requests can both pass preflight and
    // acquire competing COM leases before either publishes its session.
    if (this.externalPortAccessPending) throw new FlashStopError('external-com-workflow-active',
      'A Bluetooth repair or manual COM-port check is using the adapter. Wait for it to finish.');
    if (this.startPending) throw new FlashStopError('operation-starting',
      'A PCM Hammer operation is already preparing the adapter. Wait for its preflight to finish.');
    this.startPending = true;
    try {
    // Gate before preflight, snapshots, COM release, subprocess creation or any
    // persistent session mutation. Also protects internal P01 automation callers.
    this.assertReadOnlyBetaOperation(operation);
    const preflight = this.preflight(operation, payload);
    let exclusiveGuard = null;
    try {
      exclusiveGuard = await this.inspectExclusiveSession({
        selectedPort: preflight.values.device || '', expectedExecutable: preflight.resolved.executable,
        operation: preflight.operation, project: preflight.active
      });
    } catch (error) {
      // An unavailable Windows process inventory is NOT proof that the adapter
      // is free. Fail closed before releasing any COM handle or spawning CLI.
      throw new FlashStopError('adapter-conflict-check-failed',
        `TunIQ could not verify exclusive adapter ownership: ${clean(error.message || error, 400)}. Retry after Windows process inspection is available.`);
    }
    if (!exclusiveGuard || typeof exclusiveGuard !== 'object' || typeof exclusiveGuard.blocked !== 'boolean') {
      throw new FlashStopError('adapter-conflict-check-failed',
        'Exclusive adapter ownership inspection returned no valid decision. PCM Hammer was not started.');
    }
    if (exclusiveGuard?.blocked) {
      const conflictText = (exclusiveGuard.conflicts || []).map(item => `${item.name || 'process'} (PID ${item.pid || '?'})`).join(', ');
      throw new FlashStopError('adapter-conflict-process', `Another OBD/serial application may own the adapter: ${conflictText || 'conflicting process detected'}. Close it and retry the same step.`, { exclusiveGuard });
    }
    // Recheck after asynchronous conflict inspection, before any COM handoff.
    if (preflight.operation === 'read') this.assertFreshReadOutput(preflight.values.output);
    let safetySnapshot = null;
    if (['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(preflight.operation)) {
      try {
        safetySnapshot = await this.createSafetySnapshot(`before-${preflight.operation}`, { project: preflight.active, operation: preflight.operation });
      } catch (error) {
        throw new FlashStopError('safety-snapshot-failed', `TunIQ could not create and verify the required project safety snapshot: ${error.message}`, { snapshotError: clean(error.message || error, 2000) });
      }
      if (!safetySnapshot?.verified) throw new FlashStopError('safety-snapshot-failed', 'TunIQ did not receive a verified project safety snapshot, so the hardware operation was blocked.', { safetySnapshot });
    }
    const transaction = this.hardwareTransaction.begin({
      projectId: preflight.active.id, controller: preflight.active.controller || 'P01', os: preflight.controllerOs || preflight.active.os || '',
      port: preflight.values.device || '', operation: preflight.operation, workflowAttemptId: preflight.workflowAttemptId || ''
    });
    const portLease = await this.preparePort(preflight);
    const cooldownMs = await this.hardwareTransaction.settleBeforeOpen(preflight.values.device || portLease.port || '', waitMs => {
      this.appendActivity('p01-hardware-transaction-cooldown', {
        projectId: preflight.active.id, operation: preflight.operation, port: preflight.values.device || portLease.port || '', waitMs, transactionId: transaction.transactionId
      });
    });
    // Port handoff and Windows Bluetooth settling are asynchronous. Recheck the
    // destination after those awaits so a file created meanwhile cannot be lost.
    if (preflight.operation === 'read') {
      try { this.assertFreshReadOutput(preflight.values.output); }
      catch (error) {
        this.setPortOwner('idle', { port: preflight.values.device || '' });
        this.hardwareTransaction.save({ state: 'stopped', currentOperation: '' }, {
          type: 'read-output-guard-stopped', operation: 'read', port: preflight.values.device || '', reason: error.code || 'read-output-unavailable'
        });
        throw error;
      }
    }
    // Recheck after asynchronous COM handoff/settling, before constructing a
    // session or spawning PCM Hammer. A changed binary must never run here.
    try { this.assertPinnedCliIntegrity(preflight.resolved, preflight.config); }
    catch (error) {
      this.setPortOwner('idle', { port: preflight.values.device || '' });
      this.hardwareTransaction.save({ state: 'stopped', currentOperation: '' }, {
        type: 'cli-integrity-stopped', operation: preflight.operation,
        port: preflight.values.device || '', reason: error.code || 'cli-integrity-error'
      });
      throw error;
    }
    const profiles = preflight.candidateProfiles || [];
    const session = {
      id: `${Date.now()}-${preflight.operation}`, operation: preflight.operation,
      projectId: preflight.active.id, projectName: preflight.active.name,
      executable: preflight.resolved.executable, backendSha256: preflight.config?.backend?.sha256 || '', backendVersion: preflight.config?.backend?.version || '',
      args: [], input: preflight.values.input || null, output: preflight.values.output || null,
      device: preflight.values.device || null, initialDevice: preflight.values.device || null, voltage: preflight.voltage, portLease,
      kernelDir: preflight.kernel?.folder || null, kernelFiles: preflight.kernel?.files?.map(file => path.basename(file)) || [],
      deviceCandidates: Array.isArray(portLease.candidates) ? portLease.candidates : [], deviceIndex: 0, deviceAttempts: [], deviceDiscoveryPasses: [], portRetryCounts: {},
      integrated: true, integrationMode: preflight.config.integrationMode || 'runtime-profile-discovery',
      profileAttempts: [], startedAt: new Date().toISOString(), state: 'running', progress: 0,
      phase: `Starting integrated PCM Hammer ${OPERATIONS[preflight.operation].label}`, log: [], technicalDetails: null,
      lastOutputAt: null, readHeartbeat: null, readWatchdogTriggered: false,
      exclusiveGuard, safetySnapshot, workflowAttemptId: preflight.workflowAttemptId || '',
      hardwareTransactionId: transaction.transactionId || preflight.hardwareTransactionId || '',
      hardwareTransaction: this.hardwareTransaction.snapshot(), interOperationCooldownMs: cooldownMs,
      deviceSpec: portLease.deviceSpec || preflight.deviceLease?.spec || preflight.values.device || null,
      deviceSpecMode: portLease.deviceSpecMode || preflight.deviceLease?.mode || 'plain',
      pcmHammerExclusiveOwnership: Boolean(portLease.exclusivePcmHammerOwnership),
      typeHintFallbackTried: false
    };
    const sessionLog = path.join(this.sessionsRoot(), `${session.id}.log`);
    session.sessionLog = sessionLog;
    this.session = session;
    const emit = () => this.emit('flash:progress', { ...session, child: undefined, readWatchdogTimer: undefined });
    const stopReadWatchdog = () => {
      if (session.readWatchdogTimer) clearInterval(session.readWatchdogTimer);
      session.readWatchdogTimer = null;
    };
    const terminateReadProcess = child => {
      try {
        if (process.platform === 'win32' && child?.pid) spawn('taskkill.exe', ['/PID', String(child.pid), '/T', '/F'], { windowsHide: true });
        else child?.kill?.('SIGTERM');
      } catch {}
    };
    const append = (stream, chunk) => {
      const text = chunk.toString(); fs.appendFileSync(sessionLog, text, 'utf8');
      session.lastOutputAt = new Date().toISOString();
      session.lastOutputAtMs = Date.now();
      for (const line of text.split(/\r?\n/).filter(Boolean)) {
        const entry = { at: new Date().toISOString(), stream, text: clean(line, 3000) };
        session.log.push(entry); if (session.log.length > 1200) session.log.shift();
        session.progress = parseProgress(entry.text, session.progress);
        if (['stdout','stderr'].includes(stream)) {
          if (/read\s+propert|OSID|Hardware ID|Service No/i.test(entry.text)) session.phase = 'Reading controller properties inside TunIQ';
          else if (/read|block/i.test(entry.text)) session.phase = 'Reading PCM inside TunIQ';
          else if (/erase/i.test(entry.text)) session.phase = 'Erasing flash';
          else if (/write|program/i.test(entry.text)) session.phase = 'Writing flash';
          else if (/verif/i.test(entry.text)) session.phase = 'Verifying';
        }
        const voltage = entry.text.match(/(?:battery\s+)?voltage(?:\s+is)?\s*:\s*(\d+(?:\.\d+)?)/i)?.[1];
        if (voltage) session.voltage = Number(voltage);
      }
      emit();
    };
    const startReadWatchdog = (child, deviceAttempt) => {
      stopReadWatchdog();
      if (session.operation !== 'read') return;
      const startedMs = Date.now();
      session.readProcessStartedAt = new Date(startedMs).toISOString();
      session.lastOutputAtMs = startedMs;
      session.lastReadActivityAtMs = startedMs;
      session.lastReadFileSignature = '';
      const tick = () => {
        if (session.finalized || session.child !== child || child.exitCode != null || child.killed) return stopReadWatchdog();
        const nowMs = Date.now();
        let outputBytes = 0; let outputMtimeMs = 0;
        try { const stat = session.output ? fs.statSync(session.output) : null; outputBytes = Number(stat?.size || 0); outputMtimeMs = Number(stat?.mtimeMs || 0); } catch {}
        const signature = `${outputBytes}:${outputMtimeMs}`;
        if (signature !== session.lastReadFileSignature) {
          session.lastReadFileSignature = signature;
          if (outputBytes > 0 || outputMtimeMs > 0) session.lastReadActivityAtMs = nowMs;
        }
        const lastOutputMs = Number(session.lastOutputAtMs || startedMs);
        const lastActivityMs = Math.max(lastOutputMs, Number(session.lastReadActivityAtMs || startedMs));
        const quietMs = Math.max(0, nowMs - lastActivityMs);
        const elapsedMs = Math.max(0, nowMs - startedMs);
        const outputRatio = Math.max(0, Math.min(1, outputBytes / P01_BIN_SIZE));
        if (outputBytes > 0) session.progress = Math.max(Number(session.progress || 0), Math.min(95, outputRatio * 95));
        const expectedReached = outputBytes === P01_BIN_SIZE;
        const quietSeconds = Math.floor(quietMs / 1000);
        session.readHeartbeat = {
          state: quietMs >= this.readStallTimeoutMs ? 'stalled' : quietMs >= Math.max(15000, this.readWatchdogPollMs * 3) ? 'quiet' : 'active',
          processAlive: true,
          elapsedSeconds: Math.floor(elapsedMs / 1000),
          quietSeconds,
          outputBytes,
          expectedBytes: P01_BIN_SIZE,
          expectedSizeReached: expectedReached,
          lastOutputAt: session.lastOutputAt || null,
          updatedAt: new Date(nowMs).toISOString(),
          automaticStopAfterSeconds: Math.ceil(this.readStallTimeoutMs / 1000)
        };
        deviceAttempt.readHeartbeat = { ...session.readHeartbeat };
        if (expectedReached) session.phase = 'Full read reached 512 KB — waiting for PCM Hammer completion proof';
        else if (outputBytes > 0) session.phase = `Reading PCM inside TunIQ — ${Math.min(outputBytes, P01_BIN_SIZE).toLocaleString()} of ${P01_BIN_SIZE.toLocaleString()} bytes received`;
        else session.phase = `PCM Hammer full read is still running — ${Math.floor(elapsedMs / 1000)}s elapsed${quietSeconds ? `, ${quietSeconds}s since the last update` : ''}`;
        if (!session.readWatchdogTriggered && quietMs >= this.readStallTimeoutMs) {
          session.readWatchdogTriggered = true;
          session.readWatchdogStopCode = 'read-stalled-no-progress';
          session.readWatchdogStopMessage = `PCM Hammer remained alive but produced no output and no read-file activity for ${Math.ceil(this.readStallTimeoutMs / 1000)} seconds. TunIQ stopped only this non-destructive full read; completed Read Properties evidence was preserved.`;
          append('watchdog', `${session.readWatchdogStopMessage}
`);
          terminateReadProcess(child);
          return;
        }
        emit();
      };
      session.readWatchdogTimer = setInterval(tick, this.readWatchdogPollMs);
      if (typeof session.readWatchdogTimer.unref === 'function') session.readWatchdogTimer.unref();
      tick();
    };

    const finalize = async (code, attemptText, profile) => {
      stopReadWatchdog();
      if (session.finalized) return;
      session.exitCode = code; session.finishedAt = new Date().toISOString();
      session.result = classifyPcmHammerResult(session.operation, attemptText, code);
      if (session.cliIntegrityStopped) {
        session.result = { ...session.result, success: false, stopCode: 'cli-executable-integrity-changed' };
      }
      if (session.readDestinationStopped) {
        session.result = { ...session.result, success: false,
          stopCode: session.readDestinationStopCode || 'read-output-unavailable' };
      }
      if (session.readWatchdogTriggered) {
        session.result = { ...session.result, success: false, stopCode: session.readWatchdogStopCode || 'read-stalled-no-progress' };
      }
      // A child-process `error` is not evidence that Windows has closed the
      // process or released its COM handle. The `close` event owns finalization.
      if (session.childProcessError) {
        session.result = { ...session.result, success: false, stopCode: 'cli-process-error' };
      }
      // A cancelled read-only operation cannot be treated as successful
      // evidence even if its CLI races to a zero exit and prints completion.
      if (session.cancelRequested && ['read', 'readProperties'].includes(session.operation)) {
        session.result = { ...session.result, success: false,
          stopCode: session.operation === 'read' ? 'read-cancelled' : 'properties-cancelled' };
      }
      session.identity = parseIdentityText(attemptText);
      if (Number.isFinite(session.identity.voltage)) session.voltage = session.identity.voltage;
      session.stopCode = session.result.stopCode;
      if (session.controlledProvenPortRecovery && ['adapter-open-timeout','adapter-open-failed','adapter-locked'].includes(session.stopCode)) {
        session.stopCode = 'proven-port-reopen-failed';
        session.result = { ...session.result, success: false, stopCode: session.stopCode };
      }
      session.state = session.cancelRequested ? 'cancelled' : session.result.success ? 'complete' : 'failed';
      if (session.readWatchdogTriggered) {
        session.state = 'failed';
        session.stopCode = session.readWatchdogStopCode || 'read-stalled-no-progress';
        session.error = session.readWatchdogStopMessage || 'PCM Hammer full read stopped after the no-progress watchdog expired.';
      }
      if (session.childProcessError) {
        session.state = 'failed';
        session.stopCode = 'cli-process-error';
        session.error = `PCM Hammer child process reported an error: ${session.childProcessError}. The COM lease was retained until the child close event.`;
      }
      if (portLease.verifiedByBroker && ['adapter-open-timeout','adapter-open-failed','adapter-locked'].includes(session.stopCode)) {
        session.stopCode = 'adapter-handoff-failed';
        session.error = `TunIQ positively opened and identified ${session.device || 'the adapter port'}, released the handle, and then PCM Hammer could not claim it. Windows Bluetooth changed state during the handoff; TunIQ did not retry another COM port or repeat the same port.`;
      }
      // Progress reaches 100% only after all operation-specific proof checks pass.
      session.testWritePassed = Boolean(session.result.testWritePassed);
      session.verified = Boolean(session.result.verificationPassed || session.result.testWritePassed);
      const allProfilesRejectedBeforeCommunication = session.profileAttempts.length >= profiles.length
        && session.profileAttempts.length > 0
        && session.profileAttempts.every(item => item.syntaxFailure && !item.communicationStarted);
      if (allProfilesRejectedBeforeCommunication) {
        session.state = 'failed';
        session.stopCode = 'integrated-cli-profile-unresolved';
        session.error = `TunIQ tried every safe PCM Hammer 2.x command profile for ${OPERATIONS[session.operation].label}, but this CLI build did not accept any of them. No PCM communication began and no output was accepted.`;
      }
      if (session.operation === 'read' && !allProfilesRejectedBeforeCommunication && !session.readDestinationStopped) {
        // A user-requested cancellation is never a verified backup, even if
        // PCM Hammer races the termination request and reports exit 0 with a
        // complete-sized BIN. Preserve the file as rejected evidence instead
        // of calling the backup-import callback.
        const validation = session.cancelRequested
          ? { valid: false, code: 'read-cancelled', message: 'Full Read cancellation was requested; output is unverified and cannot be imported.' }
          : validateP01ReadFile(session.output, session.result);
        session.outputValidation = validation;
        if (!validation.valid) {
          const communicationStops = new Set(['adapter-open-timeout', 'adapter-open-failed', 'proven-port-reopen-failed', 'kernel-files-missing', 'adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'read-stalled-no-progress', 'pcmhammer-failed']);
          const classifiedStop = session.result?.stopCode;
          session.state = session.cancelRequested ? 'cancelled' : 'failed';
          session.stopCode = session.cancelRequested ? 'read-cancelled' : communicationStops.has(classifiedStop) ? classifiedStop : validation.code;
          session.error = classifiedStop === 'read-stalled-no-progress'
            ? `${session.readWatchdogStopMessage || 'PCM Hammer full read stopped after the no-progress watchdog expired.'} ${validation.message}`
            : classifiedStop === 'proven-port-reopen-failed'
              ? `PCM Hammer previously proved ${session.device || 'the selected port'} for this exact P01 project, but Windows did not reopen that same Bluetooth COM endpoint after TunIQ closed every owned handle and completed one controlled settle/retry. Completed Read Properties evidence was preserved, ${validation.message.toLowerCase()}, and no alternate COM port was attempted.`
              : communicationStops.has(classifiedStop)
                ? `PCM Hammer stopped before a complete read (${classifiedStop}). ${validation.message}`
                : validation.message;
          const quarantine = quarantineRejectedReadOutput(session.output);
          if (quarantine.path) session.rejectedOutput = quarantine.path;
          if (quarantine.warning) session.quarantineWarning = quarantine.warning;
        } else {
          session.outputInfo = validation;
          try { await this.onReadComplete(session.output, session.outputInfo, session); }
          catch (error) {
            // A valid CLI BIN is not an admitted backup if project import fails.
            // Fail closed and quarantine the original path so a later workflow
            // cannot mistake an unadmitted file for an imported original.
            // This cannot undo side effects from a partially executed callback.
            session.state = 'failed';
            session.stopCode = 'read-import-failed';
            session.importWarning = clean(error?.message || error, 500);
            session.outputInfo = { ...validation, valid: false, code: 'read-import-failed',
              message: 'Full Read file passed CLI checks, but project backup import failed; it is not accepted evidence.' };
            const quarantine = quarantineRejectedReadOutput(session.output);
            if (quarantine.path) session.rejectedOutput = quarantine.path;
            if (quarantine.warning) session.quarantineWarning = quarantine.warning;
          }
        }
      }
      const identityUseful = session.operation === 'readProperties'
        ? Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.controller)
        : Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.vin);
      // An OSID or hardware identifier printed in a failed CLI log is not
      // accepted identity evidence. A Full Read must also have passed backup
      // validation AND project import before identity can be promoted.
      if (identityUseful && !session.cancelRequested && session.state === 'complete') {
        try { await this.onIdentifyComplete(session.identity, session); }
        catch (error) { session.identityWarning = error.message; if (session.operation === 'readProperties') { session.state = 'failed'; session.stopCode = 'identity-import-failed'; } }
      }
      if (session.operation === 'readProperties' && !identityUseful && !allProfilesRejectedBeforeCommunication && !session.cancelRequested) {
        session.state = 'failed';
        const specificStops = new Set(['adapter-open-timeout', 'adapter-open-failed', 'kernel-files-missing', 'adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'partial-read', 'pcmhammer-failed']);
        if (!specificStops.has(session.result?.stopCode)) {
          session.stopCode = 'properties-incomplete';
          session.error = 'Read Properties finished without OSID, Hardware ID, service number, or controller evidence.';
        } else {
          session.stopCode = session.result.stopCode;
          session.error = `PCM Hammer stopped before Read Properties completed (${session.result.stopCode}).`;
        }
      }
      // Read Properties' generic missing-identity handler and Full Read's
      // validation must not conceal an executable substitution stop.
      if (session.cliIntegrityStopped) {
        session.state = 'failed';
        session.stopCode = 'cli-executable-integrity-changed';
      }
      // Read Properties/Full Read validation must not mask the original
      // process error once its child has finally closed.
      if (session.childProcessError) {
        session.state = 'failed';
        session.stopCode = 'cli-process-error';
        session.error = `PCM Hammer child process reported an error: ${session.childProcessError}. No COM lease was released before process close.`;
      }
      if (session.state === 'failed' && !session.error) {
        if (session.stopCode === 'proven-port-reopen-failed') {
          session.error = `PCM Hammer previously proved ${session.device || 'the selected port'} for this exact P01 project, but Windows did not reopen that same Bluetooth COM endpoint after TunIQ closed every owned handle and completed one controlled settle/retry. Completed Read Properties evidence was preserved and no alternate COM port was attempted.`;
        } else if (['adapter-open-timeout', 'adapter-open-failed'].includes(session.stopCode)) {
          const tried = [...new Set((session.deviceAttempts || []).map(item => item.device).filter(Boolean))];
          const candidates = [...new Set((session.deviceCandidates || []).map(item => item.port).filter(Boolean))];
          session.error = `PCM Hammer could not open an adapter port before PCM communication began. TunIQ released its own serial/PowerShell handles and tested ${tried.length ? tried.join(', ') : session.device || 'the selected port'}${candidates.length > tried.length ? ` from candidates ${candidates.join(', ')}` : ''}, but Windows/Bluetooth did not provide an openable outgoing OBDLink port.`;
        } else if (session.stopCode === 'kernel-files-missing') {
          session.error = 'PCM Hammer could not find its Kernel-*.bin / Loader-*.bin files. TunIQ searched the complete portable installation and did not accept a Test Write without the required kernels.';
        } else if (session.stopCode) {
          session.error = `PCM Hammer ${OPERATIONS[session.operation].label} stopped (${session.stopCode}).`;
        }
      }
      if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && code === 0 && !session.verified) {
        session.state = 'complete-unverified'; session.stopCode = 'verification-not-proven';
        session.verificationWarning = 'PCM Hammer exited, but TunIQ did not parse an explicit verification-pass result. Re-read properties and read back before treating the hardware as verified.';
      }
      // CLI exit text alone is not proof of a valid backup. Do not persist a
      // "verified" command profile or last-success metadata until the Full Read
      // passed file size/hash validation and the import callback succeeded.
      // A zero-exit CLI is only one piece of evidence. A rejected/partial BIN,
      // failed backup import, cancelled read, or failed identity import must not
      // leave a contradictory result.success=true in persisted session history.
      // Apply this after every read-only admission check, before recording the
      // successful profile or notifying downstream completion callbacks.
      if (['read', 'readProperties'].includes(session.operation) && session.state !== 'complete') {
        session.result = { ...session.result, success: false,
          stopCode: session.stopCode || session.result?.stopCode || 'read-evidence-unadmitted' };
      }
      if (session.state === 'complete' && profile?.id) {
        const provenProfile = profile.id === 'configured-template' ? profileMatchingTemplate(session.operation, profile.templates?.[session.operation]) : profile;
        const existingBackend = this.getConfig().backend || {};
        const config = this.saveConfig({
          integratedProfileId: provenProfile?.id || this.getConfig().integratedProfileId || '',
          integrationMode: provenProfile ? 'verified-profile' : 'help-driven-verified-operation',
          templates: provenProfile?.templates || this.getConfig().templates,
          backend: { ...existingBackend, product: 'PCM Hammer', official: true, verifiedByOperation: true, integrationReady: true, verifiedAt: new Date().toISOString() },
          device: session.device || this.getConfig().device || '',
          lastSuccessfulDevice: session.device || this.getConfig().lastSuccessfulDevice || '',
          lastSuccessfulAt: new Date().toISOString(),
          lastSuccessfulOperation: session.operation,
          lastSuccessfulProfileId: provenProfile?.id || profile.id || '',
          kernelDir: session.kernelDir || this.getConfig().kernelDir || '',
          kernelFiles: Array.isArray(session.kernelFiles) ? session.kernelFiles : this.getConfig().kernelFiles || [],
          profileAttempts: session.profileAttempts.slice(-20)
        });
        session.integratedProfileId = provenProfile?.id || profile.id;
        session.backendVersion = config.backend?.version || session.backendVersion;
      }
      session.progress = session.state === 'complete' ? 100 : Math.min(99, Number(session.progress) || 0);
      session.technicalDetails = {
        executable: session.executable,
        args: Array.isArray(session.args) ? [...session.args] : [],
        commandLine: [session.executable, ...(session.args || [])].map(value => /\s/.test(String(value)) ? `"${String(value)}"` : String(value)).join(' '),
        device: session.device || '', deviceSpec: session.deviceSpec || session.device || '', deviceAttempts: session.deviceAttempts || [], exitCode: code, stopCode: session.stopCode || session.result?.stopCode || '',
        kernelDir: session.kernelDir || '', kernelFiles: session.kernelFiles || [],
        deviceCandidates: session.deviceCandidates || [], deviceDiscoveryPasses: session.deviceDiscoveryPasses || [],
        usageOnly: looksLikeCliUsageOnly(attemptText), communicationStarted: hasCommunicationActivity(attemptText),
        stdoutStderrExcerpt: clean(attemptText, 12000), sessionLog,
        exclusiveGuard: session.exclusiveGuard || null, safetySnapshot: session.safetySnapshot || null, workflowAttemptId: session.workflowAttemptId || '',
        pinnedProvenPort: Boolean(portLease.pinnedProvenPort), hardwareTransaction: this.hardwareTransaction.snapshot(),
        readHeartbeat: session.readHeartbeat || null, readWatchdogTriggered: Boolean(session.readWatchdogTriggered)
      };
      const closeLedger = this.hardwareTransaction.snapshot();
      const childStartedThisPreparation = Number.isSafeInteger(closeLedger.preparationSequence) &&
        closeLedger.preparationSequence > 0 &&
        closeLedger.lastProcessStartedPreparationSequence === closeLedger.preparationSequence &&
        closeLedger.lastSessionId === session.id &&
        ['process-running', 'process-closed'].includes(closeLedger.state);
      const finalizerSucceeded = session.state === 'complete' || session.state === 'complete-unverified';
      // The child close handler already recorded a failed exit. Do not send a
      // second failed close from finalization: it could replace the original
      // parser/runtime stop code and manufacture eligibility for COM reopen.
      // Successful finalization may still promote the same closed child.
      if (childStartedThisPreparation &&
          (closeLedger.state === 'process-running' || finalizerSucceeded)) {
        this.hardwareTransaction.markProcessClosed({
          port: session.device || '', operation: session.operation, sessionId: session.id,
          success: finalizerSucceeded, stopCode: session.stopCode || '',
          communicationStarted: hasCommunicationActivity(attemptText)
        });
      } else if (closeLedger.state === 'ready-to-open' &&
          closeLedger.currentOperation === session.operation &&
          closeLedger.port === session.device &&
          closeLedger.lastProcessStartedPreparationSequence === 0) {
        // A pre-spawn path/integrity refusal must not manufacture child-close
        // evidence or authorize a controlled COM reopen.
        this.hardwareTransaction.save({ state: 'stopped', lastStopCode: session.stopCode || '',
          lastCommunicationStarted: null },
        { type: 'pcmhammer-pre-spawn-stopped', operation: session.operation,
          port: session.device || '', stopCode: session.stopCode || '' });
      }
      // Other ledger states belong to a different child or stopped attempt.
      session.hardwareTransaction = this.hardwareTransaction.snapshot();
      this.appendActivity(`flash-${session.operation}-${session.state}`, {
        projectId: session.projectId, projectName: session.projectName,
        input: session.input ? path.basename(session.input) : null,
        output: session.output ? path.basename(session.output) : null,
        exitCode: code, stopCode: session.stopCode, sessionLog,
        integratedProfileId: session.integratedProfileId || profile?.id || '', portLeaseId: portLease.leaseId
      });
      try { await this.onSessionComplete({ ...session, child: undefined, readWatchdogTimer: undefined }); }
      catch (error) { session.sessionCompletionWarning = error.message; }
      session.finalized = true;
      this.recordHistory(session);
      this.setPortOwner('idle', { port: session.device });
      emit();
      this.session = null;
    };

    const launchProfile = async (index, deviceIndex = Number(session.deviceIndex || 0)) => {
      const profile = profiles[index];
      if (!profile?.templates?.[preflight.operation]) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('integrated-profile-unresolved', `No integrated PCM Hammer command profile exists for ${OPERATIONS[preflight.operation].label}.`);
      }
      const candidate = session.deviceCandidates?.[deviceIndex] || { port: preflight.values.device || '', deviceSpec: session.deviceSpec || preflight.values.device || '', source: 'selected' };
      const physicalPort = candidate.port || preflight.values.device || '';
      const pcmHammerDeviceSpec = candidate.deviceSpec || (portLease.pinnedProvenPort ? session.deviceSpec : physicalPort);
      const attemptValues = { ...preflight.values, device: pcmHammerDeviceSpec, port: pcmHammerDeviceSpec };
      const template = profile.templates[preflight.operation];
      const args = [...preflight.resolved.prefixArgs, ...expandTemplate(template, attemptValues)];
      if (session.kernelDir && ['read','testWrite','writeCalibration','writeFull','recovery'].includes(session.operation) && !args.some(value => String(value).toLowerCase() === '--kernel-dir')) args.push('--kernel-dir', session.kernelDir);
      if (portLease.pinnedProvenPort && /--debug/i.test(preflight.config.helpText || '') && !args.some(value => String(value).toLowerCase() === '--debug')) args.push('--debug');
      session.args = args;
      session.device = physicalPort || null;
      session.deviceSpec = pcmHammerDeviceSpec || session.device;
      session.deviceIndex = deviceIndex;
      session.currentProfileId = profile.id;
      session.currentProfileLabel = profile.label;
      session.profileIndex = index;
      session.phase = profiles.length > 1
        ? `Discovering PCM Hammer command profile ${index + 1} of ${profiles.length} on ${session.device || 'automatic device selection'}`
        : `Running integrated PCM Hammer ${OPERATIONS[preflight.operation].label} on ${session.device || 'automatic device selection'}`;
      const attemptStart = session.log.length;
      const attemptNumber = session.deviceAttempts.length + 1;
      const attemptBase = path.join(this.sessionsRoot(), `${session.id}.attempt-${String(attemptNumber).padStart(2, '0')}-${safeName(session.device || 'auto')}`);
      const deviceAttempt = {
        device: session.device || '', deviceSpec: session.deviceSpec || session.device || '', source: candidate.source || 'selected', profileId: profile.id,
        kernelDir: session.kernelDir || '', startedAt: new Date().toISOString(), attempt: attemptNumber,
        stdoutLog: `${attemptBase}.stdout.log`, stderrLog: `${attemptBase}.stderr.log`
      };
      // Retry profiles and same-port recovery happen after asynchronous CLI
      // exits. A binary swapped during an earlier attempt must not be executed
      // again merely because the first preflight and COM handoff passed.
      try { this.assertPinnedCliIntegrity(preflight.resolved, preflight.config); }
      catch (error) {
        session.cliIntegrityStopped = true;
        session.error = error.message;
        append('safety', `Stopped before CLI command attempt ${attemptNumber}: executable SHA-256/path changed. No additional PCM command was launched.\n`);
        await finalize(1, 'PCM Hammer executable integrity changed before command attempt.', profile);
        return;
      }
      // The previous output check preceded asynchronous port handoff and
      // potential profile/COM retries. An unrelated process can create this
      // filename during those gaps. Check again immediately before every
      // spawn, and do not quarantine a file we never created.
      if (session.operation === 'read') {
        try { this.assertFreshReadOutput(session.output); }
        catch (error) {
          session.readDestinationStopped = true;
          session.readDestinationStopCode = error.code || 'read-output-unavailable';
          session.error = error.message;
          append('safety', `Full Read stopped before CLI attempt ${attemptNumber}: destination is no longer unused. Existing data was not modified.\n`);
          await finalize(1, 'Full Read output destination changed before CLI launch.', profile);
          return;
        }
      }
      // This check must precede spawn(): a post-spawn rejection would leave
      // a real PCM Hammer process alive without a recorded exclusive owner.
      try {
        this.hardwareTransaction.assertCanStartProcess({
          port: session.device || '', operation: session.operation, sessionId: session.id,
          transactionId: session.hardwareTransactionId,
          preparationSequence: session.hardwareTransaction.preparationSequence
        });
      } catch (error) {
        session.state = 'failed';
        session.stopCode = 'pcmhammer-spawn-admission-denied';
        session.error = clean(error.message || error, 400);
        append('safety', `PCM Hammer CLI launch denied before spawn: ${session.error}. COM ownership remains reserved pending explicit recovery.\n`);
        session.finalized = true;
        this.recordHistory(session);
        emit();
        if (this.session === session) this.session = null;
        // Do not release COM ownership or mark the foreign child closed.
        return;
      }
      session.deviceAttempts.push(deviceAttempt);
      let child;
      try {
        child = spawn(preflight.resolved.executable, args, {
          windowsHide: true,
          cwd: session.kernelDir || path.dirname(preflight.resolved.executable)
        });
      } catch (error) {
        this.setPortOwner('idle', { port: session.device });
        this.session = null;
        throw new FlashStopError('cli-launch-failed', `PCM Hammer CLI could not start: ${error.message}`);
      }
      session.child = child;
      this.hardwareTransaction.markProcessStarted({ port: session.device || '', operation: session.operation, sessionId: session.id, workflowAttemptId: session.workflowAttemptId || '' });
      try { this.registerOwnedProcess(child.pid, preflight.resolved.executable, session.id); } catch {}
      child.stdout?.on('data', chunk => {
        try { fs.appendFileSync(deviceAttempt.stdoutLog, chunk); } catch {}
        append('stdout', chunk);
      });
      child.stderr?.on('data', chunk => {
        try { fs.appendFileSync(deviceAttempt.stderrLog, chunk); } catch {}
        append('stderr', chunk);
      });
      startReadWatchdog(child, deviceAttempt);
      child.on('error', error => {
        if (session.finalized) return;
        // Node can emit `error` before `close`, including on Windows process
        // failures. Releasing here races another OBDLink/PCM Hammer COM owner.
        // Leave session, PID ownership and hardware transaction active until
        // `close` confirms that stdio and process handles have been closed.
        stopReadWatchdog();
        session.childProcessError = clean(error.message || error, 1000);
        session.phase = 'PCM Hammer process error — waiting for confirmed process exit';
        append('safety', `PCM Hammer child process error: ${session.childProcessError}. Waiting for process close before releasing COM ownership.\n`);
        emit();
      });
      child.on('close', async code => {
        stopReadWatchdog();
        try { this.releaseOwnedProcess(child.pid); } catch {}
        if (session.finalized) return;
        const attemptEntries = session.log.slice(attemptStart);
        const attemptText = attemptEntries.map(item => item.text).join('\n');
        // Do not retry another CLI profile/COM port after a process error.
        // Only `close` proves that the original process has released handles.
        if (session.childProcessError) {
          deviceAttempt.finishedAt = new Date().toISOString();
          deviceAttempt.stopCode = 'cli-process-error';
          deviceAttempt.error = session.childProcessError;
          await finalize(code === null ? 1 : code, attemptText, profile);
          return;
        }
        const communicationStarted = hasCommunicationActivity(attemptText);
        // Even a zero-byte output is an interrupted read. Never try another
        // profile or COM port against the same destination once it exists.
        const readOutputCreated = session.operation === 'read' && outputWasCreated(session.output);
        const retryable = safeToRetryProfile({ operation: session.operation, text: attemptText, exitCode: code, output: session.output });
        const usageOnly = looksLikeCliUsageOnly(attemptText);
        const openTimeout = portOpenTimedOut(attemptText);
        const openFailure = isPortOpenFailure(attemptText);
        const missingKernel = kernelFilesMissing(attemptText);
        const accessBlocked = !communicationStarted && /(?:access\s+(?:to\s+the\s+port\s+)?is\s+denied|port\s+.*(?:busy|in use|locked)|another\s+(?:program|process).*using)/i.test(attemptText);
        deviceAttempt.finishedAt = new Date().toISOString();
        deviceAttempt.exitCode = code;
        deviceAttempt.communicationStarted = communicationStarted;
        deviceAttempt.openTimeout = openTimeout;
        deviceAttempt.openFailure = openFailure;
        deviceAttempt.accessBlocked = accessBlocked;
        deviceAttempt.kernelMissing = missingKernel;
        deviceAttempt.excerpt = clean(attemptText, 2400);
        this.hardwareTransaction.markProcessClosed({
          port: session.device || '', operation: session.operation, sessionId: session.id,
          success: false, communicationStarted,
          stopCode: openTimeout ? 'adapter-open-timeout' : accessBlocked ? 'adapter-locked' : openFailure ? 'adapter-open-failed' : ''
        });
        session.hardwareTransaction = this.hardwareTransaction.snapshot();
        session.profileAttempts.push({
          profileId: profile.id, label: profile.label, args, device: session.device || '', kernelDir: session.kernelDir || '',
          exitCode: code, syntaxFailure: retryable,
          usageOnly, communicationStarted,
          openTimeout, openFailure, accessBlocked, kernelMissing: missingKernel,
          at: new Date().toISOString(), excerpt: clean(attemptText, 2400)
        });
        session.technicalDetails = {
          executable: session.executable, args: [...args],
          commandLine: [session.executable, ...args].map(value => /\s/.test(String(value)) ? `"${String(value)}"` : String(value)).join(' '),
          device: session.device || '', deviceSpec: session.deviceSpec || session.device || '', deviceAttempts: session.deviceAttempts || [], exitCode: code, profileId: profile.id, usageOnly,
          kernelDir: session.kernelDir || '', kernelFiles: session.kernelFiles || [],
          communicationStarted, openFailure, openTimeout,
          deviceCandidates: session.deviceCandidates || [], deviceDiscoveryPasses: session.deviceDiscoveryPasses || [],
          stdoutStderrExcerpt: clean(attemptText, 12000), sessionLog,
          exclusiveGuard: session.exclusiveGuard || null, safetySnapshot: session.safetySnapshot || null, workflowAttemptId: session.workflowAttemptId || '',
          pinnedProvenPort: Boolean(portLease.pinnedProvenPort), hardwareTransaction: this.hardwareTransaction.snapshot()
        };

        // A signal-killed CLI can print a stale type-hint error before its
        // ambiguous exit. Never start a second COM attempt without a numeric,
        // nonzero parser-rejection exit and no runtime/port failure evidence.
        const typedDeviceSpecUnsupported = Boolean(
          session.deviceSpec && session.deviceSpec !== session.device &&
          safeTypedDeviceFallback({ operation: session.operation, text: attemptText, exitCode: code, deviceSpec: session.deviceSpec, output: session.output }) &&
          !openFailure && !openTimeout && !accessBlocked && !missingKernel &&
          !session.readWatchdogTriggered
        );
        if (portLease.pinnedProvenPort && typedDeviceSpecUnsupported && !readOutputCreated && !session.typeHintFallbackTried && !session.cancelRequested && !communicationStarted) {
          session.typeHintFallbackTried = true;
          session.deviceSpec = session.device;
          const currentCandidate = session.deviceCandidates?.[deviceIndex];
          if (currentCandidate) currentCandidate.deviceSpec = session.device;
          append('recovery', `The installed PCM Hammer CLI does not accept the OBDLink type-pinned device form. TunIQ is retrying the same proven ${session.device} once with the plain COM name. No alternate COM port will be scanned.
`);
          await sleep(hardwareSettle(750));
          launchProfile(index, deviceIndex);
          return;
        }
        const canRetryPort = !readOutputCreated && !session.readWatchdogTriggered && !portLease.verifiedByBroker && !portLease.pinnedProvenPort && !session.cancelRequested && !communicationStarted && ['readProperties', 'read', 'testWrite'].includes(session.operation);
        const pinnedFailureCode = openTimeout ? 'adapter-open-timeout' : accessBlocked ? 'adapter-locked' : openFailure ? 'adapter-open-failed' : '';
        const canControlledReopen = !readOutputCreated && portLease.pinnedProvenPort && !session.cancelRequested && this.hardwareTransaction.canAttemptControlledReopen({
          port: session.device || '', operation: session.operation, communicationStarted, stopCode: pinnedFailureCode
        });
        if (canControlledReopen) {
          append('recovery', `${session.device} previously completed PCM communication for this exact P01 project. Windows did not release/reopen the Bluetooth COM endpoint for the next step, so TunIQ is closing every TunIQ-owned handle, waiting for the RFCOMM driver to settle, and retrying ${session.device} one final time. No alternate COM port will be scanned.\n`);
          const exclusiveLane = await this.prepareExclusivePcmHammerLane(session.device, session.operation, portLease.leaseId, 'proven-port-controlled-reopen-exclusive');
          portLease.attempts.push(exclusiveLane);
          const reopeningTransactionId = this.hardwareTransaction.snapshot().transactionId;
          let recovery;
          try {
            recovery = await this.hardwareTransaction.controlledReopen({
              port: session.device || '', operation: session.operation, communicationStarted, stopCode: pinnedFailureCode,
              onWait: waitMs => {
                session.phase = `Releasing and reopening proven ${session.device} — controlled ${Math.ceil(waitMs / 1000)}s Windows Bluetooth settle`;
                session.hardwareTransaction = this.hardwareTransaction.snapshot();
                emit();
              }
            });
          } catch (error) {
            session.stopCode = 'controlled-reopen-denied';
            append('safety', `Controlled same-port reopen stopped: ${clean(error.message, 300)}. No second PCM Hammer process launched.\n`);
            if (this.session === session && this.hardwareTransaction.snapshot().transactionId === reopeningTransactionId) {
              await finalize(code, attemptText, profile);
            } else {
              // Another transaction owns the ledger. Never finalize this old
              // attempt into the new transaction or release its COM owner.
              session.finalized = true;
              if (this.session === session) this.session = null;
            }
            return;
          }
          if (this.session !== session || session.cancelRequested) {
            session.stopCode = 'controlled-reopen-cancelled';
            if (this.session === session && this.hardwareTransaction.snapshot().transactionId === reopeningTransactionId) {
              await finalize(code, attemptText, profile);
            }
            return;
          }
          session.hardwareTransaction = this.hardwareTransaction.snapshot();
          session.controlledProvenPortRecovery = recovery;
          const pinnedCandidate = session.deviceCandidates.find(item => String(item.port || '').toUpperCase() === String(session.device || '').toUpperCase());
          if (pinnedCandidate) pinnedCandidate.source = 'proven-port-controlled-reopen';
          const candidateIndex = session.deviceCandidates.findIndex(item => String(item.port || '').toUpperCase() === String(session.device || '').toUpperCase());
          launchProfile(index, candidateIndex >= 0 ? candidateIndex : deviceIndex);
          return;
        }
        if (portLease.pinnedProvenPort && !communicationStarted && (openFailure || openTimeout || accessBlocked)) {
          session.stopCode = 'proven-port-reopen-failed';
          append('recovery', `${session.device} remained unavailable after the controlled same-port release and Bluetooth settle. TunIQ stopped without scanning COM1/COM3 or discarding the completed Read Properties evidence.\n`);
        }
        if (canRetryPort && (openFailure || openTimeout || accessBlocked)) {
          const retryKey = `${session.device || 'auto'}:${profile.id}`;
          const retryCount = Number(session.portRetryCounts[retryKey] || 0);
          if (retryCount < 1 && session.device) {
            session.portRetryCounts[retryKey] = retryCount + 1;
            append('recovery', `${session.device} did not open. TunIQ is clearing stale serial ownership and retrying this same port once.\n`);
            const handoff = await this.handoffPort(session.device, session.operation, portLease.leaseId, 'same-port-retry');
            portLease.attempts.push(handoff);
            await sleep(hardwareSettle(450));
            launchProfile(index, deviceIndex);
            return;
          }
          const added = await this.refreshSessionDeviceCandidates(session, `${session.device || 'selected port'} failed after bounded retry`);
          if (added.length) append('recovery', `Windows/PCM Hammer rescan found additional serial candidate(s): ${added.map(item => item.port).join(', ')}.\n`);
          const attemptedPorts = new Set((session.deviceAttempts || []).map(item => String(item.device || '').toUpperCase()).filter(Boolean));
          const nextCandidate = (session.deviceCandidates || [])
            .filter(item => item?.port && !attemptedPorts.has(String(item.port).toUpperCase()))
            .sort((a, b) => Number(b.recoveryScore || 0) - Number(a.recoveryScore || 0)
              || Number(Boolean(b.outgoing)) - Number(Boolean(a.outgoing))
              || String(a.port).localeCompare(String(b.port), undefined, { numeric: true }))[0];
          const nextIndex = nextCandidate ? session.deviceCandidates.findIndex(item => String(item.port).toUpperCase() === String(nextCandidate.port).toUpperCase()) : -1;
          if (nextCandidate?.port) {
            append('recovery', `${session.device} could not be opened. TunIQ is switching to alternate ${nextCandidate.outgoing ? 'outgoing ' : ''}Bluetooth/OBDLink port ${nextCandidate.port}.\n`);
            const handoff = await this.handoffPort(nextCandidate.port, session.operation, portLease.leaseId, nextCandidate.source || 'recognized-alternate');
            portLease.attempts.push(handoff);
            await sleep(hardwareSettle(450));
            launchProfile(index, nextIndex);
            return;
          }
        }

        if (!session.readWatchdogTriggered && !session.cancelRequested && retryable && index + 1 < profiles.length) {
          append('integration', `Command profile ${profile.id} was rejected before any PCM communication. Retrying safely with ${profiles[index + 1].id}.\n`);
          await sleep(80);
          launchProfile(index + 1, deviceIndex);
          return;
        }
        await finalize(code, attemptText, profile);
      });
      emit();
    };

    this.appendActivity(`flash-${session.operation}-started`, {
      projectId: session.projectId, projectName: session.projectName,
      device: session.device, voltage: session.voltage,
      releasedTunIQPort: portLease.released, directPortLease: true, portLeaseId: portLease.leaseId
    });
    launchProfile(0, 0);
    emit();
    return { ...session, child: undefined, readWatchdogTimer: undefined };
    } finally {
      // A successful launch remains protected by this.session; failed preflight
      // must release the latch so the user can safely retry later.
      this.startPending = false;
    }
  }

  async cancel() {
    if (!this.session?.child) return this.status();
    const session = this.session;
    if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && /eras|writ|program|verif/i.test(session.phase || '')) {
      session.cancelBlocked = true; session.phase = 'Cancellation blocked during critical flash phase';
      session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'TunIQ will not terminate PCM Hammer during erase/write/verify. Maintain power and allow it to finish.' });
      this.emit('flash:progress', { ...session, child: undefined, readWatchdogTimer: undefined }); return this.status();
    }
    session.cancelRequested = true; session.phase = 'Safe cancellation requested';
    try {
      if (process.platform === 'win32' && session.child.pid) spawn('taskkill.exe', ['/PID', String(session.child.pid), '/T', '/F'], { windowsHide: true });
      else session.child.kill('SIGTERM');
    } catch {}
    return this.status();
  }

  prepareAssisted(operation, payload = {}, reason = null) {
    const normalizedOperation = this.assertReadOnlyBetaOperation(operation);
    this.assertAssistedEvidenceAllowed();
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const folder = this.assistedFolder(active);
    const state = {
      type: 'pcmhammer-assisted-operation', version: 1, projectId: active.id, projectName: active.name,
      operation: normalizedOperation, status: 'waiting-for-evidence', folder,
      input: payload.input || null, device: payload.device || this.getConfig().device || this.getDeviceStatus()?.connection?.port || '',
      reason: reason ? clean(reason.message || reason, 2000) : 'CLI automation is unavailable for this step.',
      instructions: assistedInstructions(normalizedOperation, folder),
      knownFiles: fs.readdirSync(folder).map(name => fileFingerprint(path.join(folder, name))),
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    writeJson(this.assistedStateFile(active), state);
    return state;
  }

  async launchAssisted(operation, payload = {}, reason = null) {
    this.assertReadOnlyBetaOperation(operation);
    // An unrestricted external PCM Hammer GUI can write even if TunIQ requested
    // Read Properties. Do not auto-launch it in the restricted read-only beta.
    if (this.readOnlyBeta) throw new FlashStopError('read-only-beta-external-tool-blocked',
      'Restricted TunIQ beta cannot launch the unrestricted PCM Hammer GUI. Use the integrated read-only CLI.');
    const state = this.prepareAssisted(operation, payload, reason);
    const gui = this.resolveGuiExecutable();
    if (state.device) {
      await this.releasePort({ port: state.device, operation: state.operation });
      await sleep(100);
      const lock = await this.probePortLock({ port: state.device, operation: state.operation });
      if (lock?.locked || lock?.available === false) {
        state.status = 'blocked'; state.stopCode = 'adapter-locked'; state.stopMessage = `${state.device} is still locked. Close the program using it before opening PCM Hammer.`;
        writeJson(this.assistedStateFile(), state); return state;
      }
    }
    if (gui) {
      try { const child = spawn(gui, [], { detached: true, windowsHide: false, cwd: path.dirname(gui), stdio: 'ignore' }); child.unref(); state.guiExecutable = gui; state.guiLaunchedAt = new Date().toISOString(); }
      catch (error) { state.launchWarning = error.message; }
    } else state.launchWarning = 'The normal PcmHammer.exe was not found. Open it manually.';
    state.updatedAt = new Date().toISOString(); writeJson(this.assistedStateFile(), state);
    this.watchAssisted(state);
    this.appendActivity('pcmhammer-assisted-started', { projectId: state.projectId, operation: state.operation, folder: state.folder, reason: state.reason });
    return state;
  }

  watchAssisted(state) {
    if (!state?.folder || this.assistedWatchers.has(state.projectId)) return;
    let timer = null;
    try {
      const watcher = fs.watch(state.folder, () => {
        clearTimeout(timer); timer = setTimeout(() => this.scanAssisted().catch(() => {}), 350);
      });
      watcher.on('error', () => {});
      this.assistedWatchers.set(state.projectId, watcher);
    } catch {}
  }
  stopAssistedWatcher(projectId) {
    const watcher = this.assistedWatchers.get(projectId); if (watcher) { try { watcher.close(); } catch {} this.assistedWatchers.delete(projectId); }
  }

  async importAssistedEvidence(files = [], payload = {}) {
    this.assertAssistedEvidenceAllowed();
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const state = readJson(this.assistedStateFile(active), null) || this.prepareAssisted(payload.operation || 'readProperties', payload);
    const candidates = uniqueFiles(files).filter(file => fs.existsSync(file) && fs.statSync(file).isFile());
    if (!candidates.length) return { ...state, imported: [] };
    const imported = []; const logs = [];
    for (const file of candidates) {
      const ext = path.extname(file).toLowerCase();
      if (ext === '.bin') {
        const validation = validateP01ReadFile(file, { success: true });
        if (!validation.valid) { imported.push({ file, type: 'read', accepted: false, code: validation.code, message: validation.message }); continue; }
        const session = { id: `${Date.now()}-assisted-read`, operation: 'read', state: 'complete', device: state.device, proofSource: 'PCM Hammer WinForms assisted full read', result: { success: true }, assisted: true };
        try { await this.onReadComplete(file, validation, session); await this.onSessionComplete(session); imported.push({ file, type: 'read', accepted: true, sha256: validation.sha256, size: validation.size }); }
        catch (error) { imported.push({ file, type: 'read', accepted: false, code: 'read-import-failed', message: error.message }); }
      } else if (['.txt', '.log'].includes(ext)) logs.push({ file, text: fs.readFileSync(file, 'utf8') });
    }
    for (const log of logs) {
      const identity = parseIdentityText(log.text);
      const usefulIdentity = identity.os || identity.hardwareId || identity.serviceNumber || identity.controller;
      if (usefulIdentity) {
        const session = { id: `${Date.now()}-assisted-properties`, operation: 'readProperties', state: 'complete', device: state.device, proofSource: log.file, source: 'PCM Hammer WinForms Read Properties', assisted: true };
        try { await this.onIdentifyComplete(identity, session); await this.onSessionComplete(session); imported.push({ file: log.file, type: 'read-properties', accepted: true, identity }); }
        catch (error) { imported.push({ file: log.file, type: 'read-properties', accepted: false, code: 'identity-import-failed', message: error.message }); }
      }
      const testResult = classifyPcmHammerResult('testWrite', log.text, 0);
      if (testResult.testWritePassed && state.input && fs.existsSync(state.input)) {
        const session = { id: `${Date.now()}-assisted-test-write`, operation: 'testWrite', input: state.input, state: 'complete', testWritePassed: true, verified: true, device: state.device, proofSource: log.file, sessionLog: log.file, result: testResult, assisted: true };
        try { await this.onSessionComplete(session); imported.push({ file: log.file, type: 'test-write', accepted: true, input: state.input }); }
        catch (error) { imported.push({ file: log.file, type: 'test-write', accepted: false, code: 'test-write-import-failed', message: error.message }); }
      }
    }
    const accepted = imported.filter(item => item.accepted);
    state.imported = [...(state.imported || []), ...accepted.map(item => ({ ...item, importedAt: new Date().toISOString() }))].slice(-50);
    state.knownFiles = [...new Set([...(state.knownFiles || []), ...candidates.map(fileFingerprint)])];
    state.updatedAt = new Date().toISOString();
    if (accepted.length) state.status = 'evidence-imported';
    writeJson(this.assistedStateFile(active), state);
    return { ...state, imported };
  }

  async scanAssisted() {
    this.assertAssistedEvidenceAllowed();
    const active = this.getActiveProject();
    if (!active) return null;
    const state = readJson(this.assistedStateFile(active), null);
    if (!state?.folder || !fs.existsSync(state.folder)) return state;
    const known = new Set(state.knownFiles || []);
    const files = fs.readdirSync(state.folder).map(name => path.join(state.folder, name)).filter(file => {
      try { return fs.statSync(file).isFile() && !known.has(fileFingerprint(file)); } catch { return false; }
    });
    if (!files.length) { this.watchAssisted(state); return { ...state, imported: [] }; }
    return this.importAssistedEvidence(files, { operation: state.operation, input: state.input });
  }
}

module.exports = {
  FlashManager, FlashStopError, inferTemplates, expandTemplate, parseProgress, parseIdentityText,
  parseBackendIdentity, classifyPcmHammerResult, validateP01ReadFile, normalizeOperation, P01_BIN_SIZE,
  allowsDirectPcmHammerHandoff
};
