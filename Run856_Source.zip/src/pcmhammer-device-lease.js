'use strict';
const { isPcmRuntimeFailure, isPortOpenFailure, hasCommunicationActivity, normalizeCliDiagnosticText, hasUnrecognizedCliEscape } = require('./pcmhammer-integrated');
const { checkUnusedReadDestination } = require('./read-output-safety');
function clean(value, max = 500) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}
function normalizePort(value) {
  const match = clean(value, 80).toUpperCase().match(/^(COM\d+)(?::[A-Z0-9_-]+)?$/);
  return match ? match[1] : '';
}
function adapterIdentityText(profile = {}, proof = {}) {
  return [
    profile.adapterName,
    profile.adapterIdentity,
    profile.description,
    profile.firmware,
    proof.adapter,
    proof.adapterIdentity,
    proof.adapterName
  ].map(value => clean(value, 300)).filter(Boolean).join(' ');
}
function isElmFamilyAdapter(profile = {}, proof = {}) {
  return /obdlink|scan\s*tool|scantool|stn\d+|elm327|mx\+|mxplus/i.test(adapterIdentityText(profile, proof));
}
function supportsSerialTypeHints(helpText = '') {
  const text = clean(helpText, 100000);
  return /COM\w*\s*:\s*elm|COM\d+:elm|serial\s+device\s+type|known:\s*avt,\s*xpro,\s*elm,\s*slcan/i.test(text);
}
function buildPcmHammerDeviceSpec({ port = '', authoritative = false, adapterProfile = {}, proof = {}, helpText = '', forceElmHint = true } = {}) {
  const normalized = normalizePort(port);
  if (!normalized) return { port: '', spec: '', mode: 'none', typed: false };
  const elmFamily = isElmFamilyAdapter(adapterProfile, proof);
  const advertised = supportsSerialTypeHints(helpText);
  const typed = Boolean(authoritative && elmFamily && (forceElmHint || advertised));
  return {
    port: normalized,
    spec: typed ? `${normalized}:elm` : normalized,
    mode: typed ? 'proven-obdlink-elm-type-pin' : authoritative ? 'proven-port-plain' : 'plain',
    typed,
    advertised,
    elmFamily,
    adapterIdentity: adapterIdentityText(adapterProfile, proof)
  };
}
function typeHintUnsupported(text = '') {
  return /unknown\s+(?:serial\s+)?device\s+type|no\s+device\s+matching\s+"?COM\d+:elm|index\s+.*out\s+of\s+range|unrecognized\s+.*COM\d+:elm/i.test(String(text || ''));
}
// A typed COMx:elm failure is not permission to launch a second CLI when
// Node reports a signal/ambiguous exit, or when an unrelated numeric index
// error happens to match the broad diagnostic matcher above. Restrict the
// plain-COM fallback to an explicit parser rejection with a real exit code.
// The caller must ALSO prove no PCM communication/output, no cancellation,
// and that the child 'close' event released process handles.
function safeTypedDeviceFallback({ operation, text, exitCode, deviceSpec, output } = {}) {
  if (!['read', 'readProperties'].includes(operation)) return false;
  // A negative native Windows exit status may represent a process crash, not
  // a parser rejection. Large unsigned Windows exception statuses also fail
  // closed: only conventional parser exits in 1..255 qualify.
  if (!Number.isSafeInteger(exitCode) || exitCode <= 0 || exitCode > 255) return false;
  // Recheck the exact unused backup path after the first CLI process closes.
  // This is a precondition, not an atomic reservation or COM release proof.
  if (operation === 'read' && !checkUnusedReadDestination(output).ok) return false;
  // A parser message about some OTHER device type or COM port must not
  // downgrade a proven COMx:elm lease to an untyped COM retry.
  const expected = String(deviceSpec || '').trim().toUpperCase();
  if (!/^COM\d+:ELM$/.test(expected)) return false;
  if (hasUnrecognizedCliEscape(text)) return false;
  const source = normalizeCliDiagnosticText(text);
  if (isPcmRuntimeFailure(source) || isPortOpenFailure(source) || hasCommunicationActivity(source)) return false;
  const typedPorts = source.match(/\bCOM\d+:elm\b/ig) || [];
  if (typedPorts.some(port => port.toUpperCase() !== expected)) return false;
  // A generic 'unknown device type elm' message may name a *different*
  // untyped COM port elsewhere in the diagnostic. Treat any other COM port
  // or type as conflicting evidence; do not launch a second CLI attempt.
  const expectedPort = expected.slice(0, -4); // strip ':ELM'
  const mentionedPorts = source.match(/\bCOM\d+(?::[A-Z0-9_-]+)?\b/ig) || [];
  if (mentionedPorts.some(port => {
    const actual = port.toUpperCase();
    return actual !== expectedPort && actual !== expected;
  })) return false;
  const expectedPattern = expected.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  return /unknown\s+(?:serial\s+)?device\s+type\s*[:=]?\s*["']?elm\b/i.test(source) ||
    new RegExp(`(?:no\\s+device\\s+matching\\s+["']?|unrecognized\\s+[^\\r\\n]{0,80}\\b)${expectedPattern}\\b`, 'i').test(source);
}

module.exports = {
  normalizePort,
  adapterIdentityText,
  isElmFamilyAdapter,
  supportsSerialTypeHints,
  buildPcmHammerDeviceSpec,
  typeHintUnsupported,
  safeTypedDeviceFallback
};
