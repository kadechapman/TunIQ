'use strict';
// Read-only inventory of interrupted phone-log publications. Never opens log
// contents, follows file symlinks, or deletes/replaces import artifacts.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { CANONICAL_COLUMNS, MAX_LOG_ROWS } = require('./log-import');

const MAX_AUDIT_ENTRIES = 10000;
const IMPORT_NAME = /^(.*)-Imported-(\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}-\d{3}Z)(\.csv|\.meta\.json|\.import\.json)$/i;
const STAGE_PREFIX = '.phone-log-stage-';
const PARTS = ['csv', 'meta', 'report'];
const MAX_AUDIT_CSV_BYTES = 64 * 1024 * 1024;
const MAX_AUDIT_JSON_BYTES = 1024 * 1024;

// A directory can be replaced after lstat but before opendir, or after
// enumeration but before reading group contents. Do not follow a replacement
// Logs symlink or silently certify a different directory. Directory mtimes
// are intentionally ignored because another process may create a log file.
function assertStableLogsDirectory(logsFolder, original) {
  const current = fs.lstatSync(logsFolder);
  if (!current.isDirectory() || current.isSymbolicLink() ||
      current.dev !== original.dev || current.ino !== original.ino) {
    throw new Error('Phone-log Logs directory changed during audit. Retry with a stable project folder.');
  }
}

function sameIdentity(a, b) {
  return a.isFile() && b.isFile() && a.nlink === 1 && b.nlink === 1 &&
    a.dev === b.dev && a.ino === b.ino && a.size === b.size &&
    a.mtimeMs === b.mtimeMs && a.ctimeMs === b.ctimeMs;
}

// Content verification is opt-in; never open a linked file, follow a redirect,
// or read more than the fixed per-file budget. Never return log contents.
function readBoundedFile(file, maxBytes) {
  const before = fs.lstatSync(file);
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1) throw new Error('unsafe-file');
  if (!Number.isSafeInteger(before.size) || before.size > maxBytes) throw new Error('oversized-file');
  const fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const opened = fs.fstatSync(fd);
    if (!sameIdentity(before, opened)) throw new Error('changed-file');
    const data = Buffer.alloc(before.size);
    let offset = 0;
    while (offset < data.length) {
      const read = fs.readSync(fd, data, offset, data.length - offset, null);
      if (read === 0) throw new Error('truncated-file');
      offset += read;
    }
    if (fs.readSync(fd, Buffer.alloc(1), 0, 1, null) !== 0) throw new Error('grown-file');
    const after = fs.fstatSync(fd);
    const pathAfter = fs.lstatSync(file);
    if (!sameIdentity(opened, after) || !sameIdentity(after, pathAfter)) throw new Error('changed-file');
    return data;
  } finally { fs.closeSync(fd); }
}

function verifyGroupContents(logsFolder, group) {
  const issues = [];
  const paths = Object.fromEntries(PARTS.map(part => [part, path.join(logsFolder, group.parts[part])]));
  let csv, meta, report;
  try {
    csv = readBoundedFile(paths.csv, MAX_AUDIT_CSV_BYTES);
    meta = JSON.parse(readBoundedFile(paths.meta, MAX_AUDIT_JSON_BYTES).toString('utf8'));
    report = JSON.parse(readBoundedFile(paths.report, MAX_AUDIT_JSON_BYTES).toString('utf8'));
  } catch (error) {
    return { status: 'inconsistent', issues: [error.message === 'unsafe-file' ? 'unsafe-file' :
      error.message === 'oversized-file' ? 'oversized-file' :
      /^(changed|truncated|grown)-file$/.test(error.message) ? 'unstable-file' : 'unreadable-or-invalid-json'] };
  }
  if (!meta || Array.isArray(meta) || typeof meta !== 'object' ||
      !report || Array.isArray(report) || typeof report !== 'object') {
    return { status: 'inconsistent', issues: ['invalid-metadata'] };
  }
  if (meta.csvPath !== paths.csv || meta.metaPath !== paths.meta || meta.status !== 'complete') {
    issues.push('metadata-path-or-status');
  }
  for (const key of ['id', 'projectId', 'csvPath', 'metaPath', 'samples', 'sourceFileSha256',
    'normalizedFingerprint', 'normalizedCsvSha256', 'profileKey', 'startedAt', 'status']) {
    if (meta[key] !== report[key]) { issues.push('metadata-report-mismatch'); break; }
  }
  const firstNewline = csv.indexOf(10);
  if (firstNewline < 0 || csv.subarray(0, firstNewline).toString('utf8') !== CANONICAL_COLUMNS.join(',') ||
      csv.length === 0 || csv[csv.length - 1] !== 10) issues.push('invalid-csv-layout');
  else {
    let newlineCount = 0;
    for (const byte of csv) if (byte === 10) newlineCount++;
    if (!Number.isSafeInteger(meta.samples) || meta.samples < 1 || meta.samples > MAX_LOG_ROWS ||
        newlineCount - 1 !== meta.samples) issues.push('sample-count-mismatch');
  }
  const digest = meta.normalizedCsvSha256;
  if (digest !== undefined && digest !== null) {
    if (typeof digest !== 'string' || !/^[a-f0-9]{64}$/.test(digest) ||
        crypto.createHash('sha256').update(csv).digest('hex') !== digest) issues.push('csv-digest-mismatch');
  }
  return { status: issues.length ? 'inconsistent' : digest ? 'verified' : 'legacy-unverified', issues };
}


function auditPhoneLogImports(projectFolder, { maxEntries = MAX_AUDIT_ENTRIES, verifyContents = false } = {}) {
  if (typeof verifyContents !== 'boolean') throw new Error('verifyContents must be a boolean.');
  if (typeof projectFolder !== 'string' || !projectFolder.trim()) throw new Error('Provide a project directory.');
  if (!Number.isSafeInteger(maxEntries) || maxEntries < 1 || maxEntries > MAX_AUDIT_ENTRIES) {
    throw new Error(`Audit entry limit must be between 1 and ${MAX_AUDIT_ENTRIES}.`);
  }
  const folder = path.resolve(projectFolder);
  const logsFolder = path.join(folder, 'Logs');
  // Do not create the project or Logs directory during an audit.
  let directory;
  try { directory = fs.lstatSync(logsFolder); }
  catch (error) {
    if (error.code === 'ENOENT') return { status: 'clean', logsFolder, scanned: 0, truncated: false, verifyContents, groups: [], staging: [] };
    throw error;
  }
  if (!directory.isDirectory() || directory.isSymbolicLink()) {
    throw new Error('Phone-log audit requires a real, non-symlink Logs directory.');
  }
  const groups = new Map();
  const staging = [];
  let scanned = 0;
  let truncated = false;
  const dir = fs.opendirSync(logsFolder);
  try {
    assertStableLogsDirectory(logsFolder, directory);
    let entry;
    while ((entry = dir.readSync()) !== null) {
      assertStableLogsDirectory(logsFolder, directory);
      if (scanned >= maxEntries) { truncated = true; break; }
      scanned++;
      const name = entry.name;
      if (name.startsWith(STAGE_PREFIX)) {
        const info = fs.lstatSync(path.join(logsFolder, name));
        staging.push({ name, type: info.isSymbolicLink() ? 'symlink' : info.isDirectory() ? 'directory' : 'other' });
        continue;
      }
      const match = IMPORT_NAME.exec(name);
      if (!match) continue;
      const suffix = match[3].toLowerCase();
      const part = suffix === '.csv' ? 'csv' : suffix === '.meta.json' ? 'meta' : 'report';
      const key = `${match[1]}-Imported-${match[2]}`;
      if (!groups.has(key)) groups.set(key, { name: key, parts: {}, unsafe: [] });
      const group = groups.get(key);
      const info = fs.lstatSync(path.join(logsFolder, name));
      if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1) group.unsafe.push(name);
      else if (group.parts[part]) group.unsafe.push(name);
      else group.parts[part] = name;
    }
  } finally { dir.closeSync(); }
  assertStableLogsDirectory(logsFolder, directory);
  const findings = [...groups.values()].map(group => {
    assertStableLogsDirectory(logsFolder, directory);
    const missing = PARTS.filter(part => !group.parts[part]);
    const complete = !group.unsafe.length && !missing.length;
    const consistency = verifyContents && complete ? verifyGroupContents(logsFolder, group) : null;
    assertStableLogsDirectory(logsFolder, directory);
    return { name: group.name,
      status: group.unsafe.length ? 'unsafe' : missing.length ? 'incomplete' :
        consistency?.status === 'inconsistent' ? 'inconsistent' :
        consistency?.status === 'legacy-unverified' ? 'unverified' : 'complete',
      present: PARTS.filter(part => group.parts[part]), missing, unsafe: group.unsafe.sort(),
      ...(consistency ? { consistency } : {}) };
  }).sort((a, b) => a.name.localeCompare(b.name));
  staging.sort((a, b) => a.name.localeCompare(b.name));
  assertStableLogsDirectory(logsFolder, directory);
  return { status: truncated ? 'incomplete-scan' : staging.length || findings.some(group => group.status !== 'complete') ? 'attention' : 'clean',
    logsFolder, scanned, truncated, verifyContents, groups: findings, staging };
}

module.exports = { auditPhoneLogImports, MAX_AUDIT_ENTRIES, MAX_AUDIT_CSV_BYTES, MAX_AUDIT_JSON_BYTES };
