'use strict';
// Restrict renderer-initiated navigation in the local TunIQ desktop UI.
// Deliberately does not open links externally: only explicit, allowlisted
// main-process IPC handlers may open trusted external destinations.
// Does not interact with hardware, files, or calibration state.
function attachRendererNavigationGuard(webContents) {
  if (!webContents || typeof webContents.on !== 'function' ||
      typeof webContents.setWindowOpenHandler !== 'function') {
    throw new TypeError('Electron webContents with on and setWindowOpenHandler is required');
  }
  // Install popup denial before the renderer is loaded. A remote page or
  // file:// popup must never inherit the application's preload bridge.
  webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  const deny = event => event.preventDefault();
  // loadFile() is an explicit main-process navigation, not a renderer request.
  // The TunIQ UI is a single local document and needs no renderer navigation.
  for (const eventName of ['will-navigate', 'will-frame-navigate', 'will-redirect']) {
    webContents.on(eventName, deny);
  }
  webContents.on('will-attach-webview', deny);
  return webContents;
}
module.exports = { attachRendererNavigationGuard };
