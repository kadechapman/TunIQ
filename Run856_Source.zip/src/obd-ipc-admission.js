// Protect Electron IPC paths that open or use the physical OBDLink serial port.
// This does not claim exclusive ownership of other processes' COM handles;
// it coordinates TunIQ's OBD handlers with its PCM Hammer start/exit lease.
function createObdIpcAdmission(flashManager, obdManager) {
  if (!flashManager || typeof flashManager.withExclusiveExternalPortAccess !== 'function') {
    throw new TypeError('PCM Hammer exclusive-admission manager is required.');
  }
  if (!obdManager) throw new TypeError('OBD manager is required.');
  const guard = (reason, action) => flashManager.withExclusiveExternalPortAccess(
    reason, action, { requestRecovery: false }
  );
  return Object.freeze({
    connect: payload => guard('OBDLink connection', () => obdManager.connect(payload)),
    disconnect: () => guard('OBDLink disconnect', () => obdManager.disconnect()),
    doctorRun: payload => guard('OBDLink Connection Doctor', () => obdManager.runConnectionDoctor(payload)),
    sample: () => guard('OBDLink live sample', () => obdManager.sample()),
    startLog: payload => guard('OBDLink logger start', () => obdManager.startLog(payload))
  });
}
module.exports = { createObdIpcAdmission };
