const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function exists(root, relative) {
  try { return fs.existsSync(path.join(root, relative)); } catch { return false; }
}
function readJson(file, fallback = null) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; }
}
function item(id, label, severity, detail, action = '') { return { id, label, severity, detail, action }; }
function push(condition, target, value) { if (condition) target.push(value); }

// A syntactically valid lockfile is not necessarily a complete or trustworthy
// dependency tree. This is an offline metadata gate, NOT a replacement for a
// clean npm ci, provenance review, or an independent dependency audit.
function plainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value) &&
    Object.getPrototypeOf(value) === Object.prototype;
}
function registryTarball(entry) {
  if (!plainObject(entry) || typeof entry.version !== 'string' ||
      !/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(entry.version) ||
      typeof entry.resolved !== 'string' || typeof entry.integrity !== 'string' ||
      !/^sha512-[A-Za-z0-9+/]+={0,2}$/.test(entry.integrity) ||
      Buffer.from(entry.integrity.slice(7), 'base64').length !== 64) return false;
  try {
    const url = new URL(entry.resolved);
    // Public-beta builds use the official npm registry. Other registries,
    // workspaces, links and bundled packages require separate review.
    return url.protocol === 'https:' && url.hostname === 'registry.npmjs.org' &&
      !url.port && !url.username && !url.password && !url.search && !url.hash &&
      url.pathname.endsWith('.tgz');
  } catch { return false; }
}
function validPackagePath(name) {
  const part = '(?:@[A-Za-z0-9._-]+\\/)?[A-Za-z0-9._-]+';
  // Every segment must be an installed package; reject path traversal and
  // workspace/link entries that this source-only gate cannot audit.
  const pattern = new RegExp(`^node_modules\\/${part}(?:\\/node_modules\\/${part})*$`);
  return pattern.test(name) && !name.split('/').some(segment => segment === '.' || segment === '..');
}
function resolvesDependency(packages, parentPath, dependency) {
  let current = parentPath;
  for (;;) {
    const candidate = `${current ? current + '/' : ''}node_modules/${dependency}`;
    if (Object.prototype.hasOwnProperty.call(packages, candidate)) return true;
    if (!current) return false;
    const marker = current.lastIndexOf('/node_modules/');
    current = marker < 0 ? '' : current.slice(0, marker);
  }
}
function checkDependencyLock(appPath, pkg) {
  const candidates = ['npm-shrinkwrap.json', 'package-lock.json'];
  const present = candidates.filter(name => exists(appPath, name));
  if (present.length !== 1) return { valid: false, reason: present.length ? 'Multiple npm lockfiles are present.' : 'No npm lockfile is present.' };
  const file = path.join(appPath, present[0]);
  let lock;
  try {
    const stat = fs.lstatSync(file);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.size < 32 || stat.size > 20 * 1024 * 1024)
      return { valid: false, reason: 'The lockfile is not a safe, nonempty regular file.' };
    lock = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch { return { valid: false, reason: 'The lockfile cannot be parsed safely.' }; }
  if (!plainObject(lock) || ![2, 3].includes(lock.lockfileVersion) || !plainObject(lock.packages))
    return { valid: false, reason: 'An npm v2/v3 lockfile with package entries is required.' };
  const root = lock.packages[''];
  if (!plainObject(root) || lock.name !== pkg.name || lock.version !== pkg.version ||
      root.name !== pkg.name || root.version !== pkg.version)
    return { valid: false, reason: 'Lockfile root name/version does not match package.json.' };
  const dependencies = ['dependencies', 'devDependencies', 'optionalDependencies'];
  for (const field of dependencies) {
    const declared = pkg[field] === undefined ? {} : pkg[field];
    const locked = root[field] === undefined ? {} : root[field];
    if (!plainObject(declared) || !plainObject(locked) ||
        Object.keys(declared).length !== Object.keys(locked).length ||
        Object.entries(declared).some(([name, version]) => locked[name] !== version))
      return { valid: false, reason: `Lockfile root ${field} does not match package.json.` };
    for (const [name, version] of Object.entries(declared)) {
      if (typeof version !== 'string' || !/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(version))
        return { valid: false, reason: `Direct dependency ${name} is not an exact version pin.` };
      const entry = lock.packages[`node_modules/${name}`];
      if (!registryTarball(entry) || entry.version !== version)
        return { valid: false, reason: `Direct dependency ${name} lacks a matching official-registry SHA-512 lock entry.` };
    }
  }
  const entries = Object.entries(lock.packages);
  if (entries.length > 10000) return { valid: false, reason: 'Lockfile package tree exceeds the review limit.' };
  for (const [name, entry] of entries) {
    if (name === '') continue;
    if (!validPackagePath(name) || !registryTarball(entry))
      return { valid: false, reason: `Locked package ${name} lacks reviewed registry integrity metadata.` };
    for (const field of ['dependencies', 'optionalDependencies']) {
      if (entry[field] === undefined) continue;
      if (!plainObject(entry[field]))
        return { valid: false, reason: `Locked package ${name} has malformed ${field}.` };
      for (const dependency of Object.keys(entry[field])) {
        if (!validPackagePath(`node_modules/${dependency}`) ||
            !resolvesDependency(lock.packages, name, dependency))
          return { valid: false, reason: `Locked package ${name} has missing or unsupported ${field} entry ${dependency}.` };
      }
    }
  }
  return { valid: true, reason: `${present[0]} contains offline dependency-tree SHA-512 metadata; npm ci and tarball provenance review still required.` };
}

// The private evidence root may itself be a normal directory beneath a
// redirected ancestor (Windows junction or POSIX symlink). Inspect every
// ancestor, not just the final directory, and compare identities afterward.
// This is a best-effort filesystem integrity check, not an atomic lock.
function evidenceDirectoryChain(root) {
  try {
    const absolute = path.resolve(root);
    const base = path.parse(absolute).root;
    const segments = absolute.slice(base.length).split(path.sep).filter(Boolean);
    let current = base;
    const chain = [];
    for (const segment of ['', ...segments]) {
      if (segment) current = path.join(current, segment);
      const stat = fs.lstatSync(current, { bigint: true });
      if (!stat.isDirectory() || stat.isSymbolicLink() || stat.ino === 0n) return null;
      chain.push({ path: current, dev: stat.dev, ino: stat.ino });
    }
    return chain;
  } catch { return null; }
}
function sameEvidenceDirectoryChain(root, before) {
  const after = evidenceDirectoryChain(root);
  return Boolean(before && after && before.length === after.length &&
    before.every((entry, index) => entry.path === after[index].path &&
      entry.dev === after[index].dev && entry.ino === after[index].ino));
}

// The evidence manifest is itself part of the trust boundary. Do not follow
// a symlink/hard link to a JSON manifest outside the private evidence folder.
// Pin the opened inode while parsing, and fail closed on a replacement or edit.
function readPrivateHardwareManifest(root) {
  const manifestFile = path.join(root, 'hardware-verification.json');
  let fd;
  try {
    const rootChain = evidenceDirectoryChain(root);
    if (!rootChain) return null;
    const rootBefore = fs.lstatSync(root);
    if (!rootBefore.isDirectory() || rootBefore.isSymbolicLink()) return null;
    const before = fs.lstatSync(manifestFile);
    if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1 ||
        before.size === 0 || before.size > 1024 * 1024) return null;
    fd = fs.openSync(manifestFile, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.nlink !== 1 || opened.dev !== before.dev ||
        opened.ino !== before.ino || opened.size !== before.size) return null;
    const contents = fs.readFileSync(fd, 'utf8');
    const after = fs.fstatSync(fd);
    const named = fs.lstatSync(manifestFile);
    const rootAfter = fs.lstatSync(root);
    if (!named.isFile() || named.isSymbolicLink() || named.nlink !== 1 ||
        named.dev !== opened.dev || named.ino !== opened.ino || named.size !== opened.size ||
        after.dev !== opened.dev || after.ino !== opened.ino || after.nlink !== 1 ||
        after.size !== opened.size || after.mtimeMs !== opened.mtimeMs ||
        after.ctimeMs !== opened.ctimeMs || rootAfter.dev !== rootBefore.dev ||
        rootAfter.ino !== rootBefore.ino || rootAfter.isSymbolicLink() ||
        fs.realpathSync(manifestFile) !== path.join(fs.realpathSync(root), 'hardware-verification.json') ||
        !sameEvidenceDirectoryChain(root, rootChain)) return null;
    return JSON.parse(contents);
  } catch { return null; }
  finally { if (fd !== undefined) fs.closeSync(fd); }
}

// Hardware verification is intentionally stricter than the user-editable support matrix.
// This checks file integrity and human signoff, NOT whether a test really occurred on a bench.
function verifyHardwareEvidence(appPath, matrix, hardwareEvidenceRoot) {
  const root = path.resolve(hardwareEvidenceRoot || path.join(appPath, 'private-hardware-evidence'));
  const rootChain = evidenceDirectoryChain(root);
  if (!rootChain) return { valid: false, reason: 'Private hardware evidence root has a redirected, missing, or unstable ancestor directory.' };
  const manifest = readPrivateHardwareManifest(root);
  if (!Array.isArray(manifest?.records)) return { valid: false, reason: 'Private hardware verification manifest is missing or invalid.' };
  const verified = matrix.filter(entry => entry.kind === 'flashing' && entry.status === 'verified' && !/virtual/i.test(String(entry.id || entry.label || '')));
  if (!verified.length) return { valid: false, reason: 'No real flashing combination is marked Verified.' };
  // A single passing bench record must not unlock a matrix that advertises
  // additional Verified controllers, OS IDs, or adapter types. Fail closed if
  // any Verified entry has an empty, ambiguous, or malformed exact scope.
  const scopes = new Map();
  for (const entry of verified) {
    if (!Array.isArray(entry.verifiedCombinations) || entry.verifiedCombinations.length === 0) {
      return { valid: false, reason: 'A Verified flashing entry has no exact controller/OS/interface scope.' };
    }
    for (const combination of entry.verifiedCombinations) {
      const controller = String(combination?.controller || '');
      const os = String(combination?.os || '');
      const adapter = String(combination?.interface || '').trim();
      if (!/^(P01|P59)$/.test(controller) || !/^\d{6,10}$/.test(os) || !adapter) {
        return { valid: false, reason: 'A Verified flashing entry has an invalid controller/OS/interface scope.' };
      }
      scopes.set(`${controller}|${os}|${adapter.toLowerCase()}`, { controller, os, adapter });
    }
  }
  function checkFile(info, expectedSize = null) {
    if (!info || typeof info.path !== 'string' || !/^[a-f0-9]{64}$/i.test(String(info.sha256 || ''))) return false;
    const resolved = path.resolve(root, info.path);
    if (!resolved.startsWith(root + path.sep)) return false;
    let fd;
    try {
      const fileRootChain = evidenceDirectoryChain(root);
      if (!fileRootChain) return false;
      // Reject redirected parent directories as well as linked files. A path
      // that resolves inside the evidence tree may still traverse a symlink.
      const rootStat = fs.lstatSync(root);
      if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) return false;
      const relative = path.relative(root, resolved);
      let current = root;
      for (const component of relative.split(path.sep)) {
        current = path.join(current, component);
        if (fs.lstatSync(current).isSymbolicLink()) return false;
      }
      const realRoot = fs.realpathSync(root);
      const realFile = fs.realpathSync(resolved);
      if (!realFile.startsWith(realRoot + path.sep)) return false;
      // A hard link can make two paths and claimed sessions reference the
      // same physical BIN, or import an external log without a symlink.
      const stat = fs.lstatSync(resolved);
      if (!stat.isFile() || stat.nlink !== 1 || stat.size === 0 ||
          (expectedSize !== null && stat.size !== expectedSize) ||
          stat.size > 16 * 1024 * 1024) return false;
      fd = fs.openSync(resolved, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
      const before = fs.fstatSync(fd);
      if (!before.isFile() || before.nlink !== 1 || before.dev !== stat.dev ||
          before.ino !== stat.ino || before.size !== stat.size) return false;
      // Stream the already-open descriptor to bound memory use. Never reopen
      // the pathname while hashing, since it could have been replaced.
      const hash = crypto.createHash('sha256');
      const chunk = Buffer.allocUnsafe(64 * 1024);
      let offset = 0;
      while (offset < before.size) {
        const n = fs.readSync(fd, chunk, 0, Math.min(chunk.length, before.size - offset), offset);
        if (n <= 0) return false;
        hash.update(chunk.subarray(0, n));
        offset += n;
      }
      const digest = hash.digest('hex');
      const after = fs.fstatSync(fd);
      if (after.dev !== before.dev || after.ino !== before.ino ||
          after.size !== before.size || after.mtimeMs !== before.mtimeMs ||
          after.ctimeMs !== before.ctimeMs || after.nlink !== 1) return false;
      const pathAfter = fs.lstatSync(resolved);
      if (!pathAfter.isFile() || pathAfter.nlink !== 1 ||
          pathAfter.dev !== before.dev || pathAfter.ino !== before.ino ||
          pathAfter.size !== before.size) return false;
      current = root;
      for (const component of relative.split(path.sep)) {
        current = path.join(current, component);
        if (fs.lstatSync(current).isSymbolicLink()) return false;
      }
      if (fs.realpathSync(resolved) !== realFile ||
          !sameEvidenceDirectoryChain(root, fileRootChain)) return false;
      return digest === info.sha256.toLowerCase();
    } catch { return false; }
    finally { if (fd !== undefined) fs.closeSync(fd); }
  }

  // Evidence must be independent across advertised Verified scopes. Two
  // records with different adapter labels cannot reuse the same BINs, read
  // session IDs, Test Write log, or recovery log to qualify two bench tests.
  const usedEvidencePaths = new Set();
  const usedReadSessions = new Set();
  const evidencePaths = record => [record.reads[0].path, record.reads[1].path,
    record.testWrite.log.path, record.recoveryReport.log.path].map(relative => {
    const absolute = path.resolve(root, relative);
    return process.platform === 'win32' ? absolute.toLowerCase() : absolute;
  });
  const sessionKeys = record => record.reads.map(read => read.sessionId.trim().toLowerCase());
  for (const scope of scopes.values()) {
    const evidenced = manifest.records.find(record => {
      if (!record || record.physicalBenchTested !== true || record.recoveryVerified !== true || record.reviewed !== true || !String(record.reviewer || '').trim()) return false;
      if (String(record.controller || '') !== scope.controller || String(record.os || '') !== scope.os ||
          String(record.interface || '').trim().toLowerCase() !== scope.adapter.toLowerCase()) return false;
      const size = record.controller === 'P01' ? 524288 : Number(record.expectedBinBytes);
      if (!Number.isSafeInteger(size) || size < 524288 || size > 4194304) return false;
      const [first, second] = Array.isArray(record.reads) ? record.reads : [];
      if (!first || !second || typeof first.path !== 'string' || typeof second.path !== 'string' ||
          path.resolve(root, first.path) === path.resolve(root, second.path) ||
          typeof first.sessionId !== 'string' || !first.sessionId.trim() ||
          typeof second.sessionId !== 'string' || !second.sessionId.trim() ||
          first.sessionId.trim().toLowerCase() === second.sessionId.trim().toLowerCase()) return false;
      if (!checkFile(first, size) || !checkFile(second, size) || first.sha256.toLowerCase() !== second.sha256.toLowerCase()) return false;
      if (record.testWrite?.outcome !== 'success' || !checkFile(record.testWrite.log)) return false;
      if (!record.testWrite?.reviewed || !record.recoveryReport?.reviewed || !checkFile(record.recoveryReport.log)) return false;
      const paths = evidencePaths(record);
      const sessions = sessionKeys(record);
      if (new Set(paths).size !== paths.length || paths.some(key => usedEvidencePaths.has(key)) ||
          sessions.some(key => usedReadSessions.has(key))) return false;
      return true;
    });
    if (!evidenced) {
      return { valid: false, reason: `Missing independent integrity-checked private evidence for Verified ${scope.controller} OS ${scope.os} on ${scope.adapter}.` };
    }
    for (const key of evidencePaths(evidenced)) usedEvidencePaths.add(key);
    for (const key of sessionKeys(evidenced)) usedReadSessions.add(key);
  }
  if (!sameEvidenceDirectoryChain(root, rootChain)) {
    return { valid: false, reason: 'Private hardware evidence directory identity changed during verification.' };
  }
  return { valid: true, reason: `Integrity-checked private evidence covers all ${scopes.size} Verified controller/OS/interface scope(s); physical provenance still requires independent review.` };

}

function buildLaunchReadiness({
  appPath = process.cwd(),
  packageJson = null,
  versionInfo = null,
  betaState = {},
  betaProgress = {},
  updateStatus = {},
  attestation = null,
  hardwareEvidenceRoot = null
} = {}) {
  const pkg = packageJson || readJson(path.join(appPath, 'package.json'), {});
  const version = versionInfo || readJson(path.join(appPath, 'VERSION.json'), {});
  const releaseAttestation = attestation || readJson(path.join(appPath, 'RELEASE_ATTESTATION.json'), {});
  const blockers = [];
  const warnings = [];
  const passed = [];

  const versionsMatch = Boolean(pkg?.version && version?.version && pkg.version === version.version);
  push(!versionsMatch, blockers, item('version-sync', 'Version metadata mismatch', 'blocker', `package.json=${pkg?.version || 'missing'} VERSION.json=${version?.version || 'missing'}`, 'Keep one authoritative version across package and release metadata.'));
  push(versionsMatch, passed, item('version-sync', 'Version metadata synchronized', 'pass', version.version));

  const lockCheck = checkDependencyLock(appPath, pkg);
  push(!lockCheck.valid, blockers, item('dependency-lock', 'Dependency lockfile missing or invalid', 'blocker', lockCheck.reason, 'Generate and review package-lock.json using npm install --package-lock-only on a trusted machine, commit it, and verify with npm ci on clean Windows.'));
  push(lockCheck.valid, passed, item('dependency-lock', 'Offline dependency-tree lock metadata checked', 'pass', lockCheck.reason));

  const licenseSelected = Boolean(pkg?.license && pkg.license !== 'UNLICENSED' && exists(appPath, 'LICENSE'));
  push(!licenseSelected, blockers, item('license', 'Software license not finalized', 'blocker', `package license is ${pkg?.license || 'missing'} and/or LICENSE is missing.`, 'Choose the project license, add LICENSE, and remove LICENSE_SELECTION_REQUIRED.md.'));
  push(licenseSelected, passed, item('license', 'Software license finalized', 'pass', pkg.license));

  const secureFeed = Boolean(updateStatus?.configured && /^https:\/\//i.test(String(betaState?.preferences?.updateFeedUrl || updateStatus?.url || '')));
  push(!secureFeed, blockers, item('update-feed', 'Secure automatic update feed not configured', 'blocker', updateStatus?.message || 'No HTTPS update feed is active.', 'Configure the production HTTPS update feed and test update/download/install on a signed installer.'));
  push(secureFeed, passed, item('update-feed', 'Secure update feed configured', 'pass', 'HTTPS update path is active.'));

  const matrix = Array.isArray(betaState?.matrix) ? betaState.matrix : [];
  const hardware = verifyHardwareEvidence(appPath, matrix, hardwareEvidenceRoot);
  push(!hardware.valid, blockers, item('verified-hardware', 'Physical flashing verification evidence incomplete', 'blocker', hardware.reason, 'Review private, controller-specific evidence: two independent matching full reads, successful Test Write, recovery proof and integrity hashes; never ship private BIN files in public releases.'));
  push(hardware.valid, passed, item('verified-hardware', 'Hardware verification evidence present', 'pass', hardware.reason));

  const attestChecks = [
    ['windowsCodeSigningVerified', 'Windows installer signing not attested', 'Obtain a code-signing certificate, sign the installer, and verify the signature on a clean Windows PC.'],
    ['privacyReviewed', 'Privacy documents not attested as reviewed', 'Review and finalize PRIVACY.md and data-retention language.'],
    ['thirdPartyRedistributionReviewed', 'Third-party redistribution terms not attested', 'Confirm redistribution terms for PCM Hammer, TunerPro, Universal Patcher, and bundled assets.'],
    ['incidentResponseReady', 'Incident/rollback process not attested', 'Document rollback, bad-update response, and tester communication procedures.'],
    ['cleanWindowsInstallVerified', 'Clean Windows install not attested', 'Install the signed build on a clean Windows machine and complete startup/update/uninstall checks.']
  ];
  for (const [key, label, action] of attestChecks) {
    if (releaseAttestation?.[key] === true) passed.push(item(key, label.replace(' not attested', ''), 'pass', 'Attested in RELEASE_ATTESTATION.json.'));
    else blockers.push(item(key, label, 'blocker', 'No reviewed release attestation is present.', action));
  }

  const automated = Number(betaProgress?.overall || 0);
  if (automated < 70) warnings.push(item('beta-progress', 'Evidence-weighted product readiness is still below 70%', 'warning', `Current readiness: ${automated}%`, 'Finish the lowest readiness areas shown in the Release Center.'));
  else passed.push(item('beta-progress', 'Evidence-weighted product readiness is at least 70%', 'pass', `${automated}%`));

  if (!exists(appPath, '.github/workflows/windows-public-beta.yml')) blockers.push(item('windows-ci', 'Windows release workflow missing', 'blocker', 'No Windows installer release workflow was found.', 'Add and validate a Windows release workflow.'));
  else passed.push(item('windows-ci', 'Windows release workflow present', 'pass', '.github/workflows/windows-public-beta.yml'));

  if (!exists(appPath, 'SUPPORT.md')) warnings.push(item('support-docs', 'Support documentation missing', 'warning', 'SUPPORT.md was not found.', 'Publish a support/escalation path.'));
  else passed.push(item('support-docs', 'Support documentation present', 'pass', 'SUPPORT.md'));

  const totalWeighted = passed.length + warnings.length + blockers.length;
  const score = totalWeighted ? Math.max(0, Math.min(100, Math.round(((passed.length + warnings.length * 0.45) / totalWeighted) * 100))) : 0;
  const fullLaunchReady = blockers.length === 0;
  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    version: version?.version || pkg?.version || '',
    channel: version?.channel || 'unknown',
    score,
    fullLaunchReady,
    state: fullLaunchReady ? 'ready-for-release-candidate' : 'blocked',
    summary: fullLaunchReady ? 'No full-launch blockers are currently detected.' : `${blockers.length} full-launch blocker${blockers.length === 1 ? '' : 's'} remain.`,
    blockers,
    warnings,
    passed,
    nextActions: [...blockers, ...warnings].slice(0, 8).map(entry => ({ id: entry.id, label: entry.label, action: entry.action }))
  };
}

module.exports = { buildLaunchReadiness };
