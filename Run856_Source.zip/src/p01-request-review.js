const crypto = require('crypto');
const { parseTuneRequest } = require('./goal-executor');
const { explicitRequestOsConflict } = require('./calibration-request-coverage');

function clean(value, max = 4000) {
  return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);
}
function normalizeController(value) {
  return clean(value, 40).toUpperCase().replace(/[^A-Z0-9]/g, '');
}
function numberNear(text, patterns) {
  for (const pattern of patterns) {
    const match = text.match(pattern);
    if (match && Number.isFinite(Number(match[1]))) return Number(match[1]);
  }
  return null;
}
function parseP01SafetyFacts(input = '') {
  const text = clean(input, 4000);
  const lower = text.toLowerCase();
  // Parse affirmative claims per clause. A matching word inside 'not verified',
  // 'not rated', or 'do not accept' is NOT proof of safety. When a clause is
  // ambiguous, fail closed and request a separate affirmative statement.
  const clauses = lower.split(/[.!?;,]+/).map(item => item.trim()).filter(Boolean);
  const negatedOrUncertain = /\b(?:not|never|no|without|unverified|unrated|unconfirmed|unknown|unsure|uncertain|unchecked|untested|cannot|can't|don't|didn't|isn't|aren't|won't|maybe|possibly)\b/i;
  // A declaration such as "brakes verified but unsafe" must never count as
  // proof for a high-speed or high-RPM proposal. Evaluate contradictory
  // mechanical-condition language in every relevant clause, not just a
  // negation immediately adjacent to "verified" or "rated". This remains
  // text-only triage, not physical inspection or certification.
  const adverseMechanicalCondition = /\b(?:unsafe|dangerous|inadequate|insufficient|defective|damaged|broken|failed|failing|worn|compromised|unfit|unserviceable)\b/i;
  const unfitClaim = clause => negatedOrUncertain.test(clause) || adverseMechanicalCondition.test(clause);
  const affirmative = (pattern, topic) => {
    const relevant = clauses.filter(clause => topic.test(clause));
    return relevant.length > 0 && relevant.every(clause => !unfitClaim(clause)) &&
      relevant.some(clause => pattern.test(clause));
  };
  const tireRatingPatterns = [
    /tire(?:s)?[^0-9]{0,28}(?:rated|rating|good|verified|capable)[^0-9]{0,15}(\d{2,3})\s*(?:mph|mi\/h)?/i,
    /(\d{2,3})\s*(?:mph|mi\/h)[^.!?]{0,30}tire(?:s)?/i
  ];
  const tireClauses = clauses.filter(clause => /\btires?\b/i.test(clause));
  const tireRatingMph = tireClauses.some(unfitClaim) ? null :
    (clauses.map(clause => numberNear(clause, tireRatingPatterns)).find(value => value != null) ?? null);
  return {
    text,
    valvetrainVerified: affirmative(/(?:valvetrain|valve\s*springs?|pushrods?|lifters?|rotating\s+assembly)[^.!?]{0,60}(?:verified|rated|safe|good|built|capable)|(?:verified|rated|safe|good|built|capable)[^.!?]{0,60}(?:valvetrain|valve\s*springs?|pushrods?|lifters?|rotating\s+assembly)/i, /valvetrain|valve\s*springs?|pushrods?|lifters?|rotating\s+assembly/i),
    tireRatingMph,
    drivelineVerified: affirmative(/(?:driveline|driveshaft|u-?joints?|differential|transmission\s+output)[^.!?]{0,50}(?:verified|rated|safe|good|built|capable)|(?:verified|rated|safe|good|built|capable)[^.!?]{0,50}(?:driveline|driveshaft|u-?joints?|differential|transmission\s+output)/i, /driveline|driveshaft|u-?joints?|differential|transmission\s+output/i),
    brakesVerified: affirmative(/(?:brakes?|wheel\s+bearings?|suspension|stability)[^.!?]{0,50}(?:verified|rated|safe|good|built|capable)|(?:verified|rated|safe|good|built|capable)[^.!?]{0,50}(?:brakes?|wheel\s+bearings?|suspension|stability)/i, /brakes?|wheel\s+bearings?|suspension|stability/i),
    closedCourse: affirmative(/closed[-\s]*course|controlled\s+(?:test|course|environment)|dyno\s+only|track\s+use/i, /closed[-\s]*course|controlled\s+(?:test|course|environment)|dyno\s+only|track\s+use/i),
    ghostCamRisksAccepted: affirmative(/(?:accept|understand|acknowledge)[^.!?]{0,70}(?:ghost|lopey|choppy|vacuum|brake\s*assist|drivability|emissions)|(?:ghost|lopey|choppy)[^.!?]{0,70}(?:risk|vacuum|brake\s*assist|drivability|emissions)[^.!?]{0,30}(?:accepted|understood|acknowledged)/i, /ghost|lopey|choppy|vacuum|brake[-\s]*assist|drivability|emissions/i)
  };
}
function speedMph(intent) {
  const target = Number(intent?.target);
  if (!Number.isFinite(target)) return null;
  return intent.unit === 'km/h' ? target * 0.621371 : target;
}
function safetyRequirements(parsed, confirmations) {
  const missing = [];
  for (const intent of parsed?.intents || []) {
    if (intent.type === 'rev-limit' && Number(intent.target) > 5800 && !confirmations.valvetrainVerified) {
      missing.push(`State that the valvetrain and rotating assembly are verified for ${Number(intent.target).toLocaleString()} RPM.`);
    }
    if (intent.type === 'speed-limit') {
      const mph = speedMph(intent);
      if (mph != null && mph > 130) {
        if (!(Number(confirmations.tireRatingMph) >= mph)) missing.push(`State the tire speed rating in MPH; it must be at least ${Math.ceil(mph)} MPH.`);
        if (!confirmations.drivelineVerified) missing.push('State that the driveshaft and driveline are verified for the requested speed.');
        if (!confirmations.brakesVerified) missing.push('State that brakes, bearings, suspension, and stability are verified.');
        if (!confirmations.closedCourse) missing.push('State that the high-speed setting is for closed-course or controlled testing.');
      }
    }
    if (intent.type === 'ghost-cam' && !confirmations.ghostCamRisksAccepted) {
      missing.push('State that you accept the ghost-idle vacuum, brake-assist, emissions, and drivability risks.');
    }
  }
  return [...new Set(missing)];
}
function reviewP01Request({ request = '', safetyFacts = '', activeProject = null } = {}) {
  if (!activeProject?.id) throw new Error('Create or activate a P01 project first.');
  if (normalizeController(activeProject.controller) !== 'P01') throw new Error('The active project is not identified as a P01.');
  const parsed = parseTuneRequest(request);
  if (!parsed.recognized) throw new Error('TunIQ could not identify a supported P01 action. Describe VATS, fan temperatures, RPM limiter, speed limiter, or a mapped ghost-cam request.');
  const confirmations = parseP01SafetyFacts(safetyFacts);
  const osIdentifier = clean(activeProject.os, 40);
  const unresolvedRequests = [...(parsed.unresolvedRequests || [])];
  if (explicitRequestOsConflict(parsed.text, osIdentifier)) {
    unresolvedRequests.push({
      type: 'os-request-conflict',
      label: 'Request OS conflicts with active project',
      status: 'needs-review',
      requirement: 'The request names an ECM operating-system ID that disagrees with the active project. Confirm the actual OS from trusted BIN/controller evidence and the matching definition; no VATS or fan calibration may be proposed from conflicting identifiers.'
    });
  }
  // A missing/placeholder OS must not make a request appear ready. A numeric
  // project identifier is still NOT proof that the BIN and XDF match that OS.
  const osIdentified = /^\d{7,9}$/.test(osIdentifier) && !/^0+$/.test(osIdentifier);
  const missingSafetyFacts = [
    ...(!osIdentified ? ['Identify the P01 controller operating-system (OS) ID from trusted ECM/BIN evidence; a missing or placeholder OS cannot establish an exact-OS calibration plan.'] : []),
    ...safetyRequirements(parsed, confirmations),
    ...unresolvedRequests.map(item => item.requirement)
  ];
  const canonical = JSON.stringify({
    projectId: activeProject.id,
    controller: 'P01',
    os: clean(activeProject.os, 40),
    request: parsed.text,
    safetyFacts: confirmations.text,
    intents: parsed.intents,
    unresolvedRequests,
    confirmations: {
      valvetrainVerified: confirmations.valvetrainVerified,
      tireRatingMph: confirmations.tireRatingMph,
      drivelineVerified: confirmations.drivelineVerified,
      brakesVerified: confirmations.brakesVerified,
      closedCourse: confirmations.closedCourse,
      ghostCamRisksAccepted: confirmations.ghostCamRisksAccepted
    }
  });
  const requestFingerprint = crypto.createHash('sha256').update(canonical).digest('hex');
  return {
    type: 'p01-request-review',
    projectId: activeProject.id,
    projectName: activeProject.name || 'P01 Project',
    controller: 'P01',
    os: clean(activeProject.os, 40) || null,
    requestText: parsed.text,
    safetyFactsText: confirmations.text,
    parsed,
    unresolvedRequests,
    confirmations,
    missingSafetyFacts,
    ready: missingSafetyFacts.length === 0,
    // Request triage is not proof that a matching BIN/XDF or physical ECM exists.
    // Keep this separate from `ready`, which only describes request review.
    calibrationEvidenceVerified: false,
    readyForCalibration: false,
    requestFingerprint,
    protections: [
      'Works only against the active P01 project and its own protected original.',
      'Requires an exact OS-matched writable definition and never guesses addresses.',
      'Creates a numbered working revision and never overwrites the protected original.',
      'Does not write the PCM; Test Write and real write remain separate hardware steps.',
      'Unrecognized or unimplemented parts of a combined request block the entire quick-service plan.'
    ]
  };
}

module.exports = { parseP01SafetyFacts, reviewP01Request, safetyRequirements, normalizeController };
