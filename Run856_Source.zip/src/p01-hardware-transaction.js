const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
// A missing ledger is normal on first launch. A damaged/unreadable ledger is
// NOT an empty ledger: silently resetting it could lose evidence that a child
// still owns a COM port. Require operator recovery instead of reopening.
// A redirected Devices directory is not a trustworthy COM ownership ledger
// location. A symlink/junction could point to another project's stale state
// even when the ledger itself is a single-link regular file. This is a
// defense-in-depth check, not an atomic cross-process filesystem lock.
function assertLedgerParent(file) {
  // The immediate Devices directory can be ordinary while an ancestor
  // (including dataRoot itself) is a symlink/junction into another project.
  // Inspect the entire path, including the volume root. Missing ancestors
  // are permitted only for legitimate first-launch directory creation.
  const directory = path.resolve(path.dirname(file));
  const volumeRoot = path.parse(directory).root;
  const segments = directory.slice(volumeRoot.length).split(path.sep).filter(Boolean);
  let current = volumeRoot;
  let complete = true;
  for (const segment of ['', ...segments]) {
    if (segment) current = path.join(current, segment);
    let entry;
    try { entry = fs.lstatSync(current); }
    catch (error) {
      if (error.code === 'ENOENT') { complete = false; continue; }
      throw new Error(`PCM Hammer transaction ledger parent unreadable; COM admission blocked: ${error.message}`);
    }
    if (!entry.isDirectory() || entry.isSymbolicLink()) {
      throw new Error('PCM Hammer transaction ledger parent redirected or invalid; COM admission blocked.');
    }
  }
  return complete;
}
// A crashed atomic writer can leave a *newer* temporary ownership record
// beside an old, valid ledger (or with no ledger at all). Never silently trust
// that older state or remove the orphan. Preserve both for manual recovery.
function assertNoInterruptedLedgerUpdate(file) {
  assertLedgerParent(file);
  const directory = path.dirname(file);
  const prefix = `${path.basename(file)}.`;
  let entries;
  try { entries = fs.readdirSync(directory); }
  catch (error) {
    if (error.code === 'ENOENT') entries = [];
    else throw new Error(`PCM Hammer transaction ledger directory unreadable; COM admission blocked: ${error.message}`);
  }
  if (entries.some(name => name.startsWith(prefix) &&
      /^\d+\.[a-f0-9]{16}\.tmp$/.test(name.slice(prefix.length)))) {
    throw new Error('PCM Hammer transaction ledger interrupted update detected; COM admission blocked pending manual recovery.');
  }
}
function readLedger(file) {
  assertNoInterruptedLedgerUpdate(file);
  let raw;
  let fd;
  try {
    // lstat, rather than stat/readFile, distinguishes a genuinely absent
    // ledger from a dangling symlink. Never trust a redirected or hardlinked
    // ownership record when deciding whether a physical COM port is free.
    let entry;
    try { entry = fs.lstatSync(file); }
    catch (error) {
      if (error.code === 'ENOENT') {
        // An interrupted writer may have appeared after the first directory
        // scan but before the missing-ledger lookup. Deny stale admission.
        assertNoInterruptedLedgerUpdate(file);
        return null;
      }
      throw error;
    }
    if (!entry.isFile() || entry.isSymbolicLink() || entry.nlink !== 1) {
      throw new Error('ownership ledger is not a single-link regular file');
    }
    // O_NOFOLLOW closes the symlink-swap gap on systems that support it.
    // Compare the opened file with the lstat result as an additional check,
    // including on Windows where O_NOFOLLOW may not be available.
    fd = fs.openSync(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
    const opened = fs.fstatSync(fd);
    if (!opened.isFile() || opened.nlink !== 1 ||
        opened.dev !== entry.dev || opened.ino !== entry.ino) {
      throw new Error('ownership ledger changed or was redirected during open');
    }
    raw = fs.readFileSync(fd, 'utf8');
    // Recheck after reading: an interrupted writer may have left a new temp
    // record between the first scan and the ledger read. This narrows (but
    // does not eliminate) the cross-process admission race.
    assertNoInterruptedLedgerUpdate(file);
  } catch (error) {
    throw new Error(`PCM Hammer transaction ledger unreadable; COM admission blocked: ${error.message}`);
  } finally {
    if (fd !== undefined) fs.closeSync(fd);
  }
  try {
    const value = JSON.parse(raw);
    // JSON can be syntactically valid but still be a torn/incomplete ownership
    // record. Do not merge missing ownership fields with blank() defaults:
    // that would turn an unknown active child into a fresh COM preparation.
    const states = new Set([
      'idle', 'preparing', 'settling', 'ready-to-open', 'process-running',
      'process-closed', 'controlled-reopen', 'operation-complete', 'stopped'
    ]);
    if (!value || Array.isArray(value) || typeof value !== 'object' ||
        value.version !== 1 || !states.has(value.state) ||
        !Array.isArray(value.history) ||
        !['transactionId', 'projectId', 'port', 'currentOperation', 'updatedAt']
          .every(key => typeof value[key] === 'string') ||
        !Number.isSafeInteger(value.preparationSequence) || value.preparationSequence < 0 ||
        !Number.isSafeInteger(value.lastProcessStartedPreparationSequence) ||
        value.lastProcessStartedPreparationSequence < 0 ||
        value.lastProcessStartedPreparationSequence > value.preparationSequence ||
        (value.state !== 'idle' &&
         (!value.transactionId || value.preparationSequence < 1 ||
          (value.state !== 'stopped' && !value.currentOperation))) ||
        (['process-running', 'process-closed', 'operation-complete', 'controlled-reopen']
          .includes(value.state) &&
         value.lastProcessStartedPreparationSequence !== value.preparationSequence)) {
      throw new Error('invalid or incomplete ownership ledger structure');
    }
    return value;
  } catch (error) {
    throw new Error(`PCM Hammer transaction ledger invalid; COM admission blocked: ${error.message}`);
  }
}
// Never truncate the live ownership record. A failed rename preserves the
// previous JSON AND the newly written temporary record. The orphan scanner
// then blocks COM admission until an operator reconciles the two records.
function writeJson(file, value) {
  assertLedgerParent(file);
  ensureDir(path.dirname(file));
  assertLedgerParent(file);
  const temp = `${file}.${process.pid}.${crypto.randomBytes(8).toString('hex')}.tmp`;
  let fd;
  try {
    fd = fs.openSync(temp, 'wx', 0o600);
    fs.writeFileSync(fd, JSON.stringify(value, null, 2), 'utf8');
    fs.fsyncSync(fd);
    fs.closeSync(fd); fd = null;
    assertLedgerParent(file); // Do not replace a redirected parent ledger.
    fs.renameSync(temp, file);
  } finally {
    if (fd !== undefined && fd !== null) fs.closeSync(fd);
    // Do not delete a failed or incomplete atomic write. It may contain the
    // only evidence of a newer COM owner; the next read must fail closed.
    // A successful rename has already removed the temporary path.
  }
}
function clean(value, max = 240) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max); }
function normalizePort(value) { const match = clean(value, 40).toUpperCase().match(/^COM\d+$/); return match ? match[0] : ''; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, Math.max(0, Number(ms) || 0))); }

class P01HardwareTransactionManager {
  constructor(options = {}) {
    this.dataRoot = options.dataRoot || (() => process.cwd());
    this.platform = options.platform || process.platform;
    this.now = options.now || (() => Date.now());
    this.sleep = options.sleep || sleep;
    this.interOperationCooldownMs = Math.max(0, Number(options.interOperationCooldownMs ?? (this.platform === 'win32' ? 4000 : 15)));
    this.reopenRecoveryDelayMs = Math.max(0, Number(options.reopenRecoveryDelayMs ?? (this.platform === 'win32' ? 5000 : 20)));
  }

  file() { return path.join(this.dataRoot(), 'Devices', 'p01-hardware-transaction.json'); }
  blank() {
    return {
      version: 1,
      transactionId: '',
      projectId: '',
      controller: '',
      os: '',
      port: '',
      state: 'idle',
      currentOperation: '',
      lastSuccessfulOperation: '',
      lastSessionId: '',
      lastWorkflowAttemptId: '',
      recoveryCount: 0,
      preparationSequence: 0,
      lastProcessStartedPreparationSequence: 0,
      openedAt: null,
      processStartedAt: null,
      processClosedAt: null,
      lastStopCode: '',
      lastCommunicationStarted: null,
      updatedAt: new Date(this.now()).toISOString(),
      history: []
    };
  }
  load() { return { ...this.blank(), ...(readLedger(this.file()) || {}) }; }
  save(patch = {}, event = null) {
    const current = this.load();
    const history = Array.isArray(current.history) ? current.history.slice(-39) : [];
    if (event) history.push({ at: new Date(this.now()).toISOString(), ...event });
    const next = { ...current, ...patch, history, updatedAt: new Date(this.now()).toISOString() };
    writeJson(this.file(), next);
    return next;
  }
  begin({ projectId = '', controller = 'P01', os = '', port = '', operation = '', sessionId = '', workflowAttemptId = '' } = {}) {
    const normalizedPort = normalizePort(port);
    const current = this.load();
    // Never overwrite a running child's ownership record with a new preparation.
    if (current.state === 'process-running') {
      throw new Error('PCM Hammer transaction denied: previous child still owns the COM port.');
    }
    const sameTransaction = Boolean(
      current.transactionId &&
      current.projectId === clean(projectId, 160) &&
      current.port === normalizedPort
    );
    const transactionId = sameTransaction ? current.transactionId : `${this.now()}-${clean(projectId || 'p01', 80)}-${normalizedPort || 'auto'}`;
    return this.save({
      transactionId,
      projectId: clean(projectId, 160),
      controller: clean(controller || 'P01', 40).toUpperCase(),
      os: clean(os, 40),
      port: normalizedPort,
      state: 'preparing',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      lastWorkflowAttemptId: clean(workflowAttemptId, 160),
      recoveryCount: sameTransaction && current.currentOperation === operation ? Number(current.recoveryCount || 0) : 0,
      preparationSequence: sameTransaction ? Number(current.preparationSequence || 0) + 1 : 1,
      // New preparations must not inherit an earlier child-start proof.
      lastProcessStartedPreparationSequence: 0,
      openedAt: sameTransaction ? current.openedAt : new Date(this.now()).toISOString()
    }, { type: 'operation-preparing', operation: clean(operation, 80), port: normalizedPort });
  }
  requiredCooldown(port = '') {
    const current = this.load();
    const normalizedPort = normalizePort(port);
    if (!normalizedPort || current.port !== normalizedPort || !current.processClosedAt) return 0;
    const closedAt = Date.parse(current.processClosedAt);
    if (!Number.isFinite(closedAt)) return 0;
    return Math.max(0, this.interOperationCooldownMs - (this.now() - closedAt));
  }
  async settleBeforeOpen(port = '', onWait = null) {
    const normalizedPort = normalizePort(port);
    const prior = this.load();
    // A stale timer or concurrent caller must not grant COM access to a new
    // project/operation, even if the same project and COM port were reused.
    // A missing pinned Windows COM port is not a wildcard: do not accept
    // a later substitution or mark a no-port operation ready for hardware.
    // Only the explicit offline test platform uses a portless mock fixture.
    const offlineFixture = this.platform === 'test' && !prior.port && !normalizedPort;
    if (!prior.transactionId || prior.state !== 'preparing' ||
        (!offlineFixture && (!normalizedPort || prior.port !== normalizedPort)) ||
        !Number.isSafeInteger(prior.preparationSequence) || prior.preparationSequence < 1) {
      throw new Error('PCM Hammer cooldown denied: no matching prepared transaction.');
    }
    const waitMs = this.requiredCooldown(normalizedPort);
    if (waitMs > 0) {
      this.save({ state: 'settling' }, { type: 'inter-operation-cooldown', port: normalizedPort, waitMs });
      if (typeof onWait === 'function') onWait(waitMs);
      await this.sleep(waitMs);
    }
    const current = this.load();
    if (current.transactionId !== prior.transactionId ||
        current.preparationSequence !== prior.preparationSequence ||
        current.projectId !== prior.projectId ||
        current.currentOperation !== prior.currentOperation ||
        current.port !== prior.port ||
        current.state !== (waitMs > 0 ? 'settling' : 'preparing')) {
      throw new Error('PCM Hammer cooldown cancelled: transaction changed during COM handoff.');
    }
    this.save({ state: 'ready-to-open', port: normalizedPort || current.port },
      { type: 'port-ready-to-open', port: normalizedPort, waitedMs: waitMs });
    return waitMs;
  }
  // Read-only CLI admission is checked synchronously immediately before
  // spawn(). A previous child, stale transaction, or changed COM port must
  // not be overwritten by the next launch. This is not hardware proof.
  assertCanStartProcess({ port = '', operation = '', sessionId = '', transactionId = null, preparationSequence = null } = {}) {
    const current = this.load();
    const requestedPort = normalizePort(port);
    const requestedOperation = clean(operation, 80);
    const requestedSession = clean(sessionId, 160);
    // Legacy synthetic Test Write recovery fixtures deliberately model COM
    // discovery. They are not physical writes and must never bypass the real
    // Windows read-only admission path.
    if (this.platform === 'test' && requestedOperation === 'testWrite' &&
        current.currentOperation === 'testWrite' &&
        ['ready-to-open', 'process-closed'].includes(current.state)) return true;
    const firstAttempt = current.state === 'ready-to-open';
    const retryAfterClose = current.state === 'process-closed' &&
      Boolean(current.processClosedAt) &&
      current.lastProcessStartedPreparationSequence === current.preparationSequence &&
      current.lastCommunicationStarted === false &&
      (!current.lastSessionId || current.lastSessionId === requestedSession);
    // The caller that prepared the COM handoff must still own THIS preparation.
    // A second begin() may reuse the same project, COM port and operation,
    // but it must not authorize a stale first caller to spawn PCM Hammer.
    // Tokens are mandatory for real CLI admission. A caller that omits them
    // must not inherit whichever preparation currently happens to be ready.
    // Only the explicit synthetic test platform may use legacy tokenless
    // fixtures; production flash.js passes both captured values to this gate.
    if (this.platform !== 'test' &&
        (typeof transactionId !== 'string' || !transactionId ||
         !Number.isSafeInteger(preparationSequence) || preparationSequence < 1)) {
      throw new Error('PCM Hammer spawn denied: missing prepared transaction identity or sequence.');
    }
    if ((transactionId !== null && current.transactionId !== transactionId) ||
        (preparationSequence !== null && current.preparationSequence !== preparationSequence)) {
      throw new Error('PCM Hammer spawn denied: prepared transaction was superseded.');
    }
    if (!current.transactionId || !requestedPort || current.port !== requestedPort ||
        !requestedOperation || current.currentOperation !== requestedOperation ||
        !Number.isSafeInteger(current.preparationSequence) || current.preparationSequence < 1 ||
        (!firstAttempt && !retryAfterClose)) {
      throw new Error('PCM Hammer spawn denied: COM port is not exclusively admitted for this transaction.');
    }
    return true;
  }
  markProcessStarted({ port = '', operation = '', sessionId = '', workflowAttemptId = '' } = {}) {
    const current = this.load();
    // A duplicate child-start callback must never rewrite a live COM owner.
    // Production callers additionally invoke assertCanStartProcess before spawn.
    const syntheticTestWrite = this.platform === 'test' && current.currentOperation === 'testWrite';
    // A late child-start callback is not permission to reopen a completed
    // Full Read or a preparation stopped before spawn. Only begin() plus
    // admission can authorize a new attempt; keep final evidence immutable.
    if (!current.transactionId ||
        ['process-running', 'operation-complete', 'stopped'].includes(current.state) ||
        (!syntheticTestWrite && normalizePort(port) && normalizePort(port) !== current.port) ||
        (clean(operation, 80) && current.currentOperation !== clean(operation, 80))) {
      throw new Error('PCM Hammer child-start denied: active or mismatched COM transaction owner.');
    }
    return this.save({
      lastProcessStartedPreparationSequence: current.preparationSequence,
      port: normalizePort(port) || this.load().port,
      state: 'process-running',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      lastWorkflowAttemptId: clean(workflowAttemptId, 160),
      processStartedAt: new Date(this.now()).toISOString(),
      processClosedAt: null,
      lastStopCode: '',
      lastCommunicationStarted: null
    }, { type: 'pcmhammer-process-started', operation: clean(operation, 80), port: normalizePort(port) });
  }
  markProcessClosed({ port = '', operation = '', sessionId = '', success = false, stopCode = '', communicationStarted = null } = {}) {
    // A delayed `close` event from an earlier CLI attempt must never replace
    // the active project's COM owner, operation, or session. This can happen
    // after asynchronous handoff/recovery; close is evidence for its own child,
    // not authority to mutate a newer transaction. Fail closed before save().
    const current = this.load();
    const closingPort = normalizePort(port);
    const closingOperation = clean(operation, 80);
    const closingSession = clean(sessionId, 160);
    // A close event is evidence only for a child started by the current
    // preparation. An unstarted or replaced child cannot release COM ownership.
    const startedThisPreparation = Number.isSafeInteger(current.preparationSequence) &&
      current.preparationSequence > 0 &&
      current.lastProcessStartedPreparationSequence === current.preparationSequence;
    // Once the finalizer has completed an operation, a delayed duplicate
    // close is not allowed to rewrite its stop code, timestamps or history.
    // Only a running child or its first closed state may be finalized.
    const childCanClose = ['process-running', 'process-closed'].includes(current.state);
    if (!current.transactionId || !startedThisPreparation ||
        (closingPort && closingPort !== current.port) ||
        (closingOperation && current.currentOperation && closingOperation !== current.currentOperation) ||
        // A missing session ID is NOT a wildcard for an identified child.
        (current.lastSessionId && closingSession !== current.lastSessionId)) {
      throw new Error('PCM Hammer process close denied: stale or mismatched COM transaction owner or missing child-start proof.');
    }
    // The close handler records the child's exit, then the finalizer may
    // record the verified outcome for that SAME child. A delayed duplicate
    // callback must never demote an already completed read or erase evidence
    // that communication with the PCM began. Either change could manufacture
    // the pre-communication failure proof used by controlled COM reopening.
    if ((current.state === 'operation-complete' && !success) ||
        (['process-closed', 'operation-complete'].includes(current.state) &&
         current.lastCommunicationStarted === true && communicationStarted !== true)) {
      throw new Error('PCM Hammer process close denied: completion or communication evidence cannot be downgraded.');
    }
    // The first failed close is the authoritative child-exit evidence.
    // Another failed callback for the same child must not replace a syntax,
    // cancellation, or runtime failure with an adapter-open failure that
    // would incorrectly authorize controlled COM reopening. The finalizer
    // may still promote this closed child to success after independent proof.
    if (current.state === 'process-closed' && !success) {
      throw new Error('PCM Hammer process close denied: first failed child-close evidence is immutable.');
    }
    if (!childCanClose) {
      throw new Error('PCM Hammer process close denied: finalized operation cannot be closed again.');
    }
    return this.save({
      port: closingPort || current.port,
      state: success ? 'operation-complete' : 'process-closed',
      currentOperation: clean(operation, 80),
      lastSessionId: clean(sessionId, 160),
      processClosedAt: new Date(this.now()).toISOString(),
      lastStopCode: clean(stopCode, 120),
      lastCommunicationStarted: typeof communicationStarted === 'boolean' ? communicationStarted : null,
      lastSuccessfulOperation: success ? clean(operation, 80) : this.load().lastSuccessfulOperation,
      recoveryCount: success ? 0 : Number(this.load().recoveryCount || 0)
    }, { type: 'pcmhammer-process-closed', operation: clean(operation, 80), port: normalizePort(port), success: Boolean(success), stopCode: clean(stopCode, 120) });
  }
  // A controlled reopen is exclusively for a read whose CLI child has
  // confirmed close, before any PCM communication. Caller-provided diagnostics
  // must agree with the persisted close record; an unknown flag fails closed.
  canAttemptControlledReopen({ port = '', operation = '', communicationStarted = null, stopCode = '' } = {}) {
    const current = this.load();
    const normalizedPort = normalizePort(port);
    const normalizedOperation = clean(operation, 80);
    const normalizedStop = clean(stopCode, 120);
    return Boolean(
      current.transactionId && normalizedPort && current.port === normalizedPort &&
      current.state === 'process-closed' && current.processClosedAt &&
      Number.isSafeInteger(current.preparationSequence) && current.preparationSequence > 0 &&
      current.lastProcessStartedPreparationSequence === current.preparationSequence &&
      current.currentOperation === normalizedOperation &&
      normalizedOperation === 'read' &&
      communicationStarted === false && current.lastCommunicationStarted === false &&
      normalizedStop && current.lastStopCode === normalizedStop &&
      ['adapter-open-timeout', 'adapter-open-failed', 'adapter-locked', 'adapter-handoff-failed'].includes(normalizedStop) &&
      Number.isSafeInteger(current.recoveryCount) && current.recoveryCount >= 0 && current.recoveryCount < 1
    );
  }
  async controlledReopen({ port = '', operation = '', communicationStarted = null, stopCode = '', onWait = null } = {}) {
    if (!this.canAttemptControlledReopen({ port, operation, communicationStarted, stopCode })) {
      throw new Error('Controlled PCM Hammer reopen denied: no matching closed, pre-communication read attempt.');
    }
    const normalizedPort = normalizePort(port);
    const normalizedOperation = clean(operation, 80);
    const prior = this.load();
    const nextCount = prior.recoveryCount + 1;
    this.save({ state: 'controlled-reopen', recoveryCount: nextCount, processClosedAt: new Date(this.now()).toISOString() }, {
      type: 'controlled-same-port-reopen', port: normalizedPort, operation: normalizedOperation,
      stopCode: clean(stopCode, 120), waitMs: this.reopenRecoveryDelayMs
    });
    if (typeof onWait === 'function') onWait(this.reopenRecoveryDelayMs);
    await this.sleep(this.reopenRecoveryDelayMs);
    // A new project, operation, or session may have started during Bluetooth
    // cooldown. Never let the stale timer authorize another COM open.
    const current = this.load();
    if (current.transactionId !== prior.transactionId || current.state !== 'controlled-reopen' ||
        current.port !== normalizedPort || current.currentOperation !== normalizedOperation ||
        current.recoveryCount !== nextCount) {
      throw new Error('Controlled PCM Hammer reopen cancelled: transaction changed during cooldown.');
    }
    this.save({ state: 'ready-to-open' }, { type: 'controlled-reopen-ready', port: normalizedPort, operation: normalizedOperation });
    return { port: normalizedPort, waitMs: this.reopenRecoveryDelayMs, recoveryCount: nextCount };
  }
  snapshot() { return this.load(); }
  reset(reason = 'manual reset') { return this.save(this.blank(), { type: 'transaction-reset', reason: clean(reason, 240) }); }
}

module.exports = { P01HardwareTransactionManager, normalizePort };
