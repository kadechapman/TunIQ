'use strict';

// Commissioned XDF coordinates are security-sensitive metadata. Number(null),
// Number(''), Number(false), and Number([]) all become zero, which can turn a
// malformed saved map into an apparently commissioned first calibration cell.
// Accept only nonnegative safe integers or canonical decimal integer strings.
// This validates coordinates, not the provenance of the XDF/ECM definition.
function commissionedCellIndex(value) {
  if (typeof value === 'number') return Number.isSafeInteger(value) && value >= 0 ? value : null;
  if (typeof value !== 'string' || !/^(?:0|[1-9][0-9]*)$/.test(value)) return null;
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) ? parsed : null;
}

module.exports = { commissionedCellIndex };
