# Development checkpoint: pre-spawn COM admission (October 17, 2026)

This is a source-only, unpromoted `1.9.0-beta.108` development checkpoint. It does not verify physical OBDLink/PCM hardware or Windows CLI/kernel compatibility. **No ECU writes or Test Writes were performed.**

## Reproduced defect

The previous transaction manager accepted a second `markProcessStarted` call while a PCM Hammer child was recorded as running. A COM4/read owner could be replaced by a fabricated COM9/readProperties owner. In `src/flash.js`, child spawning also preceded transaction child-start bookkeeping, leaving no authoritative pre-spawn transaction admission check.

## Correction

- `P01HardwareTransactionManager.assertCanStartProcess` requires a matching prepared, pinned COM port and operation before a real CLI spawn. The initial attempt requires `ready-to-open`; subsequent same-session attempts require a confirmed child close from the current preparation and explicit evidence that PCM communication did not start.
- `markProcessStarted` rejects duplicate active-child start events and mismatched COM/operation records without changing the ledger.
- `FlashManager.launchProfile` checks admission **before** `spawn`, recording `pcmhammer-spawn-admission-denied` without launching a child if admission fails. It deliberately does not mark a foreign child closed or claim COM ownership is idle. Manual recovery may be required.
- The existing `platform: 'test'` **synthetic Test Write** fixture retains its historical simulated COM discovery behavior. This exception does not apply to Windows hardware, and is not authorization for physical writes. Production restricted beta continues to deny write operations before CLI invocation.

## Qualification still required

The Linux offline regression suite is not a Windows or hardware qualification. On a clean Windows system, verify pinned CLI SHA-256, kernel file discovery, exclusive COM handle ownership, child start/exit and error events, interrupted Full Read quarantine, and two independent matching read hashes using a supervised read-only protocol. Do not promote this checkpoint to a public installer. Licensing, dependency lockfile, code signing, privacy, update-feed security, and incident recovery remain blocked.
