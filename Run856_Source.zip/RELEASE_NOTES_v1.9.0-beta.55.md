# TunIQ v1.9.0-beta.55 — Source-only checkpoint

- Rejects placeholder, malformed, stale, symlinked, and mismatched npm v2/v3 dependency lockfiles from the public-release gate.
- Requires exact direct dependency versions with HTTPS-resolved SHA-512 integrity metadata. This is a conservative policy for TunIQ's current registry-only dependencies, not an npm dependency graph validator.
- Includes `package-lock.json` and `npm-shrinkwrap.json` in the source-only snapshot fingerprint so any changes invalidate stale readiness evidence.
- Adds regression coverage for absent, placeholder, stale and insecure direct-dependency entries and lockfile snapshot drift.
- **No package-lock.json has been generated.** No npm installation, Windows installer, physical ECU read, Test Write, PCM write, or flash was performed. The dependency-lock launch blocker remains active.
- Not READY FOR USER TESTING or READY FOR PUBLIC RELEASE. Further Windows build, clean install, hardware evidence, licensing, signing, privacy, update-feed and redistribution review are required.
