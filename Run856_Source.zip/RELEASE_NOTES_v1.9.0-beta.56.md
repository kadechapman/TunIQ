# TunIQ v1.9.0-beta.56 — Merged Dependency Lock and Win32 Read Path Guards

**Source-only checkpoint, not a public release or verified runnable Windows beta.**

## Reconciliation

An independently developed beta.55 Dependency Lockfile Launch Gate appeared in the Library while a separate Win32 read-output path fix was being packaged. Beta.56 is based on that newer verified beta.55 source and preserves its `src/launch-readiness.js`, `tools/launch-snapshot.js`, and associated regression tests. The Win32 filename fix and its tests were re-applied and verified against that baseline.

## Read-only Full Read destination safety

Rejects reserved superscript-digit COM/LPT device names, `CONIN$` and `CONOUT$` aliases, and invalid Win32 filename characters (`<`, `>`, `"`, `|`, `?`, `*`, control characters) in output filenames and parent folders. Existing protections against overwriting an existing output, NTFS alternate streams, trailing-dot/space aliases and symlink parents remain.

The new regression failed against beta.55 on `COM¹.bin` before correction and passed afterward. These are Linux-based local filesystem tests, not native Windows or physical hardware verification. The path checks are not an atomic reservation.

## Launch gate and release status

The npm lockfile validation and snapshot freshness gate from beta.55 are preserved. No genuine lockfile could be generated (`ENOTCACHED` offline, `EAI_AGAIN` online). Nine public launch blockers remain. No PCM Test Write, calibration write, full write, flash, public release, or physical ECU read occurred. Windows installation and physical read-only qualification remain outstanding.
