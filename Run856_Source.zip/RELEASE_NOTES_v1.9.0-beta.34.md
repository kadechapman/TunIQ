# TunIQ 1.9.0-beta.34 — Read Output Link Integrity Guard

Source-only safety checkpoint; **not a public release or Windows hardware qualification**.

- Reject symlink and hardlink Full Read outputs, even when they point to a complete 512 KiB original and the CLI reports success.
- Hash through a single file descriptor and reject files that change identity, size, or metadata during validation.
- Retain beta.33 zero-byte retry guard and beta.32 preflight output protection.
- Add regression tests for legitimate independent files, symlink/hardlink spoofing, and missing output.
- No physical PCM Test Write or PCM write performed. No claim of Windows hardware validation.
- Remaining launch gates include a trusted dependency lockfile, licensing, update feed, physical read-only hardware evidence, signing, privacy, redistribution review, incident response, and clean Windows install.
