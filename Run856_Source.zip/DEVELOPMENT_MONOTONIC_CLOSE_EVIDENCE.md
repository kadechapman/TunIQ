# Beta.108 development checkpoint: monotonic PCM Hammer close evidence

**Scope:** offline source-only change. No ECU/OBDLink/COM hardware, PCM Test Write, ECU write, or flash performed.

## Reproduced failure

In the preceding Win32 read-path checkpoint, `P01HardwareTransactionManager.markProcessClosed()` accepted a second, contradictory close record from the same session. After a successful read had been recorded as `operation-complete` with `lastCommunicationStarted: true`, a later failed-close record with `stopCode: adapter-open-failed` and `communicationStarted: false` changed the ledger to `process-closed`. `canAttemptControlledReopen()` then returned `true`. A failed read whose first close proved communication had begun was similarly reclassified as safe to reopen.

These are transaction-ledger inconsistencies, not observed physical ECU events. Both were reproduced with offline Node simulations against the previous source archive.

## Change

`src/p01-hardware-transaction.js` now rejects a contradictory subsequent close that either:

1. demotes an already completed operation to failure; or
2. downgrades previously recorded `communicationStarted: true` evidence to `false` or unknown.

Rejected callbacks leave the transaction state and history unchanged. A normal finalizer may still promote a previously closed child to `operation-complete` when its communication evidence remains consistent. Existing pre-spawn COM admission, port pinning, and no-automatic-write restrictions are preserved.

`tests/p01-hardware-transaction-simulations.js` adds eight offline assertions for the two unsafe sequences, unchanged-ledger proof, reopen denial, and a valid completion promotion.

## Limitations and follow-up

The transaction ledger is a file-based software record, not a physical COM lock or a substitute for verified Windows process ownership. The normal close handler and finalizer can both record close outcomes; their state transitions should receive further fault-injection tests, including restart and interrupted Full Read recovery. A clean Windows install, signed release, dependency lockfile, independent matching Full Reads, and physical OBDLink evidence remain required. No public release is authorized by this checkpoint.
