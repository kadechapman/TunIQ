# TunIQ v1.9.0-beta.103 — Reconciled Full Read CRC Integrity Guard

**Source-only development checkpoint. Not ready for user testing or public release.**

## Baseline and changes
- Reconciled onto the newest verified Library beta.102 (Kernel Transfer Failure Evidence Guard), not an outdated beta.101 snapshot.
- `src/pcmhammer.js`: retains beta.102 kernel upload/load/execute failure rejection; additionally treats explicit CRC/checksum/hash mismatch, invalid or failure diagnostics in Full Read CLI output as `read-integrity-failed`, even when the CLI exits 0 and prints a success footer.
- `tests/pcmhammer-exit-proof-simulations.js`: four synthetic CRC/checksum/hash negative cases, one positive control, and complete-size BIN admission rejection, alongside beta.102 kernel-transfer regressions.
- Existing COM ownership, read cancellation, output quarantine, identity admission and restricted read-only controls remain unchanged.

## Scope and limitations
- No physical ECU communication, Test Write, ECU write or flash was initiated.
- Offline CLI strings and filesystem simulations cannot verify physical OBDLink/PCM Hammer Windows interoperability or hardware recovery.
- A log diagnostic parser does not independently validate exact-OS ECU calibration checksums.
- A genuine dependency lockfile, clean Windows installation, hardware qualification, licensing, secure updates, privacy, signing, redistribution and recovery documentation remain release blockers.
