# TunIQ v1.9.0-beta.18 — PCM Hammer Exclusive OBDLink Device Lease

## Connection path replaced

- Once Read Properties proves COM4 and the OBDLink, PCM Hammer receives exclusive ownership of that port for the remaining protected P01 steps.
- TunIQ no longer opens, probes, disconnects, or releases the proven port before Full Read 1, Full Read 2, or Test Write.
- Proven OBDLink/STN/ELM-family sessions are launched with a typed PCM Hammer device specification such as `COM4:elm` instead of repeating generic serial-device detection.
- The visible project port remains COM4 while technical diagnostics separately record the device specification.
- An explicitly unsupported type suffix can fall back once to plain COM4; no alternate COM scan is permitted.
- PCM Hammer debug output is retained when supported so a remaining physical failure has a useful underlying exception.

## Retained behavior

- Completed P01 Properties and OS evidence are preserved.
- Startup ready-to-resume reconciliation remains enabled.
- Full-read byte progress and watchdog remain enabled.
- Proven-port project isolation remains enforced.
- AI incident replay, learning memory, and safe repair remain included.
- Dual-read, exact-XDF, Test Write, recovery, and actual-write safety gates remain unchanged.

## Hardware truth boundary

The source and packaged archive were tested with simulated PCM Hammer processes, typed-device arguments, project persistence, and the full retained recovery suite. A physical Full Read 1 or Test Write is not claimed until the user confirms it on the bench setup.
