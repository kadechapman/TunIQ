# Run96 — hardware-free Windows GUI preview (not the full TunIQ app)

This checkpoint introduces a **strictly isolated Electron UI preview** for the 1.9.0-beta.108 renderer. It is intended to make a real Windows GUI executable possible without exposing any PCM/ECU device functionality. Source-level and offline fixture checks alone do not certify successful Electron packaging or startup.

## Building on an actual Windows machine

Requirements: Windows 10/11 x64, Node.js 20+ with npm, working access to the official npm registry and Electron/electron-builder distribution endpoints, adequate disk space, and an ordinary non-administrator terminal. Disconnect all vehicle hardware. Extract this source checkpoint to a local folder.

Run in PowerShell from the extracted source folder:

```powershell
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

The script creates a disposable copy, runs the syntax/source safety checks and full offline simulated test suite, resolves a genuine npm-generated lockfile there (lifecycle scripts disabled while generating it), validates that lockfile, then runs `npm ci` and the isolated Electron renderer smoke test. It then creates a **separate Electron project with exactly seven reviewed source files**, smoke-tests that staged project, builds a **Windows unpacked directory** (not an installer), and smoke-tests the packaged `.exe`. It rejects failures and timeouts. The validated candidate lockfile is saved immediately for review even if later checks fail. Only if the full packaging smoke passes does it copy the preview under `dev-build-output/Run96-Offline-UI-Preview/` and a candidate lockfile under `dev-build-output/package-lock.candidate.json`.

The preview executable displays `OFFLINE UI PREVIEW — ALL ECU OPERATIONS DISABLED — NOT FOR VEHICLE USE` and deliberately provides exactly five synthetic bootstrap IPC handlers. The renderer does **not** receive a production main process, COM-port logic, PCM Hammer, flash logic, ECU write functionality, updates, or real vehicle data. Other preload IPC calls have no matching handler and must reject. The package has no runtime npm dependencies other than Electron itself. Browser navigation, popups, permissions, remote requests, and unreviewed local files are denied.

No user vehicle should be connected to this executable; it cannot verify real-world tuning functionality. The staged preview is intended only for inspecting UI layout and navigation. A successful preview build is **not** sufficient to announce full TunIQ `READY FOR USER TESTING`.

## Verified in this environment

- Node/JavaScript static and regression tests were run offline.
- The exact seven-file allowlist is covered by test fixtures, including source packaging exclusions and refusal to overwrite an existing staging directory.
- Native Windows packaging **could not run in the Linux environment**.
- npm registry requests failed with `EAI_AGAIN`, so neither a genuine lockfile nor installed Electron dependencies was generated here.
- Chromium browser navigation was blocked by the execution environment's administrator policy; do not count browser preview success.
- No physical ECU connection, read, Test Write, ECU write, or flash was attempted.

## Release separation

Production `npm run dist:win` remains governed by `tools/installer-release-gate.js`; this checkpoint does not weaken it. The Windows GUI preview script creates a separate, clearly labeled, hardware-free development executable only.

To advance the **full application** to supervised user testing, independently verify the real application build and startup, read-only safety end to end, dependency reproducibility, and relevant workflows on Windows. Public release has additional signing, licensing, recovery, privacy, hardware, and distribution requirements.
