# Run104 — Fix npm lockfile generation gate

## Confirmed root cause

The Windows offline-preview build previously invoked `npm install --package-lock-only --save=false`.
In npm 10.9.2, `--save=false` prevents writing `package-lock.json`, **even when the
command returns exit code 0**. This was independently reproduced in a disposable
zero-dependency project on Linux; the same npm config semantics are documented by npm.
Therefore the previous Windows script could not generate the lockfile it required
for `npm ci`, even if registry connectivity were restored.

## Changes

- The Windows preview script now uses `--package-lock=true --save=true` with
  `--package-lock-only --ignore-scripts`. It still works on a disposable source
  copy and does not write into the original checkout.
- A postcondition rejects npm exit 0 if `package-lock.json` was not actually created.
- A new offline npm CLI regression demonstrates both the failing and fixed flags
  without downloading dependencies or running any Electron/ECU code.
- The diagnosis action now correctly says **three** distinct startup proofs.

## Limits

The disposable npm fixture is **not** a TunIQ dependency lockfile and does not
prove that Electron installs or runs. TunIQ's genuine transitive lockfile still
requires npm registry connectivity. No native Windows/Electron execution occurred
in this checkpoint. Never use ECU/OBD hardware for this preview.

## Windows instructions

Disconnect all ECU/OBD hardware. With Node.js 20+ installed, extract Run104
and run in PowerShell from the extracted project root:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
node .\tests\windows-lockfile-generation-simulations.js
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output/Run97-Diagnostics-<guid>/` for the candidate lockfile,
`windows-build-transcript.txt`, `build-outcome.json`, `diagnosis.json`, and native
Electron stdout/stderr/evidence files. Review raw logs for private paths before
sharing. A successful preview remains **offline UI only**, never full TunIQ.
