# Run62 — Atomic phone-log output publication (offline only)

## Verified defect

`src/log-import.js` previously wrote the sanitized CSV directly to its final path before writing the `.meta.json` and `.import.json` records. A failed metadata write could leave a CSV that looked imported but had no matching provenance metadata. A new synthetic failure-injection regression failed against the Run61 source before the fix.

## Bounded correction

`importPhoneLog()` now constructs the three outputs in memory, stages all of them in a private temporary directory inside the project's `Logs` directory, and publishes each complete file via exclusive hard-link creation. Unlike rename, hard-link publication fails if the destination already exists. If any stage or publication fails, the operation removes staged files and only its own published files (checked by device/inode). The existing `writeNormalizedCsv()` helper remains available for evidence imports.

This is *not* a multi-file crash-atomic transaction: power loss between three publications could still leave a subset. On filesystems that disallow hard links, imports fail closed rather than fall back to potentially unsafe partial output. Native Windows/NTFS behavior has not been verified.

## Scope and safety

Only local phone-log CSV/metadata import was changed. No COM ports, ECU reads, ECU writes, flashing, or live hardware were used. Source-only readiness remains blocked; no installer or production build was generated.

## Regression coverage

`tests/phone-log-atomic-output-simulations.js` injects a second-publication failure, a metadata staging failure, and a final-name collision; it verifies no orphan files remain after failures, pre-existing destination bytes are preserved, successful imports produce matching CSV/metadata/report, and private VIN columns remain excluded. The test is integrated into the existing 76-group suite and exposed as `npm run test:phone-log-atomic`.
