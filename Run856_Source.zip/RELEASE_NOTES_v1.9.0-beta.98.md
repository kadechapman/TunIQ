# TunIQ 1.9.0-beta.98 — Nonclobber Rejected Read Quarantine

**Source-only development checkpoint, 2026-10-17. Not a Windows installer or public release.**

## Corrected safety defect

Beta.97 used a timestamp-only `fs.renameSync` destination for incomplete or cancelled Full Reads. When a rejected BIN already existed with that timestamp, the rename could overwrite the earlier rejected evidence. This was reproduced offline with a fixed clock and a preexisting `.rejected-*` file.

Beta.98 uses a random rejected suffix with exclusive hardlink reservation or bounded `COPYFILE_EXCL` fallback. It checks source file identity before removing the normal output path. If quarantine fails, the read remains failed/unadmitted and a warning is recorded; existing rejected files are never intentionally replaced. The same guard now applies after a project import callback failure. No ECU-write code was changed.

## Boundaries

These checks are best-effort filesystem protection, not a guarantee against malicious concurrent file mutation. On unsupported filesystems or cleanup errors, the original may remain and must be handled manually. The callback may have already performed partial side effects; this is not a transactional import rollback.

No physical COM, PCM Hammer Windows CLI/kernel, independent Full Reads, interrupted hardware recovery, Windows installer, code signing, or production update verification was performed. No physical Test Write, ECU write, or flash was initiated.
