# TunIQ development checkpoint — pinned COM admission

**October 17, 2026 — unpromoted beta.108 source-only checkpoint.** No physical PCM, OBDLink, Test Write, ECU write or flash was performed.

## Reproduced defect

After the previous inter-operation cooldown race fix, `P01HardwareTransactionManager.settleBeforeOpen()` still treated an empty recorded port as a wildcard. A Windows transaction prepared without a proven COM port could be marked `ready-to-open` with no port, or a later caller could substitute a COM port not recorded by `begin()`. This was reproduced using the newest verified Library source and a failing offline regression.

## Fix

On non-test platforms, cooldown admission now requires a nonempty normalized COM port **matching the pinned transaction port**. The special empty-port mock remains permitted only when `platform: 'test'` and both ports are empty, preserving existing offline simulated Test Write harness behavior. The prior `preparationSequence` race guard and active-child protection remain unchanged.

## Qualification limits

Offline tests cover missing-port rejection, late port substitution rejection, the explicit test-only fixture, existing same-port cooldown and race protection, exclusive device lease, and Full Read watchdog. These tests do not prove Windows kernel/CLI compatibility, real COM exclusivity, physical interrupted Full Read recovery, or ECU safety. Dependency lockfile, clean Windows install, signing, licensing, privacy, secure updates, exact-OS calibration/backup checks and physical hardware evidence remain blockers. No release promotion is authorized.
