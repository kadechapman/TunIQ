# Run40 — Control-byte CLI diagnostic guard (source-only)

## Scope

Offline, read-only PCM Hammer result classification and automatic CLI retry
admission. No serial device, PCM, test write, write, or flash was used.

## Reproduced defect

The previous `hasUnrecognizedCliEscape` guard rejected ESC and selected C1
terminal controls, but not backspace (`0x08`), NUL (`0x00`), or DEL (`0x7f`).
A diagnostic like `CRC err<BS>ors: 2` followed by `Read completed
successfully` could be promoted as a successful Full Read with child exit 0.
The same control bytes also allowed a second CLI profile or typed-device
fallback after a parser-error footer. Baseline reproduction recorded all three
unsafe decisions for each of the three bytes.

## Correction

`src/pcmhammer-integrated.js` now rejects C0/C1 control bytes other than
ordinary TAB, CR and LF after stripping only recognized ANSI SGR color codes.
This shares one conservative predicate across Full Read / Read Properties
classification, command-profile retry, typed-device fallback and COM activity
admission. The existing stop code `cli-diagnostic-unrecognized-escape` is
retained for compatibility; it now also denotes other unsafe controls.

## Limitations and release gate

Synthetic strings verify a software guard only. The exact PCM Hammer
CLI/kernel build, Windows behavior, OBDLink COM ownership, interrupted Full
Read recovery and two independent matching physical reads remain unverified.
A real CLI that emits binary control bytes may be rejected rather than
accepted; this is intentional until the exact output contract is qualified.
No automatic writes or AI tuning are authorized by this change.
