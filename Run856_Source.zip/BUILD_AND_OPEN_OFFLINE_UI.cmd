@echo off
setlocal
cd /d "%~dp0"
echo TunIQ OFFLINE UI PREVIEW - NO ECU READ, WRITE OR FLASH
if not exist "tools\windows-build-offline-preview.ps1" (
  echo ERROR: Missing reviewed Windows preview build script.
  pause
  exit /b 2
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\tools\windows-build-offline-preview.ps1" -LaunchAfterVerifiedBuild
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo BUILD OR INTERACTIVE LAUNCH FAILED. Check dev-build-output\Run97-Diagnostics-*
) else (
  echo Verified OFFLINE UI preview launched. This is NOT the full TunIQ tuning application.
)
pause
exit /b %RESULT%
