# Run107 — Windows offline-preview evidence completeness

This checkpoint also fixes a source-snapshot sequencing hazard: Run106 ran
`npm test` after generating `package-lock.json`, but the source-only launch
snapshot intentionally fingerprints that file. A clean archive passes the
snapshot check; introducing any lockfile changes the fingerprint and fails it.
Run107 keeps the genuine lockfile and `npm ci` installation in the build
workspace, while running the complete offline source suite in a separate
pristine copy without the generated lockfile or installed modules. This change
has only been statically checked on Linux, not executed on Windows.

This checkpoint fixes a concrete diagnostics gap introduced by Run106: the
Windows build could fail at `Record packaged Windows PE integrity`, but the
sanitized classifier did not recognize that step and returned `unknown`.

The offline-preview diagnosis now classifies packaged PE integrity failures,
lockfile generation failures, and rejected dependency lock metadata without
needing a usable native stdout log. A successful preview diagnosis also requires
well-formed `packaged-executable-integrity.json` metadata **in addition to**
three distinct nonce-bound native Electron startup proofs.

**Important limits:** the metadata check is not a cryptographic recheck of the
EXE. On Windows, the GitHub CI gate must still run
`node tools/windows-pe-integrity.js --verify <EXE> <JSON>` against the real
packaged executable. Neither the metadata nor an isolated UI preview proves
full TunIQ starts. No ECU, OBD, Test Write, write, or flash was used.

On Windows 10/11 with Node.js 20+, keep all ECU/OBD hardware disconnected.
Open PowerShell in the extracted source directory:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run test:windows-lockfile-generation
npm run test:windows-preview-diagnostics
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output/Run97-Diagnostics-<guid>/diagnosis.json`,
`build-outcome.json`, `windows-build-transcript.txt`, the native renderer,
staged, and packaged logs and evidence JSONs, and
`packaged-executable-integrity.json`. Do not share raw logs before removing
private Windows paths. Native Windows execution was not performed in this
source-only checkpoint.
