# Run48 — Invisible Unicode Backup Path Guard

**Date:** 2026-10-18. **Version:** 1.9.0-beta.108 (source-only).

## Reproduced defect

Both `checkSafeReadPath()` and `checkUnusedReadDestination()` accepted
backup filenames containing zero-width spaces, bidirectional controls,
Unicode line/paragraph separators, C1/DEL controls and unpaired surrogates.
For example, `read\u202E.bin` could appear misleadingly in UI or incident
logs. A `CON\u200B.bin` spelling can visually resemble a Windows device name.
This was reproduced on the Linux offline host before the patch.

## Correction

`src/read-output-safety.js` now rejects Unicode General Categories `Cc`,
`Cf`, `Cs`, `Zl` and `Zp` in **all original path components**, before path
normalization, as well as in the resolved filename and ancestor components.
Normal printable international Unicode (including accented characters,
Japanese text and emoji) remains accepted. The same policy applies to both
read destination preflight and post-read/import path policy.

`tests/read-output-safety-simulations.js` adds 36 checks: 22 direct unsafe
path checks, eight normalized-away unsafe-component checks, and six valid
printable-Unicode checks.

## Scope and limitations

This is defense in depth for local read-only backup paths, **not** an atomic
reservation or physical hardware qualification. The caller must still recheck
before launching PCM Hammer. No ECU write/flash, physical COM port, or
Windows installation was used. The source-only installer release gate remains
blocked. Dependency locking and native Windows testing remain outstanding.
