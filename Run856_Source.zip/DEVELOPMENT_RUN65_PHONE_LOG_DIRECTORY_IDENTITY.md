# Run65 — Fail-closed phone-log audit directory identity

Scope: **offline, read-only phone-log auditing only**. No ECU/OBD communication, flashing, calibration, or physical hardware activity.

## Reproduced defect (Run64)

`auditPhoneLogImports()` used `lstatSync(Logs)` before `opendirSync(Logs)`, but did not verify that `Logs` was still the same real directory. A controlled filesystem-hook test renamed the original `Logs` directory and replaced its path with a symlink to an empty external directory immediately before `opendirSync`. Run64 reported `status: clean`, `scanned: 0`, `groups: []` even though the original `Logs` directory contained an incomplete import. This is a **false clean** result caused by a directory-swap race.

A similar redirect between enumeration and opt-in content verification could cause reads from a different directory.

## Change

`src/phone-log-import-audit.js` now rechecks the original directory's device/inode and real non-symlink directory type after opening, during enumeration, after closing, and around per-group content verification. If the directory changes, the audit throws instead of reporting clean or verified. It does not delete, repair, or modify files.

`tests/phone-log-recovery-audit-simulations.js` adds six assertions covering deterministic redirects before directory open and after enumeration, plus preservation of original and external data. The regression fails on the original Run64 implementation and passes after the fix.

## Limits

This is a **best-effort identity guard**, not an atomic filesystem transaction or a security boundary against an attacker who can replace directories between checks. Windows native filesystem behavior remains unverified; device/inode stability should be tested on Windows NTFS. Do not treat any audit as proof of sensor authenticity.

## Release

A runnable Windows build, dependency lockfile, hardware COM exclusivity, and supervised physical read-only tests remain unverified. No release status is promoted by this change.

## Verified in this development environment

- Baseline Run64: deterministic directory redirect produced a false `clean` audit; updated regression failed against Run64 as expected.
- Patched Run65: recovery audit **28/28 checks passed** (previously 22); content-integrity checks **23/23 passed**.
- `npm run check`: exit **0**.
- `npm test`: **76 groups**, verified exit **0** from an explicit exit-code file.
- Installer release gate: exit **1**, blocked by nine source-only launch blockers (expected).
- Runtime: Linux, Node.js 22.16.0. No Windows execution or physical ECU activity.
