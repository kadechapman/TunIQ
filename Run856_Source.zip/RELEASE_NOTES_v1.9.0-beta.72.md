# TunIQ 1.9.0-beta.72 — source-only Full Read proof gate

- Fix: PCM Hammer CLI exit success was persisted as a verified profile and last successful Full Read **before** output validation and backup import. A 211-byte partial BIN with a success message could leave misleading success metadata even though the read failed.
- Now: only a completed operation can persist last-success/profile metadata; Full Read requires file-size and stable SHA-256 validation plus successful import. Failed operations cannot show 100% progress.
- Synthetic regression covers incomplete output, valid 512-KB output, and failed import. No physical hardware, Windows native CLI/kernel, clean installer, PCM Test Write, or ECU write was exercised.
- Release blocked by dependency lockfile, licensing, signed/clean Windows installer, secure update, privacy/redistribution review, incident recovery, and verified read-only hardware evidence.
