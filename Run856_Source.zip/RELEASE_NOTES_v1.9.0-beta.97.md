# TunIQ v1.9.0-beta.97 — Failed Read Import Quarantine

**Source-only development checkpoint, October 17, 2026. Not a Windows installer or public release.**

## Change

When a Full Read has valid CLI/file evidence but the project backup import callback throws, the session already fails. Previously the BIN remained at its original output path and `outputInfo.valid` remained true, which could mislead downstream consumers into treating an unadmitted file as verified. The read-only finalizer now marks `outputInfo.valid = false` with `read-import-failed`, and best-effort renames the unadmitted BIN to a uniquely suffixed `.rejected-*` path. Rename errors are recorded without promoting success. A callback that already partially mutated project state cannot be rolled back by this guard; a transactional importer remains future work.

No PCM write/test-write/flash code was modified or executed. This is an offline regression only; physical COM ownership and Windows compatibility remain unverified.

## Remaining launch gates

Dependency lockfile and `npm ci`, clean Windows installer and signing, physical read-only COM lease and interrupted-read qualification, two matching independent hardware reads, exact-OS definition/checksum review, licensing/redistribution, secure updates, privacy, incident recovery, and AI tuning approval remain unverified. Do not publish a public release.
