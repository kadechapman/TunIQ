# TunIQ v1.9.0-beta.68 — Persistent OBD Session Exit Confirmation

**Source-only development checkpoint; NOT READY FOR USER TESTING or PUBLIC RELEASE.**

- `PersistentSerialSession.close()` now awaits actual PowerShell child-process `close` notification, not just a graceful request or `kill()` call. A bounded 4-second timeout fails closed and retains possible COM ownership.
- `ObdManager.disconnect()`, `releaseForExternalTool()`, and persistent-session startup fallback no longer suppress unconfirmed close failures and cannot advertise a released COM port without process-exit evidence.
- `device:disconnect` Electron IPC now reserves the same non-cancelling external COM admission latch as connect/sample/doctor/logger, preventing disruption of PCM Hammer Full Reads and overlapping serial workflows.
- Added synthetic process-exit, forced-kill, timeout, retry, and ownership-preservation regression tests. No physical ECU, OBDLink, Windows CLI/kernel, PCM Test Write, write, or flash was used.

**Known limitation:** Windows may delay/ignore child termination; in that case TunIQ intentionally blocks handoff and requires operator recovery. Native Windows and hardware verification are still required. Nine launch blockers remain, including a real npm lockfile and clean Windows installation.
