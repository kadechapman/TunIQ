# TunIQ v1.9.0-beta.29 — Failed Identity Recheck Revocation

**Scope:** P01 proof recovery from finalized Read Properties history. No PCM Hammer executable, adapter driver, calibration, checksum, kernel, or ECU write changes.

## Confirmed regression
On beta.28, a newer `readProperties` history record with `state: failed`, `cancelled`, or `complete-unverified` was skipped. `findLatestProvenPort()` then returned an older successful COM4 proof for the same project, despite the latest attempt not confirming the current ECU. Reproduced with synthetic records before the fix.

## Fix
Reject old authoritative proof after a newer finalized unsuccessful Read Properties attempt for that project. Preserve selected COM port for manual recovery and allow fresh successful Read Properties to re-establish proof. Do not revoke prior identity on a failed Full Read; it remains needed to diagnose an interrupted read.

## Evidence boundary
Only source and synthetic session tests were performed. Physical Windows COM/OBDLink/ECU reads, Test Writes and PCM writes were **not** performed. Full public flashing remains blocked.
