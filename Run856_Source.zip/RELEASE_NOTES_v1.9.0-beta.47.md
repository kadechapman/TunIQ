# TunIQ v1.9.0-beta.47 — Restricted Read-Only PCM Backend Guard

Source-only checkpoint. No runnable Windows installer or physical hardware verification.

Default FlashManager behavior blocks PCM Test Write, Calibration Write, Full Write, and Recovery before COM-port access. The packaged app explicitly enables read-only mode. Assisted PCM Hammer GUI and Tool Connections PCM Hammer GUI launches are blocked, and guided P01 automation pauses before automatic calibration changes or Test Write. Legacy mocked write scenarios require an explicit test-only constructor option.

**Limitations:** Other external tuning tools are not sandboxed; a complete external process-launch and AI workflow audit remains. Windows CLI/kernel compatibility, clean install, physical OBDLink reads, and production readiness are not verified. No physical PCM writes were attempted.
