# TunIQ v1.9.0-beta.86 — Fail-Closed CLI Retry Exit Status

**Source-only development checkpoint. NOT ready for user testing or public release.**

## Safety correction

`src/pcmhammer-integrated.js` now permits read-only command-profile fallback only after an actual numeric, nonzero PCM Hammer child-process exit and the existing syntax-only, no-communication, untouched-output checks. Before this correction, a CLI process terminated by a signal (Node `close` code `null`) could print a usage footer and incorrectly authorize another read attempt. A successful exit `0` or string exit code could also authorize a retry.

`tests/pcmhammer-retry-exit-proof-simulations.js` adds twelve offline cases; no serial API, ECU, write, or flash is invoked. Existing beta.85 explicit exit proof for *successful Full Reads* is retained.

## Not verified

No Windows installer, clean Windows `npm ci`, physical OBDLink/PCM Hammer COM-port ownership, CLI/kernel compatibility, interrupted Full Read recovery, exact-OS calibration definition, or hardware safety certification has been performed. Do not promote to public beta until these and license, privacy, signing, secure update, incident response and redistribution requirements are reviewed. No ECU write, Test Write, or flash was performed.
