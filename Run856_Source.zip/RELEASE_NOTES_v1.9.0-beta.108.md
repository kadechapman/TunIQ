# TunIQ 1.9.0-beta.108 — Structured Read Integrity Status Guard

Source-only development checkpoint, October 17, 2026. Not an installer or public release.

## Fixed

- Read-only PCM Hammer CLI result classifier now rejects structured CRC, checksum, and hash status fields indicating failure, even with a later success footer and numeric exit 0.
- Read Properties identity evidence cannot be admitted after these status failures.
- Both read-only CLI profile retry and typed `COMx:elm` fallback reject the same failure diagnostics; this prevents repeated attempts following ambiguous runtime errors.
- Positive structured status fields remain permitted if all other evidence passes.

## Scope and limitations

Only `src/pcmhammer-integrated.js` production code changed. No physical PCM/OBDLink operation or ECU write was attempted. Offline tests cannot establish physical hardware, Windows CLI/kernel, or safe flash behavior. Source-only checkpoint; user testing and public release remain blocked by dependency locking, Windows qualification, physical read-only evidence, licensing, secure updates, signing, privacy, redistribution review, and incident/recovery documentation.
