# TunIQ v1.9.0-beta.43 — Windows Serial Failure and CLI Usage Guard

**Source-only development checkpoint. Not a Windows installer or approved hardware beta.**

## Safety correction

PCM Hammer can append CLI usage text to a runtime error. Beta.42 already blocked one COM-open error pattern, but missed Windows/.NET messages such as `The port 'COM4' does not exist`, `Access to port COM4 is denied`, and `The process cannot access the file because it is being used by another process`. With a usage footer, these could be classified as syntax-only failures and trigger a different read-only command profile. Beta.43 classifies these messages as runtime I/O failures, stopping that profile fallback. Genuine syntax-only errors still allow bounded read-only discovery.

No changes were made to write-capable operations, PCM kernel handling, or calibration logic. All tests are simulations or local filesystem tests on Linux, **not physical Windows/OBDLink/PCM validation**. No physical PCM Test Write, calibration write, or flash was performed.

## Outstanding release gates

A clean Windows installation, dependency lockfile, licensing decision, verified PCM Hammer CLI/kernel and OBDLink ownership, physical read-only interrupted-read recovery and dual matching Full Reads, privacy and redistribution reviews, signing, secure updates, and incident-response documentation remain unverified or blocked. No public release is authorized by this checkpoint.
