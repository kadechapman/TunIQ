# Windows process inventory failure: read-only recovery

TunIQ must refuse to launch PCM Hammer when its Windows process inventory is missing, malformed, or ambiguous. This does **not** prove exclusive COM ownership; it only avoids proceeding when process inspection is demonstrably unreliable.

1. Leave the ignition and PCM unchanged. Do **not** retry a write, Test Write, or flash.
2. Close other scan/serial programs, including PCM Hammer GUI, OBDwiz, terminal utilities, and loggers. Confirm no separate application is using the selected COM port.
3. Restart TunIQ and retry **Read Properties** only. If the process inventory still fails, inspect Windows PowerShell/CIM health and process permissions outside TunIQ; do not bypass the guard.
4. Preserve TunIQ's diagnostic log, Windows version, PCM Hammer CLI version, OBDLink model/firmware, and the exact error text. Remove VINs, private identifiers, and vehicle-specific BINs before sharing a report.
5. After a failed or interrupted Full Read, retain any partial output as evidence, do not overwrite it, and start a new read to a new filename only after a successful fresh preflight. Compare two independent completed reads by SHA-256 before treating them as a backup.

These instructions are not a substitute for real Windows/OBDLink validation. A passing simulated test is **not** physical hardware verification. This source checkpoint is not a qualified read-only installer or a public flashing release.
