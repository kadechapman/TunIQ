# Controlled COM reopen: read-only development checkpoint

This is a source-only safety change based on the verified TunIQ 1.9.0-beta.108 reconciled read-proof checkpoint. It is **not** a verified Windows build, physical OBDLink test, or public release.

## Defect and correction

The persisted P01 transaction manager previously admitted a same-port reopen while a PCM Hammer child was still marked `process-running`. Its public `controlledReopen()` method did not re-check the admission guard, so a direct call could change the transaction to `ready-to-open` without a confirmed child close. During its asynchronous Windows Bluetooth settle delay, a new project could replace the transaction, after which the old timer could incorrectly mark the replacement ready.

The guarded reopen now requires all of the following: a matching P01 transaction and COM port, a failed **read** with a confirmed `process-closed` ledger state, an explicit recorded pre-communication state, a matching recorded adapter-open failure, and no previous reopen. Unknown communication evidence and automatic Test Write reopen fail closed. `controlledReopen()` enforces the same conditions internally, and rechecks transaction identity/state after the delay before authorizing a second read-only COM open. The FlashManager passes communication evidence from the closed CLI attempt and handles denied/stale reopen without launching a second PCM Hammer process.

## Qualification limits

Tests use synthetic process evidence, temporary JSON transaction ledgers, and simulated waits. They **do not** prove Windows COM ownership, process-close semantics, kernel compatibility, OBDLink MX+ connectivity, independent Full Reads, or interrupted physical read recovery. No physical PCM Test Write, ECU write, or flash was attempted. A source-only launch snapshot does not substitute for an actual signed Windows installer or hardware validation.

## Remaining launch blockers

A reproducible dependency lockfile and clean Windows install, actual Windows PCM Hammer CLI/kernel qualification, physical exclusive COM ownership, interrupted Full Read recovery, two independent matching physical backups, exact-OS calibration/checksum/backup validation, licensing and redistribution review, privacy, secure update signing, and incident/recovery documentation remain required. Keep the public beta read-only until the evidence gate is satisfied.
