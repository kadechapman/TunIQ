# TunIQ Run51 — Direct protected-original file proof

**Scope:** source-only read-evidence reliability; no ECU communication, writes, flashing, or installer production.

## Reproduced defect

The P01 commissioning ledger's `fileInfo()` previously called `statSync(path)` and `readFileSync(path)` independently. Both follow filesystem symlinks. After two independent matching Full Reads were recorded, changing the active project's `bin` to a symlink pointing to one of the verified BINs made `verifiedOriginalBinding(...).activeMatches` return `true`. That could incorrectly promote a redirected path as the protected original.

## Correction

`fileInfo()` now fails closed unless the raw path is acceptable for local Windows backups, every parent is a direct directory, the file is a singly-linked regular file, and a single opened descriptor remains the same file before and after reading. On systems supporting `O_NOFOLLOW`, opening a newly substituted symlink is explicitly refused. Parent-directory identity is checked again after the digest read. The SHA-256 is computed from bytes read through the validated descriptor, not by reopening the pathname.

The existing pair-integrity test adds filesystem-only checks for a symlinked active original, a redirected parent, a hardlinked original, a deterministic lstat/open swap, and restoration of a direct original. Symlink-dependent assertions are skipped if a Windows test environment lacks permission to create symlinks.

## Limitations

This is a bounded source-level defense, not an atomic filesystem transaction. Filesystem metadata cannot guarantee safety against privileged attackers who can rewrite files and restore timestamps, or against all platform-specific filesystem behaviors. Physical Full Read independence and native Windows execution are still unverified. A successful source test is **not** approval for a Test Write, ECU write, flash, Windows installer, user beta, or public release.
