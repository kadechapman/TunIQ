# TunIQ v1.9.0-beta.48 — Read-Only CLI Template Execution Guard

Source-only development checkpoint; not approved for user testing or public release.

## Change

- In `FlashManager.preflight`, read-only beta ignores persisted custom/help-derived command templates. A saved `readProperties` or `read` template could previously contain a write command despite the operation-name guard.
- Known built-in PCM Hammer read-only CLI profiles are selected instead. Synthetic-only test mode retains its explicit override.
- Added a regression that reproduces a malicious saved Read Properties template and proves it is not selected; no subprocess, COM access, or physical PCM operation is used.

## Remaining risks

This is not an executable trust or hardware certification. A user-supplied PCM Hammer executable, `prefixArgs`, actual Windows CLI syntax, kernel compatibility, adapter ownership, read recovery, and physical Full Read success are not newly qualified. Write-capable external utilities and calibration/AI workflows remain outside this focused guard. Do not use the application to write or flash an ECU.
