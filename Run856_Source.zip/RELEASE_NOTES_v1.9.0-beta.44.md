# TunIQ v1.9.0-beta.44 — Combined Windows COM Ownership Error Guard

Source-only development checkpoint; not a runnable Windows installer or public release.

## Safety fix

Preserves the latest verified Library beta.43 protection for missing COM ports, quoted access-denied messages, and Windows sharing violations. Additional abbreviated Windows COM access-denied and locked-port messages now stop read-only PCM Hammer command-profile fallback even when CLI usage text follows. Pure syntax-only failures still allow bounded read-only profile discovery. No write-capable operation was changed or initiated.

## Verification limits

Regression cases cover three additional Windows-style messages in software simulations. Linux Node.js syntax, test, and source snapshot checks were executed. Native Windows, physical OBDLink MX+, PCM Hammer CLI/kernel and PCM qualification remain outstanding. Public release remains blocked.
