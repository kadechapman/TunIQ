# TunIQ beta.108 — preparation-token CLI spawn guard

October 17, 2026. Source-only, read-only safety development checkpoint. No physical ECU/OBDLink access or PCM write/flash was performed.

## Reproduced defect

An earlier `FlashManager.start()` caller could retain a prepared transaction while another caller ran `begin()` for the same project, COM port, and operation. The transaction ID is deliberately reused, and the original `assertCanStartProcess()` accepted a matching COM port, operation and `ready-to-open` state without checking the preparation sequence. A stale first caller could therefore inherit the second caller's COM admission. An offline reproduction against the previous Library source returned `staleAdmission: true` for sequence 1 after sequence 2 was prepared.

## Changes

- `src/p01-hardware-transaction.js`: pre-spawn admission optionally checks the captured transaction ID and preparation sequence against the current persisted ledger. A mismatch fails closed without changing the ledger.
- `src/flash.js`: production pre-spawn admission supplies both captured tokens from its own preparation. This check occurs before `spawn()` and applies to CLI read-only operations; no PCM write path was enabled.
- `tests/p01-hardware-transaction-simulations.js`: tests identical re-preparation, denied stale token, unchanged state/history, allowed current token and rejected foreign transaction ID. Legacy tokenless offline fixtures are retained; they do not establish Windows or hardware safety.

## Qualification limitations

Linux simulations do not establish Windows CLI/kernel compatibility, actual exclusive COM ownership, interrupted physical Full Read recovery, or safe physical PCM operations. There is no verified clean Windows install or lockfile. No public beta promotion is authorized by this checkpoint. Review source, tests, dependency locking, license, signing, privacy, updater, and supervised read-only hardware gates before a user beta.
