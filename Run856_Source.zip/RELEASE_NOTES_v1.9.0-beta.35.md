# TunIQ v1.9.0-beta.35 — Combined Read Output Safety

Built on the **actual Library beta.34 Read Output Link Integrity Guard** source archive, not the older GitHub beta.17 snapshot. The beta.34 post-read validator rejects symlink/hardlink spoofed Full Read files and checks file identity during hashing. This pass adds a preflight parent symlink/junction guard and repeats the check after output-directory creation and COM handoff.

No PCM communication, Test Write, or write was performed. Windows behavior and atomic destination reservation remain unverified. No public release is authorized.
