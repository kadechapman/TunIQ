# TunIQ source-only checkpoint — integrity counter fail-closed parsing

**Date:** 2026-10-18. **Base:** verified Run35, v1.9.0-beta.108. **Scope:** PCM Hammer CLI text classification and offline regressions only.

## Reproduced defect

Run35 accepted a nominal exit-0 Full Read despite `CRC errors: +2`, `Checksum failures: -1`, `Hash mismatches: 0b10`, malformed `CRC errors: 0xG2`, or an empty `CRC errors:` field in the CLI text. A trailing success footer could override those explicit error-count fields. In a syntax-error transcript, the same diagnostics could authorize an automatic retry. These are synthetic examples; no claim is made that a particular PCM Hammer release emits these formats.

## Correction

The read-integrity classifier now treats counter values as **safe only when the complete value is unambiguously zero** (decimal, hexadecimal, binary, optional positive sign) or the word `none`. Nonzero, negative, or malformed counters fail closed. The same classifier blocks read evidence promotion and retry/typed-device fallback. Ordinary zero counters remain accepted. Every counter on a combined status line is checked independently, so `CRC errors: 0; Hash mismatches: +2` is rejected. The code never opens a COM port.

## Verification and limitations

Run `node tests/pcmhammer-exit-proof-simulations.js`, `node tests/pcmhammer-retry-syntax-proof-simulations.js`, and `node tests/pcmhammer-typed-fallback-exit-simulations.js`. `npm run check` and `npm test` are independent release gates. No Windows executable, PCM Hammer binary, OBDLink MX+, physical COM ownership, ECU Full Read, ECU write, or flash is verified by this change. This parser is conservative: unrecognized counter formats may reject a legitimate read rather than admit an unsafe one.

Public release remains blocked by the dependency lockfile, clean Windows installation, physical read-only qualification, exact-OS/checksum/backup evidence, AI approval gates, licensing, signing, secure updates, privacy, third-party redistribution, and recovery documentation. Do not perform physical PCM Test Writes or ECU writes during qualification.
