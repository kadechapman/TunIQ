# TunIQ v1.9.0-beta.19 — Launch Readiness Hardening

- Adds a separate full-launch gate to the Release Center.
- Prevents feature-progress percentages from being mistaken for launch approval.
- Removes duplicate hard-coded runtime version authority; the desktop version now comes from VERSION.json/package metadata.
- Updates the compatibility matrix revision for the September 2026 beta cycle.
- Pins direct npm dependency versions to reduce build drift.
- Reports missing lockfile, license, update feed, signing, privacy review, third-party terms review, incident-response plan, clean-install verification, and verified real flashing hardware as explicit launch blockers.
- Adds exportable launch-readiness JSON.
- Preserves beta.18 PCM Hammer exclusive OBDLink COM ownership and all P01 write safety gates.
