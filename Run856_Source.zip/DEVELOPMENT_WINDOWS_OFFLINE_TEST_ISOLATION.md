# Run50 — Windows offline source validation separated from dependency installation

**Scope:** source-only development checkpoint; no Windows installer, ECU writes, or flashes.

## Reproduced workflow limitation

The previous `.github/workflows/windows-public-beta.yml` contained one Windows job.
Its `Require pinned dependency lockfile` step preceded `npm run check`, the
suite verifier, and `npm test`. With the known missing `package-lock.json`, the
job failed before running any dependency-free safety checks. This prevented
collection of useful Windows source-test evidence while the reproducible
installation blocker remained unresolved.

## Change

- `windows-offline-source-tests` runs source syntax/snapshot validation, suite
  verifier fixtures, read-only beta restrictions, installer admission tests,
  and the full simulation suite **without installing npm packages**.
- `windows-locked-dependency-check` independently requires `package-lock.json`
  **before** `npm ci`, then reruns source and suite validation with installed
  dependencies. It fails closed when the lockfile is absent.
- Read-only and installer restrictions are separate workflow steps so failure
  of either command cannot be hidden by a later successful command.
- Both jobs use read-only repository permissions. Neither produces an installer,
  modifies hardware, publishes artifacts, or authorizes an ECU-capable build.
- Regression assertions in `tests/installer-release-gate-simulations.js` check
  job separation, offline command coverage, lockfile-before-install ordering,
  and absence of release/build commands.

## Evidence boundaries

Linux Node.js simulation passes are **not** Windows execution evidence. The
new workflow must run on GitHub Actions before Windows behavior can be claimed
verified. `npm ci` remains blocked until a genuine, reproducible lockfile is
created with registry access and independently reviewed. Hardware and GUI
qualification remain unperformed. Source-only validation cannot be promoted
to READY FOR USER TESTING or READY FOR PUBLIC RELEASE.
