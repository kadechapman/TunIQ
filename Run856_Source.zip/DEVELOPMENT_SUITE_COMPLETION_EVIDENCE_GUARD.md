# Run43 — suite completion evidence guard (source-only)

**Status:** development-only checkpoint. No physical ECU communication, Test Write, write or flash was performed.

## Reproduced problem in Run42

`tools/verify-test-suite.js` accepted any stdout **or stderr** containing a success-banner substring and a clean child exit code. A child printing only `All TunIQ fake automated tests passed (76 groups).` with exit code 0 was accepted as a passing 76-group suite, despite zero completed groups. The same result occurred when the banner was emitted exclusively on stderr.

## Bounded correction

- Require at least 76 **distinct**, completed stdout checkmark lines before accepting an exact, full-line 76-group success banner on stdout.
- Stderr output cannot supply progress or a banner; substring banners and premature banners cannot certify completion.
- Deduplicate repeated checkmark labels so repeated noise cannot indefinitely refresh the idle deadline.
- Use separate UTF-8 streaming decoders for stdout and stderr, so multibyte checkmarks split across pipe chunks remain readable.
- Continue requiring a confirmed child exit code 0, no terminating signal, no timeout, and the prior total/idle deadlines.

Synthetic regressions cover missing/early/embedded/stderr-only banners, insufficient or repeated group lines, UTF-8 split across writes, and successful 76-line output. This is a test-harness integrity correction, not a claim that the tests themselves are immune to intentionally fabricated stdout. The test runner's 76-group banner is historical; it prints additional nested checkmark lines, so the guard uses a **minimum** of 76 unique lines rather than an exact checkmark count.

## Limitations and release blockers

The suite remains offline simulation and may stall intermittently. A clean Windows build, dependency lockfile, actual OBDLink/PCM Hammer behavior, physical COM exclusivity, and two independent matching Full Reads remain unverified. The guard does not change ECU read/write paths, calibration, checksums, or AI tuning. **NOT READY FOR USER TESTING OR PUBLIC RELEASE.**
