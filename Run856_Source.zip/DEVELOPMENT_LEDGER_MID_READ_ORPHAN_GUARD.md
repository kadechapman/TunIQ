# TunIQ beta.108 — mid-read orphan-ledger detection

**October 18, 2026; offline source-only development checkpoint. NOT a release or hardware qualification.**

## Source provenance

Baseline is the newest Run26 Library archive `TunIQ_Run26_Reconciled_Ledger_Integrity_Source.zip`, with 567/567 original manifest entries verified. It already reconciled Run25 redirection and orphan guards. This pass was restarted from Run26 after that checkpoint appeared; the earlier local Run25 merge was not promoted.

## Reproduced race

On unchanged Run26 source, `readLedger()` scanned the directory for orphan atomic-write files only once, *before* opening and reading the live ledger. A simulated interrupted writer creating `p01-hardware-transaction.json.2345.0123456789abcdef.tmp` during `fs.readFileSync(fd)` left an orphan while `snapshot()` still returned the old `preparing` ledger. No hardware was accessed.

## Narrow fix

`src/p01-hardware-transaction.js` now checks for interrupted writer files again after reading a ledger, and after an `ENOENT` lookup of a missing ledger. `tests/p01-hardware-transaction-simulations.js` injects the two timing windows, confirms fail-closed behavior, and checks that orphan evidence is preserved. The existing redirection, hardlink, ledger-structure and interrupted-write checks remain.

This narrows the time-of-check/time-of-use window but **does not provide atomic cross-process locking**: another writer could still appear after the second scan. Exclusive physical COM ownership, native Windows behavior and PCM Hammer CLI/kernel compatibility are unverified. Operator recovery must preserve evidence and confirm the child process is gone; no automatic orphan deletion.

## Release blockers

Complete-suite successful exit, lockfile and clean Windows installer, physical OBDLink read-only qualification (including interrupted Full Read recovery and two matching independent reads), exact-OS calibration/checksum/backup review, AI approval boundaries, license, secure updates, signing, privacy, third-party rights and recovery/incident documentation. No physical Test Write, PCM write or flash was attempted.
