@echo off
setlocal
cd /d "%~dp0"
echo.
echo TunIQ Installer - RELEASE BLOCKED UNTIL INDEPENDENT REVIEW
echo ==========================================================
echo This source-only beta has not passed production readiness.
echo No ECU-capable installer may be produced from this script.
echo.
where node >nul 2>nul || (echo Node.js is required.& exit /b 1)
node tools\installer-release-gate.js
if errorlevel 1 (
  echo Release admission denied. No installer was built.
  exit /b 1
)
rem Reserved for a future separately reviewed release pipeline.
rem This branch deliberately has no installer build command after the gate.
echo No reviewed release pipeline configured.
exit /b 1
