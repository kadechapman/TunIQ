# Run108 — Windows preview failure-step fallback

This is a source-only, hardware-disconnected development change. It does **not** establish a native Windows build, a runnable full TunIQ application, or public release readiness.

## Reproduced issue

The Run107 diagnostics classifier returned `unclassified` when a Windows build recorded a failure in one of these stages but the transcript and native stderr contained no recognizable error string:

- Launch staged preview in real Electron (smoke mode)
- Packaged Windows executable smoke
- Complete offline simulated suite

This can happen if `Start-Process` fails before Electron writes stderr, or a test exits without an expected signature. A step label is known and safe to disclose, so dropping it loses useful diagnosis.

## Change

`tools/diagnose-windows-preview.js` now uses the allowlisted `build-outcome.json` `lastStep` as a fallback after more specific network, timeout, and integrity checks. It classifies log-free staged/packaged startup, staging, offline suite, and Windows preflight failures with fixed, secret-free next actions. A passing outcome still requires three independent native smoke proofs and PE metadata; no diagnostic fallback grants approval.

`tests/windows-preview-diagnostics-simulations.js` adds six log-free failure regressions. These are offline fixtures, **not** native Windows startup tests.

## Next actual verification

On Windows 10/11 with Node.js 20+ and working npm/GitHub download access, extract a clean source archive and run:

```powershell
npm run test:windows-preview-diagnostics
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Keep ECU and OBD hardware disconnected. Review `dev-build-output/Run97-Diagnostics-<guid>/diagnosis.json`, `build-outcome.json`, and native stderr/transcript files. The script only packages an offline, ECU-disabled UI preview; even a passing preview is **not** full TunIQ user-test approval.
