# Run80 — Isolated renderer execution proof (offline-only change)

This bounded development pass fixes a false-positive in `tools/electron-renderer-runtime-smoke.js`: merely finding the expected `<script>` tags could pass even if the engine catalog and application scripts did not execute or the UI had replaced itself with a startup error.

The isolated Electron smoke now requires three independent, read-only observations:

1. The engine catalog global exposes an array catalog and its selection helper.
2. The app script installed the sidebar toggle handler.
3. The renderer has not displayed its `Startup error:` message.

Missing/unknown evidence fails closed. Six new offline regression cases cover false or absent evidence. No application ECU modules were modified. The isolated smoke does **not** register hardware IPC handlers, does **not** verify the full application startup, and cannot establish Windows user-test readiness. It may report a startup failure in an isolated session when the full application requires main-process IPC; that is an honest failure, not proof of hardware failure.

To verify on Windows after a reviewed `package-lock.json` and `npm ci`:

```powershell
npm run check
npm run test:renderer-smoke-contract
npm run test:renderer-runtime
```

A successful isolated renderer check alone is insufficient: independently verify a write-disabled full-app launch, automated tests, and packaging. Never connect ECU hardware or run Test Write/write/flash for this development gate.
