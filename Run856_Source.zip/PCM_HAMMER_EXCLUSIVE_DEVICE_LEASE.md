# PCM Hammer Exclusive OBDLink Device Lease

TunIQ v1.9.0-beta.18 removes TunIQ serial-port activity from the proven P01 hardware path.

## Problem replaced

Read Properties had already proven the P01, OS, OBDLink, and COM4. The next Full Read could still fail before PCM communication because TunIQ and PCM Hammer each performed their own port preparation and PCM Hammer repeated generic serial-device detection.

## Exclusive lease behavior

After Read Properties proves an OBDLink session:

- PCM Hammer becomes the only component allowed to open the proven COM port.
- TunIQ does not probe, open, disconnect, or release that port between protected P01 steps.
- The UI continues to display the physical port, such as COM4.
- The technical session stores the PCM Hammer device specification separately.
- Proven OBDLink/STN/ELM-family adapters use a typed device specification such as `COM4:elm` so the known adapter family is selected directly.
- If an older PCM Hammer CLI explicitly rejects the typed form, TunIQ may retry the same physical COM port once without the type suffix.
- No COM1, COM3, or alternate-port discovery is allowed inside the proven P01 transaction.

## Safety boundary

This lease only changes adapter ownership and device selection. It does not bypass:

- two complete matching 524,288-byte reads;
- BIN size and SHA-256 validation;
- exact-OS definition binding;
- checksum validation;
- Test Write;
- recovery safeguards; or
- explicit actual-write confirmation.

No partial read can become commissioning evidence.
