# TunIQ v1.9.0-beta.69 — OBD Bridge Child Exit Ownership

**Source-only checkpoint. Not a Windows installer or public release.**

- OBD bridge subprocess cancellation and timeouts retain possible COM ownership until the PowerShell child `close` event. Kill requests are not exit confirmation.
- Serial handoff to PCM Hammer, including the proven-port exclusive lane, fails closed if any OBD bridge child is still terminating.
- A new bridge request cannot start while another child has not confirmed exit.
- Bluetooth SPP repair refuses to proceed while aborted bridge children remain unconfirmed.
- Added synthetic regression for abort, reentry, timeout, COM release, and proven-port PCM Hammer handoff. No physical ECU writes or flashes were performed.

**Unverified:** Windows child-process/COM behavior, official PCM Hammer CLI/kernel compatibility, physical Full Read and interruption recovery, clean Windows installation, dependency lockfile, licensing, updates, privacy, signing, redistribution, and incident response.
