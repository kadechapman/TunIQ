# TunIQ v1.9.0-beta.94 — Positive CLI Exit Status Guard

Source-only development checkpoint. Not a Windows installer or public release.

## Safety correction

PCM Hammer read-only command-profile and typed-device fallback previously accepted negative integer child exit codes. Windows may report native process exception statuses as negative signed integers; these must not be treated as evidence of a CLI parser rejection. Both retry guards now require a conventional positive integer parser exit status (1..255), rejecting negative, unsigned Windows crash-like, and unsafe integer values, in addition to the existing explicit parser diagnostic, exclusive COM ownership, and unused Full Read destination protections. This is a conservative rejection; it does not prove COM release or hardware safety.

## Verification boundary

Offline regression fixtures include -1, signed -1073741819, unsigned 3221225477, command-not-found-style 9009, and an unsafe integer, while retaining legitimate positive parser rejection exits. Physical PCM writes, Test Writes, and flashes were not attempted. Windows installer, native CLI/kernel compatibility, OBDLink ownership, and physical Full Read/recovery remain unverified.
