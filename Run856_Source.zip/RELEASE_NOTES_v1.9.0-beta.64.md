# TunIQ v1.9.0-beta.64 — PCM Hammer Recovery Exit Ownership Guard

**Source-only checkpoint. Not a runnable, hardware-qualified Windows release.**

## Safety fix

Previously `FlashManager.clearTransientRecoveryState()` called `child.kill()` and immediately cleared `this.session` and set COM ownership idle. Process termination is asynchronous: another operation could be admitted before PCM Hammer released its COM handle. Recovery invoked while Windows process inventory was pending could also mark the COM owner idle despite an active start-admission latch.

The recovery method now requests cancellation once, keeps the active session and PCM Hammer COM ownership until the existing child close/error finalizer runs, and does not mark a pending start idle. It does not cancel an active real write; the restricted beta independently denies all physical write operations.

## Verification boundaries

New regression first failed against verified beta.62 and was rebased onto verified Library beta.63 (which preserves the independent protocol-activity retry guard). Focused tests include a synthetic child and an actual spawned Node mock CLI, **not physical ECU or Windows hardware**. A Windows installer, authentic PCM Hammer CLI/kernel and clean dependency installation are not verified. No real Test Write, write, flash or release occurred.

## Remaining work

Audit manual Bluetooth/COM recovery callers for process-exit sequencing, qualify clean Windows build and genuine npm lockfile, validate official PCM Hammer executable/kernel provenance and exact-OS backup/checksum safety, then perform supervised read-only hardware testing. Nine source launch blockers remain.
