# TunIQ v1.9.0-beta.25 — Proven Session Identity Continuity

Fixes the beta.24 continuity gap where a successful Full Read without OSID output replaced a valid Read Properties proof with an incomplete OS identity, blocking the next Test Write preflight. Only same-project, same-COM, exact-OS verified Read Properties proof may supply the missing identity.

Unverified reads, missing full-read validation, and Test Writes without an explicit pass are not promoted to proven-port evidence. Restart recovery ignores incomplete guided state and searches valid recorded history; the old fallback that treated a global last-successful COM port as project-specific proof has been removed.

All evidence checks are software-only; no physical PCM/OBDLink testing or writes are included. Full launch remains blocked pending physical qualification and release operations.
