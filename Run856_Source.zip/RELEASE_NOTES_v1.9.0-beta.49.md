# TunIQ v1.9.0-beta.49 — Read-Only CLI Prefix Arguments Guard

Source-only development checkpoint. **Not approved for user testing or public release.**

## Safety correction

Restricted read-only beta rejects any configured PCM Hammer `prefixArgs` before CLI probe, CLI device discovery, or Read Properties / Full Read preflight. Previously, saved prefix arguments were prepended to the built-in read-only command profile, allowing an unreviewed command verb or option to reach the executable. The configuration is retained for user review, and the status reports `cliPrefixArgsBlocked`.

This does **not** verify the installed PCM Hammer executable, its kernel files, Windows behavior, or physical ECU safety. Test-only simulated-write mode remains isolated to explicit synthetic fixtures. Never use it with physical hardware.

## Recovery

If `read-only-beta-prefix-args-blocked` appears, inspect `Tools/pcmhammer-cli.json` under TunIQ's data directory and remove the `prefixArgs` entries only after confirming the CLI is the expected standalone PCM Hammer executable. Re-probe and use Read Properties before attempting a Full Read. Do not attempt a Test Write, calibration write, recovery flash, or external GUI handoff in this beta.

## Qualification still required

Clean Windows installation and runnable packaged build, real PCM Hammer CLI/kernel version compatibility, supervised OBDLink MX+ read-only verification, independent matching Full Reads, interrupted-read recovery, dependency lockfile, licensing, secure updates, signing, privacy, redistribution, and incident response.
