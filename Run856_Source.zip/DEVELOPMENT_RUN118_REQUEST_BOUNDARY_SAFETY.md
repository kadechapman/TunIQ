# Run118 — P01 request boundary and fan-bank safety (source-only)

This development pass corrects three reproduced fail-open/ambiguous request-parser cases. It is **not** a calibration definition or a hardware verification.

1. **Mixed temperature units:** A request like `fans on at 210 F and off at 190 C` was parsed as a valid 210/190 °F pair. The parser now identifies explicit numeric C/F units and refuses mixed-unit requests; uniform explicit Celsius remains supported in read-only review.
2. **Individual fan banks:** A request for `fan 1 on at 205 F and fan 2 on at 215 F` was reduced to the first setpoint. Requests that name fan 1 or fan 2 now require separately verified exact-OS mappings and relay/output wiring. Shared fan on/off temperatures do **not** prove the outputs are enabled.
3. **Overlength request truncation:** The parser silently dropped text after 2,000 characters, potentially discarding a trailing knock-sensor delete. Requests over 2,000 characters now fail with an explicit error, including when a pre-parsed request is supplied to proposal generation.

The existing combined-request gate remains: VATS, fan thresholds, fan-output enablement, physical LSX Stage 2 cam tuning and knock-sensor changes must each be accounted for. Knock protection is not disabled. Physical cam parameters are not generated without the cam card, logs, and exact OS definition. VATS and fan mappings require independently verified controller identity, protected reads, exact OS/XDF, checksum and recovery evidence before any hardware operation.

## Verification and boundaries

The regression tests reproduce the old behavior before the fix, and validate fail-closed behavior afterward. Run `node tests/p01-universal-request-simulations.js`, `node tests/p01-quick-service-simulations.js`, `npm run check`, `npm test` and `npm run check:windows-source-paths`. These are **source-only and simulated** tests on Linux. No native Windows Electron execution, npm dependency installation, physical ECM read, Test Write, write, or flash was performed. A full runnable application has not been verified.
