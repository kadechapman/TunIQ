# TunIQ v1.9.0-beta.93 — Conflicting COM Diagnostic Guard

**2026-10-17 — source-only development checkpoint; NOT an installer or public release.**

## Defect reproduced in verified beta.92

`safeTypedDeviceFallback()` rejected another `COMx:elm` device but ignored plain `COMx` references in CLI output. For a request to `COM4:elm`, `Unknown serial device type "elm" on COM8` and `No device matching "COM4:elm"; unknown port COM9` incorrectly authorized a second CLI attempt. The defect was reproduced offline before modification.

## Change

`src/pcmhammer-device-lease.js` now scans **all** `COMx` and `COMx:type` references in the diagnostic. It denies fallback if any mention does not match the requested port or requested `:elm` type. A matching plain COM port or the requested typed port remains acceptable, subject to existing numeric nonzero exit, no-runtime-communication, unused Full Read output, and exclusive lease checks. This deliberately favors false negatives over unsafe retries.

`tests/pcmhammer-typed-fallback-exit-simulations.js` adds five synthetic cases (four denial scenarios and one valid matching plain COM reference). `tests/release-promotion-simulations.js` checks that the conflicting-port safeguard remains present.

## Verification limits

Offline tests cannot establish Windows CLI/kernel compatibility, physical COM-port release, independent PCM reads, or hardware recovery. Source integrity and automated tests are recorded in the accompanying test report. No physical PCM Test Write, ECU write, flash, or physical read was attempted. Write-capable code remains unqualified and must not be promoted for public beta.

## Release blockers

Reviewed dependency lockfile, licensing, secure updates, physical hardware qualification, Windows signing, privacy review, third-party redistribution permissions, incident response, and clean Windows installation remain outstanding. **Not ready for user testing or public release.**
