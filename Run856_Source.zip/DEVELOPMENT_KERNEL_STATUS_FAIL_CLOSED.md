# Run37 — fail-closed kernel/loader status evidence

Date: 2026-10-18. Version: 1.9.0-beta.108. Source-only development checkpoint; **not a user-testing or public-release build**.

## Baseline and reproduced defect

Started from the verified Run36 Library source archive (SHA-256 `1b70d20d151852dc99f6302a408e796bef83d9030c18f5a48fb1cb3862821740`; 579/579 source entries verified). Compared against verified Run35 (SHA-256 `4d0e8ba2406bfb573717e9a545ecc74bc9071bde661006ac74a9f9f5c45eccd8`). No hardware or ECU access was performed.

Synthetic PCM Hammer output containing `Kernel upload: false`, `Kernel handshake failed`, or `Loader execution: false` plus `Read completed successfully` and process exit 0 could be accepted as successful read evidence. `Kernel upload: false`, `Loader execution: false`, and `Kernel transfer status: failed` followed by an `Unknown option`/Usage footer could authorize another CLI profile attempt. These are offline counterexamples, **not confirmed real PCM Hammer log formats**.

## Source correction

`src/pcmhammer-integrated.js` provides one `hasKernelTransferFailure()` detector for explicit kernel/loader upload, load, execution, startup, transfer, handshake, and initialization failures, including structured `false`/`no` statuses. `src/pcmhammer.js` uses the same detector to reject optimistic read success, while CLI retry and typed-device fallback use it through `isPcmRuntimeFailure()`. A later success footer or syntax message cannot override a known kernel failure. Explicit successful kernel status remains permitted.

## Limitations

This improves offline CLI log classification. It does **not** prove physical PCM Hammer CLI compatibility, kernel correctness, adapter ownership, safe Full Read recovery, or reliable hardware communication. All physical PCM Test Write, ECU write, and flash operations remain prohibited for this checkpoint. This is not a Windows build. An unknown log dialect could still require additional fail-closed handling.

## Release blockers

No dependency lockfile, reproducible `npm ci`, clean Windows installation, signed executable, or physical OBDLink/PCM Hammer qualification is established. The application also requires exact-OS calibration/backup/checksum qualification, secure update and privacy review, licensing and redistribution review, and incident/recovery documentation. Recommend only a supervised read-only beta after the relevant gates pass.
