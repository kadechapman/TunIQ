# TunIQ v1.9.0-beta.88 — Reconciled CLI Retry Safety

Based on the newest verified Library beta.87 Full Read Retry Destination Guard source, not the older beta.86 baseline. Preserves its missing/unsafe output destination guard, and adds explicit CLI parser/syntax rejection before another read-only PCM Hammer profile is tried. Generic Usage text alone is insufficient.

Offline tests cover missing, redirected, reserved, existing and safe Full Read output paths, plus generic usage-only errors versus affirmative syntax rejection. This source-only checkpoint is not a Windows installer or physical OBDLink/PCM Hammer verification. No real ECU Test Write, write or flash occurred. A supervised read-only beta is the maximum recommended milestone after Windows and hardware qualification.
