# TunIQ v1.9.0-beta.65 — External COM Workflow Admission Guard

**Source-only development checkpoint. Not approved for user testing or public release.**

## Safety change

A beta.64 recovery cancellation correctly retained PCM Hammer's internal COM lease until process exit, but desktop Bluetooth repair and manual COM verification could immediately open the same serial adapter without checking that lease. Beta.65 routes those handlers and manual PCM Hammer handoff through `FlashManager.withExclusiveExternalPortAccess`. The method rejects a live/starting/terminating PCM Hammer process and reserves admission across asynchronous external operations. `FlashManager.start` refuses to launch PCM Hammer during that reservation. Failed external workflows release their reservation in `finally`.

## Verification boundary

Regression first failed against beta.64 because the external lease method did not exist. Synthetic Node tests verify exclusive admission, pending termination, concurrent external workflows, cleanup on failure, and desktop IPC handler wiring. No physical Windows OBDLink, PCM Hammer CLI/kernel, ECU Full Read or ECU write was performed. The Windows installer, dependency lockfile, signing, licensing, update feed, privacy, exact-OS definitions and physical read recovery remain unqualified.

## Operator recovery

If manual verification or Bluetooth repair is refused, wait for PCM Hammer to exit and retry; preserve partial read data and use a fresh destination for any subsequent Full Read. Never perform a Test Write or ECU flash to recover a read failure.
