# Run42 — bounded automated-suite progress evidence (source-only)

**Status:** development checkpoint, not a Windows or physical PCM qualification.

The 76-group `npm test` suite intermittently failed to produce a final exit status in previous checkpoints. A printed checkmark is not proof that all groups passed. The previous verifier had a total 300-second deadline but did not report which group last completed, so timeout evidence could not identify where investigation should begin.

`tools/verify-test-suite.js` now records completed-group lines and uses a separate 120-second no-progress deadline, capped by the existing 300-second total deadline. Arbitrary stdout/stderr chatter and an early success banner do not extend the no-progress deadline. On either timeout the wrapper fails closed, terminates the suite process, closes its own pipes, and reports the last completed group. It still requires both the complete 76-group banner **and** a clean child exit code 0 to pass. The progress count includes any test's checkmark lines, so it is **not** itself a 76-group completion certificate.

`tests/verify-test-suite-simulations.js` adds synthetic cases for idle stdout noise, last-group diagnostics, active progress, and invalid idle deadline. These tests spawn Node only and never access COM ports or ECUs.

**Limitations:** The wrapper does not guarantee termination of descendants on all platforms; it does not resolve the underlying intermittently stalled suite or establish Windows installer, OBDLink, PCM Hammer, Full Read recovery, calibration, or checksum safety. A timed-out suite must not be reported as passed even when all visible groups printed checkmarks. The project still lacks a dependency lockfile and native Windows/hardware qualification.
