# Run98 — Windows offline preview smoke evidence and build outcome

This is a **hardware-free Electron UI preview** validation improvement, not a full TunIQ build or a release approval.

## Changes

- The Windows script now requests a fresh nonce-bound JSON renderer-ready proof from the **staged** Electron application before invoking electron-builder. A zero exit code alone is not enough. The proof must identify `offline-renderer-ready`, the matching nonce, and explicit `hardwareAvailable: false` / `writeHandlersRegistered: false`.
- It preserves staged proof in the per-run diagnostics directory alongside the packaged-executable proof.
- It writes `build-outcome.json` on success or failure with only a reviewed step label and boolean state. No environment variables, tokens, usernames, local file paths, or raw npm output are intentionally serialized into this JSON. The PowerShell transcript may contain local paths; review it before sharing.

## Windows execution (NOT verified by Linux tests)

On Windows 10/11 x64 with Node.js 20+ and npm registry access, disconnect all OBD and ECU hardware. Extract the complete Run98 source archive and open PowerShell in its root:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Review `dev-build-output/Run97-Diagnostics-<guid>/build-outcome.json`, `windows-build-transcript.txt`, `staged-smoke-evidence.json`, `packaged-smoke-evidence.json`, and `package-lock.candidate.json` (only files reached by the run exist). The historical `Run97` folder names are retained for compatibility with prior Windows instructions; the code checkpoint is Run98.

**Do not connect a vehicle.** Passing this workflow verifies only an offline interface preview. It does not verify the full Electron main process, live ECU reads, writes, Test Writes, flashing, or production readiness.
