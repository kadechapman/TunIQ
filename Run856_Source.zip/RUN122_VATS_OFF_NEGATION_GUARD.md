# Run122 — VATS object-between-verb negation guard

Source-only safety correction for the P01 request admission parser.

## Reproduced defect

Run121 recognized `Do not turn VATS off; just set fans on at 210 F and off at 190 F.` as a ready request containing a VATS-disable action. The VATS intent parser recognized `VATS ... off`, while the request-coverage guard only recognized `do not turn off VATS` (verb immediately before `off`). The new regression was run against Run121 and failed before the correction.

## Correction

`src/calibration-request-coverage.js` now blocks negative instructions with the object between the verb and `off`, including `do not turn VATS off`, `don't turn the VATS off`, `never switch VATS off`, and `do not shut my VATS off`. `Do not want to turn VATS off` and `don't want VATS turned off` are also covered. Contradictory mixed requests fail closed rather than preparing a partial VATS-disable calibration. Tests verify the original failure, related phrasings, a forged parsed-request bypass, and the positive `Turn VATS off` control.

This is a bounded pattern-based guard, not a complete natural-language understanding system. The user must authorize the change and the exact ECM OS/BIN/XDF mapping must be verified separately. No ECU writes or flashes, no invented addresses or cam/fan values.

## LS 5.3 owner test scope

- VATS: authorized request, exact controller/OS and matching definition, protected stock backup and independent readback evidence required before future hardware changes.
- Electric fans: separate output enablement and wiring verification from temperature thresholds. No guessed pinout or temperature values.
- Physical LSX Stage 2 cam: wait for exact cam card and baseline logs; no preset calibration values.
- Knock sensor delete: unsupported by the automatic planner; preserve knock protection and diagnose the sensors/harness.

Native Windows Electron and full ECU-capable application remain unverified until genuine npm lockfile, Windows dependency installation and native isolated/staged/packaged/delivered startup evidence exist. Linux fixtures do not establish Windows readiness.
