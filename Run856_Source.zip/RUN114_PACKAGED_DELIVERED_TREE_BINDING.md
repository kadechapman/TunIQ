# Run114 — Packaged-to-delivered Windows preview resource binding

This is a **hardware-isolated Electron UI preview** build verification change, **not** a complete TunIQ application or a production release.

## Reproduced failure

Run113 verified the smoke-tested packaged executable's SHA-256 against the copied executable, and independently verified the copied application's tree *after* delivered smoke. It did **not** compare the smoke-tested packaged **resources** against the delivered resources. A synthetic regression replaced `resources/app.asar` during the package-to-delivery copy and generated a matching new delivered-tree manifest. The Run113 reviewer accepted the changed resource tree (regression failed red). This can hide changes to unexercised application resources even when both narrow startup smokes pass.

## Fix

1. After the packaged native smoke and **before copying**, Windows records `packaged-preview-tree-integrity.json` for the complete `dist/win-unpacked` tree.
2. After copying and **before delivered startup**, Windows verifies the final output against the smoke-tested packaged tree. A mismatch stops the build before the delivered smoke.
3. The independent reviewer verifies the delivered output against **both** the packaged tree and the post-delivered-smoke tree. The diagnostic gate requires both metadata records to match. Windows CI independently re-hashes the packaged-tree proof against the delivered output before upload.
4. Distinct, actionable failure codes are provided for packaged-tree recording and package-to-delivery copy mismatches. Existing four nonce-bound native startup proofs, PE SHA-256, and final delivered-tree verification remain mandatory.

## Evidence and limitations

The new regression is an offline synthetic file-copy test, not a Windows execution. A genuine npm lockfile, native Windows `npm ci`, and actual isolated/staged/packaged/delivered Electron startup must still be verified on Windows 10/11. The reviewer is intentionally fail-closed on non-Windows hosts. Do not connect an ECU or OBD device, or perform any Test Write, write, or flash.

## Windows commands

In a fresh source extraction with Node.js 20+ and no ECU/OBD hardware:

```powershell
npm ping --registry=https://registry.npmjs.org/
npm run check
npm run test:windows-preview-evidence-review
npm run test:windows-preview-diagnostics
npm run test:windows-preview-ci
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

On failure inspect `dev-build-output/Run97-Diagnostics-<guid>/diagnosis.json`, `build-outcome.json`, `windows-build-transcript.txt`, and the native Electron stdout/stderr logs. A passing isolated UI preview still does **not** authorize full TunIQ user testing or public release.
