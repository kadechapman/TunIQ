# Run125 — Windows dependency candidate provenance

The hardware-free Windows operator script now captures SHA-256 digests of the
**disposable** `package.json`, npm-generated `package-lock.json`, and the
per-run `package-lock.candidate.json` after dependency metadata preflight.
It writes `lockfile-provenance.json` beside the candidate in the unique
`dev-build-output/Readonly-Validation-<guid>/` directory. A later `npm ci`
must preserve all three byte streams or the operator aborts **before native
Electron renderer startup**. The report contains no local file paths and
explicitly marks native installation, full application, and hardware as
unverified; it is not proof of a successful npm install or Windows launch.

`tools/windows-lockfile-provenance.js` is a Node-only offline utility.
`--capture <candidate> <report>` exclusively creates evidence and refuses
candidate/lock mismatch. `--verify <candidate> <report>` checks the current
working `package.json`, lockfile, candidate, and report against captured hashes.
It rejects missing/changed/redirected files and tampered digest metadata.
The CLI regression fixture exercises ten real offline cases, including mutation
of each input, evidence overwrite, and a symlink candidate. A separate static
operator test verifies invocation order around `npm ci`. Neither executes
PowerShell, Electron, ECU communication, a Test Write, or a flash.

## Windows operator (hardware disconnected)

From the extracted source directory on trusted Windows 10/11 with Node.js 20+:

```powershell
npm run check
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1 -PrepareOnly
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Keep `dev-build-output/Readonly-Validation-<guid>/` including the candidate,
provenance report, npm debug logs and renderer evidence. Review raw logs before
sharing them; they may contain private Windows paths. The separate preview
script tests a hardware-free isolated UI, not the complete TunIQ application.

## ECM dev scope

No ECU calibration code changed. VATS requires exact controller OS/BIN/XDF
verification and backups. Fan output enablement and physical wiring are
separate from fan on/off temperature mapping. The LSX Stage 2 cam requires its
actual cam card and baseline logs. Automatic knock protection disablement
remains blocked pending diagnostics. No OS address, fan target, cam value,
checksum proof or physical ECU compatibility was inferred.
