# TunIQ Run109 — verify the executable actually delivered

The hardware-free Windows preview build previously launched the temporary packaged
executable, then copied it to `dev-build-output` without starting that **copied**
executable. A passing temporary smoke and a valid PE header are not evidence
that the final distributed copy launches.

Run109 adds a SHA-256 equality gate between the smoke-tested packaged EXE and
the delivered EXE, then launches the copied EXE in offline `--smoke` mode with
a fresh nonce. The delivered proof is preserved as `delivered-smoke-evidence.json`,
with `delivered-electron.stdout.log` and `.stderr.log`. GitHub CI requires four
distinct startup nonces (isolated renderer, staged, packaged, delivered) plus
PE integrity metadata. The local diagnosis classifies delivered-copy mismatches
and log-free delivered startup failures. All ECU/OBD and write/flash functionality
remains excluded from this preview.

This is a source-only implementation until the Windows script actually runs.
Even a passing preview is not a complete TunIQ development build or approval
for vehicle use.
