# TunIQ v1.9.0-beta.75 — Reconciled Full Read Backup Guards

**Source-only development checkpoint; not a runnable Windows beta or public release.**

- Reconciles the two independently verified beta.74 source variants without discarding either safety improvement.
- `validateP01ReadFile()` now applies the shared Win32 filename, parent-name, and namespace safety policy before filesystem access, preserving existing symlink/junction parent and SHA-256 validation.
- `P01CommissioningManager.recordRead()` retains the beta.74 digest/size binding: a same-size substituted BIN or malformed proof is rejected before ledger promotion.
- Both regression suites are wired into the full automated test runner and release contract.
- No physical OBDLink/PCM Hammer or native Windows test was performed; no ECU Test Write, write or flash was attempted.
- No dependency lockfile, code signing, licensing, secure updates or production hardware evidence is supplied.
