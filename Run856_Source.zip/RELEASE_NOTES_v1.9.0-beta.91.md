# TunIQ v1.9.0-beta.91 — Typed Fallback Diagnostic Binding

**Source-only development checkpoint; not a Windows installer or public release.**

## Read-only safety correction

The PCM Hammer `COMx:elm` fallback predicate previously treated any `unknown serial device type` diagnostic, or a `no device matching COMy:elm` error from a different port, as permission to retry the proven adapter with an untyped COM name. A parser rejection of another type or port is not evidence that the requested typed adapter specification was rejected. Both conditions were reproduced against beta.90 with synthetic CLI text.

`src/pcmhammer-device-lease.js` now requires the exact requested `COMx:elm` device specification and matching parser rejection: an explicit `elm` type error or a device-matching/unrecognized error naming that same port. A missing/untagged spec or a log naming another typed COM port fails closed. `src/flash.js` supplies the current device spec. Existing numeric nonzero exit, no-PCM-activity, COM ownership and backup destination checks remain.

Regression cases cover wrong device type, missing type, wrong COM port, absent/untagged device spec, valid matching diagnostics, process exit and runtime errors. No physical ECU communication, PCM Test Write, ECU write or flash was performed.

## Release qualification

No reviewed npm dependency lockfile is present. An offline lockfile attempt failed `ENOTCACHED`; an online attempt failed DNS `EAI_AGAIN`. No clean Windows build, signing, CLI/kernel qualification, physical OBDLink tests, exact-OS calibration validation, secure updates or release attestations were verified. Do not publish. Next: generate and review a real npm lockfile on a trusted connected machine, then run clean Windows installation and supervised read-only hardware checks.
