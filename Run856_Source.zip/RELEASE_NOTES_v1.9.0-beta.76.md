# TunIQ 1.9.0-beta.76 — Combined Full Read Regression Coverage

Source-only development checkpoint. Adds an eight-scenario filesystem-only regression proving that imported Full Read path policy and P01 commissioning digest binding work together. Also verifies that a failed CLI result and partial 211-byte read cannot be promoted. The production read/COM/write code is unchanged from verified beta.75. No physical ECU communication or write/flash was performed. Windows installer and hardware readiness remain unverified.
