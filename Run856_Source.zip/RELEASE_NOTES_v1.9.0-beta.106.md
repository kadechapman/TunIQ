# TunIQ v1.9.0-beta.106 — Read Properties Block Failure Identity Guard

Source-only development checkpoint, October 17, 2026. **Not ready for user testing or public release.**

## Safety correction

Beta.105 classified `Failed to read block 128\nOSID: 9379910` (Read Properties, exit 0) as successful and would permit controller identity evidence to be imported. Three such block failures also yielded contradictory `success: true` and `stopCode: repeated-block-read-failures`. Beta.106 rejects one or more explicit block failures for **both** read-only operations, while preserving clean Read Properties progress. No ECU write, flash, or physical Test Write performed.

## Scope and limitations

Only read-only CLI result classification, regression assertions, version metadata, documentation, and generated integrity/readiness records changed. No physical hardware verified. No Windows build verified. The source-only readiness snapshot remains blocked. A trusted dependency lockfile, Windows clean-install validation, and supervised read-only COM/Full Read qualification remain required.
