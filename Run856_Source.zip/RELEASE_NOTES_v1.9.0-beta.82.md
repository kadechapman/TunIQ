# TunIQ v1.9.0-beta.82 — Reconciled Read and Hardware Evidence Guards

**Source-only development checkpoint. Not a Windows installer or public release.**

This checkpoint combines two separately verified beta.81 improvements on the same verified beta.80 source baseline:

1. Reject symlink, junction-parent, and multiply-linked BIN aliases **before** admitting P01 Full Read evidence or verifying an independent pair (`src/p01-commissioning.js`).
2. Reject private hardware verification evidence beneath redirected ancestor directories, and recheck directory identities during evidence hashing (`src/launch-readiness.js`).

Offline regression coverage includes seven read-admission scenarios and the private hardware evidence ancestor scenario. The earlier live verification of saved read pairs remains in place. No physical PCM Hammer/OBDLink, Windows junction, ECU Test Write, write, or flash was performed. These checks are not atomic locks and do not certify physical hardware evidence.
