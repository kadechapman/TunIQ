# Private hardware evidence requirements

The Full Launch Gate requires `private-hardware-evidence/hardware-verification.json` in the app/source root, or an explicit `hardwareEvidenceRoot` supplied to `buildLaunchReadiness`. This folder must remain private and must never be included in an installer or published source archive.

Each `records[]` entry must contain `controller` (P01 or P59), exact numeric `os`, `interface`, `physicalBenchTested: true`, `recoveryVerified: true`, `reviewed: true`, and a named `reviewer`. Supply two `reads` with distinct `sessionId`, different relative `path`, identical SHA-256, and actual matching file contents (P01: 524288 bytes; P59: explicitly set `expectedBinBytes`). Also include `testWrite: { outcome: "success", reviewed: true, log: {path, sha256} }` and `recoveryReport: { reviewed: true, log: {path, sha256} }`. Only paths inside the private evidence folder are accepted.

The integrity checks detect missing or modified files, but cannot establish that logs were produced by real hardware or that the reviewer is independent. Human review and actual physical tests remain mandatory. No ECU writes are initiated by this gate.

## beta.36 integrity limitations

Evidence files must be nonempty, regular, single-link files inside a real private evidence directory. Symlinked path components and hard-linked BINs/logs are rejected. Two reads must have distinct normalized paths and distinct claimed session IDs. Files are SHA-256 hashed from a pinned descriptor and their identity/metadata checked before and after hashing. Logs larger than 16 MiB are rejected to bound local validation memory.

**Important:** These structural checks cannot prove the physical origin of a BIN, a real PCM Hammer Test Write, recovery behavior, or an independent reviewer. A synthetic fixture with self-asserted signoff is still not physical verification. Keep public flashing disabled until real bench tests, logs and independent review are completed.

## beta.38 scope completeness rule

Each entry marked `kind: flashing` and `status: verified` must list nonempty `verifiedCombinations` with an exact P01/P59 controller, numeric OS ID, and interface name. **Every distinct combination** must have a corresponding private hardware-verification record with two independent matching reads and integrity-checked Test Write and recovery logs. One passing combination does not authorize any other combination. Duplicate combinations are deduplicated for this coverage check. This is a local evidence-integrity check, **not** independent proof of physical hardware provenance or permission to flash. Do not include private PCM BINs or logs in public packages.

## beta.39 manifest integrity and fork reconciliation

The private `hardware-verification.json` itself must be an independent regular file, not a symlink or hard link, with size >0 and <=1 MiB. Its file identity and metadata are checked during a pinned-descriptor read, in addition to the beta.38 complete-scope evidence checks. The two independent beta.38 safety branches were merged in beta.39. These controls validate local structure only and do not authenticate physical hardware provenance.

## beta.40 cross-scope evidence independence

Every distinct Verified controller/OS/interface combination must be backed by its own read sessions, BIN paths, Test Write log and recovery log. The same files or session IDs may not qualify multiple scopes. This check does not prove real hardware origin or independence of people reviewing the evidence.
