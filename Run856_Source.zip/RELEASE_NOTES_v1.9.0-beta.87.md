# TunIQ 1.9.0-beta.87 — Full Read Retry Destination Guard

Source-only safety checkpoint; not a runnable Windows beta.

- `src/pcmhammer-integrated.js`: require `checkUnusedReadDestination(output).ok` before read-only Full Read CLI profile retry. Reuses the existing shared filesystem safety policy; prevents retries with missing output, redirected parent directories, Windows aliases or unsafe namespaces.
- Offline regressions: explicit output requirement, symlink parent, Win32 reserved name, UNC path, untouched ordinary path, interrupted partial BIN and read-properties behavior.
- No physical PCM/OBDLink testing, PCM Test Write, write or flash. Do not publish or treat this as Windows hardware validation.
- Public launch remains blocked by lockfile, clean Windows install, signed installer, license, privacy, secure updates, redistribution permissions, recovery documentation and physical read-only qualification.
