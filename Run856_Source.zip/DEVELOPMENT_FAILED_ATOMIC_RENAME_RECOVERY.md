# Failed atomic COM ledger rename — fail-closed recovery (development checkpoint)

**Scope:** TunIQ 1.9.0-beta.108 source-only, offline regression. No PCM/OBDLink hardware was used; no ECU write or flash was initiated.

## Reproduced failure

The previous `writeJson()` wrote a new transaction record to a temporary file, flushed it, then attempted to rename it over `Devices/p01-hardware-transaction.json`. On a failed rename, `finally` deleted the temporary file. The previous valid ledger remained readable, so a subsequent COM8 preparation could be admitted despite evidence that a newer ownership transition had been attempted. This was reproduced using an injected `EACCES` rename error against the unmodified Run29 source.

## Change

`src/p01-hardware-transaction.js` no longer unlinks an atomic temporary record when a write or rename fails. Successful `renameSync` removes the temporary pathname normally. The existing `assertNoInterruptedLedgerUpdate()` guard detects a retained `p01-hardware-transaction.json.<pid>.<16hex>.tmp` file and blocks snapshot reads, new preparations, and process-launch admission. The old complete ledger and the new pending record are both preserved. Tests verify the failed rename, retained new state, blocked admission, preserved old bytes, and recovery after an **explicit simulated operator reconciliation**.

## Manual recovery procedure (not automatic)

1. Stop TunIQ; do not initiate a PCM Hammer operation or any ECU write.
2. Independently verify no PCM Hammer child, OBD session, or other process owns the physical COM port. If uncertain, leave the operation blocked.
3. Back up the original ledger and all matching temporary records with timestamps and hashes before changing anything. Treat the latest transaction state as unknown until reviewed.
4. Compare transaction IDs, preparation sequence, process-start/close evidence and session IDs. Resolve any running or interrupted Full Read with the existing read-only recovery procedure; do not infer completion from a partial BIN.
5. Only after a responsible operator has reconciled the evidence and verified a safe idle state, archive the orphan separately and restore a trusted ledger. Restart TunIQ and recheck admission. Do **not** blindly delete the orphan to resume operation.

## Limits

This does not provide atomic cross-process COM locking, Windows CLI/kernel compatibility, hardware-tested interruption recovery, or a public release qualification. A filesystem crash can still occur before data is durable; no physical hardware combination is verified. The remaining release blockers, including the missing npm lockfile and clean Windows install, remain unchanged.
