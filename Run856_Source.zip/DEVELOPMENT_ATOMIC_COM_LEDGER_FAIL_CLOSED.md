# TunIQ beta.108 — atomic PCM Hammer ownership ledger and corrupt-state denial

**Scope:** Source-only, offline development checkpoint. No physical PCM Hammer, OBDLink, ECU, Test Write, or write/flash operation was performed.

## Reproduced defect

`P01HardwareTransactionManager.load()` previously treated *every* JSON read or parse failure as an absent ledger. An interrupted/truncated `Devices/p01-hardware-transaction.json` could therefore be silently replaced by `begin()` with a fresh `preparing` transaction, despite the lost ledger possibly having recorded an active PCM Hammer child. The original source was reproduced accepting `begin()` after replacing the file with `{broken`.

## Correction

- Missing file (`ENOENT`) is accepted for first launch only. Unreadable, malformed, or structurally invalid existing files throw `PCM Hammer transaction ledger ... COM admission blocked`; the damaged file remains intact for diagnosis.
- Ledger replacement now writes a unique `0600` temporary file in the same directory, flushes it with `fsync`, closes it, and atomically renames it over the ledger. A failed rename leaves the previous ledger intact and cleans up the temp file.
- Added offline regression tests for torn JSON, invalid JSON structure, denial of new preparations and spawn admission, preservation of damaged bytes, injected rename failure, temp cleanup, and successful replacement.

## Recovery (manual, not automated)

Stop TunIQ, verify that all PCM Hammer child processes have exited and the adapter is disconnected, preserve the damaged ledger and relevant logs for incident review, and only then use a reviewed recovery procedure to quarantine the ledger before any new read-only session. Never delete an active owner's ledger to force COM access. This change does **not** prove cross-process exclusivity, Windows filesystem durability, or physical recovery safety.

## Release restrictions

No ECU write/flash path changed. A native clean Windows install, a real lockfile, verified CLI/kernel pairing, exclusive OBDLink COM ownership, two independent matching Full Reads, interrupted-read hardware recovery, exact-OS/checksum/backup gates, signed updates, licensing and privacy review remain outstanding. A public release is blocked. Consider supervised read-only testing only after a runnable Windows build and appropriate hardware evidence exist.
