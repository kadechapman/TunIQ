# Run53: complete stdout tail verification (source-only)

## Scope

`tools/verify-test-suite.js` verifies an offline automated suite. It does not access an ECU, serial port, or perform a flash. The verifier previously processed only newline-terminated stdout records, so a child that printed every required test milestone and the final success banner but exited normally **without a final newline** was incorrectly rejected. The issue was reproduced by a new regression before the correction.

## Correction

- Parse the final buffered stdout record when the child process and its pipes close, including any UTF-8 decoder tail.
- Continue requiring all 76 distinct groups, all 73 named milestones, the exact success banner, a clean exit code, and no timeout/signal/spawn error.
- Never treat stderr output as evidence. Ignore stdout tails longer than the existing 4,096-character bound.
- Avoid recreating a timer if the timeout path has already settled the verifier.

## Evidence and limits

The verifier's offline regression suite now covers unterminated success, unterminated final group, stderr-only banner, and a nonzero child exit with an unterminated banner. A passing suite is evidence for its offline simulations only; it is not evidence of a runnable Windows installer or a safe physical ECU read. Dependency lockfile and native Windows validation remain outstanding.
