# TunIQ v1.9.0-beta.105 — Reconciled Single-Block Full Read Failure Guard

**Source-only development checkpoint. Not ready for user testing or public release.**

## Newest baseline and defect

Reconciled onto verified Library beta.104 (Read Integrity Counter and Retry Guard), not an outdated beta.103 snapshot. Beta.104 rejects explicit CRC/checksum/hash counters and prevents CLI retries after integrity failure. However, it still accepted `Failed to read block 128` followed by `Read completed successfully` with exit code 0 because it required three failed blocks before rejecting the Full Read. The new regression reproduced this behavior before correction.

## Fix and tests

`src/pcmhammer.js` now treats **any** explicit failed block as disqualifying Full Read evidence. One or two failures return `block-read-failed`; three or more preserve `repeated-block-read-failures`. Full-size BIN admission also rejects the resulting failed CLI evidence. A clean block-progress control still passes. This deliberately fails closed even if a later retry is reported successful; the application has no independent per-block integrity proof.

`tests/pcmhammer-exit-proof-simulations.js` adds five synthetic checks. Beta.104's separate integrity-counter and retry guards remain in place. No production ECU-writing code was changed or exercised.

## Release limitations

No physical COM/OBDLink/ECU testing, native Windows installer, clean `npm ci`, signed build, actual calibration checksum validation, interrupted Full Read recovery, independent matching physical reads, secure update qualification, licensing or privacy attestation is established. No physical Test Write, ECU write or flash was initiated.
