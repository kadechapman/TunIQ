# TunIQ Run79 — Isolated Renderer Asset Admission

Scope: offline, renderer-only smoke-test request admission. No production ECU runtime, calibration, flashing, or communication code changed.

The Run78 isolated Electron smoke-test request filter accepted *any* real file beneath `src/renderer`, including an unexpected JSON file or a nested JavaScript file. That undermined the claim that only reviewed renderer assets could be requested.

Run79 admits only `index.html`, `styles.css`, `engine-catalog.js`, and `app.js`, all resolved to real files directly beneath the renderer directory. It rejects remote protocols, missing files, siblings, symlinks resolving outside the directory, unexpected nested files, and local file URLs containing query strings or fragments. Newly required assets must be reviewed and added explicitly.

This is a source-level request admission hardening and offline regression check. It is **not** evidence that Electron starts, that Windows builds, or that any ECU is safe to write. The real Electron runtime and Windows install remain unverified while `package-lock.json` and Electron dependencies are unavailable.
