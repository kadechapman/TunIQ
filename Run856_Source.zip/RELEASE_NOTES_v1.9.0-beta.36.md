# TunIQ 1.9.0-beta.36 — Private Hardware Evidence Integrity Guard

**Source-only development checkpoint; not an installer, public beta, or proof of physical PCM safety.**

The hardware launch gate now rejects linked BINs and logs, duplicate Full Read paths expressed through aliases, empty evidence logs, and symlinked parent components. It hashes from an open descriptor and checks file identity and timestamps before/after reading. A regression test reproduced acceptance of hard-linked reads in beta.35 before the fix.

No ECU writes, test writes, physical PCM reads, or flashes were performed. These checks validate local file integrity, not the authenticity of claimed physical tests. Public release remains blocked by Windows/hardware, signing, licensing, secure update, privacy and distribution requirements.
