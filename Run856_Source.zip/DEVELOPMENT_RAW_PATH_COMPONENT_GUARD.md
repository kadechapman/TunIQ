# Run47 — Raw Windows Backup Path Component Guard

**Date:** 2026-10-18. **Version:** 1.9.0-beta.108 (source-only).

## Reproduced issue

`checkSafeReadPath()` and `checkUnusedReadDestination()` inspected components
*after* `path.resolve()`. The following untrusted input was accepted on a
Linux offline test host:

```
/tmp/backup/NUL.bin/../read.bin
```

Normalization removes the `NUL.bin` segment before the existing Windows-device
alias check. The same issue applies to a removed `COM1.bin`, NTFS alternate-data
stream component, invalid Win32 character, or trailing-dot/space alias.

## Change

- `src/read-output-safety.js` now inspects the original caller-supplied path
  components before normalization. Device names, NTFS alternate-data stream
  spellings, invalid Win32 characters, and trailing-dot/space aliases are
  rejected even if a later `..` would remove the segment.
- Legitimate Windows absolute drive prefixes (e.g. `C:` before a separator)
  and ordinary `.` / `..` navigation remain accepted by this raw-component
  check; existing namespace, symlink, destination-existence, and normalized
  path checks still apply.
- `tests/read-output-safety-simulations.js` adds 18 negative assertions for
  nine hidden raw-component spellings across both read path policy and
  Full Read destination admission, plus two positive normalization assertions.

This is defense-in-depth for *read-only backup path validation*, not an atomic
filesystem reservation. Callers must still recheck immediately before CLI
spawn. This does not prove Windows behavior or any physical ECU safety.

## Verification and limitations

Run47 verification evidence and exact commands are in `TEST_REPORT.md` in the
separate development artifact package. No real COM port, PCM Hammer ECU write,
Test Write, or flash was accessed. A Windows runnable build is not verified.
The dependency lockfile remains missing; npm registry lookup failed with
`EAI_AGAIN` on this Linux host. The installer release gate remains blocked.
