# TunIQ v1.9.0-beta.66 — Non-disruptive PCM Hammer CLI Probe Lease

**Source-only development checkpoint. Not ready for user testing or public release.**

## Change

In beta.65, `FlashManager.probe()` could spawn PCM Hammer help/version subprocesses and change saved CLI configuration while a Full Read held the serial adapter. The probe did not participate in the external COM admission lease. Beta.66 wraps the entire probe in `withExclusiveExternalPortAccess(..., { requestRecovery: false })`, so it cannot overlap an active or pending PCM Hammer session or another external COM consumer. The new mode deliberately does not request cancellation or abort bridge work. The admission latch stays held across asynchronous help/version probes and is released on completion or failure. Existing Bluetooth/manual-repair behavior is unchanged.

## Verification limits

The regression was observed on unmodified beta.65 using a synthetic manager and mocked CLI capture. Tests do not establish real Windows CLI/kernel compatibility, physical COM exclusivity, or successful Full Reads. No ECU Test Write, write, or flash was initiated. A genuine npm lockfile, clean Windows installer, licensing, privacy, update-feed, signing and hardware qualification remain blocked.

## Recovery

If probing is refused during a read, allow the read to finish or its process to exit before retrying. Never cancel an active Full Read merely to refresh CLI help. Preserve any partial output and retry interrupted reads only to a new, unused local destination.
