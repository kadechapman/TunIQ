# Run105: bounded Windows dependency installation and Electron binary download diagnosis

This is a **source-only, hardware-isolated preview build** improvement. It does not certify native Windows startup or the full TunIQ application.

The temporary-copy `npm ci` command now uses `--fetch-retries=0 --fetch-timeout=30000` so npm registry stalls fail earlier with actionable diagnostics. This bounds npm registry requests, **not** Electron's independent GitHub binary download, the entire installation, or all postinstall subprocesses; the GitHub Actions job retains its 90-minute upper limit.

`tools/diagnose-windows-preview.js` now distinguishes a failure downloading Electron's GitHub binary during `npm ci` (`electron-binary-download`) from a failure resolving the npm registry (`npm-registry-dns`). The diagnosis includes fixed advice, not raw URLs, local paths, tokens, or logs. It does not approve a build.

On Windows 10/11, disconnect all ECU/OBD hardware, extract this source and run in PowerShell:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run test:windows-lockfile-generation
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output/Run97-Diagnostics-<guid>/diagnosis.json`, `build-outcome.json`, the local `windows-build-transcript.txt`, and native Electron stderr logs. Review private paths before sharing raw logs. A successful preview does not establish full application readiness. No ECU reads, Test Writes, writes or flashes are part of this workflow.
