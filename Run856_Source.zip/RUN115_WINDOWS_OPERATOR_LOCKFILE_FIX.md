# Run115 — Windows read-only operator lockfile fix (source-only)

**Scope:** Windows operator validation and hardware-isolated UI preview. This is **not** a verified full TunIQ development build or release. Never attach ECU/OBD hardware; never run ECU Test Write, write, or flash.

## Reproduced issue

`tools/windows-readonly-dev-validation.ps1` still used `npm install --package-lock-only ... --save=false`. Actual offline npm CLI fixtures show that npm can return **exit code 0** with that flag yet omit `package-lock.json`. The separate `tools/windows-build-offline-preview.ps1` had already fixed the same issue in Run104, but the operator kit was left behind.

Run115 explicitly uses `--package-lock=true --save=true` in the disposable operator copy and fails closed if npm reports success without a regular `package-lock.json`. Registry retries/timeouts are bounded for both lock generation and `npm ci`. The operator kit continues to run only source checks, offline simulations, locked dependency installation, and a hardware-isolated renderer smoke; it does **not** start the production application.

## Windows commands (Node.js 20+)

From the extracted source root in PowerShell, with ECU/OBD disconnected:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run test:windows-lockfile-generation
npm run test:windows-readonly-dev
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1 -PrepareOnly
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

`-PrepareOnly` validates the candidate lockfile without `npm ci` or Electron startup. The separate preview build attempts four actual native Electron startup proofs and preserves diagnostics under `dev-build-output/Run97-Diagnostics-<guid>/`. It is **not** a full TunIQ app build even if it succeeds.

If lock generation fails with `EAI_AGAIN`, check registry DNS/network; `ENOTCACHED` means the offline cache cannot satisfy the dependency graph. Do not fabricate a lockfile, bypass integrity checks, or approve an app from simulated tests. Review raw Windows logs for private local paths before sharing.

## Verification boundaries

The actual npm fixture is dependency-free and offline. Windows script regressions are static checks on Linux. Native Windows dependency installation and isolated/staged/packaged/delivered Electron startup must be run and reviewed on a Windows host. No public GitHub source publication is authorized by this change.
