# TunIQ beta.108 — reconciled mandatory Windows pre-spawn tokens

**Date:** October 17, 2026 (America/Chicago). **Source-only development checkpoint.** Not approved for user testing or public release. No physical OBDLink/ECU communication, PCM Test Write, ECU write, or flash.

## Newest actual source and comparison

Before finalizing, a newer Library source appeared. The final changes were reapplied to **`TunIQ_First_Failed_Close_TunIQ_beta108_dev_First_Failed_Close_Immutable_Source.zip`**, SHA-256 `7cfc99a2440bf776f25aec8431cb27a9880ff14e1ddc941da980f574e77dd2f4`, and all **562/562** manifest entries verified. The preceding Preparation Token source (`e0a4530c421b3289d706b7ec136de5f378e0c432e127a44945180ce7158ba3ba`, 561/561 verified) was also inspected. The newer source already prevents a duplicate failed child-close callback from manufacturing controlled-reopen evidence; its `src/flash.js` finalizer correction and transaction regressions are retained.

## Reproduced admission defect

The unmodified **newest** source allowed a Windows read-only PCM Hammer spawn check to succeed when the caller omitted both captured transaction ID and preparation sequence. Offline reproduction returned `tokenlessWindowsAdmission=true` for COM8 Full Read. Matching COM port and operation alone do not prove the caller still owns the current preparation.

## Correction

`src/p01-hardware-transaction.js` now requires a nonempty transaction ID and a positive safe-integer preparation sequence on every non-test platform before any pre-spawn COM admission. The explicitly synthetic `platform='test'` fixtures remain exempt; actual Windows and other production platforms cannot use the exemption. Existing exact-match, exclusive COM-port, session-retry and first-failed-close protections remain in place. `src/flash.js` already passes both captured values; it was not modified in this checkpoint. No ECU-writing functionality was enabled or modified.

`tests/p01-hardware-transaction-simulations.js` adds five missing/partial/invalid-token cases, confirms rejection leaves the ledger byte-for-byte unchanged, and verifies the current captured tokens still admit the intended operation. Existing Windows simulation assertions now pass explicit tokens.

## Executed verification

Linux, Node.js 22.16.0, npm 10.9.2. Baseline defect reproduced; fixed reproduction returned `tokenlessWindowsAdmission=false` with unchanged ledger. Targeted hardware transaction, exclusive lease (13/13), Full Read watchdog (14/14), child-process-error ownership, finalizer and read-only guard tests passed. **Full `npm test`: 76/76 groups passed, recorded exit 0** on this reconciled source. `npm run check` passed after source-only snapshot regeneration. All hardware-related tests are simulations, not physical qualification.

`npm ci --offline --ignore-scripts --no-audit --no-fund` failed because `package-lock.json` is absent. No clean Windows installer or native PCM Hammer CLI/kernel test. No physical COM-port, interrupted Full Read, matching read, Test Write, ECU write or flash tests.

## Release gate

Nine source-only public-launch blockers remain: dependency lockfile, license, secure updater, physical hardware evidence, Windows signing, privacy, redistribution permissions, incident response and clean Windows installation. Exact-OS definitions/checksum, protected backups, supervised read recovery and AI approval boundaries remain unqualified. Verified physical hardware combinations: **zero**. No defensible overall readiness percentage. A supervised **read-only beta** is the appropriate next milestone only after a runnable Windows build and relevant safety evidence. No public release.
