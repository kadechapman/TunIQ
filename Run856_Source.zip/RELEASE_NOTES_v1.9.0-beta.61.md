# TunIQ 1.9.0-beta.61 — Read Block Runtime Failure Retry Guard

**Development checkpoint only. Not a runnable or public release.**

## Fixed

PCM Hammer may emit `Failed to read block 23 at address ...` or `Block 42 read failed` followed by generic `Usage:` help without writing a BIN. Beta.60 could treat this as command syntax rejection and try another CLI profile against the same adapter. Beta.61 treats block-read, address-read, and checksum/CRC failure messages as ECU runtime evidence, preventing profile retries after such failures.

The guard preserves genuine syntax-only fallback and all existing beta.60 COM start-admission, executable-integrity, read-output collision, and interrupted-read safeguards.

## Evidence limits

Synthetic Node.js tests exercise the CLI parser and an integrated mock read failure. They do not verify Windows COM behavior, PCM Hammer binary/kernel provenance, an OBDLink adapter, or a physical PCM. No physical Test Write, write, or flash was initiated. Source-only readiness remains blocked until the nine public launch gates and hardware qualification are satisfied.
