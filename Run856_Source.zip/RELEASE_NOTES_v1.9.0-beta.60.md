# TunIQ v1.9.0-beta.60 — merged source-only checkpoint

Preserves verified Library beta.59's **synchronous PCM Hammer start-admission latch**, which blocks a second start while Windows process inventory and COM handoff are pending.

Adds a **final per-attempt Full Read output collision guard** in `src/flash.js`. If a different process creates the target filename after asynchronous handoff, TunIQ fails before launching the CLI and preserves the unrelated file without quarantine. `tests/p01-full-read-watchdog-simulations.js` adds a synthetic regression (11/11 scenarios). This regression failed against beta.58 before correction.

These are source-level simulations, not atomic filesystem guarantees, native Windows tests, or physical ECU validation. No PCM Test Write, write or flash was performed. The nine public-launch blockers remain unresolved; no installer or public release is authorized.
