# TunIQ v1.9.0-beta.59 — Concurrent PCM Hammer Start Admission Guard

**Source-only development checkpoint, October 16, 2026. NOT approved for user testing or public release.**

The verified beta.58 source allowed overlapping `start()` requests during asynchronous Windows process inspection before the first request populated `this.session`. The second request could also enter the COM handoff path. Beta.59 synchronously reserves admission to the start pipeline, rejects a competing request with `operation-starting`, and clears the reservation on success or failure. A launched child remains protected by the existing active-session check.

A synthetic deferred-inventory regression failed against beta.58 and passed with this change. This is a software concurrency guard, not an OS-level exclusive serial lock. Real Windows PCM Hammer/OBDLink tests, interrupted Full Read recovery, exact-OS calibration and backup validation, dependency locking, installer/signing, licensing, privacy and release attestation remain blocked. **No physical PCM Test Write, write or flash was attempted.**
