# PCM Hammer child-start provenance guard (source-only development checkpoint)

Reconciled onto the newer verified **Stale Child Close Ownership Guard** checkpoint; its cross-project, cross-port, cross-operation and cross-session close checks remain in place.

This checkpoint strengthens the **read-only** controlled COM reopen decision in `src/p01-hardware-transaction.js`.

## Reproduced unsafe cases in the previous checkpoint

1. A prepared read followed by `markProcessClosed()` **without any** `markProcessStarted()` could satisfy `canAttemptControlledReopen()`, incorrectly treating a fabricated or out-of-order close record as evidence of a previous PCM Hammer child.
2. A new preparation on the same project/port could inherit an earlier child start as proof if a close was recorded without a new start.

## Changes

- `begin()` invalidates child-start provenance for each new preparation sequence.
- `markProcessStarted()` records the preparation sequence for the child-start event.
- `canAttemptControlledReopen()` now requires a recorded child start for the **current** preparation sequence in addition to its existing confirmed-close, no-communication, read-only, same-port and single-retry gates.

This is a ledger safety improvement, **not** proof of exclusive Windows COM handle ownership. A software caller can still provide false event data; hardware testing is required. It does not enable PCM Test Write, writes, or flashing.

## Release restrictions

No Windows executable, clean installation, real PCM Hammer CLI/kernel, OBDLink MX+, physical Full Read, or interrupted-read recovery was verified in this Linux development pass. The dependency lockfile, licensing, secure updates, privacy, signing, redistribution, and recovery procedures remain blockers. Do not promote this source-only checkpoint to a public release.

## Additional finding (not fixed in this bounded pass)

A duplicate `markProcessStarted()` call can overwrite the running child record. A future fix must prevent a second `spawn()` **before** creating a process, not throw after a child has already been spawned. The current `src/flash.js` launches asynchronously; throwing after spawn could orphan a child. This is a separate release blocker.
