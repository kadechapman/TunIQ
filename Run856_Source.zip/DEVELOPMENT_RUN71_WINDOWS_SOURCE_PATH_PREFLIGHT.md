# Run71 — Offline Windows source-path compatibility preflight

TunIQ beta.108 is a source-only checkpoint. This run adds a **read-only** audit
of Windows-incompatible source paths before Windows dependency installation.
No ECU access, Test Write, flash, or hardware operation is involved.

`tools/windows-source-path-preflight.js` checks source paths recorded in
`SOURCE_MANIFEST.json` for Windows reserved device names (including COM/LPT),
invalid characters, trailing dots/spaces, path traversal, case-insensitive
file/directory collisions, duplicate entries, excessive lengths, and
file/directory conflicts. It validates the manifest SHA-256 sidecar and
hashes existing listed source files without modifying them. Symlinked and
hardlinked source files are rejected. Historical `test-results/*.log` files
are allowed to be absent from a Git checkout because they are intentionally
ignored; their names are still audited. All other missing source entries fail.

Run with `npm run check:windows-source-paths` or
`node tools/windows-source-path-preflight.js --report` for nonblocking JSON.
Synthetic regressions run with `npm run test:windows-source-paths` and are
also executed by the installer-admission simulation group. Both Windows CI
jobs now check source paths before any dependency installation.

This check is **not** a Windows build or installation. A passing result does
not prove NTFS filesystem behavior, checkout-root path length, npm package
installation, GUI launch, or physical ECU compatibility. The source archive
manifest can include ignored historical logs; GitHub's existing `main` branch
is not the compatible beta.108 source tree. A genuine npm lockfile is still
missing, and the release gate remains closed.
