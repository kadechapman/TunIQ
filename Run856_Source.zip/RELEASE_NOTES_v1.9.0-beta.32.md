# TunIQ v1.9.0-beta.32 — Full Read Output Preservation Guard

**Source-only safety checkpoint. Not a public installer or physical PCM qualification.**

- Reproduced on beta.30 source: `preflight('read', {output: protectedOriginal})` accepted an existing BIN destination. Beta.31 retained the same behavior.
- Full Read now refuses an existing destination, including a protected original, interrupted partial file, or dangling symlink. A read must create a new filename; it cannot overwrite or rename an existing file.
- Rechecks after asynchronous exclusive-process inspection (before COM handoff) and after COM handoff/cooldown (before starting the PCM Hammer child process), recording a stopped hardware transaction for the latter collision.
- Regression tests cover protected BIN, partial read, dangling symlink (where supported), file appearing during conflict inspection, and file appearing during cooldown.
- This is a software-only safeguard. An external process racing precisely between the final check and CLI file creation is not ruled out; exclusive OS-level output creation remains future work. Windows and physical OBDLink/PCM Hammer compatibility remain unverified.
- No ECU writes, physical Test Write, calibration-map changes, or AI write authorization.
