# Run54 — Verified-progress idle deadline for the offline suite

**Date:** 2026-10-19. **Scope:** source-only, no ECU or COM-port access.

## Reproduced issue

The test-suite verifier previously reset its no-progress timer for **any** new stdout
line beginning with `✓ `. A child that stopped running TunIQ's actual safety
milestones could continue printing unique unrelated checkmarks and prevent the
idle timeout, despite `requiredCount` remaining zero. With a 150 ms idle limit
and 700 ms total limit, the pre-fix synthetic child failed only at the total
`timeout` rather than `idle-timeout` (19 unrelated groups, zero required).

## Change

`tools/verify-test-suite.js` now resets the idle deadline **only** on the first
occurrence of a milestone named in `tests/suite-progress-required.json`.
Unrelated checkmarks, duplicates, arbitrary stdout and early banners do not
extend the idle deadline. The total timeout, exit-code check, 76 distinct group
requirement, 73 required milestones, and exact success banner remain mandatory.

`tests/verify-test-suite-simulations.js` now exercises unrelated checkmark spam,
repeated recognized milestones, and genuine sequential required milestones.
The latter must remain valid progress; the first two must fail by idle timeout.

## Limits and release status

This protects the verifier's stall detection, **not** against a malicious child
that deliberately prints all 73 known milestone names without running tests.
It does not establish Windows runtime compatibility, physical OBDLink operation,
ECU-read integrity, installer safety, or authorization to flash an ECU.
No write or flash was performed. This is not a runnable Windows build.
