# TunIQ Windows lockfile candidate — review only

This is an **alternative to publishing the source to GitHub** just to run the
Windows Actions workflow. It needs a clean, reviewed Git checkout and working
npm registry access on the operator's Windows computer. It does not install
Electron, run TunIQ, contact an ECM, or certify a Windows application.

1. Install Git, Node.js and npm on Windows. Keep ECM cables disconnected.
2. Place `Run339_DEV_BRANCH.bundle` in a local folder. In PowerShell:

   ```powershell
   git clone -b dev/run339 .\Run339_DEV_BRANCH.bundle .\TunIQ-run339
   cd .\TunIQ-run339
   npm run check
   npm run check:windows-source-paths
   npm run check:dev-readonly-admission
   node .\tools\generate-lockfile-candidate.js "$env:TEMP\TunIQ-lockfile-review-$(Get-Date -Format yyyyMMddHHmmss)"
   ```

3. The tool creates **only** `package-lock.candidate.json` and
   `candidate-provenance.json` in a new folder outside the checkout. Review
   both files and their SHA-256 hashes before considering any promotion.
4. A candidate passing the offline metadata reviewer **does not prove** that
   `npm ci`, Electron, Windows packaging, startup, all nine workspaces, or any
   physical ECM operation works. Never use it as authorization to flash.

For a network-free fixture test, run `npm run test:windows-lockfile-operator`.
This uses a synthetic dependency-free Git project and real npm CLI, and does
not generate the actual TunIQ dependency lockfile. If the npm registry is
unreachable, candidate generation fails and leaves no approved artifact.

No GitHub push, commit, or release is performed by this operator.
