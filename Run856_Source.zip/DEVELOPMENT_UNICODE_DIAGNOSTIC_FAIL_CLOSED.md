# Run45 — Unicode diagnostic ambiguity fails closed (read-only)

## Reproduced defect

The Run44 PCM Hammer CLI diagnostic classifier rejected unsafe ASCII controls but
accepted Unicode default-ignorable characters and Unicode line separators. A
synthetic `CRC err\u200Bors: 2` followed by `Read completed successfully` and
exit code 0 was classified as a successful Full Read. A parser `Unknown option`
footer could also authorize a second read-only CLI profile or typed-device
fallback after the same ambiguous diagnostic. This is **not** physical ECU
proof; all reproduction used in-memory synthetic CLI strings.

## Change

`hasUnrecognizedCliEscape` now rejects Unicode default-ignorable code points
(including zero-width characters, bidi controls, variation selectors and BOM)
and U+2028/U+2029 Unicode line separators. The existing shared detector is
used by Full Read and Read Properties result classification, CLI command-profile
retry admission, and typed-device fallback admission. It rejects the entire
ambiguous diagnostic rather than trying to reconstruct hidden text.

Normal ASCII/UTF-8 words, CRLF, LF, tabs, and supported ANSI SGR colors remain
accepted. This is a conservative fail-closed policy: genuine CLI diagnostics
containing default-ignorable Unicode will require investigation before retry.

## Verification and limitations

Regression cases were added to `tests/pcmhammer-exit-proof-simulations.js`,
`tests/pcmhammer-retry-syntax-proof-simulations.js`, and
`tests/pcmhammer-typed-fallback-exit-simulations.js`. The tests first failed
against Run44 and passed after the change. This does not establish actual
PCM Hammer/OBDLink hardware compatibility, a runnable Windows application,
or permission to write/flash an ECU. The installer release gate remains blocked.
