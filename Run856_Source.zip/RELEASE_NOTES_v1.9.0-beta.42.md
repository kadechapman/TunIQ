# TunIQ v1.9.0-beta.42 — Combined Exclusive Ownership and COM CLI Usage Guard

Built from the latest verified Library beta.41 **Fail-Closed Windows Adapter Ownership** source. Retains beta.41's exclusive-adapter process inventory failure handling, and adds a read-only PCM Hammer CLI classifier guard: a COM-open failure followed by generic usage/help output is never treated as a syntax-only failure. This prevents unnecessary command-profile fallback after a port-open failure. Pure syntax errors can still use bounded profile discovery, and controlled COM-port recovery behavior remains unchanged.

The regression was reproduced on the preceding beta.41 source and verified with local software simulations. This is a source-only checkpoint; no physical Windows/PCM Hammer/OBDLink/ECU verification, Test Write, or PCM write was performed. Public release remains blocked.
