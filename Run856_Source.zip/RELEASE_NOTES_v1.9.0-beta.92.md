# TunIQ v1.9.0-beta.92 — Reconciled Typed Fallback Guards

Source-only development checkpoint, not an installer or public release.

This checkpoint preserves the independently verified beta.91 diagnostic-binding fix: the `COMx:elm` fallback must match the requested COM port and ELM parser rejection, not an unrelated device type or port. It adds a fresh `checkUnusedReadDestination(output)` guard after the previous CLI process exits, before allowing a Full Read plain-COM retry. Missing output, nonexistent parent, existing partial BIN, reserved Windows filename, and symlink/junction parents fail closed. Read Properties does not need a backup destination.

The checks are non-atomic filesystem preconditions and do not establish actual Windows COM-port release. No physical OBDLink/PCM Hammer session, PCM Test Write, ECU write, or flash was performed. Release blockers remain: dependency lockfile, clean Windows install, licensing, signing, secure updates, privacy, redistribution rights, incident response, physical read-only qualification, exact-OS/checksum and backup evidence, and AI approval boundaries.
