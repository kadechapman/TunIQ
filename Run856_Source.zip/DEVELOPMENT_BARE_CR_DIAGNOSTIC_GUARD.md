# Run41 — Fail-closed bare carriage-return PCM Hammer diagnostics

## Scope

This checkpoint changes **offline read-only CLI evidence interpretation only**. It does not open a COM port, start PCM Hammer, run a Test Write, write a PCM, or flash an ECU.

## Reproduced Run40 defect

Run40 allowed a standalone carriage return (`0x0d`) to interrupt diagnostic keywords. For example, `CRC err\rors: 2` followed by `Read completed successfully` and process exit 0 was classified as a successful Full Read. The same malformed diagnostic followed by a CLI `Unknown option`/`Usage` footer permitted an automatic command-profile retry; with a typed-device error it permitted a typed-to-untyped fallback. `Kernel upl\road: false` exhibited the same class of problem.

A standalone carriage return is not an unambiguous newline: terminal output can use it to return to the beginning of the current line, hiding text or overwriting a status. The parser must not infer successful reads or safe command discovery from that output.

## Correction

`src/pcmhammer-integrated.js` now treats any CR **not immediately followed by LF** as unrecognized control evidence. This shared fail-closed guard prevents Full Read/Read Properties proof and automatic CLI retries or typed-device fallback. Proper Windows `CRLF`, ordinary `LF` and `TAB`, and recognized ANSI SGR color codes remain supported.

## Tests and limits

Regression cases were added to three existing offline suites: `pcmhammer-exit-proof-simulations.js`, `pcmhammer-retry-syntax-proof-simulations.js`, and `pcmhammer-typed-fallback-exit-simulations.js`. No hardware qualification is claimed. A CLI that emits standalone CR progress updates will now be rejected until its exact version and output contract are independently qualified; this is intentional conservative behavior. The text classifier is not proof of exclusive physical COM-port ownership or interrupted-read recovery. A reproducible clean Windows install, real adapter/kernel compatibility, and supervised independent physical Full Reads remain blockers.

## Run41 verification outcome

- Baseline Run40 reproduced four unsafe decisions: Full Read acceptance, kernel-status read acceptance, CLI command-profile retry, and typed-device fallback. Corrected source blocked all four; clean CRLF evidence remained accepted.
- Targeted exit-proof, syntax-retry, typed-device fallback, exclusive-lease, Full Read watchdog, launch-readiness, read-only beta guard, and suite-verifier simulations passed with exit code 0.
- `npm run check` passed. A full `npm test` attempt did not return a confirmed final exit code within the bounded execution window. **The complete suite is NOT verified for this checkpoint.**
- Offline `npm ci` failed because the repository has no dependency lockfile. Registry access also failed (DNS EAI_AGAIN). No Windows build or hardware testing occurred.
