# Run67 — Transitive dependency lock metadata containment

## Scope and provenance

Based on the checksum-verified Run66 source ZIP and complete Git bundle. This is a source-only, read-only development pass on `dev/run67-lockfile-transitive-safety`. No ECU communication, Test Write, ECU flash, dependency installation, Windows executable, or installer is performed.

## Reproduced issue

The Run66 Windows dependency preflight verified direct dependencies but ignored additional entries in `package-lock.json` under `packages`. A synthetic lockfile with an unverified transitive dependency passed `lockfileReady: true`. This matters because `npm ci` can install transitive packages; verifying only direct packages is not a meaningful whole-lock metadata check.

## Change

`tools/windows-dependency-preflight.js` now inspects every non-root package entry, rejecting malformed package paths, non-object entries, links, non-exact semantic versions, missing/malformed or short integrity digests, and non-HTTPS/non-public-npm-registry resolution URLs. A missing `resolved` URL is allowed because npm may omit it; therefore this remains a **metadata-only** check. Direct dependencies retain their own mismatch checks even when transitive entries fail.

`tests/windows-dependency-preflight-simulations.js` adds synthetic regressions for missing transitive integrity, `file:` and HTTP resolution, nonapproved registry origins, link entries, path traversal, invalid transitive versions, malformed integrity, null entries, and valid nested scoped entries. No network, hardware, or installer is involved.

## Remaining limitations

The check does not prove transitive dependency-graph closure, registry authenticity, artifact contents, npm installation reproducibility, Windows execution, or hardware safety. It intentionally restricts `resolved` URLs to `registry.npmjs.org` and will reject other registries pending explicit review. The actual `package-lock.json` is still missing; npm registry access was unavailable (`EAI_AGAIN`) in this run, so no fabricated lockfile was generated. The installer release gate remains fail-closed.
