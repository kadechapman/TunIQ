# TunIQ beta.108 — reconciled child-close ownership and pre-spawn stop guard

Date: 2026-10-17 (America/Chicago). Source-only development checkpoint; **not ready for user testing or public release**. No real ECU, OBDLink, COM port, Test Write, write or flash used.

## Baseline and reconciliation

Newest Library archive: `TunIQ_beta108_dev_Monotonic_Close_Evidence_Source.zip`, SHA-256 `b54b85b0865ebb4ae4f512ad77ea2c8ec4f06cdeb6450f83f33f1a8db1341cb6`, 557/557 source-manifest files verified. Its immediate parent was the Windows Root Relative Read Path Guard archive (556 entries). A separately developed sibling, `TunIQ_beta108_dev_Child_Close_Evidence_Guard_Source.zip` (SHA-256 `f47bc5270dcc94c50c94de00b1f496a9c35b01bd5582cbe9add6f5f6d63e281c`), contains complementary safety protections not in the newest archive. This pass reconciles those protections onto the newest archive rather than reverting the monotonic communication-evidence guard.

## Reproduced defects

Against the **unmodified newest source**, `markProcessClosed` accepted (1) a success callback without a child having started and changed `preparing` to `operation-complete`, and (2) a callback lacking `sessionId` while another identified child owned the COM port, changing `process-running` to `operation-complete`.

## Corrections

- `src/p01-hardware-transaction.js`: require matching child-start preparation proof, a closable state, and exact matching session when a child has an ID. Retain monotonic evidence checks from the newest source, which prevent downgrading completion or erasing PCM communication evidence.
- `src/flash.js`: for a pre-spawn Full Read output collision or CLI refusal, record a stopped preparation rather than fabricating child-close evidence. Do not mutate an unrelated owner's ledger.
- `tests/p01-hardware-transaction-simulations.js`: verify unstarted, stale-preparation, missing-session and mismatched-session close callbacks fail without mutation, while matching finalization and monotonic communication evidence still work.
- `tests/p01-full-read-watchdog-simulations.js`: verify an output collision stops preparation with no child-close/start evidence.

## Tests and limitations

Linux Node.js 22.16.0, npm 10.9.2. `node tests/p01-hardware-transaction-simulations.js`: 87 offline checks, pass. `node tests/p01-full-read-watchdog-simulations.js`: 14/14, pass. `node tests/pcmhammer-exclusive-device-lease-simulations.js`: 13/13, pass. `node tests/read-output-safety-simulations.js`: 50, pass. `node tests/pcmhammer-read-result-consistency-simulations.js`: 25, pass. `node tests/p01-read-independence-simulations.js`: 7, pass. `node tests/launch-readiness-simulations.js`: 12/12, pass. `node tests/read-only-beta-guard-simulations.js`: pass. `npm run check` passed after `npm run release:snapshot` refreshed the source-only snapshot (nine blockers). The complete `node tests/run-tests.js` suite was attempted once and **timed out after 260 seconds**, stopping after beta.18 startup regression output. **Do not claim a full-suite pass.** `npm ci --offline --ignore-scripts --no-audit` failed due to missing lockfile.

No native Windows installer, clean Windows install, Windows CLI/kernel pairing, physical COM ownership, independent matching physical Full Reads, interrupted physical Full Read recovery, calibration/checksum qualification, or hardware write/flash was verified. Physical hardware combinations verified: 0.

## Release blockers and next action

Nine source-only blockers remain: npm lockfile, license, secure updates, hardware evidence, Windows signing, privacy review, redistribution terms, incident response, and clean Windows install. Exact-OS calibration, checksum validation, protected backups, and approval-gated AI tuning need separate review. No defensible overall readiness percentage. **Next:** diagnose the full-suite stall, create a trusted registry-resolved lockfile, verify `npm ci` and a clean Windows build, then supervise read-only hardware tests. No October 17 public release.
