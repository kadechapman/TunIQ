# TunIQ v1.9.0-beta.89 — Existing Backup Parent Guard

**Source-only development checkpoint, October 17, 2026. Not a runnable Windows installer or a public release.**

- Fail closed when a Full Read destination has a missing immediate or ancestor directory. Earlier beta.88 treated `ENOENT` for an ancestor as acceptable, allowing a syntax-only CLI retry against an unavailable output directory.
- Keep the existing restrictions on Win32 device names, UNC paths, symbolic links, existing BINs, ambiguous child exits, and generic CLI usage text.
- Add offline regression cases to read destination and retry-exit tests.
- No physical adapter/PCM Test Write, read, write, or flash. Windows CLI/kernel compatibility, exclusive COM-port release, installer, and production readiness remain unverified.
