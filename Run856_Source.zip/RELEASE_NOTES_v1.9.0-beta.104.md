# TunIQ v1.9.0-beta.104 — Read Integrity Counter and Retry Guard

**October 17, 2026. Source-only development checkpoint. Not a public release or verified Windows build.**

## Read-only defect and correction

- Beta.103 could accept a nominally successful Full Read even when the CLI logged `CRC errors: 2`, `Hash mismatches: 3`, or `CRC does not match expected value`, because the classifier recognized only a narrower set of integrity failure wording.
- The same diagnostics followed by `Unknown option` and a CLI usage footer could authorize an automatic second command profile, despite evidence of failed read integrity. The typed `COMx:elm` fallback had the same issue.
- A shared `hasReadIntegrityFailure` detector now rejects explicit nonzero CRC/checksum/hash error counts, counted errors, and does-not-match diagnostics, alongside beta.103's existing mismatch/failure wording.
- Read-only Full Read and Read Properties evidence admission both fail closed on these diagnostics. The shared runtime-failure detector also prevents automatic CLI profile and typed-port retries.
- Zero error counts such as `CRC errors: 0` remain non-failure evidence. Positive exit and complete BIN size remain necessary, but not sufficient, for read admission.

## Boundaries

All new regression cases use synthetic CLI strings and local synthetic files. No physical COM port was opened and no PCM Test Write, write, or flash was attempted. This guard does **not** verify exact-OS calibration checksums, physical COM release, interrupted Full Read recovery, or independent hardware read consistency.

## Release blockers

An authentic npm lockfile, clean Windows build/install, compatible PCM Hammer CLI and kernel distribution, licensing, signing, secure updates, privacy review, redistribution permissions, incident response, and supervised physical read-only hardware qualification remain outstanding. Public release is blocked.
