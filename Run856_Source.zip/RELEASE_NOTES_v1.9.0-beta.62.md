# TunIQ 1.9.0-beta.62 — merged source-only checkpoint

Merged two independently verified beta.61 developments on top of the newest Library source.

- Preserves runtime block-read/checksum failure detection in `src/pcmhammer-integrated.js` and its mock CLI regression: no fallback to alternate CLI syntax after ECU communication failure, even if Usage help appears.
- Rejects Win32 device/extended-length namespaces, UNC/network shares and drive-relative Full Read paths before normalization, with cross-platform filesystem regression tests.
- Preserves concurrent-start admission, executable pinning and per-attempt destination collision protections from beta.60.
- Source-only, no Windows installer or hardware qualification. No physical Test Write, PCM write, recovery flash or other ECU write.
- Public launch blocked by dependency lock, licensing, secure updates, signing, privacy, redistribution, incident response, clean Windows install and physical hardware evidence.
