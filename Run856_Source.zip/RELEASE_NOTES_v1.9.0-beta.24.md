# TunIQ v1.9.0-beta.24 — Proven-Port Evidence Binding

## Safety change
Before treating a claimed P01 COM port as an authoritative PCM Hammer-exclusive lane, TunIQ now checks that the proof has the same selected COM port, active project ID, P01 controller, exact operating-system number, and a previously successful operation type. Missing or mismatched fields fail closed before a PCM Hammer session starts. Ordinary manually authorized Read Properties is unchanged.

This is **internal evidence consistency**, not proof of physical communication. Source-only launch readiness remains blocked. No real PCM writes are enabled by this change.
