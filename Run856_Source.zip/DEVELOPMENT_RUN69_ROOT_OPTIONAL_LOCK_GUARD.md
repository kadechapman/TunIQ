# TunIQ Run69 — Root optional dependency lockfile parity

**Scope:** Offline, read-only npm dependency metadata validation. No dependency installation, ECU access, Test Write, write, or flash.

## Reproduced failure

Run68 incorrectly accepted a synthetic `package.json` with a pinned `optionalDependencies` entry even though `package-lock.json` omitted both that root declaration and its package. `inspectWindowsDependencyLock()` reported `lockfileReady: true`.

## Correction

`tools/windows-dependency-preflight.js` now checks the root `optionalDependencies` map against the lockfile exactly as it already checks `dependencies` and `devDependencies`. It requires matching dependency sets, exact pinned versions, matching root specifications, a matching installed package version, and valid integrity metadata. Null dependency maps are rejected rather than treated as absent.

Eight new offline assertions cover missing/extra root optional declarations, a valid pinned optional dependency, version mismatch, range mismatch, unpinned version, and null maps.

## Boundaries

This is metadata-only validation. Optional packages may have platform-specific installation behavior; a successful preflight does **not** verify Windows npm installation, peer resolution, downloaded artifacts, or an executable. The actual project still lacks `package-lock.json`, so the strict preflight must fail closed. The beta remains read-only for safety testing; production release and physical hardware qualification remain blocked.
