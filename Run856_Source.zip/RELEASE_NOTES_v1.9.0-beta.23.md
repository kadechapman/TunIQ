# TunIQ v1.9.0-beta.23 — Exact Hardware Qualification Scope

- Public launch gate now fails closed unless reviewed evidence matches an explicitly verified controller + operating system + interface combination.
- Prevents one Verified P01 record from approving unrelated P01 OS versions or other adapters.
- Adds mismatch regression checks; no PCM Hammer communication or writing behavior changed.
- No physical hardware testing was performed. Flashing remains experimental.
