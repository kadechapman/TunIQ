'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run654-'));
try {
  const pkg = {name:'fixture',version:'1.0.0',dependencies:{alpha:'^1.0.0'}};
  const lock = {lockfileVersion:3,packages:{'':{name:'fixture',version:'1.0.0',devDependencies:{alpha:'^1.0.0'}},'node_modules/alpha':{version:'1.0.1'}}};
  fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(pkg));
  fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
  let r = assess(dir);
  assert(r.blockers.includes('package-lock-root-dependency-group-mismatch'));
  assert.deepStrictEqual(r.wrongGroupRootDeclarations,['dependencies:alpha']);
  lock.packages[''].dependencies=lock.packages[''].devDependencies;
  delete lock.packages[''].devDependencies;
  fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
  r=assess(dir);
  assert(!r.blockers.includes('package-lock-root-dependency-group-mismatch'));
  assert.deepStrictEqual(r.blockers,[]);
  console.log('Run654 root dependency group mismatch: 2 cases passed');
} finally { fs.rmSync(dir,{recursive:true,force:true}); }
