'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { inspectReadOnlyAdmissionSources, inspectReadOnlyAdmission } = require('../tools/dev-readonly-admission-preflight');
const root = path.resolve(__dirname, '..');
const main = fs.readFileSync(path.join(root, 'src/main.js'), 'utf8');
const flash = fs.readFileSync(path.join(root, 'src/flash.js'), 'utf8');
const cases = [
  ['production read-only flag removed', main.replace('readOnlyBeta: true,', 'readOnlyBeta: false,'), flash, 'production-readonly-flag-missing'],
  ['production read-only flag deleted', main.replace('readOnlyBeta: true,', ''), flash, 'production-readonly-flag-missing'],
  ['duplicate flag overrides read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n  readOnlyBeta: false,'), flash, 'production-readonly-flag-missing'],
  ['dynamic options spread can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n  ...runtimeOptions,'), flash, 'production-readonly-flag-missing'],
  ['computed option can override read-only', main.replace('  readOnlyBeta: true,', "  readOnlyBeta: true,\n  ['readOnlyBeta']: false,"), flash, 'production-readonly-flag-missing'],
  ['getter can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n  get readOnlyBeta() { return false; },'), flash, 'production-readonly-flag-missing'],
  ['deeper-indented spread can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n    ...runtimeOptions,'), flash, 'production-readonly-flag-missing'],
  ['tab-indented spread can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n\t...runtimeOptions,'), flash, 'production-readonly-flag-missing'],
  ['deeper-indented computed key can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n    ["readOnlyBeta"]: false,'), flash, 'production-readonly-flag-missing'],
  ['tab-indented getter can override read-only', main.replace('  readOnlyBeta: true,', '  readOnlyBeta: true,\n\tget readOnlyBeta() { return false; },'), flash, 'production-readonly-flag-missing'],
  // These inline overrides bypassed the old indentation-only regex. The
  // reviewed-constructor fingerprint must fail closed on every variation.
  ['inline spread after ordinary property', main.replace('  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject,', '  readOnlyBeta: true,\n  dataRoot, ...runtimeOptions,\n  getActiveProject,'), flash, 'production-flash-constructor-unreviewed'],
  ['inline computed read-only key', main.replace('  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject,', '  readOnlyBeta: true,\n  dataRoot, ["readOnlyBeta"]: false,\n  getActiveProject,'), flash, 'production-flash-constructor-unreviewed'],
  ['inline quoted read-only key', main.replace('  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject,', '  readOnlyBeta: true,\n  dataRoot, "readOnlyBeta": false,\n  getActiveProject,'), flash, 'production-flash-constructor-unreviewed'],
  ['inline read-only getter', main.replace('  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject,', '  readOnlyBeta: true,\n  dataRoot, get readOnlyBeta() { return false; },\n  getActiveProject,'), flash, 'production-flash-constructor-unreviewed'],
  ['unreviewed constructor option edit', main.replace('  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject,', '  readOnlyBeta: true,\n  dataRoot,\n  getActiveProject: () => null,'), flash, 'production-flash-constructor-unreviewed'],
  ['unreviewed constructor comment', main.replace('const flashManager = new FlashManager({', 'const flashManager = new FlashManager({\n  // unreviewed constructor edit\n'), flash, 'production-flash-constructor-unreviewed'],
  ['default write escape enabled', main, flash.replace("options.platform === 'test'", "options.platform === 'win32'"), 'flash-manager-default-readonly-contract-changed'],
  ['flash manager write rejection removed', main, flash.replace("this.readOnlyBeta && !['readProperties', 'read'].includes(normalized)", 'false'), 'flash-manager-write-denial-missing'],
  ['flash IPC guard removed', main.replace('flashManager.assertReadOnlyBetaOperation(operation);', ''), flash, 'flash-ipc-write-denial-missing'],
  ['automatic P01 write guard removed', main.replace("flashManager.assertReadOnlyBetaOperation('writeCalibration');", ''), flash, 'p01-auto-ipc-write-denial-missing'],
  ['automatic P01 write guard moved after start', main.replace("  flashManager.assertReadOnlyBetaOperation('writeCalibration');\n", '').replace("  emitP01Auto(next); return p01AutoSnapshot(next);", "  flashManager.assertReadOnlyBetaOperation('writeCalibration');\n  emitP01Auto(next); return p01AutoSnapshot(next);"), flash, 'p01-auto-ipc-write-denial-missing']
];
assert.deepEqual(inspectReadOnlyAdmissionSources(main, flash), { safe: true, blockers: [] });
assert.equal(inspectReadOnlyAdmission(root).safe, true);
for (const [name, mutatedMain, mutatedFlash, expected] of cases) {
  const result = inspectReadOnlyAdmissionSources(mutatedMain, mutatedFlash);
  assert.equal(result.safe, false, name);
  assert(result.blockers.includes(expected), `${name}: ${JSON.stringify(result.blockers)}`);
}
console.log(`Read-only admission preflight: ${cases.length + 2}/${cases.length + 2} checks passed (offline, no ECU access).`);
