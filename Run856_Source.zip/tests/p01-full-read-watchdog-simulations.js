const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { FlashManager, P01_BIN_SIZE } = require('../src/flash');
const { validateP01ReadFile } = require('../src/pcmhammer');
const { safeToRetryProfile, outputWasCreated, isSyntaxFailure, isPortOpenFailure, looksLikeCliUsageOnly } = require('../src/pcmhammer-integrated');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return true;
    await wait(20);
  }
  throw new Error('Timed out waiting for full-read watchdog simulation.');
}
function makeFixture(name, options = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), `tuniq-read-watchdog-${name}-`));
  const project = path.join(root, 'project');
  const data = path.join(root, 'data');
  const portable = path.join(root, 'PCM-Hammer');
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(project, 'Revisions'), { recursive: true });
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const executable = path.join(portable, 'PcmHammerCLI');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const events = [];
  const completed = [];
  const active = { id: `p-${name}`, name: `P01 ${name}`, folder: project, controller: 'P01' };
  const manager = new FlashManager({
    platform: 'test', allowSimulatedCliPrefixArgs: true, // synthetic Node mock only
    dataRoot: () => data,
    getActiveProject: () => active,
    getToolPath: () => portable,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
    releasePort: async () => ({ released: true }),
    appendActivity: () => {},
    emit: (channel, payload) => { if (channel === 'flash:progress') events.push(payload); },
    onReadComplete: async () => {},
    onSessionComplete: async session => completed.push(session),
    readWatchdogPollMs: options.pollMs || 20,
    readStallTimeoutMs: options.stallMs || 500
  });
  return { root, project, data, portable, mock, executable, events, completed, active, manager };
}
async function configure(fixture) {
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  await fixture.manager.probe({ executable: fixture.executable, prefixArgs: [fixture.mock] });
  fixture.manager.saveDevice('COM4');
}
async function runSlowRead() {
  const fixture = makeFixture('slow', { pollMs: 20, stallMs: 1500 });
  await configure(fixture);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'slow-silent-read';
  process.env.PCMHAMMER_MOCK_CHUNK_DELAY_MS = '70';
  await fixture.manager.start('read', { directPortHandoffAuthorized: true, directPortHandoffReason: 'focused read monitor test' });
  await waitFor(() => !fixture.manager.session, 8000);
  const history = fixture.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'completed read should be recorded');
  assert.equal(history.state, 'complete');
  assert.equal(history.outputInfo.size, P01_BIN_SIZE);
  const heartbeats = fixture.events.filter(item => item.readHeartbeat && item.operation === 'read');
  assert(heartbeats.length >= 2, 'quiet read should emit repeated live heartbeats');
  assert(heartbeats.some(item => Number(item.readHeartbeat.outputBytes) > 0), 'heartbeat should observe growing read file');
  assert(heartbeats.some(item => Number(item.progress) > 0 && Number(item.progress) < 100), 'read-file growth should produce visible progress before completion');
  assert(heartbeats.some(item => /still running|bytes received|waiting for PCM Hammer completion proof/i.test(item.phase || '')), 'phase should explain what the quiet read is doing');
  return fixture;
}
async function runStalledRead() {
  const fixture = makeFixture('stall', { pollMs: 20, stallMs: 180 });
  await configure(fixture);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'stalled-read';
  process.env.PCMHAMMER_MOCK_STALL_HOLD_MS = '5000';
  await fixture.manager.start('read', { directPortHandoffAuthorized: true, directPortHandoffReason: 'focused stalled-read test' });
  await waitFor(() => !fixture.manager.session, 8000);
  const history = fixture.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'stalled read should be recorded');
  assert.equal(history.state, 'failed');
  assert.equal(history.stopCode, 'read-stalled-no-progress');
  assert.equal(history.readWatchdogTriggered, true);
  assert(/completed Read Properties evidence was preserved/i.test(history.error || ''));
  assert(history.rejectedOutput && fs.existsSync(history.rejectedOutput), 'partial read should be renamed as rejected evidence');
  assert.notEqual(fs.statSync(history.rejectedOutput).size, P01_BIN_SIZE, 'rejected stalled file must not look complete');
  return fixture;
}
async function runReadDestinationGuard() {
  const fixture = makeFixture('output-guard');
  await configure(fixture);
  // The path checked for overwrite/symlink safety must be the same absolute
  // path handed to PCM Hammer, even when a caller supplies a relative name.
  const relativeOutput = path.relative(process.cwd(), path.join(fixture.project, 'Originals', 'relative-read.bin'));
  const relativePreflight = fixture.manager.preflight('read', { output: relativeOutput });
  assert.equal(relativePreflight.values.output, path.resolve(relativeOutput),
    'relative read output must be converted to the exact checked absolute destination');
  // First-run projects may need a new Originals subfolder; it is created only
  // after the ancestor chain is checked, then inspected again.
  const nested = path.join(fixture.project, 'Originals', 'new-session', 'fresh.bin');
  const nestedPreflight = fixture.manager.preflight('read', { output: nested });
  assert.equal(nestedPreflight.values.output, nested);
  assert(fs.statSync(path.dirname(nested)).isDirectory());
  const original = path.join(fixture.project, 'Originals', 'protected-original.bin');
  const partial = path.join(fixture.project, 'Originals', 'interrupted-read.bin');
  fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x42));
  fs.writeFileSync(partial, Buffer.alloc(211, 0x13));
  const originalBefore = fs.readFileSync(original);
  const partialBefore = fs.readFileSync(partial);
  for (const output of [original, partial]) {
    assert.throws(() => fixture.manager.preflight('read', { output }), error => error.code === 'read-output-exists');
    await assert.rejects(fixture.manager.start('read', { output }), error => error.code === 'read-output-exists');
  }
  assert.deepEqual(fs.readFileSync(original), originalBefore);
  assert.deepEqual(fs.readFileSync(partial), partialBefore);
  const link = path.join(fixture.project, 'Originals', 'dangling-output.bin');
  try {
    fs.symlinkSync(path.join(fixture.project, 'Originals', 'missing.bin'), link);
    assert.throws(() => fixture.manager.preflight('read', { output: link }), error => error.code === 'read-output-exists');
  } catch (error) { if (error.code !== 'EPERM' && error.code !== 'EACCES') throw error; }
  // Simulate another process creating the destination while COM ownership is
  // being transferred, after the synchronous preflight has already passed.
  const race = path.join(fixture.project, 'Originals', 'race.bin');
  fixture.manager.inspectExclusiveSession = async () => {
    fs.writeFileSync(race, Buffer.from('another process created this'));
    return { blocked: false, conflicts: [], warnings: [] };
  };
  await assert.rejects(fixture.manager.start('read', { output: race }), error => error.code === 'read-output-exists');
  assert.equal(fs.readFileSync(race, 'utf8'), 'another process created this');
  assert.equal(fixture.manager.session, null);
  assert.equal(fixture.manager.getHistory().filter(item => item.operation === 'read').length, 0);
  // Collision after COM handoff/cooldown must also fail before spawning CLI.
  fixture.manager.inspectExclusiveSession = async () => ({ blocked: false, conflicts: [], warnings: [] });
  const lateRace = path.join(fixture.project, 'Originals', 'late-race.bin');
  const originalSettle = fixture.manager.hardwareTransaction.settleBeforeOpen.bind(fixture.manager.hardwareTransaction);
  fixture.manager.hardwareTransaction.settleBeforeOpen = async (...args) => {
    const waited = await originalSettle(...args);
    fs.writeFileSync(lateRace, Buffer.from('late collision'));
    return waited;
  };
  await assert.rejects(fixture.manager.start('read', { output: lateRace }), error => error.code === 'read-output-exists');
  assert.equal(fs.readFileSync(lateRace, 'utf8'), 'late collision');
  assert.equal(fixture.manager.hardwareTransaction.snapshot().state, 'stopped');
  assert.equal(fixture.manager.portOwner.owner, 'idle');
  assert.equal(fixture.manager.session, null);
  // A symlinked parent must be rejected before CLI invocation or mkdir.
  const linkedParent = path.join(fixture.project, 'Linked-Originals');
  try {
    fs.symlinkSync(path.join(fixture.project, 'Originals'), linkedParent, process.platform === 'win32' ? 'junction' : 'dir');
    const linkedOutput = path.join(linkedParent, 'unsafe.bin');
    assert.throws(() => fixture.manager.preflight('read', { output: linkedOutput }), error => error.code === 'read-output-symlink-parent');
    await assert.rejects(fixture.manager.start('read', { output: linkedOutput }), error => error.code === 'read-output-symlink-parent');
    assert.equal(fs.existsSync(linkedOutput), false);
  } catch (error) { if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error; }
  fs.rmSync(fixture.root, { recursive: true, force: true });
}

// Regression: an unrelated process can create the destination after the
// asynchronous handoff check, immediately before a CLI attempt. That file is
// not TunIQ's partial read and must never be spawned into or quarantined.
async function runLastMomentReadCollisionGuard() {
  const fixture = makeFixture('last-moment-collision');
  const marker = Buffer.from('unrelated process owns this filename');
  const output = path.join(fixture.project, 'Originals', 'late-owner.bin');
  try {
    await configure(fixture);
    process.env.PCMHAMMER_MOCK_SCENARIO = 'slow-silent-read';
    const pinnedCheck = fixture.manager.assertPinnedCliIntegrity.bind(fixture.manager);
    let injected = false;
    fixture.manager.assertPinnedCliIntegrity = (...args) => {
      const result = pinnedCheck(...args);
      if (!injected && fixture.manager.session?.operation === 'read') {
        injected = true;
        fs.writeFileSync(output, marker);
      }
      return result;
    };
    await fixture.manager.start('read', { output, directPortHandoffAuthorized: true,
      directPortHandoffReason: 'synthetic final pre-spawn output collision' });
    await waitFor(() => !fixture.manager.session, 8000);
    const history = fixture.manager.getHistory().find(item => item.operation === 'read');
    assert(injected, 'test must inject collision after asynchronous handoff');
    assert(history && history.state === 'failed', 'collision must fail closed');
    assert.equal(history.stopCode, 'read-output-exists');
    assert.equal(history.deviceAttempts.length, 0, 'collision must stop before spawning PCM Hammer');
    const noChildLedger = fixture.manager.hardwareTransaction.snapshot();
    assert.equal(noChildLedger.state, 'stopped', 'pre-spawn refusal must stop the prepared transaction');
    assert.equal(noChildLedger.processClosedAt, null, 'pre-spawn refusal cannot fabricate a child close');
    assert.equal(noChildLedger.lastProcessStartedPreparationSequence, 0,
      'pre-spawn refusal cannot fabricate child-start proof');
    assert.deepEqual(fs.readFileSync(output), marker, 'foreign file must remain unchanged');
    assert.equal(history.rejectedOutput, undefined, 'foreign file must not be quarantined');
  } finally {
    fs.rmSync(fixture.root, { recursive: true, force: true });
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
  }
}

async function runZeroByteReadRetryGuard() {
  const fixture = makeFixture('zero-byte-retry', { pollMs: 20, stallMs: 2000 });
  await configure(fixture);
  const output = path.join(fixture.project, 'Originals', 'zero-byte-interrupted.bin');
  const usage = 'Usage: PcmHammerCLI\nOperations: read';
  assert.equal(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output }), false, 'generic usage footer alone cannot authorize retry');
  fs.writeFileSync(output, Buffer.alloc(0));
  assert.equal(outputWasCreated(output), true, 'zero-byte output is a protected interrupted read');
  assert.equal(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output }), false, 'zero-byte read output must prohibit profile fallback');
  const link = path.join(fixture.project, 'Originals', 'dangling-retry.bin');
  try {
    fs.symlinkSync(path.join(fixture.project, 'Originals', 'missing-target.bin'), link);
    assert.equal(outputWasCreated(link), true, 'dangling symlink must block output reuse');
  } catch (error) { if (error.code !== 'EPERM' && error.code !== 'EACCES') throw error; }
  fs.rmSync(output);
  process.env.PCMHAMMER_MOCK_SCENARIO = 'empty-read-open-failed';
  await fixture.manager.start('read', { output, directPortHandoffAuthorized: true, directPortHandoffReason: 'zero-byte interrupted read simulation' });
  await waitFor(() => !fixture.manager.session, 8000);
  const history = fixture.manager.getHistory().find(item => item.operation === 'read');
  assert(history && history.state === 'failed', 'mock CLI open failure must stop read');
  assert.equal(history.deviceAttempts.length, 1, 'zero-byte output must prevent all alternate-port and command-profile retries');
  assert(history.rejectedOutput && fs.existsSync(history.rejectedOutput), 'zero-byte output must be retained as rejected evidence');
  assert.equal(fs.statSync(history.rejectedOutput).size, 0);
  fs.rmSync(fixture.root, { recursive: true, force: true });
}

function runPortFailureUsageRetryGuard() {
  // Some CLI builds append generic usage text after a Windows COM-open error.
  // That is not evidence that the command syntax was rejected before opening
  // the adapter, so no alternate command profile should be attempted.
  const portFailureWithUsage = [
    'Error: could not open the selected device: timed out trying to open serial port COM4.',
    'Usage: PCM Hammer CLI --read --device COM4'
  ].join('\n');
  assert.equal(isSyntaxFailure(portFailureWithUsage, 1), false, 'COM-open failure is not a CLI syntax rejection');
  assert.equal(looksLikeCliUsageOnly(portFailureWithUsage), false, 'usage footer cannot hide COM-open failure');
  for (const operation of ['readProperties', 'read']) {
    assert.equal(safeToRetryProfile({ operation, text: portFailureWithUsage, exitCode: 1 }), false,
      `${operation} must not retry command syntax after a COM-open failure`);
  }
  const usageOnly = 'Usage: PCM Hammer CLI\nOperations: read';
  assert.equal(safeToRetryProfile({ operation: 'readProperties', text: usageOnly, exitCode: 64 }), false,
    'pure usage footer without explicit syntax rejection must not authorize retry');
}

// Windows/.NET serial errors can be followed by a generic CLI usage footer.
// They are device/runtime failures, never proof that the CLI syntax was wrong.
function runWindowsSerialErrorUsageGuard() {
  const runtimeFailures = [
    "System.IO.IOException: The port 'COM4' does not exist.",
    "System.IO.IOException: Access to port COM4 is denied.",
    "System.IO.IOException: The process cannot access the file because it is being used by another process."
  ];
  for (const failure of runtimeFailures) {
    const output = `${failure}\nUsage: PCM Hammer CLI\nOperations: read`;
    assert.equal(isPortOpenFailure(output), true, `must recognize runtime I/O failure: ${failure}`);
    assert.equal(looksLikeCliUsageOnly(output), false, 'usage footer cannot turn runtime failure into syntax error');
    assert.equal(isSyntaxFailure(output, 1), false, 'runtime failure cannot authorize syntax-profile fallback');
    for (const operation of ['readProperties', 'read']) {
      assert.equal(safeToRetryProfile({ operation, text: output, exitCode: 1 }), false,
        `${operation} must not cycle command profiles after Windows I/O failure`);
    }
  }
  assert.equal(safeToRetryProfile({ operation: 'readProperties', text: 'Error: unknown option --device\nUsage: PCM Hammer CLI', exitCode: 64 }), true,
    'genuine syntax-only failures must still allow bounded read-only fallback');
}

// Some Windows serial libraries omit "port" or "is" in access-denied
// messages. Do not treat those adapter-ownership failures as CLI syntax.
function runAdditionalComOwnershipGuard() {
  const errors = [
    'Error: Access to COM4 denied',
    "Error: Access to port 'COM4' denied",
    'Error: serial port COM4 is locked'
  ];
  for (const error of errors) {
    const mixed = `${error}\nUsage: PCM Hammer CLI\nOperations: read`;
    assert.equal(isPortOpenFailure(mixed), true, `must recognize COM ownership failure: ${error}`);
    assert.equal(isSyntaxFailure(mixed, 1), false, `must not misclassify COM ownership as syntax: ${error}`);
    for (const operation of ['readProperties', 'read']) {
      assert.equal(safeToRetryProfile({ operation, text: mixed, exitCode: 1 }), false,
        `${operation} must not retry profiles after COM ownership failure: ${error}`);
    }
  }
}

// A CLI may print generic usage after a failed ECU handshake, no-response
// timeout, or kernel transfer failure. These are runtime failures even if the
// log has no "Opening COM" line; trying another syntax profile is unsafe.
function runPcmRuntimeFailureUsageGuard() {
  const failures = [
    'Error: Failed to connect to PCM',
    'Error: No response from ECU',
    'Error: Timed out waiting for response',
    'Error: Kernel upload failed',
    'Error: Failed to read block 23 at address 0x00120000',
    'Error: Block 42 read failed: timeout',
    'Error: PCM read failed at address 0x001A0000',
    'Error: Checksum mismatch while reading PCM'
  ];
  for (const failure of failures) {
    const mixed = `${failure}\nUsage: PCM Hammer CLI\nOperations: read`;
    assert.equal(looksLikeCliUsageOnly(mixed), false, `runtime failure cannot be usage-only: ${failure}`);
    assert.equal(isSyntaxFailure(mixed, 1), false, `runtime failure cannot be syntax-only: ${failure}`);
    for (const operation of ['readProperties', 'read']) {
      assert.equal(safeToRetryProfile({ operation, text: mixed, exitCode: 1 }), false,
        `${operation} must not cycle profiles after runtime communication failure: ${failure}`);
    }
  }
  assert.equal(safeToRetryProfile({ operation: 'readProperties', text: 'Unknown option --device\nUsage: PCM Hammer CLI\nOperations: read', exitCode: 64 }), true,
    'a genuine command syntax rejection must retain bounded read-only fallback');
}

// A CLI can touch an ELM/STN adapter or exchange diagnostic frames before
// printing a generic usage footer. That is not a syntax-only rejection.
function runProtocolTrafficUsageGuard() {
  const examples = [
    'ELM327 adapter initialized',
    'STN1170 interface ready',
    'TX: 6C 10 F0 22 F1',
    'RX: 6C F0 10 62 F1',
    'Received response from ECU',
    'Sending diagnostic request',
    'Kernel loaded successfully'
  ];
  for (const proof of examples) {
    const mixed = `${proof}\nUnknown option\nUsage: PCM Hammer CLI\nOperations: read`;
    assert.equal(looksLikeCliUsageOnly(mixed), false, `adapter activity must not look syntax-only: ${proof}`);
    assert.equal(isSyntaxFailure(mixed, 64), false, `adapter activity cannot be syntax failure: ${proof}`);
    for (const operation of ['readProperties', 'read']) {
      assert.equal(safeToRetryProfile({ operation, text: mixed, exitCode: 64 }), false,
        `${operation} must not retry after adapter traffic: ${proof}`);
    }
  }
  assert.equal(safeToRetryProfile({ operation: 'read', text: 'Unknown option\nUsage: PCM Hammer CLI\nOperations: read', exitCode: 64 }), false,
    'Full Read CLI profile fallback must not proceed without a known output destination');
}

async function runMockProtocolTrafficUsageGuard() {
  const fixture = makeFixture('protocol-traffic-usage');
  try {
    await configure(fixture);
    process.env.PCMHAMMER_MOCK_SCENARIO = 'protocol-traffic-usage';
    const output = path.join(fixture.project, 'Originals', 'protocol-failed.bin');
    await fixture.manager.start('read', { output, directPortHandoffAuthorized: true,
      directPortHandoffReason: 'synthetic protocol activity only' });
    await waitFor(() => !fixture.manager.session, 8000);
    const history = fixture.manager.getHistory().find(item => item.operation === 'read');
    assert(history && history.state === 'failed', 'protocol activity followed by CLI usage must fail');
    assert.equal(history.deviceAttempts.length, 1, 'no second CLI profile may touch adapter after protocol activity');
    assert.equal(fs.existsSync(output), false, 'mock must not create a misleading complete BIN');
  } finally {
    fs.rmSync(fixture.root, { recursive: true, force: true });
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
  }
}

async function runMockPcmRuntimeFailureGuard() {
  const fixture = makeFixture('pcm-runtime-usage');
  try {
    await configure(fixture);
    process.env.PCMHAMMER_MOCK_SCENARIO = 'pcm-no-response-usage';
    await fixture.manager.start('readProperties', { directPortHandoffAuthorized: true, directPortHandoffReason: 'mock no-response runtime failure' });
    await waitFor(() => !fixture.manager.session, 8000);
    const history = fixture.manager.getHistory().find(item => item.operation === 'readProperties');
    assert(history && history.state === 'failed', 'mock PCM no-response must fail read-only operation');
    assert.equal(history.profileAttempts.length, 1, 'PCM runtime failure must stop after one CLI command profile');
  } finally {
    fs.rmSync(fixture.root, { recursive: true, force: true });
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
  }
}

// Regression: a CLI may append usage help to a read-block failure before
// creating its destination. That is ECU runtime evidence, not syntax proof.
// Never relaunch a different command profile on the same COM port.
async function runMockReadBlockFailureUsageGuard() {
  const fixture = makeFixture('read-block-runtime-usage');
  try {
    await configure(fixture);
    process.env.PCMHAMMER_MOCK_SCENARIO = 'read-block-failure-usage';
    const output = path.join(fixture.project, 'Originals', 'failed-block-read.bin');
    await fixture.manager.start('read', { output, directPortHandoffAuthorized: true,
      directPortHandoffReason: 'synthetic read-block runtime failure' });
    await waitFor(() => !fixture.manager.session, 8000);
    const history = fixture.manager.getHistory().find(item => item.operation === 'read');
    assert(history && history.state === 'failed', 'read-block runtime failure must fail closed');
    assert.equal(history.deviceAttempts.length, 1, 'read-block runtime failure must never cycle command profiles');
    assert.equal(fs.existsSync(output), false, 'mock failure must not create a misleading completed BIN');
  } finally {
    fs.rmSync(fixture.root, { recursive: true, force: true });
    delete process.env.PCMHAMMER_MOCK_SCENARIO;
  }
}

function runReadLinkIntegrityGuard() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-link-integrity-'));
  try {
    const original = path.join(root, 'protected-original.bin');
    const symlink = path.join(root, 'fake-new-read.bin');
    const hardlink = path.join(root, 'hardlinked-read.bin');
    const fresh = path.join(root, 'fresh-read.bin');
    fs.writeFileSync(original, Buffer.alloc(P01_BIN_SIZE, 0x44));
    fs.writeFileSync(fresh, Buffer.alloc(P01_BIN_SIZE, 0x45));
    assert.equal(validateP01ReadFile(fresh, { success: true }).valid, true, 'independent complete regular file must still validate');
    try {
      fs.symlinkSync(original, symlink);
      const result = validateP01ReadFile(symlink, { success: true });
      assert.equal(result.valid, false, 'a symlink to a valid original must never count as a new read');
      assert.equal(result.code, 'read-file-unsafe-link');
    } catch (error) { if (error.code !== 'EPERM' && error.code !== 'EACCES') throw error; }
    fs.linkSync(original, hardlink);
    const linked = validateP01ReadFile(hardlink, { success: true });
    assert.equal(linked.valid, false, 'a hard link to a protected original must never count as an independent read');
    assert.equal(linked.code, 'read-file-unsafe-link');
    assert.equal(fs.readFileSync(original).length, P01_BIN_SIZE, 'original must remain intact');
    assert.equal(validateP01ReadFile(path.join(root, 'missing.bin'), { success: true }).code, 'read-file-missing');
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}

function staticLiveUiContract() {
  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  const renderer = fs.readFileSync(path.join(__dirname, '..', 'src', 'renderer', 'app.js'), 'utf8');
  assert(main.includes("channel === 'flash:progress' && p01AutoManager"), 'Flash progress must refresh Guided P01 state live.');
  assert(main.includes('overlayP01LiveFlash'), 'Guided P01 snapshot must map live PCM Hammer progress.');
  assert(renderer.includes('auto.liveOperationPhase'), 'Guided P01 renderer must show live operation phase.');
  assert(renderer.includes('auto.liveOperationHeartbeat'), 'Guided P01 renderer must show process/read heartbeat.');
}
async function runP01FullReadWatchdogSimulations({ quiet = false } = {}) {
  staticLiveUiContract();
  await runSlowRead();
  await runStalledRead();
  await runReadDestinationGuard();
  await runLastMomentReadCollisionGuard();
  await runZeroByteReadRetryGuard();
  runReadLinkIntegrityGuard();
  runPortFailureUsageRetryGuard();
  runWindowsSerialErrorUsageGuard();
  runAdditionalComOwnershipGuard();
  runPcmRuntimeFailureUsageGuard();
  await runMockPcmRuntimeFailureGuard();
  await runMockReadBlockFailureUsageGuard();
  runProtocolTrafficUsageGuard();
  await runMockProtocolTrafficUsageGuard();
  if (!quiet) console.log('✓ P01 full-read monitor: heartbeat, stall stop, existing-output protection, and zero-byte retry stop, and link-integrity rejection, and COM-open/usage classification and Windows I/O failure rejection plus COM ownership variants and ECU runtime failure guards and protocol traffic retry stop (14/14)');
  return { passed: 14, total: 14 };
}
if (require.main === module) runP01FullReadWatchdogSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01FullReadWatchdogSimulations };
