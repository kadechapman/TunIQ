'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { inspect, exitCodeFor } = require('../tools/owner-windows-readiness-run687');
const root = path.resolve(__dirname, '..');
for (const controller of ['P01', 'E38', undefined]) {
  const result = inspect(root, { controller, os: 'unknown' }, 'Review VATS, fans, cam, and knock sensors');
  assert.equal(result.readyForUserTesting, false);
  assert.equal(result.readyForPublicRelease, false);
  assert.equal(result.ecmWriteAuthorized, false);
  assert.equal(exitCodeFor(result), 2);
  assert.equal(result.evidenceBlockers.length, 7);
  assert.equal(new Set(result.evidenceBlockers).size, 7);
  for (const value of Object.values(result.owner.calibrationGates)) assert.equal(value, false);
  for (const gate of ['electric-fan-output-enablement-not-verified', 'electric-fan-temperature-thresholds-not-verified', 'knock-protection-diagnostics-not-verified']) assert.ok(result.evidenceBlockers.includes(gate));
}
console.log('Run699 owner evidence-blocker assertions passed (3 controller fixtures)');
