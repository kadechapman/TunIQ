'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { stage, verifyStage, SOURCE_FILES, assertUnredirectedPath } = require('../tools/stage-readonly-preview');
const { ASSETS, CHANNELS, reply, admittedUrl, admittedMainFrameNavigation, admitPreviewIpcEvent, writeSmokeEvidence, assessPreviewNavigation, runPreviewNavigationRoundTrip, assessPreviewSettledState, NAV_SETTLE_MS } = require('../tools/readonly-preview-main');
const { pathToFileURL } = require('node:url');
const MAIN = fs.readFileSync(path.join(__dirname, '../tools/readonly-preview-main.js'), 'utf8');
const SCRIPT = fs.readFileSync(path.join(__dirname, '../tools/windows-build-offline-preview.ps1'), 'utf8');
let n = 0;
function check(what, fn) { fn(); n++; }
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-offline-stage-contract-'));
try {
  const staging = path.join(dir, 'staged');
  const report = stage(staging);
  check('stage has exactly reviewed source list',()=>assert.equal(report.files, 7));
  const files = [];
  function list(folder, prefix = '') {
    for (const ent of fs.readdirSync(folder, { withFileTypes:true })) {
      const rel = path.join(prefix,ent.name);
      if(ent.isDirectory())list(path.join(folder,ent.name),rel); else files.push(rel.replace(/\\/g,'/'));
    }
  }
  list(staging);
  for(const forbidden of ['src/main.js','src/flash.js','src/obd.js','src/pcmhammer.js',
    'src/pcmhammer-integrated.js','src/p01-auto.js','src/autonomous-tune.js','src/updater.js']) {
    check(`exclude ${forbidden}`,()=>assert(!files.includes(forbidden)));
  }
  check('no source wildcard',()=>assert(!JSON.stringify(require(path.join(staging,'package.json')).build.files).includes('*')));
  check('preview includes only allowlisted files',()=>{
    assert.deepEqual(files.sort(),[...SOURCE_FILES.map(([,target])=>target),'package.json','STAGING_SHA256.json'].sort());
  });
  check('offline stage has no dependencies at runtime',()=>assert.equal(require(path.join(staging,'package.json')).dependencies,undefined));
  // Run200: The staged offline build must not expose the production preload's
  // hardware and calibration IPC surface, even if main-process IPC denies it.
  check('offline stage uses a dedicated seven-method preload instead of production preload',()=>{
    const staged = fs.readFileSync(path.join(staging, 'src/preload.js'), 'utf8');
    const dedicated = fs.readFileSync(path.join(__dirname, '../tools/readonly-preview-preload.js'), 'utf8');
    const production = fs.readFileSync(path.join(__dirname, '../src/preload.js'), 'utf8');
    assert.equal(staged, dedicated);
    assert.notEqual(staged, production);
    const vm = require('node:vm');
    let api;
    const invocations = [];
    vm.runInNewContext(staged, {
      require(name) {
        assert.equal(name, 'electron');
        return {
          contextBridge: { exposeInMainWorld(name, value) {
            assert.equal(name, 'tuniq');
            api = value;
          } },
          ipcRenderer: { invoke(channel, ...args) {
            invocations.push({ channel, args });
            return { channel, args };
          } }
        };
      }
    }, { timeout: 1000 });
    const allowed = {
      getBootstrap: 'app:get-bootstrap',
      getKnowledgeState: 'knowledge:state',
      listProjects: 'project:list',
      listTuneLibrary: 'tune-library:list',
      getProjectFiles: 'project:files',
      getWorkspaceSummary: 'workspace:get-summary',
      setUiPreferences: 'settings:set-ui-preferences'
    };
    assert.deepEqual(Object.keys(api).sort(), Object.keys(allowed).sort());
    assert.equal(api.startFlashOperation, undefined);
    assert.equal(api.writeP01Auto, undefined);
    assert.equal(api.loadCalibration, undefined);
    assert.equal(api.openExternal, undefined);
    for (const [method, channel] of Object.entries(allowed)) {
      assert.equal(api[method]({ test: true }).channel, channel);
    }
    assert.deepEqual(invocations.map(item => item.channel), Object.values(allowed));
  });
  check('preview main requires only electron navigation and core nodes',()=>{
    const imports=[...MAIN.matchAll(/require\(['"]([^'"]+)['"]\)/g)].map(match=>match[1]);
    assert.deepEqual(imports.sort(),['./src/renderer-navigation-guard','electron','node:fs','node:os','node:path','node:url'].sort());
  });
  check('seven hardware-free bootstrap, tune-list and preference handlers',()=>{
    assert.equal((MAIN.match(/case '(?:app:get-bootstrap|knowledge:state|project:list|project:files|workspace:get-summary|settings:set-ui-preferences|tune-library:list)'/g)||[]).length,7);
    assert(MAIN.includes('ipcMain.handle(channel'));
  });
  check('no hardware commands in preview',()=>assert(!/require\(['"](?:\.\/)?(?:src\/)?(?:flash|obd|pcmhammer|p01-auto|main)(?:\.js)?['"]\)/.test(MAIN)));
  check('sandbox and context isolation',()=>{
    for(const guard of ['sandbox: true','nodeIntegration: false','contextIsolation: true','webSecurity: true','devTools: false'])assert(MAIN.includes(guard));
  });
  // Run205: asset URL allowlisting is not equivalent to top-level document
  // navigation admission. A file://styles.css navigation previously escaped
  // the intended single-document preview without a will-navigate veto.
  check('top-level navigation is restricted to the exact reviewed index document',()=>{
    const root = path.join(staging, 'src/renderer');
    const index = pathToFileURL(path.join(root, 'index.html')).href;
    const css = pathToFileURL(path.join(root, 'styles.css')).href;
    assert.equal(admittedMainFrameNavigation(index, root), true);
    assert.equal(admittedMainFrameNavigation(css, root), false);
    assert.equal(admittedMainFrameNavigation(index + '#settings', root), false);
    assert.equal(admittedMainFrameNavigation('https://example.invalid/', root), false);
    assert(MAIN.includes("window.webContents.on('will-navigate'"));
    assert(MAIN.includes('event.preventDefault()'));
    assert(MAIN.includes('admittedMainFrameNavigation(url)'));
  });
  check('network and permission denied',()=>{
    assert(MAIN.includes('onBeforeRequest'));
    assert(MAIN.includes('setPermissionRequestHandler'));
    assert(MAIN.includes('setWindowOpenHandler'));
  });
  // Run186: the old two-page smoke passed even with a broken Projects
  // sidebar handler. Exercise Garage, Projects, Settings, then Dashboard.
  check('native preview smoke validates navigation before approving renderer',()=>{
    assert(MAIN.includes('assessPreviewNavigation(navigation)'));
    assert(MAIN.includes("'preview-navigation-failed'"));
    assert(MAIN.indexOf('assessPreviewNavigation(navigation)') < MAIN.indexOf("finish(true, 'offline-renderer-ready')"));
  });
  const route = ['garage', 'workflow', 'flash', 'scanner', 'fullai', 'tunes', 'bridge', 'settings', 'dashboard'];
  check('native smoke route covers every actual sidebar page',()=>{
    const html = fs.readFileSync(path.join(__dirname, '../src/renderer/index.html'), 'utf8');
    const pages = [...html.matchAll(/<button data-page="([^"]+)"/g)].map(match=>match[1]);
    assert.deepEqual([...route].sort(), pages.sort());
    assert.equal(new Set(route).size, route.length);
  });
  const validProof = () => ({handlersBound:true, steps:route.map(page=>({page,
    sectionActive:true,sidebarActive:true,activePageCount:1,activeSidebarCount:1,
    selectedSectionId:page,selectedSidebarPage:page,pageVisible:true,warningVisible:true,
    writeControlsDisabled:true}))});
  // Run272: the staged native preview used to accept a navigation proof
  // even when every dangerous write control was enabled. Fail closed on
  // missing/false proof at any route; this is not a hardware test.
  check('navigation proof refuses enabled or unreported write controls',()=>{
    for (const page of route) for (const value of [false, null, undefined]) {
      const proof = validProof();
      proof.steps.find(step => step.page === page).writeControlsDisabled = value;
      assert.equal(assessPreviewNavigation(proof), false, `${page}: ${value}`);
    }
  });
  check('valid nine-page navigation round-trip passes',()=>{
    assert.equal(assessPreviewNavigation(validProof()),true);
  });
  for (const field of ['sectionActive','sidebarActive','activePageCount',
    'activeSidebarCount','selectedSectionId','selectedSidebarPage']) {
    check(`navigation smoke rejects wrong ${field} at Projects`,()=>{
      const evidence = validProof();
      evidence.steps[1][field] = field.includes('Count') ? 2 : field.startsWith('selected') ? 'garage' : false;
      assert.equal(assessPreviewNavigation(evidence),false);
    });
  }
  check('navigation smoke rejects missing no-ECU warning at any intermediate route',()=>{
    for (const page of route) {
      const proof = validProof();
      proof.steps.find(step => step.page === page).warningVisible = false;
      assert.equal(assessPreviewNavigation(proof), false, `${page} warning missing`);
    }
  });
  check('navigation smoke rejects missing, reordered, and unreviewed routes',()=>{
    const missing = validProof(); missing.steps.pop();
    const reordered = validProof(); [reordered.steps[0], reordered.steps[1]] = [reordered.steps[1], reordered.steps[0]];
    const unreviewed = validProof(); unreviewed.steps[2].page = 'unknown';
    assert.equal(assessPreviewNavigation(missing),false);
    assert.equal(assessPreviewNavigation(reordered),false);
    assert.equal(assessPreviewNavigation(unreviewed),false);
  });
  check('navigation smoke rejects malformed or missing proof',()=>{
    assert.equal(assessPreviewNavigation(null),false);
    assert.equal(assessPreviewNavigation({}),false);
    assert.equal(assessPreviewNavigation({...validProof(),handlersBound:false}),false);
  });
  // A fake DOM exercises the same serialized function used in native Electron.
  function fakeNavigationDocument(brokenPage = null, nonexclusive = false, extraPage = false, hiddenPage = null, offscreenPage = null, warningFault = null, pagePaintFault = null, enabledWriteAtPage = null) {
    let selected = 'dashboard';
    const warning = {id:'offline-dev-banner',parentElement:null,
      get textContent(){return warningFault?.page === selected && warningFault.mode === 'text'
        ? 'OFFLINE UI PREVIEW' : 'ALL ECU OPERATIONS DISABLED — NOT FOR VEHICLE USE';},
      getBoundingClientRect(){const left=warningFault?.page === selected && warningFault.mode === 'offscreen' ? 1400 : 0;
        return {left,top:0,right:left+900,bottom:32,width:900,height:32};}};
    const active = Object.fromEntries(['dashboard', ...route].map(page => [page, page === 'dashboard']));
    const classes = name => ({contains:key=>key==='active' && active[name]});
    const pages = Object.fromEntries(['dashboard',...route].map(name=>[name,{
      id:name,classList:classes(name), parentElement:null,
      getBoundingClientRect(){ const left=name===offscreenPage?1600:250;
        return {left,top:105,right:left+700,bottom:705,width:700,height:600}; }
    }]));
    const buttons = Object.fromEntries(['dashboard',...route].map(name=>[name,{
      dataset:{page:name}, classList:classes(name),
      onclick: name===brokenPage ? () => {} : () => {
        selected = name;
        for (const page of Object.keys(active)) active[page] = nonexclusive || page===name;
      },
      click(){this.onclick();}
    }]));
    return {
      defaultView: {innerWidth:1260,innerHeight:850,getComputedStyle(element){
        const warningVendor = element === warning && warningFault?.page === selected;
        const pageVendor = element.id === selected && pagePaintFault?.page === selected;
        return {display:element.id===hiddenPage || (element===warning && warningFault?.page===selected && warningFault.mode==='hidden')?'none':'block',visibility:'visible',
          opacity:'1',clipPath:'none',filter:'none',contentVisibility:'visible',
          webkitClipPath:(warningVendor && warningFault.mode === 'webkit-clip') ||
            (pageVendor && pagePaintFault.mode === 'webkit-clip') ? 'inset(100%)' : 'none',
          webkitMaskImage:(warningVendor && warningFault.mode === 'webkit-mask') ||
            (pageVendor && pagePaintFault.mode === 'webkit-mask') ? 'linear-gradient(transparent, transparent)' : 'none'};
      }},
      querySelector(selector){if(selector==='#offline-dev-banner') return warningFault?.page===selected && warningFault.mode==='missing' ? null : warning;
        return buttons[selector.match(/data-page="([^"]+)"/)?.[1]] || null;},
      querySelectorAll(selector){
        if (selector==='.page.active') return [
          ...Object.values(pages).filter(page=>page.classList.contains('active')),
          ...(extraPage ? [{id:'unreviewed'}] : [])];
        if (selector==='.app-sidebar button.active') return Object.values(buttons)
          .filter(button=>button.classList.contains('active'));
        return [];
      },
      getElementById(name){
        if (['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery'].includes(name)) {
          return { disabled: selected !== enabledWriteAtPage };
        }
        return pages[name] || null;
      }
    };
  }
  check('native navigation refuses enabled write control on every route',()=>{
    for (const page of route) {
      const proof = runPreviewNavigationRoundTrip(fakeNavigationDocument(
        null, false, false, null, null, null, null, page));
      assert.equal(assessPreviewNavigation(proof), false, page);
      assert.equal(proof.steps.find(step => step.page === page).writeControlsDisabled, false);
    }
  });
  check('actual nine-route sidebar click round-trip passes',()=>{
    const proof=runPreviewNavigationRoundTrip(fakeNavigationDocument());
    assert.deepEqual(proof.steps.map(step=>step.page),route);
    assert.equal(assessPreviewNavigation(proof),true);
  });
  for (const page of route) {
    check(`broken ${page} click handler blocks Windows preview`,()=>{
      assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(fakeNavigationDocument(page))),false);
    });
  }
  // Run240 regression: active sidebar/page classes are not proof that the
  // clicked page is visible. A hidden or offscreen non-Dashboard page must
  // fail native smoke instead of passing after the final Dashboard settles.
  for (const page of route) {
    check(`hidden ${page} route fails native smoke`,()=>{
      assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(
        fakeNavigationDocument(null,false,false,page))),false);
    });
    check(`offscreen ${page} route fails native smoke`,()=>{
      assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(
        fakeNavigationDocument(null,false,false,null,page))),false);
    });
  }
  // Run241: a no-ECU banner that vanishes only on an intermediate page
  // must fail the native route smoke even if it reappears on Dashboard.
  for (const page of route) for (const mode of ['missing','hidden','text','offscreen']) {
    check(`no-ECU warning ${mode} at ${page} fails native smoke`,()=>{
      const proof = runPreviewNavigationRoundTrip(fakeNavigationDocument(null,false,false,null,null,{page,mode}));
      assert.equal(assessPreviewNavigation(proof),false);
    });
  }
  // Run242 regression: a vendor-prefixed clipping/mask style can suppress
  // painting while unprefixed computed CSS properties still read 'none'.
  // Every route must reject an invisible warning or selected page.
  for (const page of route) for (const mode of ['webkit-clip', 'webkit-mask']) {
    check(`vendor ${mode} on no-ECU warning at ${page} fails native smoke`,()=>{
      const proof = runPreviewNavigationRoundTrip(fakeNavigationDocument(
        null,false,false,null,null,{page,mode}));
      assert.equal(assessPreviewNavigation(proof),false);
    });
    check(`vendor ${mode} on selected ${page} page fails native smoke`,()=>{
      const proof = runPreviewNavigationRoundTrip(fakeNavigationDocument(
        null,false,false,null,null,null,{page,mode}));
      assert.equal(assessPreviewNavigation(proof),false);
    });
  }
  check('simultaneously active pages or an unreviewed page fail',()=>{
    assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(fakeNavigationDocument(null,true))),false);
    assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(fakeNavigationDocument(null,false,true))),false);
  });
  check('native smoke uses real sidebar click path, not direct showPage',()=>{
    assert(MAIN.includes('runPreviewNavigationRoundTrip.toString()'));
    assert(!MAIN.includes("showPage('garage', {persist:false, record:false})"));
  });
  // Run149: a successful immediate click check missed the 180ms debounced
  // preference save. An async IPC rejection can produce an error toast after
  // the smoke has already approved the Windows preview.
  function settledDoc({ errorToast = false, pageCount = 1, sidebarCount = 1,
    appHidden = false, splashVisible = false, missingWarning = false,
    warningHidden = false, warningOpacity = '1', appOpacity = '1',
    warningVisibility = 'visible', warningText = 'OFFLINE UI PREVIEW — ALL ECU OPERATIONS DISABLED',
    appWidth = 800, appHeight = 600, warningTop = 0, warningLeft = 0,
    viewportWidth = 1260, viewportHeight = 850, warningAncestorOpacity = '1',
    warningClipPath = 'none', warningAncestorClipPath = 'none',
    warningFilter = 'none', warningAncestorFilter = 'none',
    warningContentVisibility = 'visible', warningAncestorContentVisibility = 'visible',
    appAncestorOpacity = '1', appAncestorFilter = 'none',
    appAncestorClipPath = 'none', appAncestorContentVisibility = 'visible',
    dashboardHidden = false, dashboardVisibility = 'visible', dashboardOpacity = '1',
    dashboardClipPath = 'none', dashboardFilter = 'none',
    dashboardContentVisibility = 'visible', dashboardLeft = 250, dashboardTop = 105,
    dashboardWidth = 800, dashboardHeight = 600,
    dashboardAncestorOpacity = '1', dashboardAncestorClipPath = 'none',
    writeControlsEnabled = false } = {}) {
    const appAncestor = { kind: 'app-ancestor', parentElement: null };
    const app = { kind: 'app', parentElement: appAncestor, getBoundingClientRect: () => ({width:appWidth,height:appHeight}) };
    const dashboardAncestor = { kind: 'dashboard-ancestor', parentElement: app };
    const dashboard = { kind: 'dashboard', parentElement: dashboardAncestor,
      getBoundingClientRect: () => ({left:dashboardLeft, top:dashboardTop,
        right:dashboardLeft+dashboardWidth, bottom:dashboardTop+dashboardHeight,
        width:dashboardWidth, height:dashboardHeight}) };
    const splash = { kind: 'splash' };
    const warningAncestor = { kind: 'warning-ancestor', parentElement: null };
    const warning = { kind: 'warning', parentElement: warningAncestor, textContent: warningText,
      getBoundingClientRect: () => ({left:warningLeft, top:warningTop,
        right:warningLeft+800, bottom:warningTop+(warningHidden?0:30),
        width:800,height:warningHidden?0:30}) };
    return {
      defaultView: {innerWidth:viewportWidth, innerHeight:viewportHeight, getComputedStyle(element) {
        if (element === app) return {display:appHidden?'none':'block',visibility:'visible',opacity:appOpacity};
        if (element === appAncestor) return {display:'block',visibility:'visible',opacity:appAncestorOpacity,
          clipPath:appAncestorClipPath, filter:appAncestorFilter, contentVisibility:appAncestorContentVisibility};
        if (element === dashboardAncestor) return {display:'block',visibility:'visible',
          opacity:dashboardAncestorOpacity, clipPath:dashboardAncestorClipPath};
        if (element === dashboard) return {display:dashboardHidden?'none':'block',
          visibility:dashboardVisibility, opacity:dashboardOpacity, clipPath:dashboardClipPath,
          filter:dashboardFilter, contentVisibility:dashboardContentVisibility};
        if (element === splash) return {display:splashVisible?'block':'none',visibility:'visible'};
        if (element === warning) return {display:warningHidden?'none':'block',visibility:warningVisibility,opacity:warningOpacity,
          clipPath:warningClipPath, filter:warningFilter, contentVisibility:warningContentVisibility};
        if (element === warningAncestor) return {display:'block',visibility:'visible',opacity:warningAncestorOpacity,
          clipPath:warningAncestorClipPath, filter:warningAncestorFilter, contentVisibility:warningAncestorContentVisibility};
        throw new Error('unknown fixture element');
      }},
      querySelector(selector) {
        if (selector === '#toastStack .app-toast.error') return errorToast ? {} : null;
        if (selector === '#app') return app;
        if (selector === '#splash') return splash;
        if (selector === '#offline-dev-banner') return missingWarning ? null : warning;
        if (selector === '#dashboard.active') return dashboard;
        if (selector === '.app-sidebar button[data-page="dashboard"].active') return {};
        return null;
      },
      getElementById(name) {
        return ['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery'].includes(name)
          ? { disabled: !writeControlsEnabled } : null;
      },
      querySelectorAll(selector) {
        if (selector === '.page.active') return Array(pageCount).fill({});
        if (selector === '.app-sidebar button.active') return Array(sidebarCount).fill({});
        return [];
      }
    };
  }
  // Run273: an unsafe initial Dashboard could be made safe by the first
  // sidebar click, letting a nine-page-only smoke certify a preview that
  // exposed enabled ECU write controls before user interaction. Require the
  // actual native smoke to inspect the ready Dashboard BEFORE clicking.
  check('native smoke rejects an unsafe initial Dashboard before navigation',()=>{
    const unsafeInitial = settledDoc({writeControlsEnabled:true});
    const safeAfterClick = runPreviewNavigationRoundTrip(fakeNavigationDocument());
    assert.equal(assessPreviewSettledState(unsafeInitial), false);
    assert.equal(assessPreviewNavigation(safeAfterClick), true,
      'later safe navigation alone does not establish initial safety');
    const initialGate = MAIN.indexOf("'preview-initial-safety-failed'");
    const navigation = MAIN.indexOf('runPreviewNavigationRoundTrip.toString()');
    const initialInspection = MAIN.indexOf('assessPreviewSettledState.toString()');
    assert(initialGate >= 0 && initialInspection >= 0 &&
      initialInspection < initialGate && initialGate < navigation,
      'native Electron must reject unsafe initial state before sidebar clicks');
    assert(MAIN.includes("'preview-initial-safety-inspection-failed'"));
    assert.equal((MAIN.match(/assessPreviewSettledState\.toString\(\)/g)||[]).length, 2,
      'initial and post-navigation states must both be inspected');
  });
  check('settled native preview refuses late-enabled write controls',()=>{
    assert.equal(assessPreviewSettledState(settledDoc({writeControlsEnabled:true})), false);
  });
  check('settled navigation passes only one dashboard page and sidebar selection',()=>{
    assert.equal(assessPreviewSettledState(settledDoc()), true);
  });
  // Run187: a hidden app, restored splash, or removed safety banner could
  // pass the old settled-state smoke if Dashboard still had active classes.
  for (const [label, options] of [
    ['hidden app', {appHidden:true}],
    ['zero-width app', {appWidth:0}],
    ['zero-height app', {appHeight:0}],
    ['visible splash', {splashVisible:true}],
    ['missing no-ECU warning', {missingWarning:true}],
    ['hidden no-ECU warning', {warningHidden:true}],
    ['transparent no-ECU warning', {warningOpacity:'0'}],
    ['nearly transparent no-ECU warning', {warningOpacity:'0.05'}],
    // Run218: CSS opacity is not inherited in getComputedStyle(). A fully
    // opaque banner inside a transparent body/wrapper is still invisible.
    ['transparent no-ECU warning ancestor', {warningAncestorOpacity:'0'}],
    ['nearly transparent no-ECU warning ancestor', {warningAncestorOpacity:'0.2'}],
    // Run219: opacity and viewport geometry cannot detect a fully clipped,
    // filter-transparent, or content-visibility-hidden mandatory warning.
    ['clip-path-hidden no-ECU warning', {warningClipPath:'inset(100%)'}],
    ['clip-path-hidden no-ECU warning ancestor', {warningAncestorClipPath:'inset(100%)'}],
    ['filter-transparent no-ECU warning', {warningFilter:'opacity(0)'}],
    ['filter-transparent no-ECU warning ancestor', {warningAncestorFilter:'opacity(0)'}],
    ['content-visibility-hidden no-ECU warning', {warningContentVisibility:'hidden'}],
    ['content-visibility-hidden no-ECU warning ancestor', {warningAncestorContentVisibility:'hidden'}],
    ['no-ECU warning moved below viewport', {warningTop:900}],
    ['no-ECU warning moved above viewport', {warningTop:-100}],
    ['no-ECU warning moved right of viewport', {warningLeft:1400}],
    ['no-ECU warning moved left of viewport', {warningLeft:-900}],
    ['collapsed no-ECU warning', {warningVisibility:'collapse'}],
    ['transparent app', {appOpacity:'0'}],
    ['transparent app-only wrapper', {appAncestorOpacity:'0'}],
    ['nearly transparent app-only wrapper', {appAncestorOpacity:'0.1'}],
    ['clipped app-only wrapper', {appAncestorClipPath:'inset(100%)'}],
    ['filter-transparent app-only wrapper', {appAncestorFilter:'opacity(0)'}],
    ['content-hidden app-only wrapper', {appAncestorContentVisibility:'hidden'}],
    ['warning text removed', {warningText:'Offline UI Preview'}]
  ]) {
    check(`settled navigation refuses ${label}`,()=>{
      assert.equal(assessPreviewSettledState(settledDoc(options)),false);
    });
  }
  // Run232: the selected Dashboard can have an active class while being
  // CSS-hidden, clipped, or moved outside the viewport. The app shell and
  // separate no-ECU banner remain visible, so the prior smoke approved a
  // blank/empty main screen. These are renderer-only negative fixtures.
  for (const [label, options] of [
    ['CSS-hidden selected dashboard', {dashboardHidden:true}],
    ['visibility-hidden selected dashboard', {dashboardVisibility:'hidden'}],
    ['transparent selected dashboard', {dashboardOpacity:'0'}],
    ['transparent dashboard-only ancestor', {dashboardAncestorOpacity:'0'}],
    ['clipped dashboard-only ancestor', {dashboardAncestorClipPath:'inset(100%)'}],
    ['clipped selected dashboard', {dashboardClipPath:'inset(100%)'}],
    ['filter-transparent selected dashboard', {dashboardFilter:'opacity(0)'}],
    ['content-hidden selected dashboard', {dashboardContentVisibility:'hidden'}],
    ['selected dashboard moved right of viewport', {dashboardLeft:1400}],
    ['selected dashboard moved below viewport', {dashboardTop:900}],
    ['zero-width selected dashboard', {dashboardWidth:0}],
    ['zero-height selected dashboard', {dashboardHeight:0}]
  ]) {
    check(`settled navigation refuses ${label}`,()=>{
      assert.equal(assessPreviewSettledState(settledDoc(options)),false);
    });
  }
  check('partially visible selected dashboard is accepted',()=>{
    assert.equal(assessPreviewSettledState(settledDoc({dashboardTop:-250})),true);
  });
  check('settled navigation refuses absent renderer style API',()=>{
    const doc=settledDoc(); delete doc.defaultView;
    assert.equal(assessPreviewSettledState(doc),false);
  });
  check('late preference-save error toast fails preview smoke',()=>{
    const doc = settledDoc({errorToast:true});
    assert.equal(assessPreviewNavigation(runPreviewNavigationRoundTrip(fakeNavigationDocument())),true,
      'original immediate navigation check misses a delayed error toast');
    assert.equal(assessPreviewSettledState(doc),false);
  });
  check('settled navigation rejects duplicate active pages or sidebar buttons',()=>{
    assert.equal(assessPreviewSettledState(settledDoc({pageCount:2})),false);
    assert.equal(assessPreviewSettledState(settledDoc({sidebarCount:2})),false);
  });
  check('native smoke waits past debounced preference save and checks late UI errors',()=>{
    assert(NAV_SETTLE_MS >= 500 && NAV_SETTLE_MS < 3000);
    assert(MAIN.includes('setTimeout(resolve, NAV_SETTLE_MS)'));
    assert(MAIN.includes('assessPreviewSettledState.toString()'));
    assert(MAIN.includes("'preview-navigation-post-click-error'"));
    const delay = MAIN.indexOf('setTimeout(resolve, NAV_SETTLE_MS)');
    const inspect = MAIN.lastIndexOf('assessPreviewSettledState.toString()');
    const approve = MAIN.indexOf("finish(true, 'offline-renderer-ready')");
    assert(delay > MAIN.indexOf('assessPreviewNavigation(navigation)'));
    assert(inspect > delay && approve > inspect);
  });
  check('preview displays unambiguous warning',()=>{
    const html=fs.readFileSync(path.join(staging,'src/renderer/index.html'),'utf8');
    assert(html.includes('ALL ECU OPERATIONS DISABLED'));
    assert(html.includes('Content-Security-Policy'));
  });
  // Run144: the staging manifest previously omitted package.json and had no
  // verifier. The Windows builder must reject modified renderer/package bytes
  // and unexpected files before launching Electron or packaging the preview.
  check('staged preview integrity includes package.json',()=>{
    const manifest = JSON.parse(fs.readFileSync(path.join(staging, 'STAGING_SHA256.json'), 'utf8'));
    assert.equal(manifest.length, SOURCE_FILES.length + 1);
    assert(manifest.some(item => item.path === 'package.json'));
    assert.equal(verifyStage(staging).files, SOURCE_FILES.length + 1);
  });
  check('staged preview CLI verifier succeeds on intact package',()=>{
    const result = spawnSync(process.execPath, [path.join(__dirname, '../tools/stage-readonly-preview.js'), '--verify', staging], {encoding:'utf8'});
    assert.equal(result.status, 0, result.stderr);
    assert.equal(JSON.parse(result.stdout).verified, true);
  });
  check('tampered renderer is rejected before native preview startup',()=>{
    const dest = path.join(dir, 'tampered-renderer');
    stage(dest);
    fs.appendFileSync(path.join(dest, 'src/renderer/app.js'), '\n// changed\n');
    const cli = spawnSync(process.execPath, [path.join(__dirname, '../tools/stage-readonly-preview.js'), '--verify', dest], {encoding:'utf8'});
    assert.equal(cli.status, 2, 'tampered stage must be rejected by Windows CLI');
  });
  // Run170: stage manifest is not a trusted independent digest. Rehashing a
  // modified renderer used to bypass verification even though its bytes no
  // longer matched the source checkpoint being packaged.
  function rewriteAndRehash(dest, relative, change) {
    const target = path.join(dest, relative);
    fs.writeFileSync(target, change(fs.readFileSync(target, 'utf8')));
    const manifestPath = path.join(dest, 'STAGING_SHA256.json');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const crypto = require('node:crypto');
    manifest.find(item => item.path === relative).sha256 =
      crypto.createHash('sha256').update(fs.readFileSync(target)).digest('hex');
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
  }
  check('rehashing an altered renderer cannot bypass source binding',()=>{
    const dest = path.join(dir, 'rehash-renderer');
    stage(dest);
    rewriteAndRehash(dest, 'src/renderer/app.js', text => text + '\n// modified after staging\n');
    assert.throws(()=>verifyStage(dest), /source-binding-mismatch/);
  });
  check('rehashing an altered HTML banner cannot bypass source binding',()=>{
    const dest = path.join(dir, 'rehash-html');
    stage(dest);
    rewriteAndRehash(dest, 'src/renderer/index.html', text =>
      text.replace('OFFLINE UI PREVIEW', 'UNVERIFIED UI PREVIEW'));
    assert.throws(()=>verifyStage(dest), /source-binding-mismatch/);
  });
  check('tampered package is rejected before native preview startup',()=>{
    const dest = path.join(dir, 'tampered-package');
    stage(dest);
    const pkg = path.join(dest, 'package.json');
    fs.appendFileSync(pkg, ' ');
    assert.throws(()=>verifyStage(dest), /integrity|hash/i);
  });
  check('unapproved extra file is rejected',()=>{
    const dest = path.join(dir, 'extra-source');
    stage(dest);
    fs.mkdirSync(path.join(dest, 'src', 'hardware'), {recursive:true});
    fs.writeFileSync(path.join(dest, 'src', 'hardware', 'flash.js'), 'not approved');
    assert.throws(()=>verifyStage(dest), /unapproved|unexpected/i);
  });
  check('unapproved empty directory is rejected',()=>{
    const dest = path.join(dir, 'extra-directory');
    stage(dest);
    fs.mkdirSync(path.join(dest, 'src', 'hardware'));
    assert.throws(()=>verifyStage(dest), /unapproved/i);
  });
  check('changed package metadata with rehashed manifest still rejected',()=>{
    const dest = path.join(dir, 'altered-build-contract');
    stage(dest);
    const pkgPath = path.join(dest, 'package.json');
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    pkg.main = 'src/main.js';
    fs.writeFileSync(pkgPath, JSON.stringify(pkg));
    const manifestPath = path.join(dest, 'STAGING_SHA256.json');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const crypto = require('node:crypto');
    manifest.find(x=>x.path === 'package.json').sha256 = crypto.createHash('sha256').update(fs.readFileSync(pkgPath)).digest('hex');
    fs.writeFileSync(manifestPath, JSON.stringify(manifest));
    assert.throws(()=>verifyStage(dest), /package|contract/i);
  });
  // Run171: electron-builder accepts additional package build options. The
  // old selected-field contract accepted a rehashed package that added
  // extraResources or extraFiles, potentially packaging unreviewed files.
  for (const [label, mutate] of [
    ['extraResources', pkg => { pkg.build.extraResources = [{ from: '../private-controller-files', to: 'controller-files' }]; }],
    ['extraFiles', pkg => { pkg.build.extraFiles = [{ from: '../private-controller-files', to: 'controller-files' }]; }],
    ['afterPack', pkg => { pkg.build.afterPack = '../unreviewed-hook.js'; }],
    ['top-level extra field', pkg => { pkg.config = { build: { extraResources: ['../unreviewed'] } }; }]
  ]) {
    check(`rehashed preview package cannot add ${label}`,()=>{
      const dest = path.join(dir, `unsafe-build-contract-${label.replace(/\s+/g,'-')}`);
      stage(dest);
      rewriteAndRehash(dest, 'package.json', text => {
        const pkg = JSON.parse(text);
        mutate(pkg);
        return JSON.stringify(pkg, null, 2) + '\n';
      });
      assert.throws(()=>verifyStage(dest), /unsafe-preview-package-contract/);
    });
  }
  check('Windows builder verifies staged hashes before smoke and packaging',()=>{
    const stageIndex = SCRIPT.indexOf('Stage strictly allowlisted, hardware-free Electron application');
    const verifyIndex = SCRIPT.indexOf('Verify staged preview file hashes and allowlist');
    const smokeIndex = SCRIPT.indexOf('Launch staged preview in real Electron');
    const reverifyIndex = SCRIPT.indexOf('Reverify staged preview before packaging');
    const packageIndex = SCRIPT.indexOf('Package hardware-free preview only');
    assert(stageIndex >= 0 && verifyIndex > stageIndex && smokeIndex > verifyIndex);
    assert(reverifyIndex > smokeIndex && packageIndex > reverifyIndex);
    assert(SCRIPT.includes("'tools/stage-readonly-preview.js','--verify',$stage"));
  });
  check('stage refuses overwrite',()=>assert.throws(()=>stage(staging),/empty/));
  // A late write-time failure is different from source validation failure:
  // all seven inputs may be valid, yet output creation can fail (e.g. ENOSPC).
  // The requested output must remain absent/empty, never partially usable.
  function withInjectedManifestWriteFailure(fn) {
    const original = fs.writeFileSync;
    fs.writeFileSync = function(file, ...args) {
      if (path.basename(String(file)) === 'STAGING_SHA256.json') {
        throw new Error('injected-write-failure');
      }
      return original.call(this, file, ...args);
    };
    try { fn(); } finally { fs.writeFileSync = original; }
  }
  const scratchEntries = () => fs.readdirSync(dir).filter(name => name.startsWith('.tuniq-preview-staging-'));
  check('late staging write failure leaves no partial output or scratch directory',()=>{
    const dest = path.join(dir, 'failed-stage');
    withInjectedManifestWriteFailure(()=>assert.throws(()=>stage(dest),/injected-write-failure/));
    assert.equal(fs.existsSync(dest), false);
    assert.deepEqual(scratchEntries(), []);
  });
  check('late write failure preserves a preexisting empty destination',()=>{
    const dest = path.join(dir, 'empty-failed-stage');
    fs.mkdirSync(dest);
    withInjectedManifestWriteFailure(()=>assert.throws(()=>stage(dest),/injected-write-failure/));
    assert.deepEqual(fs.readdirSync(dest), []);
    assert.deepEqual(scratchEntries(), []);
  });
  check('successful stage supports a preexisting empty destination',()=>{
    const dest = path.join(dir, 'empty-success-stage');
    fs.mkdirSync(dest);
    assert.equal(stage(dest).files, SOURCE_FILES.length);
    assert(fs.existsSync(path.join(dest, 'STAGING_SHA256.json')));
    assert.deepEqual(scratchEntries(), []);
  });
  // A malformed or redirected source must be rejected BEFORE writing even
  // one preview file. Run139 wrote partial output before checking later files.
  const fixtureRoot = path.join(dir, 'invalid-source-fixture');
  for (const [source] of SOURCE_FILES) {
    const from = path.join(__dirname, '..', source);
    const to = path.join(fixtureRoot, source);
    fs.mkdirSync(path.dirname(to), { recursive: true });
    fs.copyFileSync(from, to);
  }
  const fixtureScript = path.join(fixtureRoot, 'tools/stage-readonly-preview.js');
  fs.copyFileSync(path.join(__dirname, '../tools/stage-readonly-preview.js'), fixtureScript);
  const fixtureHtml = path.join(fixtureRoot, 'src/renderer/index.html');
  const originalHtml = fs.readFileSync(fixtureHtml, 'utf8');
  fs.writeFileSync(fixtureHtml, originalHtml.replace('</body>', '</b0dy>'));
  const invalidHtmlOutput = path.join(dir, 'invalid-html-stage');
  check('invalid renderer HTML leaves no partial staged preview',()=>{
    const result = spawnSync(process.execPath, [fixtureScript, '--output', invalidHtmlOutput], { encoding: 'utf8' });
    assert.equal(result.status, 2, result.stdout + result.stderr);
    assert.match(result.stderr, /Unexpected renderer HTML/);
    assert.equal(fs.existsSync(invalidHtmlOutput), false, 'partial staging output must not exist');
  });
  fs.writeFileSync(fixtureHtml, originalHtml);
  const unsafeSource = path.join(fixtureRoot, 'src/renderer/app.js');
  fs.unlinkSync(unsafeSource);
  fs.symlinkSync(path.join(fixtureRoot, 'src/renderer/styles.css'), unsafeSource);
  const unsafeSourceOutput = path.join(dir, 'unsafe-source-stage');
  check('unsafe later source leaves no partial staged preview',()=>{
    const result = spawnSync(process.execPath, [fixtureScript, '--output', unsafeSourceOutput], { encoding: 'utf8' });
    assert.equal(result.status, 2, result.stdout + result.stderr);
    assert.match(result.stderr, /Redirected preview path refused|Unsafe preview source/);
    assert.equal(fs.existsSync(unsafeSourceOutput), false, 'partial staging output must not exist');
  });
  // The preview stage must never create output inside its own source tree.
  // Previously this mutated the source checkout, despite refusing ancestors.
  const insideSource = fs.mkdtempSync(path.join(path.resolve(__dirname, '..'), '.tuniq-stage-inside-source-'));
  try {
    const insideOutput = path.join(insideSource, 'preview');
    check('stage refuses to write inside its source checkout',()=>{
      assert.throws(()=>stage(insideOutput),/Refusing to stage inside or over source tree/);
      assert.equal(fs.existsSync(insideOutput), false);
    });
  } finally { fs.rmSync(insideSource, {recursive:true,force:true}); }
  // Run138: staging previously followed a symlink to an empty destination,
  // creating preview files outside the caller's intended output directory.
  // A symlinked parent can redirect the output just as a leaf alias can.
  const realOutput = path.join(dir, 'real-output');
  fs.mkdirSync(realOutput);
  const redirectedOutput = path.join(dir, 'redirected-output');
  fs.symlinkSync(realOutput, redirectedOutput, 'dir');
  check('stage rejects redirected destination leaf',()=>{
    assert.throws(()=>stage(redirectedOutput),/Redirected preview path refused/);
    assert.deepEqual(fs.readdirSync(realOutput), []);
  });
  check('stage rejects redirected destination parent',()=>{
    assert.throws(()=>stage(path.join(redirectedOutput, 'child')),/Redirected preview path refused/);
    assert.deepEqual(fs.readdirSync(realOutput), []);
  });
  check('source ancestry guard rejects redirected parent',()=>{
    const source = path.join(dir, 'source-file');
    fs.writeFileSync(source, 'fixture');
    assert.throws(()=>assertUnredirectedPath(path.join(redirectedOutput, 'source-file')), /Redirected preview path refused/);
    assert.doesNotThrow(()=>assertUnredirectedPath(source));
  });
  check('script uses disposable source and refuses overwrite',()=>{
    assert(SCRIPT.includes('Join-Path $env:TEMP'));
    assert(SCRIPT.includes('Refusing to overwrite prior preview'));
    assert(SCRIPT.includes('-Attributes ReparsePoint'));
    assert(SCRIPT.includes('Refusing unsafe preview copy'));
    assert(SCRIPT.includes("$candidate = Join-Path $diagnostics 'package-lock.candidate.json'"));
    assert(SCRIPT.includes("Copy-Item -LiteralPath 'package-lock.json' -Destination $candidate -ErrorAction Stop"));
    assert(SCRIPT.indexOf('package-lock.candidate.json') < SCRIPT.indexOf('Install locked Electron dependencies'));
  });
  for (const keyword of ['npm.cmd','--package-lock-only','--ignore-scripts','--require-lock',
    'electron-renderer-runtime-smoke.js','--smoke','--win','dir','win-unpacked']) {
    check(`Windows script requires ${keyword}`,()=>assert(SCRIPT.includes(keyword)));
  }
  // Run202: use the documented electron-builder v26 --dir switch for an
  // unpacked Windows app. Treating `dir` as a positional Windows target is
  // ambiguous and can fail or produce an unexpected artifact on CLI changes.
  check('Windows packaging uses explicit unpacked-directory CLI switch',()=>{
    const command = SCRIPT.match(/Step 'Package hardware-free preview only \(NO installer\)' \$builder @\(([^\r\n]+)\)/);
    assert(command, 'missing Windows packaging command');
    assert.equal(command[1], "'--projectDir',$stage,'--win','--dir','--x64','--publish','never'");
    assert(!SCRIPT.includes("'--win','dir'"), 'ambiguous positional dir target');
  });
  check('script refuses to call production electron main',()=>{
    assert(!SCRIPT.includes('npm.cmd start'));
    assert(!SCRIPT.includes("@('run','dist:win')"));
    assert(!SCRIPT.includes('src/main.js\'\)'));
  });
  check('native renderer runtime has bounded startup and diagnostic proof',()=>{
    for (const marker of ['renderer-runtime.stdout.log', 'renderer-runtime.stderr.log',
      'renderer-runtime-evidence.json', '$rendererProcess.WaitForExit(45000)',
      'TUNIQ_RENDERER_SMOKE_NONCE', 'Isolated renderer runtime produced no evidence.',
      'Isolated renderer runtime evidence is incomplete, stale, or unsuccessful.']) {
      assert(SCRIPT.includes(marker), `missing ${marker}`);
    }
    assert(SCRIPT.indexOf('renderer-runtime-evidence.json') < SCRIPT.indexOf('Stage strictly allowlisted'));
  });
  check('staged Electron startup is bounded and uses the actual binary',()=>{
    assert(SCRIPT.includes('node_modules\\electron\\dist\\electron.exe'));
    assert(SCRIPT.includes('$stageProcess.WaitForExit(30000)'));
    assert(SCRIPT.includes('Stop-Process -Id $stageProcess.Id -Force'));
    assert(SCRIPT.includes('Staged Electron smoke timed out after 30 seconds.'));
    assert(SCRIPT.includes('Start-Process -FilePath $electron -ArgumentList $stageArgs'));
  });
  check('staged Electron path is quoted to handle Windows spaces',()=>{
    assert(SCRIPT.includes('$stageArgs ='));
    assert(SCRIPT.includes('$stage.Replace('));
    assert(SCRIPT.includes('\" --smoke'));
  });
  check('npm registry failure is fast and full suite is still a hard gate',()=>{
    assert(SCRIPT.includes('--fetch-retries=0'));
    assert(SCRIPT.includes('--fetch-timeout=15000'));
    assert(SCRIPT.indexOf('Resolve genuine npm lock graph') < SCRIPT.indexOf('Complete offline simulated suite'));
    assert(SCRIPT.indexOf('Complete offline simulated suite') < SCRIPT.indexOf('Stage strictly allowlisted'));
  });
  check('staged Electron smoke requires nonce-bound renderer evidence',()=>{
    for (const marker of ['stageNonce = [guid]::NewGuid()',
      'Staged Electron smoke produced no renderer evidence.',
      'Staged Electron renderer evidence is incomplete, stale, or unsuccessful.',
      'staged-smoke-evidence.json']) {
      assert(SCRIPT.includes(marker), `missing ${marker}`);
    }
    assert(SCRIPT.indexOf('staged-smoke-evidence.json') < SCRIPT.indexOf('Package hardware-free preview only'),
      'staged smoke must be checked before packaging');
  });
  check('successful preview output is unique and cannot overwrite prior builds',()=>{
    assert(SCRIPT.includes("'dev-build-output\\Offline-UI-Preview-' + [guid]::NewGuid().ToString('N')"));
    assert(SCRIPT.includes('Refusing to overwrite prior preview'));
  });
  check('native Electron diagnostics survive failed smoke processes',()=>{
    for (const name of ['staged-electron.stdout.log','staged-electron.stderr.log',
      'packaged-electron.stdout.log','packaged-electron.stderr.log',
      'delivered-electron.stdout.log','delivered-electron.stderr.log']) {
      assert(SCRIPT.includes(name), `missing native diagnostic stream: ${name}`);
    }
    assert.equal((SCRIPT.match(/-RedirectStandardOutput/g) || []).length, 4);
    assert.equal((SCRIPT.match(/-RedirectStandardError/g) || []).length, 4);
  });
  check('failed smoke evidence preserved before process exit gate',()=>{
    const staged = SCRIPT.indexOf("Copy-Item -LiteralPath $stageReport -Destination (Join-Path $diagnostics 'staged-smoke-evidence.json')");
    const packaged = SCRIPT.indexOf("Copy-Item -LiteralPath $smokeReport -Destination (Join-Path $diagnostics 'packaged-smoke-evidence.json')");
    assert(staged > SCRIPT.indexOf('$stageProcess.WaitForExit(30000)'));
    assert(packaged > SCRIPT.indexOf('$result.WaitForExit(30000)'));
    assert(staged < SCRIPT.indexOf('Validate staged Electron renderer evidence'));
    assert(packaged < SCRIPT.indexOf('Packaged smoke produced no evidence file.'));
    // Failure logs must not bypass the actual evidence and exit checks.
    assert(SCRIPT.includes('if ($stageProcess.ExitCode -ne 0)'));
    assert(SCRIPT.includes('if ($result.ExitCode -ne 0)'));
    assert(SCRIPT.includes('if ($smokeProof.kind -ne'));
  });
  check('delivered output is hashed and separately smoke-tested',()=>{
    for (const marker of ['Get-FileHash -LiteralPath $exe -Algorithm SHA256',
      'Get-FileHash -LiteralPath $deliveredExe -Algorithm SHA256',
      'Start-Process -FilePath $deliveredExe', 'delivered-smoke-evidence.json',
      'Delivered executable smoke evidence is incomplete, stale, or unsuccessful.']) {
      assert(SCRIPT.includes(marker), `missing delivered copy gate: ${marker}`);
    }
    assert(SCRIPT.indexOf('Copy-Item -LiteralPath (Join-Path $stage') <
      SCRIPT.indexOf('Start-Process -FilePath $deliveredExe'));
    assert(SCRIPT.indexOf('Start-Process -FilePath $deliveredExe') <
      SCRIPT.indexOf('Record packaged Windows PE integrity'));
  });
  check('Windows always attempts bounded, secret-free failure triage',()=>{
    assert(SCRIPT.includes('tools/diagnose-windows-preview.js'));
    assert(SCRIPT.includes('$diagnostics --write'));
    assert(SCRIPT.includes('if ($transcriptStarted) { Stop-Transcript | Out-Null }'));
    assert(SCRIPT.indexOf('build-outcome.json') < SCRIPT.lastIndexOf('tools/diagnose-windows-preview.js'));
  });
  check('Windows failure leaves safe machine-readable outcome',()=>{
    for (const marker of ["$script:currentStep = $Title", "build-outcome.json",
      "fullTunIQVerified = $false", "hardwareUsed = $false",
      "windowsRuntimeVerified = $script:buildSucceeded"]) {
      assert(SCRIPT.includes(marker), `missing ${marker}`);
    }
    assert(!SCRIPT.includes('ConvertTo-Json -InputObject $env:'), 'never log env secrets');
  });
  check('packaged Windows smoke requires nonce-bound file proof',()=>{
    for(const marker of ['TUNIQ_PREVIEW_SMOKE_REPORT','TUNIQ_PREVIEW_SMOKE_NONCE',
      'packaged-smoke-evidence.json','offline-renderer-ready','smokeProof.nonce -ne $nonce']) {
      assert(SCRIPT.includes(marker), `missing ${marker}`);
    }
    assert(SCRIPT.indexOf('package-lock.candidate.json') < SCRIPT.indexOf("@('ci'"),
      'candidate lock must be saved before npm ci');
    assert(SCRIPT.includes('Start-Transcript'));
    assert(SCRIPT.includes('Stop-Transcript'));
  });
  const nonce='a'.repeat(32);
  const evidenceDir=path.join(os.tmpdir(),`TunIQ-preview-${'b'.repeat(32)}`);
  fs.mkdirSync(evidenceDir,{recursive:true});
  try {
    const file=path.join(evidenceDir,`smoke-${nonce}.json`);
    check('write nonce-bound smoke evidence exactly once',()=>{
      const result=writeSmokeEvidence({passed:true,reason:'offline-renderer-ready'},file,nonce);
      assert.equal(result.hardwareAvailable,false);
      assert.equal(result.writeHandlersRegistered,false);
      assert.equal(JSON.parse(fs.readFileSync(file,'utf8')).nonce,nonce);
      assert.throws(()=>writeSmokeEvidence({passed:true,reason:'offline-renderer-ready'},file,nonce),/EEXIST/);
    });
    check('reject spoofed or external smoke evidence paths',()=>{
      assert.throws(()=>writeSmokeEvidence({passed:true},path.join(dir,`smoke-${nonce}.json`),nonce),/disposable/);
      assert.throws(()=>writeSmokeEvidence({passed:true},path.join(evidenceDir,'other.json'),nonce),/disposable/);
      assert.throws(()=>writeSmokeEvidence({passed:true},file,'BAD'),/invalid-smoke/);
    });
  } finally { fs.rmSync(evidenceDir,{recursive:true,force:true}); }
  check('preview package contains no packaged updater module',()=>assert(!files.includes('node_modules/electron-updater')));
  check('exact seven hardware-free simulated IPC channels',()=>assert.deepEqual(CHANNELS,[
    'app:get-bootstrap','knowledge:state','project:list','project:files','workspace:get-summary',
    'settings:set-ui-preferences','tune-library:list']));
  check('navigation preference saves are handled in memory, without a disk write',()=>{
    const saved = reply('settings:set-ui-preferences', { lastPage: 'garage',
      recentPages: ['garage','dashboard'], scrollPositions: { dashboard: 120 },
      sidebarCollapsed: true });
    assert.equal(saved.uiPreferences.lastPage, 'garage');
    assert.equal(saved.uiPreferences.scrollPositions.dashboard, 120);
    assert.equal(reply('app:get-bootstrap').settings.uiPreferences.lastPage, 'garage');
    // Returned objects must not be able to mutate the in-memory preference store.
    saved.uiPreferences.scrollPositions.dashboard = 999;
    saved.uiPreferences.recentPages.push('flash');
    assert.equal(reply('app:get-bootstrap').settings.uiPreferences.scrollPositions.dashboard, 120);
    assert.deepEqual(reply('app:get-bootstrap').settings.uiPreferences.recentPages, ['garage','dashboard']);
    assert(MAIN.includes('ipcMain.handle(channel, (event, payload) => {'));
    assert(MAIN.includes('admitPreviewIpcEvent(event, window?.webContents)'));
    assert(!/writeFileSync|appendFileSync/.test(MAIN.slice(MAIN.indexOf('function updatePreviewPreferences'), MAIN.indexOf('function reply'))));
  });
  check('invalid preference payloads and hardware channels remain denied',()=>{
    for (const payload of [null, [], {lastPage:'../flash'}, {flashEnabled:true},
      {scrollPositions:{dashboard:-1}}, {recentPages:['../../private']},
      {sidebarCollapsed:'true'}]) {
      assert.throws(()=>reply('settings:set-ui-preferences', payload),/invalid-preview-preferences/);
    }
    assert.deepEqual(reply('tune-library:list'), []);
    assert.throws(()=>reply('tune-library:import', {file:'calibration.bin'}),/offline-preview-ipc-denied/);
    assert.throws(()=>reply('flash:start', {enabled:true}),/offline-preview-ipc-denied/);
    assert.throws(()=>reply('device:connect', {}),/offline-preview-ipc-denied/);
  });
  // Run188: the old handler called reply(channel,payload) for every IPC
  // sender. A subframe or different BrowserWindow could receive even the
  // preview bootstrap, despite not being the reviewed top-level document.
  function ipcFixture() {
    const root = path.join(staging, 'src/renderer');
    const frame = { url: pathToFileURL(path.join(root, 'index.html')).href };
    const contents = { mainFrame: frame, isDestroyed: () => false };
    return { root, frame, contents, event: { sender: contents, senderFrame: frame } };
  }
  check('top-level reviewed preview document can use inert IPC',()=>{
    const f=ipcFixture();
    assert.equal(admitPreviewIpcEvent(f.event,f.contents,f.root),true);
  });
  // Run215: URL identity alone is insufficient for IPC admission. If the
  // reviewed index.html gains a second hardlink, the asset allowlist rejects
  // it but the previous IPC guard still trusted its unchanged file:// URL.
  check('preview IPC refuses hardlinked index document even at reviewed URL',()=>{
    const f=ipcFixture();
    const index=path.join(f.root,'index.html');
    const alias=path.join(f.root,'index-hardlink.html');
    fs.linkSync(index,alias);
    try {
      assert.equal(admittedUrl(f.frame.url,f.root),false);
      assert.equal(admitPreviewIpcEvent(f.event,f.contents,f.root),false);
    } finally { fs.unlinkSync(alias); }
  });
  check('different BrowserWindow cannot use preview IPC',()=>{
    const f=ipcFixture();
    assert.equal(admitPreviewIpcEvent({...f.event,sender:{}},f.contents,f.root),false);
  });
  check('subframe cannot use preview IPC even with identical URL',()=>{
    const f=ipcFixture();
    assert.equal(admitPreviewIpcEvent({...f.event,senderFrame:{url:f.frame.url}},f.contents,f.root),false);
  });
  for (const [label, url] of [
    ['external origin','https://example.invalid/'],
    ['other local asset',pathToFileURL(path.join(staging,'src/renderer/app.js')).href],
    ['fragment',pathToFileURL(path.join(staging,'src/renderer/index.html')).href+'#other'],
    ['query',pathToFileURL(path.join(staging,'src/renderer/index.html')).href+'?x=1']
  ]) {
    check(`preview IPC refuses ${label}`,()=>{
      const f=ipcFixture(); f.frame.url=url;
      assert.equal(admitPreviewIpcEvent(f.event,f.contents,f.root),false);
    });
  }
  check('missing frame or sender cannot use preview IPC',()=>{
    const f=ipcFixture();
    assert.equal(admitPreviewIpcEvent({},f.contents,f.root),false);
    assert.equal(admitPreviewIpcEvent(f.event,null,f.root),false);
  });
  check('destroyed webContents cannot use preview IPC',()=>{
    const f=ipcFixture(); f.contents.isDestroyed=()=>true;
    assert.equal(admitPreviewIpcEvent(f.event,f.contents,f.root),false);
  });
  check('native IPC registration invokes frame guard before reply',()=>{
    assert(MAIN.includes('admitPreviewIpcEvent(event, window?.webContents)'));
    assert(MAIN.indexOf('admitPreviewIpcEvent(event, window?.webContents)') <
      MAIN.indexOf('return reply(channel, payload);'));
  });
  check('nonbootstrap IPC is rejected',()=>assert.throws(()=>reply('flash:start'),/denied/));
  check('flash is blocked in bootstrap',()=>assert.equal(reply('app:get-bootstrap').flash.status,'blocked'));
  // Run314: the Electron offline preview (not only the standalone browser
  // bridge) must not share a mutable flash-history array across responses.
  check('offline flash snapshots cannot inherit forged success history',()=>{
    const first = reply('app:get-bootstrap');
    const workspace = reply('workspace:get-summary');
    assert.notStrictEqual(first.flash, workspace.flash);
    assert.notStrictEqual(first.flash.history, workspace.flash.history);
    first.flash.history.push({ status: 'success', operation: 'flash-write', forged: true });
    first.flash.status = 'success';
    workspace.flash.history.push({ status: 'success', forged: true });
    const next = reply('app:get-bootstrap');
    const nextWorkspace = reply('workspace:get-summary');
    for (const response of [next, nextWorkspace]) {
      assert.equal(response.flash.status, 'blocked');
      assert.deepEqual(response.flash.history, []);
    }
  });
  check('project fixtures contain no private vehicle data',()=>assert.deepEqual(reply('project:list'),[]));
  for (const file of ASSETS) {
    check(`admit reviewed ${file}`,()=>assert.equal(admittedUrl(pathToFileURL(path.join(staging,'src/renderer',file)).href,path.join(staging,'src/renderer')), true));
  }
  for (const file of ['../preload.js','../renderer-navigation-guard.js','missing.js']) {
    check(`reject unapproved ${file}`,()=>assert.equal(admittedUrl(pathToFileURL(path.join(staging,'src/renderer',file)).href,path.join(staging,'src/renderer')),false));
  }
  for (const url of ['https://example.com/','file:///C:/Windows/System32/drivers/etc/hosts','data:text/javascript,alert(1)',
    pathToFileURL(path.join(staging,'src/renderer/app.js')).href+'?unexpected=1',
    pathToFileURL(path.join(staging,'src/renderer/app.js')).href+'#fragment']) {
    check('reject unsafe URL',()=>assert.equal(admittedUrl(url,path.join(staging,'src/renderer')),false));
  }
  const redirect = path.join(staging,'src/renderer','shortcut.js');
  fs.symlinkSync(path.join(staging,'src/renderer/app.js'), redirect);
  check('symlink alias is denied',()=>assert.equal(admittedUrl(pathToFileURL(redirect).href,path.join(staging,'src/renderer')),false));
  const hardlink = path.join(staging,'src/renderer','styles-copy.css');
  fs.linkSync(path.join(staging,'src/renderer/styles.css'),hardlink);
  check('hardlinked approved asset is denied',()=>assert.equal(admittedUrl(pathToFileURL(path.join(staging,'src/renderer/styles.css')).href,path.join(staging,'src/renderer')),false));
  fs.unlinkSync(redirect);fs.unlinkSync(hardlink);
  console.log(`Offline Electron preview packaging regressions: ${n}/${n} passed (no Windows execution).`);
} finally { fs.rmSync(dir,{recursive:true,force:true}); }
