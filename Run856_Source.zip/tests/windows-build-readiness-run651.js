'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run651-'));
try {
  const pkg = { name: 'fixture', version: '1.0.0', dependencies: { alpha: '^1.0.0' }, devDependencies: { alpha: '^2.0.0' } };
  const lock = { lockfileVersion: 3, packages: { '': { name: 'fixture', version: '1.0.0', dependencies: { alpha: '^1.0.0' }, devDependencies: { alpha: '^2.0.0' } }, 'node_modules/alpha': { version: '2.0.0' } } };
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(lock));
  let result = assess(root);
  assert(result.blockers.includes('package-json-dependency-group-conflict'));
  assert.deepStrictEqual(result.conflictingPackageDependencySpecs, ['alpha']);
  pkg.devDependencies.alpha = '^1.0.0';
  lock.packages[''].devDependencies.alpha = '^1.0.0';
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(lock));
  result = assess(root);
  assert(!result.blockers.includes('package-json-dependency-group-conflict'));
  assert.deepStrictEqual(result.conflictingPackageDependencySpecs, []);
  console.log('Run651 conflicting dependency group fixtures: 2 passed');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
