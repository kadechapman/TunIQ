'use strict';
// Offline CLI-profile selection regression. No executable, serial port, or ECU is used.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { safeToRetryProfile } = require('../src/pcmhammer-integrated');

function runPcmHammerRetryExitProofSimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-retry-exit-'));
  let passed = 0;
  try {
    const output = path.join(folder, 'unused.bin');
    const usage = 'Unknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full';
    for (const exitCode of [null, undefined, '64', 0, -1, -1073741819, 3221225477, 9009, Number.MAX_SAFE_INTEGER + 1, NaN, Infinity, false]) {
      assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode, output }), false,
        `ambiguous/normal child exit ${String(exitCode)} must never authorize another Full Read CLI profile`);
      passed++;
    }
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output }), true,
      'genuine numeric nonzero syntax-only exit may retry before output exists'); passed++;
    for (const missingOutput of [path.join(folder, 'missing', 'read.bin'),
      path.join(folder, 'missing', 'nested', 'read.bin')]) {
      assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output: missingOutput }), false,
        'missing backup parent must never authorize a second CLI profile'); passed++;
    }

    assert.strictEqual(safeToRetryProfile({ operation: 'readProperties', text: usage, exitCode: 1 }), true,
      'Read Properties syntax-only fallback remains supported'); passed++;
    assert.strictEqual(safeToRetryProfile({ operation: 'testWrite', text: usage, exitCode: 64 }), false,
      'write-related operations must never use automatic CLI profile retry'); passed++;
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64 }), false,
      'Full Read retry requires an explicit output destination'); passed++;
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output: path.join(folder, 'NUL.bin') }), false,
      'Windows reserved device names cannot be retried as BIN paths'); passed++;
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output: '//server/share/read.bin' }), false,
      'network and device namespace paths cannot be retried'); passed++;
    const realFolder = path.join(folder, 'real');
    const linkedFolder = path.join(folder, 'redirect');
    fs.mkdirSync(realFolder);
    try {
      fs.symlinkSync(realFolder, linkedFolder, 'dir');
      assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output: path.join(linkedFolder, 'unused.bin') }), false,
        'a symlink/junction ancestor must never authorize another Full Read profile'); passed++;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }
    fs.writeFileSync(output, Buffer.alloc(0));
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: usage, exitCode: 64, output }), false,
      'even zero-byte output prohibits another Full Read attempt'); passed++;
    assert.strictEqual(safeToRetryProfile({ operation: 'read', text: 'Opening serial port COM4\nUnknown option --device', exitCode: 64 }), false,
      'communication evidence prohibits profile retry'); passed++;
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) {
  const result = runPcmHammerRetryExitProofSimulations();
  console.log(`PCM Hammer retry exit-proof simulations: ${result.passed}/${result.passed} passed (offline only)`);
}
module.exports = { runPcmHammerRetryExitProofSimulations };
