const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { reviewP01Request, parseP01SafetyFacts } = require('../src/p01-request-review');
const { buildGoalProposal } = require('../src/goal-executor');
const { selectGoalMapCandidates } = require('../src/p01-auto');

function workspace(projectId = 'p01-any-os') {
  return {
    mode: 'xdf', projectId, modified: {}, tables: {
      vats: {
        name: 'Vehicle Anti Theft System Enable', description: 'VATS operating mode', unit: '',
        rowHeaders: ['Value'], colHeaders: ['Value'], values: [[1]],
        enumLabels: [{ index: 0, value: 'Disabled' }, { index: 1, value: 'Enabled' }]
      },
      fans: {
        name: 'Cooling Fan Temperature Control', description: 'Electric fan coolant temperature thresholds', unit: 'deg F',
        rowHeaders: ['Fan 1 On', 'Fan 1 Off', 'Fan 2 On', 'Fan 2 Off'], colHeaders: ['Value'],
        values: [[205], [198], [215], [208]], min: 130, max: 235
      }
    }
  };
}

function runP01UniversalRequestSimulations(options = {}) {
  const quiet = Boolean(options.quiet);
  const active = { id: 'p01-any-os', name: 'Customer P01', controller: 'P01', os: '12587603' };

  const lowRisk = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS and set both electric fans on at 210 F and off at 190 F.'
  });
  assert.equal(lowRisk.ready, true);
  assert.deepEqual(lowRisk.parsed.intents.map(item => item.type), ['vats-disable', 'fan-control']);
  assert.equal(lowRisk.os, '12587603');
  assert.equal(lowRisk.protections.length, 5);

  // Run360: Contradictory controller OS claims without an `OS ID:` label
  // previously passed the quick-service gate. They are not controller proof,
  // and a conflicting OS must block the entire VATS/fan proposal.
  for (const suffix of [
    'My PCM actually runs 12212156',
    'The ECM runs 12212156',
    'PCM runs 12212156',
    'The controller currently uses 12212156',
    'The PCM is running OS 12212156',
    'The ECM reports OS 12212156',
    'My ECU actually runs 12212156',
    'The ECU reports OS 12212156'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `contradictory controller OS admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing exact-OS conflict review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /(?:full tune request is not supported|request OS conflicts)/i,
    `partial VATS/fan proposal despite conflicting controller OS: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${suffix}`);
  }
  for (const suffix of [
    'My PCM actually runs 12587603',
    'The ECM reports OS 12587603',
    'The ECU reports OS 12587603',
    'The controller uses 12587603',
    'The PCM runs 5.3 liters',
    'The PCM has 2 fan outputs',
    'Check whether the PCM runs a different OS'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `unrelated or matching controller text misclassified: ${suffix}`);
  }

  // Run380: A combined calibration request must never silently treat physically
  // absent knock sensors as consent to disable knock protection. This is
  // request triage only; it makes no ECU-specific mapping or hardware change.
  for (const statement of [
    'Both knock sensors were pulled',
    'The knock sensors are gone',
    'I yanked both knock sensors'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${statement}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `missing knock sensors admitted: ${statement}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock diagnostic review: ${statement}`);
    // Run391: Review denial must also prevent a partial VATS/fan proposal
    // or mutation when the sensors have physically been removed.
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /full tune request is not supported/i,
    `partial proposal despite removed knock sensors: ${statement}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${statement}`);
  }

  // Run383: Disconnected sensor hardware and absent harness wiring also require
  // explicit knock-system diagnostics, not an implicit knock-protection delete.
  // Verify combined VATS/fan requests cannot produce partial workspace changes.
  for (const statement of [
    'Both knock sensors are unplugged',
    'The knock sensor connectors are disconnected',
    'I removed the knock sensor wiring harness',
    'The knock sensors are not installed'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${statement}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `disconnected knock hardware admitted: ${statement}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock diagnostic review: ${statement}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /full tune request is not supported/i,
    `partial proposal despite disconnected knock hardware: ${statement}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${statement}`);
  }

  // Run356: A bypassed/spoofed knock feedback *path* is not necessarily
  // described as sensor deletion. It still requires independent diagnostics
  // before an otherwise supported VATS/fan request; no hardware is touched.
  for (const suffix of [
    'The knock sensor signal is bypassed',
    'The knock sensor input was jumpered',
    'Knock detection has been bypassed',
    'The knock sensor feedback was spoofed',
    'Knock monitoring has been bridged'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `defeated knock feedback path admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock feedback diagnostic review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite bypassed knock feedback: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${suffix}`);
  }
  for (const suffix of [
    'Check whether the knock sensor signal is bypassed',
    'Inspect if the knock sensor input was jumpered',
    'Is the knock sensor signal bypassed?',
    'The knock sensor signal is not bypassed',
    "The knock sensor feedback hasn't been spoofed",
    'The knock sensor input was never jumpered'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic or non-defeat context misclassified: ${suffix}`);
  }

  // Run357: Reported electrical failures cannot be treated as fan-temperature
  // tuning alone. All values below are synthetic; no relay/fuse or OS is
  // assumed to be compatible, and rejected requests never mutate a workspace.
  for (const suffix of [
    'The electric fan fuse is blown',
    'Fan relay fuse has failed',
    'The fan relay is burnt out',
    'The fan relay contacts are welded shut',
    'The PCM fan output driver is damaged',
    'Fan relay wiring is shorted'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `failed fan circuit admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-circuit-fault'),
      `fan circuit diagnostic blocker missing: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite circuit fault: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${suffix}`);
  }
  for (const suffix of [
    'The electric fan fuse is not blown',
    'The fan relay fuse has not failed',
    'Check whether the fan relay is burnt out',
    'Inspect if the PCM fan output driver is damaged',
    'Is the fan relay fuse blown?',
    'Fan relay wiring is not shorted'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-circuit-fault'),
      `negated/diagnostic fan circuit fault misclassified: ${suffix}`);
  }

  // Run349: Incomplete fan relay/output wiring is a separate commissioning
  // blocker even if the request includes a complete fan temperature pair.
  // These are synthetic statements, never proof of physical wiring or pins.
  for (const suffix of [
    "Fan relays aren't wired to the ECM",
    "Fan relay wiring isn't complete",
    'Fan relays have not been connected',
    'The fan output harness is disconnected',
    "The ECM fan relay hasn't been installed",
    'Fan relay wires aren’t hooked up'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `incomplete fan circuit admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-circuit-incomplete'),
      `independent fan circuit diagnostic review omitted: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({
      request, workspace: draft, activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal despite incomplete fan wiring: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated after fan wiring rejection: ${suffix}`);
  }
  for (const suffix of [
    'Are the fan relays not connected?',
    'Are fan relays not connected?',
    'Have fan relays not been connected?',
    "Check whether fan relay wiring isn't complete",
    "The fan relays aren't disconnected",
    'The fan relays are connected',
    'The fan relay wiring is complete',
    'I have not checked the fan relays'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-circuit-incomplete'),
      `non-fault fan context incorrectly classified: ${suffix}`);
  }

  // Run351: A fan output reported as not enabled is a separate diagnostic
  // blocker, not a temperature-table instruction. These are synthetic text
  // cases, NOT actual ECM flags, verified setpoints, or wiring evidence.
  for (const suffix of [
    "The PCM fan output isn't enabled",
    'The fan relay outputs are not enabled',
    'The ECM fan driver has never been enabled',
    "My fan relay output isn't active",
    'The fan output enable flag is false',
    'My PCM is not configured for electric fan outputs'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `inactive fan output admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-unverified'),
      `missing separate fan-output diagnostics: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /fan|full tune request/i,
    `partial VATS/fan proposal admitted despite inactive output: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace changed after rejection: ${suffix}`);
  }
  for (const suffix of [
    'Check whether the PCM fan output is not enabled',
    "Inspect if the PCM fan output isn't enabled",
    'The PCM fan output is enabled',
    'The fan output enable flag is true',
    "The fan relay output isn't disabled",
    'The PCM is configured for electric fan outputs'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`});
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-unverified'),
      `healthy or diagnostic fan-output context misclassified: ${suffix}`);
  }

  // Run352: A disabled output described as a configuration/state assignment
  // is not an enabled relay. Mixed VATS/fan-temperature requests must be
  // rejected without touching the workspace; test numbers are synthetic.
  for (const suffix of [
    'The ECM fan output is set to disabled',
    'The PCM fan output is currently set to off',
    'Fan relay outputs are configured as disabled',
    'The fan output enable flag is set to false',
    'The ECM fan outputs have been switched off',
    'The fan relay output is marked inactive'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `configured-off fan output admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-unverified'),
      `missing configured-off fan diagnostic review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /fan|full tune request/i,
    `partial VATS/fan proposal admitted despite disabled output: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `workspace changed after rejection: ${suffix}`);
  }
  for (const suffix of [
    'Check whether the ECM fan output is set to disabled',
    'Is the ECM fan output set to off?',
    'The ECM fan output is not set to disabled',
    'The PCM fan output is set to on',
    'The fan output enable flag is set to true',
    'The fan relay outputs are configured as enabled'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`});
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-unverified'),
      `healthy or diagnostic configured-output context misclassified: ${suffix}`);
  }

  // Run330: A completed electric-fan wiring change is NOT evidence that the
  // PCM output enable flag and the temperature pair are separately verified.
  // Do not silently propose only VATS/temperatures while dropping wiring work.
  // These are synthetic syntax fixtures, not verified fan pins or setpoints.
  for (const suffix of [
    'I wired in dual electric fans',
    'The electric fans are wired into the PCM',
    'The electric fans are already hooked up',
    'I connected the electric fans to relays',
    'We wired up electric fans'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `fan hardware commissioning omitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `fan output independent review missing: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /fan|full tune request/i,
    `direct planner admitted fan hardware change: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `rejected fan request mutated workspace: ${suffix}`);
  }
  for (const suffix of [
    'Check whether the electric fans are wired in',
    'Inspect if electric fans are already hooked up',
    'The electric fans are not wired in',
    'I have not connected the electric fans to relays',
    'I did not wire in electric fans'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`});
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `negative/diagnostic fan wiring treated as commissioned: ${suffix}`);
  }

  // Run346: A completed fan RELAY/OUTPUT wiring claim is not proof that the
  // PCM output is enabled. The earlier fan-wiring pattern only recognized
  // "fans are wired", silently omitting relay/output-first statements from
  // an otherwise parsable VATS/temperature request. Text fixtures only.
  for (const suffix of [
    'My fan relays are wired to the ECM',
    'The PCM fan outputs are wired to relays',
    'The fan relay harness is connected',
    'The fan output wiring is complete'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `fan relay/output wiring silently omitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `fan output requires independent review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /fan|full tune request/i);
    assert.equal(JSON.stringify(draft), before);
  }
  for (const suffix of [
    'Check whether my fan relays are wired to the ECM',
    'Inspect if the PCM fan outputs are wired to relays',
    'My fan relays are not wired to the ECM',
    'The fan relay harness is not connected',
    'Is the fan output wiring complete?'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`});
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `diagnostic or negative fan wiring incorrectly commissioned: ${suffix}`);
  }

  // Run347: Passive installation/completion of the fan relay circuit is not
  // proof that the ECM output is enabled. Do not silently admit only VATS and
  // temperature edits. Synthetic syntax fixtures, not physical calibration.
  for (const suffix of [
    'The fan relays have been installed',
    'My fan relay wiring has been completed',
    'The fan relay harness was fitted',
    'My fan relays are installed',
    'The fan output harness was installed'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `passive fan circuit installation omitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `fan circuit requires independent output review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /fan|full tune request/i);
    assert.equal(JSON.stringify(draft), before);
  }
  for (const suffix of [
    'Check whether the fan relays have been installed',
    'Inspect if my fan relay wiring has been completed',
    'The fan relays have not been installed',
    'My fan relay harness was never fitted',
    'Have the fan relays been installed?'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`});
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `diagnostic/negative fan installation misclassified: ${suffix}`);
  }

  // Run348: Common contractions can report absent physical knock feedback.
  // This must block an otherwise parsable VATS/fan request, without asserting
  // a controller-specific DTC or granting permission to disable knock control.
  for (const suffix of [
    "My knock sensors aren't plugged in",
    "The knock sensors aren't connected",
    "The knock sensors weren't reinstalled",
    "The knock sensor isn't hooked up",
    "My knock sensors haven't been connected",
    "The knock sensors aren’t fitted"
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `contracted knock feedback loss silently omitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock diagnostic review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /knock|full tune request/i);
    assert.equal(JSON.stringify(draft), before);
  }
  for (const suffix of [
    "Check whether the knock sensors aren't plugged in",
    "Diagnose if the knock sensors weren't reinstalled",
    "The knock sensors aren't missing",
    "The knock sensors aren't unplugged",
    "Aren't the knock sensors plugged in?",
    "The knock sensors are connected"
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`});
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic/preservation statement misclassified: ${suffix}`);
  }

  // Run332: A smooth/chrome valley cover with no knock-sensor provision is
  // a physical configuration issue, not proof of working knock protection.
  // Synthetic text only: no ECU OS, pin, or camshaft mapping is inferred.
  for (const suffix of [
    'I installed a smooth valley cover without knock sensor holes',
    'The replacement valley cover has no provisions for knock sensors',
    'My chrome valley cover lacks knock sensor mounting holes',
    'My new valley cover has no knock sensor ports',
    'My engine has no knock sensor ports'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `missing valley-cover knock review: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `physical knock-feedback configuration omitted: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /knock|full tune request/i,
    `partial proposal admitted missing knock mounting provision: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `rejected valley-cover request mutated workspace: ${suffix}`);
  }
  for (const suffix of [
    'Check whether my valley cover has no knock sensor ports',
    'Inspect if the replacement valley cover has no provisions for knock sensors',
    'I did not install a smooth valley cover without knock sensor holes',
    'My valley cover has knock sensor ports',
    'Check whether my engine has no knock sensor ports'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`});
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `inspection/negative valley-cover statement falsely blocked: ${suffix}`);
  }

  // Run331: Future omission, open knock circuits, explicit feedback defeat,
  // and simulator substitution are NOT equivalent to healthy sensors. Block
  // a mixed VATS/fan proposal rather than silently dropping the knock issue.
  // These are syntax-only fixtures, never verified controller/DTC mappings.
  for (const suffix of [
    'Knock sensors will not be installed',
    'My knock sensor circuits are open',
    'I need to eliminate knock sensor feedback',
    'I plugged in knock sensor simulators',
    'We will not install the knock sensors',
    'Knock sensor circuit is open',
    'We installed knock sensor emulators'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `missing knock-feedback review: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `knock-feedback fault silently omitted: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /knock|full tune request/i,
    `direct planner admitted compromised knock feedback: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `rejected knock request mutated workspace: ${suffix}`);
  }
  for (const suffix of [
    'Check whether knock sensors will not be installed',
    'Inspect if my knock sensor circuits are open',
    'Check whether knock sensor feedback was eliminated',
    'Check if knock sensor simulators were installed',
    'Knock sensor circuits are not open',
    'I will not eliminate knock sensor feedback'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic/healthy knock wording misclassified: ${suffix}`);
  }

  // Run324: Passive physical knock-sensor loss and requested DTC-reporting
  // suppression must not disappear from a combined VATS/fan plan. The
  // identifiers and temperatures below are synthetic text fixtures only.
  for (const [suffix, expectedType] of [
    ['My knock sensors are physically removed', 'knock-sensor-delete'],
    ['My knock sensor is physically missing', 'knock-sensor-delete'],
    ['My knock sensors were still physically absent', 'knock-sensor-delete'],
    ['Knock sensor DTC reporting should be suppressed', 'knock-diagnostic-suppression'],
    ['Knock sensor code reporting must be disabled', 'knock-diagnostic-suppression']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `unsafe knock state admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === expectedType),
      `missing independent knock-system diagnostic review: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /knock|full tune request/i,
    `direct planner admitted unsafe knock state: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `rejected knock request mutated workspace: ${suffix}`);
  }
  for (const suffix of [
    'Check whether my knock sensors are physically removed',
    'My knock sensors are not physically removed',
    'Are my knock sensors physically missing?',
    'Knock sensor DTC reporting should remain enabled',
    'Check whether knock sensor DTC reporting should be suppressed'
  ]) {
    const review = reviewP01Request({activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`});
    assert(!review.unresolvedRequests.some(item =>
      ['knock-sensor-delete', 'knock-diagnostic-suppression'].includes(item.type)),
      `diagnostic or healthy knock statement incorrectly blocked: ${suffix}`);
  }

  // Run328: Passive reports of absent physical knock feedback must block
  // the whole mixed request, including the direct planner. Diagnostic
  // questions and explicitly healthy states must not be misclassified.
  for (const suffix of [
    'My knock sensors have been physically disconnected',
    'My knock sensors are no longer installed',
    'The knock sensors are out',
    'My knock sensors are no longer connected',
    'The knock sensors are still physically unplugged'
  ]) {
    const request = `Disable VATS and set both electric fans on at 210 F and off at 190 F. ${suffix}.`;
    const review = reviewP01Request({activeProject: active, request});
    assert.equal(review.ready, false, `missing physical knock feedback admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing separate knock diagnostics: ${suffix}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []}), /knock|full tune request/i,
    `direct planner admitted missing physical knock feedback: ${suffix}`);
    assert.equal(JSON.stringify(draft), before, `rejected request mutated workspace: ${suffix}`);
  }
  for (const suffix of [
    'Check whether my knock sensors are physically disconnected',
    'Check if the knock sensors are no longer installed',
    'Are the knock sensors out?',
    'My knock sensors are not physically disconnected',
    'My knock sensors are not out',
    'My knock sensors are out of specification'
  ]) {
    const request = `Disable VATS and set both electric fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({activeProject: active, request});
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic or healthy knock state blocked: ${suffix}`);
  }

  // Run299: Numbered knock-sensor loss must block a combined VATS/fan
  // request rather than silently approving the safe-looking subset. These
  // are synthetic text fixtures, not verified ECM sensor-bank mappings.
  for (const suffix of [
    'knock sensor #2 was unplugged',
    'knock sensor 1 is disconnected',
    'cut knock sensor 2 wire',
    'knock sensor #1 missing',
    'knock sensor bank 2 was unplugged',
    'knock sensor 1 was replaced with a resistor'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `numbered knock fault was ignored: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock-system review: ${suffix}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: [] }), /knock|full tune request/i,
    `direct proposal admitted numbered knock fault: ${suffix}`);
  }
  for (const suffix of [
    'Check whether knock sensor 1 is disconnected',
    'Inspect if knock sensor #2 was unplugged',
    'Log knock sensor 1 voltage',
    'knock sensor 1 is connected'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `read-only/healthy numbered knock wording incorrectly treated as removal: ${suffix}`);
  }

  // Run300: Numbered knock-sensor OFF directives expressed as a future or
  // desired state must never be silently dropped from VATS/fan proposals.
  // These are syntax-only fixtures; neither sensor numbering nor OS bits
  // are established by these requests.
  for (const suffix of [
    'knock sensor #1 should be disabled',
    'knock sensor 2 needs to be disabled',
    'knock sensor bank 2 must be bypassed',
    'knock sensor #2 will be removed',
    'knock sensor #1 is to be ignored',
    'knock sensor 2 should stay off'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `numbered knock OFF directive was ignored: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock protection review: ${suffix}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: [] }), /knock|full tune request/i,
    `direct proposal admitted numbered knock OFF directive: ${suffix}`);
  }
  for (const suffix of [
    'Check whether knock sensor 1 should be disabled',
    'Inspect if knock sensor #2 will be removed',
    'knock sensor 2 should stay connected',
    'knock sensor #1 should be tested'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic/healthy numbered knock wording incorrectly blocked: ${suffix}`);
  }

  // Run301: Assignment-style numbered knock sensor OFF/absent states must
  // block a combined VATS/fan proposal pending separate diagnostics. No
  // sensor-bank/OS mapping or physical calibration is inferred from text.
  for (const suffix of [
    'knock sensor #1 = disabled',
    'knock sensor 2: off',
    'knock sensor bank 2 = false',
    'knock sensor #2 enable flag = 0',
    'knock sensor 1 status: removed',
    'knock sensor 1 = unplugged'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `numbered knock assignment admitted: ${suffix}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing numbered knock assignment diagnostic review: ${suffix}`);
    const draftWorkspace = workspace();
    const originalWorkspace = JSON.stringify(draftWorkspace);
    assert.throws(() => buildGoalProposal({ request, workspace: draftWorkspace, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /knock|full tune request/i,
    `direct planner admitted numbered knock assignment: ${suffix}`);
    assert.equal(JSON.stringify(draftWorkspace), originalWorkspace,
      `rejected numbered knock assignment changed workspace: ${suffix}`);
  }
  for (const suffix of [
    'knock sensor #1 = connected',
    'knock sensor 2 status: active',
    'Check whether knock sensor #1 = disabled',
    'Inspect if knock sensor bank 2 enable flag = 0'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${suffix}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `healthy/diagnostic numbered knock assignment blocked: ${suffix}`);
  }

  // Run211: an OS identifier supplied in the request must not silently
  // disagree with the active P01 project while the planner proposes VATS/fan
  // changes. These numeric IDs are fixture labels, NOT the owner's OS.
  const conflictingOsRequest = 'Disable VATS and set fans on at 210 F and off at 190 F. ECM OS ID: 12212156.';
  const conflictingOsReview = reviewP01Request({ activeProject: active, request: conflictingOsRequest });
  assert.equal(conflictingOsReview.ready, false, 'request/project OS disagreement was accepted');
  assert(conflictingOsReview.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
    'missing explicit OS mismatch review');
  assert.throws(() => buildGoalProposal({
    request: conflictingOsRequest, workspace: workspace(), activeProject: active,
    confirmations: {}, ruleFolders: []
  }), /OS.*(?:conflict|mismatch|disagree)/i, 'direct proposal bypassed OS mismatch review');
  const matchingOsRequest = 'Disable VATS and set fans on at 210 F and off at 190 F. ECM OS ID: 12587603.';
  assert.equal(reviewP01Request({ activeProject: active, request: matchingOsRequest }).ready, true,
    'matching explicit OS label was incorrectly rejected (not proof of a verified OS map)');
  const contradictoryOsRequest = 'Disable VATS and set fans on at 210 F and off at 190 F. OS: 12587603; OS ID: 12212156.';
  assert.equal(reviewP01Request({ activeProject: active, request: contradictoryOsRequest }).ready, false,
    'two conflicting explicit OS IDs were accepted');

  // Run212: OSID / OS-ID / OS_ID and identifier wording are common
  // request labels. They must not bypass exact-OS consistency checks merely
  // because they lack the spaces used by the earlier `OS ID` fixture.
  // All identifiers here are synthetic fixture labels, not ECM evidence.
  for (const label of [
    'ECM OSID: 12212156',
    'PCM OS-ID = 12212156',
    'ECM OS_ID #12212156',
    'OS identifier: 12212156',
    'Operating-system identifier 12212156',
    'OS is 12212156'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `OS label mismatch was admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing exact-OS mismatch blocker for: ${label}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /OS.*(?:conflict|mismatch|disagree)/i, `direct proposal bypassed OS label: ${label}`);
  }
  for (const label of ['ECM OSID: 12587603', 'PCM OS-ID = 12587603', 'OS identifier: 12587603']) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}.`;
    assert.equal(reviewP01Request({ activeProject: active, request }).ready, true,
      `matching OS syntax was incorrectly blocked: ${label}`);
  }
  const conflictingAliases = 'Disable VATS and set fans on at 210 F and off at 190 F. OSID: 12587603; OS-ID: 12212156.';
  assert.equal(reviewP01Request({ activeProject: active, request: conflictingAliases }).ready, false,
    'contradictory OSID and OS-ID labels were admitted');

  // Run246: malformed, placeholder, or nonnumeric explicitly supplied OS
  // labels must not disappear from the exact-OS consistency gate. All OS
  // numbers here are synthetic fixture labels, not verified controller IDs.
  for (const label of [
    'OS ID: 1258760300', 'OS ID: 0', 'OSID: 12587603A',
    'OS ID: unknown', 'OS is TBD', 'Operating system identifier: N/A',
    'OS: 12587603/12212156', 'OS ID: 12587603.0'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unverified OS label was accepted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing malformed-OS review: ${label}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /OS.*(?:conflict|mismatch|disagree)/i, `direct proposal bypassed invalid OS label: ${label}`);
  }
  for (const label of ['OS ID: 12587603', 'OS is 12587603', 'OS: 12587603']) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `matching explicit OS was rejected: ${label}`);
  }

  // Run247: An explicit matching OS followed by an unlabelled alternative
  // must not make a combined VATS/fan request appear OS-consistent. These
  // are synthetic test identifiers, not verified ECM OS evidence.
  for (const label of [
    'OS ID: 12587603 or 12212156',
    'OS ID: 12587603, 12212156',
    'OS ID: 12587603 & 12212156',
    'OS ID: 12587603 (or 12212156)',
    'OS ID: 12587603 or unknown',
    'OS ID: 12587603 or TBD',
    'OS ID: 12587603 or 12587603A'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed alternate OS was admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing alternate-OS blocker: ${label}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /OS.*(?:conflict|mismatch|disagree)/i, `direct proposal bypassed alternate OS: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603 and verify the relay wiring',
    'OS ID: 12587603, inspect the relay wiring',
    'OS ID: 12587603 or 12587603'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `matching OS or ordinary conjunction falsely blocked: ${label}`);
  }

  // Run248: A parenthesized OS alternative or a separated slash/versus
  // must not be dropped from a combined VATS/fan request. These are
  // synthetic labels for request triage, never real ECM compatibility proof.
  for (const label of [
    'OS ID: 12587603 / 12212156',
    'OS ID: 12587603 vs 12212156',
    'OS ID: 12587603 versus 12212156',
    'OS ID: 12587603 (12212156)',
    'OS ID: 12587603 (unknown)',
    'OS ID: 12587603 (TBD)'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `ambiguous OS alternative was admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing OS conflict blocker for: ${label}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /OS.*(?:conflict|mismatch|disagree)/i,
    `direct proposal bypassed ambiguous OS: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603 / check relay wiring',
    'OS ID: 12587603 (verified against the project label)',
    'OS ID: 12587603 (12587603)'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `harmless OS annotation was rejected: ${label}`);
  }

  // Run316: uncertainty words and "and/or" must not hide an alternate OS
  // after a matching identifier. These are synthetic OS labels only, not
  // controller compatibility or a verified BIN/XDF binding.
  for (const label of [
    'OS ID: 12587603 or maybe 12212156',
    'OS ID: 12587603 or possibly 12212156',
    'OS ID: 12587603 and/or 12212156',
    'OS ID: 12587603 (maybe 12212156)',
    'OS ID: 12587603 (perhaps OS ID: 12212156)'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `uncertain alternate OS admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing OS conflict blocker for: ${label}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i,
    `planner admitted uncertain alternate OS: ${label}`);
    assert.equal(JSON.stringify(draft), before, `rejected OS alternative changed workspace: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603 or maybe inspect the fan relay',
    'OS ID: 12587603 (possibly verified by the shop)',
    'OS ID: 12587603 or maybe 12587603'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `ordinary prose or same OS incorrectly rejected: ${label}`);
  }

  // Run317: natural-language uncertainty must not silently override a
  // matching first OS identifier. Also avoid treating a fan count as a
  // second OS candidate. All identifiers and temperatures are fixtures.
  for (const label of [
    'OS ID: 12587603 or it might be 12212156',
    'OS ID: 12587603 but it could be 12212156',
    'OS ID: 12587603 or maybe it is 12212156',
    'OS ID: 12587603 (I think 12212156)',
    'OS ID: 12587603 or a 12212156',
    'OS ID: 12587603; OS might be 12212156'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `natural-language alternate OS admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing natural-language OS conflict blocker: ${label}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i,
    `planner admitted natural-language alternate OS: ${label}`);
    assert.equal(JSON.stringify(draft), before, `OS conflict mutated workspace: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603 and 2 electric fans',
    'OS ID: 12587603, 2 fans',
    'OS ID: 12587603 or it might be 12587603',
    'OS ID: 12587603 but it could be verified by the shop'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `fan count, matching OS or ordinary prose rejected: ${label}`);
  }

  // Run318: punctuation followed by a conversational alternative must not
  // bypass exact-OS consistency. These identifiers are synthetic fixtures.
  for (const label of [
    'OS ID: 12587603, or it could be 12212156',
    'OS ID: 12587603; or I think it is 12212156',
    'OS ID: 12587603, but it may be 12212156',
    'OS ID: 12587603 or I think it is 12212156'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `punctuated alternate OS admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'));
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i);
    assert.equal(JSON.stringify(draft), before, `OS conflict mutated workspace: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603, or it could be 12587603',
    'OS ID: 12587603, and 2 electric fans',
    'OS ID: 12587603, or it could be checked against the project',
    'OS ID: 12587603; and inspect the fan relay'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `matching OS or ordinary prose rejected: ${label}`);
  }

  // Run319: Matching intermediate alternatives cannot hide a later conflicting
  // OS claim. Synthetic IDs are text-only consistency fixtures, not ECU proof.
  for (const label of [
    'OS ID: 12587603 or 12587603 or 12212156',
    'OS ID: 12587603, 12587603, 12212156',
    'OS ID: 12587603 or 12587603 or unknown',
    'OS ID: 12587603, or 12587603, or it could be 12212156'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `chained conflicting OS admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'));
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i);
    assert.equal(JSON.stringify(draft), before, `chained OS conflict mutated workspace: ${label}`);
  }
  // An excessive unverified alternative chain is ambiguous, even when the
  // bounded scan encounters only matching synthetic identifiers.
  const oversizedOsChain = 'OS ID: 12587603' + ' or 12587603'.repeat(13);
  assert.equal(reviewP01Request({ activeProject: active,
    request: `Disable VATS and set fans on at 210 F and off at 190 F. ${oversizedOsChain}` }).ready,
    false, 'excessive OS alternative chain was silently accepted');
  for (const label of [
    'OS ID: 12587603 or 12587603 or 12587603',
    'OS ID: 12587603, or 12587603',
    'OS ID: 12587603 and 2 electric fans',
    'OS ID: 12587603 or 12587603 and inspect the relay wiring'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `matching chained OS or ordinary prose rejected: ${label}`);
  }

  // Run350: A parenthetical correction from the controller itself is a
  // second OS claim even when it is not introduced by "or" or a repeated
  // "OS ID" label. A matching project label is not controller proof.
  for (const label of [
    'OS ID: 12587603 (the PCM actually runs 12212156)',
    'OS ID: 12587603 (my ECM reports OS 12212156)',
    'OS ID: 12587603 (my ECU has 12212156)',
    'OS ID: 12587603 (controller uses 12212156)'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `controller OS correction admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'));
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i);
    assert.equal(JSON.stringify(draft), before, `OS conflict mutated workspace: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603 (the PCM actually runs 12587603)',
    'OS ID: 12587603 (controller uses 12587603)',
    'OS ID: 12587603 (my ECU runs 12587603)',
    'OS ID: 12587603 (the PCM runs smoothly)',
    'OS ID: 12587603 (check whether the ECM is connected)'
  ]) {
    assert.equal(reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` }).ready,
    true, `nonconflicting OS annotation rejected: ${label}`);
  }

  // Run355: Contrastive controller corrections outside parentheses must not
  // be lost behind a matching project label. These synthetic OS values are
  // not evidence of real ECU compatibility or a definition mapping.
  for (const label of [
    'OS ID: 12587603, but the PCM actually runs 12212156',
    'OS ID: 12587603 but the ECM reports 12212156',
    'OS ID: 12587603, but the ECU actually runs 12212156',
    'OS ID: 12587603 (but my PCM is 12212156)',
    'OS ID: 12587603, though the PCM says 12212156',
    'OS ID: 12587603; however the controller uses unknown'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${label}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `contrastive controller OS correction admitted: ${label}`);
    assert(review.unresolvedRequests.some(item => item.type === 'os-request-conflict'),
      `missing independent OS review: ${label}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /OS.*(?:conflict|mismatch|disagree)/i);
    assert.equal(JSON.stringify(draft), before, `OS conflict mutated workspace: ${label}`);
  }
  for (const label of [
    'OS ID: 12587603, but the PCM actually runs 12587603',
    'OS ID: 12587603, but the ECU actually runs 12587603',
    'OS ID: 12587603 (but my PCM is 12587603)',
    'OS ID: 12587603, but the PCM runs smoothly',
    'OS ID: 12587603, but the ECM has 2 fan outputs',
    'OS ID: 12587603, though the PCM has 5.3 engine'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${label}` });
    assert.equal(review.ready, true, `nonconflicting controller description rejected: ${label}`);
  }

  // Run154: A pre-parsed request object is not authoritative calibration
  // intent. Rebinding text while retaining older intents, or altering a
  // fan setpoint inside an otherwise valid parsed object, must fail closed.
  const staleParsed = {
    ...lowRisk.parsed,
    text: 'Disable VATS.'
  };
  assert.throws(() => buildGoalProposal({
    request: staleParsed, workspace: workspace(), activeProject: active,
    confirmations: {}, ruleFolders: []
  }), /parsed|intent|match|changed|stale/i, 'stale fan intent survived a text-only VATS request');
  const forgedFan = {
    ...lowRisk.parsed,
    intents: lowRisk.parsed.intents.map(item => item.type === 'fan-control'
      ? { ...item, fanOn: 225 } : { ...item })
  };
  assert.throws(() => buildGoalProposal({
    request: forgedFan, workspace: workspace(), activeProject: active,
    confirmations: {}, ruleFolders: []
  }), /parsed|intent|match|changed|stale/i, 'forged fan target survived canonical request parsing');
  const forgedVats = {
    ...lowRisk.parsed,
    text: 'Set electric fans on at 210 F and off at 190 F.'
  };
  assert.throws(() => buildGoalProposal({
    request: forgedVats, workspace: workspace(), activeProject: active,
    confirmations: {}, ruleFolders: []
  }), /parsed|intent|match|changed|stale/i, 'VATS action survived removal from request text');

  // Run121: Negated VATS instructions must never become a VATS-disable
  // calibration merely because the parser recognizes the word "disable".
  for (const request of [
    'Do not disable VATS; just set fans on at 210 F and off at 190 F.',
    "Don't delete VATS. Set fans on at 210 F and off at 190 F.",
    'Never remove VATS. Set fans on at 210 F and off at 190 F.',
    'Keep VATS enabled and set fans on at 210 F and off at 190 F.',
    'Leave VATS on and set fans on at 210 F and off at 190 F.',
    'VATS should not be disabled. Set fans on at 210 F and off at 190 F.',
    'I do not want to disable VATS. Set fans on at 210 F and off at 190 F.',
    'I do not want VATS disabled. Set fans on at 210 F and off at 190 F.',
    'VATS must remain enabled. Set fans on at 210 F and off at 190 F.',
    'Disable VATS. Actually, do not disable VATS.',
    'Do not turn VATS off; just set fans on at 210 F and off at 190 F.',
    "Don't turn the VATS off; set fans on at 210 F and off at 190 F.",
    'Never switch VATS off; set fans on at 210 F and off at 190 F.',
    'Do not shut my VATS off; set fans on at 210 F and off at 190 F.',
    'Do not want to turn VATS off; set fans on at 210 F and off at 190 F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `negated VATS request accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'vats-intent-contradiction'), `missing VATS intent blocker: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `negated VATS action proposal: ${request}`);
  }
  const forgedParsed = reviewP01Request({ activeProject: active, request: 'Do not disable VATS; set fans on at 210 F and off at 190 F.' }).parsed;
  assert.throws(() => buildGoalProposal({
    request: { ...forgedParsed, unresolvedRequests: [] }, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /full tune request is not supported/i, 'forged parsed request cannot hide negated VATS intent');
  // Run122: The verb can surround the object ("turn VATS off") instead
  // of preceding it ("turn off VATS"). Forged parsed objects must not
  // turn this negation into an executable VATS change.
  const negatedObjectBetween = reviewP01Request({
    activeProject: active,
    request: 'Do not turn VATS off; just set fans on at 210 F and off at 190 F.'
  }).parsed;
  assert.throws(() => buildGoalProposal({
    request: { ...negatedObjectBetween, unresolvedRequests: [] },
    workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /full tune request is not supported/i);
  const affirmativeObjectBetween = reviewP01Request({
    activeProject: active, request: 'Turn VATS off and set fans on at 210 F and off at 190 F.'
  });
  assert.equal(affirmativeObjectBetween.ready, true, 'affirmative turn-VATS-off request should remain recognized');
  const affirmativeVats = reviewP01Request({ activeProject: active, request: 'Disable VATS for my authorized engine swap.' });
  assert.equal(affirmativeVats.ready, true);
  assert(!affirmativeVats.unresolvedRequests.some(item => item.type === 'vats-intent-contradiction'));

  // A mixed quick-service request must never hide unimplemented physical changes.
  const mixed = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS, enable electric fans, delete the knock sensors, and tune my LSX Stage 2 cam.'
  });
  assert.equal(mixed.ready, false);
  assert.deepEqual(mixed.parsed.intents.map(item => item.type), ['vats-disable']);
  assert.deepEqual(mixed.unresolvedRequests.map(item => item.type), [
    'knock-sensor-delete', 'physical-camshaft-tune', 'fan-output-enable', 'fan-control-incomplete'
  ]);
  assert(mixed.missingSafetyFacts.some(item => /knock protection/i.test(item)));
  assert(mixed.missingSafetyFacts.some(item => /cam card/i.test(item)));
  assert(mixed.missingSafetyFacts.some(item => /on and off temperatures/i.test(item)));
  assert.throws(() => buildGoalProposal({
    request: mixed.requestText, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /full tune request is not supported/i);
  // Pre-parsed objects cannot conceal the pending portions of a request.
  assert.throws(() => buildGoalProposal({
    request: { ...mixed.parsed, unresolvedRequests: [] }, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /full tune request is not supported/i);
  assert.notEqual(lowRisk.requestFingerprint, mixed.requestFingerprint);

  // Run220: Colloquial physical removal wording can be missed by the
  // explicit "remove/delete/disconnect" patterns. It must not be silently
  // dropped from an otherwise recognized VATS/fan quick-service request.
  // These are text triage fixtures, not ECU, DTC, or OS compatibility proof.
  for (const phrase of [
    'I pulled the knock sensors out.',
    'I took out both knock sensors.',
    'I pulled out the knock sensors.',
    'I want to pull the knock sensors out.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical knock sensor removal admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock diagnostic review for: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite knock removal: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the knock sensor wiring.',
    'Pull the knock sensor diagnostic codes for review.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only request falsely classified as sensor removal: ${phrase}`);
  }

  // Run233: Past-tense physical disconnection must not be dropped from an
  // otherwise recognized VATS/fan request. These phrases describe absent
  // knock feedback, not proof that disabling knock protection is safe.
  for (const phrase of [
    'I unplugged both knock sensors.',
    'I disconnected the knock sensors.',
    'I unhooked the knock sensors.',
    'I detached both knock sensors.',
    'Both knock sensors were unplugged.',
    'The knock sensors have been disconnected.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `past-tense knock disconnection accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock-system diagnostic review for: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite physical knock disconnection: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the knock sensor connectors.',
    'Log knock sensor voltages.',
    'Check whether the knock sensors are connected.',
    'Check whether the knock sensors were unplugged.',
    'Diagnose if the knock sensors have been disconnected.',
    'Inspect disconnected knock sensors.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only phrase falsely treated as physical disconnection: ${phrase}`);
  }

  const physicalCamOnly = reviewP01Request({ activeProject: active, request: 'Tune my LSX Stage 2 camshaft.' });
  assert.equal(physicalCamOnly.ready, false);
  assert.deepEqual(physicalCamOnly.unresolvedRequests.map(item => item.type), ['physical-camshaft-tune']);
  // Run134: Physical Stage 2 cam requests can be written with Roman numerals,
  // spelled-out stage numbers, or an LSX brand after the stage designation.
  // None may be silently dropped from a combined VATS quick-service request.
  for (const request of [
    'Disable VATS and tune my LSXceleration Stage II cam.',
    'Disable VATS and tune my LSX Stage Two cam.',
    'Disable VATS and tune my Stage 2 LSX cam.',
    'Disable VATS and tune my stage ii cam.',
    'Disable VATS and tune my stage two cam.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical cam request accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `physical cam change silently dropped: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `physical cam change proposed: ${request}`);
  }
  // Run213: A physical cam calibration can be requested as a hyphenated
  // cam-card or a cam profile/grind without the word camshaft or a stage.
  // The VATS/fan planner must not silently drop that unimplemented work.
  // These are text-only fixtures; no real cam card or calibration is inferred.
  for (const phrase of [
    'Tune from my cam-card specs.',
    'Recalibrate for my cam profile.',
    'Adjust idle airflow for the cam grind.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical cam instruction admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `physical cam instruction silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial cam/VATS proposal: ${phrase}`);
  }
  // Run214: A physical cam tune may put the action BEFORE the standalone
  // word "cam". The VATS/fan quick-service parser must not silently discard
  // "tune for my new cam" simply because no "camshaft" or "cam-card" appears.
  // These are syntax-only safety fixtures, not actual cam-card calibration.
  for (const phrase of [
    'Tune for my new cam.',
    'Adjust idle for the new cam.',
    'Calibrate for my LSX cam.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `standalone physical cam instruction admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `standalone physical cam instruction silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial cam/VATS proposal: ${phrase}`);
  }
  const mixedGhostAndPhysical = reviewP01Request({ activeProject: active,
    request: 'Disable VATS and add a ghost cam idle. Also tune for my new cam.' });
  assert(mixedGhostAndPhysical.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
    'ghost-cam intent must not conceal a separate physical cam calibration request');
  for (const phrase of ['Inspect the cam sensor.', 'Tune the camera preview.', 'Log the cam position sensor.']) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `non-camshaft task misclassified as physical cam tune: ${phrase}`);
  }
  for (const phrase of ['Inspect the cam position sensor.', 'Show the camera preview.']) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `unrelated observation falsely treated as physical cam tuning: ${phrase}`);
  }
  // Run197 regression: preservation instructions without the word "disable"
  // must never be dropped from a recognized VATS + fan-temperature request.
  // These are request-text tests only, not exact-OS or ECU verification.
  for (const phrase of [
    'Leave VATS alone.',
    'Keep VATS as-is.',
    'Do not touch VATS.',
    "Don't change the VATS.",
    'VATS should be left unchanged.',
    'Preserve the factory VATS settings.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `VATS preservation silently omitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'vats-intent-contradiction'),
      `VATS preservation blocker missing: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS proposal accepted: ${phrase}`);
  }
  for (const phrase of [
    'Review the current VATS state.',
    'Inspect the VATS configuration without changing it.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'vats-intent-contradiction'),
      `read-only VATS observation incorrectly blocked: ${phrase}`);
  }
  // Run198: Spelled-out and speed-tier fan banks are separate outputs, not
  // the single shared fan-on/fan-off pair. Reject partial VATS proposals.
  // These fixtures never infer fan pin mappings, output polarity or targets.
  for (const phrase of [
    'Set fan one to 200 F.',
    'Configure fan two on threshold to 205 F.',
    'Use separate low-speed and high-speed fan thresholds.',
    'Set low speed fan threshold to 195 F.',
    'High-speed fan output = enabled.',
    'Fan two off temperature: 185 F.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `separate fan-bank instruction silently dropped: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-bank-specific'),
      `missing separate fan-bank review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial fan-bank proposal admitted: ${phrase}`);
  }
  for (const phrase of [
    'Review fan one wiring.',
    'Inspect low-speed fan relay status.',
    'Check high-speed fan output diagnostics without changing settings.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only fan-bank observation blocked: ${phrase}`);
  }
  // Run199: Indexed relay/driver directives are not shared fan temperatures.
  // In Run198 these were silently omitted, producing a partial VATS/fan plan.
  // The strings are fixture-only; no output pin, polarity, OS map or ECU is
  // identified by a relay number in these tests.
  for (const [phrase, blocker] of [
    ['Fan relay 1 should be enabled.', 'fan-output-enable'],
    ['ECM fan output #2 must be disabled.', 'fan-output-disable'],
    ['PCM fan driver 1 is to be activated.', 'fan-output-enable'],
    ['Fan relay #2 needs to be deactivated.', 'fan-output-disable'],
    ['Electric fan control 1 will be switched on.', 'fan-output-enable'],
    ['Cooling fan relay 2 has to be turned off.', 'fan-output-disable']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `indexed fan output directive silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} for indexed fan output: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial indexed fan output proposal: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay 1 wiring.',
    'Review ECM fan output #2 status.',
    'Check PCM fan driver 1 without changing it.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only indexed fan observation blocked: ${phrase}`);
  }
  // Run237: Index values are request text, not proof of physical outputs.
  // An unsupported or unexpected fan relay number must never be silently
  // omitted from an otherwise valid VATS + shared fan-temperature proposal.
  // The fixture numbers below DO NOT assert that the ECM has those outputs.
  for (const [phrase, blocker] of [
    ['Fan relay 3 should be enabled.', 'fan-output-enable'],
    ['ECM fan output #4 must be disabled.', 'fan-output-disable'],
    ['PCM fan driver 3 enable flag = true.', 'fan-output-enable'],
    ['Fan relay 3 status: inactive.', 'fan-output-disable'],
    ['Fan output 3 = enabled.', 'fan-output-enable'],
    ['Fan output #10 should be activated.', 'fan-output-enable'],
    ['Fan relay 0 is disabled.', 'fan-output-disable'],
    ['Fan relay 3 polarity = inverted.', 'fan-output-strategy'],
    ['Fan output #4 drive mode = active high.', 'fan-output-strategy'],
    ['Set fan relay #3 to ground switched.', 'fan-output-strategy']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unmapped indexed fan request silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} review for unmapped fan index: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial fan proposal for index: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay 3 wiring.',
    'Review ECM fan output #4 status without changing it.',
    'Check fan relay 10 drive mode only.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only fan index observation blocked: ${phrase}`);
  }
  // Run238: Spoken indices and "number N" are still indexed physical
  // outputs, not a shared coolant-temperature target. These are synthetic
  // text fixtures; no extra fan output is claimed to exist on any ECM.
  for (const [phrase, blocker] of [
    ['Fan relay three should be enabled.', 'fan-output-enable'],
    ['Fan output number three = enabled.', 'fan-output-enable'],
    ['Fan relay zero should be disabled.', 'fan-output-disable'],
    ['ECM fan output number four must be disabled.', 'fan-output-disable'],
    ['Fan relay three polarity = active low.', 'fan-output-strategy'],
    ['Fan driver number five drive mode = inverted.', 'fan-output-strategy'],
    ['Fan relay ten enable flag = true.', 'fan-output-enable'],
    ['Fan relay number 3 should be enabled.', 'fan-output-enable']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `spelled fan output silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} for spoken fan index: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial fan proposal for spoken index: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay three wiring.',
    'Review fan output number three without changing it.',
    'Check fan driver five status only.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only spoken fan observation blocked: ${phrase}`);
  }
  // Run221: An indexed fan relay/output enable flag is independent of
  // temperature thresholds. A numeric or boolean state is not an OS bit
  // mapping. The quick-service planner must not silently discard it.
  for (const [phrase, blocker] of [
    ['Fan relay 1 enable flag = 0.', 'fan-output-disable'],
    ['ECM fan output #2 enable bit: false.', 'fan-output-disable'],
    ['PCM fan driver 1 enable state = true.', 'fan-output-enable'],
    ['Fan relay #2 enable flag should be disabled.', 'fan-output-disable'],
    ['Fan output #2 enable flag = 1.', 'fan-output-enable'],
    ['Set fan relay 1 enable flag to enabled.', 'fan-output-enable']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `indexed fan enable state silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing independent ${blocker} review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial fan output state proposal: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay 1 enable flag without changing it.',
    'Review ECM fan output #2 enable bit status.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only fan output observation blocked: ${phrase}`);
  }
  // Run207: Indexed relay/output polarity is a physical driver setting,
  // separate from both fan temperatures and output enablement. A partial
  // VATS/fan proposal must not discard these instructions. These are only
  // syntax fixtures; no pin, OS mapping, or safe polarity is assumed.
  for (const phrase of [
    'Set fan relay #2 to active low.',
    'ECM fan output 1 polarity = inverted.',
    'Set fan relay 1 to ground switched.',
    'Fan output #2 drive mode = active high.',
    'PCM fan driver #1 drive mode: power switched.',
    'Fan relay 1 should be active low.',
    'Fan output 2 = reversed.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `indexed fan drive strategy silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-strategy'),
      `indexed fan drive strategy missing separate review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial indexed fan drive proposal admitted: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay #2 polarity without changing it.',
    'Review ECM fan output 1 drive mode.',
    'Check PCM fan driver #1 wiring and active-low status.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only indexed fan review blocked: ${phrase}`);
  }
  // Run196: Declarative and assignment-style ECM requests must not be
  // silently omitted from an otherwise recognized VATS/temperature plan.
  // These are syntax/fixture checks, NOT proof of controller OS addresses,
  // output polarity, fan wiring, DTC mappings, or physical ECM behavior.
  for (const [phrase, blocker] of [
    ['VATS enable flag = true.', 'vats-intent-contradiction'],
    ['VATS = enabled.', 'vats-intent-contradiction'],
    ['Knock DTCs should be ignored.', 'knock-diagnostic-suppression'],
    ['Knock sensor fault reporting should be suppressed.', 'knock-diagnostic-suppression'],
    ['Knock sensor fault codes: no MIL.', 'knock-diagnostic-suppression'],
    ['Knock sensors not fitted.', 'knock-sensor-delete'],
    ['Fan output 1 = enabled.', 'fan-output-enable'],
    ['Fan PWM mode = electric.', 'fan-output-enable']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed assignment silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} for ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal admitted: ${phrase}`);
  }
  for (const phrase of [
    'Review VATS enable flag status.',
    'Review knock sensor fault reporting status.',
    'Check fan output 1 wiring.',
    'Inspect fan PWM mode.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert.equal(review.ready, true, `read-only observation misclassified: ${phrase}`);
  }
  // Run195: A combined VATS/fan request must not silently omit
  // controller fan mode commissioning or target-first knock DTC suppression.
  // These phrases were previously accepted as complete VATS/temperature-only
  // plans despite requiring independent exact-OS and diagnostic review.
  for (const phrase of [
    'Set cooling fan control mode to electric.',
    'Set fan type to electric.',
    'Fan control mode = PWM.',
    'Fan control strategy should be set to dual.',
    'ECM fan relay mode: single speed.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan mode silently omitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `missing separate fan output commissioning review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  for (const phrase of [
    'Knock sensor codes set to no error.',
    'P0327 set to no error.',
    'P0332 should be classified as not reported.',
    'Knock sensor DTCs are configured as disabled.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock DTC classification silently omitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing separate knock diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  for (const phrase of [
    'Review the current cooling fan control mode.',
    'Review P0327 classification without changing it.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item =>
      item.type === 'fan-output-enable' || item.type === 'knock-diagnostic-suppression'),
    `diagnostic observation misclassified as change: ${phrase}`);
  }
  // Run185: A knock-related DTC's MIL/CEL classification is a diagnostic
  // suppression request, not a harmless companion to VATS/fan temperatures.
  // No physical DTC map, ECM bit, or MIL behavior is assumed by these tests.
  for (const phrase of [
    'P0327 MIL = off.',
    'P0332 MIL reporting = disabled.',
    'Knock sensor DTC MIL = off.',
    'Knock sensor DTC type = no error.',
    'Set P0327 to no MIL.',
    'Turn off CEL for P0332.',
    'P0332 check engine light = off.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock MIL/DTC classification silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing knock diagnostic review for ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  // Run208: imperative 'set P0327 MIL to off' changes DTC visibility
  // even though it is not an assignment. Never silently admit a VATS/fan
  // quick-service request containing this separate diagnostic change.
  // P03xx strings are generic triage examples, NOT an OS-specific DTC map.
  for (const phrase of [
    'Set P0327 MIL to off.',
    'Configure P0327 check engine light to disabled.',
    'Set knock sensor DTCs MIL to no MIL.',
    'Change P0332 DTC type to no error.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock indicator imperative silently admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing independent knock diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  // Run209: object-first indicator shutdown ("turn P0327 MIL off")
  // must not vanish from a valid VATS/fan quick-service request. This
  // checks only request triage, not whether any DTC exists on the owner OS.
  for (const phrase of [
    'Turn P0327 MIL off.',
    'Switch P0332 CEL off.',
    'Shut P0327 check engine light off.',
    'Turn knock sensor DTCs MIL off.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `object-first knock indicator shutdown accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing knock indicator shutdown review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  // Run210: a MIL/CEL target between the verb and OFF is a separate
  // knock-DTC visibility request ("turn the MIL off for P0327"). Never
  // silently accept only the companion VATS/fan request. These P03xx
  // examples are generic syntax fixtures, not verified ECM/OS DTC maps.
  for (const phrase of [
    'Turn the MIL off for P0327.',
    'Switch the check engine light off for P0332.',
    'Turn the CEL off on P0327.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `indicator-first knock DTC shutdown accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing separate knock indicator review: ${phrase}`);
    assert.throws(() => buildGoalProposal({ request, workspace: workspace(),
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `partial VATS/fan proposal accepted: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the MIL for P0327.',
    'Review P0327 MIL status.',
    'P0327 MIL = on.',
    'Set P0327 MIL to on.',
    'Review whether P0327 MIL should remain on.',
    'Knock sensor DTC count = 0.',
    'P0332 MIL lamp is working.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `knock diagnostic observation incorrectly classified as suppression: ${phrase}`);
  }
  // Run184: protect against sensor-input suppression and code-reporting
  // aliases that were previously ignored inside valid VATS/fan requests.
  for (const [phrase, blocker] of [
    ['Knock sensor monitoring = disabled.', 'knock-sensor-delete'],
    ['Ignore knock sensor input.', 'knock-sensor-delete'],
    ['Knock sensors: not installed.', 'knock-sensor-delete'],
    ['Knock sensors should be ignored.', 'knock-sensor-delete'],
    ['P0327 reporting = disabled.', 'knock-diagnostic-suppression'],
    ['Knock sensor codes should not report.', 'knock-diagnostic-suppression'],
    ['Do not log P0327 or P0332.', 'knock-diagnostic-suppression']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unsafe knock protection/reporting alias accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} for ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal accepted: ${phrase}`);
  }
  for (const phrase of [
    'Review the knock sensor monitoring log.',
    'P0327 reporting status = active.',
    'Knock sensor input voltage = 0.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item =>
      item.type === 'knock-sensor-delete' || item.type === 'knock-diagnostic-suppression'),
      `diagnostic observation incorrectly blocked: ${phrase}`);
  }
  // Run183: assignment-style sensor removal and knock diagnostic reporting
  // suppression must never be silently dropped from an otherwise supported
  // VATS/fan request. These are syntax triage cases, not controller mappings.
  for (const [phrase, blocker] of [
    ['Knock sensors = disabled.', 'knock-sensor-delete'],
    ['Knock sensors = 0.', 'knock-sensor-delete'],
    ['Knock sensor diagnostics enabled = false.', 'knock-diagnostic-suppression'],
    ['Knock sensor DTC reporting = off.', 'knock-diagnostic-suppression'],
    ['Knock sensor DTCs disabled.', 'knock-diagnostic-suppression']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unsafe knock assignment admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker),
      `missing ${blocker} for: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal admitted: ${phrase}`);
  }
  // Observations must not be misclassified as requested protection changes.
  for (const phrase of [
    'Knock sensor voltage = 0.',
    'Knock sensor DTC count = 0.',
    'Review the knock sensor diagnostic log.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item =>
      item.type === 'knock-sensor-delete' || item.type === 'knock-diagnostic-suppression'),
      `observation incorrectly treated as a protection change: ${phrase}`);
  }
  const fansOnly = reviewP01Request({ activeProject: active, request: 'Enable electric fans.' });
  assert.equal(fansOnly.ready, false);
  assert.deepEqual(fansOnly.unresolvedRequests.map(item => item.type), ['fan-output-enable', 'fan-control-incomplete']);
  const ghostOnly = reviewP01Request({ activeProject: active, request: 'Give it a ghost cam.' });
  assert.deepEqual(ghostOnly.unresolvedRequests, []);
  assert.equal(ghostOnly.ready, false); // Existing vacuum/driveability acceptance is still required.
  const knockOnly = reviewP01Request({ activeProject: active, request: 'Delete the knock sensors.' });
  assert.equal(knockOnly.ready, false);
  assert.deepEqual(knockOnly.unresolvedRequests.map(item => item.type), ['knock-sensor-delete']);
  // Run256: A user may describe physical knock sensor removal as 'pulled'
  // without saying 'out/off', or as 'gone'. The VATS/fan planner must not
  // silently discard the loss of knock feedback. These are text fixtures,
  // not exact-OS hardware claims, DTC mappings or permission to disable KR.
  for (const phrase of [
    'I pulled both knock sensors',
    'I yanked the knock sensors',
    'Both knock sensors were pulled',
    'The knock sensors are gone',
    'We extracted the factory knock sensors',
    'I pulled my knock sensor'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical knock removal was accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `physical knock removal missing diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal for: ${phrase}`);
  }
  for (const phrase of [
    'Please pull knock sensor codes',
    'Inspect whether the knock sensors were pulled',
    'Check if knock sensors are gone',
    'Pull knock sensor data logs'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `read-only knock diagnostic request was misclassified: ${phrase}`);
  }
  // Run257: Passive physical-removal reports can say sensors "have been
  // taken out" or "are out of the block" without an active remove verb.
  // These are synthetic request fixtures, not evidence of the owner's wiring.
  for (const phrase of [
    'Both knock sensors have been taken out',
    'The knock sensors were taken out',
    'I had the knock sensors taken out',
    'The knock sensors are out of the engine',
    'My knock sensor is out of the block'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `passive knock removal admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the knock sensors have been taken out',
    'Inspect if the knock sensors are out of the engine',
    'Are the knock sensors taken out?',
    'The knock sensors have not been taken out',
    'Log knock sensor codes that were taken out'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic or negative statement misclassified: ${phrase}`);
  }
  // Run266: Physical sensors left out during an LS build are a separate
  // knock-feedback diagnostic issue, not permission to plan VATS/fans alone.
  // These are synthetic text fixtures, not evidence about the owner's ECM.
  for (const phrase of [
    'I left both knock sensors out',
    'The knock sensors were left out',
    'Both knock sensors were never reinstalled',
    'I did not reinstall the knock sensors',
    'The knock sensors have not been installed',
    'The knock sensors were not put back in'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `uninstalled knock hardware admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock diagnostics for: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the knock sensors were left out',
    'Were the knock sensors left out?',
    'I did not leave the knock sensors out',
    'The knock sensors were reinstalled'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic or installed-sensor control misclassified: ${phrase}`);
  }
  // Knock-control removal has several common wordings. None may be
  // silently discarded when combined with an otherwise supported VATS change.
  for (const phrase of [
    'knock sensors disabled', 'turn off knock retard', 'disable knock detection',
    'run without knock sensors', 'knock control off', 'delete knock feedback'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unsafe knock request was missed: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'), `missing knock protection blocker: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  // Run153: Generic knock-protection wording must not be silently ignored.
  // This is diagnostic admission only; no knock maps or protection changes.
  for (const phrase of [
    'disable knock protection',
    'turn knock monitoring off',
    'turn knock protection off',
    'disable knock response',
    'knock monitoring disabled'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unsafe knock protection request accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock protection review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const phrase of [
    'inspect knock protection',
    'verify knock monitoring is enabled',
    'keep knock response enabled'
  ]) {
    const review = reviewP01Request({ activeProject: active, request: `Disable VATS and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic observation misread as knock disable: ${phrase}`);
  }
  // Run128 regression: zeroing knock retard/control is an instruction to
  // defeat knock protection, even when the verb is not "disable" or "delete".
  // It must not disappear behind an otherwise supported VATS change.
  for (const phrase of [
    'set knock retard to zero',
    'set knock retard to 0 degrees',
    'zero out knock retard',
    'set knock control to 0',
    'set knock retard limit to 0'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `zeroed knock protection was accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'), `missing knock review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  // Run164: An otherwise valid VATS instruction must not conceal a request
  // to zero knock-retard tables or KR (the common logging abbreviation).
  // This is a review-only guard; it does not propose any ECU values.
  for (const phrase of [
    'set knock retard table to zero',
    'set knock retard tables to 0',
    'set KR to 0',
    'zero out KR',
    'set KR limit to zero'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed knock-retard change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `knock-retard protection review missing: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  // Run165: Zeroing knock gain, multiplier, or sensitivity, or switching
  // off a knock enable flag, can defeat protection without using the words
  // "delete knock sensors". Mixed VATS requests must fail closed.
  for (const phrase of [
    'set knock retard multiplier to zero',
    'set knock retard gain to 0',
    'set knock retard sensitivity to zero',
    'set knock control multiplier to 0',
    'set KR multiplier to zero',
    'set KR gain to 0',
    'set knock retard enable flag off'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock protection scalar change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `knock protection scalar review missing: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const phrase of [
    'inspect knock retard gain',
    'log KR multiplier',
    'verify knock retard sensitivity is active'
  ]) {
    const review = reviewP01Request({ activeProject: active, request: `Disable VATS and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `knock scalar diagnostic observation misclassified: ${phrase}`);
  }
  for (const phrase of ['inspect KR at idle', 'log KR and knock retard', 'keep KR protection enabled']) {
    const review = reviewP01Request({ activeProject: active, request: `Disable VATS and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only KR observation misclassified: ${phrase}`);
  }
  // A request to suppress knock-sensor diagnostics is not a harmless request
  // to read diagnostic trouble codes. Require a separate diagnostic review.
  for (const phrase of ['turn knock sensor diagnostics off', 'disable knock sensor diagnostics']) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock diagnostics suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `knock diagnostics suppression silently dropped: ${phrase}`);
  }
  for (const phrase of ['inspect knock sensor diagnostics', 'log knock sensor diagnostics']) {
    const review = reviewP01Request({ activeProject: active, request: `Disable VATS and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `diagnostic-only request misclassified: ${phrase}`);
  }
  // Run130 regression: physical knock-sensor disconnection and requests to
  // suppress knock-fault reporting must not be silently dropped from a VATS
  // proposal. Suppressing a DTC is not proof that knock control still works.
  for (const [phrase, blocker] of [
    ['unplug both knock sensors', 'knock-sensor-delete'],
    ['disconnect the knock sensors', 'knock-sensor-delete'],
    ['ignore knock sensor faults', 'knock-diagnostic-suppression'],
    ['suppress knock sensor codes', 'knock-diagnostic-suppression'],
    ['set knock sensor DTCs to no error', 'knock-diagnostic-suppression']
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed knock change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === blocker), `missing knock diagnostic blocker: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const request of [
    'Disable VATS and log knock sensor fault codes.',
    'Disable VATS and diagnose disconnected knock sensors.',
    'Disable VATS and inspect knock sensor DTCs.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => ['knock-sensor-delete', 'knock-diagnostic-suppression'].includes(item.type)), `diagnostic observation falsely blocked: ${request}`);
  }
  // Run222: Physical knock feedback can be lost at the harness or connector,
  // even if the sensors themselves are still installed. Never silently drop
  // this condition from a mixed VATS/fan proposal. No wiring/OS assumptions.
  for (const phrase of [
    'Knock sensor harness is unplugged',
    'Both knock sensors have been unplugged',
    'The knock sensor wiring is cut',
    'Knock sensor wires cut',
    'Knock sensor harness = disconnected',
    'I unplugged the knock sensor harness',
    'Knock sensor connector came unplugged'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `compromised knock feedback accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock wiring diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal for: ${phrase}`);
  }
  for (const phrase of [
    'inspect knock sensor harness for unplugged connectors',
    'check whether knock sensor wiring is cut',
    'log knock sensor harness status',
    'inspect knock sensor wires for cuts'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `read-only knock wiring diagnostic misclassified: ${phrase}`);
  }
  // Run234: Past-tense active wire damage with intervening determiners was
  // silently omitted from mixed VATS/fan requests. Physical knock feedback
  // must be diagnosed separately, never disabled to hide a wiring fault.
  for (const phrase of [
    'I cut both knock sensor wires',
    'We severed the knock sensor harness',
    'I snipped the knock sensor wires',
    'The mechanic cut my knock sensor wiring',
    'I cut the stock knock sensor connectors'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical knock wiring damage admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock wiring review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'Check whether I cut both knock sensor wires',
    'Inspect if the mechanic severed the knock sensor harness',
    'Review the knock sensor wiring for damage',
    'Log knock sensor wire voltages'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only knock wiring request blocked: ${phrase}`);
  }
  // Run235: Damage to wires *to* the sensors must not be dropped when the
  // physical wiring noun precedes the knock-sensor target. This is text-only
  // safety triage; it does not diagnose hardware or authorize a calibration.
  for (const phrase of [
    'I cut the wires to the knock sensors',
    'We severed the harness going to both knock sensors',
    'The wires to the knock sensors were cut',
    'The wiring going to my knock sensors has been snipped',
    'The connectors for the knock sensors are disconnected'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `reversed knock wiring damage admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock wiring review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the wires to the knock sensors were cut',
    'Inspect if the harness going to both knock sensors is severed',
    'Diagnose if the connectors for the knock sensors are disconnected'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only wiring inspection misclassified: ${phrase}`);
  }
  // Run236: Negative connection-state descriptions are physical knock-feedback
  // concerns even without the verbs unplug/disconnect. The P01 quick planner
  // must not silently prepare only companion VATS/fan changes. This is text
  // triage, not a controller OS map or permission to disable knock protection.
  for (const phrase of [
    'The knock sensors are not plugged in',
    'My knock sensors are not connected',
    'The knock sensor connectors are not plugged in',
    'The knock sensor harness is not connected',
    'Both knock sensors have not been hooked up',
    'The knock sensors were never connected'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `negative knock connection state admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock-system diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the knock sensors are not plugged in',
    'Diagnose if the knock sensor harness is not connected',
    'Inspect whether the knock sensor connectors are not plugged in',
    'Log knock sensor connection status'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `read-only knock connection inspection misclassified: ${phrase}`);
  }
  // Run239: Reported knock sensor/circuit faults must not disappear from a
  // combined VATS/fan request. A faulty sensor is a diagnostic concern, NOT
  // authorization to delete the DTC, zero KR, or assume a compatible OS map.
  for (const phrase of [
    'My knock sensors are faulty',
    'Both knock sensors have failed',
    'The knock sensor harness is broken',
    'The knock sensor signal is missing',
    'Knock sensor 1 has no signal',
    'The knock sensor circuit is open',
    'My knock sensors are not working'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `reported knock-system fault admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock-system diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the knock sensors are faulty',
    'Diagnose if the knock sensor signal is missing',
    'Inspect whether the knock sensor harness is broken',
    'Log the knock sensor signal',
    'Check whether knock sensor 1 has no signal'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic-only knock inspection misclassified: ${phrase}`);
  }
  // Run312: A reported intermittent/erratic knock signal or intermittent
  // knock-circuit DTC must block the *entire* combined quick-service plan.
  // All text and OS identifiers here are synthetic; no DTC/OS mapping is asserted.
  for (const phrase of [
    'knock sensor signal intermittent',
    'knock sensor 1 circuit intermittent',
    'knock sensor signal erratic',
    'knock sensor 2 signal unstable',
    'P0327 is intermittent',
    'DTC P0332: intermittent',
    'P0327 and P0332 are intermittent'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `intermittent knock fault silently omitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item =>
      ['knock-sensor-delete', 'knock-diagnostic-fault'].includes(item.type)),
      `missing independent knock diagnostic review: ${phrase}`);
    const draft = workspace();
    const original = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({
      request, workspace: draft, activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `direct planner admitted intermittent knock fault: ${phrase}`);
    assert.equal(JSON.stringify(draft), original,
      `rejected intermittent knock fault mutated workspace: ${phrase}`);
  }
  for (const phrase of [
    'Check whether knock sensor signal is intermittent',
    'Inspect if knock sensor 1 circuit is erratic',
    'Diagnose whether P0327 is intermittent',
    'P0327 is not intermittent',
    'knock sensor signal is stable'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item =>
      ['knock-sensor-delete', 'knock-diagnostic-fault'].includes(item.type)),
      `diagnostic question or healthy statement falsely blocked: ${phrase}`);
  }

  // Run313: Adjective-first knock signal faults must not be silently
  // discarded from an otherwise recognized VATS/fan request. These are
  // synthetic language fixtures, not an OS-specific sensor diagnosis.
  for (const phrase of [
    'Intermittent knock sensor signal on the engine',
    'Erratic knock sensor readings during acceleration',
    'Unstable knock sensor feedback under load',
    'Knock sensor readings are erratic',
    'Knock sensor voltage is unstable'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `reported knock signal fault omitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock diagnostic review: ${phrase}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft,
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request is not supported/i, `direct planner admitted knock signal fault: ${phrase}`);
    assert.equal(JSON.stringify(draft), before,
      `rejected knock fault modified workspace: ${phrase}`);
  }
  for (const phrase of [
    'Check whether intermittent knock sensor signal is present',
    'Inspect if erratic knock sensor readings exist',
    'Are the knock sensor readings erratic?',
    'Is the knock sensor signal intermittent?',
    'Knock sensor readings are stable'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `question/healthy knock statement misclassified: ${phrase}`);
  }

  // Run249: A reported active/pending/stored knock-circuit DTC is a diagnostic
  // blocker, even when no one explicitly asks to suppress the code. This
  // must not disappear behind a recognized VATS + fan-temperature request.
  // Generic code examples below are triage fixtures, NOT this ECM's OS map.
  for (const phrase of [
    'P0327 is active.',
    'DTC P0332: pending.',
    'Stored DTC P0327.',
    'P0334 confirmed.',
    'P0328 currently present.',
    'Knock circuit code P0326 is stored.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `reported knock-circuit DTC admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-fault'),
      `missing separate knock diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite reported knock DTC: ${phrase}`);
  }
  for (const phrase of [
    'Check whether P0327 is active.',
    'Inspect if DTC P0332 is pending.',
    'Check for active P0327.',
    'Review P0327 status.',
    'Keep P0327 reporting active.',
    'P0327 was cleared.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-fault'),
      `diagnostic-only knock DTC inspection misclassified: ${phrase}`);
  }
  // Run250: A reported knock DTC can be expressed with compound state verbs
  // or a group of codes ("P0327 and P0332 are pending"). Do not silently
  // admit a VATS/fan proposal merely because the DTC status uses "is still",
  // "has been", or plural "are". These codes are synthetic triage fixtures.
  for (const phrase of [
    'P0327 is still active.',
    'P0327 has been stored.',
    'P0327 and P0332 are pending.',
    'DTC P0332 is currently confirmed.',
    'P0327 remains currently active.',
    'P0332 has been confirmed.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `compound knock DTC status admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-fault'),
      `missing knock DTC review for compound status: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite compound knock DTC: ${phrase}`);
  }
  for (const phrase of [
    'Check whether P0327 is still active.',
    'Inspect if P0327 and P0332 are pending.',
    'Determine whether DTC P0332 has been stored.',
    'P0327 is no longer active.',
    'P0332 has not been confirmed.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-fault'),
      `inspection or negative DTC status misclassified: ${phrase}`);
  }
  // Run223: Block-off plugs and sensor relocation can eliminate or compromise
  // physical knock feedback without the words "delete" or "unplug". These
  // fixtures only require diagnostic review; they never authorize a bypass.
  for (const phrase of [
    'I plugged the knock sensor holes',
    'Knock sensor ports are capped',
    'Knock sensor holes have block-off plugs installed',
    'I installed plugs in the knock sensor ports',
    'I relocated both knock sensors'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `physical knock feedback change admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock hardware diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite knock hardware change: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the knock sensor ports for plugs',
    'Check whether knock sensor holes are plugged',
    'Log knock sensor relocation concerns'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `read-only knock hardware diagnostic misclassified: ${phrase}`);
  }
  // Run137 regression: Object-first descriptive knock-DTC suppression can
  // bypass the code-number guard. It must not be silently omitted when the
  // same request contains a supported VATS change.
  for (const phrase of [
    'turn knock sensor DTCs off',
    'switch knock sensor codes off',
    'shut knock sensor fault codes off',
    'turn knock sensor fault reporting off'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock reporting suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `descriptive knock DTC suppression silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const phrase of [
    'keep knock sensor codes on',
    'check whether knock sensor DTCs are off',
    'inspect knock sensor fault reporting'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `diagnostic-only knock DTC observation falsely blocked: ${phrase}`);
  }
  // Run131: A request can suppress a knock-circuit DTC by its code alone,
  // without ever saying "knock sensor". Such code-only instructions must
  // not be silently omitted from an otherwise supported VATS proposal.
  for (const phrase of [
    'disable P0327 and P0332',
    'suppress DTC P0327',
    'set P0332 to no error',
    'mark P0325 not reported',
    'turn off code P0330',
    'ignore codes P0327/P0332'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `code-only knock fault suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'), `missing knock DTC review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  // Run132: Object-first "turn P0327 off" is a DTC suppression request,
  // not a harmless code mention. Do not prepare a partial VATS proposal.
  for (const phrase of [
    'turn P0327 off',
    'switch P0332 off',
    'turn codes P0327 and P0332 off',
    'shut DTC P0330 off'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `object-first knock DTC suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'), `missing knock DTC review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const phrase of [
    'log P0327 and P0332',
    'inspect DTC P0327',
    'keep P0332 reporting active',
    'record P0325 fault history',
    'check whether P0327 is off',
    'turn P0327 logging on'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'), `diagnostic-only DTC request falsely blocked: ${phrase}`);
  }
  // Run169: Assignment-style DTC reporting changes were silently ignored in
  // combined VATS requests. A code or named knock DTC assigned to an OFF/
  // suppressed state is not permission to prepare only the VATS proposal.
  // The code names are generic triage fixtures, NOT a verified ECU DTC map.
  for (const phrase of [
    'P0327 = no error',
    'P0332: not reported',
    'DTC P0325 = disabled',
    'codes P0327/P0332: off',
    'set P0327 = false',
    'knock sensor DTC = no error',
    'knock control fault reporting: disabled',
    'knock sensor diagnostics = 0'
  ]) {
    const request = `Disable VATS and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `assignment-style knock DTC suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing assignment-style knock DTC review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS proposal for: ${phrase}`);
  }
  for (const phrase of [
    'log P0327 = active',
    'inspect P0332: present',
    'knock sensor diagnostics = enabled',
    'verify knock control fault reporting: on'
  ]) {
    const review = reviewP01Request({ activeProject: active, request: `Disable VATS and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `non-suppressing DTC observation incorrectly blocked: ${phrase}`);
  }
  // Run173: Numeric-zero and `as` reporting changes were silently ignored
  // by Run172 in otherwise valid VATS/fan requests. These generic DTC names
  // are syntax-only triage fixtures, not an exact-OS calibration definition.
  for (const phrase of [
    'set knock sensor DTCs to 0',
    'set knock sensor codes to zero',
    'change knock control fault reporting to false',
    'mark knock sensor diagnostics as not reported',
    'set P0327 to 0',
    'set P0332 to zero',
    'mark P0332 as not reported',
    'P0327 = zero',
    'knock sensor DTCs = zero'
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock diagnostic suppression accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `missing knock diagnostic review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'read P0327 at 0 counts',
    'log knock sensor DTCs as reported',
    'inspect P0332 to see whether it is reported',
    'verify knock sensor diagnostics are enabled'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-diagnostic-suppression'),
      `diagnostic observation falsely treated as suppression: ${phrase}`);
  }
  // Diagnostic observations are not instructions to disable knock control.
  for (const request of [
    'Disable VATS and log knock retard at 0 degrees.',
    'Disable VATS and inspect knock retard readings.',
    'Disable VATS and verify knock control is enabled.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'), `false knock-delete flag: ${request}`);
  }
  // Nearby VATS verbs must not be misread as a knock delete.
  for (const request of [
    'Disable VATS and inspect knock sensors.',
    'Disable VATS and keep knock sensors enabled.',
    'Disable VATS and turn on knock sensors.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'), `false knock-delete detection: ${request}`);
  }
  const stageCam = reviewP01Request({ activeProject: active, request: 'Disable VATS and tune my stage 2 cam.' });
  assert.equal(stageCam.ready, false, 'unbranded physical stage cam must require review');
  assert(stageCam.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'));

  const fansEnabledWithTemperatures = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS, enable electric fans, and set fans on at 210 F and off at 190 F.'
  });
  assert.equal(fansEnabledWithTemperatures.ready, false);
  assert(fansEnabledWithTemperatures.unresolvedRequests.some(item => item.type === 'fan-output-enable'));

  // Run127 regression: requesting ECM fan output/relay commissioning is
  // different from editing fan temperature cells. Natural wordings such as
  // "turn on electric fans" and "switch to electric fans" were silently
  // discarded when a valid fan temperature pair was present.
  for (const request of [
    'Disable VATS, turn on the electric fans, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, switch to electric fans, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, activate PCM fan control, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, enable the fan relay outputs, and set fans on at 210 F and off at 190 F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output commissioning silently accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'), `missing fan output review: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial fan/VATS proposal: ${request}`);
  }
  // Run129 regression: "turn on PCM fan control" and its object-first
  // variants explicitly commission controller outputs, not just thresholds.
  // They must never be silently dropped from a combined VATS/fan request.
  for (const request of [
    'Disable VATS, turn on PCM fan control, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, switch on ECM fan relay outputs, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, turn the PCM fan control on, and set fans on at 210 F and off at 190 F.',
    'Disable VATS, turn the ECM fan outputs on, and set fans on at 210 F and off at 190 F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `controller fan enable request accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'), `controller output commissioning silently ignored: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial controller output proposal: ${request}`);
  }
  // Run150: Object-first fan relay/output commissioning without an explicit
  // PCM/ECM prefix must not disappear behind an otherwise valid threshold
  // pair. "Turn fan outputs on" changes output state, not coolant setpoints.
  for (const phrase of [
    'turn fan relays on',
    'switch the fan outputs on',
    'turn my electric fan control on',
    'power both fan drivers on'
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output commissioning accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `object-first fan output enablement silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  // Run156: Modal/declarative output commissioning is an independent
  // hardware state change, even without an imperative "enable" verb.
  // These fixture temperatures are not physical-vehicle recommendations.
  for (const phrase of [
    'fan relays should be enabled',
    'ECM fan outputs need to be activated',
    'fan drivers must be on',
    'PCM fan control is to be enabled',
    'fan outputs need to be turned on'
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `declarative fan output commissioning accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `declarative fan output commissioning silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'fan relays are already enabled',
    'the fan outputs were enabled last year'
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `existing-output status misclassified as enable instruction: ${phrase}`);
  }
  // Run166: A fan-output enable FLAG or BIT is an independent ECM output
  // configuration, not a fan temperature threshold. These are mock requests,
  // never verified OS addresses, settings, or real vehicle targets.
  for (const phrase of [
    'set PCM fan output enable flag to 1',
    'set electric fan relay enable bit to true',
    'set ECM fan control enable flag to on',
    'fan relay output enable bit should be 1',
    'set fan output enable state to enabled'
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan enable flag silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `fan enable flag not separately reviewed: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan flag proposal: ${phrase}`);
  }
  for (const phrase of [
    'set PCM fan output enable flag to 0',
    'set electric fan relay enable bit to false',
    'set ECM fan control enable flag to off',
    'fan relay output enable bit must be 0'
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan disable flag silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-disable'),
      `fan disable flag not separately reviewed: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan disable flag proposal: ${phrase}`);
  }
  for (const phrase of [
    'inspect PCM fan output enable flag',
    'log electric fan relay enable bit',
    'verify ECM fan control enable state'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.` });
    assert(!review.unresolvedRequests.some(item =>
      item.type === 'fan-output-enable' || item.type === 'fan-output-disable'),
    `read-only fan flag inspection incorrectly classified: ${phrase}`);
  }
  // Run224: Indexed fan output states can include an intervening status or
  // enable field ("fan relay 1 enabled = false"). These are physical relay/
  // driver states, not coolant setpoints. An ambiguous assignment or stated
  // condition must not silently vanish from a VATS + temperature proposal.
  // No flag polarity, ECM pin or OS mapping is assumed by these fixtures.
  for (const [phrase, type] of [
    ['Fan relay 1 enabled = false', 'fan-output-disable'],
    ['ECM fan output 2 active: true', 'fan-output-enable'],
    ['Fan relay #1 status = off', 'fan-output-disable'],
    ['Fan output 2 enable = 0', 'fan-output-disable'],
    ['Fan relay 2 is disabled', 'fan-output-disable'],
    ['Fan relay 1 is enabled', 'fan-output-enable']
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `indexed output state silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === type),
      `missing separate indexed output review for: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite: ${phrase}`);
  }
  for (const phrase of [
    'Inspect fan relay 1 status',
    'Log ECM fan output 2 enabled state',
    'Verify fan relay #1 wiring'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item =>
      ['fan-output-enable', 'fan-output-disable'].includes(item.type)),
    `diagnostic-only fan check falsely classified as output state: ${phrase}`);
  }

  // Run167: Assignment notation is common in calibration requests. A
  // requested fan-output flag or knock-retard zeroing must not vanish when
  // combined with an otherwise recognized VATS/temperature request. These
  // are synthetic inputs, not ECU definitions, addresses, or target values.
  for (const [phrase, type] of [
    ['set PCM fan output enable flag = 1', 'fan-output-enable'],
    ['ECM fan relay enable bit: true', 'fan-output-enable'],
    ['set electric fan control enable state = enabled', 'fan-output-enable'],
    ['set PCM fan output enable flag = 0', 'fan-output-disable'],
    ['electric fan relay enable bit: false', 'fan-output-disable'],
    ['set knock retard multiplier = 0', 'knock-sensor-delete'],
    ['KR gain = zero', 'knock-sensor-delete'],
    ['set knock retard = 0', 'knock-sensor-delete']
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `assignment silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === type),
      `assignment not separately reviewed: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal from assignment: ${phrase}`);
  }
  for (const phrase of [
    'inspect PCM fan output enable flag',
    'log KR gain',
    'review knock retard multiplier'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.` });
    assert(!review.unresolvedRequests.some(item =>
      ['fan-output-enable', 'fan-output-disable', 'knock-sensor-delete'].includes(item.type)),
    `read-only diagnostic mislabeled as assignment: ${phrase}`);
  }
  // Run206: Fan PWM duty/frequency and relay-output polarity are separate
  // controller-output strategy changes, not coolant temperature thresholds.
  // These are request-triage fixtures only, not verified P01/OS parameters.
  for (const phrase of [
    'set fan PWM duty cycle to 80%',
    'set ECM fan PWM duty cycle to 80%',
    'fan PWM duty cycle = 80%',
    'change fan PWM frequency to 100 Hz',
    'set fan output polarity to active low',
    'ECM fan relay output polarity = inverted',
    'set fan relay control to ground switched',
    'fan relay output polarity should be active low'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output strategy silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-strategy'),
      `fan output strategy not independently reviewed: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan strategy proposal: ${phrase}`);
  }
  for (const phrase of [
    'inspect fan PWM duty cycle',
    'log ECM fan PWM frequency',
    'verify fan relay output polarity',
    'read fan relay control ground switched state'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-strategy'),
      `read-only fan strategy observation falsely blocked: ${phrase}`);
  }
  // Run178: The fan relay/output state itself may be assigned without an
  // explicit "enable flag" label. This is still an independent physical ECM
  // output request, never a temperature-only calibration. Synthetic strings
  // below do NOT establish a controller's pins, polarity, or fan setpoints.
  for (const [phrase, type] of [
    ['ECM fan output = on', 'fan-output-enable'],
    ['PCM fan relay: enabled', 'fan-output-enable'],
    ['fan relay output = 1', 'fan-output-enable'],
    ['fan output enabled = true', 'fan-output-enable'],
    ['fan relay outputs active = 1', 'fan-output-enable'],
    ['fan control output: false', 'fan-output-disable'],
    ['fan relays = off', 'fan-output-disable'],
    ['fan relay driver = 0', 'fan-output-disable'],
    ['electric fan driver: inactive', 'fan-output-disable']
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output assignment silently accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === type),
      `fan output assignment not separately reviewed: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal from fan output assignment: ${phrase}`);
  }
  for (const phrase of [
    'inspect ECM fan output state',
    'log PCM fan relay status',
    'verify fan relay driver wiring',
    'fan output voltage = 12 V'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.` });
    assert(!review.unresolvedRequests.some(item =>
      item.type === 'fan-output-enable' || item.type === 'fan-output-disable'),
    `read-only or non-state fan output phrase mislabeled: ${phrase}`);
  }
  // Run251: Explicit ECM/PCM fan-output pin assignment is separate from
  // fan-temperature thresholds and output enablement. Pin numbers here are
  // synthetic request tokens, not verified controller pins or OS mappings.
  for (const phrase of [
    'Assign ECM fan output to pin 42.',
    'Fan relay control pin = 42.',
    'Use PCM pin 42 for the fan relay.',
    'Move the fan relay output to pin 42.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output pin assignment accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `missing separate exact-OS fan pin review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal despite fan pin assignment: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the ECM fan output pin.',
    'Verify fan relay pin wiring.',
    'Log the PCM fan output voltage.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `diagnostic-only fan pin phrase misclassified: ${phrase}`);
  }

  // Run252: A fan-output pin *property* can be requested without the verbs
  // covered by Run251 ("set output pin to", "should use pin", or routing
  // "through" a controller pin). These numbers are synthetic text fixtures,
  // never proof of a supported ECM pin, polarity, or exact-OS definition.
  for (const phrase of [
    'Set ECM fan output pin to 42.',
    'Change fan relay output pin to 42.',
    'Route fan relay control through ECM pin 42.',
    'Fan relay output should use pin 42.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output pin-property change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `pin-property change lacked separate hardware/OS review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite fan pin-property change: ${phrase}`);
  }
  for (const phrase of [
    'Inspect ECM fan output pin.',
    'Verify the fan relay control through the harness.',
    'Log ECM fan output voltage.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `diagnostic-only phrase incorrectly flagged as a pin change: ${phrase}`);
  }

  // Run253: Connector-qualified fan pin assignments are independent hardware
  // decisions. C2/42 are synthetic request tokens, not a real ECM pin map.
  for (const phrase of [
    'Assign ECM fan output to connector C2 pin 42.',
    'Route fan relay output through ECM C2 pin 42.',
    'Set fan relay output pin to C2-42.',
    'Use ECM connector C2 pin 42 for the fan relay.',
    'Fan relay output pin = C2-42.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `connector-qualified fan pin change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `missing connector-qualified fan pin review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite connector-qualified pin change: ${phrase}`);
  }
  for (const phrase of [
    'Inspect which ECM connector C2 pin controls the fan relay.',
    'Verify ECM connector C2 pin 42 wiring for the fan relay.',
    'Log fan relay output status before changing the wiring.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `read-only connector diagnostic incorrectly treated as pin change: ${phrase}`);
  }

  // Run254: A fan output pin assignment with an electric/cooling/radiator
  // qualifier is still a separate hardware decision. A shared fan-temperature
  // pair must not silently drop it. All pins/connector labels are synthetic.
  for (const phrase of [
    'Assign electric fan output to connector C2 pin 42.',
    'Set cooling fan relay output pin to C2-42.',
    'Route radiator fan control through ECM C2 pin 42.',
    'Assign PCM electric fan relay output to pin 42.',
    'Use ECM connector C2 pin 42 for the electric fan relay.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `qualified fan pin change accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `missing independent qualified fan pin review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite qualified pin assignment: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the electric fan output pin wiring.',
    'Verify cooling fan relay output on the harness.',
    'Log the radiator fan control voltage.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `read-only qualified fan pin check was blocked: ${phrase}`);
  }

  // Run255: Connector-first fan-output pin assignments were invisible to
  // fan-first mapping checks. These are text-only synthetic connector/pin
  // labels, never verified ECM mappings or proof of output compatibility.
  for (const phrase of [
    'ECM connector C2 pin 42 = electric fan relay output.',
    'ECM C2 pin 42 should drive the cooling fan relay.',
    'ECM C2-42 is the new radiator fan output.',
    'Assign C2 pin 42 as the electric fan relay output.',
    'PCM C2/42: fan control output.'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `connector-first fan assignment accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `missing connector-first fan hardware review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i,
    `partial VATS/fan proposal despite connector-first assignment: ${phrase}`);
  }
  for (const phrase of [
    'Inspect whether ECM C2 pin 42 drives the fan relay.',
    'Verify the wiring at ECM connector C2 pin 42 for the cooling fan.',
    'Log PCM C2/42 fan output voltage without changing wiring.'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-pin-mapping'),
      `read-only connector-first fan inspection was blocked: ${phrase}`);
  }

  // Run168: Explicit assignment of a knock-control enable/active flag to an
  // OFF state must not be silently omitted from a VATS/fan proposal. These
  // are synthetic request strings only, not OS-specific flag definitions.
  for (const phrase of [
    'knock retard enable flag = 0',
    'KR enable flag: false',
    'knock control enabled = off',
    'set knock retard enable flag = 0',
    'knock detection active flag = 0',
    'knock feedback enable bit = false'
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock enable-flag assignment accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `knock protection flag review missing: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal from knock flag: ${phrase}`);
  }
  for (const phrase of [
    'knock retard enable flag = 1',
    'inspect knock retard enable flag',
    'log KR enable state',
    'verify knock detection active flag is on'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `non-disabling knock flag request falsely blocked: ${phrase}`);
  }
  // Run151: Disabling a fan relay/output is a separate physical controller
  // state change, not a fan-off temperature. It must not be dropped when
  // VATS and the fan threshold pair otherwise look supported.
  for (const phrase of [
    'disable the fan relay outputs',
    'turn fan relays off',
    'switch the ECM fan output off',
    'shut off the PCM fan driver'
  ]) {
    const request = `Disable VATS, ${phrase}, and set fans on at 210 F and off at 190 F.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `fan output shutdown accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-disable'),
      `fan output shutdown silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  // Run152 regression: declarative fan-output shutdown language must not
  // disappear behind otherwise supported VATS + temperature instructions.
  // Fixture temperatures below are NOT targets for a physical vehicle.
  for (const phrase of [
    'fan relay outputs should be disabled',
    'the fan relay outputs are off',
    'fan relays must stay off',
    'the ECM cooling fan driver needs to be disabled',
    'fan control outputs will be deactivated'
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `declarative fan output shutdown accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-disable'),
      `fan output state change silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal: ${phrase}`);
  }
  for (const phrase of [
    'the fan relay outputs are enabled',
    'fan relays should stay active'
  ]) {
    const request = `Disable VATS, set fans on at 210 F and off at 190 F, and ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-disable'),
      `false fan-output shutdown detection: ${phrase}`);
  }
  // Temperature-only wording is not an instruction to enable a physical output.
  for (const request of [
    'Disable VATS and turn fans on at 210 F and off at 190 F.',
    'Disable VATS and set fans to turn on at 210 F and off at 190 F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'), `false output-enable flag: ${request}`);
  }
  const partialFans = reviewP01Request({ activeProject: active, request: 'Disable VATS and set fans on at 210 F.' });
  assert.equal(partialFans.ready, false);
  assert(partialFans.unresolvedRequests.some(item => item.type === 'fan-control-incomplete'));
  const reverseFans = reviewP01Request({ activeProject: active, request: 'Disable VATS, set fans on at 180 F and off at 200 F.' });
  assert.equal(reverseFans.ready, false);
  assert(reverseFans.unresolvedRequests.some(item => item.type === 'fan-control-invalid'));

  const combinedWithThresholds = reviewP01Request({
    activeProject: active, request: 'Disable VATS, set fans on at 210 F and off at 190 F, and delete knock sensors.'
  });
  assert.equal(combinedWithThresholds.ready, false);
  assert.deepEqual(combinedWithThresholds.parsed.intents.map(item => item.type), ['vats-disable', 'fan-control']);
  assert.deepEqual(combinedWithThresholds.unresolvedRequests.map(item => item.type), ['knock-sensor-delete']);

  // Run133 regression: the quick-service parser extracts only the first
  // fan on/off pair. A second pair or extra threshold must never disappear
  // behind an otherwise valid VATS + fan proposal.
  for (const request of [
    'Disable VATS and set fans on at 210 F and off at 190 F, then on at 220 F and off at 200 F.',
    'Disable VATS and set fans on at 210 F and off at 190 F; set fans on at 220 F and off at 200 F.',
    'Disable VATS and set fans on at 210 F and off at 190 F; also fan off at 180 F.',
    'Disable VATS and set fans on at 210 F and off at 190 F, but on at 205 F instead.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `multiple fan threshold instructions accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-multiple-thresholds'), `missing multiple-threshold review: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial first-pair fan proposal: ${request}`);
  }
  for (const request of [
    'Disable VATS and set fans on at 210 F and off at 190 F.',
    'Disable VATS and set both electric fans on at 100 C and off at 90 C.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-multiple-thresholds'), `single fan pair falsely flagged: ${request}`);
  }

  // Run179: The parser defaults unitless values to Fahrenheit, or adopts
  // Celsius from one threshold. Neither is authorization for the other
  // threshold's unit. Mixed VATS/fan plans must fail closed on both cases.
  for (const request of [
    'Disable VATS and set fans on at 210 and off at 190.',
    'Disable VATS and set fans on at 100 C and off at 90.',
    'Disable VATS and set fans on at 210 F and off at 190.',
    'Disable VATS and set fans on at 210 and off at 190 F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unitless fan threshold accepted: ${request}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-threshold-units-unconfirmed'),
      `missing independent fan-unit review: ${request}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal with guessed units: ${request}`);
  }
  for (const request of [
    'Disable VATS and set fans on at 210 F and off at 190 F.',
    'Disable VATS and set fans on at 100 C and off at 90 C.',
    'Disable VATS and turn fans on at 210 degrees F and off at 190 degrees F.'
  ]) {
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-threshold-units-unconfirmed'),
      `explicit fan units incorrectly blocked: ${request}`);
  }
  // Run180: A complete numeric pair does not override an explicit request
  // to preserve existing fan thresholds. Previously the parser admitted the
  // numeric pair and silently dropped the later contradiction. All inputs
  // here are synthetic review fixtures, not ECM setpoint recommendations.
  for (const phrase of [
    'but do not change fan temperatures',
    'but keep the fan settings unchanged',
    'actually leave the fan thresholds alone',
    'but never adjust fan setpoints',
    'without modifying fan temperatures',
    'fan temps must remain stock',
    'preserve the cooling fan calibration as-is'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F; ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `contradictory fan threshold request accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-threshold-intent-contradiction'),
      `missing fan preservation contradiction review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite preservation request: ${phrase}`);
  }
  for (const phrase of [
    'inspect the fan temperatures',
    'leave the radio settings unchanged',
    'do not change the thermostat'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F; ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-threshold-intent-contradiction'),
      `non-contradictory request falsely flagged: ${phrase}`);
  }
  // A second fan bank or mixed temperature units must never be silently
  // collapsed into the first recognized pair and applied alongside VATS.
  const mixedUnits = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS and set fans on at 210 F and off at 190 C.'
  });
  assert.equal(mixedUnits.ready, false, 'mixed F/C must not be interpreted as all F');
  assert(mixedUnits.unresolvedRequests.some(item => item.type === 'fan-mixed-units'));
  assert.throws(() => buildGoalProposal({
    request: mixedUnits.requestText, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /full tune request is not supported/i);

  const explicitCelsius = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS and set fans on at 100 C and off at 90 C.'
  });
  assert.equal(explicitCelsius.ready, true, 'uniform Celsius thresholds should remain supported');
  assert.equal(explicitCelsius.parsed.intents.find(item => item.type === 'fan-control').unit, 'C');

  const splitBanks = reviewP01Request({
    activeProject: active,
    request: 'Disable VATS and set fan 1 on at 205 F and fan 2 on at 215 F and off at 190 F.'
  });
  assert.equal(splitBanks.ready, false, 'fan bank 2 must not disappear from a combined request');
  assert(splitBanks.unresolvedRequests.some(item => item.type === 'fan-bank-specific'));

  // The parser formerly truncated the tail, hiding a knock-delete request.
  const longRequest = 'Disable VATS. ' + 'confirm engine details. '.repeat(100) + 'Delete knock sensors.';
  assert(longRequest.length > 2000);
  assert.throws(() => reviewP01Request({ activeProject: active, request: longRequest }), /2,000|2000|length/i);
  assert.throws(() => buildGoalProposal({
    request: { ...lowRisk.parsed, text: longRequest }, workspace: workspace(), activeProject: active, confirmations: {}, ruleFolders: []
  }), /2,000|2000|length/i);

  const highRisk = reviewP01Request({
    activeProject: active,
    request: 'Give it a mild ghost cam, set the rev limiter to 6000 RPM, and set the speed limiter to 190 MPH.'
  });
  assert.equal(highRisk.ready, false);
  assert(highRisk.missingSafetyFacts.some(item => /valvetrain/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /tire speed rating/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /closed-course/i.test(item)));
  assert(highRisk.missingSafetyFacts.some(item => /ghost-idle/i.test(item)));

  const factsText = 'Valvetrain and rotating assembly verified for 6000 RPM. Tires rated 200 MPH. Driveshaft and driveline verified. Brakes, bearings, suspension and stability verified. Closed-course testing only. I accept ghost idle vacuum, brake-assist, emissions and drivability risks.';
  const facts = parseP01SafetyFacts(factsText);
  assert.equal(facts.valvetrainVerified, true);
  assert.equal(facts.tireRatingMph, 200);
  assert.equal(facts.drivelineVerified, true);
  assert.equal(facts.brakesVerified, true);
  assert.equal(facts.closedCourse, true);
  assert.equal(facts.ghostCamRisksAccepted, true);

  // Negative or uncertain declarations must not satisfy high-risk confirmations.
  // Run119 accepted these because its regexes matched 'not verified' and
  // 'not rated' as if they were affirmative safety evidence.
  const deniedFacts = parseP01SafetyFacts('Valvetrain not verified for 6500 RPM. Tires not rated 200 MPH. Driveline not verified. Brakes not verified. Not closed-course testing. I do not accept ghost idle risks.');
  assert.equal(deniedFacts.valvetrainVerified, false, 'negated valvetrain verification');
  assert.equal(deniedFacts.tireRatingMph, null, 'negated tire rating');
  assert.equal(deniedFacts.drivelineVerified, false, 'negated driveline verification');
  assert.equal(deniedFacts.brakesVerified, false, 'negated brakes verification');
  assert.equal(deniedFacts.closedCourse, false, 'negated closed-course confirmation');
  assert.equal(deniedFacts.ghostCamRisksAccepted, false, 'negated ghost-cam risk acceptance');
  const deniedReview = reviewP01Request({ activeProject: active, request: highRisk.requestText, safetyFacts: 'Valvetrain not verified. Tires not rated 200 MPH. Driveline not verified. Brakes not verified. Not closed-course testing. I do not accept ghost idle risks.' });
  assert.equal(deniedReview.ready, false, 'negative confirmations cannot clear high-risk review');
  assert(deniedReview.missingSafetyFacts.length >= 5);
  const mixedFacts = parseP01SafetyFacts('Valvetrain not verified. Tires rated 200 MPH. Driveline not verified. Brakes verified. Closed-course testing only. I accept ghost idle risks.');
  assert.equal(mixedFacts.valvetrainVerified, false);
  assert.equal(mixedFacts.tireRatingMph, 200);
  assert.equal(mixedFacts.drivelineVerified, false);
  assert.equal(mixedFacts.brakesVerified, true);
  assert.equal(mixedFacts.closedCourse, true);
  assert.equal(mixedFacts.ghostCamRisksAccepted, true);

  const contradictory = parseP01SafetyFacts('Valvetrain not verified. Valvetrain verified. Tires not rated 200 MPH. Tires rated 200 MPH. Brakes verified. Brakes not verified.');
  assert.equal(contradictory.valvetrainVerified, false, 'contradictory valvetrain claims fail closed');
  assert.equal(contradictory.tireRatingMph, null, 'contradictory tire ratings fail closed');
  assert.equal(contradictory.brakesVerified, false, 'contradictory brake claims fail closed');

  // Run329: A positive-sounding verification word does not override a
  // contradictory unsafe or failed condition in the same safety statement.
  // These are synthetic text claims, not evidence that any vehicle is safe.
  for (const [claim, key, expectedMissing] of [
    ['Valvetrain verified unsafe for 6000 RPM', 'valvetrainVerified', /valvetrain/i],
    ['Driveline verified but failed inspection', 'drivelineVerified', /driveshaft|driveline/i],
    ['Brakes verified inadequate', 'brakesVerified', /brakes|bearings/i],
    ['Tires rated 200 MPH but damaged', 'tireRatingMph', /tire speed rating/i]
  ]) {
    const safeFacts = factsText.replace(
      key === 'valvetrainVerified' ? 'Valvetrain and rotating assembly verified for 6000 RPM' :
      key === 'drivelineVerified' ? 'Driveshaft and driveline verified' :
      key === 'brakesVerified' ? 'Brakes, bearings, suspension and stability verified' :
      'Tires rated 200 MPH', claim);
    const parsedFacts = parseP01SafetyFacts(safeFacts);
    assert.equal(parsedFacts[key], key === 'tireRatingMph' ? null : false,
      `contradictory mechanical safety claim admitted: ${claim}`);
    const reviewed = reviewP01Request({ activeProject: active, request: highRisk.requestText, safetyFacts: safeFacts });
    assert.equal(reviewed.ready, false, `high-risk review accepted: ${claim}`);
    assert(reviewed.missingSafetyFacts.some(item => expectedMissing.test(item)),
      `missing separate safety verification requirement: ${claim}`);
  }

  // A typed or placeholder OS does not establish exact OS-matched readiness.
  for (const os of ['', 'unknown', 'P01', '1234']) {
    const noOs = reviewP01Request({ activeProject: { ...active, os }, request: 'Disable VATS.' });
    assert.equal(noOs.ready, false, `missing/unidentified OS was marked ready: ${os}`);
    assert(noOs.missingSafetyFacts.some(item => /OS|operating system/i.test(item)));
  }

  // Run264: a physical electric-fan conversion is NOT verified ECM fan-output
  // enablement. A quick-service VATS/temperature pair must not silently
  // discard a newly installed/converted fan system. All temperatures and OS
  // labels in these fixtures are synthetic, not owner calibration values.
  for (const phrase of [
    'I converted from a clutch fan to electric fans',
    'I installed an electric fan conversion kit',
    'I swapped the stock fan for electric fans',
    'I converted the truck to dual electric fans',
    'I retrofitted electric cooling fans',
    'I am converting my truck from mechanical fans to electric fans'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unverified physical fan conversion accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `fan conversion omitted independent output commissioning review: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal after conversion: ${phrase}`);
  }
  for (const phrase of [
    'My electric fans are already working',
    'I am inspecting electric fan conversion kit options',
    'Compare Celsius and Fahrenheit fan temperature units',
    'Please log the electric fan status'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `non-commissioning fan context falsely blocked: ${phrase}`);
  }

  // Run271: installing standalone electric fans is a physical conversion
  // even when the owner never says "kit", "swap", or "converted". The
  // quick-service temperature pair must not silently omit ECM output review.
  // All OS labels and temperatures are synthetic test data.
  for (const phrase of [
    'I installed two electric fans on the truck',
    'I added dual electric fans to my 5.3',
    'I mounted electric cooling fans after removing the clutch fan',
    'I fitted aftermarket electric fans',
    'I am installing a pair of electric fans',
    'We mounted new electric fans on the radiator'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `installed fan hardware admitted without output review: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `independent fan-output commissioning omitted: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite installation: ${phrase}`);
  }
  for (const phrase of [
    'I have not installed electric fans',
    'I never installed electric fans',
    'Check whether I installed electric fans',
    'I am comparing electric fans for later',
    'My electric fans are already working'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'fan-output-enable'),
      `non-installation fan statement falsely classified: ${phrase}`);
  }

  // Run267: physical cam swaps described without the exact words "camshaft"
  // or "Stage 2 cam" still require an independent real-cam calibration
  // review. A VATS/fan quick-service request must not silently discard an
  // installed cam or a bumpstick tune. These are syntax-only fixtures;
  // no cam-card specs, idle targets, or OS addresses are assumed.
  for (const phrase of [
    'I installed a bigger cam, need the idle tune',
    'Cam is installed, need to tune idle',
    'Tune my idle because I swapped cams',
    'I swapped the cam out, need an idle tune',
    'New cam went in, please adjust idle',
    'Installed a different cam and want idle adjusted',
    'Change idle airflow for my LSX cam',
    'Calibrate idle after installing a cam',
    'I have an LSXceleration stage 2 bumpstick, tune idle',
    'Need to tune for the new bumpstick'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed physical cam tune accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `physical cam calibration silently dropped: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite physical cam: ${phrase}`);
  }
  for (const phrase of [
    'Inspect the cam position sensor',
    'Log cam position sensor readings',
    'Tune the camera preview',
    'I am comparing bumpstick options, not tuning a cam'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `non-calibration cam discussion falsely blocked: ${phrase}`);
  }

  // Run270: A physical cam already running in an LS engine can be described
  // without an install/swap verb, "stage", or "camshaft". Never silently
  // omit its unverified idle calibration from a combined VATS/fan proposal.
  // These are language-only fixtures, NOT cam-card specifications or OS maps.
  for (const phrase of [
    'I am running an aftermarket cam in the 5.3 and need idle tuned',
    'I have a performance cam in the 5.3 and need idle tuned',
    'I got a new cam in the LS and need idle tuning',
    'My 5.3 has a custom cam and needs an idle tune',
    'We are running a bigger cam in the motor',
    'The engine runs an LSX cam and needs idle calibration'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unreviewed running cam accepted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `physical cam calibration silently omitted: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal despite running cam: ${phrase}`);
  }
  for (const phrase of [
    'I have a cam position sensor in the 5.3',
    'We are running a camera preview',
    'I have a performance cam sitting in a box for later',
    'Check whether my engine has a cam position sensor'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `non-installed or non-camshaft context misclassified: ${phrase}`);
  }

  // Run400: A physical LSX Stage 2 cam request combined with VATS/fans and
  // missing knock feedback must fail atomically. Synthetic fan numbers and OS
  // here are fixture inputs, never ECM compatibility or calibration proof.
  for (const phrase of [
    'My installed LSX Stage 2 cam needs tuning and both knock sensors are removed',
    'Calibrate my LSX Stage 2 camshaft and I disconnected the knock sensors'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `combined cam/knock request admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'physical-camshaft-tune'),
      `missing cam-card review: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock diagnostic review: ${phrase}`);
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({ request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: [] }), /full tune request is not supported/i,
    `partial calibration proposal admitted: ${phrase}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated: ${phrase}`);
  }

  // Run268 regression: an unconnected knock-sensor circuit may be described
  // as "still unplugged" or a forgotten reconnect. This is a diagnostic
  // blocker, never consent to suppress knock protection or DTC reporting.
  for (const phrase of [
    'Both knock sensors are still unplugged',
    'The knock sensors were not reconnected',
    'I forgot to plug in the knock sensors',
    'I never hooked up the knock sensors',
    'I forgot to reinstall both knock sensors',
    'We did not reconnect the knock sensors'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `unverified knock connection admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing independent knock diagnostics: ${phrase}`);
    assert.throws(() => buildGoalProposal({
      request, workspace: workspace(), activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial VATS/fan proposal despite knock fault: ${phrase}`);
  }
  for (const phrase of [
    'Are the knock sensors still unplugged?',
    'Check whether the knock sensors are still unplugged',
    'I did not forget to plug in the knock sensors',
    'The knock sensors are plugged in'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `diagnostic question or affirmative connection falsely classified as missing: ${phrase}`);
  }

  // Run269: physical knock-sensor substitution with dummy plugs or resistors
  // is not equivalent to retaining functional knock feedback. Never drop it
  // from a combined VATS/fan request. No real ECM OS or wiring is inferred.
  for (const phrase of [
    'I replaced both knock sensors with block-off plugs',
    'The knock sensors were replaced with dummy plugs',
    'I installed dummy knock sensors instead of the real sensors',
    'I used resistors in place of the knock sensors',
    'I put block off plugs where the knock sensors used to be',
    'Both knock sensors are bypassed',
    'The knock sensors were spoofed',
    'Knock sensor input is faked',
    'I replaced the knock sensors with plugs'
  ]) {
    const request = `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.`;
    const review = reviewP01Request({ activeProject: active, request });
    assert.equal(review.ready, false, `knock feedback substitution admitted: ${phrase}`);
    assert(review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `missing knock-system diagnostic blocker: ${phrase}`);
    // Run401: Rejection must be atomic even when a plausible-looking XDF
    // contains VATS and fan tables. Dummy sensors/resistors are not knock proof.
    const draft = workspace();
    const before = JSON.stringify(draft);
    assert.throws(() => buildGoalProposal({
      request, workspace: draft, activeProject: active,
      confirmations: {}, ruleFolders: []
    }), /full tune request is not supported/i, `partial proposal despite substituted knock feedback: ${phrase}`);
    assert.equal(JSON.stringify(draft), before, `workspace mutated despite substituted knock feedback: ${phrase}`);
  }
  for (const phrase of [
    'Check whether the knock sensors were replaced with dummy plugs',
    'Inspect if resistors were used in place of the knock sensors',
    'I replaced the knock sensors with genuine working sensors',
    'I compared dummy knock sensor products but installed none'
  ]) {
    const review = reviewP01Request({ activeProject: active,
      request: `Disable VATS and set fans on at 210 F and off at 190 F. ${phrase}.` });
    assert(!review.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
      `non-substitution or diagnostic question misclassified: ${phrase}`);
  }

  const highRiskReady = reviewP01Request({ activeProject: active, request: highRisk.requestText, safetyFacts: factsText });
  assert.equal(highRiskReady.ready, true);
  assert.equal(highRiskReady.missingSafetyFacts.length, 0);
  assert.notEqual(highRisk.requestFingerprint, highRiskReady.requestFingerprint);

  assert.throws(() => reviewP01Request({ activeProject: { ...active, controller: 'P59' }, request: 'Disable VATS' }), /not identified as a P01/i);
  assert.throws(() => reviewP01Request({ activeProject: null, request: 'Disable VATS' }), /activate a P01 project/i);

  const proposal = buildGoalProposal({
    request: lowRisk.requestText,
    workspace: workspace(),
    activeProject: active,
    confirmations: lowRisk.confirmations,
    ruleFolders: []
  });
  const selection = selectGoalMapCandidates(proposal);
  assert.equal(selection.safeToAutoMap, true);
  assert(selection.actionIds.includes('vats-disable'));
  assert(selection.actionIds.some(id => /^fan-/.test(id)));
  assert.equal(selection.proposalIds.length, 5);

  const html = fs.readFileSync(path.join(__dirname, '../src/renderer/index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(__dirname, '../src/renderer/app.js'), 'utf8');
  const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  assert(html.includes('UNIVERSAL P01 COMMAND CENTER'));
  assert(html.includes('CONFIRMATION 1 OF 2') && html.includes('CONFIRMATION 2 OF 2'));
  assert(html.includes('id="quickServiceRequest"'));
  assert(html.includes('id="p01AutoSafetyFacts"'));
  assert(!html.includes('id="quickServiceVats"'));
  assert(!html.includes('id="p01AutoValvetrain"'));
  assert(renderer.includes('reviewP01Request'));
  assert(renderer.includes('quickServicePlanConfirmed'));
  assert(main.includes("ipcMain.handle('p01-request:review'"));
  const startHandler = main.slice(main.indexOf("ipcMain.handle('p01-auto:start'"), main.indexOf("ipcMain.handle('p01-auto:resume'"));
  assert(startHandler.includes('reviewP01Request') && startHandler.indexOf('reviewP01Request') < startHandler.indexOf('prepareFreshPhysicalP01Bridge'), 'P01 request safety review must precede any hardware bridge preparation');

  if (!quiet) console.log('✓ Universal P01 request center: exact OS, complete-request coverage, safety facts, and two-stage confirmation');
  return { scenarios: 21 };
}

if (require.main === module) {
  try { runP01UniversalRequestSimulations(); }
  catch (error) { console.error(error.stack || error); process.exit(1); }
}

module.exports = { runP01UniversalRequestSimulations };
