'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const {inspect, exitCodeFor} = require('../tools/owner-windows-readiness-run687');
const root = path.resolve(__dirname,'..');
const request = 'Review exact-OS VATS, fan output and temperature thresholds, LSX Stage 2 cam card and knock sensors';
for (const project of [null, {}, {id:'x',controller:'E38',os:'unknown'}, {id:'x',controller:'P01',os:'unknown'}]) {
  const report = inspect(root, project, request);
  assert.equal(report.fixtureController === null, project?.controller !== 'P01');
  assert.equal(report.owner.ready,false);
  assert.equal(report.ecmWriteAuthorized,false);
  assert.equal(report.readyForUserTesting,false);
  assert.equal(exitCodeFor(report),2);
  assert.ok(Object.values(report.owner.calibrationGates).every(x=>x===false));
}
console.log('Run693: 24 controller-provenance fail-closed assertions passed');
