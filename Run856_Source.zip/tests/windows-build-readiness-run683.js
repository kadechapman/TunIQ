'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['encoded colon','../packages/foo%3Abar',true],
 ['encoded question','../packages/foo%3fbar',true],
 ['encoded hash','../packages/foo%23bar',true],
 ['encoded pipe','../packages/foo%7cbar',true],
 ['encoded angle','../packages/foo%3Cbar',true],
 ['encoded quote','../packages/foo%22bar',true],
 ['encoded star','../packages/foo%2abar',true],
 ['encoded zero','../packages/foo%00bar',true],
 ['normal percent digits','../packages/foo%20bar',false],
 ['normal workspace','../packages/foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq683-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run683: ten encoded Windows path fixtures passed');
