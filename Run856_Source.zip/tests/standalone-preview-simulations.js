'use strict';
// Offline source/payload tests; no Windows native execution or ECU access.
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createStandalone, writeStandalone } = require('../tools/build-standalone-browser-preview');
const { spawnSync } = require('node:child_process');
const { makeFiles } = require('../tools/stage-browser-preview');
const { inspect, verifyFiles } = require('../tools/verify-windows-standalone-embed');
const root = path.resolve(__dirname, '..');
let count = 0;
function check(label, test) { test(); count++; console.log('PASS ' + label); }
const bytes = createStandalone();
const html = bytes.toString('utf8');
const assets = new Map(makeFiles());
const scriptTags = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(x => x[1]);
check('Single HTML contains exactly three inline scripts', () => assert.equal(scriptTags.length, 3));
check('Embedded scripts match the original preview bridge and renderer exactly', () => {
  ['browser-preview-bridge.js', 'engine-catalog.js', 'app.js'].forEach((name, i) => {
    const asset = name === 'browser-preview-bridge.js' ? 'src/renderer/browser-preview-bridge.js' : `src/renderer/${name}`;
    assert.equal(scriptTags[i], assets.get(asset).toString('utf8').replace(/\r\n?/g, '\n'));
  });
});
check('CSP SHA-256 hashes bind each actual embedded script', () => {
  const csp = html.match(/http-equiv="Content-Security-Policy" content="([^"]+)"/);
  assert.ok(csp);
  for (const script of scriptTags) {
    const hash = crypto.createHash('sha256').update(script).digest('base64');
    assert.ok(csp[1].includes(`'sha256-${hash}'`));
  }
  assert.match(csp[1], /connect-src 'none'/);
  assert.doesNotMatch(csp[1], /script-src[^;]*'unsafe-inline'/);
});
check('All CSS embedded and no external stylesheet or script', () => {
  assert.match(html, /<style>[\s\S]+<\/style>/);
  assert.doesNotMatch(html, /<(?:script|link)\b[^>]*(?:src|href)=/i);
});
check('Visible hardware-disabled banner retained', () => assert.match(html, /ALL ECU OPERATIONS DISABLED/));
check('No native device bridge or Electron dependency in standalone HTML', () => {
  assert.doesNotMatch(html, /require\(['"]electron['"]\)|ipcRenderer|nodeIntegration\s*:\s*true/);
  assert.match(html, /getBootstrap: async/);
});
check('Deterministic standalone output', () => assert.ok(createStandalone().equals(bytes)));
check('Writing a second time refuses overwrite', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-standalone-test-'));
  try {
    const file = path.join(dir, 'preview.html');
    const report = writeStandalone(file);
    assert.equal(report.hardwareAvailable, false);
    assert.equal(report.sha256, crypto.createHash('sha256').update(bytes).digest('hex'));
    assert.throws(() => writeStandalone(file), /Refusing to overwrite/);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
});
// The direct HTML writer is also callable without the shell cross-builder.
// Before Run359 it created output directories inside the source checkout;
// the shell-only guard did not protect this entry point.
check('direct standalone writer rejects in-source output without mkdir', () => {
  const dir = path.join(root, '.tuniq-rejected-standalone-html');
  assert.equal(fs.existsSync(dir), false);
  assert.throws(() => writeStandalone(path.join(dir, 'preview.html')), /Refusing in-source/);
  assert.equal(fs.existsSync(dir), false);
});
if (process.platform !== 'win32') {
  check('direct standalone writer rejects symlink-alias source output without mkdir', () => {
    const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-html-alias-'));
    try {
      const alias = path.join(scratch, 'source-alias');
      fs.symlinkSync(root, alias, 'dir');
      const dir = path.join(root, '.tuniq-rejected-standalone-alias');
      assert.equal(fs.existsSync(dir), false);
      assert.throws(() => writeStandalone(path.join(alias, '.tuniq-rejected-standalone-alias', 'preview.html')), /Refusing in-source/);
      assert.equal(fs.existsSync(dir), false);
    } finally { fs.rmSync(scratch, { recursive: true, force: true }); }
  });
}
check('direct standalone writer permits new external output directories', () => {
  const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-html-safe-'));
  try {
    const target = path.join(scratch, 'nested', 'preview.html');
    const report = writeStandalone(target);
    assert.equal(report.hardwareAvailable, false);
    assert.ok(fs.readFileSync(target).equals(bytes));
  } finally { fs.rmSync(scratch, { recursive: true, force: true }); }
});
check('Cross-compile source embeds HTML and launches only local temp HTML', () => {
  const code = fs.readFileSync(path.join(root, 'tools/windows-standalone-browser-preview.c'), 'utf8');
  assert.match(code, /#include "embedded_preview.h"/);
  assert.match(code, /GetTempFileNameW/);
  assert.match(code, /#include "windows-standalone-file-guard.h"/);
  assert.match(code, /GetFileInformationByHandle\(h,&info\)/);
  assert.match(code, /GetFileType\(h\)!=1/);
  assert.match(code, /tuniq_preview_fresh_regular_file\(&info\)/);
  assert.match(code, /CreateFileW\(html_file,0x40000000UL,0,0,3,0x00200080UL,0\)/);
  assert.match(code, /#include "windows-standalone-temp-path.h"/);
  assert.match(code, /!tuniq_local_temp_path\(temp_dir,n\)/);
  assert.match(code, /GetDriveTypeW\(drive_root\)!=3/);
  assert.match(code, /ShellExecuteW\(0,open_verb,html_file/);
  assert.doesNotMatch(code, /https?:|WinHttp|InternetOpen|pcmhammer|CreateProcess|WinExec/i);
});
check('Cross-compiled preview is packaged only after static verification and checked after ZIP roundtrip', () => {
  const build = fs.readFileSync(path.join(root, 'tools/build-windows-standalone-preview.sh'), 'utf8');
  assert.match(build, /python3.*package-standalone-preview\.py.*create/);
  assert.match(build, /python3.*package-standalone-preview\.py.*verify/);
  assert.ok(build.indexOf('verify-windows-standalone-embed.js') < build.indexOf('package-standalone-preview.py'));
  assert.match(build, /for tool in node clang lld-link file python3/);
  assert.match(build, /standalone-temp-path-simulations\.c/);
  assert.match(build, /standalone-file-guard-simulations\.c/);
  assert.ok(build.indexOf('standalone-temp-path-simulations.c') < build.indexOf('clang -target x86_64-pc-windows-msvc'));
});
// A rejected cross-build must not create any directory in the source checkout.
// Linux-only shell regression; it does not execute a Windows binary.
if (process.platform === 'linux') {
  check('cross-build rejects in-source output without creating it', () => {
    const target = path.join(root, '.tuniq-rejected-crossbuild-output');
    assert.equal(fs.existsSync(target), false);
    const result = spawnSync('bash', [path.join(root, 'tools/build-windows-standalone-preview.sh'), target],
      { cwd: root, encoding: 'utf8', timeout: 10000 });
    assert.equal(result.status, 2);
    assert.match(result.stderr, /Refusing in-source output/);
    assert.equal(fs.existsSync(target), false);
  });
  check('cross-build rejects symlink-alias source output without creating it', () => {
    const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-crossbuild-path-'));
    try {
      const alias = path.join(scratch, 'alias');
      fs.symlinkSync(root, alias, 'dir');
      const target = path.join(root, '.tuniq-rejected-alias-output');
      assert.equal(fs.existsSync(target), false);
      const result = spawnSync('bash', [path.join(root, 'tools/build-windows-standalone-preview.sh'),
        path.join(alias, '.tuniq-rejected-alias-output')],
        { cwd: root, encoding: 'utf8', timeout: 10000 });
      assert.equal(result.status, 2);
      assert.match(result.stderr, /Refusing in-source output/);
      assert.equal(fs.existsSync(target), false);
    } finally { fs.rmSync(scratch, { recursive: true, force: true }); }
  });
}
check('Windows cross-build remains separate from production Electron', () => {
  const build = fs.readFileSync(path.join(root, 'tools/build-windows-standalone-preview.sh'), 'utf8');
  assert.match(build, /-target x86_64-pc-windows-msvc/);
  assert.match(build, /\/subsystem:windows \/entry:mainCRTStartup \/nodefaultlib \/timestamp:0/);
  assert.match(build, /Refusing nonempty output directory/);
});
check('Win64 standalone verifier rejects arbitrary or truncated PE files', () => {
  assert.throws(() => inspect(Buffer.alloc(4096), bytes), /missing-mz/);
  assert.throws(() => inspect(Buffer.from('MZ'), bytes), /invalid-preview-input/);
});
check('cross-compile script refuses unverified Win64 imports or missing embedded payload', () => {
  const build = fs.readFileSync(path.join(root, 'tools/build-windows-standalone-preview.sh'), 'utf8');
  assert.match(build, /verify-windows-standalone-embed\.js/);
  assert.match(build, /static-verification\.json/);
  assert.ok(build.indexOf('verify-windows-standalone-embed.js') < build.indexOf('cp "$work\/TunIQ_Standalone_Offline_Preview.exe"'));
});
// Optional actual cross-compiled PE test: run with TUNIQ_STANDALONE_EXE set.
// It remains a Linux static-binary test, NOT native Windows execution.
if (process.env.TUNIQ_STANDALONE_EXE) {
  check('real cross-compiled Win64 PE contains the exact reviewed HTML and imports', () => {
    const exe = fs.readFileSync(process.env.TUNIQ_STANDALONE_EXE);
    const proof = inspect(exe, bytes);
    assert.equal(proof.embeddedHtmlBytes, bytes.length);
    assert.equal(proof.nativeWindowsRuntimeVerified, false);
    assert.deepEqual(Object.keys(proof.imports).sort(), ['KERNEL32.dll', 'SHELL32.dll', 'USER32.dll']);
    assert.deepEqual(verifyFiles(process.env.TUNIQ_STANDALONE_EXE,
      path.join(path.dirname(process.env.TUNIQ_STANDALONE_EXE), 'TunIQ_Offline_Preview.html')), proof);
    const tampered = Buffer.from(exe);
    tampered[proof.embeddedOffset + 100] ^= 1;
    assert.throws(() => inspect(tampered, bytes), /embedded-html-not-exactly-once/);
    // These both passed the old HTML/import-only verifier, despite containing
    // unreviewed PE material. Static rejection is not Windows runtime proof.
    const overlay = Buffer.concat([exe, Buffer.from('UNREVIEWED_OVERLAY')]);
    assert.throws(() => inspect(overlay, bytes), /unexpected-pe-overlay/);
    const certificate = Buffer.from(exe);
    const peOffset = certificate.readUInt32LE(0x3c);
    certificate.writeUInt32LE(4096, peOffset + 24 + 112 + 4 * 8);
    certificate.writeUInt32LE(1024, peOffset + 24 + 112 + 4 * 8 + 4);
    assert.throws(() => inspect(certificate, bytes), /unexpected-pe-security-directory/);
    const overlap = Buffer.from(exe);
    const sectionTable = peOffset + 24 + overlap.readUInt16LE(peOffset + 20);
    overlap.writeUInt32LE(0x400, sectionTable + 40 + 20); // .rdata overlaps .text
    assert.throws(() => inspect(overlap, bytes), /invalid-pe-section-overlap/);
    // All four mutations were accepted by the Run244 verifier. A Windows
    // loader can process a TLS callback or delay import independently of the
    // normal import allowlist; writable code and redirected entry points are
    // likewise outside the reviewed launcher contract.
    for (const [name, directoryIndex] of [['TLS', 9], ['delay-import', 13],
      ['CLR', 14], ['export', 0]]) {
      const extraDirectory = Buffer.from(exe);
      const offset = peOffset + 24 + 112 + directoryIndex * 8;
      extraDirectory.writeUInt32LE(0x1000, offset);
      extraDirectory.writeUInt32LE(40, offset + 4);
      assert.throws(() => inspect(extraDirectory, bytes), /unexpected-pe-data-directory/, name);
    }
    const writableCode = Buffer.from(exe);
    writableCode.writeUInt32LE((writableCode.readUInt32LE(sectionTable + 36) | 0x80000000) >>> 0,
      sectionTable + 36);
    assert.throws(() => inspect(writableCode, bytes), /writable-executable-pe-section/);
    const redirectedEntry = Buffer.from(exe);
    redirectedEntry.writeUInt32LE(0x2000, peOffset + 24 + 16); // .rdata
    assert.throws(() => inspect(redirectedEntry, bytes), /invalid-pe-entrypoint/);
    const unreviewedImport = Buffer.from(exe);
    const importAt = unreviewedImport.indexOf(Buffer.from('KERNEL32.dll'));
    assert.ok(importAt >= 0);
    unreviewedImport[importAt + 7] = '3'.charCodeAt(0);
    assert.throws(() => inspect(unreviewedImport, bytes), /unreviewed-win64-imports/);
  });
}
console.log(`STANDALONE_PREVIEW_SOURCE_FIXTURES ${count}/${count} PASS (NOT native Windows runtime)`);
