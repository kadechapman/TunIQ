'use strict';
// Real offline npm lockfile generation on disposable Git fixtures. No Electron.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { generateCandidate } = require('../tools/generate-lockfile-candidate');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-operator-test-'));
const source = path.join(root, 'source');
const out = path.join(root, 'candidate');
let passed = 0;
let skipped = 0;
const check = (name, fn) => { fn(); passed++; };
function makeLink(target, link) {
  try { fs.symlinkSync(target, link, process.platform === 'win32' ? 'junction' : 'dir'); }
  catch (error) {
    if (process.platform === 'win32' && ['EPERM', 'EACCES', 'ENOTSUP', 'ENOENT'].includes(error.code)) {
      skipped++;
      return false;
    }
    throw error;
  }
  return true;
}
function git(args) {
  const result = spawnSync('git', args, { cwd: source, encoding: 'utf8', timeout: 10000 });
  assert.equal(result.status, 0, `git ${args.join(' ')}: ${result.stderr}`);
}
try {
  fs.mkdirSync(source);
  fs.writeFileSync(path.join(source, 'package.json'), '{"name":"tuniq-operator-fixture","version":"1.0.0","private":true}\n');
  fs.writeFileSync(path.join(source, 'README.md'), 'reviewed source\n');
  git(['init', '-q']);
  git(['add', 'package.json', 'README.md']);
  git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'fixture']);
  check('reject output inside source checkout', () =>
    assert.throws(() => generateCandidate(source, path.join(source, 'candidate'), { offline: true })));
  check('reject dirty tracked source before npm', () => {
    fs.writeFileSync(path.join(source, 'README.md'), 'dirty source\n');
    assert.throws(() => generateCandidate(source, out, { offline: true }));
    fs.writeFileSync(path.join(source, 'README.md'), 'reviewed source\n');
  });
  check('reject output redirected into source through a symlinked parent', () => {
    const alias = path.join(root, 'source-alias');
    if (!makeLink(source, alias)) return;
    const redirected = path.join(alias, 'candidate-via-alias');
    assert.throws(() => generateCandidate(source, redirected, { offline: true }),
      /outside|source|redirect|symlink/i);
    assert.equal(fs.existsSync(path.join(source, 'candidate-via-alias')), false);
  });
  check('reject a dangling symlink as an existing output destination', () => {
    const dangling = path.join(root, 'dangling-candidate');
    if (!makeLink(path.join(root, 'missing-target'), dangling)) return;
    assert.throws(() => generateCandidate(source, dangling, { offline: true }),
      /exists|symlink|output/i);
    assert.equal(fs.lstatSync(dangling).isSymbolicLink(), true);
  });
  check('generate real npm lockfile candidate offline and review against Git commit', () => {
    const result = generateCandidate(source, out, { offline: true });
    assert.equal(result.passed, true);
    assert.equal(result.nativeInstallVerified, false);
    assert.equal(result.electronRuntimeVerified, false);
    assert.equal(result.fullTunIQVerified, false);
    assert.equal(result.physicalHardwareVerified, false);
  });
  check('source checkout never receives a lockfile', () =>
    assert.equal(fs.existsSync(path.join(source, 'package-lock.json')), false));
  check('review artifact contains genuine npm lockfile and source-bound provenance', () => {
    const lock = JSON.parse(fs.readFileSync(path.join(out, 'package-lock.candidate.json')));
    const proof = JSON.parse(fs.readFileSync(path.join(out, 'candidate-provenance.json')));
    assert.equal(lock.packages[''].name, 'tuniq-operator-fixture');
    assert.equal(proof.nativeInstallVerified, false);
    assert.match(proof.sourceCommit, /^[a-f0-9]{40}$/);
  });
  check('refuse to overwrite an existing reviewed candidate', () =>
    assert.throws(() => generateCandidate(source, out, { offline: true })));
  check('refuse to generate when source already contains a lockfile', () => {
    fs.writeFileSync(path.join(source, 'package-lock.json'), '{}\n');
    assert.throws(() => generateCandidate(source, path.join(root, 'new'), { offline: true }));
    fs.unlinkSync(path.join(source, 'package-lock.json'));
  });
  check('reject dangling package-lock symlink before npm resolution', () => {
    const lock = path.join(source, 'package-lock.json');
    try {
      fs.symlinkSync(path.join(root, 'nonexistent-lock.json'), lock, 'file');
    } catch (error) {
      if (process.platform === 'win32' && ['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) {
        skipped++;
        return;
      }
      throw error;
    }
    try {
      assert.throws(() => generateCandidate(source, path.join(root, 'dangling-lock-output'), { offline: true }),
        /lockfile|shrinkwrap/i);
      assert.equal(fs.existsSync(path.join(root, 'dangling-lock-output')), false);
    } finally { fs.unlinkSync(lock); }
  });
  check('reject dangling npm-shrinkwrap symlink before npm resolution', () => {
    const shrinkwrap = path.join(source, 'npm-shrinkwrap.json');
    try {
      fs.symlinkSync(path.join(root, 'nonexistent-shrinkwrap.json'), shrinkwrap, 'file');
    } catch (error) {
      if (process.platform === 'win32' && ['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) {
        skipped++;
        return;
      }
      throw error;
    }
    try {
      assert.throws(() => generateCandidate(source, path.join(root, 'dangling-shrinkwrap-output'), { offline: true }),
        /lockfile|shrinkwrap/i);
      assert.equal(fs.existsSync(path.join(root, 'dangling-shrinkwrap-output')), false);
    } finally { fs.unlinkSync(shrinkwrap); }
  });
  // A concurrent process can create an untracked lockfile *after* the first
  // source check. git diff HEAD will not see that file. Use a disposable npm
  // shim that runs real offline npm, then introduces the conflicting entry.
  // This is a source/fixture race test, not a native Windows runtime test.
  if (process.platform !== 'win32') {
    const shimDir = path.join(root, 'npm-race-shim');
    fs.mkdirSync(shimDir);
    const realNpm = spawnSync('which', ['npm'], { encoding: 'utf8' }).stdout.trim();
    assert.ok(realNpm, 'real npm must be available for offline race fixture');
    const shim = path.join(shimDir, 'npm');
    const cleanPath = process.env.PATH;
    fs.writeFileSync(shim, `#!${process.execPath}\n` +
      `const cp=require('node:child_process'),fs=require('node:fs'),path=require('node:path');\n` +
      `const r=cp.spawnSync(${JSON.stringify(realNpm)},process.argv.slice(2),` +
      `{stdio:'inherit',env:{...process.env,PATH:${JSON.stringify(cleanPath)}}});\n` +
      `if(process.argv.includes('install')&&r.status===0){` +
      `fs.writeFileSync(path.join(process.env.TUNIQ_TEST_SOURCE,` +
      `process.env.TUNIQ_TEST_LOCK_ENTRY),'{}\\n');}\n` +
      `process.exit(r.status??1);\n`);
    fs.chmodSync(shim, 0o755);
    for (const entry of ['package-lock.json', 'npm-shrinkwrap.json']) {
      check(`reject ${entry} introduced during npm resolution`, () => {
        const previousPath = process.env.PATH;
        const previousSource = process.env.TUNIQ_TEST_SOURCE;
        const previousEntry = process.env.TUNIQ_TEST_LOCK_ENTRY;
        const candidateDir = path.join(root, `race-${entry}`);
        try {
          process.env.PATH = shimDir + path.delimiter + cleanPath;
          process.env.TUNIQ_TEST_SOURCE = source;
          process.env.TUNIQ_TEST_LOCK_ENTRY = entry;
          assert.throws(() => generateCandidate(source, candidateDir, { offline: true }),
            /lockfile|shrinkwrap/i);
          assert.equal(fs.existsSync(candidateDir), false);
          assert.equal(fs.existsSync(path.join(source, entry)), true);
        } finally {
          process.env.PATH = previousPath;
          if (previousSource === undefined) delete process.env.TUNIQ_TEST_SOURCE;
          else process.env.TUNIQ_TEST_SOURCE = previousSource;
          if (previousEntry === undefined) delete process.env.TUNIQ_TEST_LOCK_ENTRY;
          else process.env.TUNIQ_TEST_LOCK_ENTRY = previousEntry;
          fs.rmSync(path.join(source, entry), { force: true });
        }
      });
    }
  }
  check('failed npm dependency resolution leaves no candidate artifact', () => {
    const p = path.join(source, 'package.json');
    fs.writeFileSync(p, '{"name":"tuniq-operator-fixture","version":"1.0.0","private":true,"dependencies":{"never-installed-xyz":"1.0.0"}}\n');
    git(['add', 'package.json']);
    git(['-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid', 'commit', '-qm', 'offline-miss']);
    assert.throws(() => generateCandidate(source, path.join(root, 'failed'), { offline: true }));
    assert.equal(fs.existsSync(path.join(root, 'failed')), false);
  });
  console.log(`Windows lockfile operator: ${passed - skipped}/${passed - skipped} passed, ${skipped} Windows symlink-privilege skips (real offline npm; no Windows Electron).`);
} finally { fs.rmSync(root, { recursive: true, force: true }); }
