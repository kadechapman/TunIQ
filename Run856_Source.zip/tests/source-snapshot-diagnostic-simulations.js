'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '../tools/diagnose-source-snapshot.js'), 'utf8');
function check(recorded, verifierValid = false, verifierThrows = false, rawVerifierResult = undefined, noLockfiles = false) {
  const context = {
    require(name) {
      if (name === 'node:fs') return { readFileSync: () => JSON.stringify({ criticalSource: recorded }), lstatSync: p => { if (!noLockfiles && p.endsWith('npm-shrinkwrap.json')) return { isFile: () => true, size: 120 }; throw Object.assign(Error('missing'), { code: 'ENOENT' }); } }; 
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { if (verifierThrows) throw new Error('fixture verifier failure'); return rawVerifierResult !== undefined ? rawVerifierResult : { valid: verifierValid, reason: verifierValid ? null : 'criticalSource mismatch' }; }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  return context.module.exports.diagnose(os.tmpdir());
}
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }).sourceDigestStatus, 'matches');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'b'.repeat(64), fileCount: 3 }).sourceDigestStatus, 'mismatch');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'abc', fileCount: 3 }).sourceDigestStatus, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: -1 }).sourceDigestStatus, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 1.5 }).sourceDigestStatus, 'unverifiable');
assert.equal(check({ schemaVersion: 2, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }).sourceDigestStatus, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'md5', sha256: 'a'.repeat(64), fileCount: 3 }).digestMatches, null);
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'A'.repeat(64), fileCount: 3 }).sourceDigestStatus, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true).status, 'matches');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'b'.repeat(64), fileCount: 3 }, true).status, 'mismatch');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'invalid', fileCount: 3 }, true).status, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, true).status, 'unverifiable');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, true).reason, 'snapshot-verifier-error');
const dependencyResult = check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'b'.repeat(64), fileCount: 3 });
assert.equal(dependencyResult.dependencyInputs[0].present, false);
assert.equal(dependencyResult.dependencyInputs[1].present, true);
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, true).dependencyInputs[0].present, false);
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 4 }).fileCountDelta, -1);
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 4 }).missingFileAttribution, 'unknown-without-recorded-path-inventory');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }).missingFileAttribution, null);
// Missing/corrupt snapshot must retain lockfile evidence and never imply a verified baseline.
{
  const missingContext = {
    require(name) {
      if (name === 'node:fs') return { readFileSync: () => { throw new Error('fixture missing snapshot'); }, lstatSync: p => { if (p.endsWith('npm-shrinkwrap.json')) return { isFile: () => true, size: 120 }; throw Object.assign(Error('missing'), { code: 'ENOENT' }); } };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return { criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }), verifySnapshot: () => { throw Error('must not verify absent snapshot'); } };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, missingContext, { filename: 'diagnose-source-snapshot.js' });
  const missing = missingContext.module.exports.diagnose(os.tmpdir());
  assert.equal(missing.status, 'missing-or-invalid-snapshot');
  assert.equal(missing.dependencyInputs[0].present, false);
  assert.equal(missing.dependencyInputs[1].present, true);
  assert.match(missing.warning, /not source authentication/);
}
// Only an explicit boolean true may admit a matching snapshot.
for (const nonBoolean of ['true', 1, {}, []]) {
  assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, nonBoolean).status, 'unverifiable');
}
console.log('Source snapshot diagnostic metadata fixtures: 27/27 passed (mocked, offline).');

// Malformed verifier returns fail closed without throwing or claiming authentication.
for (const malformed of [null, false, 'true', 1, []]) {
  const result = check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, false, malformed);
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'invalid-snapshot-verifier-result');
  assert.equal(result.dependencyInputs[1].present, true);
}
console.log('Malformed verifier response cases: 15/15 assertions passed (mocked, offline).');

// Structurally valid objects with absent/non-boolean verdicts must not be called mismatches.
for (const malformed of [{}, {valid: null}, {valid: 'false'}, {valid: 0}, {valid: 1}]) {
  const result = check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, false, malformed);
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'invalid-snapshot-verifier-verdict');
  assert.equal(result.dependencyInputs[1].present, true);
}
console.log('Malformed verifier verdict cases: 15/15 assertions passed (mocked, offline).');

// Missing lockfiles are candidates only; a count delta cannot identify a path.
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 4 }).lockfileCountMismatchCandidate, 'npm-lockfile-absent-candidate-not-attribution'); // fixture has shrinkwrap, but package-lock is absent
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }).lockfileCountMismatchCandidate, null);
console.log('Lockfile attribution caution fixtures: 2/2 passed.');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 4 }, false, false, undefined, true).lockfileCountMismatchCandidate, 'npm-lockfile-absent-candidate-not-attribution');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 2 }, false, false, undefined, true).lockfileCountMismatchCandidate, null);
console.log('Missing lockfile candidate fixtures: 2/2 passed.');
// At most two optional npm lockfiles can explain a count deficit; larger deficits require other causes.
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 5 }, false, false, undefined, true).lockfileCountMismatchCandidate, 'npm-lockfile-absent-candidate-not-attribution');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 6 }, false, false, undefined, true).lockfileCountMismatchCandidate, null);
console.log('Bounded lockfile-count attribution fixtures: 2/2 passed.');

// A filesystem/source traversal error must fail closed instead of crashing diagnostics.
{
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => { throw Object.assign(Error('missing'), { code: 'ENOENT' }); } };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => { throw new Error('fixture unreadable source'); },
        verifySnapshot: () => { throw new Error('must not verify after fingerprint failure'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'source-fingerprint-error');
  assert.match(result.error, /unreadable source/);
  assert.match(result.warning, /not evidence of source integrity/);
}
console.log('Fingerprint traversal failure: 4/4 assertions passed (mocked, offline).');

// A failed filesystem lockfile probe must not be interpreted as a missing lockfile.
{
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => { throw Object.assign(new Error('fixture permission denied'), { code: 'EACCES' }); } };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { throw Error('must not verify after dependency probe failure'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'dependency-input-probe-error');
  assert.match(result.error, /permission denied/);
  assert.equal(result.dependencyInputs, undefined);
}
console.log('Dependency input probe failure: 4/4 assertions passed (mocked, offline).');

// Parseable JSON with an invalid document shape must fail closed rather than crash.
for (const invalidDocument of [null, false, 42, 'string', []]) {
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => { throw Object.assign(Error('missing'), { code: 'ENOENT' }); }, readFileSync: () => JSON.stringify(invalidDocument) };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { throw Error('must not verify malformed document'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'invalid-snapshot-document-shape');
  assert.match(result.warning, /cannot authenticate source/);
}
console.log('Invalid readiness document shape: 15/15 assertions passed (mocked, offline).');

// Current source fingerprint must be a well-formed SHA-256 record before verification.
for (const malformed of [null, [], {}, {sha256: 'a'.repeat(64), fileCount: -1}, {sha256: 'invalid', fileCount: 3}]) {
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => ({}), readFileSync: () => { throw Error('should not read snapshot'); } };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return { criticalSourceFingerprint: () => malformed, verifySnapshot: () => { throw Error('must not verify malformed fingerprint'); } };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'invalid-current-source-fingerprint');
}
console.log('Malformed current fingerprint: 10/10 assertions passed (mocked, offline).');

// A success verdict accompanied by mismatch evidence must never authenticate source.
for (const verifier of [
  { valid: true, reason: 'criticalSource mismatch' },
  { valid: true, changedFields: ['criticalSource'] },
  { valid: true, reason: null, changedFields: [] }
]) {
  const result = check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3 }, true, false, verifier);
  assert.equal(result.status, verifier.changedFields?.length === 0 ? 'matches' : 'unverifiable');
}
console.log('Contradictory verifier evidence fixtures: 3/3 passed.');

// Verifier metadata with unexpected types must never authorize a matching snapshot.
for (const evidence of [
  {valid: true, reason: {message: 'ok'}},
  {valid: true, changedFields: 'none'},
  {valid: true, changedFields: [null]},
  {valid: true, changedFields: [7]},
  {valid: false, changedFields: {field: 'digest'}}
]) {
  const result = check({schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 3}, true, false, evidence);
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'invalid-snapshot-verifier-evidence');
  assert.match(result.warning, /cannot authenticate/);
}
console.log('Malformed verifier evidence: 15/15 assertions passed (mocked, offline).');

// A single absent lockfile is a candidate for one missing file, never two.
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 4 }).lockfileCountMismatchCandidate, 'npm-lockfile-absent-candidate-not-attribution');
assert.equal(check({ schemaVersion: 1, algorithm: 'sha256', sha256: 'a'.repeat(64), fileCount: 5 }).lockfileCountMismatchCandidate, null);
console.log('Partial lockfile absence: 2/2 assertions passed (mocked, offline).');

// Permission errors must not masquerade as missing lockfiles.
{
 const context = { require(name) {
  if (name === 'node:fs') return { lstatSync: () => { throw Object.assign(Error('denied'), {code:'EACCES'}); } };
  if (name === 'node:path') return path;
  if (name === './launch-snapshot') return { criticalSourceFingerprint: () => ({sha256:'a'.repeat(64),fileCount:3}), verifySnapshot: () => { throw Error('should not verify'); } };
  throw Error(name);
 }, module:{exports:{}},process:{argv:[]},__dirname:os.tmpdir() };
 vm.runInNewContext(source,context,{filename:'diagnose-source-snapshot.js'});
 const result=context.module.exports.diagnose(os.tmpdir());
 assert.equal(result.status,'unverifiable');
 assert.equal(result.reason,'dependency-input-probe-error');
 assert.match(result.error,/denied/);
}
console.log('Permission-denied lockfile probe: 3/3 assertions passed.');

// A directory masquerading as a lockfile must fail closed, not count as present.
{
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => ({ isFile: () => false }) };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { throw Error('must not verify directory lockfile'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'dependency-input-probe-error');
  assert.match(result.error, /not a regular non-symlink file/);
}
console.log('Non-file dependency input: 3/3 assertions passed (mocked, offline).');

// A symlink to a regular lockfile is not independently authenticated input.
{
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => ({ isFile: () => false, isSymbolicLink: () => true }) };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return { criticalSourceFingerprint: () => ({sha256: 'a'.repeat(64), fileCount: 3}), verifySnapshot: () => { throw Error('should not verify'); } };
      throw Error(`Unexpected dependency ${name}`);
    }, module: {exports:{}}, process:{argv:[]}, __dirname:os.tmpdir()
  };
  vm.runInNewContext(source, context, {filename:'diagnose-source-snapshot.js'});
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'dependency-input-probe-error');
  assert.match(result.error, /non-symlink/);
}
console.log('Symlink lockfile rejection: 3/3 assertions passed.');

// An empty regular lockfile is not usable dependency evidence, and must fail closed.
{
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => ({ isFile: () => true, size: 0 }) };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { throw Error('must not verify after empty dependency input'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'dependency-input-probe-error');
  assert.match(result.error, /empty/);
}
console.log('Empty lockfile guard: 3/3 assertions passed (mocked, offline).');

// Invalid filesystem size metadata must fail closed, not imply a usable dependency lock.
for (const invalidSize of [undefined, null, -1, 1.5, Number.NaN, Number.POSITIVE_INFINITY]) {
  const context = {
    require(name) {
      if (name === 'node:fs') return { lstatSync: () => ({ isFile: () => true, size: invalidSize }) };
      if (name === 'node:path') return path;
      if (name === './launch-snapshot') return {
        criticalSourceFingerprint: () => ({ sha256: 'a'.repeat(64), fileCount: 3 }),
        verifySnapshot: () => { throw Error('must not verify after invalid file metadata'); }
      };
      throw Error(`Unexpected dependency ${name}`);
    }, module: { exports: {} }, process: { argv: [] }, __dirname: os.tmpdir()
  };
  vm.runInNewContext(source, context, { filename: 'diagnose-source-snapshot.js' });
  const result = context.module.exports.diagnose(os.tmpdir());
  assert.equal(result.status, 'unverifiable');
  assert.equal(result.reason, 'dependency-input-probe-error');
  assert.match(result.error, /invalid or empty file size/);
}
console.log('Invalid lockfile stat size metadata: 18/18 assertions passed (mocked, offline).');
