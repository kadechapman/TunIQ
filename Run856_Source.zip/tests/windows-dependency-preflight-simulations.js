'use strict';
// Synthetic local JSON only; never installs dependencies or packages TunIQ.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { inspectWindowsDependencyLock, MAX_LOCK_BYTES } = require('../tools/windows-dependency-preflight');

function runWindowsDependencyPreflightSimulations({ quiet = false } = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-lock-audit-'));
  const packageFile = path.join(dir, 'package.json');
  const lockFile = path.join(dir, 'package-lock.json');
  const pkg = { name: 'offline-fixture', version: '1.0.0', dependencies: { 'a-package': '2.3.4' },
    devDependencies: { 'b-package': '5.6.7' } };
  const integrity = `sha512-${Buffer.alloc(64, 1).toString('base64')}`;
  const lock = () => ({ name: pkg.name, version: pkg.version, lockfileVersion: 3, packages: {
    '': { name: pkg.name, version: pkg.version, dependencies: { ...pkg.dependencies }, devDependencies: { ...pkg.devDependencies } },
    'node_modules/a-package': { version: '2.3.4', integrity },
    'node_modules/b-package': { version: '5.6.7', integrity }
  } });
  let passed = 0;
  const check = (condition, label) => { assert.ok(condition, label); passed++; };
  const write = (packageJson = pkg, lockJson = lock()) => {
    fs.writeFileSync(packageFile, JSON.stringify(packageJson));
    fs.writeFileSync(lockFile, JSON.stringify(lockJson));
  };
  try {
    write();
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'valid exact direct dependency metadata accepted');
    check(inspectWindowsDependencyLock(dir).windowsBuildVerified === false, 'metadata never claims Windows build');
    fs.unlinkSync(lockFile);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-missing'), 'missing lockfile rejected');
    write(); fs.writeFileSync(lockFile, 'null');
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-structure'), 'JSON null lockfile rejected');
    write(); fs.writeFileSync(packageFile, 'false');
    check(inspectWindowsDependencyLock(dir).blockers.includes('package-json-invalid-shape'), 'JSON false package rejected');
    write(); fs.writeFileSync(lockFile, '{oops');
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-json'), 'malformed lockfile rejected');
    write(); const rootMismatch = lock(); rootMismatch.packages[''].version = '2.0.0'; write(pkg, rootMismatch);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-root-mismatch'), 'wrong root version rejected');
    write(); const old = lock(); old.lockfileVersion = 1; write(pkg, old);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-structure'), 'old lock format rejected');
    write(); const wrong = lock(); wrong.packages['node_modules/a-package'].version = '9.9.9'; write(pkg, wrong);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-a-package-resolution-invalid'), 'wrong resolved version rejected');
    write(); const missing = lock(); delete missing.packages['node_modules/a-package'].integrity; write(pkg, missing);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-a-package-resolution-invalid'), 'missing integrity rejected');
    write(); const noDirect = lock(); delete noDirect.packages[''].dependencies['a-package']; write(pkg, noDirect);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependencies-set-mismatch'), 'missing root dependency rejected');
    write({ ...pkg, dependencies: { 'a-package': '^2.3.4' } });
    check(inspectWindowsDependencyLock(dir).blockers.includes('unpinned-a-package'), 'unpinned direct dependency rejected');
    // Root optional dependencies must be pinned, present, and identical in
    // package.json and the lockfile. Otherwise a missing optional dependency
    // can silently pass an offline Windows readiness check.
    write({ ...pkg, optionalDependencies: { 'optional-lib': '1.2.3' } });
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-optionalDependencies-set-mismatch'), 'missing root optional dependency rejected');
    write(); const extraOptional = lock(); extraOptional.packages[''].optionalDependencies = { 'optional-lib': '1.2.3' }; write(pkg, extraOptional);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-optionalDependencies-set-mismatch'), 'unexpected locked root optional dependency rejected');
    write(); const optionalPkg = { ...pkg, optionalDependencies: { 'optional-lib': '1.2.3' } };
    const validOptional = lock(); validOptional.packages[''].optionalDependencies = { 'optional-lib': '1.2.3' };
    validOptional.packages['node_modules/optional-lib'] = { version: '1.2.3', integrity }; write(optionalPkg, validOptional);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'valid pinned root optional dependency accepted');
    const optionalWrongVersion = structuredClone(validOptional); optionalWrongVersion.packages['node_modules/optional-lib'].version = '9.9.9'; write(optionalPkg, optionalWrongVersion);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-optional-lib-resolution-invalid'), 'wrong optional dependency version rejected');
    const optionalWrongRange = structuredClone(validOptional); optionalWrongRange.packages[''].optionalDependencies['optional-lib'] = '1.2.4'; write(optionalPkg, optionalWrongRange);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-optional-lib-range-mismatch'), 'optional dependency range mismatch rejected');
    write({ ...optionalPkg, optionalDependencies: { 'optional-lib': '^1.2.3' } }, validOptional);
    check(inspectWindowsDependencyLock(dir).blockers.includes('unpinned-optional-lib'), 'unpinned root optional dependency rejected');
    write({ ...pkg, optionalDependencies: null });
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-optionalDependencies-invalid'), 'null root optional dependency map rejected');
    const invalidOptionalLock = lock(); invalidOptionalLock.packages[''].optionalDependencies = null; write(pkg, invalidOptionalLock);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-map-invalid'), 'null locked optional dependency map rejected');
    // Transitive lock entries must not bypass metadata-only safety checks.
    write(); const noIntegrity = lock(); noIntegrity.packages['node_modules/indirect'] = { version: '1.2.3' }; write(pkg, noIntegrity);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-transitive-integrity-invalid'), 'transitive dependency missing integrity rejected');
    write(); const local = lock(); local.packages['node_modules/indirect'] = { version: '1.2.3', integrity, resolved: 'file:../local-package' }; write(pkg, local);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'local file resolution rejected');
    write(); const insecure = lock(); insecure.packages['node_modules/indirect'] = { version: '1.2.3', integrity, resolved: 'http://registry.npmjs.org/indirect/-/indirect-1.2.3.tgz' }; write(pkg, insecure);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'plain HTTP resolution rejected');
    write(); const remote = lock(); remote.packages['node_modules/indirect'] = { version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/indirect/-/indirect-1.2.3.tgz' }; write(pkg, remote);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'integrity-pinned transitive registry package accepted');
    // Run176: the same trusted registry host must not let a lock entry
    // silently resolve a different package or version (or a metadata URL).
    write(); const wrongTarballName = lock(); wrongTarballName.packages['node_modules/indirect'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/other/-/other-1.2.3.tgz'
    }; write(pkg, wrongTarballName);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'wrong package tarball rejected');
    write(); const wrongTarballVersion = lock(); wrongTarballVersion.packages['node_modules/indirect'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/indirect/-/indirect-9.9.9.tgz'
    }; write(pkg, wrongTarballVersion);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'wrong version tarball rejected');
    write(); const registryMetadata = lock(); registryMetadata.packages['node_modules/indirect'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/indirect'
    }; write(pkg, registryMetadata);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'non-tarball registry metadata rejected');
    write(); const queryTarball = lock(); queryTarball.packages['node_modules/indirect'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/indirect/-/indirect-1.2.3.tgz?redirect=1'
    }; write(pkg, queryTarball);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'tarball with unreviewed query rejected');
    write(); const scopedTarball = lock(); scopedTarball.packages['node_modules/@scope/normal'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/@scope/normal/-/normal-1.2.3.tgz'
    }; write(pkg, scopedTarball);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'canonical scoped tarball accepted');
    write(); const encodedScopedTarball = lock(); encodedScopedTarball.packages['node_modules/@scope/normal'] = {
      version: '1.2.3', integrity, resolved: 'https://registry.npmjs.org/@scope%2Fnormal/-/normal-1.2.3.tgz'
    }; write(pkg, encodedScopedTarball);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'encoded scoped tarball accepted');
    write(); const scoped = lock(); scoped.packages['node_modules/@scope/nested/node_modules/indirect'] = { version: '1.2.3', integrity }; write(pkg, scoped);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'nested scoped registry package accepted');
    write(); const customRegistry = lock(); customRegistry.packages['node_modules/indirect'] = { version: '1.2.3', integrity, resolved: 'https://untrusted.example/indirect.tgz' }; write(pkg, customRegistry);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-resolution'), 'nonapproved registry host rejected');
    write(); const linked = lock(); linked.packages['node_modules/indirect'] = { version: '1.2.3', integrity, link: true }; write(pkg, linked);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-linked-package'), 'symlinked lockfile package rejected');
    write(); const traversal = lock(); traversal.packages['node_modules/../outside'] = { version: '1.2.3', integrity }; write(pkg, traversal);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-package-path'), 'path traversal package entry rejected');
    // Run334: unreferenced transitive entries were previously admitted with
    // Windows-legal but npm-invalid names. A lock graph containing them is
    // not safe to call metadata-ready, even if no edge points to the entry.
    for (const badPath of [
      'node_modules/bad package',
      'node_modules/@scope/bad name',
      'node_modules/%2e%2e',
      'node_modules/a-package/node_modules/@scope/bad%20name'
    ]) {
      write(); const invalidName = lock();
      invalidName.packages[badPath] = { version: '1.2.3', integrity };
      write(pkg, invalidName);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-package-path'),
        `unreferenced npm-invalid package path rejected: ${badPath}`);
    }
    write(); const validScopedName = lock();
    validScopedName.packages['node_modules/@scope/valid_name'] = { version: '1.2.3', integrity };
    write(pkg, validScopedName);
    check(inspectWindowsDependencyLock(dir).lockfileReady,
      'ordinary scoped registry package path remains accepted');
    // Run175: a Linux-valid lockfile can be impossible or ambiguous on a
    // case-insensitive Windows node_modules filesystem. Refuse it before npm ci.
    write(); const reserved = lock(); reserved.packages['node_modules/CON'] = { version: '1.2.3', integrity }; write(pkg, reserved);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'), 'Windows reserved device package rejected');
    // Run304: device names and DEL were accepted by dependency metadata
    // even though the delivered-tree Windows validator rejects them.
    for (const unsafeName of ['CONIN$', 'conout$', 'CONIN$.txt', 'ConOut$.json', 'bad\x7fchild']) {
      write(); const device = lock();
      device.packages[`node_modules/${unsafeName}`] = { version: '1.2.3', integrity };
      write(pkg, device);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'),
        `Windows reserved/DEL package component rejected: ${JSON.stringify(unsafeName)}`);
    }
    write(); const forbidden = lock(); forbidden.packages['node_modules/bad:name'] = { version: '1.2.3', integrity }; write(pkg, forbidden);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'), 'Windows forbidden punctuation rejected');
    write(); const trailing = lock(); trailing.packages['node_modules/indirect.'] = { version: '1.2.3', integrity }; write(pkg, trailing);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'), 'Windows trailing period package rejected');
    write(); const scopedReserved = lock(); scopedReserved.packages['node_modules/@team/AUX.txt'] = { version: '1.2.3', integrity }; write(pkg, scopedReserved);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'), 'Windows reserved scoped package rejected');
    write(); const caseCollision = lock(); caseCollision.packages['node_modules/A-Package'] = { version: '2.3.4', integrity }; write(pkg, caseCollision);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-windows-case-collision'), 'Windows case-colliding package paths rejected');
    write(); const nestedCollision = lock(); nestedCollision.packages['node_modules/a-package/node_modules/CHILD'] = { version: '1.2.3', integrity };
    nestedCollision.packages['node_modules/a-package/node_modules/child'] = { version: '1.2.3', integrity }; write(pkg, nestedCollision);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-windows-case-collision'), 'nested case-colliding package paths rejected');
    write(); const ancestorCollision = lock(); ancestorCollision.packages['node_modules/Parent/node_modules/first'] = { version: '1.2.3', integrity };
    ancestorCollision.packages['node_modules/parent/node_modules/second'] = { version: '1.2.3', integrity }; write(pkg, ancestorCollision);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-windows-case-collision'), 'case-colliding parent directory prefixes rejected');
    write(); const safeScoped = lock(); safeScoped.packages['node_modules/@team/normal-child'] = { version: '1.2.3', integrity }; write(pkg, safeScoped);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'ordinary scoped package path remains accepted');
    // Run333: a long nested node_modules path was previously accepted as
    // Windows-layout safe even though it exceeds the conservative relative
    // path budget before the checkout root is added. This is not a native
    // Windows install test or a guarantee for shorter paths.
    write(); const nestedPath = count => Array.from({ length: count }, (_, i) =>
      `node_modules/segment${String(i).padStart(2, '0')}`).join('/');
    const normalNested = lock(); normalNested.packages[nestedPath(10)] = { version: '1.0.0', integrity };
    write(pkg, normalNested);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'bounded nested package path accepted');
    write(); const overlongNested = lock(); overlongNested.packages[nestedPath(11)] = { version: '1.0.0', integrity };
    write(pkg, overlongNested);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'),
      'nested package path exceeding Windows relative-path budget rejected');
    write(); const extremeNested = lock(); extremeNested.packages[nestedPath(22)] = { version: '1.0.0', integrity };
    write(pkg, extremeNested);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-invalid-windows-package-path'),
      'very long nested package path rejected before native install');
    write(); const wrongVersion = lock(); wrongVersion.packages['node_modules/indirect'] = { version: 'git+ssh://example.invalid/indirect', integrity }; write(pkg, wrongVersion);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-transitive-version-invalid'), 'non-semver transitive version rejected');
    write(); const shortIntegrity = lock(); shortIntegrity.packages['node_modules/indirect'] = { version: '1.2.3', integrity: 'sha512-YWJj' }; write(pkg, shortIntegrity);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-transitive-integrity-invalid'), 'truncated transitive digest rejected');
    write(); const malformed = lock(); malformed.packages['node_modules/indirect'] = null; write(pkg, malformed);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-transitive-entry-invalid'), 'null transitive package entry rejected');
    // A pinned tarball is not sufficient if its declared dependency is absent
    // from the lock graph. These checks are offline; no npm registry is used.
    write(); const missingEdge = lock(); missingEdge.packages['node_modules/a-package'].dependencies = { 'nested-required': '^1.0.0' }; write(pkg, missingEdge);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-target-missing'), 'missing transitive required dependency rejected');
    write(); const missingOptional = lock(); missingOptional.packages['node_modules/a-package'].optionalDependencies = { 'optional-child': '1.0.0' }; write(pkg, missingOptional);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-target-missing'), 'missing optional lockfile dependency rejected');
    write(); const nestedChild = lock(); nestedChild.packages['node_modules/a-package'].dependencies = { 'nested-required': '^1.0.0' };
    nestedChild.packages['node_modules/a-package/node_modules/nested-required'] = { version: '1.2.0', integrity }; write(pkg, nestedChild);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'nested dependency target accepted');
    write(); const hoistedChild = lock(); hoistedChild.packages['node_modules/a-package'].dependencies = { 'hoisted-required': '^1.0.0' };
    hoistedChild.packages['node_modules/hoisted-required'] = { version: '1.2.0', integrity }; write(pkg, hoistedChild);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'hoisted dependency target accepted');
    // Run177: the nearest locked target must satisfy exact transitive pins.
    // Presence alone is not enough; npm ci must not be misrepresented as ready.
    write(); const exactMismatch = lock(); exactMismatch.packages['node_modules/a-package'].dependencies = { child: '2.0.0' };
    exactMismatch.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, exactMismatch);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-dependency-version-mismatch'), 'wrong exact hoisted version rejected');
    write(); const exactNestedMismatch = lock(); exactNestedMismatch.packages['node_modules/a-package'].dependencies = { child: '2.0.0' };
    exactNestedMismatch.packages['node_modules/a-package/node_modules/child'] = { version: '1.0.0', integrity };
    exactNestedMismatch.packages['node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, exactNestedMismatch);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-dependency-version-mismatch'), 'wrong nearest nested version rejected despite correct hoisted version');
    write(); const exactOptionalMismatch = lock(); exactOptionalMismatch.packages['node_modules/a-package'].optionalDependencies = { child: '2.0.0' };
    exactOptionalMismatch.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, exactOptionalMismatch);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-dependency-version-mismatch'), 'wrong exact optional dependency rejected');
    write(); const exactMatch = lock(); exactMatch.packages['node_modules/a-package'].dependencies = { child: '2.0.0' };
    exactMatch.packages['node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, exactMatch);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'correct exact hoisted version accepted');
    write(); const exactNestedMatch = lock(); exactNestedMatch.packages['node_modules/a-package'].dependencies = { child: '2.0.0' };
    exactNestedMatch.packages['node_modules/a-package/node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, exactNestedMatch);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'correct exact nearest nested version accepted');
    write(); const rangeNotProven = lock(); rangeNotProven.packages['node_modules/a-package'].dependencies = { child: '^2.0.0' };
    rangeNotProven.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, rangeNotProven);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'semver range satisfaction remains unverified by metadata preflight');
    // Run181: exact peer requirements must not be silently accepted when the
    // installed peer is absent or the wrong version. No npm or Windows runtime.
    write(); const peerMismatch = lock(); peerMismatch.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' };
    peerMismatch.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, peerMismatch);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-peer-version-mismatch'), 'wrong exact peer version rejected');
    write(); const peerMissing = lock(); peerMissing.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' }; write(pkg, peerMissing);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-dependency-target-missing'), 'missing required peer rejected');
    write(); const peerValid = lock(); peerValid.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' };
    peerValid.packages['node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, peerValid);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'correct exact peer accepted');
    write(); const peerOptional = lock(); peerOptional.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' };
    peerOptional.packages['node_modules/a-package'].peerDependenciesMeta = { child: { optional: true } }; write(pkg, peerOptional);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'declared optional absent peer accepted');
    peerOptional.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, peerOptional);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-peer-version-mismatch'), 'present but wrong optional peer rejected');
    // Run182: a package's own node_modules is NOT a valid peer location.
    // A normal dependency can resolve there; a peer must be beside/above
    // the declaring package. A nested fake peer previously passed Run181.
    write(); const peerBelowParent = lock(); peerBelowParent.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' };
    peerBelowParent.packages['node_modules/a-package/node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, peerBelowParent);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-dependency-target-missing'), 'nested child cannot satisfy parent peer');
    write(); const peerBelowParentOptional = structuredClone(peerBelowParent);
    peerBelowParentOptional.packages['node_modules/a-package'].peerDependenciesMeta = { child: { optional: true } }; write(pkg, peerBelowParentOptional);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'nested child ignored for absent optional peer');
    write(); const peerWrongHoisted = structuredClone(peerBelowParent);
    peerWrongHoisted.packages['node_modules/child'] = { version: '1.0.0', integrity }; write(pkg, peerWrongHoisted);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-exact-peer-version-mismatch'), 'wrong hoisted peer rejected despite matching nested child');
    write(); const peerCorrectHoisted = structuredClone(peerWrongHoisted);
    peerCorrectHoisted.packages['node_modules/child'].version = '2.0.0'; write(pkg, peerCorrectHoisted);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'correct hoisted peer accepted even with nested child');
    write(); const peerGrandchild = lock(); peerGrandchild.packages['node_modules/a-package/node_modules/parent'] = {
      version: '1.0.0', integrity, peerDependencies: { child: '2.0.0' }
    };
    peerGrandchild.packages['node_modules/a-package/node_modules/parent/node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, peerGrandchild);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-dependency-target-missing'), 'grandchild nested below peer owner rejected');
    write(); peerGrandchild.packages['node_modules/a-package/node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, peerGrandchild);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'grandchild peer satisfied at declaring package parent level');
    write(); const peerBadMeta = lock(); peerBadMeta.packages['node_modules/a-package'].peerDependencies = { child: '2.0.0' };
    peerBadMeta.packages['node_modules/a-package'].peerDependenciesMeta = { child: { optional: 'true' } };
    peerBadMeta.packages['node_modules/child'] = { version: '2.0.0', integrity }; write(pkg, peerBadMeta);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-metadata-invalid'), 'malformed optional peer metadata rejected');
    write(); const peerBadMap = lock(); peerBadMap.packages['node_modules/a-package'].peerDependencies = [];
    write(pkg, peerBadMap);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-dependency-map-invalid'), 'malformed peer map rejected');
    write(); const peerRange = lock(); peerRange.packages['node_modules/a-package'].peerDependencies = { child: '^2.0.0' };
    peerRange.packages['node_modules/child'] = { version: '2.1.0', integrity }; write(pkg, peerRange);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'range peer metadata admitted without claiming range proof');
    write(); const ancestorChild = lock(); ancestorChild.packages['node_modules/a-package/node_modules/parent'] = {
      version: '1.0.0', integrity, dependencies: { 'ancestor-required': '1.0.0' } };
    ancestorChild.packages['node_modules/a-package/node_modules/ancestor-required'] = { version: '1.0.0', integrity }; write(pkg, ancestorChild);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'nearest ancestor dependency target accepted');
    write(); const scopedChild = lock(); scopedChild.packages['node_modules/a-package'].dependencies = { '@team/child': '^1.0.0' };
    scopedChild.packages['node_modules/@team/child'] = { version: '1.1.0', integrity }; write(pkg, scopedChild);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'scoped dependency target accepted');
    write(); const badMap = lock(); badMap.packages['node_modules/a-package'].dependencies = []; write(pkg, badMap);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-map-invalid'), 'malformed transitive dependency map rejected');
    write(); const badName = lock(); badName.packages['node_modules/a-package'].dependencies = { '../outside': '1.0.0' }; write(pkg, badName);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-name-invalid'), 'unsafe transitive dependency name rejected');
    write(); const badSpec = lock(); badSpec.packages['node_modules/a-package'].dependencies = { 'child': null }; write(pkg, badSpec);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-spec-invalid'), 'malformed transitive dependency specification rejected');
    // Registry-only metadata must not treat shorthand Git/hosted sources or
    // npm aliases as ordinary semver ranges merely because a target exists.
    for (const unsafeSpec of [
      'github:someuser/somerepo', 'gitlab:someuser/somerepo',
      'git@github.com:someuser/somerepo.git', 'someuser/somerepo',
      'npm:alternate-package@1.2.3', 'ssh://git@example.invalid/repo',
      'latest', '1.0.0 || github:someuser/somerepo'
    ]) {
      const unsafe = lock();
      unsafe.packages['node_modules/a-package'].dependencies = { child: unsafeSpec };
      unsafe.packages['node_modules/child'] = { version: '1.0.0', integrity };
      write(pkg, unsafe);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-spec-invalid'),
        `non-registry or non-semver transitive spec rejected: ${unsafeSpec}`);
    }
    // Run302: a numeric suffix does not turn an npm dist-tag into semver.
    // The former character whitelist admitted all these tags, despite
    // reporting registry-only semver metadata as verified.
    for (const spec of ['latest2', 'tag2026', 'git2', 'release2026']) {
      const tagged = lock();
      tagged.packages['node_modules/a-package'].dependencies = { child: spec };
      tagged.packages['node_modules/child'] = { version: '1.0.0', integrity };
      write(pkg, tagged);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-spec-invalid'),
        `numeric npm dist-tag rejected: ${spec}`);
      tagged.packages['node_modules/a-package'].peerDependencies = { child: spec };
      delete tagged.packages['node_modules/a-package'].dependencies;
      write(pkg, tagged);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-peer-dependency-spec-invalid'),
        `numeric npm peer dist-tag rejected: ${spec}`);
    }
    for (const spec of ['1.2.3', '^1.2.3', '~2.0.0', '1.2.x', '*',
      '>=1.0.0 <2.0.0', '1.0.0 - 2.0.0', '>=1.0.0-beta.1', '^1.0.0 || ~2.0.0']) {
      const validRange = lock();
      validRange.packages['node_modules/a-package'].dependencies = { child: spec };
      validRange.packages['node_modules/child'] = { version: spec === '1.2.3' ? '1.2.3' : '1.0.0', integrity };
      write(pkg, validRange);
      check(inspectWindowsDependencyLock(dir).lockfileReady,
        `ordinary semver syntax accepted without claiming resolution: ${spec}`);
    }
    // Normal semver ranges remain supported for transitive packages.
    const semverRange = lock();
    semverRange.packages['node_modules/a-package'].dependencies = { child: '^1.0.0 || ~2.0.0' };
    semverRange.packages['node_modules/child'] = { version: '1.0.0', integrity };
    write(pkg, semverRange);
    check(inspectWindowsDependencyLock(dir).lockfileReady, 'ordinary transitive semver range accepted');
    write(); const badOptionalMap = lock(); badOptionalMap.packages['node_modules/a-package'].optionalDependencies = 'not-an-object'; write(pkg, badOptionalMap);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-dependency-map-invalid'), 'malformed optional dependency map rejected');
    write(); fs.writeFileSync(path.join(dir, 'npm-shrinkwrap.json'), '{}');
    check(inspectWindowsDependencyLock(dir).blockers.includes('shrinkwrap-takes-precedence'), 'shrinkwrap precedence rejected');
    fs.unlinkSync(path.join(dir, 'npm-shrinkwrap.json'));
    write(); fs.truncateSync(lockFile, MAX_LOCK_BYTES + 1);
    check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-oversized-file'), 'oversized lockfile rejected');
    write(); const cli = path.join(__dirname, '../tools/windows-dependency-preflight.js');
    const validCli = spawnSync(process.execPath, [cli, dir, '--require-lock'], { encoding: 'utf8' });
    check(validCli.status === 0 && JSON.parse(validCli.stdout).lockfileReady, 'valid CLI reports metadata only');
    fs.unlinkSync(lockFile);
    const blockedCli = spawnSync(process.execPath, [cli, dir, '--require-lock'], { encoding: 'utf8' });
    check(blockedCli.status === 2, 'missing lockfile blocks strict CLI');
    const reportCli = spawnSync(process.execPath, [cli, dir, '--report'], { encoding: 'utf8' });
    check(reportCli.status === 0 && !JSON.parse(reportCli.stdout).lockfileReady, 'report mode surfaces blocker without failing offline job');
    const badCli = spawnSync(process.execPath, [cli, dir, '--unknown'], { encoding: 'utf8' });
    check(badCli.status === 1, 'invalid CLI options rejected');
    write();
    try {
      fs.unlinkSync(lockFile);
      fs.symlinkSync(packageFile, lockFile);
      check(inspectWindowsDependencyLock(dir).blockers.includes('lockfile-unsafe-file'), 'linked lockfile rejected');
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      if (!quiet) console.log('Windows dependency preflight: symlink case unavailable on this filesystem');
    }
    if (!quiet) console.log(`Windows dependency preflight: ${passed} local offline checks passed (no installer)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
if (require.main === module) runWindowsDependencyPreflightSimulations();
module.exports = { runWindowsDependencyPreflightSimulations };
