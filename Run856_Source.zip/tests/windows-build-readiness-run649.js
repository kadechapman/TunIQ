'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const {assess} = require('../tools/windows-build-readiness-run647');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq649-'));
try {
 const pkg={name:'fixture',version:'1.0.0',dependencies:{alpha:'^1.0.0'}};
 const lock={lockfileVersion:3,packages:{'':{name:'fixture',version:'1.0.0',dependencies:{alpha:'^2.0.0'}},'node_modules/alpha':{version:'2.0.0'}}};
 fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(pkg));
 fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
 assert(assess(dir).blockers.includes('package-lock-dependency-spec-mismatch'));
 lock.packages[''].dependencies.alpha='^1.0.0';
 fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
 assert(!assess(dir).blockers.includes('package-lock-dependency-spec-mismatch'));
 console.log('PASS Run649 dependency spec mismatch and matching fixture');
} finally {fs.rmSync(dir,{recursive:true,force:true});}
