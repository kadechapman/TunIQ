'use strict';
// Synthetic local file inputs only. No COM, OBD, ECU or flash activity.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { normalizeFile, importPhoneLog, MAX_LOG_BYTES } = require('../src/log-import');

function runPhoneLogFileSnapshotSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-phone-snapshot-'));
  const original = 'Time,Engine RPM,VIN\n0,850,PRIVATEVIN\n1,900,PRIVATEVIN\n';
  let passed = 0;
  try {
    const csv = path.join(root, 'valid.csv');
    fs.writeFileSync(csv, original);
    const parsed = normalizeFile(csv);
    assert.equal(parsed.rows.length, 2); passed++;
    assert(!JSON.stringify(parsed.rows).includes('PRIVATEVIN')); passed++;

    const large = path.join(root, 'oversized.csv');
    fs.writeFileSync(large, Buffer.alloc(1));
    fs.truncateSync(large, MAX_LOG_BYTES + 1); // sparse, no huge allocation
    const realRead = fs.readSync;
    let readCalls = 0;
    try {
      fs.readSync = (...args) => { readCalls++; return realRead(...args); };
      assert.throws(() => normalizeFile(large), /16 MB|size limit/i); passed++;
      assert.equal(readCalls, 0, 'oversized log must be rejected before any file read'); passed++;
    } finally { fs.readSync = realRead; }

    const linked = path.join(root, 'linked.csv');
    try {
      fs.symlinkSync(csv, linked);
      assert.throws(() => normalizeFile(linked), /symbolic|link|regular file|unsafe/i); passed++;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }

    const growing = path.join(root, 'growing.csv');
    fs.writeFileSync(growing, original);
    let didGrow = false;
    try {
      fs.readSync = (...args) => {
        const n = realRead(...args);
        if (!didGrow && n > 0) { didGrow = true; fs.appendFileSync(growing, '2,950,PRIVATEVIN\n'); }
        return n;
      };
      assert.throws(() => normalizeFile(growing), /changed|grew|size|during read/i); passed++;
    } finally { fs.readSync = realRead; }
    assert(didGrow); passed++;

    const truncated = path.join(root, 'truncated.csv');
    fs.writeFileSync(truncated, original);
    let didTruncate = false;
    try {
      fs.readSync = (...args) => {
        if (!didTruncate) { didTruncate = true; fs.truncateSync(truncated, 1); }
        return realRead(...args);
      };
      assert.throws(() => normalizeFile(truncated), /changed|truncated|during read/i); passed++;
    } finally { fs.readSync = realRead; }
    assert(didTruncate); passed++;

    const replaced = path.join(root, 'replaced.csv');
    fs.writeFileSync(replaced, original);
    const realOpen = fs.openSync;
    let didReplace = false;
    try {
      fs.openSync = (file, ...args) => {
        if (file === replaced && !didReplace) {
          didReplace = true;
          fs.renameSync(replaced, replaced + '.old');
          fs.writeFileSync(replaced, original.replace('850', '999'));
        }
        return realOpen(file, ...args);
      };
      assert.throws(() => normalizeFile(replaced), /changed|replaced|during read/i); passed++;
    } finally { fs.openSync = realOpen; }
    assert(didReplace); passed++;

    // A change after parsing must not change the recorded SHA-256 provenance.
    const project = { id: 'p1', name: 'Test', folder: path.join(root, 'project') };
    fs.writeFileSync(csv, original);
    const realWrite = fs.writeFileSync;
    let didMutate = false;
    try {
      fs.writeFileSync = (file, ...args) => {
        if (!didMutate && String(file).endsWith('.csv') && String(file).includes('-Imported-')) {
          didMutate = true;
          realWrite(csv, original.replace('850', '999'));
        }
        return realWrite(file, ...args);
      };
      const result = importPhoneLog({ sourceFile: csv, activeProject: project });
      assert.equal(result.sourceFileSha256, crypto.createHash('sha256').update(original).digest('hex')); passed++;
      assert.equal(fs.readFileSync(result.csvPath, 'utf8').includes('850'), true); passed++;
    } finally { fs.writeFileSync = realWrite; }
    assert(didMutate); passed++;

    if (!quiet) console.log(`✓ Phone-log bounded snapshot: ${passed} local-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runPhoneLogFileSnapshotSimulations();
module.exports = { runPhoneLogFileSnapshotSimulations };
