const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');
const { buildPcmHammerDeviceSpec, typeHintUnsupported } = require('../src/pcmhammer-device-lease');

const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitFor(predicate, timeout = 8000) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    if (predicate()) return;
    await wait(20);
  }
  throw new Error('Timed out waiting for PCM Hammer exclusive-device lease simulation.');
}

function createFixture() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-pcmhammer-exclusive-'));
  const project = path.join(root, 'project');
  const portable = path.join(root, 'PCM-Hammer');
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  const executable = path.join(portable, 'PcmHammerCLI');
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  const active = { id: 'p01-exclusive', name: 'P01 Exclusive', folder: project, controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' };
  let releaseCalls = 0;
  const connectionManager = {
    load: () => ({ adapterName: 'OBDLink MX+', adapterIdentity: 'OBDLink MX+ STN2255', lastWorkingPort: 'COM4', identityVerifiedAt: new Date().toISOString() }),
    preflight: async () => ({ ready: false })
  };
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data'),
    getActiveProject: () => active,
    getToolPath: () => portable,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
    releasePort: async () => { releaseCalls += 1; return { released: true }; },
    abortBridgeRequests: () => ({ aborted: 0 }),
    connectionManager,
    appendActivity: () => {},
    emit: () => {},
    onReadComplete: async () => {},
    onSessionComplete: async () => {},
    platform: 'test', allowSimulatedCliPrefixArgs: true, // synthetic Node mock only
    interOperationCooldownMs: 1,
    reopenRecoveryDelayMs: 2
  });
  return { root, project, portable, executable, mock, active, manager, releaseCalls: () => releaseCalls };
}

async function runExclusiveLeaseRead() {
  const f = createFixture();
  process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
  process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
  process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
  await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
  f.manager.saveConfig({ device: 'COM4', lastSuccessfulDevice: 'COM4', lastSuccessfulOperation: 'readProperties' });
  const common = { device: 'COM4', directPortHandoffAuthorized: true, authoritativeProvenPort: true };
  const valid = { port: 'COM4', projectId: f.active.id, controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411', operation: 'readProperties' };
  for (const invalid of [null, { ...valid, port: 'COM3' }, { ...valid, projectId: 'other-project' },
    { ...valid, os: '9379910' }, { ...valid, controller: 'P59' }, { ...valid, hardwareId: 'OTHER-HW' }, { ...valid, serviceNumber: 'OTHER-SERVICE' }]) {
    assert.throws(() => f.manager.preflight('read', { ...common, provenHardwareSession: invalid }),
      error => error.code === 'proven-port-evidence-mismatch' || error.stopCode === 'proven-port-evidence-mismatch',
      'stale or mismatched proof must stop before PCM Hammer opens a COM port');
  }

  f.active.os = '';
  assert.throws(() => f.manager.preflight('read', { ...common, provenHardwareSession: valid }),
    error => error.code === 'proven-port-evidence-mismatch',
    'unknown active project OS must not inherit a supposedly proven COM lane');
  f.active.os = '9373372';
  assert.equal(f.releaseCalls(), 0, 'invalid proof checks must never touch the adapter');
  await f.manager.start('read', {
    device: 'COM4',
    directPortHandoffAuthorized: true,
    authoritativeProvenPort: true,
    provenHardwareSession: valid,
    directPortHandoffReason: 'Read Properties proved this OBDLink and P01.'
  });
  await waitFor(() => !f.manager.session);
  const history = f.manager.getHistory().find(item => item.operation === 'read');
  assert(history, 'exclusive read must be recorded');
  assert.equal(history.state, 'complete');
  assert.equal(history.portLease?.mode, 'proven-pcmhammer-exclusive-lane');
  assert.equal(history.portLease?.exclusivePcmHammerOwnership, true);
  assert.equal(f.releaseCalls(), 0, 'TunIQ must not open/disconnect/release the proven COM port before PCM Hammer');
  assert(history.args.includes('COM4:elm'), 'proven OBDLink must use PCM Hammer ELM type pin to skip serial auto-detect');
  assert.equal(history.device, 'COM4');
  assert.equal(history.deviceSpec, 'COM4:elm');
}

async function runFailedExclusiveInspectionGuard() {
  const f = createFixture();
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
    await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
    f.manager.saveConfig({ device: 'COM4' });
    f.manager.inspectExclusiveSession = async () => { throw new Error('Windows process inventory unavailable'); };
    await assert.rejects(
      f.manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true }),
      error => error.code === 'adapter-conflict-check-failed',
      'failed process inventory must block PCM Hammer before touching COM4');
    assert.equal(f.releaseCalls(), 0);
    assert.equal(f.manager.session, null);
    assert.equal(f.manager.portOwner.owner, 'idle');
    assert.equal(f.manager.getHistory().length, 0);
    f.manager.inspectExclusiveSession = async () => null;
    await assert.rejects(
      f.manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true }),
      error => error.code === 'adapter-conflict-check-failed',
      'missing ownership decision must block PCM Hammer');
    assert.equal(f.releaseCalls(), 0);
    assert.equal(f.manager.session, null);
  } finally { if (f.manager.session) await waitFor(() => !f.manager.session); fs.rmSync(f.root, { recursive: true, force: true }); }
}

// A second UI/IPC request can arrive while the first start awaits Windows
// process inventory. Neither request may progress to COM handoff concurrently.
async function runConcurrentStartGuard() {
  const f = createFixture();
  let releaseInspection;
  const inspectionGate = new Promise(resolve => { releaseInspection = resolve; });
  let inspections = 0;
  let first;
  let second;
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
    await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
    f.manager.saveConfig({ device: 'COM4' });
    f.manager.inspectExclusiveSession = async () => {
      inspections++;
      await inspectionGate;
      throw new Error('Deliberate inventory failure; do not open a COM port');
    };
    first = f.manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true })
      .then(() => ({ code: 'unexpected-success' }), error => error);
    assert.equal(inspections, 1, 'first start must be waiting for process inspection');
    second = f.manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true })
      .then(() => ({ code: 'unexpected-success' }), error => error);
    const outcome = await Promise.race([
      second,
      wait(120).then(() => ({ code: 'second-start-waited-for-inventory' }))
    ]);
    assert.equal(outcome.code, 'operation-starting',
      'second start must fail immediately while first is awaiting process inspection');
    assert.equal(inspections, 1, 'second start must not run process inventory');
    assert.equal(f.releaseCalls(), 0, 'neither start may touch or release COM4');
    assert.equal(f.manager.session, null, 'no subprocess session may be created');
  } finally {
    releaseInspection();
    if (first) await first;
    if (second) await second;
    fs.rmSync(f.root, { recursive: true, force: true });
  }
  assert.equal(f.manager.startPending, false, 'failed start must release its in-flight guard');
}

// A recovery click must not advertise COM ownership as idle while the prior
// PCM Hammer process is still terminating. This is a synthetic child only.
function runRecoveryExitOwnershipGuard() {
  const f = createFixture();
  try {
    let killCalls = 0;
    const child = { pid: 123456, killed: false, kill() { killCalls++; this.killed = true; return true; } };
    const session = { id: 'synthetic-read', operation: 'read', child, cancelRequested: false };
    f.manager.session = session;
    f.manager.setPortOwner('pcmhammer', { port: 'COM4', operation: 'read' });
    const recovery = f.manager.clearTransientRecoveryState('synthetic read cancellation');
    assert.equal(killCalls, 1, 'recovery must request cancellation of an active read');
    assert.strictEqual(f.manager.session, session, 'do not drop active process session before its close event');
    assert.equal(f.manager.portOwner.owner, 'pcmhammer', 'do not release COM ownership until process exit');
    assert.equal(session.cancelRequested, true, 'disable any command retry after cancellation');
    assert.equal(recovery.activeSession, true, 'report pending termination to the caller');
    // Repeated recovery requests must not claim the adapter is free either.
    f.manager.clearTransientRecoveryState('repeat recovery click');
    assert.equal(f.manager.portOwner.owner, 'pcmhammer');
    // A start can also be awaiting asynchronous Windows inspection with no
    // published session yet. Recovery must preserve that admission lease.
    f.manager.session = null;
    f.manager.startPending = true;
    const pending = f.manager.clearTransientRecoveryState('during process inventory');
    assert.equal(f.manager.portOwner.owner, 'pcmhammer', 'in-flight preflight cannot be marked idle');
    assert.equal(pending.activeSession, true, 'pending admission must be reported as active');
  } finally {
    f.manager.session = null;
    f.manager.startPending = false;
    fs.rmSync(f.root, { recursive: true, force: true });
  }
}

// Synthetic Node CLI integration: COM ownership is released only by the
// child close/finalize path, never by the recovery button itself.
async function runRecoveryProcessExitIntegration() {
  const f = createFixture();
  const originalScenario = process.env.PCMHAMMER_MOCK_SCENARIO;
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'stalled-read';
    process.env.PCMHAMMER_MOCK_STALL_HOLD_MS = '5000';
    await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
    f.manager.saveConfig({ device: 'COM4' });
    await f.manager.start('read', { device: 'COM4', directPortHandoffAuthorized: true });
    assert(f.manager.session?.child?.pid, 'mock read child must be running');
    const recovery = f.manager.clearTransientRecoveryState('read-only recovery integration');
    assert.equal(recovery.activeSession, true);
    assert.equal(f.manager.portOwner.owner, 'pcmhammer', 'COM must stay leased until mock process closes');
    await waitFor(() => !f.manager.session);
    assert.equal(f.manager.portOwner.owner, 'idle', 'normal child finalizer must release the COM lease');
    assert(f.manager.getHistory().some(item => item.operation === 'read'), 'interrupted read must leave an audit history');
  } finally {
    if (originalScenario === undefined) delete process.env.PCMHAMMER_MOCK_SCENARIO;
    else process.env.PCMHAMMER_MOCK_SCENARIO = originalScenario;
    delete process.env.PCMHAMMER_MOCK_STALL_HOLD_MS;
    if (f.manager.session) {
      try { f.manager.session.child?.kill(); } catch {}
      await waitFor(() => !f.manager.session);
    }
    fs.rmSync(f.root, { recursive: true, force: true });
  }
}

// A Bluetooth repair/manual COM probe is an external serial-port consumer.
// It must not run while PCM Hammer is terminating or starting, and it must
// reserve admission across asynchronous work so PCM Hammer cannot race in.
async function runExternalComWorkflowLeaseGuard() {
  const f = createFixture();
  try {
    let externalTouches = 0;
    let releaseExternal;
    const externalGate = new Promise(resolve => { releaseExternal = resolve; });
    const external = f.manager.withExclusiveExternalPortAccess('synthetic Bluetooth repair', async () => {
      externalTouches++;
      await externalGate;
      return 'repair-finished';
    });
    assert.equal(f.manager.externalPortAccessPending, true, 'external operation must reserve COM synchronously');
    await assert.rejects(
      f.manager.start('readProperties', { device: 'COM4' }),
      error => error.code === 'external-com-workflow-active',
      'PCM Hammer must not start while Bluetooth repair is running');
    await assert.rejects(
      f.manager.withExclusiveExternalPortAccess('simultaneous manual port probe', async () => { externalTouches++; }),
      error => error.code === 'external-com-workflow-active',
      'two external COM consumers must never overlap');
    assert.equal(externalTouches, 1);
    releaseExternal();
    assert.equal(await external, 'repair-finished');
    assert.equal(f.manager.externalPortAccessPending, false, 'lease must release on success');

    await assert.rejects(f.manager.withExclusiveExternalPortAccess('failed probe', async () => {
      throw new Error('simulated adapter probe failure');
    }), /simulated adapter probe failure/);
    assert.equal(f.manager.externalPortAccessPending, false, 'lease must release on error');

    const child = { pid: 123456, killed: false, kill() { this.killed = true; return true; } };
    f.manager.session = { id: 'synthetic-read', operation: 'read', child, cancelRequested: false };
    f.manager.setPortOwner('pcmhammer', { port: 'COM4', operation: 'read' });
    await assert.rejects(f.manager.withExclusiveExternalPortAccess('manual verify during termination', async () => {
      externalTouches++;
    }), error => error.code === 'pcmhammer-exit-pending');
    assert.equal(externalTouches, 1, 'manual COM probe must never touch adapter while PCM Hammer is live');
    assert.equal(f.manager.portOwner.owner, 'pcmhammer');
    assert.equal(f.manager.externalPortAccessPending, false);
    f.manager.session = null;
    f.manager.startPending = true;
    await assert.rejects(f.manager.withExclusiveExternalPortAccess('repair during preflight', async () => {
      externalTouches++;
    }), error => error.code === 'pcmhammer-exit-pending');
    assert.equal(externalTouches, 1, 'repair must not start during pending PCM Hammer admission');
  } finally {
    f.manager.session = null;
    f.manager.startPending = false;
    fs.rmSync(f.root, { recursive: true, force: true });
  }
  const main = fs.readFileSync(path.join(__dirname, '..', 'src', 'main.js'), 'utf8');
  for (const label of ['Bluetooth SPP repair', 'Manual OBDLink port verification', 'Manual PCM Hammer COM handoff']) {
    assert(main.includes(`withExclusiveExternalPortAccess('${label}'`), `${label} must use the external COM admission lease`);
  }
}

// CLI help/version probing must not spawn a second PCM Hammer process while
// a read owns the adapter, and must never cancel an active read to probe.
async function runCliProbeAdmissionGuard() {
  const f = createFixture();
  let captures = 0;
  let cancellations = 0;
  try {
    f.manager.runCapture = async () => {
      captures++;
      return { code: 0, text: 'PCM Hammer CLI v2.0 --help --version', stdout: '', stderr: '' };
    };
    const session = { id: 'active-read', operation: 'read', child: { kill() { cancellations++; return true; } } };
    f.manager.session = session;
    f.manager.setPortOwner('pcmhammer', { port: 'COM4', operation: 'read' });
    await assert.rejects(f.manager.probe({ executable: f.executable }), error => error.code === 'pcmhammer-exit-pending',
      'CLI probe must be rejected while a PCM Hammer read owns COM4');
    assert.strictEqual(f.manager.session, session, 'CLI probe must not clear the active session');
    assert.equal(cancellations, 0, 'CLI probe must not cancel an active read');
    assert.equal(captures, 0, 'CLI probe must not spawn help/version subprocesses');
    assert.equal(fs.existsSync(f.manager.configFile()), false, 'rejected probe must not mutate CLI configuration');
    f.manager.session = null;
    f.manager.setPortOwner('idle', { port: 'COM4' });
    f.manager.startPending = true;
    await assert.rejects(f.manager.probe({ executable: f.executable }), error => error.code === 'pcmhammer-exit-pending',
      'CLI probe must not race PCM Hammer startup');
    f.manager.startPending = false;
    assert.equal(captures, 0);
    let releaseProbe;
    const probeGate = new Promise(resolve => { releaseProbe = resolve; });
    f.manager.runCapture = async () => {
      captures++;
      if (captures === 1) await probeGate;
      return { code: 0, text: 'PCM Hammer CLI v2.0 --help --version', stdout: '', stderr: '' };
    };
    const probe = f.manager.probe({ executable: f.executable });
    await waitFor(() => captures === 1);
    assert.equal(f.manager.externalPortAccessPending, true, 'CLI probe must reserve adapter admission during subprocesses');
    await assert.rejects(f.manager.start('readProperties', { device: 'COM4' }), error => error.code === 'external-com-workflow-active',
      'PCM Hammer must not start while CLI probing is in flight');
    await assert.rejects(f.manager.probe({ executable: f.executable }), error => error.code === 'external-com-workflow-active',
      'overlapping CLI probes must not spawn');
    assert.equal(captures, 1, 'rejected overlapping probe must not spawn');
    releaseProbe();
    await probe;
    assert.equal(f.manager.externalPortAccessPending, false, 'successful probe must release admission');
  } finally {
    f.manager.session = null;
    f.manager.startPending = false;
    fs.rmSync(f.root, { recursive: true, force: true });
  }
}

// End-to-end synthetic CLI regression: a failed transaction admission must
// stop BEFORE spawn(), not merely throw after a child already owns COM4.
async function runPreSpawnAdmissionIntegration() {
  const f = createFixture();
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
    await f.manager.probe({ executable: f.executable, prefixArgs: [f.mock] });
    f.manager.saveConfig({ device: 'COM4' });
    let registeredChildren = 0;
    f.manager.registerOwnedProcess = () => { registeredChildren++; };
    let admissionChecks = 0;
    f.manager.hardwareTransaction.assertCanStartProcess = () => {
      admissionChecks++;
      throw new Error('Synthetic competing COM owner');
    };
    await f.manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    await waitFor(() => f.manager.getHistory().some(item => item.stopCode === 'pcmhammer-spawn-admission-denied'));
    assert.equal(admissionChecks, 1, 'real launch path must check the transaction immediately before spawn');
    assert.equal(registeredChildren, 0, 'denied pre-spawn admission must not register or launch a child');
    assert.equal(f.manager.session, null, 'denied attempt must terminate the local session');
    assert.notEqual(f.manager.portOwner.owner, 'idle', 'denied admission must not falsely release a foreign COM owner');
    assert.equal(f.manager.getHistory().at(-1).state, 'failed');
  } finally {
    fs.rmSync(f.root, { recursive: true, force: true });
  }
}

async function runPcmHammerExclusiveDeviceLeaseSimulations({ quiet = false } = {}) {
  const typed = buildPcmHammerDeviceSpec({ port: 'COM4', authoritative: true, adapterProfile: { adapterName: 'OBDLink MX+', adapterIdentity: 'STN2255' }, helpText: '--device COM3:elm' });
  assert.equal(typed.spec, 'COM4:elm');
  assert.equal(typed.typed, true);
  const plain = buildPcmHammerDeviceSpec({ port: 'COM4', authoritative: false, adapterProfile: { adapterName: 'OBDLink MX+' } });
  assert.equal(plain.spec, 'COM4');
  assert.equal(typeHintUnsupported('Error: unknown serial device type "elm".'), true);
  await runExclusiveLeaseRead();
  await runFailedExclusiveInspectionGuard();
  await runConcurrentStartGuard();
  runRecoveryExitOwnershipGuard();
  await runRecoveryProcessExitIntegration();
  await runExternalComWorkflowLeaseGuard();
  await runCliProbeAdmissionGuard();
  await runPreSpawnAdmissionIntegration();
  if (!quiet) console.log('✓ PCM Hammer exclusive device lease and pre-spawn denial: 13/13 offline checks');
  return { passed: 13, total: 13 };
}

if (require.main === module) runPcmHammerExclusiveDeviceLeaseSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runPcmHammerExclusiveDeviceLeaseSimulations };
