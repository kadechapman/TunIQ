'use strict';
// Filesystem-only regression: never touches PCM Hammer, COM ports, or an ECU.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
const { checkSafeReadPath } = require('../src/read-output-safety');

function runP01ReadAdmissionAliasSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-admission-'));
  let passed = 0;
  let symlinkSkipped = 0;
  function trySymlink(target, link, type = 'file') {
    try { fs.symlinkSync(target, link, type); return true; }
    catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      symlinkSkipped += 1; return false;
    }
  }
  try {
    const first = path.join(root, 'first.bin');
    const second = path.join(root, 'second.bin');
    const contents = Buffer.alloc(P01_BIN_SIZE, 0x71);
    fs.writeFileSync(first, contents);
    const active = { id: 'alias-admission', name: 'Read admission fixture', controller: 'P01', os: '9379910', folder: root, bin: first };
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'fixture', serviceNumber: 'fixture' });

    const firstLink = path.join(root, 'first-link.bin');
    if (trySymlink(first, firstLink)) {
      assert.throws(() => manager.recordRead(firstLink, {}, { id: 'linked-first' }), /link|alias|independent|regular/i,
        'A symbolic-link file must not be accepted as a first read');
      assert.equal(manager.load().reads.length, 0, 'rejected first read must not be persisted'); passed++;
      fs.unlinkSync(firstLink);
    }

    const redirected = path.join(root, 'redirected');
    const parentLinkAvailable = trySymlink(root, redirected, 'dir');
    if (parentLinkAvailable) {
      assert.throws(() => manager.recordRead(path.join(redirected, 'first.bin'), {}, { id: 'redirected-first' }), /link|alias|regular|redirect/i,
        'A symlink or junction parent must not be accepted as a read source');
      assert.equal(manager.load().reads.length, 0); passed++;
    }

    // The CLI and commissioning ledger must share Win32-safe path rules.
    // POSIX can create these names, while Win32 may resolve them to device
    // aliases or NTFS streams; the ledger must never trust such a read.
    const unsafeNames = ['NUL.bin', 'COM¹.bin', 'backup.bin:alternate', 'backup.bin.'];
    for (const name of unsafeNames) {
      const candidate = path.join(root, name);
      assert.equal(checkSafeReadPath(candidate).ok, false, `Win32 path policy must reject ${name}`);
      if (process.platform !== 'win32') {
        fs.writeFileSync(candidate, contents);
        assert.throws(() => manager.recordRead(candidate, {}, { id: `unsafe-${name}` }),
          /safe local path|direct|regular/i, `unsafe name must never enter commissioning ledger: ${name}`);
        assert.equal(manager.load().reads.length, 0);
        fs.unlinkSync(candidate);
      }
      passed++;
    }
    const unsafeParent = path.join(root, 'AUX');
    assert.equal(checkSafeReadPath(path.join(unsafeParent, 'read.bin')).ok, false);
    if (process.platform !== 'win32') {
      fs.mkdirSync(unsafeParent);
      fs.writeFileSync(path.join(unsafeParent, 'read.bin'), contents);
      assert.throws(() => manager.recordRead(path.join(unsafeParent, 'read.bin'), {}, { id: 'unsafe-parent' }),
        /safe local path|direct|regular/i);
      assert.equal(manager.load().reads.length, 0);
    }
    passed++;

    const initial = manager.recordRead(first, {}, { id: 'session-1' });
    assert.equal(initial.pairStatus, 'awaiting-second'); passed++;

    if (trySymlink(first, second)) {
      assert.throws(() => manager.recordRead(second, {}, { id: 'session-2' }), /link|alias|independent|regular/i,
        'A symbolic-link second read must not be reported as verified');
      assert.equal(manager.load().reads.length, 1, 'rejected second read must not be persisted');
      assert.equal(manager.status().dualReadVerified, false); passed++;
      fs.unlinkSync(second);
    }

    if (parentLinkAvailable) {
      fs.writeFileSync(second, contents);
      assert.throws(() => manager.recordRead(path.join(redirected, 'second.bin'), {}, { id: 'redirected-second' }), /link|alias|regular|redirect/i,
        'A redirected parent must not qualify as an independent second read');
      assert.equal(manager.load().reads.length, 1); passed++;
      fs.unlinkSync(second);
    }

    fs.linkSync(first, second);
    assert.throws(() => manager.recordRead(second, {}, { id: 'session-3' }), /link|alias|independent|regular/i,
      'Hard-linked read paths are not independent read evidence');
    assert.equal(manager.load().reads.length, 1); passed++;
    fs.unlinkSync(second);

    fs.writeFileSync(second, contents);
    const verified = manager.recordRead(second, {}, { id: 'session-4' });
    assert.equal(verified.acceptedAsOriginal, true);
    assert.equal(verified.status.dualReadVerified, true); passed++;

    if (process.platform !== 'win32') {
      // Even a previously verified pair must fail closed if a ledger path
      // is changed to a Win32 device alias after successful verification.
      const renamed = path.join(root, 'NUL.bin');
      fs.renameSync(second, renamed);
      const state = manager.load();
      state.readPair.second.path = renamed;
      manager.save(state);
      assert.equal(manager.status().dualReadVerified, false,
        'live pair status must not trust a Windows-unsafe backup path');
      passed++;
    }

    console.log(`✓ P01 read admission aliases: ${passed} filesystem-only checks passed${symlinkSkipped ? ` (${symlinkSkipped} symlink checks unavailable)` : ''} (no hardware)`);
    return { passed, symlinkSkipped, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runP01ReadAdmissionAliasSimulations();
module.exports = { runP01ReadAdmissionAliasSimulations };
