'use strict';
// Synthetic PE fixture only. No Electron, native Windows, ECU, or flash activity.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { inspectPe, writeEvidence, verifyEvidence } = require('../tools/windows-pe-integrity');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-pe-test-'));
let checks = 0;
const check = (label, fn) => { fn(); checks++; };
const exe = path.join(dir, 'preview.exe');
const evidence = path.join(dir, 'proof.json');
function fixture() {
  const data = Buffer.alloc(4096);
  data.write('MZ', 0, 'ascii');
  data.writeUInt32LE(0x100, 0x3c);
  data.write('PE\0\0', 0x100, 'binary');
  data.writeUInt16LE(0x8664, 0x104);
  data.writeUInt16LE(1, 0x106); // one .text section
  data.writeUInt16LE(0x0002, 0x116);
  data.writeUInt16LE(0x00f0, 0x114);
  data.writeUInt16LE(0x020b, 0x118);
  data.writeUInt32LE(0x1000, 0x118 + 16); // entry point RVA
  data.writeUInt32LE(0x1000, 0x118 + 32); // section alignment
  data.writeUInt32LE(0x200, 0x118 + 36); // file alignment
  data.writeUInt32LE(0x2000, 0x118 + 56); // image size
  data.writeUInt32LE(0x400, 0x118 + 60); // headers size
  data.write('.text', 0x208, 'ascii'); // first section header
  data.writeUInt32LE(0x1000, 0x208 + 8);
  data.writeUInt32LE(0x1000, 0x208 + 12);
  data.writeUInt32LE(0x200, 0x208 + 16);
  data.writeUInt32LE(0x400, 0x208 + 20);
  data.writeUInt16LE(2, 0x118 + 68);
  fs.writeFileSync(exe, data);
  fs.truncateSync(exe, 2 * 1024 * 1024);
}
try {
  fixture();
  check('valid synthetic AMD64 GUI PE parsed', () => assert.equal(inspectPe(exe).machine, 'amd64'));
  check('new hard link created during hashing invalidates PE evidence', () => {
    const alias = path.join(dir, 'inflight-hardlink.exe');
    const originalRead = fs.readSync;
    let linked = false;
    try {
      fs.readSync = function(fd, ...args) {
        if (!linked && args[3] === 0 && args[2] >= 1024 * 1024) {
          linked = true;
          fs.linkSync(exe, alias);
        }
        return originalRead.call(fs, fd, ...args);
      };
      assert.throws(() => inspectPe(exe), /executable-changed-during-hash/);
      assert.equal(linked, true);
    } finally {
      fs.readSync = originalRead;
      fs.rmSync(alias, { force: true });
    }
  });
  check('same-size PE mutation with restored mtime invalidates evidence', () => {
    const originalRead = fs.readSync;
    const preserved = new Date('2020-01-01T00:00:00.000Z');
    fs.utimesSync(exe, preserved, preserved);
    let changed = false;
    try {
      fs.readSync = function(fd, ...args) {
        if (!changed && args[3] === 0 && args[2] >= 1024 * 1024) {
          changed = true;
          const edit = fs.openSync(exe, 'r+');
          try { fs.writeSync(edit, Buffer.from([0x7f]), 0, 1, 2 * 1024 * 1024 - 1); }
          finally { fs.closeSync(edit); }
          fs.utimesSync(exe, preserved, preserved);
        }
        return originalRead.call(fs, fd, ...args);
      };
      assert.throws(() => inspectPe(exe), /executable-changed-during-hash/);
      assert.equal(changed, true);
    } finally {
      fs.readSync = originalRead;
      fixture();
    }
  });
  check('evidence written and independently verified', () => { writeEvidence(exe, evidence); assert.equal(verifyEvidence(exe, evidence), true); });
  check('evidence never claims startup', () => assert.equal(JSON.parse(fs.readFileSync(evidence)).nativeStartupVerified, false));
  check('proof replaced between lstat and descriptor open is rejected', () => {
    const replacement = path.join(dir, 'replacement-proof.json');
    const moved = path.join(dir, 'original-proof-moved.json');
    fs.copyFileSync(evidence, replacement);
    const originalOpen = fs.openSync;
    let swapped = false;
    try {
      fs.openSync = function(file, ...args) {
        if (!swapped && file === evidence) {
          swapped = true;
          fs.renameSync(evidence, moved);
          fs.copyFileSync(replacement, evidence);
        }
        return originalOpen.call(fs, file, ...args);
      };
      assert.throws(() => verifyEvidence(exe, evidence), /pe-proof-changed/);
      assert.equal(swapped, true);
    } finally {
      fs.openSync = originalOpen;
      fs.rmSync(evidence, { force: true });
      fs.renameSync(moved, evidence);
      fs.rmSync(replacement, { force: true });
    }
  });
  check('replaced PE proof path must not certify a different proof', () => {
    // An attacker-controlled proof is checked by lstat first. The original
    // implementation reopened that pathname and could read substituted bytes.
    const validProof = fs.readFileSync(evidence, 'utf8');
    const validCopy = path.join(dir, 'valid-proof-copy.json');
    const moved = path.join(dir, 'moved-invalid-proof.json');
    fs.writeFileSync(validCopy, validProof);
    fs.writeFileSync(evidence, JSON.stringify({ ...JSON.parse(validProof), sha256: '0'.repeat(64) }, null, 2));
    const originalRead = fs.readFileSync;
    let swapped = false;
    try {
      fs.readFileSync = function(file, ...args) {
        if (!swapped && file === evidence) {
          swapped = true;
          fs.renameSync(evidence, moved);
          fs.copyFileSync(validCopy, evidence);
        }
        return originalRead.call(fs, file, ...args);
      };
      assert.throws(() => verifyEvidence(exe, evidence), /mismatch|changed|unsafe/);
    } finally {
      fs.readFileSync = originalRead;
      fs.rmSync(evidence, { force: true });
      fs.rmSync(moved, { force: true });
      fs.copyFileSync(validCopy, evidence);
      fs.rmSync(validCopy, { force: true });
    }
  });
  check('overwrite existing proof denied', () => assert.throws(() => writeEvidence(exe, evidence), /EEXIST/));
  check('tampered executable rejected', () => { fs.appendFileSync(exe, 'tamper'); assert.throws(() => verifyEvidence(exe, evidence), /mismatch/); });
  fixture();
  check('missing MZ rejected', () => { const fd = fs.openSync(exe, 'r+'); fs.writeSync(fd, Buffer.from('XX'), 0, 2, 0); fs.closeSync(fd); assert.throws(() => inspectPe(exe), /dos-header/); });
  fixture();
  check('wrong architecture rejected', () => { const fd = fs.openSync(exe, 'r+'); const b = Buffer.alloc(2); b.writeUInt16LE(0x14c); fs.writeSync(fd, b, 0, 2, 0x104); fs.closeSync(fd); assert.throws(() => inspectPe(exe), /amd64/); });
  fixture();
  check('missing PE header rejected', () => { const fd = fs.openSync(exe, 'r+'); fs.writeSync(fd, Buffer.from('XXXX'), 0, 4, 0x100); fs.closeSync(fd); assert.throws(() => inspectPe(exe), /pe-header/); });
  fixture();
  // Run230: A PE-shaped 2MB placeholder used to pass header/hash checks
  // even with no executable sections, no entry point, or invalid image layout.
  const mutateHeader = (offset, value, size = 4) => {
    fixture();
    const fd = fs.openSync(exe, 'r+');
    try {
      const b = Buffer.alloc(size);
      if (size === 2) b.writeUInt16LE(value);
      else b.writeUInt32LE(value);
      fs.writeSync(fd, b, 0, size, offset);
    } finally { fs.closeSync(fd); }
  };
  check('PE with zero sections rejected', () => {
    mutateHeader(0x106, 0, 2);
    assert.throws(() => inspectPe(exe), /invalid-pe-layout/);
  });
  check('PE with zero entry point rejected', () => {
    mutateHeader(0x118 + 16, 0);
    assert.throws(() => inspectPe(exe), /invalid-pe-layout/);
  });
  check('PE with entry point outside image rejected', () => {
    mutateHeader(0x118 + 16, 0x4000);
    assert.throws(() => inspectPe(exe), /invalid-pe-layout/);
  });
  check('PE with section table outside declared headers rejected', () => {
    mutateHeader(0x118 + 60, 0x200);
    assert.throws(() => inspectPe(exe), /invalid-pe-layout/);
  });
  check('PE with zero image size rejected', () => {
    mutateHeader(0x118 + 56, 0);
    assert.throws(() => inspectPe(exe), /invalid-pe-layout/);
  });
  check('short placeholder exe rejected', () => { fs.truncateSync(exe, 4096); assert.throws(() => inspectPe(exe), /too-small/); });
  fixture();
  check('symlink executable rejected', () => { const link = path.join(dir, 'link.exe'); fs.symlinkSync(exe, link); assert.throws(() => inspectPe(link), /unsafe/); });
  check('symlink proof rejected', () => { const link = path.join(dir, 'link.json'); fs.symlinkSync(evidence, link); assert.throws(() => verifyEvidence(exe, link), /unsafe/); });
  console.log(`Windows PE integrity offline fixture regressions: ${checks}/${checks} passed (no Windows execution).`);
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
