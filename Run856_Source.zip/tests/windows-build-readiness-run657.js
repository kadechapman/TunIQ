'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq657-'));
const base = { name: 'fixture', version: '1.0.0' };
function run(pkg, lock, expected) {
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(lock));
  const r = assess(root);
  assert.deepStrictEqual(r.blockers, expected, JSON.stringify(r));
  assert.strictEqual(r.ecmWriteAuthorized, false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified, false);
}
try {
  run(base, { lockfileVersion: 3, packages: { '': { ...base } } }, []);
  for (const group of ['dependencies', 'devDependencies', 'optionalDependencies']) {
    run(base, { lockfileVersion: 3, packages: { '': { ...base, [group]: { stale: '1.0.0' } }, 'node_modules/stale': { version: '1.0.0' } } }, ['package-lock-root-extra-dependency-declarations']);
  }
  run({ ...base, dependencies: { a: '1.0.0' } }, { lockfileVersion: 3, packages: { '': { ...base, dependencies: { a: '1.0.0' } }, 'node_modules/a': { version: '1.0.0' } } }, []);
} finally { fs.rmSync(root, { recursive: true, force: true }); }
console.log('Run657: five stale-root/valid dependency fixtures passed');
