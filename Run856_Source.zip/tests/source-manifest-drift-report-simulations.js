'use strict';
const assert = require('node:assert/strict');
const { report } = require('../tools/source-manifest-drift-report');
const base = {windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'], contentMismatchCount: 1,
  contentMismatches: [{path: 'package.json', expectedSize: 4, actualSize: 5, expectedSha256: 'a'.repeat(64), actualSha256: 'b'.repeat(64)}]};
const drift = report('/unused', () => base);
assert.equal(drift.manifestVerified, false);
assert.equal(drift.evidenceComplete, true);
assert.equal(drift.mismatches[0].path, 'package.json');
assert.equal(report('/unused', () => ({...base, contentMismatchCount: 2})).evidenceComplete, false);
assert.equal(report('/unused', () => ({...base, contentMismatchCount: 0, contentMismatches: []})).manifestVerified, false);
assert.equal(report('/unused', () => ({...base, windowsSourcePathsSafe: true, blockers: [], contentMismatchCount: 0, contentMismatches: []})).manifestVerified, true);
const malformed = report('/unused', () => ({...base, contentMismatches: [null]}));
assert.equal(malformed.evidenceComplete, false);
assert.equal(malformed.mismatches.length, 0);
assert.ok(malformed.blockers.includes('incomplete-or-malformed-mismatch-evidence'));
const invalidHash = report('/unused', () => ({...base, contentMismatches: [{...base.contentMismatches[0], actualSha256: 'bad'}]}));
assert.equal(invalidHash.evidenceComplete, false);
assert.equal(invalidHash.manifestVerified, false);
for (const badPath of ['../package.json', 'C:/package.json', 'bad\\path', 'bad\npath', 'CON']) {
  const result = report('/unused', () => ({...base, contentMismatches: [{...base.contentMismatches[0], path: badPath}]}));
  assert.equal(result.evidenceComplete, false, `unsafe path accepted: ${JSON.stringify(badPath)}`);
  assert.equal(result.manifestVerified, false);
}
const duplicate = report('/unused', () => ({...base, contentMismatchCount: 2,
  contentMismatches: [base.contentMismatches[0], {...base.contentMismatches[0]}]}));
assert.equal(duplicate.evidenceComplete, false);
const equalHashes = report('/unused', () => ({...base, contentMismatches: [{...base.contentMismatches[0], actualSha256: 'A'.repeat(64)}]}));
assert.equal(equalHashes.evidenceComplete, false);
assert.equal(equalHashes.manifestVerified, false);
assert.ok(equalHashes.blockers.includes('incomplete-or-malformed-mismatch-evidence'));
for (const badAudit of [null, undefined, false, 'bad', [], 42]) {
  const result = report('/unused', () => badAudit);
  assert.equal(result.manifestVerified, false);
  assert.equal(result.evidenceComplete, false);
  assert.ok(result.blockers.includes('unverified-preflight'));
  assert.ok(result.blockers.includes('incomplete-or-malformed-mismatch-evidence'));
}
console.log('source-manifest-drift-report simulations: 19 passed');
