'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
for (const [entry, invalid] of [
  [{version:'1.0.0',link:'true'},true],
  [{link:true},true],
  [{link:true,resolved:''},true],
  [{link:true,resolved:42},true],
  [{link:true,resolved:'../electron'},false],
  [{version:'1.0.0',link:false},false],
  [{version:'1.0.0'},false]
]) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(),'tuniq662-'));
  try {
    fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}}));
    fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}},'node_modules/electron':entry}}));
    const result=assess(dir);
    assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'),invalid,JSON.stringify(entry));
    assert.strictEqual(result.ecmWriteAuthorized,false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false);
    if (!invalid) assert.deepStrictEqual(result.blockers,[]);
  } finally { fs.rmSync(dir,{recursive:true,force:true}); }
}
console.log('Run662: 7 link metadata fixtures passed');
