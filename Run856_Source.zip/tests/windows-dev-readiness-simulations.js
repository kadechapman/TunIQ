'use strict';
const assert = require('node:assert/strict');
const { inspectWindowsDevReadiness } = require('../tools/windows-dev-readiness');
const result = inspectWindowsDevReadiness();
assert.equal(result.sourceOnly, true);
assert.equal(result.sourceIntegrityPassed, false);
assert(result.blockers.some(value => value.startsWith('source-integrity:')));
assert.equal(result.nativeWindowsRuntimeVerified, false);
assert.equal(result.fullApplicationVerified, false);
assert.equal(result.readyForUserTesting, false);
assert.equal(result.readyForPublicRelease, false);
assert(result.blockers.includes('native-windows-electron-runtime-not-tested'));
assert(result.blockers.includes('full-application-runtime-not-tested'));
assert.equal(result.dependenciesReady, false);
assert(result.blockers.includes('dependency:lockfile-missing'));
console.log('PASS offline readiness cannot be misreported as Windows runtime or user-test readiness');

// A nonexistent checkout must fail closed without crashing the report generator.
const missing = inspectWindowsDevReadiness('/this-tuniq-checkout-does-not-exist-run581');
assert.equal(missing.readyForUserTesting, false);
assert.equal(missing.readonlyAdmissionPassed, false);
assert.equal(missing.sourceIntegrityPassed, false);
assert(missing.blockers.some(value => value.startsWith('source-integrity:')));
assert(missing.blockers.some(value => value.startsWith('dependency:')));
assert(missing.blockers.some(value => value.startsWith('readonly:')));
console.log('PASS absent checkout fails closed and produces structured blockers');

// Simulate a future dependency preflight returning a failure with no reasons.
// The aggregate gate must never silently omit that failure.
const dependencyPath = require.resolve('../tools/windows-dependency-preflight');
const readinessPath = require.resolve('../tools/windows-dev-readiness');
const dependencyModule = require.cache[dependencyPath];
const originalExports = dependencyModule.exports;
try {
  for (const malformed of [{ lockfileReady: false, blockers: [] }, { lockfileReady: false }, null]) {
    dependencyModule.exports = { ...originalExports, inspectWindowsDependencyLock: () => malformed };
    delete require.cache[readinessPath];
    const check = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(check.dependenciesReady, false);
    assert(check.blockers.includes('dependency:unverified'));
    assert.equal(check.readyForUserTesting, false);
  }
} finally {
  dependencyModule.exports = originalExports;
  delete require.cache[readinessPath];
}
console.log('PASS malformed dependency preflight results fail closed');

// A contradictory success flag must not override reported blockers or absent evidence.
for (const malformed of [
  { lockfileReady: true, blockers: ['conflicting-evidence'] },
  { lockfileReady: true },
  { lockfileReady: true, blockers: null }
]) {
  const dependencyModule = require.cache[dependencyPath];
  const original = dependencyModule.exports;
  try {
    dependencyModule.exports = { ...original, inspectWindowsDependencyLock: () => malformed };
    delete require.cache[readinessPath];
    const check = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(check.dependenciesReady, false);
    assert(check.blockers.some(value => value.startsWith('dependency:')));
  } finally {
    dependencyModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS contradictory or malformed success evidence fails closed');

// Malformed blocker entries must not leak objects or empty diagnostics into output.
for (const malformed of [
  { lockfileReady: true, blockers: [null] },
  { lockfileReady: false, blockers: [{}] },
  { lockfileReady: false, blockers: [''] },
  { lockfileReady: false, blockers: ['   '] },
  { lockfileReady: false, blockers: ['valid', 42] },
  { lockfileReady: false, blockers: ['bad\nline'] },
  { lockfileReady: false, blockers: ['bad\x1b[31m'] },
  { lockfileReady: false, blockers: ['x'.repeat(513)] },
  { lockfileReady: false, blockers: ['duplicate', 'duplicate'] }
]) {
  const dependencyModule = require.cache[dependencyPath];
  const original = dependencyModule.exports;
  try {
    dependencyModule.exports = { ...original, inspectWindowsDependencyLock: () => malformed };
    delete require.cache[readinessPath];
    const check = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(check.dependenciesReady, false);
    assert(check.blockers.includes('dependency:unverified'));
    assert(check.blockers.every(value => typeof value === 'string' && value.trim().length));
  } finally {
    dependencyModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS malformed blocker entries fail closed with safe diagnostics');

// Expose bounded, actionable integrity diagnostics without changing readiness.
const sourcePath = require.resolve('../tools/windows-source-path-preflight');
const sourceModule = require.cache[sourcePath];
const savedSource = sourceModule.exports;
try {
  sourceModule.exports = { ...savedSource, inspectWindowsSourceLayout: () => ({
    windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'],
    contentMismatchCount: 25,
    contentMismatches: Array.from({ length: 25 }, (_, i) => ({ path: `src/mismatch-${i}.js` })),
    unsafeSourcePaths: ['src/missing.js']
  }) };
  delete require.cache[readinessPath];
  const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
  assert.equal(audit.sourceIntegrityEvidence.contentMismatchCount, 25);
  assert.equal(audit.sourceIntegrityEvidence.mismatchedPaths.length, 20);
  assert.deepEqual(audit.sourceIntegrityEvidence.missingOrUnsafePaths, ['src/missing.js']);
  assert.equal(audit.readyForUserTesting, false);
} finally {
  sourceModule.exports = savedSource;
  delete require.cache[readinessPath];
}
console.log('PASS bounded source integrity mismatch evidence remains diagnostic-only');

// Contradictory integrity counts must fail closed even with a success flag.
for (const evidence of [
  { contentMismatchCount: 1, contentMismatches: [{ path: 'src/a.js' }], unsafeSourcePaths: [] },
  { contentMismatchCount: 0, contentMismatches: [], unsafeSourcePaths: ['src/unsafe.js'] },
  { contentMismatchCount: 0, contentMismatches: [{ path: 'src/a.js' }], unsafeSourcePaths: [] },
  { contentMismatchCount: null, contentMismatches: [], unsafeSourcePaths: [] }
]) {
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: true, blockers: [], ...evidence
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(audit.sourceIntegrityPassed, false);
    assert(audit.blockers.includes('source-integrity:unverified'));
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS contradictory integrity evidence cannot bypass source gate');

// A preflight success without audited manifest coverage, or with unresolved
// path issues, cannot count as authenticated source-integrity evidence.
for (const evidence of [
  { fileCount: 0, issues: [] },
  { fileCount: 10, issues: ['unresolved-source-path'] },
  { fileCount: 10 },
  { fileCount: undefined, issues: [] }
]) {
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: true, blockers: [], fileCount: 10,
      contentMismatchCount: 0, contentMismatches: [], unsafeSourcePaths: [], ...evidence
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(audit.sourceIntegrityPassed, false);
    assert(audit.blockers.includes('source-integrity:unverified'));
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS missing manifest coverage and unresolved path issues fail closed');

// Count and array disagreement must be surfaced, not silently treated as
// a trustworthy diagnostic tally. This does not promote runtime readiness.
for (const [count, paths, expected] of [[2, ['src/a.js'], false], [1, ['src/a.js'], true], [0, [], true]]) {
  const moduleEntry = require.cache[sourcePath];
  const original = moduleEntry.exports;
  try {
    moduleEntry.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'],
      fileCount: 10, issues: [], contentMismatchCount: count,
      contentMismatches: paths.map(path => ({ path })), unsafeSourcePaths: []
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(audit.sourceIntegrityEvidence.mismatchEvidenceConsistent, expected);
    assert.equal(audit.sourceIntegrityPassed, false);
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    moduleEntry.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS mismatched integrity tally is explicitly flagged');

// Duplicate or unsafe mismatch paths are contradictory source evidence.
for (const paths of [['src/a.js', 'src/a.js'], ['../outside.js'], ['C:\\outside.js'], ['/absolute.js'], ['src//bad.js'], ['C:relative.js'], ['src/bad\u0000name.js'], ['src/bad\nname.js']]) {
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'],
      fileCount: 10, issues: [], unsafeSourcePaths: [],
      contentMismatchCount: paths.length, contentMismatches: paths.map(path => ({ path }))
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(audit.sourceIntegrityEvidence.mismatchEvidenceConsistent, false);
    assert.equal(audit.sourceIntegrityPassed, false);
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS duplicate and unsafe mismatch paths invalidate readiness evidence');

// Even a nominally clean upstream result must not bypass strict triage validation.
for (const extra of [
  { issues: ['repeated', 'repeated'] },
  { blockers: ['duplicate', 'duplicate'] },
  { unsafeSourcePaths: ['src/CON.txt'] }
]) {
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: true, blockers: [], fileCount: 10,
      issues: [], unsafeSourcePaths: [], contentMismatchCount: 0,
      contentMismatches: [], ...extra
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.equal(audit.sourceIntegrityPassed, false);
    assert(audit.blockers.includes('source-integrity:unverified') ||
      audit.blockers.some(x => x.startsWith('source-integrity:')));
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS readiness reuses strict source-integrity evidence gate');

// A crashed integrity validator must yield a blocked structured report, not
// terminate the offline readiness command or imply Windows runtime proof.
const triagePath = require.resolve('../tools/source-integrity-triage');
const triageModule = require.cache[triagePath];
const originalTriage = triageModule.exports;
try {
  triageModule.exports = { ...originalTriage, triage: () => { throw new Error('simulated-integrity-validator-crash'); } };
  delete require.cache[readinessPath];
  const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
  assert.equal(audit.sourceIntegrityPassed, false);
  assert(audit.blockers.includes('source-integrity:triage-validator-error'));
  assert.equal(audit.readyForUserTesting, false);
  assert.equal(audit.nativeWindowsRuntimeVerified, false);
} finally {
  triageModule.exports = originalTriage;
  delete require.cache[readinessPath];
}
console.log('PASS crashed source-integrity validator fails closed');

// Malformed source path diagnostics must not leak controls, traversal, or
// oversized strings into reports, even when the preflight itself is blocked.
try {
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'],
      contentMismatchCount: 6,
      contentMismatches: [{path: 'safe/one.js'}, {path: 'bad\nline'}, {path: '../escape'}, {path: 'x'.repeat(513)}, {path: 'C:/absolute.js'}, {path: 'bad:stream.js'}],
      unsafeSourcePaths: ['safe/missing.js', 'bad\x1b[31m', '../escape', 'x'.repeat(513), 'C:/absolute.js', 'bad:stream.js']
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.deepEqual(audit.sourceIntegrityEvidence.mismatchedPaths, ['safe/one.js']);
    assert.deepEqual(audit.sourceIntegrityEvidence.missingOrUnsafePaths, ['safe/missing.js']);
    assert.equal(audit.sourceIntegrityPassed, false);
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
} catch (error) { throw error; }
console.log('PASS unsafe source diagnostic paths omitted from readiness artifacts');

// Invalid entries must not consume the bounded diagnostic budget.
{
  const sourceModule = require.cache[sourcePath];
  const original = sourceModule.exports;
  try {
    sourceModule.exports = { ...original, inspectWindowsSourceLayout: () => ({
      windowsSourcePathsSafe: false, blockers: ['source-manifest-content-mismatch'],
      contentMismatchCount: 22,
      contentMismatches: [...Array.from({length: 21}, (_, i) => ({path: `../invalid-${i}`})), {path: 'safe/last.js'}],
      unsafeSourcePaths: [...Array.from({length: 21}, (_, i) => `../invalid-${i}`), 'safe/last-missing.js']
    }) };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    assert.deepEqual(audit.sourceIntegrityEvidence.mismatchedPaths, ['safe/last.js']);
    assert.deepEqual(audit.sourceIntegrityEvidence.missingOrUnsafePaths, ['safe/last-missing.js']);
    assert.equal(audit.sourceIntegrityPassed, false);
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    sourceModule.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS invalid diagnostic entries cannot exhaust safe evidence budget');

// Exceptions from preflights must never leak terminal controls or arbitrary
// message text into readiness reports, even when a checker throws.
for (const injected of [
  Object.assign(new Error('\x1b[31msecret\n'), { code: 'BAD\nCODE' }),
  new Error('private path /home/operator/secret'),
  Object.assign(new Error('hidden'), { code: 'EACCES' })
]) {
  const modulePath = require.resolve('../tools/windows-dependency-preflight');
  const entry = require.cache[modulePath];
  const original = entry.exports;
  try {
    entry.exports = { ...original, inspectWindowsDependencyLock: () => { throw injected; } };
    delete require.cache[readinessPath];
    const audit = require('../tools/windows-dev-readiness').inspectWindowsDevReadiness();
    const expected = injected.code === 'EACCES' ? 'EACCES' : 'UNKNOWN';
    assert(audit.blockers.includes(`dependency:preflight-error:${expected}`));
    assert(!JSON.stringify(audit).includes(injected.message));
    assert.equal(audit.readyForUserTesting, false);
  } finally {
    entry.exports = original;
    delete require.cache[readinessPath];
  }
}
console.log('PASS preflight exceptions are bounded and redacted');
