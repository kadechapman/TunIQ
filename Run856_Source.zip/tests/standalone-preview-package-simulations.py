#!/usr/bin/env python3
"""Actual offline ZIP/PE package mutation tests; never runs Windows or ECU."""
import shutil
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parent.parent
TOOL = ROOT / 'tools' / 'package-standalone-preview.py'
EXE = 'TunIQ_Standalone_Offline_Preview.exe'
ZIP = 'TunIQ_Standalone_Offline_Preview.zip'

def run(folder, success):
    p = subprocess.run([sys.executable, str(TOOL), 'verify', str(folder)], capture_output=True, text=True, timeout=30)
    assert (p.returncode == 0) == success, (p.returncode, p.stdout, p.stderr)
    return p

def main(original):
    original = Path(original)
    assert run(original, True).returncode == 0
    print('PASS original package roundtrip and PE/import/HTML proof')
    with tempfile.TemporaryDirectory(prefix='tuniq-zip-negative-') as temp:
        temp = Path(temp)
        def reset():
            for f in temp.iterdir(): f.unlink()
            for name in (EXE, 'TunIQ_Offline_Preview.html', 'static-verification.json', ZIP, ZIP+'.sha256'):
                shutil.copy2(original / name, temp / name)
        reset()
        with (temp / EXE).open('r+b') as f:
            f.seek(3000); b = f.read(1); f.seek(3000); f.write(bytes([b[0] ^ 1]))
        run(temp, False)
        print('PASS modified PE rejected before ZIP approval')
        reset()
        with zipfile.ZipFile(temp / ZIP, 'a') as z:
            z.writestr('UNREVIEWED.txt', 'unexpected')
        run(temp, False)
        print('PASS unreviewed ZIP extra entry rejected')
        reset()
        with (temp / ZIP).open('r+b') as f:
            f.seek(120); b = f.read(1); f.seek(120); f.write(bytes([b[0] ^ 1]))
        run(temp, False)
        print('PASS corrupted ZIP rejected')
        reset()
        (temp / (ZIP+'.sha256')).write_text('0'*64+'  '+ZIP+'\n')
        run(temp, False)
        print('PASS wrong ZIP checksum rejected')
        reset()
        # Same bytes and checksum, but mark the HTML as a Unix symlink in ZIP metadata.
        archive = temp / ZIP
        with zipfile.ZipFile(archive, 'r') as source:
            entries = [(item, source.read(item)) for item in source.infolist()]
        with zipfile.ZipFile(archive, 'w') as target:
            for info, data in entries:
                if info.filename == 'TunIQ_Offline_Preview.html':
                    info.external_attr = 0o120777 << 16
                    info.create_system = 3
                target.writestr(info, data)
        (temp / (ZIP+'.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+ZIP+'\n')
        run(temp, False)
        print('PASS ZIP symlink metadata rejected despite matching bytes/checksum')
        reset()
        # An attacker can update the checksum after adding a ZIP comment;
        # prior versions accepted this unreviewed payload as verified.
        archive = temp / ZIP
        with zipfile.ZipFile(archive, 'a') as z:
            z.comment = b'UNREVIEWED ZIP COMMENT'
        (temp / (ZIP+'.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+ZIP+'\n')
        run(temp, False)
        print('PASS unreviewed ZIP comment rejected even with updated checksum')
        reset()
        # Extra per-entry metadata is similarly not part of the reviewed ZIP.
        archive = temp / ZIP
        with zipfile.ZipFile(archive, 'r') as source:
            entries = [(item, source.read(item)) for item in source.infolist()]
        with zipfile.ZipFile(archive, 'w') as target:
            for info, data in entries:
                if info.filename == 'READ_ME_FIRST.txt':
                    info.extra = b'ZZ\x04\x00ABCD'
                target.writestr(info, data)
        (temp / (ZIP+'.sha256')).write_text(hashlib.sha256(archive.read_bytes()).hexdigest()+'  '+ZIP+'\n')
        run(temp, False)
        print('PASS unreviewed ZIP extra field rejected even with updated checksum')
        reset()
        (temp / 'static-verification.json').write_text('{}')
        run(temp, False)
        print('PASS stale static proof rejected')
    print('STANDALONE_PACKAGE_ACTUAL_FIXTURES 9/9 PASS (not native Windows runtime)')

if __name__ == '__main__':
    if len(sys.argv) != 2: raise SystemExit('usage: standalone-preview-package-simulations.py BUILT_OUTPUT_DIR')
    main(sys.argv[1])
