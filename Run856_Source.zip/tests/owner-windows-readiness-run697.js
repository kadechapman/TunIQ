'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const reviewerPath = require.resolve('../src/p01-request-review');
const readinessPath = require.resolve('../tools/owner-windows-readiness-run687');
const reviewer = require(reviewerPath);
const original = reviewer.reviewP01Request;
const root = path.resolve(__dirname, '..');
try {
  for (const malformed of [
    { ready: true, unresolvedRequests: [{ type: '' }], missingSafetyFacts: [] },
    { ready: true, unresolvedRequests: [{ type: '   ' }], missingSafetyFacts: [] },
    { ready: true, unresolvedRequests: [], missingSafetyFacts: [''] },
    { ready: true, unresolvedRequests: [], missingSafetyFacts: ['   '] }
  ]) {
    reviewer.reviewP01Request = () => malformed;
    delete require.cache[readinessPath];
    const { inspect, exitCodeFor } = require(readinessPath);
    const result = inspect(root, { controller: 'P01' }, 'test');
    assert.equal(result.owner.requestReviewReady, false);
    assert.match(result.owner.reviewError, /invalid result/);
    assert.equal(result.owner.ready, false);
    assert.equal(result.ecmWriteAuthorized, false);
    assert.equal(result.readyForUserTesting, false);
    assert.equal(exitCodeFor(result), 2);
  }
  process.stdout.write('PASS Run697: four malformed review fixtures, six safety assertions each (24 assertions)\n');
} finally {
  reviewer.reviewP01Request = original;
  delete require.cache[readinessPath];
}
