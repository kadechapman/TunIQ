const assert = require('assert');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function readFileGuardedMissingParent(root) {
  const { checkUnusedReadDestination } = require('../src/read-output-safety');
  const missing = path.join(root, '.tuniq-definitely-not-created-parent', 'read.bin');
  return checkUnusedReadDestination(missing).code === 'read-output-unavailable';
}

function runReleasePromotionSimulations() {
  const root = path.join(__dirname, '..');
  const version = JSON.parse(fs.readFileSync(path.join(root, 'VERSION.json'), 'utf8'));
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'src', 'renderer', 'index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(root, 'src', 'renderer', 'app.js'), 'utf8');

  assert.equal(version.version, '1.9.0-beta.108');
  assert.equal(version.channel, 'beta');
  assert.equal(version.name, 'Structured Read Integrity Status Guard');
  assert.equal(version.release, 'Source-only Development Checkpoint');
  assert.equal(pkg.version, '1.9.0-beta.108');
  const gitignore = fs.readFileSync(path.join(root, '.gitignore'), 'utf8');
  assert(/^private-hardware-evidence\/\s*$/m.test(gitignore), 'private hardware evidence must be excluded from source control');
  const releaseWorkflow = fs.readFileSync(path.join(root, '.github', 'workflows', 'windows-public-beta.yml'), 'utf8');
  assert(!/\bpush\s*:/m.test(releaseWorkflow), 'no tag push may automatically trigger public release');
  assert(!/gh release create|electron-builder|npm run dist:win/.test(releaseWorkflow),
    'unqualified source-only CI must not build or publish a flash-capable installer');
  assert(/contents:\s*read/.test(releaseWorkflow), 'CI must have read-only repository permissions');
  assert(/npm ci\b/.test(releaseWorkflow), 'CI must require a committed dependency lockfile');
  assert(!/npm install\b/.test(releaseWorkflow), 'CI must not silently resolve unlocked dependencies');

  assert.equal(pkg.build.appId, 'com.tuniq.desktop', 'stable promotion must preserve the installed app identity');
  assert.equal(pkg.build.nsis.deleteAppDataOnUninstall, false, 'project data must remain protected during uninstall/update');
  assert(main.includes("const VERSION_INFO = require('../VERSION.json');"));
  assert(main.includes('const APP_VERSION = VERSION_INFO.version'), 'runtime version must derive from release metadata instead of another hard-coded version');
  const connectionManager = fs.readFileSync(path.join(root, 'src', 'intelligent-connection-manager.js'), 'utf8');
  const flash = fs.readFileSync(path.join(root, 'src', 'flash.js'), 'utf8');
  const deviceLease = fs.readFileSync(path.join(root, 'src', 'pcmhammer-device-lease.js'), 'utf8');
  assert(connectionManager.includes('connection-broker-adapter-verified'));
  assert(connectionManager.includes('connection-broker-bluetooth-repair'));
  assert(main.includes("p01-auto:bluetooth-repair"));
  assert(main.includes("p01-auto:manual-pcmhammer-handoff"));
  assert(main.includes('pcmHammerProvenPort'));
  assert(main.includes('recoverP01ProvenHardwareSession'));
  assert(main.includes('releaseVirtualAdapterBeforeP01Operation'));
  assert(main.includes('provenHardwareSession'));
  assert(html.includes('id="betaOverallProgress"'));
  assert(html.includes('id="launchReadinessState"'));
  assert(renderer.includes('function renderLaunchReadiness'));
  assert(main.includes("launch:get-readiness"));
  assert(renderer.includes('function renderBetaProgress'));
  assert(connectionManager.includes('attempted.has(candidate.port)'));
  assert(flash.includes("['readProperties','read','testWrite','writeCalibration','writeFull','recovery']"));
  assert(flash.includes('verified-adapter-connection-broker'));
  assert(flash.includes('prepareExclusivePcmHammerLane'));
  assert(flash.includes('this.externalPortAccessPending'), 'external Bluetooth/manual COM lease must block PCM Hammer start');
  assert(flash.includes("withExclusiveExternalPortAccess('PCM Hammer CLI probe'"), 'CLI probe must reserve exclusive admission without cancelling a read');
  assert(main.includes("withExclusiveExternalPortAccess('Bluetooth SPP repair'"), 'Bluetooth repair must reserve exclusive serial access');
  assert(main.includes("withExclusiveExternalPortAccess('Manual OBDLink port verification'"), 'manual port verification must reserve exclusive serial access');
  assert(main.includes('createObdIpcAdmission(flashManager, obdManager)'), 'OBD IPC serial admission must be wired into Electron main');
  assert(main.includes("obdIpcAdmission.disconnect()"), 'OBD disconnect must not bypass COM admission');
  const obd = fs.readFileSync(path.join(root, 'src', 'obd.js'), 'utf8');
  assert(obd.includes('await this.serialSession.close()'), 'OBD disconnect must await persistent child exit');
  assert(obd.includes('this.assertBridgeExited'), 'bridge process exit must be confirmed before COM handoff');
  assert(flash.includes('bridge.pendingExit'), 'proven PCM Hammer lane must refuse pending bridge exit');
  assert(flash.includes('this.startPending'), 'concurrent PCM Hammer start admission guard must be present');
  assert(flash.includes('session.childProcessError'), 'child error must not prematurely release PCM Hammer COM ownership');
  assert(flash.includes('CLI exit text alone is not proof of a valid backup'), 'Full Read success metadata must be proof gated');
  const pcm = fs.readFileSync(path.join(root, 'src', 'pcmhammer.js'), 'utf8');
  assert(pcm.includes('sameReadParents'), 'Full Read backup parent identity must be verified');
  assert(pcm.includes('result.success !== true'), 'Full Read validation must reject absent or non-boolean CLI success evidence');
  assert(pcm.includes('const okExit = exitCode === 0;'), 'PCM Hammer must reject missing or signal-terminated process exit status');
  assert(pcm.includes('kernelTransferFailure'), 'kernel transfer failure guard from beta.102 must remain');
  assert(pcm.includes('readIntegrityFailure'), 'Full Read classifier must reject CRC/checksum integrity failure');
  assert(pcm.includes('hasReadIntegrityFailure(source)'), 'read-only evidence must use shared integrity-error detection');
  assert(pcm.includes('hasReadUnitFailure(source)'), 'read-only evidence must reject failed memory sectors/pages');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('hasReadUnitFailure(source)'), 'CLI retries must share memory-unit failure detection');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('hasReadIntegrityFailure(source)'), 'syntax retries must share read-integrity failure detection');
  assert(fs.readFileSync(path.join(root, 'tests', 'run-tests.js'), 'utf8').includes('runPcmHammerExitProofSimulations();'), 'exit-proof regression must run in the complete test suite');
  assert(fs.readFileSync(path.join(root, 'tests', 'run-tests.js'), 'utf8').includes('runPcmHammerRetryExitProofSimulations();'), 'retry-exit regression must run in the complete suite');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('!Number.isSafeInteger(exitCode) || exitCode <= 0 || exitCode > 255'), 'ambiguous child exit cannot trigger CLI profile retry');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('checkUnusedReadDestination(output)'), 'Full Read CLI profile fallback must revalidate the unused output destination');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('if (!explicitSyntaxRejection) return false;'), 'generic usage footer must not permit CLI profile retry');
  assert(fs.readFileSync(path.join(root, 'src', 'pcmhammer-integrated.js'), 'utf8').includes('hasSerialPortOpenedProof(source)'), 'opened serial handle must prevent syntax-only fallback');
  assert(readFileGuardedMissingParent(root), 'missing Full Read parent directories must fail closed');
  assert(fs.readFileSync(path.join(root, 'tests', 'run-tests.js'), 'utf8').includes('runPcmHammerRetrySyntaxProofSimulations();'), 'syntax-proof regression must run in the complete suite');
  assert(pcm.includes('checkSafeReadPath(file)'), 'existing Full Read files must enforce Win32 path safety before filesystem IO');
  const readPathSafety = fs.readFileSync(path.join(root, 'src', 'read-output-safety.js'), 'utf8');
  assert(readPathSafety.includes('function checkSafeReadPath(output)'), 'shared existing-read path safety policy must remain available');
  const readinessSource = fs.readFileSync(path.join(root, 'src', 'launch-readiness.js'), 'utf8');
  assert(readinessSource.includes('sameEvidenceDirectoryChain(root, rootChain)'), 'private hardware evidence must recheck ancestor identities');
  const commissioning = fs.readFileSync(path.join(root, 'src', 'p01-commissioning.js'), 'utf8');
  assert(commissioning.includes('actual.sha256 !== info.sha256.toLowerCase()'), 'commissioning must bind imported BIN digest to earlier Full Read proof');
  assert(commissioning.includes('no-proven-independent-matching-pair'), 'disk-only BIN names cannot self-certify as two ECU reads');
  assert(commissioning.includes('directReadEvidenceFile(file)'), 'commissioning must reject linked read files before ledger admission');
  assert(commissioning.includes('checkSafeReadPath(file).ok'), 'commissioning must reject Win32 backup aliases at ledger admission and recovery');
  assert(commissioning.includes('independentReadFiles(pair.first.path, record.path)'), 'second read must prove separate physical-file identity before verification');
  assert(commissioning.includes('independentReadFiles(first.path, second.path)'), 'saved read-pair repair must reject file aliases');
  assert(commissioning.includes('verifiedPairEvidenceIntact(pair, identity.fingerprint)'), 'verified read-pair status must recheck live file evidence');
  assert(flash.includes('assertAssistedEvidenceAllowed'), 'restricted beta must block unverified assisted/manual evidence');
  assert(flash.includes('read-only-beta-assisted-evidence-blocked'), 'assisted evidence must fail closed in read-only beta');
  assert(main.includes('flashManager.assertAssistedEvidenceAllowed();'), 'IPC must block assisted import before the file picker');
  assert(flash.includes('deviceSpec'));
  assert(deviceLease.includes('proven-obdlink-elm-type-pin'));
  assert(deviceLease.includes('`${normalized}:elm`'));
  assert(deviceLease.includes('function safeTypedDeviceFallback('), 'typed COM fallback must have a dedicated fail-closed exit guard');
  assert(deviceLease.includes('!Number.isSafeInteger(exitCode) || exitCode <= 0 || exitCode > 255'), 'typed COM fallback must reject ambiguous/signal exits');
  assert(deviceLease.includes('typedPorts.some(port => port.toUpperCase() !== expected)'), 'typed fallback must reject diagnostics for a different COM port');
  assert(deviceLease.includes('mentionedPorts.some(port =>'), 'typed fallback must reject conflicting untyped COM references');
  assert(flash.includes('safeTypedDeviceFallback({ operation: session.operation, text: attemptText, exitCode: code, deviceSpec: session.deviceSpec, output: session.output })'), 'typed fallback must pass device identity and exact output');
  assert(flash.includes("['read', 'readProperties'].includes(session.operation) && session.state !== 'complete'"), 'read-only final result success must agree with admitted session state');
  assert(deviceLease.includes('checkUnusedReadDestination(output).ok'), 'typed Full Read fallback must recheck the unused backup path');
  assert(fs.readFileSync(path.join(root, 'tests', 'run-tests.js'), 'utf8').includes('runPcmHammerTypedFallbackExitSimulations();'), 'typed COM fallback regression must run in the complete suite');
  assert(main.includes("path.join(app.getPath('appData'), 'TunIQ')"), '1.8 must reuse the existing AppData project root');
  assert(html.includes('Continue / Finish P01 Setup'));
  assert(!html.includes('Start Guided Automatic P01 Setup'));
  assert(html.includes('id="p01AutoResume" type="button" class="ghost hidden"'), 'legacy resume control must not be a normal-path action');
  assert(renderer.includes("resumeReady?`Resume ${p01AutoPhaseLabel(phase).replace(/^Preparing /,'')}`:stopped&&recoveredAtFinalStep?'Retry Failed Test Write':'Continue / Finish P01 Setup'"));
  assert(renderer.includes('Verified reads recovered — continuing at Test Write.'));
  assert(renderer.includes('it will not perform an actual PCM write'));
  assert(renderer.includes("commissioned?'SETUP COMPLETE':written?'WRITE COMPLETE'"));

  // Prove a beta.27-era project with good files and a damaged ledger promotes without rereading.
  const projectRoot = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-180-promotion-'));
  try {
    const active = { id: 'customline', name: 'Customline', controller: 'P01', os: '9379910', folder: projectRoot };
    const imports = path.join(projectRoot, 'Imports', 'PCM-Hammer');
    fs.mkdirSync(imports, { recursive: true });
    const first = path.join(imports, 'P01-Read-session-a-p01_origin_read1.bin');
    const second = path.join(imports, 'P01-Read-session-b-p01_origin_read2.bin');
    fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x71));
    fs.writeFileSync(second, Buffer.alloc(P01_BIN_SIZE, 0x71));
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: '4294967295', serviceNumber: '9354896' });
    manager.recordRead(first, {}, { id: 'read-session-a', device: 'COM3', proofSource: 'read-session-a' });
    manager.recordRead(second, {}, { id: 'read-session-b', device: 'COM3', proofSource: 'read-session-b' });
    const damaged = manager.load();
    damaged.readPair = null;
    delete damaged.canonicalReadSha256;
    delete damaged.canonicalReadPath;
    delete damaged.dualReadVerifiedAt;
    manager.save(damaged);
    const recovered = manager.repairVerifiedReadPair('1.8 release promotion simulation');
    assert.equal(recovered.repaired, true);
    assert.equal(recovered.status.dualReadVerified, true);
    assert.equal(recovered.status.identity.os, '9379910');
    const extra = path.join(imports, 'P01-Read-unnecessary-third.bin');
    fs.writeFileSync(extra, Buffer.alloc(P01_BIN_SIZE, 0x19));
    const result = manager.recordRead(extra, { proofSource: '1.8 repeated click simulation' }, { id: 'extra-session', device: 'COM3' });
    assert.equal(result.continuityLocked, true);
    assert.equal(manager.status().canonicalReadSha256, recovered.status.canonicalReadSha256);
  } finally {
    fs.rmSync(projectRoot, { recursive: true, force: true });
  }

  console.log('✓ TunIQ 1.9.0-beta.108 structured read integrity status guard promotion: launch gate, single version authority, PCM Hammer exclusive COM ownership, and evidence-based readiness percentages');
  return { passed: true, scenarios: 3 };
}

if (require.main === module) runReleasePromotionSimulations();
module.exports = { runReleasePromotionSimulations };
