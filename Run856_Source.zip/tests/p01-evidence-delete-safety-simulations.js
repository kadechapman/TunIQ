'use strict';
// Local temporary-directory regression only. No ECU or serial hardware access.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01EvidenceManager } = require('../src/p01-evidence');

function runP01EvidenceDeleteSafetySimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-evidence-delete-'));
  let passed = 0;
  try {
    const data = path.join(root, 'data');
    const manager = new P01EvidenceManager({ dataRoot: () => data, getActiveProject: () => null });
    const evidenceRoot = manager.root();
    const importsRoot = path.join(evidenceRoot, 'Imported');
    fs.mkdirSync(importsRoot, { recursive: true });
    const outside = path.join(root, 'outside');
    fs.mkdirSync(outside);
    const sentinel = path.join(outside, 'keep.txt');
    fs.writeFileSync(sentinel, 'never delete outside the import root');
    const setIndex = items => fs.writeFileSync(manager.indexFile(), JSON.stringify(items));

    // Regression: persisted normalizedPath is editable JSON metadata, not an
    // authority to choose a directory for recursive deletion.
    const safeId = '1234567890123-normal-log';
    const owned = path.join(importsRoot, safeId);
    fs.mkdirSync(owned);
    fs.writeFileSync(path.join(owned, 'evidence.json'), '{}');
    setIndex([{ id: safeId, normalizedPath: sentinel }]);
    manager.deleteImport(safeId);
    assert.equal(fs.existsSync(sentinel), true, 'external sentinel must survive forged normalizedPath'); passed++;
    assert.equal(fs.existsSync(owned), false, 'only the owned import directory is removed'); passed++;
    assert.equal(manager.imports().length, 0, 'successful deletion updates the index'); passed++;

    // A forged id must not escape Imported using traversal or separators.
    const traversal = '../outside';
    setIndex([{ id: traversal, normalizedPath: null }]);
    assert.throws(() => manager.deleteImport(traversal), /unsafe|invalid|outside|path/i);
    assert.equal(fs.existsSync(sentinel), true, 'traversal cannot delete a sibling directory'); passed++;
    assert.equal(manager.imports().length, 1, 'rejected deletion must retain its record'); passed++;

    // A missing owned directory may be cleaned from the index without
    // touching any unrelated files.
    setIndex([{ id: '1234567890123-missing', normalizedPath: sentinel }]);
    manager.deleteImport('1234567890123-missing');
    assert.equal(manager.imports().length, 0); passed++;
    assert.equal(fs.existsSync(sentinel), true); passed++;

    // If filesystem deletion fails, retain the evidence index for recovery.
    const blockedId = '1234567890123-blocked';
    const blockedFolder = path.join(importsRoot, blockedId);
    fs.mkdirSync(blockedFolder);
    setIndex([{ id: blockedId }]);
    const originalRm = fs.rmSync;
    try {
      fs.rmSync = function (target, ...args) {
        if (target === blockedFolder) throw Object.assign(new Error('simulated permission denied'), { code: 'EPERM' });
        return originalRm.call(fs, target, ...args);
      };
      assert.throws(() => manager.deleteImport(blockedId), /permission denied/i);
    } finally { fs.rmSync = originalRm; }
    assert.equal(manager.imports().length, 1, 'failed filesystem deletion must not drop the index'); passed++;
    assert.equal(fs.existsSync(blockedFolder), true); passed++;

    // A symlink/junction cannot redirect the import root or a stored item.
    const redirected = path.join(root, 'redirected');
    fs.mkdirSync(redirected);
    fs.writeFileSync(path.join(redirected, 'keep.txt'), 'keep');
    const linkedId = '1234567890123-linked';
    const linkedFolder = path.join(importsRoot, linkedId);
    try {
      fs.symlinkSync(redirected, linkedFolder, process.platform === 'win32' ? 'junction' : 'dir');
      setIndex([{ id: linkedId }]);
      assert.throws(() => manager.deleteImport(linkedId), /symlink|junction|unsafe|redirect/i);
      assert.equal(fs.existsSync(path.join(redirected, 'keep.txt')), true); passed++;
      assert.equal(manager.imports().length, 1); passed++;
      fs.unlinkSync(linkedFolder);
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }
    // The Imported directory itself must not be a redirected junction.
    const parkedImports = path.join(evidenceRoot, 'Imported-parked');
    fs.renameSync(importsRoot, parkedImports);
    try {
      try {
        fs.symlinkSync(redirected, importsRoot, process.platform === 'win32' ? 'junction' : 'dir');
        setIndex([{ id: '1234567890123-root-link' }]);
        assert.throws(() => manager.deleteImport('1234567890123-root-link'), /redirect|symlink|unsafe/i);
        assert.equal(fs.existsSync(path.join(redirected, 'keep.txt')), true); passed++;
        assert.equal(manager.imports().length, 1); passed++;
      } catch (error) {
        if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      }
    } finally {
      try { fs.unlinkSync(importsRoot); } catch (error) { if (error.code !== 'ENOENT') throw error; }
      fs.renameSync(parkedImports, importsRoot);
    }
    if (!quiet) console.log(`✓ P01 evidence delete containment: ${passed} local-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runP01EvidenceDeleteSafetySimulations();
module.exports = { runP01EvidenceDeleteSafetySimulations };
