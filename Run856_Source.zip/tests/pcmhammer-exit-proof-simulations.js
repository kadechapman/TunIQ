'use strict';
// Synthetic CLI classifier regression only: never launches PCM Hammer or opens a COM port.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { classifyPcmHammerResult, validateP01ReadFile, P01_BIN_SIZE } = require('../src/pcmhammer');

function runPcmHammerExitProofSimulations() {
  let passed = 0;
  const completedLog = 'Read entire PCM complete';
  for (const [code, expected] of [
    [null, false], [undefined, false], ['0', false], [NaN, false], [1, false], [0, true]
  ]) {
    const classified = classifyPcmHammerResult('read', completedLog, code);
    assert.strictEqual(classified.success, expected,
      `Full Read with exit ${String(code)} must ${expected ? 'succeed' : 'fail'} despite a completion line`);
    assert.strictEqual(classified.okExit, expected);
    if (!expected) assert.strictEqual(classified.stopCode, 'pcmhammer-failed');
    passed++;
  }
  const properties = 'PCM Hammer 2.0\nOSID: 9379910';
  assert.strictEqual(classifyPcmHammerResult('readProperties', properties, null).success, false,
    'missing child exit status cannot certify Read Properties'); passed++;
  assert.strictEqual(classifyPcmHammerResult('readProperties', properties, 0).success, true,
    'normal numeric zero exit still permits genuine completed Read Properties evidence'); passed++;

  // A CLI may print a success footer after reporting missing kernels. It
  // must not certify Read Properties or a Full Read on a nominal exit 0.
  for (const [operation, completion] of [
    ['read', 'Read completed successfully'],
    ['readProperties', 'OSID: 9379910']
  ]) {
    const conflicting = classifyPcmHammerResult(operation,
      `No .bin kernel files found\n${completion}`, 0);
    assert.strictEqual(conflicting.stopCode, 'kernel-files-missing');
    assert.strictEqual(conflicting.success, false,
      `${operation}: kernel failure must override completion evidence`);
    passed++;
  }

  // Kernel transfer failure is fatal even when the CLI prints a success
  // footer or an OSID and exits zero. No COM port or hardware is involved.
  for (const [operation, diagnostic, footer] of [
    ['read', 'Failed to upload kernel', 'Read completed successfully'],
    ['read', 'Kernel upload failed', 'Read completed successfully'],
    ['read', 'Failed to execute kernel', 'Read completed successfully'],
    ['readProperties', 'Kernel load failed', 'OSID: 9379910'],
    ['readProperties', 'Error loading kernel', 'OSID: 9379910'],
    ['read', 'Kernel transfer timed out', 'Read completed successfully'],
    ['read', 'Kernel handshake failed', 'Read completed successfully'],
    ['read', 'Kernel upload: false', 'Read completed successfully'],
    ['read', 'Kernel transfer status: failed', 'Read completed successfully'],
    ['readProperties', 'Loader execution: false', 'OSID: 9379910'],
    ['readProperties', 'Kernel handshake: false', 'OSID: 9379910']
  ]) {
    const result = classifyPcmHammerResult(operation, `${diagnostic}\n${footer}`, 0);
    assert.strictEqual(result.kernelTransferFailure, true, `${diagnostic}: kernel transfer failure must be detected`);
    assert.strictEqual(result.success, false, `${diagnostic}: contradictory success evidence must be rejected`);
    assert.strictEqual(result.stopCode, 'kernel-transfer-failed');
    passed++;
  }
  // Numeric kernel statuses have no cross-version boolean/exit-code meaning.
  // An unqualified numeric result cannot certify a Full Read or OS identity.
  for (const [operation, diagnostic, footer] of [
    ['read', 'Kernel upload: 0', 'Read completed successfully'],
    ['read', 'Kernel upload status: 0', 'Read completed successfully'],
    ['read', 'Kernel upload: 1', 'Read completed successfully'],
    ['read', 'Kernel handshake: 0x00', 'Read completed successfully'],
    ['readProperties', 'Loader execution: 1', 'OSID: 9379910'],
    ['readProperties', 'Kernel transfer result = -1', 'OSID: 9379910']
  ]) {
    const result = classifyPcmHammerResult(operation, `${diagnostic}\n${footer}`, 0);
    assert.strictEqual(result.kernelTransferFailure, true, `ambiguous numeric kernel status must block: ${diagnostic}`);
    assert.strictEqual(result.success, false, `numeric status cannot certify ${operation}: ${diagnostic}`);
    assert.strictEqual(result.stopCode, 'kernel-transfer-failed');
    passed++;
  }
  for (const positive of ['Kernel upload completed', 'Kernel upload: true', 'Loader execution: success']) {
    assert.strictEqual(classifyPcmHammerResult('read',
      `${positive}\nRead completed successfully`, 0).success, true,
      `ordinary successful kernel status must not be rejected: ${positive}`); passed++;
  }

  // ANSI SGR colors may split fatal diagnostics. Unknown control escapes
  // are ambiguous CLI evidence, not permission to accept a backup.
  for (const [operation, diagnostic, footer, expectedCode] of [
    ['read', 'CRC \x1b[31merrors: 2\x1b[0m', 'Read completed successfully', 'read-integrity-failed'],
    ['read', 'Checksum \x1b[1;31mverification failed\x1b[0m', 'Read completed successfully', 'read-integrity-failed'],
    ['read', 'Kernel upload: \x1b[31mfalse\x1b[0m', 'Read completed successfully', 'kernel-transfer-failed'],
    ['readProperties', 'Kernel \x1b[31mhandshake failed\x1b[0m', 'OSID: 9379910', 'kernel-transfer-failed'],
    ['read', 'Read \x1b[31mcompleted: false\x1b[0m', 'Read completed successfully', 'read-incomplete'],
    ['read', 'Opened serial port COM4\n\x1b[?25l', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    // Backspace/NUL/DEL can conceal a fatal counter or alter rendered output.
    ['read', 'CRC err\x08ors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'CRC err\x00ors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['readProperties', 'OSID: 9379910\n\x7f', 'OSID: 9379910', 'cli-diagnostic-unrecognized-escape'],
    // A standalone CR can split an error keyword or overwrite a progress line.
    ['read', 'CRC err\rors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'Kernel upl\road: false', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['readProperties', 'OSID: 9379910\rProgress', 'OSID: 9379910', 'cli-diagnostic-unrecognized-escape'],
    // Invisible Unicode format controls and Unicode line separators can split
    // fatal words without any ASCII control byte. Do not trust the footer.
    ['read', 'CRC err\u200bors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'Kernel upl\u202eoad: false', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'CRC err\u2028ors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['readProperties', 'OSID: 9379910\ufeff', 'OSID: 9379910', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'CRC err\u034fors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape'],
    ['read', 'CRC err\ufe0fors: 2', 'Read completed successfully', 'cli-diagnostic-unrecognized-escape']
  ]) {
    const result = classifyPcmHammerResult(operation, `${diagnostic}\n${footer}`, 0);
    assert.strictEqual(result.success, false, `${operation} must reject colored/unknown diagnostic ${JSON.stringify(diagnostic)}`);
    assert.strictEqual(result.stopCode, expectedCode);
    passed++;
  }
  for (const [diagnostic, footer] of [
    ['CRC \x1b[32merrors: 0\x1b[0m', 'Read completed successfully'],
    ['Kernel upload: \x1b[32mtrue\x1b[0m', 'Read completed successfully'],
    ['CRC errors: 0\r\n', 'Read completed successfully'],
    ['Read status — complete', 'Read completed successfully']
  ]) {
    assert.strictEqual(classifyPcmHammerResult('read', `${diagnostic}\n${footer}`, 0).success, true,
      'well-formed ANSI colors around clean statuses must not produce false failures');
    passed++;
  }
  // A nominal exit 0 and completion footer cannot override explicit data
  // integrity errors. These are synthetic CLI messages, not hardware proof.
  for (const diagnostic of [
    'CRC mismatch on block 128',
    'Checksum verification failed',
    'Invalid CRC detected',
    'Hash mismatch during read verification'
  ]) {
    const classified = classifyPcmHammerResult('read',
      `Read completed successfully\n${diagnostic}`, 0);
    assert.strictEqual(classified.success, false,
      `read-integrity diagnostic must override CLI success: ${diagnostic}`);
    assert.strictEqual(classified.stopCode, 'read-integrity-failed');
    passed++;
  }
  // Nonzero error counters and natural-language mismatch diagnostics must
  // override a later successful footer, even without a literal 'CRC mismatch'.
  for (const diagnostic of [
    'CRC errors: 2',
    'Hash mismatches: 3',
    'CRC does not match expected value',
    'Checksum did not match the received data',
    // Some CLI builds zero-pad counters; 0002 still means two bad checks.
    'CRC errors: 02',
    'Checksum failures: 0002',
    'Hash mismatches: 0003',
    '0004 CRC errors',
    // Some wrappers format error counters in hexadecimal. Nonzero is fatal.
    'CRC errors: 0x02',
    'Checksum failures: 0x0A',
    'Hash mismatches: 0X10',
    '0x0F CRC errors',
    // Signed, binary and malformed counters must fail closed.
    'CRC errors: +2',
    'Checksum failures: -1',
    'Hash mismatches: 0b10',
    'CRC errors: 0xG2',
    'CRC errors:',
    'CRC errors: 0; Hash mismatches: +2',
    'CRC errors: 0; Checksum failures: -1',
    '+3 CRC errors',
    '-2 Hash mismatches'
  ]) {
    const classified = classifyPcmHammerResult('read',
      `${diagnostic}\nRead completed successfully`, 0);
    assert.strictEqual(classified.success, false,
      `explicit integrity failure must reject Full Read: ${diagnostic}`);
    assert.strictEqual(classified.stopCode, 'read-integrity-failed');
    passed++;
  }
  const hexFailedProperties = classifyPcmHammerResult('readProperties',
    'OSID: 9379910\nCRC errors: 0x02', 0);
  assert.strictEqual(hexFailedProperties.success, false,
    'hexadecimal integrity failures cannot certify Read Properties identity'); passed++;
  assert.strictEqual(hexFailedProperties.stopCode, 'read-integrity-failed'); passed++;
  const failedProperties = classifyPcmHammerResult('readProperties',
    'OSID: 9379910\nCRC errors: 2', 0);
  assert.strictEqual(failedProperties.success, false,
    'Read Properties identity cannot be accepted alongside explicit integrity failures'); passed++;
  assert.strictEqual(failedProperties.stopCode, 'read-integrity-failed'); passed++;
  for (const diagnostic of ['CRC errors: 0', 'CRC errors: 000', 'Hash mismatches: 0', '0 CRC errors', '0000 CRC errors', 'CRC errors: 0x00', 'Hash mismatches: 0X0000', '0x00 CRC errors', 'CRC errors: +0', 'CRC errors: 0b000', 'Hash mismatches: none', '+0 CRC errors', 'CRC errors: 0; Hash mismatches: 0']) {
    const result = classifyPcmHammerResult('read',
      `${diagnostic}\nRead completed successfully`, 0);
    assert.strictEqual(result.success, true,
      `zero integrity-error counters must not be mistaken for failures: ${diagnostic}`);
    passed++;
  }
  // Some CLI variants use structured status fields, e.g. "CRC check: FAILED".
  // Beta.107 admitted a successful Full Read and OSID after these failures.
  for (const diagnostic of [
    'CRC check: FAILED',
    'Checksum validation: FAILED',
    'Hash verification: FAILED',
    'CRC: FAIL',
    'Checksum result = INVALID'
  ]) {
    for (const [operation, completion] of [
      ['read', 'Read completed successfully'],
      ['readProperties', 'OSID: 9379910']
    ]) {
      const classified = classifyPcmHammerResult(operation, `${diagnostic}\n${completion}`, 0);
      assert.strictEqual(classified.success, false, `${operation} must reject structured integrity failure: ${diagnostic}`);
      assert.strictEqual(classified.stopCode, 'read-integrity-failed');
      passed++;
    }
  }
  for (const diagnostic of ['CRC check: PASSED', 'Checksum validation: OK', 'Hash verification: SUCCESS']) {
    const classified = classifyPcmHammerResult('read', `${diagnostic}\nRead completed successfully`, 0);
    assert.strictEqual(classified.success, true, `positive integrity status must not be rejected: ${diagnostic}`);
    passed++;
  }
  // One or two failed blocks must not be overridden by a success footer.
  for (const [diagnostic, expectedCount] of [
    ['Failed to read block 128', 1],
    ['Block 128 read error', 1],
    ['Read block 128 timeout\nFailed to read block 129', 2]
  ]) {
    const classified = classifyPcmHammerResult('read',
      `${diagnostic}\nRead completed successfully`, 0);
    assert.strictEqual(classified.blockFailures, expectedCount);
    assert.strictEqual(classified.success, false,
      `any failed block must disqualify a Full Read: ${diagnostic}`);
    assert.strictEqual(classified.stopCode, 'block-read-failed');
    passed++;
  }
  // Read Properties also collects controller identity. A block failure must
  // never be followed by an admitted OSID, even if a CLI footer exits zero.
  // Beta.105 incorrectly returned success=true for both one and three errors.
  for (const [diagnostic, expectedCount, stopCode] of [
    ['Failed to read block 128', 1, 'block-read-failed'],
    ['Failed to read block 128\nBlock 129 read error\nFailed to read block 130', 3, 'repeated-block-read-failures']
  ]) {
    const classified = classifyPcmHammerResult('readProperties',
      `${diagnostic}\nOSID: 9379910`, 0);
    assert.strictEqual(classified.blockFailures, expectedCount);
    assert.strictEqual(classified.success, false,
      'Read Properties identity must not be admitted after failed block diagnostics');
    assert.strictEqual(classified.stopCode, stopCode,
      'Read Properties failure stop code must agree with failed success evidence');
    passed++;
  }
  assert.strictEqual(classifyPcmHammerResult('readProperties',
    'Block 128 read successfully\nOSID: 9379910', 0).success, true,
    'clean Read Properties block progress remains acceptable'); passed++;

  // Alternate CLI builds report failed sectors/pages, not just blocks.
  for (const diagnostic of [
    'Failed to read sector 0x1800',
    'Read page 128 timeout',
    'Sector 0x1800 read error',
    'Page 128 read failed'
  ]) {
    const classified = classifyPcmHammerResult('read',
      `${diagnostic}\nRead completed successfully`, 0);
    assert.strictEqual(classified.success, false, `failed memory unit must invalidate Full Read: ${diagnostic}`);
    assert.strictEqual(classified.stopCode, 'read-unit-failed');
    passed++;
  }
  const propertiesUnitFailure = classifyPcmHammerResult('readProperties',
    'OSID: 9379910\nFailed to read sector 0x1800', 0);
  assert.strictEqual(propertiesUnitFailure.success, false); passed++;
  assert.strictEqual(propertiesUnitFailure.stopCode, 'read-unit-failed'); passed++;
  const cleanUnits = classifyPcmHammerResult('read',
    'Read sector 0x1800 completed\nPage 128 read successfully\nRead completed successfully', 0);
  assert.strictEqual(cleanUnits.success, true); passed++;
  const cleanBlocks = classifyPcmHammerResult('read',
    'Block 128 read successfully\nRead completed successfully', 0);
  assert.strictEqual(cleanBlocks.success, true,
    'normal successful block progress must remain acceptable'); passed++;

  const crcOk = classifyPcmHammerResult('read',
    'CRC verification passed\nRead completed successfully', 0);
  assert.strictEqual(crcOk.success, true,
    'positive CRC verification must not be mistaken for an integrity failure'); passed++;

  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-exit-proof-'));
  try {
    const file = path.join(folder, 'synthetic.bin');
    fs.writeFileSync(file, Buffer.alloc(P01_BIN_SIZE, 0x42));
    const missingExit = classifyPcmHammerResult('read', completedLog, null);
    const rejected = validateP01ReadFile(file, missingExit);
    assert.strictEqual(rejected.valid, false, 'a full-size BIN must not override missing process exit proof'); passed++;
    const accepted = validateP01ReadFile(file, classifyPcmHammerResult('read', completedLog, 0));
    assert.strictEqual(accepted.valid, true, 'normal numeric zero exit must preserve valid synthetic Full Read validation'); passed++;
    const contradictory = validateP01ReadFile(file,
      { success: true, stopCode: 'kernel-files-missing' });
    assert.strictEqual(contradictory.valid, false,
      'a contradictory success flag and explicit failure stop must never admit a BIN'); passed++;
    assert.strictEqual(contradictory.code, 'kernel-files-missing'); passed++;
    const classified = classifyPcmHammerResult('read',
      'No .bin kernel files found\nRead completed successfully', 0);
    assert.strictEqual(validateP01ReadFile(file, classified).valid, false,
      'conflicting CLI log cannot certify a full-size backup'); passed++;
    const failedBlock = classifyPcmHammerResult('read',
      'Failed to read block 128\nRead completed successfully', 0);
    assert.strictEqual(validateP01ReadFile(file, failedBlock).valid, false,
      'a full-size BIN must not override a single failed block diagnostic'); passed++;
    const failedSector = classifyPcmHammerResult('read',
      'Failed to read sector 0x1800\nRead completed successfully', 0);
    assert.strictEqual(validateP01ReadFile(file, failedSector).valid, false); passed++;
    const integrityFailure = classifyPcmHammerResult('read',
      'CRC mismatch on block 128\nRead completed successfully', 0);
    assert.strictEqual(validateP01ReadFile(file, integrityFailure).valid, false,
      'CRC mismatch must prevent admission of a complete-size BIN'); passed++;

  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
  return { passed, scenarios: passed };
}
if (require.main === module) {
  const result = runPcmHammerExitProofSimulations();
  console.log(`PCM Hammer exit-proof simulations: ${result.passed}/${result.scenarios} passed`);
}
module.exports = { runPcmHammerExitProofSimulations };
