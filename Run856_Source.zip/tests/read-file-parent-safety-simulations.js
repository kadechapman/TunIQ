'use strict';
// Filesystem-only regression: never starts PCM Hammer or accesses an ECU.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { P01_BIN_SIZE, validateP01ReadFile } = require('../src/pcmhammer');

function runReadFileParentSafetySimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-parent-'));
  let passed = 0;
  try {
    const real = path.join(root, 'real');
    fs.mkdirSync(real);
    const file = path.join(real, 'read.bin');
    fs.writeFileSync(file, Buffer.alloc(P01_BIN_SIZE, 0x71));
    const result = { success: true };
    assert.equal(validateP01ReadFile(file, result).valid, true, 'normal local backup remains valid'); passed++;
    // Regression: the file can grow after its first fstat(). A plain
    // readFileSync(fd) allocates the *new*, unbounded size before noticing
    // the mismatch. Read verification must cap allocation to one P01 image.
    const growing = path.join(real, 'growing.bin');
    fs.writeFileSync(growing, Buffer.alloc(P01_BIN_SIZE, 0x75));
    const originalFstat = fs.fstatSync;
    const originalReadFile = fs.readFileSync;
    let grew = false;
    let unboundedFdReads = 0;
    let grownResult;
    try {
      fs.fstatSync = function (fd, ...args) {
        const stat = originalFstat.call(fs, fd, ...args);
        if (!grew && stat.size === P01_BIN_SIZE) {
          grew = true;
          fs.truncateSync(growing, P01_BIN_SIZE + 16 * 1024 * 1024);
        }
        return stat;
      };
      fs.readFileSync = function (target, ...args) {
        if (typeof target === 'number') unboundedFdReads++;
        return originalReadFile.call(fs, target, ...args);
      };
      grownResult = validateP01ReadFile(growing, result);
    } finally {
      fs.fstatSync = originalFstat;
      fs.readFileSync = originalReadFile;
    }
    assert.equal(grew, true, 'fixture must grow the file after the first fstat'); passed++;
    assert.equal(grownResult.code, 'read-file-changed', 'growing backup must fail integrity proof'); passed++;
    assert.equal(unboundedFdReads, 0, 'read verifier must never call unbounded readFileSync(fd)'); passed++;
    // A fixed-size loop must tolerate short reads without treating a complete
    // 512-KB backup as partial. This also proves the bounded read path runs.
    const originalReadSync = fs.readSync;
    let boundedCalls = 0;
    let shortResult;
    try {
      fs.readSync = function (fd, buffer, offset, length, position) {
        boundedCalls++;
        assert(length <= P01_BIN_SIZE, 'single read request exceeded P01 image size');
        return originalReadSync.call(fs, fd, buffer, offset, Math.min(length, 8192), position);
      };
      shortResult = validateP01ReadFile(file, result);
    } finally { fs.readSync = originalReadSync; }
    assert.equal(shortResult.valid, true, 'short reads must still verify complete backups'); passed++;
    assert.equal(shortResult.sha256, crypto.createHash('sha256').update(Buffer.alloc(P01_BIN_SIZE, 0x71)).digest('hex'),
      'short reads must preserve the exact verified BIN digest'); passed++;
    assert(boundedCalls > 2, 'read verifier must use bounded readSync calls'); passed++;
    // If the backup is truncated while the fixed-size read is underway,
    // neither a partial buffer nor an earlier success status is sufficient.
    const shrinking = path.join(real, 'shrinking.bin');
    fs.writeFileSync(shrinking, Buffer.alloc(P01_BIN_SIZE, 0x76));
    let shrunk = false;
    let truncatedResult;
    try {
      fs.readSync = function (fd, buffer, offset, length, position) {
        const count = originalReadSync.call(fs, fd, buffer, offset, Math.min(length, 8192), position);
        if (!shrunk && count > 0) {
          shrunk = true;
          fs.truncateSync(shrinking, 8192);
        }
        return count;
      };
      truncatedResult = validateP01ReadFile(shrinking, result);
    } finally { fs.readSync = originalReadSync; }
    assert.equal(shrunk, true, 'fixture must truncate a file mid-read'); passed++;
    assert.equal(truncatedResult.code, 'read-file-changed', 'partial read must fail closed'); passed++;
    const link = path.join(root, 'redirected');
    fs.symlinkSync(real, link, process.platform === 'win32' ? 'junction' : 'dir');
    assert.equal(validateP01ReadFile(path.join(link, 'read.bin'), result).code, 'read-file-unsafe-parent',
      'symlink/junction parent cannot be accepted as a verified backup'); passed++;
    const nested = path.join(real, 'nested');
    fs.mkdirSync(nested);
    const nestedFile = path.join(nested, 'read.bin');
    fs.writeFileSync(nestedFile, Buffer.alloc(P01_BIN_SIZE, 0x72));
    assert.equal(validateP01ReadFile(path.join(link, 'nested', 'read.bin'), result).code,
      'read-file-unsafe-parent', 'indirect redirected ancestor must be rejected'); passed++;
    assert.equal(validateP01ReadFile(path.join(root, 'missing', 'read.bin'), result).code,
      'read-file-unsafe-parent', 'uninspectable parent must fail closed'); passed++;
    const direct = path.join(root, 'direct-link.bin');
    fs.symlinkSync(file, direct);
    assert.equal(validateP01ReadFile(direct, result).code, 'read-file-unsafe-link',
      'existing direct-file symlink guard must remain effective'); passed++;
    assert.equal(validateP01ReadFile(file, { success: false, stopCode: 'partial-read' }).valid, false,
      'failed PCM Hammer completion must not be accepted'); passed++;
    // Existing/assisted Full Read imports must enforce the same Windows path
    // rules as a new CLI destination. Linux fixtures exercise Win32 aliases.
    for (const unsafeName of ['NUL.bin', 'CON.bin', 'COM¹.bin', 'read.bin.', 'read.bin:alternate']) {
      const unsafeFile = path.join(real, unsafeName);
      fs.writeFileSync(unsafeFile, Buffer.alloc(P01_BIN_SIZE, 0x73));
      assert.equal(validateP01ReadFile(unsafeFile, result).code, 'read-file-windows-alias',
        `existing unsafe Win32 alias must not become a verified original: ${unsafeName}`);
      passed++;
    }
    const unsafeParent = path.join(root, 'Originals.');
    fs.mkdirSync(unsafeParent);
    const unsafeParentFile = path.join(unsafeParent, 'read.bin');
    fs.writeFileSync(unsafeParentFile, Buffer.alloc(P01_BIN_SIZE, 0x74));
    assert.equal(validateP01ReadFile(unsafeParentFile, result).code, 'read-file-windows-alias',
      'unsafe Windows alias in an existing parent must fail'); passed++;
    for (const unsafeNamespace of [String.raw`\\server\share\read.bin`,
      String.raw`\\?\C:\Temp\read.bin`, String.raw`C:relative-read.bin`]) {
      assert.equal(validateP01ReadFile(unsafeNamespace, result).code, 'read-file-unsafe-namespace',
        'device/network/drive-relative paths must fail before opening'); passed++;
    }
    console.log(`✓ PCM read parent-path integrity: ${passed} filesystem-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) runReadFileParentSafetySimulations();
module.exports = { runReadFileParentSafetySimulations };
