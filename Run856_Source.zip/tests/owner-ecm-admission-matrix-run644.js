'use strict';
// Run644: synthetic, non-hardware admission regression for owner's combined requests.
const assert = require('node:assert/strict');
const { reviewP01Request } = require('../src/p01-request-review');
const request = 'Disable VATS. Enable the ECM fan outputs. Set electric fans on at 210 F and off at 190 F. Tune my installed LSX Stage 2 cam. Both knock sensors are physically missing.';
for (const os of ['unknown', '00000000', '12587603']) {
  const result = reviewP01Request({activeProject:{id:'run644-fixture',controller:'P01',os},request});
  assert.equal(result.ready,false,`must fail closed: ${os}`);
  const blockers = new Set(result.unresolvedRequests.map(x=>x.type));
  for(const required of ['fan-output-enable','physical-camshaft-tune','knock-sensor-delete']) {
    assert(blockers.has(required),`${os}: missing ${required}`);
  }
  if(os !== '12587603') assert(result.missingSafetyFacts.some(x=>x.includes('operating-system (OS) ID')),`${os}: OS must be unresolved`);
  console.log(`PASS ${os}: independent fan/cam/knock blockers retained; no ECM operations`);
}
