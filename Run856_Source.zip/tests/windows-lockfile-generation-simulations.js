'use strict';
// Actual npm CLI probe on a dependency-free temporary fixture. Never contacts
// a registry, installs Electron, runs ECU code, or modifies project package.json.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const root = path.resolve(__dirname, '..');
const script = fs.readFileSync(path.join(root, 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
const operatorScript = fs.readFileSync(path.join(root, 'tools', 'windows-readonly-dev-validation.ps1'), 'utf8');
let checks = 0;
const check = (label, test) => { assert.ok(test, label); checks++; };
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-lock-probe-'));
const packagePath = path.join(dir, 'package.json');
const lockPath = path.join(dir, 'package-lock.json');
const npmLogs = path.join(dir, 'npm-debug');
const original = JSON.stringify({ name: 'tuniq-lock-probe', version: '1.0.0', private: true }) + '\n';
const npmCmd = process.platform === 'win32' ? 'npm.cmd' : 'npm';
function npmProbe(flag) {
  return spawnSync(npmCmd, ['install', '--package-lock-only', '--package-lock=true',
    flag, '--ignore-scripts', '--no-audit', '--no-fund', '--offline', '--fetch-retries=0',
    `--logs-dir=${npmLogs}`],
    { cwd: dir, encoding: 'utf8', timeout: 20000, shell: process.platform === 'win32',
      env: { ...process.env, npm_config_update_notifier: 'false' } });
}
try {
  fs.writeFileSync(packagePath, original);
  const bad = npmProbe('--save=false');
  check('baseline npm probe exits successfully', bad.status === 0 && !bad.error);
  check('save=false reproduces silent missing lockfile', !fs.existsSync(lockPath));
  const good = npmProbe('--save=true');
  check('corrected npm probe exits successfully', good.status === 0 && !good.error);
  check('corrected npm probe writes a real lockfile', fs.existsSync(lockPath));
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  check('npm-generated lockfile has valid root metadata',
    lock.lockfileVersion >= 2 && lock.packages?.['']?.name === 'tuniq-lock-probe');
  check('npm leaves package.json unchanged', fs.readFileSync(packagePath, 'utf8') === original);
  check('real npm CLI writes bounded-run debug logs to requested directory',
    fs.existsSync(npmLogs) && fs.readdirSync(npmLogs).some(name => name.endsWith('.log')));
  check('Windows build forces lock writing, never save=false',
    script.includes("'--package-lock=true','--save=true'") &&
    !script.includes("'--save=false'") &&
    script.includes('npm returned success but did not write package-lock.json'));
  check('separate Windows read-only operator kit also forces genuine lock writing',
    operatorScript.includes("'--package-lock=true', '--save=true'") &&
    !operatorScript.includes("'--save=false'") &&
    operatorScript.includes('npm succeeded without writing package-lock.json') &&
    operatorScript.includes("$npmLogArg = '--logs-dir=' + $diagnostics"));
  // Run341: The Windows CI workflow must use the same source-bound, hardened
  // local operator that has real offline npm regression coverage. A duplicated
  // PowerShell resolver had drifted from the operator and wrote artifacts
  // inside the source checkout. These are static workflow checks, not proof
  // of Windows runner execution.
  const candidateWorkflow = fs.readFileSync(path.join(root, '.github/workflows/windows-lockfile-candidate.yml'), 'utf8');
  check('candidate workflow is manual and repository read-only',
    /workflow_dispatch:/.test(candidateWorkflow) && /permissions:\s*\n\s*contents: read/.test(candidateWorkflow) &&
    !/push:|pull_request:|schedule:/.test(candidateWorkflow));
  check('candidate workflow uses native Windows and reviewed Node major',
    candidateWorkflow.includes('runs-on: windows-latest') && candidateWorkflow.includes("node-version: '20'"));
  check('candidate workflow rejects pre-existing source lockfile',
    candidateWorkflow.includes("if (Test-Path -LiteralPath 'package-lock.json')") &&
    candidateWorkflow.includes('Review it instead of silently replacing it.'));
  check('candidate workflow performs source and read-only checks before operator', (() => {
    const source = candidateWorkflow.indexOf('npm.cmd run check:windows-source-paths');
    const readonly = candidateWorkflow.indexOf('npm.cmd run check:dev-readonly-admission');
    const generate = candidateWorkflow.indexOf('tools/generate-lockfile-candidate.js');
    return source >= 0 && source < readonly && readonly < generate;
  })());
  check('candidate workflow delegates dependency resolution to hardened local operator',
    candidateWorkflow.includes('node.exe tools/generate-lockfile-candidate.js $out') &&
    !candidateWorkflow.includes('npm.cmd install --package-lock-only') &&
    !candidateWorkflow.includes('Copy-Item -LiteralPath $sourcePackage'));
  check('candidate workflow stores review output outside source checkout',
    candidateWorkflow.includes("Join-Path $env:RUNNER_TEMP 'tuniq-lockfile-review-only'") &&
    candidateWorkflow.includes('${{ runner.temp }}/tuniq-lockfile-review-only/') &&
    !candidateWorkflow.includes('dev-build-output/lockfile-review-only'));
  check('candidate workflow refuses to overwrite existing review output',
    candidateWorkflow.includes('if (Test-Path -LiteralPath $out)') &&
    candidateWorkflow.includes('Refusing to overwrite previous review output'));
  check('candidate workflow independently reviews source-bound candidate before upload', (() => {
    const generate = candidateWorkflow.indexOf('tools/generate-lockfile-candidate.js');
    const review = candidateWorkflow.indexOf('tools/review-windows-lockfile-candidate.js');
    const upload = candidateWorkflow.indexOf('actions/upload-artifact@v4');
    return generate >= 0 && review > generate && upload > review &&
      candidateWorkflow.includes('Candidate/source commit or lockfile provenance review failed.');
  })());
  check('candidate workflow retains unverified evidence and never publishes or launches',
    candidateWorkflow.includes('tuniq-windows-lockfile-candidate-UNVERIFIED') &&
    candidateWorkflow.includes('if-no-files-found: error') &&
    !/git push|git commit|electron-builder|npm.cmd ci|npm.cmd start/.test(candidateWorkflow));
  // Run142: npm --package-lock-only can still mutate package.json before
  // provenance is captured. Do not bless a modified dependency manifest.
  check('Windows preview refuses manifest drift during lockfile resolution', (() => {
    const before = script.indexOf('$manifestHashBefore = (Get-FileHash -LiteralPath');
    const resolve = script.indexOf('Resolve genuine npm lock graph without running scripts');
    const after = script.indexOf('$manifestHashAfter = (Get-FileHash -LiteralPath');
    const review = script.indexOf('Review lock graph constraints');
    return before !== -1 && before < resolve && after > resolve && after < review &&
      script.includes('if ($manifestHashAfter -ne $manifestHashBefore)') &&
      script.includes('package.json changed during npm lockfile resolution. No build approval.');
  })());
  // Run320: the standalone operator validation must not bless a package.json
  // modified by npm lockfile resolution. This check runs before preflight and
  // before provenance capture; matching the preview script is not sufficient.
  check('Windows operator validation rejects package.json drift before lock review', (() => {
    const before = operatorScript.indexOf('$manifestHashBefore = (Get-FileHash');
    const resolve = operatorScript.indexOf('Generate npm lockfile candidate (no lifecycle scripts)');
    const after = operatorScript.indexOf('$manifestHashAfter = (Get-FileHash');
    const review = operatorScript.indexOf('Validate lockfile metadata');
    const capture = operatorScript.indexOf('Capture candidate and package provenance');
    return before !== -1 && before < resolve && after > resolve && after < review &&
      review < capture &&
      operatorScript.includes('if ($manifestHashAfter -ne $manifestHashBefore)') &&
      operatorScript.includes('package.json changed during npm lockfile resolution. No candidate or build approval.');
  })());
  // Run321: npm's before/after manifest guard is insufficient if an earlier
  // offline test mutates the disposable package.json. Require equality with
  // the source reviewed BEFORE the copy and before the full test suite.
  check('Windows operator binds tested and resolved manifest to reviewed source', (() => {
    const baseline = operatorScript.indexOf('$reviewedManifestHash = (Get-FileHash');
    const copy = operatorScript.indexOf('foreach ($entry in Get-ChildItem');
    const copied = operatorScript.indexOf('$copiedManifestHash = (Get-FileHash');
    const suite = operatorScript.indexOf("Run-Step 'Full offline simulated suite'");
    const tested = operatorScript.indexOf('$testedManifestHash = (Get-FileHash');
    const original = operatorScript.indexOf('$sourceManifestHashAfterTests = (Get-FileHash');
    const resolution = operatorScript.indexOf('$manifestHashBefore = (Get-FileHash');
    return baseline > -1 && baseline < copy && copy < copied && copied < suite &&
      suite < tested && tested < original && original < resolution &&
      operatorScript.includes('$copiedManifestHash -ne $reviewedManifestHash') &&
      operatorScript.includes('$testedManifestHash -ne $reviewedManifestHash') &&
      operatorScript.includes('$sourceManifestHashAfterTests -ne $reviewedManifestHash') &&
      operatorScript.includes('$manifestHashBefore -ne $reviewedManifestHash');
  })());
  // Run322: package.json-only checks miss test-time mutation of application code.
  // The operator must reverify every manifest-listed source file after npm test,
  // before any npm resolution, install or Electron launch is allowed.
  check('Windows operator rechecks source-manifest integrity after full suite', (() => {
    const suite = operatorScript.indexOf("Run-Step 'Full offline simulated suite'");
    const recheck = operatorScript.indexOf("Run-Step 'Post-suite critical-source snapshot'");
    const npm = operatorScript.indexOf("Run-Step 'Generate npm lockfile candidate");
    const ci = operatorScript.indexOf("Run-Step 'Install exact dependency graph");
    return suite !== -1 && suite < recheck && recheck < npm && npm < ci &&
      operatorScript.includes("Run-Step 'Post-suite critical-source snapshot' 'node.exe' @('tools/launch-snapshot.js', '--check')");
  })());
  // Run325: the disposable suite must not be allowed to mutate the ORIGINAL
  // reviewed tree while only its own working copy is rechecked. In contrast
  // to the disposable copy, the original's entire source manifest is stable.
  check('Windows operator verifies original snapshot and full manifest after tests, before npm', (() => {
    const suite = operatorScript.indexOf("Run-Step 'Full offline simulated suite'");
    const originalSnapshot = operatorScript.indexOf("Run-Step 'Reviewed original source snapshot unchanged'");
    const originalManifest = operatorScript.indexOf("Run-Step 'Reviewed original source manifest unchanged'");
    const resolution = operatorScript.indexOf("Run-Step 'Generate npm lockfile candidate");
    return suite >= 0 && suite < originalSnapshot && originalSnapshot < originalManifest &&
      originalManifest < resolution &&
      operatorScript.includes("(Join-Path $source 'tools/launch-snapshot.js'), '--check'") &&
      operatorScript.includes("(Join-Path $source 'tools/windows-source-path-preflight.js'), $source, '--require-safe'");
  })());
  // Exercise the same manifest auditor on a synthetic original tree. A source
  // mutation must fail, even though the disposable worktree is unchanged.
  const originalTree = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-reviewed-source-'));
  try {
    const src = path.join(originalTree, 'src');
    fs.mkdirSync(src);
    const file = path.join(src, 'app.js');
    const reviewed = 'reviewed original application\n';
    fs.writeFileSync(file, reviewed);
    const manifest = JSON.stringify({version:'fixture',files:[{
      path:'src/app.js',size:Buffer.byteLength(reviewed),sha256:crypto.createHash('sha256').update(reviewed).digest('hex')
    }]}, null, 2)+'\n';
    fs.writeFileSync(path.join(originalTree,'SOURCE_MANIFEST.json'), manifest);
    fs.writeFileSync(path.join(originalTree,'SOURCE_MANIFEST_SHA256.txt'),
      crypto.createHash('sha256').update(manifest).digest('hex')+'  SOURCE_MANIFEST.json\n');
    const {inspectWindowsSourceLayout} = require('../tools/windows-source-path-preflight');
    check('original manifest auditor accepts unchanged reviewed source',
      inspectWindowsSourceLayout(originalTree).windowsSourcePathsSafe === true);
    fs.writeFileSync(file, 'modified original application\n');
    check('original manifest auditor rejects source changed outside disposable copy',
      inspectWindowsSourceLayout(originalTree).windowsSourcePathsSafe === false);
  } finally { fs.rmSync(originalTree, {recursive:true,force:true}); }
  // Actual source fingerprint regression: generated test-results are mutable,
  // but any code change must invalidate the reviewed source-only snapshot.
  const { criticalSourceFingerprint } = require('../tools/launch-snapshot');
  const sourceFixture = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-post-suite-source-'));
  try {
    fs.mkdirSync(path.join(sourceFixture, 'src'));
    fs.mkdirSync(path.join(sourceFixture, 'tools'));
    fs.mkdirSync(path.join(sourceFixture, 'tests'));
    fs.mkdirSync(path.join(sourceFixture, 'test-results'));
    fs.writeFileSync(path.join(sourceFixture, 'VERSION.json'), JSON.stringify({version:'fixture'}) + '\n');
    fs.writeFileSync(path.join(sourceFixture, 'tools', 'fixture.js'), 'module.exports = {};\n');
    fs.writeFileSync(path.join(sourceFixture, 'tests', 'fixture.js'), 'module.exports = {};\n');
    fs.writeFileSync(path.join(sourceFixture, 'package.json'), original);
    fs.writeFileSync(path.join(sourceFixture, 'src', 'app.js'), 'original');
    fs.writeFileSync(path.join(sourceFixture, 'test-results', 'generated.json'), '{}');
    const baseline = criticalSourceFingerprint(sourceFixture).sha256;
    fs.writeFileSync(path.join(sourceFixture, 'test-results', 'generated.json'), '{"updated":true}');
    check('generated test result changes do not invalidate critical source fingerprint',
      criticalSourceFingerprint(sourceFixture).sha256 === baseline);
    fs.writeFileSync(path.join(sourceFixture, 'src', 'app.js'), 'modified');
    check('test-time application code mutation invalidates critical source fingerprint',
      criticalSourceFingerprint(sourceFixture).sha256 !== baseline);
  } finally { fs.rmSync(sourceFixture, {recursive:true, force:true}); }
  // A real local file mutation demonstrates the failure mode without running
  // PowerShell or asserting a Windows runtime proof.
  const hash = value => crypto.createHash('sha256').update(value).digest('hex');
  const reviewedHash = hash(original);
  const mutatedManifest = JSON.stringify({name:'tuniq-lock-probe',version:'1.0.0',private:true,
    scripts:{test:'node -e "process.exit(0)"'}}) + '\n';
  fs.writeFileSync(packagePath, mutatedManifest);
  check('synthetic test-time manifest drift differs from reviewed source',
    hash(fs.readFileSync(packagePath)) !== reviewedHash);
  fs.writeFileSync(packagePath, original);
  check('restored reviewed source manifest passes equality check',
    hash(fs.readFileSync(packagePath)) === reviewedHash);
  // Run123: preserve native Windows preview npm debug logs even if lockfile
  // resolution or npm ci fails before Electron can start.
  check('Windows preview creates an npm log argument in the diagnostic directory',
    script.includes("$npmLogArg = '--logs-dir=' + $diagnostics"));
  check('Windows preview lockfile resolution routes npm logs to diagnostics',
    script.includes("'--fetch-timeout=15000',$npmLogArg"));
  check('Windows preview npm ci routes npm logs to diagnostics',
    script.includes("'--fetch-timeout=30000',$npmLogArg"));
  // A real npm failure must still leave a useful debug log; no registry access.
  fs.writeFileSync(packagePath, JSON.stringify({name:'tuniq-lock-probe', version:'1.0.0',
    private:true, dependencies:{'tuniq-missing-fixture':'1.0.0'}}) + '\n');
  const failedCi = spawnSync(npmCmd, ['ci', '--offline', '--ignore-scripts',
    '--no-audit', '--no-fund', '--fetch-retries=0', `--logs-dir=${npmLogs}`],
    { cwd:dir, encoding:'utf8', timeout:20000, shell:process.platform === 'win32',
      env:{...process.env, npm_config_update_notifier:'false'} });
  check('actual offline npm ci fails on mismatched lockfile', failedCi.status !== 0 && !failedCi.error);
  check('actual failed npm ci preserves a debug log in the requested directory',
    fs.readdirSync(npmLogs).filter(name => name.endsWith('.log')).length >= 3);
  fs.writeFileSync(packagePath, original);
  console.log(`Windows npm lockfile generation: ${checks}/${checks} passed (real offline npm CLI fixture; no Electron installed).`);
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
