'use strict';
// Pure Node regression tests. Do not start Electron or touch COM/ECU hardware.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');
const { writeRendererEvidence, assessRendererSnapshot, isRendererElementPainted, isAllowedRendererRequest, isRendererConsoleError, isolatedBootstrapReply, registerIsolatedBootstrapHandlers, ISOLATED_BOOTSTRAP_CHANNELS, EXPECTED_CSP, ALLOWED_RENDERER_ASSETS, PRIMARY_NAV_PAGES, validPrimaryNavigationProof, inspectPrimaryNavigation } = require('../tools/electron-renderer-runtime-smoke');
const navigationPages = ['dashboard', 'garage', 'workflow', 'flash', 'scanner', 'fullai', 'tunes', 'bridge', 'settings'];
const goodNavigation = { pages: navigationPages.map(page => ({
  page, active: true, sidebarSelected: true, singleActive: true, painted: true,
  safetyWarningVisible: page === 'flash' ? true : null,
  writeControlsDisabled: page === 'flash' ? true : null
})), restoredDashboard: true, restoredDashboardPainted: true, restoredWriteControlsDisabled: true };
const good = { navigationProof: goodNavigation, readyState: 'complete', title: 'TunIQ', csp: EXPECTED_CSP,
  bridgeAvailable: true, rendererDomPresent: true, stylesheetLoaded: true,
  engineCatalogExecuted: true, appHandlersBound: true, startupErrorVisible: false, consoleErrorObserved: false,
  appVisible: true, splashHidden: true, deniedRequestObserved: false,
  scripts: ['engine-catalog.js', 'app.js'] };
const cases = [
  ['missing snapshot', null, 'invalid-renderer-snapshot'],
  ['navigation missing', (({ navigationProof, ...rest }) => rest)(good), 'primary-navigation-unverified'],
  ['navigation incomplete', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.slice(0, 8) } }, 'primary-navigation-unverified'],
  ['navigation wrong page', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map((p, i) => i === 2 ? { ...p, page: 'devices' } : p) } }, 'primary-navigation-unverified'],
  ['navigation section hidden', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map((p, i) => i === 2 ? { ...p, painted: false } : p) } }, 'primary-navigation-unverified'],
  ['navigation not selected', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map((p, i) => i === 2 ? { ...p, sidebarSelected: false } : p) } }, 'primary-navigation-unverified'],
  ['navigation multiple active sections', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map((p, i) => i === 2 ? { ...p, singleActive: false } : p) } }, 'primary-navigation-unverified'],
  ['flash write controls enabled', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map(p => p.page === 'flash' ? { ...p, writeControlsDisabled: false } : p) } }, 'primary-navigation-unverified'],
  ['flash write control proof missing', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map(p => p.page === 'flash' ? (({ writeControlsDisabled, ...rest }) => rest)(p) : p) } }, 'primary-navigation-unverified'],
  ['flash warning missing', { ...good, navigationProof: { ...goodNavigation, pages: goodNavigation.pages.map(p => p.page === 'flash' ? { ...p, safetyWarningVisible: false } : p) } }, 'primary-navigation-unverified'],
  ['dashboard not restored', { ...good, navigationProof: { ...goodNavigation, restoredDashboard: false } }, 'primary-navigation-unverified'],
  ['restored dashboard not painted', { ...good, navigationProof: { ...goodNavigation, restoredDashboardPainted: false } }, 'primary-navigation-unverified'],
  ['write controls reenabled after navigation', { ...good, navigationProof: { ...goodNavigation, restoredWriteControlsDisabled: false } }, 'primary-navigation-unverified'],
  ['array snapshot', [], 'invalid-renderer-snapshot'],
  ['incomplete document', { ...good, readyState: 'loading' }, 'document-not-loaded'],
  ['unexpected title', { ...good, title: 'Other' }, 'unexpected-document-title'],
  ['missing CSP', { ...good, csp: null }, 'missing-or-weakened-csp'],
  ['weakened CSP', { ...good, csp: "script-src 'self' 'unsafe-inline'" }, 'missing-or-weakened-csp'],
  ['preload failure', { ...good, bridgeAvailable: false }, 'preload-bridge-unavailable'],
  ['catalog script not executed', { ...good, engineCatalogExecuted: false }, 'engine-catalog-not-executed'],
  ['catalog execution evidence missing', (({ engineCatalogExecuted, ...rest }) => rest)(good), 'engine-catalog-not-executed'],
  ['app script not executed', { ...good, appHandlersBound: false }, 'app-script-not-executed'],
  ['app execution evidence missing', (({ appHandlersBound, ...rest }) => rest)(good), 'app-script-not-executed'],
  ['startup error rendered', { ...good, startupErrorVisible: true }, 'renderer-startup-error-or-unknown'],
  ['startup error status missing', (({ startupErrorVisible, ...rest }) => rest)(good), 'renderer-startup-error-or-unknown'],
  ['renderer script console error', { ...good, consoleErrorObserved: true }, 'renderer-console-error-or-unknown'],
  ['renderer console status missing', (({ consoleErrorObserved, ...rest }) => rest)(good), 'renderer-console-error-or-unknown'],
  ['blocked renderer request', { ...good, deniedRequestObserved: true }, 'renderer-disallowed-resource-request'],
  ['blocked-request status missing', (({ deniedRequestObserved, ...rest }) => rest)(good), 'renderer-disallowed-resource-request'],
  ['missing UI', { ...good, rendererDomPresent: false }, 'renderer-dom-missing'],
  ['bootstrap pending behind splash', { ...good, appVisible: false, splashHidden: false }, 'application-not-visible'],
  ['application visibility not proven', (({ appVisible, ...rest }) => rest)(good), 'application-not-visible'],
  ['splash still visible', { ...good, splashHidden: false }, 'splash-not-dismissed'],
  ['splash visibility not proven', (({ splashHidden, ...rest }) => rest)(good), 'splash-not-dismissed'],
  ['missing CSS', { ...good, stylesheetLoaded: false }, 'stylesheet-not-loaded'],
  ['missing scripts', { ...good, scripts: [] }, 'unexpected-renderer-scripts'],
  ['extra script', { ...good, scripts: [...good.scripts, 'unexpected.js'] }, 'unexpected-renderer-scripts'],
  ['reordered scripts', { ...good, scripts: [...good.scripts].reverse() }, 'unexpected-renderer-scripts']
];
function runRendererRuntimeSmokeSimulations({ quiet = false } = {}) {
  assert.deepEqual(assessRendererSnapshot(good), { passed: true, blockers: [] });
  for (const [label, snapshot, expected] of cases) {
    const result = assessRendererSnapshot(snapshot);
    assert.equal(result.passed, false, label);
    assert(result.blockers.includes(expected), `${label}: ${JSON.stringify(result)}`);
  }
  // Execute the exact navigation probe serialized into native Electron against
  // a fake DOM with real click-state transitions. No browser or hardware runs.
  assert.deepEqual([...PRIMARY_NAV_PAGES], navigationPages);
  assert.equal(validPrimaryNavigationProof(goodNavigation), true);
  let activePage = 'dashboard';
  const fakeSections = Object.fromEntries(navigationPages.map(page => [page, {
    id: page, classList: { contains: value => value === 'active' && activePage === page }
  }]));
  const fakeButtons = Object.fromEntries(navigationPages.map(page => [page, {
    dataset: { page }, onclick: () => { activePage = page; },
    click() { this.onclick(); },
    classList: { contains: value => value === 'active' && activePage === page }
  }]));
  const warning = { textContent: 'CAPABILITY CHECK REQUIRED' };
  const writeControls = Object.fromEntries(['flashTestWrite', 'flashWriteCalibration', 'flashWriteFull', 'flashRecovery']
    .map(id => [id, { disabled: true }]));
  const fakeDocument = {
    querySelector(selector) {
      const page = /^\.app-sidebar button\[data-page="([a-z]+)"\]$/.exec(selector)?.[1];
      if (page) return fakeButtons[page] || null;
      if (selector === 'section.page.active') return fakeSections[activePage];
      return null;
    },
    querySelectorAll(selector) {
      return selector === 'section.page.active' ? [fakeSections[activePage]] : [];
    },
    getElementById(id) { return id === 'flashSafetyBadge' ? warning : writeControls[id] || fakeSections[id] || null; }
  };
  const executeNavigation = () => vm.runInNewContext(
    `(${inspectPrimaryNavigation.toString()})(pages, painted)`,
    { document: fakeDocument, getComputedStyle: () => ({}), pages: navigationPages,
      painted: element => Boolean(element) });
  const navigationResult = executeNavigation();
  assert.equal(validPrimaryNavigationProof(navigationResult), true,
    'nine actual sidebar clicks and visible flash warning are required');
  assert.equal(activePage, 'dashboard', 'navigation probe restores dashboard');
  assert.equal(navigationResult.restoredDashboardPainted, true,
    'restored dashboard must remain painted after nine navigation clicks');
  assert.equal(navigationResult.restoredWriteControlsDisabled, true,
    'all four flash write controls must stay disabled after navigation');
  const normalDashboardClick = fakeButtons.dashboard.onclick;
  fakeButtons.dashboard.onclick = () => {
    normalDashboardClick();
    writeControls.flashTestWrite.disabled = false;
  };
  assert.equal(validPrimaryNavigationProof(executeNavigation()), false,
    'navigation-triggered write control re-enable must fail closed');
  fakeButtons.dashboard.onclick = normalDashboardClick;
  writeControls.flashTestWrite.disabled = true;
  warning.textContent = 'READY TO FLASH';
  assert.equal(validPrimaryNavigationProof(executeNavigation()), false,
    'missing uncommissioned warning blocks native smoke');
  warning.textContent = 'CAPABILITY CHECK REQUIRED';
  writeControls.flashWriteCalibration.disabled = false;
  assert.equal(validPrimaryNavigationProof(executeNavigation()), false,
    'enabled calibration write button blocks native smoke');
  writeControls.flashWriteCalibration.disabled = true;
  fakeButtons.scanner.onclick = () => {};
  assert.equal(validPrimaryNavigationProof(executeNavigation()), false,
    'broken sidebar click blocks native smoke');
  activePage = 'dashboard';
  // Run the exact predicate injected into Electron against inert fake DOM
  // nodes. The old display-only check incorrectly accepted these cases.
  const parent = { nodeType: 1, parentElement: null };
  const app = { nodeType: 1, parentElement: parent, getClientRects: () => [{ width: 640, height: 480 }] };
  const normal = { display: 'block', visibility: 'visible', opacity: '1' };
  const paintedCases = [
    ['rendered app', app, new Map(), true],
    ['ancestor display none', app, new Map([[parent, { ...normal, display: 'none' }]]), false],
    ['ancestor visibility hidden', app, new Map([[parent, { ...normal, visibility: 'hidden' }]]), false],
    ['ancestor opacity zero', app, new Map([[parent, { ...normal, opacity: '0' }]]), false],
    ['own visibility hidden', app, new Map([[app, { ...normal, visibility: 'hidden' }]]), false],
    ['own opacity zero', app, new Map([[app, { ...normal, opacity: '0' }]]), false],
    ['missing element', null, new Map(), false],
    ['zero layout boxes', { ...app, getClientRects: () => [] }, new Map(), false],
    ['zero-width layout box', { ...app, getClientRects: () => [{ width: 0, height: 100 }] }, new Map(), false],
    ['zero-height layout box', { ...app, getClientRects: () => [{ width: 100, height: 0 }] }, new Map(), false],
    ['invalid layout geometry', { ...app, getClientRects: () => [{ width: NaN, height: 100 }] }, new Map(), false],
    ['nonfinite layout geometry', { ...app, getClientRects: () => [{ width: Infinity, height: 100 }] }, new Map(), false],
    ['one visible rectangle', { ...app, getClientRects: () => [{ width: 0, height: 0 }, { width: 200, height: 100 }] }, new Map(), true],
    ['ancestor content visibility hidden', app, new Map([[parent, { ...normal, contentVisibility: 'hidden' }]]), false],
    ['own content visibility hidden', app, new Map([[app, { ...normal, contentVisibility: 'hidden' }]]), false],
    ['missing computed style', app, new Map([[app, null]]), false]
  ];
  for (const [label, node, overrides, expected] of paintedCases) {
    assert.equal(isRendererElementPainted(node, el => overrides.has(el) ? overrides.get(el) : normal), expected, label);
  }
  // Verify the function embedded in the actual runtime script has not drifted
  // from the exported implementation exercised above.
  const paintedPredicate = isRendererElementPainted.toString();
  assert(paintedPredicate.includes('getClientRects') && paintedPredicate.includes('parentElement'));
  assert.equal(vm.runInNewContext(`(${paintedPredicate})(element, styleFor)`, { element: app,
    styleFor: node => node === parent ? { ...normal, display: 'none' } : normal }), false,
    'serialized Electron predicate rejects hidden ancestor');

  // Both old and new Electron console-message event signatures must be
  // classified without mistaking a warning for a fatal JavaScript error.
  const consoleCases = [
    [2, true], ['error', true], [{ level: 'error', message: 'script failed' }, true],
    [{ level: 2, message: 'script failed' }, true],
    [0, false], [1, false], [3, false], ['warning', false],
    [{ level: 'warning' }, false], [{ level: 'info' }, false],
    [null, false], [{}, false]
  ];
  for (const [level, expected] of consoleCases) assert.equal(isRendererConsoleError(level), expected);
  // Only a small, explicit read-only IPC fixture can satisfy startup.
  const expectedBootstrap = ['app:get-bootstrap', 'knowledge:state', 'project:list',
    'project:files', 'workspace:get-summary'];
  assert.deepEqual([...ISOLATED_BOOTSTRAP_CHANNELS], expectedBootstrap);
  const handlers = new Map();
  registerIsolatedBootstrapHandlers({ handle: (channel, reply) => {
    assert(!handlers.has(channel), `duplicate fixture handler: ${channel}`);
    handlers.set(channel, reply);
  } });
  assert.deepEqual([...handlers.keys()], expectedBootstrap);
  for (const channel of expectedBootstrap) {
    assert.deepEqual(handlers.get(channel)(), isolatedBootstrapReply(channel));
  }
  assert.equal(isolatedBootstrapReply('app:get-bootstrap').device.connected, false);
  assert.equal(isolatedBootstrapReply('app:get-bootstrap').beta.agreementAccepted, true);
  assert.equal(isolatedBootstrapReply('workspace:get-summary').activeProject, null);
  assert.equal(isolatedBootstrapReply('project:files').active, null);
  assert.deepEqual(isolatedBootstrapReply('project:list'), []);
  assert.throws(() => isolatedBootstrapReply('flash:write'), /isolated-ipc-denied/);
  assert.throws(() => isolatedBootstrapReply('flash:test-write'), /isolated-ipc-denied/);
  assert.throws(() => isolatedBootstrapReply('device:connect'), /isolated-ipc-denied/);
  assert.throws(() => isolatedBootstrapReply('update:install'), /isolated-ipc-denied/);
  // The runtime entrypoint must not import the actual hardware-capable main process.
  const source = fs.readFileSync(path.join(__dirname, '..', 'tools', 'electron-renderer-runtime-smoke.js'), 'utf8');
  assert(!/require\(['"]\.\.\/src\/(?:main|obd|flash|pcmhammer)['"]\)/.test(source));
  assert(source.includes('onBeforeRequest') && source.includes('attachRendererNavigationGuard'));
  assert(source.includes('if (!allowed) deniedRequestObserved = true;'));
  assert(source.includes('snapshot.deniedRequestObserved = deniedRequestObserved;'));
  assert(source.includes('${isRendererElementPainted.toString()}'));
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-renderer-allowlist-'));
  let requestCases = 0;
  try {
    const renderer = path.join(root, 'renderer');
    fs.mkdirSync(renderer);
    const index = path.join(renderer, 'index.html');
    const sibling = path.join(root, 'secret.txt');
    const unlisted = path.join(renderer, 'unlisted.json');
    const nested = path.join(renderer, 'nested', 'app.js');
    const alias = path.join(renderer, 'unlisted-alias.js');
    fs.mkdirSync(path.dirname(nested));
    for (const asset of ALLOWED_RENDERER_ASSETS) fs.writeFileSync(path.join(renderer, asset), 'ok');
    fs.writeFileSync(sibling, 'no');
    fs.writeFileSync(unlisted, 'private');
    fs.writeFileSync(nested, 'not-an-approved-asset');
    // A symlink alias used to pass because realpath() resolved to app.js.
    // This must be rejected by the request-name check.
    let aliasCreated = false;
    try { fs.symlinkSync(path.join(renderer, 'app.js'), alias); aliasCreated = true; }
    catch (error) { if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error; }
    let hardlinkCreated = false;
    const linkedAsset = path.join(renderer, 'hardlink-source.js');
    try { fs.linkSync(path.join(renderer, 'app.js'), linkedAsset); hardlinkCreated = true; }
    catch (error) { if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error; }
    const allowed = [...ALLOWED_RENDERER_ASSETS].map(asset => pathToFileURL(path.join(renderer, asset)).href);
    const denied = [pathToFileURL(sibling).href, pathToFileURL(unlisted).href,
      pathToFileURL(nested).href, `${pathToFileURL(index).href}?v=1`,
      `${pathToFileURL(index).href}#fragment`, 'https://example.org/', 'http://127.0.0.1/',
      'ws://example.org/', 'data:text/html,hello', 'javascript:alert(1)',
      'file:///does-not-exist/index.html', 'not a URL'];
    // A hardlinked approved asset is rejected to avoid mutable aliasing.
    for (const url of allowed) assert.equal(isAllowedRendererRequest(url, renderer), !hardlinkCreated || !url.endsWith('/app.js'), url);
    for (const url of denied) assert.equal(isAllowedRendererRequest(url, renderer), false, url);
    if (aliasCreated) {
      assert.equal(isAllowedRendererRequest(pathToFileURL(alias).href, renderer), false, 'symlink alias');
      requestCases++;
    }
    requestCases += denied.length + allowed.length;
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
  // Verify the exact nonce-bound artifact emitted by real Electron on Windows.
  // This fixture only calls the pure file writer; it is not native runtime proof.
  const proofDir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-renderer-evidence-'));
  let evidenceCases = 0;
  try {
    const nonce = 'a'.repeat(32);
    const filename = path.join(proofDir, 'proof.json');
    // Regression: a raw success boolean without a renderer snapshot must never create native evidence.
    assert.throws(() => writeRendererEvidence(true, path.join(proofDir, 'bare-success.json'), 'c'.repeat(32)),
      /renderer snapshot/, 'boolean-only native proof must be rejected');
    evidenceCases++;
    const proof = { snapshot: good, blockers: [] };
    const evidence = writeRendererEvidence(proof, filename, nonce);
    assert.deepEqual(JSON.parse(fs.readFileSync(filename, 'utf8')), evidence); evidenceCases++;
    assert.equal(evidence.passed, false, 'plain Node must not claim a passing native Electron run'); evidenceCases++;
    assert.equal(evidence.rendererSnapshotValidated, true); evidenceCases++;
    assert.equal(evidence.primaryNavigationVerified, true); evidenceCases++;
    assert.equal(evidence.observedPrimaryPageCount, 9); evidenceCases++;
    assert.equal(evidence.nativeWindowsElectronVerified, false); evidenceCases++;
    assert.equal(evidence.actualElectronRuntime, false, 'plain Node must not claim Electron execution'); evidenceCases++;
    assert.equal(evidence.hardwareUsed, false); evidenceCases++;
    assert.equal(evidence.ecuWriteOrFlashPerformed, false); evidenceCases++;
    assert.throws(() => writeRendererEvidence(proof, filename, nonce), /EEXIST/); evidenceCases++;
    assert.throws(() => writeRendererEvidence(proof, 'relative.json', nonce), /Invalid/); evidenceCases++;
    assert.throws(() => writeRendererEvidence(proof, path.join(proofDir, 'bad.json'), 'bad'), /Invalid/); evidenceCases++;
    const failure = writeRendererEvidence({ snapshot: good, blockers: ['renderer-load-failed'] },
      path.join(proofDir, 'failed.json'), 'b'.repeat(32));
    assert.equal(failure.passed, false); evidenceCases++;
    assert.equal(failure.runtimeBlockerCount, 1); evidenceCases++;
    const invalidNavigation = writeRendererEvidence({ snapshot: { ...good, navigationProof: null }, blockers: [] },
      path.join(proofDir, 'invalid-navigation.json'), 'd'.repeat(32));
    assert.equal(invalidNavigation.rendererSnapshotValidated, false); evidenceCases++;
    assert.equal(invalidNavigation.primaryNavigationVerified, false); evidenceCases++;
    assert.equal(invalidNavigation.observedPrimaryPageCount, 0); evidenceCases++;
    assert.throws(() => writeRendererEvidence({ snapshot: good, blockers: [null] },
      path.join(proofDir, 'invalid-blockers.json'), 'e'.repeat(32)), /renderer snapshot/); evidenceCases++;
  } finally { fs.rmSync(proofDir, { recursive: true, force: true }); }
  const passed = cases.length + 11 + paintedCases.length + requestCases + consoleCases.length + 1 + 1 + expectedBootstrap.length + 8 + evidenceCases + 6;
  if (!quiet) console.log(`Isolated Electron renderer smoke: ${passed}/${passed} offline checks passed (no runtime or ECU access).`);
  return { passed, electronRuntimeVerified: false };
}
if (require.main === module) runRendererRuntimeSmokeSimulations();
module.exports = { runRendererRuntimeSmokeSimulations };
