'use strict';
// Synthetic PCM Hammer CLI events only; no adapter, PCM, or physical writes.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const Module = require('module');
const childProcess = require('child_process');

async function waitFor(predicate, timeoutMs = 5000) {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error('Synthetic CLI did not finish');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
}

async function runPcmHammerReadProofPromotionSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-proof-promotion-'));
  const tool = path.join(root, 'PCM-Hammer');
  const executable = path.join(tool, 'PcmHammerCLI');
  const project = path.join(root, 'project');
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  fs.mkdirSync(path.join(tool, 'Kernels'), { recursive: true });
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.writeFileSync(path.join(tool, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(tool, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }
  const flashPath = require.resolve('../src/flash');
  const originalLoad = Module._load;
  let intercept = false;
  const children = [];
  let FlashManager;
  try {
    delete require.cache[flashPath];
    Module._load = function(request, parent, isMain) {
      if (request === 'child_process' && parent?.filename === flashPath) return {
        ...childProcess,
        spawn: (...args) => {
          if (!intercept || args[0] !== executable) return childProcess.spawn(...args);
          const child = new EventEmitter();
          child.pid = 6500 + children.length;
          child.stdout = new EventEmitter();
          child.stderr = new EventEmitter();
          child.kill = () => true;
          children.push(child);
          return child;
        }
      };
      return originalLoad.apply(this, arguments);
    };
    ({ FlashManager } = require('../src/flash'));
  } finally { Module._load = originalLoad; }
  const imports = [];
  const identities = [];
  const completions = [];
  let failImport = false;
  let failIdentityImport = false;
  const manager = new FlashManager({
    platform: 'test', allowSimulatedCliPrefixArgs: true,
    dataRoot: () => path.join(root, 'data'),
    getActiveProject: () => ({ id: 'fixture', name: 'Synthetic P01', folder: project, controller: 'P01' }),
    getToolPath: () => tool,
    getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.8 } }),
    releasePort: async () => ({ released: true }),
    appendActivity: () => {}, emit: () => {},
    onReadComplete: async (...args) => { if (failImport) throw new Error('synthetic import failure'); imports.push(args); },
    onIdentifyComplete: async (...args) => { if (failIdentityImport) throw new Error('synthetic identity import failure'); identities.push(args); },
    onSessionComplete: async session => completions.push(session)
  });
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
    process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
    await manager.probe({ executable, prefixArgs: [mock] });
    manager.saveDevice('COM4');
    const prior = manager.saveConfig({
      lastSuccessfulOperation: 'readProperties', lastSuccessfulProfileId: 'prior-read-properties',
      lastSuccessfulAt: '2026-10-15T00:00:00.000Z'
    });
    const output = path.join(project, 'Originals', 'short-with-success-message.bin');
    intercept = true;
    await manager.start('read', { device: 'COM4', output, directPortHandoffAuthorized: true });
    assert.equal(children.length, 1);
    fs.writeFileSync(output, Buffer.alloc(211, 0x41));
    children[0].stdout.emit('data', Buffer.from('OSID: 9379910\nRead completed successfully\n'));
    children[0].emit('close', 0);
    await waitFor(() => !manager.session);
    const result = manager.getHistory().find(item => item.operation === 'read');
    assert(result && result.state === 'failed', 'short Full Read must fail even with a CLI success message');
    assert.equal(result.result?.success, false, 'partial Full Read must not retain CLI success after evidence rejection');
    assert.equal(result.stopCode, 'read-size-partial');
    assert.equal(imports.length, 0, 'short read must never import');
    assert.equal(identities.length, 0, 'failed Full Read must not promote incidental OSID output');
    assert(result.rejectedOutput && fs.existsSync(result.rejectedOutput), 'partial read must be quarantined');
    assert.equal(manager.getConfig().lastSuccessfulOperation, prior.lastSuccessfulOperation,
      'failed Full Read must not be recorded as the last successful CLI operation');
    assert.equal(manager.getConfig().lastSuccessfulProfileId, prior.lastSuccessfulProfileId,
      'failed Full Read must not promote its CLI profile');
    assert.equal(manager.getConfig().lastSuccessfulAt, prior.lastSuccessfulAt,
      'failed Full Read must not update the successful-operation timestamp');
    assert.equal(result.progress < 100, true, 'failed Full Read must not claim 100% completion');
    assert.equal(completions.length, 1);

    // A complete 512-KB read must still promote the proven profile normally.
    const goodOutput = path.join(project, 'Originals', 'verified.bin');
    await manager.start('read', { device: 'COM4', output: goodOutput, directPortHandoffAuthorized: true });
    fs.writeFileSync(goodOutput, Buffer.alloc(524288, 0x52));
    children[1].stdout.emit('data', Buffer.from('Read completed successfully\n'));
    children[1].emit('close', 0);
    await waitFor(() => !manager.session);
    assert.equal(imports.length, 1, 'complete read should import');
    assert.equal(manager.getHistory()[0].state, 'complete');
    assert.equal(manager.getConfig().lastSuccessfulOperation, 'read', 'verified Full Read may promote profile');
    const verifiedAt = manager.getConfig().lastSuccessfulAt;
    const verifiedProfile = manager.getConfig().lastSuccessfulProfileId;

    // Even a complete file is not a completed workflow when the backup import
    // fails; do not overwrite the last successful CLI operation timestamp.
    failImport = true;
    const importFailedOutput = path.join(project, 'Originals', 'import-failed.bin');
    await manager.start('read', { device: 'COM4', output: importFailedOutput, directPortHandoffAuthorized: true });
    fs.writeFileSync(importFailedOutput, Buffer.alloc(524288, 0x53));
    children[2].stdout.emit('data', Buffer.from('OSID: 9379910\nRead completed successfully\n'));
    children[2].emit('close', 0);
    await waitFor(() => !manager.session);
    const importFailed = manager.getHistory()[0];
    assert.equal(importFailed.state, 'failed');
    assert.equal(importFailed.result?.success, false, 'failed backup import must revoke successful read evidence');
    assert.equal(importFailed.stopCode, 'read-import-failed');
    assert.equal(importFailed.outputInfo?.valid, false, 'failed import cannot retain verified output evidence');
    assert.equal(importFailed.outputInfo?.code, 'read-import-failed');
    assert.equal(identities.length, 0, 'failed backup import must not promote incidental identity evidence');
    assert(importFailed.rejectedOutput && fs.existsSync(importFailed.rejectedOutput), 'failed import must quarantine its unadmitted BIN');
    assert(!fs.existsSync(importFailedOutput), 'failed import must not leave an apparently accepted BIN at the original destination');
    assert.equal(manager.getConfig().lastSuccessfulAt, verifiedAt, 'failed import must not update last success timestamp');
    assert.equal(manager.getConfig().lastSuccessfulProfileId, verifiedProfile, 'failed import must not replace proven profile');
    assert(importFailed.progress < 100, 'failed import cannot claim complete progress');

    // A cancellation request is authoritative even if a child races to a
    // nominal exit 0 with a complete-looking BIN and success text. It must
    // not import or promote the read as verified evidence.
    failImport = false;
    const cancelledOutput = path.join(project, 'Originals', 'cancelled-after-complete.bin');
    await manager.start('read', { device: 'COM4', output: cancelledOutput, directPortHandoffAuthorized: true });
    fs.writeFileSync(cancelledOutput, Buffer.alloc(524288, 0x54));
    children[3].stdout.emit('data', Buffer.from('Read completed successfully\n'));
    await manager.cancel();
    children[3].emit('close', 0);
    await waitFor(() => !manager.session);
    const cancelled = manager.getHistory()[0];
    assert.equal(cancelled.state, 'cancelled', 'cancelled read must not be reported as successful');
    assert.equal(imports.length, 1, 'cancelled full-size BIN must not be imported');
    assert.equal(cancelled.result.success, false, 'cancelled read result cannot advertise success');
    assert.equal(cancelled.stopCode, 'read-cancelled');
    assert.equal(manager.getConfig().lastSuccessfulAt, verifiedAt, 'cancelled read must not promote CLI success');
    assert(cancelled.rejectedOutput && fs.existsSync(cancelled.rejectedOutput), 'cancelled read must retain rejected evidence');

    // The same cancellation boundary applies to Read Properties: a valid
    // OSID line must not be promoted into a project after cancellation.
    await manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    children[4].stdout.emit('data', Buffer.from('PCM Hammer 2.0\nOSID: 9379910\n'));
    await manager.cancel();
    children[4].emit('close', 0);
    await waitFor(() => !manager.session);
    const cancelledProperties = manager.getHistory()[0];
    assert.equal(cancelledProperties.state, 'cancelled');
    assert.equal(cancelledProperties.result.success, false);
    assert.equal(cancelledProperties.stopCode, 'properties-cancelled');
    assert.equal(identities.length, 0, 'cancelled Read Properties must not import identity evidence');
    assert.equal(manager.getConfig().lastSuccessfulAt, verifiedAt);

    // Rejected Full Read files must never overwrite a previous rejected BIN.
    // beta.97 used a timestamp-only rename destination. A second rejection
    // in the same millisecond can silently replace an earlier backup on NTFS
    // or POSIX. Pin the clock and create that exact pre-existing destination.
    const collisionOutput = path.join(project, 'Originals', 'collision-partial.bin');
    await manager.start('read', { device: 'COM4', output: collisionOutput, directPortHandoffAuthorized: true });
    const fixedTime = 1770000000000;
    const oldRejected = `${collisionOutput}.rejected-${fixedTime}`;
    const oldRejectedBytes = Buffer.from('existing rejected read must survive unchanged');
    fs.writeFileSync(oldRejected, oldRejectedBytes);
    fs.writeFileSync(collisionOutput, Buffer.alloc(103, 0x61));
    children[5].stdout.emit('data', Buffer.from('Read completed successfully\n'));
    const originalNow = Date.now;
    try {
      Date.now = () => fixedTime;
      children[5].emit('close', 0);
      await waitFor(() => !manager.session);
    } finally { Date.now = originalNow; }
    const collision = manager.getHistory()[0];
    assert.equal(collision.state, 'failed');
    assert.equal(collision.stopCode, 'read-size-partial');
    assert.deepEqual(fs.readFileSync(oldRejected), oldRejectedBytes,
      'an existing rejected BIN must never be overwritten by a later failed read');
    assert(collision.rejectedOutput && collision.rejectedOutput !== oldRejected && fs.existsSync(collision.rejectedOutput),
      'new rejected evidence must use a distinct, existing quarantine destination');
    assert(!fs.existsSync(collisionOutput), 'failed read must not remain at the normal backup path');
    assert.equal(imports.length, 1, 'partial read cannot invoke the import callback');

    // Read Properties may print a plausible OSID before an explicit CLI error.
    // A nonzero exit must never promote that identity into the active project.
    await manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    assert.equal(children.length, 7);
    children[6].stdout.emit('data', Buffer.from('OSID: 9379910\nRead Properties failed\n'));
    children[6].emit('close', 1);
    await waitFor(() => !manager.session);
    const failedProperties = manager.getHistory()[0];
    assert.equal(failedProperties.state, 'failed');
    assert.equal(failedProperties.result?.success, false, 'failed Read Properties must not retain a successful result');
    assert.equal(identities.length, 0, 'failed Read Properties cannot promote identity from an error log');
    assert.equal(manager.getConfig().lastSuccessfulAt, verifiedAt,
      'failed Read Properties cannot promote a successful CLI timestamp');

    // Successful Read Properties remains admitted after a clean CLI exit.
    await manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    assert.equal(children.length, 8);
    children[7].stdout.emit('data', Buffer.from('OSID: 9379910\nRead Properties completed\n'));
    children[7].emit('close', 0);
    await waitFor(() => !manager.session);
    assert.equal(manager.getHistory()[0].state, 'complete');
    assert.equal(identities.length, 1, 'successful Read Properties still admits identity');

    // A successful CLI exit is not an accepted Read Properties workflow if
    // the project identity callback rejects the evidence. Its persisted result
    // must agree with failed session state and must not promote a CLI profile.
    failIdentityImport = true;
    await manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    assert.equal(children.length, 9);
    children[8].stdout.emit('data', Buffer.from('OSID: 9379910\nRead Properties completed\n'));
    children[8].emit('close', 0);
    await waitFor(() => !manager.session);
    const rejectedIdentity = manager.getHistory()[0];
    assert.equal(rejectedIdentity.state, 'failed');
    assert.equal(rejectedIdentity.stopCode, 'identity-import-failed');
    assert.equal(rejectedIdentity.result?.success, false, 'failed identity import must revoke CLI success evidence');
    assert.equal(rejectedIdentity.result?.stopCode, 'identity-import-failed');
    assert.equal(identities.length, 1, 'failed identity callback must not admit additional identity');

    console.log('✓ Read proof promotion: failed operations cannot import backup or identity; verified operations still admit evidence (synthetic only)');
    return { passed: 42, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
    delete require.cache[flashPath];
  }
}
if (require.main === module) runPcmHammerReadProofPromotionSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runPcmHammerReadProofPromotionSimulations };
