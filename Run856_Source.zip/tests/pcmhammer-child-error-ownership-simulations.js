'use strict';
// Synthetic child-process events only: no serial adapter, ECU, or real PCM Hammer.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { EventEmitter } = require('events');
const Module = require('module');
const childProcess = require('child_process');

async function waitFor(predicate, timeoutMs = 4000) {
  const started = Date.now();
  while (!predicate()) {
    if (Date.now() - started > timeoutMs) throw new Error('Timed out waiting for synthetic child process finalization.');
    await new Promise(resolve => setTimeout(resolve, 10));
  }
}

async function runPcmHammerChildErrorOwnershipSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-pcmhammer-child-error-'));
  const portable = path.join(root, 'PCM-Hammer');
  const project = path.join(root, 'project');
  const executable = path.join(portable, 'PcmHammerCLI');
  const mock = path.join(__dirname, 'mock-pcmhammer-cli.js');
  fs.mkdirSync(path.join(portable, 'Kernels'), { recursive: true });
  fs.mkdirSync(path.join(project, 'Originals'), { recursive: true });
  fs.writeFileSync(path.join(portable, 'Kernels', 'Kernel-P01.bin'), Buffer.alloc(64, 1));
  fs.writeFileSync(path.join(portable, 'Kernels', 'Loader-P01.bin'), Buffer.alloc(64, 2));
  try { fs.symlinkSync(process.execPath, executable); } catch { fs.copyFileSync(process.execPath, executable); }

  const flashPath = require.resolve('../src/flash');
  const originalLoad = Module._load;
  let intercept = false;
  const children = [];
  const fakeSpawn = (...args) => {
    if (!intercept || args[0] !== executable) return childProcess.spawn(...args);
    const child = new EventEmitter();
    child.pid = 4300 + children.length;
    child.stdout = new EventEmitter();
    child.stderr = new EventEmitter();
    child.kill = () => true;
    children.push(child);
    return child;
  };
  let FlashManager;
  try {
    delete require.cache[flashPath];
    Module._load = function(request, parent, isMain) {
      if (request === 'child_process' && parent?.filename === flashPath) return { ...childProcess, spawn: fakeSpawn };
      return originalLoad.apply(this, arguments);
    };
    ({ FlashManager } = require('../src/flash'));
  } finally { Module._load = originalLoad; }
  const active = { id: 'synthetic', name: 'Synthetic P01', folder: project, controller: 'P01' };
  const released = [];
  const owned = [];
  const completions = [];
  const readImports = [];
  const manager = new FlashManager({
    platform: 'test', allowSimulatedCliPrefixArgs: true,
    dataRoot: () => path.join(root, 'data'), getActiveProject: () => active,
    getToolPath: () => portable, getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.8 } }),
    releasePort: async () => ({ released: true }), appendActivity: () => {}, emit: () => {},
    registerOwnedProcess: pid => { owned.push(pid); },
    releaseOwnedProcess: pid => { released.push(pid); },
    onSessionComplete: async session => completions.push(session),
    onReadComplete: async (...args) => readImports.push(args)
  });
  try {
    process.env.PCMHAMMER_MOCK_PROFILE = 'real-cli';
    process.env.PCMHAMMER_MOCK_SCENARIO = 'success';
    process.env.PCMHAMMER_MOCK_REQUIRE_KERNEL = '1';
    await manager.probe({ executable, prefixArgs: [mock] });
    manager.saveDevice('COM4');
    intercept = true;
    await manager.start('readProperties', { device: 'COM4', directPortHandoffAuthorized: true });
    assert.equal(children.length, 1, 'only synthetic CLI is launched');
    const child = children[0];
    assert.equal(manager.portOwner.owner, 'pcmhammer');
    assert(owned.includes(child.pid), 'child PID should be registered as owner');
    child.emit('error', new Error('synthetic Windows child-process error before close'));
    await new Promise(resolve => setImmediate(resolve));
    assert(manager.session, 'error alone must not clear active PCM Hammer session');
    assert.equal(manager.portOwner.owner, 'pcmhammer', 'COM port remains owned until close');
    assert(!released.includes(child.pid), 'error alone is not process-exit evidence');
    await assert.rejects(manager.withExclusiveExternalPortAccess('Bluetooth repair', async () => true, { requestRecovery: false }),
      error => error.code === 'pcmhammer-exit-pending');
    await assert.rejects(manager.start('readProperties', { device: 'COM4' }),
      error => error.code === 'operation-running');
    assert.equal(completions.length, 0, 'no completion before close');
    child.emit('close', null);
    await waitFor(() => !manager.session);
    assert(released.includes(child.pid), 'release ownership only after close');
    assert.equal(manager.portOwner.owner, 'idle');
    const result = manager.getHistory().find(item => item.operation === 'readProperties');
    assert(result && result.state === 'failed');
    assert.equal(result.stopCode, 'cli-process-error');
    assert.equal(completions.length, 1);
    assert.equal(children.length, 1, 'no profile/port retries after child error');

    // Interrupted Full Read must preserve its partial file as rejected evidence,
    // never import it as a good backup, and never launch another CLI attempt.
    const output = path.join(project, 'Originals', 'interrupted-read.bin');
    await manager.start('read', { device: 'COM4', output, directPortHandoffAuthorized: true });
    assert.equal(children.length, 2);
    const readChild = children[1];
    fs.writeFileSync(output, Buffer.alloc(211, 0x42));
    readChild.emit('error', new Error('synthetic read process error'));
    await new Promise(resolve => setImmediate(resolve));
    assert(manager.session && manager.portOwner.owner === 'pcmhammer');
    assert(fs.existsSync(output), 'partial output remains untouched while process may own COM');
    assert.equal(readImports.length, 0);
    readChild.emit('close', null);
    await waitFor(() => !manager.session);
    const read = manager.getHistory().find(item => item.operation === 'read');
    assert(read && read.state === 'failed');
    assert.equal(read.stopCode, 'cli-process-error');
    assert(read.rejectedOutput && fs.existsSync(read.rejectedOutput), 'partial read preserved as rejected evidence');
    assert.equal(fs.statSync(read.rejectedOutput).size, 211);
    assert.equal(readImports.length, 0, 'interrupted Full Read must never be imported');
    assert.equal(children.length, 2, 'no retry after Full Read child error');
    assert.equal(manager.portOwner.owner, 'idle');
    console.log('✓ PCM Hammer child error holds COM until close and preserves interrupted read evidence (synthetic)');
    return { passed: true, scenarios: 13 };
  } finally {
    intercept = false;
    delete require.cache[flashPath];
    fs.rmSync(root, { recursive: true, force: true });
  }
}

if (require.main === module) runPcmHammerChildErrorOwnershipSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runPcmHammerChildErrorOwnershipSimulations };
