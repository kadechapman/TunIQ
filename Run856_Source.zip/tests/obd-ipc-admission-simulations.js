const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { FlashManager } = require('../src/flash');
const { createObdIpcAdmission } = require('../src/obd-ipc-admission');

async function runObdIpcAdmissionSimulations() {
  const source = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  for (const [channel, action] of [
    ['device:connect', 'connect(payload)'],
    ['device:disconnect', 'disconnect()'],
    ['device:doctor-run', 'doctorRun(payload)'],
    ['device:sample', 'sample()'],
    ['logger:start', 'startLog(payload)']
  ]) {
    assert(source.includes(`ipcMain.handle('${channel}', async `), `${channel} IPC must exist`);
    assert(source.includes(`obdIpcAdmission.${action}`), `${channel} must use exclusive admission`);
  }
  let calls = 0;
  const obd = {
    connect: async () => { calls++; return 'connected'; },
    disconnect: async () => { calls++; return 'disconnected'; },
    runConnectionDoctor: async () => { calls++; return 'doctor'; },
    sample: async () => { calls++; return 'sample'; },
    startLog: () => { calls++; return 'logging'; }
  };
  const flash = new FlashManager({
    dataRoot: () => path.join(__dirname, '..'), getActiveProject: () => null,
    getToolPath: () => '', getDeviceStatus: () => ({}), releasePort: async () => {},
    appendActivity: () => {}, emit: () => {}, platform: 'test'
  });
  const handlers = createObdIpcAdmission(flash, obd);
  const operations = [() => handlers.connect({ port: 'COM4' }), () => handlers.disconnect(), () => handlers.doctorRun({ port: 'COM4' }),
    () => handlers.sample(), () => handlers.startLog({})];

  // A running Full Read must not be cancelled, and none of the OBD handlers
  // may probe or sample the adapter while PCM Hammer still owns it.
  let cancelled = 0;
  flash.session = { operation: 'read', cancelRequested: false };
  flash.cancel = async () => { cancelled++; };
  for (const operation of operations) {
    await assert.rejects(operation(), e => e.code === 'pcmhammer-exit-pending');
  }
  assert.equal(calls, 0);
  assert.equal(cancelled, 0);
  assert.equal(flash.session.cancelRequested, false);
  flash.session = null;

  // The synchronous admission latch must protect asynchronous OBD connection
  // before the first await, including from a competing PCM Hammer start.
  let finishConnect;
  const pending = new Promise(resolve => { finishConnect = resolve; });
  obd.connect = async () => { calls++; await pending; return 'connected'; };
  const connecting = handlers.connect({ port: 'COM4' });
  assert.equal(flash.externalPortAccessPending, true);
  await assert.rejects(handlers.doctorRun({}), e => e.code === 'external-com-workflow-active');
  await assert.rejects(handlers.disconnect(), e => e.code === 'external-com-workflow-active');
  await assert.rejects(flash.start('readProperties', {}), e => e.code === 'external-com-workflow-active');
  assert.equal(calls, 1);
  finishConnect();
  assert.equal(await connecting, 'connected');
  assert.equal(flash.externalPortAccessPending, false);
  assert.equal(await handlers.sample(), 'sample');
  assert.equal(await handlers.disconnect(), 'disconnected');
  assert.equal(await handlers.startLog({}), 'logging');
  assert.equal(await handlers.doctorRun({}), 'doctor');

  // Failed connection attempts cannot strand the exclusive latch.
  obd.connect = async () => { throw new Error('synthetic COM failure'); };
  await assert.rejects(handlers.connect({}), /synthetic COM failure/);
  assert.equal(flash.externalPortAccessPending, false);
  flash.startPending = true;
  await assert.rejects(handlers.sample(), e => e.code === 'pcmhammer-exit-pending');
  flash.startPending = false;
  console.log('✓ 5 guarded IPC entrypoints, active-read non-cancellation, concurrent admission, and failure cleanup');
  return { passed: true, scenarios: 5 };
}
if (require.main === module) runObdIpcAdmissionSimulations().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = { runObdIpcAdmissionSimulations };
