'use strict';
// Source-only request-triage regression. These are synthetic project facts,
// not verified ECU identity, addresses, calibration values, or flash evidence.
const assert = require('node:assert/strict');
const { reviewP01Request } = require('../src/p01-request-review');
const project = { id: 'fixture-ls53', name: 'Synthetic LS 5.3', controller: 'P01', os: '12587603' };
const base = 'Disable VATS and set electric fans on at 210 F and off at 190 F.';
const cases = [
  { name: 'explicit fan-output commissioning is separate', request: `${base} Enable the ECM fan outputs.`, blocker: 'fan-output-enable' },
  { name: 'negated fan output enablement requires clarification', request: `${base} Do not enable the ECM fan outputs.`, blocker: 'fan-output-intent-contradiction' },
  { name: 'reported disabled fan output is not solved by temperatures', request: `${base} ECM fan output enable flag is false.`, blocker: 'fan-output-unverified' },
  { name: 'physical knock sensor removal requires diagnostics', request: `${base} Both knock sensors were pulled.`, blocker: 'knock-sensor-delete' },
  { name: 'missing knock sensors require diagnostics', request: `${base} Both knock sensors are physically missing.`, blocker: 'knock-sensor-delete' },
  { name: 'unplugged knock sensors require diagnostics', request: `${base} Both knock sensors are still unplugged.`, blocker: 'knock-sensor-delete' },
  { name: 'direct knock sensor delete request is not silently accepted', request: 'Delete knock sensors from my LS 5.3.', blocker: 'knock-sensor-delete' },
  { name: 'passively zeroed knock retard requires diagnostics', request: `${base} Knock retard was zeroed out.`, blocker: 'knock-sensor-delete' },
  { name: 'passively zeroed knock retard tables require diagnostics', request: `${base} Knock retard tables were zeroed out.`, blocker: 'knock-sensor-delete' },
  { name: 'knock retard disable request after removal requires diagnostics', request: 'Turn off knock retard because I removed the knock sensors.', blocker: 'knock-sensor-delete' },
  { name: 'conflicting controller OS prevents partial VATS proposal', request: `${base} My PCM actually runs 12212156.`, blocker: 'os-request-conflict' },
  { name: 'physical Stage 2 cam needs exact cam card and review', request: `${base} Tune my installed LSX Stage 2 cam.`, blocker: 'physical-camshaft-tune' },
  { name: 'knock DTC suppression is not automatic', request: `${base} Disable knock sensor DTC P0327 reporting.`, blocker: 'knock-diagnostic-suppression' },
  { name: 'contradictory VATS preservation is blocked', request: `${base} Do not disable VATS.`, blocker: 'vats-intent-contradiction' },
];
for (const { name, request, blocker } of cases) {
  const result = reviewP01Request({ activeProject: project, request });
  assert.equal(result.ready, false, name);
  assert(result.unresolvedRequests.some(x => x.type === blocker), `${name}: missing ${blocker}`);
  console.log(`PASS ${name}: ${blocker}`);
}
// Regression: parsed fan temperature targets are only user requests, not proof
// that the independent ECM output-enable circuit is commissioned.
const fanReview = reviewP01Request({ activeProject: project, request: `${base} Enable the ECM fan outputs.` });
assert.equal(fanReview.parsed.intents.find(x => x.type === 'fan-control')?.fanOn, 210);
assert.equal(fanReview.parsed.intents.find(x => x.type === 'fan-control')?.fanOff, 190);
assert.equal(fanReview.ready, false);
assert(fanReview.unresolvedRequests.some(x => x.type === 'fan-output-enable'));
console.log('PASS fan thresholds remain unverified requests; output commissioning separately blocked');
// Combined requests must preserve *both* independent blockers. A fan-output
// request must not mask physically removed knock sensors or imply protection
// was disabled as part of an otherwise supported VATS/fan proposal.
const combinedReview = reviewP01Request({
  activeProject: project,
  request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing.`
});
assert.equal(combinedReview.ready, false);
for (const type of ['fan-output-enable', 'knock-sensor-delete']) {
  assert(combinedReview.unresolvedRequests.some(item => item.type === type), `combined request missing ${type}`);
}
console.log('PASS combined fan commissioning and missing knock sensors retain independent blockers');

// A project with an unknown OS must not inherit the synthetic fixture's OS.
// The OS-identity gate and independent hardware diagnostics must all survive
// one combined request; no guessed address or fan threshold is commissioned.
const unknownOsReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing.`
});
assert.equal(unknownOsReview.ready, false);
assert(unknownOsReview.missingSafetyFacts.some(item => item.includes('operating-system (OS) ID')));
for (const type of ['fan-output-enable', 'knock-sensor-delete']) {
  assert(unknownOsReview.unresolvedRequests.some(item => item.type === type), `unknown OS request missing ${type}`);
}
console.log('PASS unknown OS and combined fan/knock blockers remain independent');

// Run850: A physically installed cam and a missing knock-feedback circuit
// remain independent review items even when VATS and fan requests coexist.
// These fixture temperatures and OS labels are NOT verified ECM facts.
const combinedCamKnockReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Enable the ECM fan outputs. Tune my installed LSX Stage 2 cam. Both knock sensors are physically missing.`
});
assert.equal(combinedCamKnockReview.ready, false);
assert(combinedCamKnockReview.missingSafetyFacts.some(item => item.includes('operating-system (OS) ID')));
for (const type of ['fan-output-enable', 'physical-camshaft-tune', 'knock-sensor-delete']) {
  assert(combinedCamKnockReview.unresolvedRequests.some(item => item.type === type), `combined cam/knock request missing ${type}`);
}
console.log('PASS Run850 unknown OS, fan output, physical cam, and knock protection independently blocked');


console.log(`${cases.length} owner LS 5.3 request safety fixtures passed (no hardware)`);

// A physical cam request without a supplied cam card cannot be inferred from
// the Stage 2 product name, and must not clear independent fan/knock gates.
const combinedCamReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
});
assert.equal(combinedCamReview.ready, false);
assert(combinedCamReview.missingSafetyFacts.some(item => item.includes('operating-system (OS) ID')));
for (const type of ['physical-camshaft-tune', 'fan-output-enable', 'knock-sensor-delete']) {
  assert(combinedCamReview.unresolvedRequests.some(item => item.type === type), `combined cam request missing ${type}`);
}
console.log('PASS unknown OS and missing physical cam-card data retain independent fan/knock blockers');

// Placeholder OS values are never evidence of an exact-OS calibration match.
// Keep independent fan/knock/cam blockers even when the project OS is numeric.
for (const invalidOs of ['', '00000000', '1258760X', '12587603 guessed']) {
  const result = reviewP01Request({
    activeProject: { ...project, os: invalidOs },
    request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
  });
  assert.equal(result.ready, false, `invalid OS ${JSON.stringify(invalidOs)} must not be ready`);
  assert(result.missingSafetyFacts.some(item => item.includes('operating-system (OS) ID')),
    `invalid OS ${JSON.stringify(invalidOs)} must require identification`);
  for (const type of ['fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
    assert(result.unresolvedRequests.some(item => item.type === type),
      `invalid OS ${JSON.stringify(invalidOs)} lost ${type}`);
  }
  console.log(`PASS invalid OS ${JSON.stringify(invalidOs)} preserves independent blockers`);
}

// Suppressing a knock diagnostic is a separate safety request from physical
// sensor removal. Neither may be silently cleared by unrelated VATS/fan work.
const combinedKnockDtcReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing. Disable knock sensor DTC P0327 reporting.`
});
assert.equal(combinedKnockDtcReview.ready, false);
assert(combinedKnockDtcReview.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['fan-output-enable', 'knock-sensor-delete', 'knock-diagnostic-suppression']) {
  assert(combinedKnockDtcReview.unresolvedRequests.some(x => x.type === type),
    `combined knock DTC request lost independent blocker ${type}`);
}
console.log('PASS physical knock removal and DTC suppression remain separately blocked');

// Conflicting VATS instructions must not erase separate physical hardware
// blockers, even when the controller OS has not been authenticated.
const conflictingVatsCombinedReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Do not disable VATS. Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
});
assert.equal(conflictingVatsCombinedReview.ready, false);
assert(conflictingVatsCombinedReview.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['vats-intent-contradiction', 'fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(conflictingVatsCombinedReview.unresolvedRequests.some(x => x.type === type),
    `conflicting VATS request lost independent blocker ${type}`);
}
console.log('PASS contradictory VATS and unknown OS retain independent fan, knock and cam blockers');

// Run553: A negated fan-output instruction must not swallow other independent
// hardware and calibration blockers in a combined owner request.
const negatedFanCombinedReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Do not enable the ECM fan outputs. Both knock sensors were pulled. Tune my installed LSX Stage 2 cam.`
});
assert.equal(negatedFanCombinedReview.ready, false);
assert(negatedFanCombinedReview.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['fan-output-intent-contradiction', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(negatedFanCombinedReview.unresolvedRequests.some(x => x.type === type),
    `negated fan combined request lost ${type}`);
}
console.log('PASS negated fan commissioning retains independent knock/cam and OS blockers');

// Run554: A fan temperature request plus a reported disabled output flag
// must retain the output-hardware blocker even when an OS-shaped project
// identifier and syntactically valid temperatures are present. This does not
// establish actual OS identity or a safe fan calibration.
const disabledFanFlagReview = reviewP01Request({
  activeProject: project,
  request: `${base} ECM fan output enable flag is false. Tune my installed LSX Stage 2 cam.`
});
assert.equal(disabledFanFlagReview.ready, false);
for (const type of ['fan-output-unverified', 'physical-camshaft-tune']) {
  assert(disabledFanFlagReview.unresolvedRequests.some(x => x.type === type),
    `disabled output flag request lost ${type}`);
}
assert.equal(disabledFanFlagReview.parsed.intents.find(x => x.type === 'fan-control')?.fanOn, 210);
assert.equal(disabledFanFlagReview.parsed.intents.find(x => x.type === 'fan-control')?.fanOff, 190);
console.log('PASS fan temperatures do not commission a disabled ECM fan output or calibrate an unspecified cam');

// Run564: An explicitly conflicting OS ID must not be resolved by accepting
// the project metadata, even when other requested modifications are present.
// This checks request triage only; neither ID is authenticated ECU evidence.
const conflictingOsCombinedReview = reviewP01Request({
  activeProject: project,
  request: `${base} My PCM actually runs 12212156. Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
});
assert.equal(conflictingOsCombinedReview.ready, false);
for (const type of ['os-request-conflict', 'fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(conflictingOsCombinedReview.unresolvedRequests.some(x => x.type === type),
    `conflicting OS request lost independent blocker ${type}`);
}
console.log('PASS conflicting OS cannot bypass fan commissioning, knock diagnostics, or cam-card requirements');

// Run565: A conflicting OS claim plus a request to suppress a knock DTC
// must preserve BOTH physical sensor and diagnostic suppression blockers.
// This is request-triage evidence, not a validated ECM calibration.
const conflictingOsKnockDtcReview = reviewP01Request({
  activeProject: project,
  request: `${base} My PCM actually runs 12212156. Enable the ECM fan outputs. Both knock sensors are physically missing. Disable knock sensor DTC P0327 reporting. Tune my installed LSX Stage 2 cam.`
});
assert.equal(conflictingOsKnockDtcReview.ready, false);
for (const type of ['os-request-conflict', 'fan-output-enable', 'knock-sensor-delete', 'knock-diagnostic-suppression', 'physical-camshaft-tune']) {
  assert(conflictingOsKnockDtcReview.unresolvedRequests.some(x => x.type === type),
    `conflicting OS + knock DTC request lost independent blocker ${type}`);
}
console.log('PASS conflicting OS preserves separate physical knock and diagnostic-suppression blockers');

// Run568: A claimed cam-card specification in free-form user text is not a
// validated physical cam card or an exact-OS calibration definition. Keep
// the cam, fan-output, and knock-sensor reviews independent and fail closed.
const claimedCamCardReview = reviewP01Request({
  activeProject: project,
  request: `${base} Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam; cam card says 220/224 duration, .550/.550 lift, 112 LSA.`
});
assert.equal(claimedCamCardReview.ready, false);
for (const type of ['physical-camshaft-tune', 'fan-output-enable', 'knock-sensor-delete']) {
  assert(claimedCamCardReview.unresolvedRequests.some(item => item.type === type),
    `unverified free-text cam-card claim lost independent ${type} blocker`);
}
console.log('PASS unverified free-text cam specs do not authorize physical cam calibration or bypass fan/knock review');

// Run569: Conflicting fan threshold instructions must not authorize a partial
// VATS/fan proposal or erase independent physical knock/cam blockers.
const contradictoryFanThresholdReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Do not change the fan temperatures. Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
});
assert.equal(contradictoryFanThresholdReview.ready, false);
assert(contradictoryFanThresholdReview.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['fan-threshold-intent-contradiction', 'fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(contradictoryFanThresholdReview.unresolvedRequests.some(x => x.type === type),
    `conflicting fan thresholds lost independent blocker ${type}`);
}
console.log('PASS contradictory fan thresholds retain OS, output, knock and cam blockers');

// Run727: Explicit requests to turn off knock protection or ignore knock
// faults must remain blocked even when accompanied by a recognizable VATS
// instruction. A parser regression must never silently approve the subset.
for (const [request, expected] of [
  ['Disable VATS. Turn off knock protection.', ['knock-sensor-delete']],
  ['Disable VATS. Disable knock retard.', ['knock-sensor-delete']],
  ['Disable VATS. Ignore knock sensor faults.', ['knock-sensor-delete', 'knock-diagnostic-suppression']]
]) {
  const result = reviewP01Request({ activeProject: project, request });
  assert.equal(result.ready, false, `unsafe knock request approved: ${request}`);
  for (const type of expected) {
    assert(result.unresolvedRequests.some(item => item.type === type),
      `knock protection request lost ${type}: ${request}`);
  }
  console.log(`PASS Run727 knock-protection regression: ${request}`);
}

// A syntactically reviewed request never certifies BIN/XDF or hardware evidence.
const triageOnly = reviewP01Request({ activeProject: project, request: base });
assert.equal(triageOnly.calibrationEvidenceVerified, false);
assert.equal(triageOnly.readyForCalibration, false);
console.log('PASS request review cannot claim calibration evidence or hardware readiness');

// Run751: A completed request triage must never be promoted to calibration
// readiness just because the project contains an OS-shaped identifier.
// Fan temperature requests alone also do not prove ECM output commissioning.
for (const request of ['Disable VATS.', 'Set fans on at 210 F and off at 190 F.']) {
  const reviewed = reviewP01Request({ activeProject: project, request });
  assert.equal(reviewed.ready, true, `expected triage-only readiness for ${request}`);
  assert.equal(reviewed.calibrationEvidenceVerified, false, 'no BIN/XDF/ECM proof in fixture');
  assert.equal(reviewed.readyForCalibration, false, 'triage must not authorize calibration');
  assert(reviewed.protections.some(text => /exact OS-matched writable definition/i.test(text)));
  console.log(`PASS triage-only readiness cannot authorize calibration: ${request}`);
}

// Run782: Present-tense passive knock-retard zeroing must be flagged independently.
for (const request of [
  'Disable VATS. Knock retard tables are zeroed out.',
  'Disable VATS. KR values are zeroed.'
]) {
  const reviewed = reviewP01Request({ activeProject: project, request });
  assert.equal(reviewed.ready, false, `passive knock bypass was admitted: ${request}`);
  assert(reviewed.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
    `passive knock bypass was silently omitted: ${request}`);
}
console.log('PASS Run782 present-tense passive knock bypass requires independent diagnostic review');

// Run784: Descriptive zero-valued knock tables must not be silently dropped.
for (const request of [
  'Disable VATS. KR tables are all zeros.',
  'Disable VATS. Knock retard values read 0.',
  'Disable VATS. Knock control gain remains zero.'
]) {
  const reviewed = reviewP01Request({ activeProject: project, request });
  assert.equal(reviewed.ready, false, `zero-valued knock state admitted: ${request}`);
  assert(reviewed.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
    `zero-valued knock state silently omitted: ${request}`);
}
console.log('PASS Run784 zero-valued knock calibration descriptions require review');

// Run785: Content-based zero table descriptions require knock diagnostics.
for (const request of [
  'Disable VATS. KR tables contain only zeros.',
  'Disable VATS. Knock retard tables are filled with 0.',
  'Disable VATS. Knock control values consist of zeros.'
]) {
  const reviewed = reviewP01Request({ activeProject: project, request });
  assert.equal(reviewed.ready, false, `zero-filled knock table admitted: ${request}`);
  assert(reviewed.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
    `zero-filled knock table silently omitted: ${request}`);
}
console.log('PASS Run785 zero-filled knock table descriptions require review');

// Run787: Entirely-zero knock table contents require independent diagnostics.
for (const request of [
  'Disable VATS. KR tables consist of entirely zeros.',
  'Disable VATS. Knock retard tables are filled with entirely zeros.'
]) {
  const reviewed = reviewP01Request({ activeProject: project, request });
  assert.equal(reviewed.ready, false, `entirely-zero knock table admitted: ${request}`);
  assert(reviewed.unresolvedRequests.some(item => item.type === 'knock-sensor-delete'),
    `entirely-zero knock table silently omitted: ${request}`);
}
console.log('PASS Run787 entirely-zero knock table descriptions require review');

// Run851: A matching user-typed OS label and requested fan thresholds are
// not authenticated controller evidence. A simultaneous knock-retard bypass
// report and missing cam card must remain independently visible. This is
// source-only triage and must never be interpreted as flash authorization.
const ownerCompositeReview851 = reviewP01Request({
  activeProject: project,
  request: `${base} OS ID: 12587603. Enable the ECM fan outputs. ` +
    'KR tables contain only zeros. Tune my installed LSX Stage 2 cam.'
});
assert.equal(ownerCompositeReview851.ready, false);
assert.equal(ownerCompositeReview851.calibrationEvidenceVerified, false);
assert.equal(ownerCompositeReview851.readyForCalibration, false);
for (const type of ['fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(ownerCompositeReview851.unresolvedRequests.some(item => item.type === type),
    `Run851 composite request lost independent blocker: ${type}`);
}
console.log('PASS Run851 matching text OS cannot authorize fan outputs, zeroed KR, or physical cam tuning');

// Run852: An affirmative statement in the free-text safety-facts field is
// not authenticated ECM/BIN evidence and must not clear hardware blockers.
// Distinct physical cam-card requests also must not share review fingerprints.
const ownerRequest = `${base} Enable the ECM fan outputs. Tune my installed LSX Stage 2 cam. Both knock sensors are physically missing.`;
const assertedFactsReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: ownerRequest,
  safetyFacts: 'I confirm the ECM OS, fan wiring, cam specs, and knock protection are verified.'
});
assert.equal(assertedFactsReview.ready, false);
assert.equal(assertedFactsReview.calibrationEvidenceVerified, false);
assert.equal(assertedFactsReview.readyForCalibration, false);
assert(assertedFactsReview.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['fan-output-enable', 'physical-camshaft-tune', 'knock-sensor-delete']) {
  assert(assertedFactsReview.unresolvedRequests.some(x => x.type === type), `free-text assertions cleared ${type}`);
}
const differentCamReview = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Enable the ECM fan outputs. Tune my installed different physical camshaft. Both knock sensors are physically missing.`,
  safetyFacts: 'I confirm the ECM OS, fan wiring, cam specs, and knock protection are verified.'
});
assert.notEqual(assertedFactsReview.requestFingerprint, differentCamReview.requestFingerprint);
assert.equal(differentCamReview.readyForCalibration, false);
console.log('PASS Run852 free-text evidence cannot authenticate OS, fan outputs, cam, or knock protection; changed cam request changes fingerprint');

// Run853: Supplying a numeric fan threshold pair and an OS-shaped label in
// the same request cannot commission an ECM fan output or justify bypassing
// physically absent knock sensors. This is triage-only fixture evidence.
const combinedThresholdKnockReview853 = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} OS ID: 12587603. Enable the ECM fan outputs. Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.`
});
assert.equal(combinedThresholdKnockReview853.ready, false);
assert.equal(combinedThresholdKnockReview853.calibrationEvidenceVerified, false);
assert.equal(combinedThresholdKnockReview853.readyForCalibration, false);
assert(combinedThresholdKnockReview853.missingSafetyFacts.some(x => x.includes('operating-system (OS) ID')));
for (const type of ['fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(combinedThresholdKnockReview853.unresolvedRequests.some(item => item.type === type),
    `Run853 numeric fan thresholds / text OS cleared ${type}`);
}
console.log('PASS Run853 fan threshold pair and OS-shaped text do not clear independent hardware safety blockers');

// Run854: A contradictory VATS instruction must remain visible alongside
// independent hardware risks. This is request triage only; no OS mapping,
// fan setpoint, cam card, or ECU operation is inferred from the text.
const conflictingOwnerReview854 = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} Disable VATS but keep VATS enabled. Enable the ECM fan outputs. ` +
    'Both knock sensors are physically missing. Tune my installed LSX Stage 2 cam.'
});
assert.equal(conflictingOwnerReview854.ready, false);
assert.equal(conflictingOwnerReview854.calibrationEvidenceVerified, false);
assert.equal(conflictingOwnerReview854.readyForCalibration, false);
for (const type of ['vats-intent-contradiction', 'fan-output-enable', 'knock-sensor-delete', 'physical-camshaft-tune']) {
  assert(conflictingOwnerReview854.unresolvedRequests.some(item => item.type === type),
    `Run854 conflicting VATS request lost independent blocker: ${type}`);
}
console.log('PASS Run854 contradictory VATS instruction cannot hide fan, knock, or physical cam blockers');

// Run856: A user-provided OS label cannot authenticate the BIN/XDF pair, and
// a fan-temperature request cannot prove that the physical ECM output is
// commissioned. Preserve the independent cam and knock diagnostics.
const ownerReview856 = reviewP01Request({
  activeProject: { ...project, os: 'unknown' },
  request: `${base} OS ID: 12587603. Enable ECM electric fan outputs and set fan on/off temperatures. ` +
    'Tune the installed LSX Stage 2 cam. Both knock sensors are physically missing.'
});
assert.equal(ownerReview856.ready, false);
assert.equal(ownerReview856.calibrationEvidenceVerified, false);
assert.equal(ownerReview856.readyForCalibration, false);
for (const type of ['fan-output-enable', 'physical-camshaft-tune', 'knock-sensor-delete']) {
  assert(ownerReview856.unresolvedRequests.some(item => item.type === type),
    `Run856 combined request omitted independent safety issue: ${type}`);
}
console.log('PASS Run856 user OS label and fan-temperature request cannot bypass hardware review');
