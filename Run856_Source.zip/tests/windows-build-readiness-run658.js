'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq658-'));
const pkg = { name: 'fixture', version: '1.0.0', dependencies: { a: '1.0.0' } };
try {
  for (const [entry, invalid] of [[{version:'1.0.0'}, false], [null,true], [[],true], ['bad',true], [42,true], [false,true]]) {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
    fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify({ lockfileVersion:3, packages:{ '':{...pkg}, 'node_modules/a':entry } }));
    const r=assess(root);
    assert.strictEqual(r.blockers.includes('package-lock-dependency-entries-invalid'), invalid, JSON.stringify(r));
    assert.strictEqual(r.ecmWriteAuthorized,false);
    assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
  }
} finally { fs.rmSync(root,{recursive:true,force:true}); }
console.log('Run658: six package-entry structure fixtures passed');
