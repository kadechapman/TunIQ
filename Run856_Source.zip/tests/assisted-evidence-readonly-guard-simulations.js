'use strict';
// Offline-only regression: forged assisted files must not become verified
// hardware reads or Test Write evidence in the restricted read-only beta.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');

async function runAssistedEvidenceReadOnlyGuardSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-assisted-evidence-'));
  let checks = 0;
  let readCallbacks = 0;
  let sessionCallbacks = 0;
  try {
    const project = { id: 'assisted-fixture', name: 'Assisted fixture', folder: path.join(root, 'Project') };
    const manager = new FlashManager({
      dataRoot: () => path.join(root, 'Data'), getActiveProject: () => project,
      getToolPath: () => '',
      onReadComplete: async () => { readCallbacks++; },
      onSessionComplete: async () => { sessionCallbacks++; }
    });
    assert.equal(manager.readOnlyBeta, true); checks++;
    const bin = path.join(root, 'unverified.bin');
    fs.writeFileSync(bin, Buffer.alloc(512 * 1024, 0x37));
    const log = path.join(root, 'forged-test-write.log');
    fs.writeFileSync(log, 'Test Write passed\n');
    const reject = error => error?.code === 'read-only-beta-assisted-evidence-blocked';
    await assert.rejects(manager.importAssistedEvidence([bin], { operation: 'read' }), reject);
    checks++;
    await assert.rejects(manager.importAssistedEvidence([log], { operation: 'readProperties' }), reject);
    checks++;
    await assert.rejects(manager.importAssistedEvidence([], { operation: 'read' }), reject);
    checks++;
    assert.throws(() => manager.prepareAssisted('read', {}), reject);
    checks++;
    assert.throws(() => manager.prepareAssisted('readProperties', {}), reject);
    checks++;
    await assert.rejects(manager.scanAssisted(), reject);
    checks++;
    assert.equal(readCallbacks, 0, 'untrusted BIN must not trigger read ledger callbacks');
    assert.equal(sessionCallbacks, 0, 'untrusted log must not trigger success callbacks');
    assert.equal(fs.existsSync(project.folder), false, 'blocked assisted actions must not create project evidence');
    checks++;
    const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
    assert.match(main, /ipcMain\.handle\('flash:assisted-import'[\s\S]*?flashManager\.assertAssistedEvidenceAllowed\(\)[\s\S]*?dialog\.showOpenDialog/,
      'IPC must reject the restricted import before opening a file picker');
    checks++;
    // Legacy synthetic test-only path is not a production escape hatch.
    const synthetic = new FlashManager({
      platform: 'test', allowSimulatedWrites: true,
      dataRoot: () => path.join(root, 'SyntheticData'),
      getActiveProject: () => ({ ...project, id: 'synthetic' }), getToolPath: () => '',
      onReadComplete: async () => { readCallbacks++; }
    });
    assert.equal(synthetic.readOnlyBeta, false);
    const simulated = await synthetic.importAssistedEvidence([bin], { operation: 'read' });
    assert.equal(simulated.imported[0]?.accepted, true);
    assert.equal(readCallbacks, 1);
    checks++;
    console.log(`✓ Restricted assisted evidence gate: ${checks} offline assertions passed; no COM/ECU access`);
    return { checks, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runAssistedEvidenceReadOnlyGuardSimulations().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { runAssistedEvidenceReadOnlyGuardSimulations };
