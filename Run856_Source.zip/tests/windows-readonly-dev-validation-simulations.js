'use strict';
// Offline static safety/ordering contract for the Windows operator kit.
// This does not execute PowerShell, download packages, or access hardware.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-readonly-dev-validation.ps1'), 'utf8');
const ordered = [
  'Disposable validation copy:',
  'Source syntax and launch snapshot',
  'Windows source integrity',
  'Write-admission safety',
  'Offline Electron startup contract',
  'Full offline simulated suite',
  'Generate npm lockfile candidate',
  'Validate lockfile metadata',
  'Install exact dependency graph in disposable copy',
  'Hardware-isolated renderer runtime smoke (native Electron; 45-second limit)'
];
let checks = 0;
let cursor = -1;
for (const step of ordered) {
  const next = source.indexOf(step);
  assert(next > cursor, `Unsafe or missing validation stage: ${step}`);
  cursor = next;
  checks++;
}
// All potentially mutating offline checks must execute in the disposable copy,
// not in the reviewed source directory. Preserve this ordering regression.
const copyIndex = source.indexOf('Disposable validation copy:');
const testIndex = source.indexOf('Full offline simulated suite');
const workIndex = source.indexOf('Push-Location $work');
const sourceIndex = source.indexOf('Push-Location $source');
assert(copyIndex >= 0 && copyIndex < workIndex && workIndex < testIndex,
  'Offline suite must run only after entering the disposable validation copy');
assert(sourceIndex === -1, 'Reviewed source must never be used as a test working directory');
checks += 2;
assert(source.includes('-Attributes ReparsePoint'),
  'Unsafe symlink or junction must be rejected before copying');
assert(source.indexOf('-Attributes ReparsePoint') < source.indexOf('Copy-Item -LiteralPath'),
  'Reparse-point guard must run before the first source copy');
checks += 2;
for (const required of [
  "$env:OS -ne 'Windows_NT'", 'Node.js 20+', 'dev-build-output',
  "'package-lock.candidate.json'", "'--package-lock-only'", "'--ignore-scripts'",
  "'--require-lock'", "'--no-audit'", "'ci'", "'node_modules\\electron\\dist\\electron.exe'",
  "if ($PrepareOnly)", 'No user-testing approval', 'NOT READY FOR USER TESTING',
  "'private-hardware-evidence'"
]) {
  assert(source.includes(required), `Missing guard or disclosure: ${required}`);
  checks++;
}
for (const prohibited of ['npm.cmd start', "@('start')", 'electron-builder', 'installer-release-gate.js',
  "@('run', 'dist:win')", 'pcmhammer.exe', 'src/main.js\'\)']) {
  assert(!source.includes(prohibited), `Unexpected hardware-capable app or installer command: ${prohibited}`);
  checks++;
}
// Run115: the separate operator kit must not reintroduce Run104's npm bug.
// npm exits zero with --save=false but silently omits package-lock.json.
assert(source.includes("'--package-lock=true', '--save=true'"),
  'Operator kit must explicitly enable both npm lockfile writing flags');
assert(!source.includes("'--save=false'"),
  'Operator kit must not suppress npm lockfile generation');
assert(source.includes('npm succeeded without writing package-lock.json'),
  'Operator kit must fail closed if npm exits zero without writing the lockfile');
assert(source.includes("'--fetch-retries=0', '--fetch-timeout=30000'"),
  'Operator kit npm ci must have bounded registry retries and timeout');
checks += 4;
// Run116: a native renderer command exiting zero without a fresh, validated
// proof is not startup verification; preserve logs for Windows diagnosis.
for (const required of [
  'Start-Process -FilePath $electron', 'WaitForExit(45000)',
  "$npmLogArg = '--logs-dir=' + $diagnostics",
  "'--fetch-timeout=15000', $npmLogArg",
  "'--fetch-timeout=30000', $npmLogArg",
  'renderer-runtime.stdout.log', 'renderer-runtime.stderr.log',
  'renderer-runtime-evidence.json', 'TUNIQ_RENDERER_SMOKE_REPORT',
  'TUNIQ_RENDERER_SMOKE_NONCE', '$proof.nonce -ne $nonce',
  '$proof.actualElectronRuntime -ne $true', '$proof.hardwareUsed -ne $false',
  '$proof.ecuWriteOrFlashPerformed -ne $false',
  'Native renderer exited without nonce-bound evidence',
  'Native renderer evidence was stale, incomplete, or unsuccessful.',
  'Stop-Process -Id $process.Id -Force',
  '$env:TUNIQ_RENDERER_SMOKE_REPORT = $oldReport',
  '$env:TUNIQ_RENDERER_SMOKE_NONCE = $oldNonce'
]) {
  assert(source.includes(required), `Native renderer proof or diagnostic guard missing: ${required}`);
  checks++;
}
// Run124: every operator run must retain its own genuine lockfile candidate.
// The former shared dev-build-output/package-lock.candidate.json could be
// overwritten by another attempt and mistaken for the current run's graph.
assert(source.includes("$candidate = Join-Path $diagnostics 'package-lock.candidate.json'"),
  'Lockfile candidate must be bound to the unique per-run diagnostics directory');
assert(source.includes("Copy-Item -LiteralPath 'package-lock.json' -Destination $candidate -ErrorAction Stop"),
  'Candidate must be copied from the validated lockfile with a checked destination');
assert(!source.includes("Join-Path $out 'package-lock.candidate.json'"),
  'A shared, overwriteable lockfile candidate path is not acceptable evidence');
checks += 3;
// Run125: the installed dependency graph must still match the candidate
// and package metadata captured before npm ci. Static contract only; the
// actual offline CLI mutation tests live in a separate fixture.
for (const required of [
  "$provenance = Join-Path $diagnostics 'lockfile-provenance.json'",
  "'Capture candidate and package provenance'",
  "'Verify npm ci preserved dependency provenance'",
  "'tools/windows-lockfile-provenance.js', '--capture', $candidate, $provenance",
  "'tools/windows-lockfile-provenance.js', '--verify', $candidate, $provenance"
]) {
  assert(source.includes(required), `Missing lockfile provenance guard: ${required}`);
  checks++;
}
assert(source.indexOf('Capture candidate and package provenance') < source.indexOf('Install exact dependency graph'),
  'Candidate provenance must be captured before npm ci');
assert(source.indexOf('Verify npm ci preserved dependency provenance') > source.indexOf('Install exact dependency graph'),
  'Dependency provenance must be verified after npm ci');
checks += 2;
assert(!source.includes("@('run', 'test:renderer-runtime')"),
  'Operator kit must not trust an unbounded npm renderer command without proof');
checks++;
console.log(`Windows read-only development kit static regressions: ${checks}/${checks} passed (offline only).`);
