'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['double-encoded traversal','%252e%252e/packages/foo',true],
 ['double-encoded backslash','..%255cpackages%255cfoo',true],
 ['double-encoded colon','../packages/C%253afoo',true],
 ['double-encoded percent separator','../packages/foo%252fbar',true],
 ['single encoded safe letter','../packages/%66oo',false],
 ['literal percent without escape','../packages/100%complete',false],
 ['normal sibling workspace','../packages/foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq686-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run686: 7 nested-escape regression fixtures passed');
