'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['different dependencies/devDependencies', {dependencies:{alpha:'^1'},devDependencies:{alpha:'^2'}},true],
  ['different dependencies/optionalDependencies', {dependencies:{alpha:'^1'},optionalDependencies:{alpha:'^2'}},true],
  ['different devDependencies/optionalDependencies', {devDependencies:{alpha:'^1'},optionalDependencies:{alpha:'^2'}},true],
  ['same duplicate spec', {dependencies:{alpha:'^1'},devDependencies:{alpha:'^1'}},false],
  ['single group', {dependencies:{alpha:'^1'}},false],
  ['no groups', {},false],
];
for (const [label, lockGroups, blocked] of cases) {
 const root = fs.mkdtempSync(path.join(os.tmpdir(),'tuniq670-'));
 try {
  const pkg = {name:'tuniq',version:'1.0.0',dependencies:{alpha:'^1'}};
  const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',...lockGroups},'node_modules/alpha':{version:'1.0.0'}}};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify(pkg));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
  const result = assess(root);
  assert.strictEqual(result.blockers.includes('package-lock-root-dependency-group-conflict'),blocked,label);
  assert.strictEqual(result.ecmWriteAuthorized,false,label);
  assert.strictEqual(result.nativeWindowsRuntimeVerified,false,label);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run670: 6 lockfile root cross-group conflict fixtures passed');
