'use strict';
// Real extracted source admission: a fixture passing does not certify this source.
// No install, Electron launch, network or ECU access.
const assert = require('node:assert/strict');
const path = require('node:path');
const { inspectWindowsDependencyLock } = require('../tools/windows-dependency-preflight');
const source = path.resolve(__dirname, '..');
const audit = inspectWindowsDependencyLock(source);
assert.equal(audit.windowsBuildVerified, false, 'offline preflight cannot prove Windows runtime');
assert.equal(audit.nativeInstallVerified, false, 'offline preflight cannot prove native npm install');
assert.equal(audit.physicalHardwareVerified, false, 'offline preflight cannot prove hardware');
if (!audit.lockfileReady) {
  assert.ok(audit.blockers.length > 0, 'missing lock evidence must be a blocker');
  console.log('BLOCKED real source Windows dependency admission:', audit.blockers.join(', '));
} else {
  console.log('PASS real source lock metadata only; native npm ci and Windows runtime remain unverified');
}
