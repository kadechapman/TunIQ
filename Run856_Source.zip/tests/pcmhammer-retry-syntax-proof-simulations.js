'use strict';
// Pure text/exit-code regression: no serial devices or PCM operations.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { safeToRetryProfile } = require('../src/pcmhammer-integrated');

function runPcmHammerRetrySyntaxProofSimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-explicit-syntax-'));
  const output = path.join(folder, 'unused.bin');
  try {
  const cases = [
    ['read', 'Usage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Error: unexpected process failure\nUsage: PCM Hammer CLI\nOperations: read-properties', 1, false],
    ['read', 'Error: unhandled exception\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'Unknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, true],
    // The CLI has already opened the COM handle; a trailing usage footer is not
    // proof that a second read-only process is safe to launch.
    ['read', 'Opened serial port COM4\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'Serial port COM4 opened\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Opened serial port COM4\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['readProperties', 'Error: No operation specified.\nUsage: PCM Hammer CLI\nOperations: read-properties', 1, true],
    ['read', 'Missing required option --output\nUsage: PCM Hammer CLI\nOperations: read-full', 64, true],
    ['read', 'CRC errors: 2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC \x1b[31merrors: 2\x1b[0m\nUnknown option --device\nUsage: PCM Hammer CLI', 64, false],
    ['readProperties', 'Kernel upload: \x1b[31mfalse\x1b[0m\nUnknown option --device', 64, false],
    ['readProperties', '\x1b[?25l\nUnknown option --device', 64, false],
    ['read', 'Unknown option --device\nUsage: PCM Hammer CLI\n\x08', 64, false],
    ['readProperties', 'Unknown option --device\n\x00', 64, false],
    ['readProperties', 'Unknown option --device\n\x7f', 64, false],
    ['read', 'CRC err\rors: 2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'Kernel upl\road: false\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC err\u200bors: 2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'Kernel upl\u202eoad: false\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC err\u2028ors: 2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Unknown option --device\ufeff\nUsage: PCM Hammer CLI', 64, false],
    ['readProperties', 'Unknown option --device\r\nUsage: PCM Hammer CLI', 64, true],
    ['readProperties', '\x1b[31mUnknown option\x1b[0m --device\nUsage: PCM Hammer CLI', 64, true],
    ['readProperties', 'Opened \x1b[31mserial port COM4\x1b[0m\nUnknown option --device', 64, false],
    ['readProperties', 'Access to \x1b[31mport COM4 is denied\x1b[0m\nUnknown option --device', 64, false],
    ['read', 'Kernel upload: 0\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Kernel upload status: 0\nUnknown option --device\nUsage: PCM Hammer CLI', 64, false],
    ['readProperties', 'Loader execution: 1\nUnknown option --device\nUsage: PCM Hammer CLI', 64, false],
    ['readProperties', 'Kernel handshake: 0x00\nUnknown option --device\nUsage: PCM Hammer CLI', 64, false],
    ['read', 'Kernel upload: false\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Kernel transfer status: failed\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['readProperties', 'Loader execution: false\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['read', 'CRC errors: 02\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: 0x02\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: +2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: -1\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: 0b10\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: 0xG2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors:\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'CRC errors: 0; Hash mismatches: +2\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Hash mismatches: 0X0A\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['read', 'CRC check: FAILED\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Hash verification: FAILED\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['readProperties', 'Hash mismatches: 3\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['read', 'Read completed: false\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Read status: failed\nUnknown option --device\nUsage: PCM Hammer CLI\nOperations: read-properties', 64, false],
    ['read', 'Read page 128 timeout\nUnknown option --device\nUsage: PCM Hammer CLI', 64, false],
    ['readProperties', 'Failed to read sector 0x1800\nUnknown option --device', 64, false],
    ['testWrite', 'Unknown option --device\nUsage: PCM Hammer CLI', 64, false]
  ];
  for (const [operation, text, exitCode, expected] of cases) {
    assert.strictEqual(safeToRetryProfile({ operation, text, exitCode, output: operation === 'read' ? output : undefined }), expected,
      `unexpected retry decision for ${operation}: ${text}`);
  }
  return { passed: cases.length, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) {
  const result = runPcmHammerRetrySyntaxProofSimulations();
  console.log(`PCM Hammer explicit-syntax retry simulations: ${result.passed}/${result.passed} passed (offline only)`);
}
module.exports = { runPcmHammerRetrySyntaxProofSimulations };
