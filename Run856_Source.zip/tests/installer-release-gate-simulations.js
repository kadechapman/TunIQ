'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');
const { checkInstallerAdmission } = require('../tools/installer-release-gate');
const { verifySnapshot } = require('../tools/launch-snapshot');
const { runWindowsDependencyPreflightSimulations } = require('./windows-dependency-preflight-simulations');
const { runWindowsSourcePathPreflightSimulations } = require('./windows-source-path-preflight-simulations');
const { runRendererNavigationGuardSimulations } = require('./renderer-navigation-guard-simulations');
const { runElectronStartupContractPreflightSimulations } = require('./electron-startup-contract-preflight-simulations');
const { runRendererRuntimeSmokeSimulations } = require('./electron-renderer-runtime-smoke-simulations');

function runInstallerReleaseGateSimulations() {
  const root = path.resolve(__dirname, '..');
  const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
  const batch = fs.readFileSync(path.join(root, 'BUILD_WINDOWS_INSTALLER.bat'), 'utf8');
  const workflow = fs.readFileSync(path.join(root, '.github', 'workflows', 'windows-public-beta.yml'), 'utf8');
  for (const name of ['dist:win', 'dist:win:unsigned', 'pack:win']) {
    assert.match(pkg.scripts[name], /^node tools\/installer-release-gate\.js && /,
      `${name} must reject before electron-builder is reached`);
  }
  assert.match(batch, /node tools\\installer-release-gate\.js/i);
  assert.match(batch, /if errorlevel 1\s*\(/i);
  assert.doesNotMatch(batch, /\b(?:npm install|npm run dist:win|electron-builder)\b/i,
    'Legacy convenience script must not build or install unpinned dependencies');
  // Regression: the old single-job Windows workflow stopped at its missing
  // lockfile check before executing even dependency-free safety simulations.
  // Keep the offline evidence independent of npm ci and installer admission.
  assert.match(workflow, /windows-offline-source-tests:\s*\n\s*runs-on: windows-latest/);
  assert.match(workflow, /windows-locked-dependency-check:\s*\n\s*runs-on: windows-latest/);
  const offline = workflow.split('  windows-offline-source-tests:')[1]
    .split('  windows-locked-dependency-check:')[0];
  const locked = workflow.split('  windows-locked-dependency-check:')[1];
  for (const command of ['npm run check', 'npm run test:suite-verifier',
    'npm run test:read-only-beta', 'npm run test:installer-admission',
    'npm run test:windows-dependency-preflight', 'npm run test:windows-source-paths',
    'npm run check:windows-source-paths', 'npm run test:renderer-navigation',
    'npm run check:electron-startup-contract', 'npm run test:electron-startup-contract', 'npm test']) {
    assert(offline.includes(command), `Windows offline job must run ${command}`);
  }
  assert(offline.includes('npm run test:renderer-smoke-contract'),
    'Offline Windows job must test isolated renderer smoke assertions');
  assert(locked.includes('npm run test:renderer-runtime'),
    'Locked Windows job must exercise a real Electron renderer after installation');
  assert(locked.indexOf('npm run test:renderer-runtime') > locked.indexOf('npm ci') &&
    locked.indexOf('npm run test:renderer-runtime') > locked.indexOf('npm test'),
    'Runtime smoke must execute only after dependency installation and automated suite');
  const smoke = runRendererRuntimeSmokeSimulations({ quiet: true });
  assert(smoke.passed >= 24 && smoke.electronRuntimeVerified === false);
  const executableOffline = offline.split('\n').filter(line => !line.trim().startsWith('#')).join('\n');
  assert.doesNotMatch(executableOffline, /\bnpm (?:ci|install)\b|\belectron-builder\b/i,
    'Offline Windows safety tests must not require dependency installation or packaging');
  assert.match(offline, /run: npm run test:read-only-beta\s*\n\s*- name: Verify installer restrictions/);
  assert.match(offline, /run: npm run test:installer-admission\s*\n\s*- name: Validate dependency lock metadata fixtures/);
  assert(locked.indexOf('Test-Path package-lock.json') >= 0 &&
    locked.indexOf('Test-Path package-lock.json') < locked.indexOf('npm ci'),
    'Windows dependency installation must require a real lockfile first');
  const executableWorkflow = workflow.split('\n').filter(line => !line.trim().startsWith('#')).join('\n');
  assert.doesNotMatch(executableWorkflow, /\belectron-builder\b|\bnpm run (?:dist:win|pack:win)\b|\b(upload-artifact|create-release)\b/i,
    'Windows source-only workflow must not package or publish ECU-capable builds');
  assert(locked.indexOf('npm run check:windows-source-paths') >= 0 &&
    locked.indexOf('npm run check:windows-source-paths') < locked.indexOf('npm ci'),
    'Windows source-path preflight must run before npm ci');
  assert(locked.indexOf('node tools/windows-dependency-preflight.js --require-lock') >= 0 &&
    locked.indexOf('node tools/windows-dependency-preflight.js --require-lock') < locked.indexOf('npm ci'),
    'Windows lockfile metadata preflight must run before npm ci');
  const startupContract = runElectronStartupContractPreflightSimulations({ quiet: true });
  assert(startupContract.passed >= 20 && startupContract.electronRuntimeVerified === false);
  assert(locked.indexOf('npm run check:electron-startup-contract') >= 0 &&
    locked.indexOf('npm run check:electron-startup-contract') < locked.indexOf('npm ci'),
    'Electron startup contract must be checked before dependency installation');
  const rendererGuard = runRendererNavigationGuardSimulations({ quiet: true });
  assert(rendererGuard.passed >= 18 && rendererGuard.electronRuntimeVerified === false);
  const sourcePaths = runWindowsSourcePathPreflightSimulations({ quiet: true });
  assert(sourcePaths.passed >= 30 && sourcePaths.windowsBuildVerified === false);
  const preflight = runWindowsDependencyPreflightSimulations({ quiet: true });
  assert(preflight.passed >= 18, 'offline dependency preflight regressions must execute');
  const admission = checkInstallerAdmission(root);
  assert.equal(admission.allowed, false);
  const snapshot = verifySnapshot(root);
  if (snapshot.valid) {
    assert.equal(admission.reason, 'source-only-not-release-authorized');
    assert(admission.blockerIds.includes('dependency-lock'));
  } else {
    // An edited or stale source tree must fail at the earlier integrity gate.
    // Do not expect downstream source-only admission on invalid provenance.
    assert.equal(admission.reason, 'source-snapshot-invalid');
    assert.equal(admission.detail, snapshot.reason);
    assert.equal(Object.hasOwn(admission, 'blockerIds'), false);
  }
  const result = spawnSync(process.execPath, ['tools/installer-release-gate.js'], {
    cwd: root, encoding: 'utf8', timeout: 10000
  });
  assert.equal(result.status, 1);
  assert.match(result.stderr, /installer BLOCKED/);
  // A copied, user-edited snapshot cannot become an installer authorization.
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-installer-gate-'));
  try {
    fs.writeFileSync(path.join(temp, 'LAUNCH_READINESS_CURRENT.json'),
      JSON.stringify({ snapshotKind: 'release-attested', fullLaunchReady: true,
        physicalHardwareVerified: true, blockers: [] }));
    const forged = checkInstallerAdmission(temp);
    assert.equal(forged.allowed, false);
    assert.equal(forged.reason, 'source-snapshot-invalid');
  } finally { fs.rmSync(temp, { recursive: true, force: true }); }
  return { passed: true, cases: 21 + preflight.passed + sourcePaths.passed + rendererGuard.passed + startupContract.passed + smoke.passed };
}

if (require.main === module) {
  try { const report = runInstallerReleaseGateSimulations();
    console.log(`Installer release admission simulations: ${report.cases}/${report.cases} passed`);
  } catch (error) { console.error(error.stack || error); process.exitCode = 1; }
}
module.exports = { runInstallerReleaseGateSimulations };
