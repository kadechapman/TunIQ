'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run652-'));
try {
  const pkg = {name:'fixture', version:'1.0.0', dependencies:{alpha:'^1.0.0'}};
  const lock = {lockfileVersion:3, packages:{'':{name:'fixture',version:'1.0.0'},'node_modules/alpha':{version:'1.0.1'}}};
  fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(pkg));
  fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
  let result=assess(dir);
  assert.strictEqual(result.rootDependencyDeclarationsAbsent,true);
  lock.packages[''].dependencies={alpha:'^1.0.0'};
  fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
  result=assess(dir);
  assert.strictEqual(result.rootDependencyDeclarationsAbsent,false);
  assert.deepStrictEqual(result.missingRootDependencyDeclarations,[]);
  console.log('Run652 missing root declarations and matching declarations: 2 passed');
} finally {fs.rmSync(dir,{recursive:true,force:true});}
