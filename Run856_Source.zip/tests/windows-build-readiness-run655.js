'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq655-'));
function check(pkg, lock, blocker) {
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(lock));
  const result = assess(root);
  assert(result.blockers.includes(blocker), JSON.stringify(result));
  assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
  assert.strictEqual(result.ecmWriteAuthorized, false);
}
try {
  const pkg = { name: 'fixture', version: '1.0.0' };
  const lock = { lockfileVersion: 3, packages: { '': { name: 'fixture', version: '1.0.0' } } };
  check(pkg, { ...lock, packages: [] }, 'package-lock-invalid');
  check(pkg, { ...lock, packages: { '': null } }, 'package-lock-invalid');
  check({ ...pkg, dependencies: [] }, lock, 'package-json-dependency-groups-invalid');
  check({ ...pkg, devDependencies: null }, lock, 'package-json-dependency-groups-invalid');
  check(pkg, { ...lock, packages: { '': { ...lock.packages[''], dependencies: [] } } }, 'package-lock-root-dependency-groups-invalid');
  check(pkg, { ...lock, packages: { '': { ...lock.packages[''], optionalDependencies: null } } }, 'package-lock-root-dependency-groups-invalid');
  assert.deepStrictEqual(assess(root).blockers, ['package-lock-root-dependency-groups-invalid']);
  console.log('Run655: six malformed metadata cases passed; no runtime/ECM authorization');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
