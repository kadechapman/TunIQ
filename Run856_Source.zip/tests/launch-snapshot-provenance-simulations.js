'use strict';
// Offline source-snapshot provenance test. Never invokes PCM Hammer or hardware.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { writeSnapshot, verifySnapshot, criticalSourceFingerprint } = require('../tools/launch-snapshot');

function runLaunchSnapshotProvenanceSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-snapshot-provenance-'));
  let passed = 0;
  const put = (name, value) => fs.writeFileSync(path.join(root, name), value);
  try {
    put('package.json', JSON.stringify({ name: 'tuniq-desktop', version: '1.9.0-beta.108', license: 'UNLICENSED' }));
    put('VERSION.json', JSON.stringify({ version: '1.9.0-beta.108', channel: 'beta' }));
    put('LICENSE_SELECTION_REQUIRED.md', 'License must be reviewed before release.');
    put('PRIVACY.md', 'No private ECU logs are uploaded.');
    put('INSTALL_AND_RUN_WINDOWS.bat', '@echo off\r\necho Review installer\r\n');
    for (const directory of ['src', 'tools', 'tests']) {
      fs.mkdirSync(path.join(root, directory));
      put(`${directory}/fixture.js`, '// reviewed fixture\n');
    }
    fs.mkdirSync(path.join(root, 'schemas'));
    fs.mkdirSync(path.join(root, 'build'));
    fs.mkdirSync(path.join(root, '.github', 'ISSUE_TEMPLATE'), { recursive: true });
    put('.gitignore', 'private-hardware-evidence/\n');
    put('schemas/p01-evidence-package.schema.json', '{"type":"object"}');
    put('build/icon.ico', Buffer.from('installer-icon-a'));
    put('.github/ISSUE_TEMPLATE/bug-report.yml', 'body: []\n');
    const fingerprintInventory = criticalSourceFingerprint(root, true);
    const fingerprintDefault = criticalSourceFingerprint(root);
    assert.strictEqual(fingerprintInventory.sha256, fingerprintDefault.sha256); passed++;
    assert.strictEqual(fingerprintInventory.fileCount, fingerprintInventory.inventory.length); passed++;
    assert.deepStrictEqual(fingerprintInventory.inventory.map(item => item.path), fingerprintInventory.inventory.map(item => item.path).sort()); passed++;
    assert.ok(fingerprintInventory.inventory.every(item => /^[a-f0-9]{64}$/.test(item.sha256) && Number.isInteger(item.bytes))); passed++;
    assert.strictEqual(Object.prototype.hasOwnProperty.call(fingerprintDefault, 'inventory'), false); passed++;
    writeSnapshot(root);
    assert.strictEqual(verifySnapshot(root).valid, true); passed++;

    for (const [name, modified] of [
      ['LICENSE_SELECTION_REQUIRED.md', 'Unreviewed license claim.'],
      ['PRIVACY.md', 'Changed data collection disclosure.'],
      ['INSTALL_AND_RUN_WINDOWS.bat', '@echo off\r\necho Changed installer\r\n']
    ]) {
      const original = fs.readFileSync(path.join(root, name));
      put(name, modified);
      assert.strictEqual(verifySnapshot(root).valid, false, `${name} must invalidate source snapshot`); passed++;
      fs.writeFileSync(path.join(root, name), original);
      assert.strictEqual(verifySnapshot(root).valid, true, `${name} restoration must restore fingerprint`); passed++;
    }
    // Evidence-schema, installer assets and private-evidence exclusion rules
    // must invalidate a snapshot just like executable code and root policy.
    for (const [name, modified] of [
      ['schemas/p01-evidence-package.schema.json', '{"type":"array"}'],
      ['build/icon.ico', Buffer.from('installer-icon-b')],
      ['.gitignore', '# private evidence no longer excluded\n'],
      ['.github/ISSUE_TEMPLATE/bug-report.yml', 'body: [sensitive-ecu-data]\n']
    ]) {
      const file = path.join(root, name);
      const original = fs.readFileSync(file);
      fs.writeFileSync(file, modified);
      assert.strictEqual(verifySnapshot(root).valid, false, `${name} must invalidate source snapshot`); passed++;
      fs.writeFileSync(file, original);
      assert.strictEqual(verifySnapshot(root).valid, true, `${name} restoration must restore fingerprint`); passed++;
    }
    put('schemas/new-definition.schema.json', '{"type":"object"}');
    assert.strictEqual(verifySnapshot(root).valid, false, 'new evidence schema must invalidate snapshot'); passed++;
    fs.unlinkSync(path.join(root, 'schemas/new-definition.schema.json'));
    assert.strictEqual(verifySnapshot(root).valid, true); passed++;
    put('LICENSE', 'Unreviewed license added');
    assert.strictEqual(verifySnapshot(root).valid, false, 'adding a new root license must invalidate source snapshot'); passed++;
    fs.unlinkSync(path.join(root, 'LICENSE'));
    put('SUPPORT.md', 'New support policy');
    assert.strictEqual(verifySnapshot(root).valid, false, 'new support document must invalidate source snapshot'); passed++;
    fs.unlinkSync(path.join(root, 'SUPPORT.md'));
    assert.strictEqual(verifySnapshot(root).valid, true); passed++;

    // A removed required root manifest must fail closed rather than disappear
    // from the digest. Optional dependency lockfiles remain optional inputs.
    for (const required of ['package.json', 'VERSION.json']) {
      const original = fs.readFileSync(path.join(root, required));
      fs.unlinkSync(path.join(root, required));
      assert.throws(() => criticalSourceFingerprint(root), /missing required file/, `${required} missing must fail closed`); passed++;
      fs.writeFileSync(path.join(root, required), original);
      assert.strictEqual(verifySnapshot(root).valid, true); passed++;
    }
    // Removing an entire executable or regression-test tree must fail closed.
    for (const directory of ['src', 'tools', 'tests']) {
      fs.renameSync(path.join(root, directory), path.join(root, `${directory}-temporarily-removed`));
      assert.throws(() => criticalSourceFingerprint(root), /missing required file/, `${directory} missing must fail closed`); passed++;
      fs.renameSync(path.join(root, `${directory}-temporarily-removed`), path.join(root, directory));
      assert.strictEqual(verifySnapshot(root).valid, true); passed++;
    }
    // Empty executable/test trees cannot be treated as a valid source snapshot.
    for (const directory of ['src', 'tools', 'tests']) {
      const fixture = path.join(root, directory, 'fixture.js');
      const original = fs.readFileSync(fixture);
      fs.unlinkSync(fixture);
      assert.throws(() => criticalSourceFingerprint(root), /empty directory/, `${directory} empty must fail closed`); passed++;
      fs.writeFileSync(fixture, original);
      assert.strictEqual(verifySnapshot(root).valid, true); passed++;
    }
    // An empty nested folder previously left the reviewed digest unchanged.
    // Reject it rather than silently ignoring unreviewed source-tree changes.
    for (const directory of ['src', 'tools', 'tests']) {
      const nested = path.join(root, directory, 'unreviewed-empty');
      fs.mkdirSync(nested);
      assert.throws(() => criticalSourceFingerprint(root), /empty directory/, `${directory} nested empty directory must fail closed`); passed++;
      fs.rmdirSync(nested);
      assert.strictEqual(verifySnapshot(root).valid, true); passed++;
    }
    const before = criticalSourceFingerprint(root).sha256;
    put('SOURCE_MANIFEST.json', '{}');
    put('MANIFEST_SHA256.txt', 'generated');
    assert.strictEqual(criticalSourceFingerprint(root).sha256, before, 'generated manifests must not create a cyclic snapshot fingerprint'); passed++;
    return { passed, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) {
  const result = runLaunchSnapshotProvenanceSimulations();
  console.log(`Launch snapshot provenance simulations: ${result.passed}/${result.passed} passed (offline only)`);
}
module.exports = { runLaunchSnapshotProvenanceSimulations };
