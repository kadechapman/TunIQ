'use strict';
// Offline Electron webContents doubles only. Never starts Electron or opens a device.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { EventEmitter } = require('node:events');
const { attachRendererNavigationGuard } = require('../src/renderer-navigation-guard');

function runRendererNavigationGuardSimulations({ quiet = false } = {}) {
  let passed = 0;
  const check = (condition, message) => { assert.ok(condition, message); passed++; };
  const webContents = new EventEmitter();
  let openHandler = null;
  webContents.setWindowOpenHandler = handler => { openHandler = handler; };
  check(attachRendererNavigationGuard(webContents) === webContents, 'guard attaches to webContents');
  check(typeof openHandler === 'function', 'popup denial handler registered');
  for (const url of [
    'https://example.invalid/evil', 'file:///C:/other-app/index.html',
    'javascript:alert(1)', 'data:text/html,evil', 'about:blank',
    'ms-settings:bluetooth', 'file:///C:/TunIQ/src/renderer/index.html'
  ]) {
    check(openHandler({ url }).action === 'deny', `popup denied: ${url}`);
  }
  for (const name of ['will-navigate', 'will-frame-navigate', 'will-redirect', 'will-attach-webview']) {
    let prevented = 0;
    const event = { preventDefault() { prevented++; } };
    webContents.emit(name, event, 'https://example.invalid/evil');
    check(prevented === 1, `${name} denied`);
  }
  check(webContents.listenerCount('will-navigate') > 0, 'top-level navigation handler registered');
  check(webContents.listenerCount('will-attach-webview') > 0, 'webview handler registered');
  assert.throws(() => attachRendererNavigationGuard(null), /webContents/, 'missing webContents must fail closed'); passed++;
  assert.throws(() => attachRendererNavigationGuard({ on() {} }), /setWindowOpenHandler/, 'missing popup handler must fail closed'); passed++;
  assert.throws(() => attachRendererNavigationGuard({ setWindowOpenHandler() {} }), /on/, 'missing event API must fail closed'); passed++;
  const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
  check(main.includes("require('./renderer-navigation-guard')"), 'main imports navigation guard');
  const install = main.indexOf('attachRendererNavigationGuard(mainWindow.webContents)');
  const load = main.indexOf("mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'))");
  check(install > main.indexOf('function createWindow()') && install < load,
    'navigation guard installed before first renderer load');
  if (!quiet) console.log(`Renderer navigation guard: ${passed}/${passed} offline checks passed`);
  return { passed, hardwareVerified: false, electronRuntimeVerified: false };
}
if (require.main === module) runRendererNavigationGuardSimulations();
module.exports = { runRendererNavigationGuardSimulations };
