'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { triage } = require('../tools/source-integrity-triage');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-triage-'));
try {
  fs.mkdirSync(path.join(root, 'src'));
  fs.writeFileSync(path.join(root, 'src', 'safe.js'), 'modified');
  const manifest = JSON.stringify({ files: [{ path: 'src/safe.js', size: 8,
    sha256: crypto.createHash('sha256').update('original').digest('hex') }] });
  fs.writeFileSync(path.join(root, 'SOURCE_MANIFEST.json'), manifest);
  fs.writeFileSync(path.join(root, 'SOURCE_MANIFEST_SHA256.txt'),
    crypto.createHash('sha256').update(manifest).digest('hex') + '  SOURCE_MANIFEST.json\n');
  const before = fs.readFileSync(path.join(root, 'SOURCE_MANIFEST.json'));
  const report = triage(root);
  assert.equal(report.manifestVerified, false);
  assert.equal(report.mismatchCount, 1);
  assert.equal(report.evidenceComplete, true);
  assert.deepEqual(report.evidenceIssues, []);
  assert.equal(report.groups.code[0].path, 'src/safe.js');
  assert.equal(report.groups.code[0].actualSize, 8);
  assert.deepEqual(fs.readFileSync(path.join(root, 'SOURCE_MANIFEST.json')), before);
  const absent = triage(path.join(root, 'nonexistent'));
  assert.equal(absent.manifestVerified, false);
  assert.equal(absent.evidenceComplete, false);
  assert.ok(absent.evidenceIssues.includes('invalid-manifest-file-count'));
  // Even if a fixture contains all matching files, a mismatched manifest
  // digest must not be promoted to a verified source checkpoint.
  fs.writeFileSync(path.join(root, 'src', 'safe.js'), 'original');
  const tampered = triage(root);
  assert.equal(tampered.mismatchCount, 0);
  assert.equal(tampered.manifestVerified, true);
  fs.writeFileSync(path.join(root, 'SOURCE_MANIFEST_SHA256.txt'), '0'.repeat(64) + '  SOURCE_MANIFEST.json\n');
  const invalidDigest = triage(root);
  assert.equal(invalidDigest.manifestVerified, false);
  assert.ok(invalidDigest.blockers.includes('manifest-digest-mismatch'));
  // Missing source root must remain a structured failure, not a thrown exception.
  assert.ok(Array.isArray(absent.evidenceIssues));
  // Malformed upstream success evidence must fail closed without throwing.
  const malformed = triage(root, () => ({ windowsSourcePathsSafe: true, fileCount: 1,
    blockers: null, issues: null, unsafeSourcePaths: null,
    contentMismatchCount: 1, contentMismatches: [null] }));
  assert.equal(malformed.manifestVerified, false);
  assert.ok(malformed.evidenceIssues.includes('invalid-audit-blockers'));
  assert.ok(malformed.evidenceIssues.includes('missing-audit-path-evidence'));
  assert.ok(malformed.evidenceIssues.includes('contradictory-audit-success'));
  assert.ok(malformed.evidenceIssues.includes('invalid-mismatch-entry'));
  // Missing or non-boolean status cannot establish a trustworthy audit outcome.
  for (const status of [undefined, null, 1, 'true']) {
    const badStatus = triage(root, () => ({ windowsSourcePathsSafe: status,
      fileCount: 1, blockers: [], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 0, contentMismatches: [] }));
    assert.equal(badStatus.manifestVerified, false);
    assert.equal(badStatus.evidenceComplete, false);
    assert.ok(badStatus.evidenceIssues.includes('invalid-audit-status'));
  }
  // A false upstream status with zero findings is unexplained, not complete evidence.
  const unexplained = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: [], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 0, contentMismatches: [] }));
  assert.equal(unexplained.manifestVerified, false);
  assert.equal(unexplained.evidenceComplete, false);
  assert.ok(unexplained.evidenceIssues.includes('unexplained-audit-failure'));
  // Audit prose must not contain bidirectional controls that disguise findings.
  for (const control of ['\u202a', '\u202e', '\u2066', '\u2069']) {
    const audit = { windowsSourcePathsSafe: false, fileCount: 1,
      blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 0, contentMismatches: [] };
    const deceptiveBlocker = triage(root, () => ({ ...audit,
      blockers: [`content-${control}mismatch`] }));
    assert.ok(deceptiveBlocker.evidenceIssues.includes('invalid-audit-blockers'));
    const deceptiveIssue = triage(root, () => ({ ...audit,
      issues: [`path-${control}issue`] }));
    assert.ok(deceptiveIssue.evidenceIssues.includes('invalid-audit-issue-entry'));
  }
  // Invisible formatting and C1 controls must not obscure audit evidence.
  for (const control of ['\u0085', '\u200b', '\u200d', '\u2060', '\ufeff']) {
    const audit = { windowsSourcePathsSafe: false, fileCount: 1,
      blockers: ['source-mismatch'], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 0, contentMismatches: [] };
    const badBlocker = triage(root, () => ({ ...audit, blockers: [`source${control}mismatch`] }));
    assert.ok(badBlocker.evidenceIssues.includes('invalid-audit-blockers'));
    const badIssue = triage(root, () => ({ ...audit, issues: [`source${control}mismatch`] }));
    assert.ok(badIssue.evidenceIssues.includes('invalid-audit-issue-entry'));
    const badPath = triage(root, () => ({ ...audit, contentMismatchCount: 1,
      contentMismatches: [{ path: `src/${control}safe.js`, expectedSha256: 'a'.repeat(64),
        actualSha256: 'b'.repeat(64), expectedSize: 1, actualSize: 1 }] }));
    assert.ok(badPath.evidenceIssues.includes('invalid-mismatch-path'));
  }
  const repeatedIssue = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: ['manifest-digest-mismatch'],
    issues: ['duplicate record', 'duplicate record'], unsafeSourcePaths: [],
    contentMismatchCount: 0, contentMismatches: [] }));
  assert.equal(repeatedIssue.evidenceComplete, false);
  assert.ok(repeatedIssue.evidenceIssues.includes('duplicate-audit-issue'));
  // A claimed successful audit without its mismatch inventory is not proof of integrity.
  const omittedInventory = triage(root, () => ({ windowsSourcePathsSafe: true,
    fileCount: 1, blockers: [], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 0 }));
  assert.equal(omittedInventory.manifestVerified, false);
  assert.equal(omittedInventory.evidenceComplete, false);
  assert.ok(omittedInventory.evidenceIssues.includes('missing-content-mismatch-evidence'));
  // A null upstream result must be a structured failure, not a TypeError.
  const nullAudit = triage(root, () => null);
  assert.equal(nullAudit.manifestVerified, false);
  assert.ok(nullAudit.evidenceIssues.includes('invalid-manifest-file-count'));
  // Reject Windows drive paths, backslash traversal, and empty path segments.
  for (const badPath of ['C:/windows/system.ini', 'src\\..\\secret', 'src//file.js', 'src/./file.js', 'src/file.js:stream', 'src/CON.txt', 'src/trailing.', 'src/new\nline.js', 'src/tab\tfile.js', 'src/escape\x1bfile.js', 'src/del\x7ffile.js']) {
    const bad = triage(root, () => ({ windowsSourcePathsSafe: false, fileCount: 1,
      blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 1, contentMismatches: [{ path: badPath,
        expectedSha256: 'a'.repeat(64), actualSha256: 'b'.repeat(64),
        expectedSize: 1, actualSize: 1 }] }));
    assert.equal(bad.manifestVerified, false);
    assert.ok(bad.evidenceIssues.includes('invalid-mismatch-path'), badPath);
    assert.equal(Object.values(bad.groups).flat().length, 0);
  }
  // Unicode bidirectional controls can disguise source paths in audit reports.
  // Reject them in both mismatch and missing/unsafe inventories.
  for (const control of ['\u202a', '\u202e', '\u2066', '\u2069']) {
    const deceptivePath = `src/${control}safe.js`;
    const mismatch = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 1, contentMismatches: [{ path: deceptivePath,
        expectedSha256: 'a'.repeat(64), actualSha256: 'b'.repeat(64),
        expectedSize: 1, actualSize: 1 }] }));
    assert.ok(mismatch.evidenceIssues.includes('invalid-mismatch-path'));
    const unsafe = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: ['unsafe-path'], issues: [], unsafeSourcePaths: [deceptivePath],
      contentMismatchCount: 0, contentMismatches: [] }));
    assert.ok(unsafe.evidenceIssues.includes('invalid-unsafe-path-format'));
  }
  // Duplicate entries cannot be treated as independent source evidence.
  const duplicateEntry = { path: 'src/safe.js', expectedSha256: 'a'.repeat(64),
    actualSha256: 'b'.repeat(64), expectedSize: 8, actualSize: 8 };
  const duplicates = triage(root, () => ({ windowsSourcePathsSafe: false, fileCount: 1,
    blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 2, contentMismatches: [duplicateEntry, { ...duplicateEntry }] }));
  assert.equal(duplicates.manifestVerified, false);
  assert.equal(duplicates.evidenceComplete, false);
  assert.ok(duplicates.evidenceIssues.includes('duplicate-mismatch-path'));
  assert.equal(duplicates.groups.code.length, 1);
  // Windows filesystems commonly treat path casing as equivalent. Distinct
  // spellings must not count as independent integrity evidence.
  const caseCollision = triage(root, () => ({ windowsSourcePathsSafe: false, fileCount: 2,
    blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 2, contentMismatches: [duplicateEntry,
      { ...duplicateEntry, path: 'SRC/SAFE.JS' }] }));
  assert.equal(caseCollision.evidenceComplete, false);
  assert.ok(caseCollision.evidenceIssues.includes('duplicate-mismatch-path'));
  assert.equal(caseCollision.groups.code.length, 1);
  const unsafeCaseCollision = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 2, blockers: ['unsafe-path'], issues: [],
    unsafeSourcePaths: ['src/Bad', 'SRC/bad'], contentMismatchCount: 0,
    contentMismatches: [] }));
  assert.equal(unsafeCaseCollision.evidenceComplete, false);
  assert.ok(unsafeCaseCollision.evidenceIssues.includes('duplicate-unsafe-path-entry'));
  // A path cannot simultaneously be trusted as a readable content mismatch
  // and classified unsafe; conflicting audit evidence must fail closed.
  const conflictingPaths = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: ['unsafe-path', 'content-mismatch'], issues: [],
    unsafeSourcePaths: ['SRC/SAFE.JS'], contentMismatchCount: 1,
    contentMismatches: [duplicateEntry] }));
  assert.equal(conflictingPaths.evidenceComplete, false);
  assert.ok(conflictingPaths.evidenceIssues.includes('mismatch-path-also-unsafe'));
  assert.equal(conflictingPaths.groups.code.length, 0);
  // Duplicate blocker records cannot count as distinct audit evidence.
  const duplicateBlockers = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: ['content-mismatch', 'content-mismatch'], issues: [],
    unsafeSourcePaths: [], contentMismatchCount: 1,
    contentMismatches: [duplicateEntry] }));
  assert.equal(duplicateBlockers.evidenceComplete, false);
  assert.ok(duplicateBlockers.evidenceIssues.includes('duplicate-audit-blocker'));
  // Malformed audit issues must not be silently treated as complete evidence.
  for (const issues of [[null], [''], [42]]) {
    const badIssues = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: ['source-issue'], issues,
      unsafeSourcePaths: [], contentMismatchCount: 0, contentMismatches: [] }));
    assert.equal(badIssues.evidenceComplete, false);
    assert.ok(badIssues.evidenceIssues.includes('invalid-audit-issue-entry'));
  }
  // A claimed inventory larger than the manifest cannot be trusted.
  const impossible = triage(root, () => ({ windowsSourcePathsSafe: false, fileCount: 1,
    blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 2, contentMismatches: [duplicateEntry,
      { ...duplicateEntry, path: 'src/second.js' }] }));
  assert.equal(impossible.evidenceComplete, false);
  assert.ok(impossible.evidenceIssues.includes('mismatch-inventory-exceeds-manifest'));
  // Disjoint inventories cannot collectively claim more paths than exist in
  // the manifest, even when neither inventory individually exceeds it.
  const combinedOverflow = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: ['unsafe-path', 'content-mismatch'], issues: [],
    unsafeSourcePaths: ['src/other.js'], contentMismatchCount: 1,
    contentMismatches: [duplicateEntry] }));
  assert.equal(combinedOverflow.evidenceComplete, false);
  assert.ok(combinedOverflow.evidenceIssues.includes('combined-inventory-exceeds-manifest'));
  assert.equal(combinedOverflow.groups.code.length, 1);
  // An alleged content mismatch with identical hashes is contradictory evidence.
  const identical = triage(root, () => ({ windowsSourcePathsSafe: false, fileCount: 1,
    blockers: ['content-mismatch'], issues: [], unsafeSourcePaths: [],
    contentMismatchCount: 1, contentMismatches: [{ ...duplicateEntry,
      actualSha256: duplicateEntry.expectedSha256 }] }));
  assert.equal(identical.evidenceComplete, false);
  assert.ok(identical.evidenceIssues.includes('identical-digests-in-mismatch'));
  assert.equal(identical.groups.code.length, 0);
  const unsafeEvidence = triage(root, () => ({ windowsSourcePathsSafe: false,
    fileCount: 1, blockers: ['unsafe-path'], issues: [],
    unsafeSourcePaths: ['src/bad', 'src/bad', ''],
    contentMismatchCount: 0, contentMismatches: [] }));
  assert.equal(unsafeEvidence.evidenceComplete, false);
  assert.ok(unsafeEvidence.evidenceIssues.includes('duplicate-unsafe-path-entry'));
  assert.ok(unsafeEvidence.evidenceIssues.includes('invalid-unsafe-path-entry'));
  for (const unsafePath of ['../outside', '/absolute', 'C:/drive', 'src\\bad', 'src//bad', 'src/NUL', 'src/trailing ', 'src/file:ads']) {
    const malformedUnsafe = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: ['unsafe-path'], issues: [],
      unsafeSourcePaths: [unsafePath], contentMismatchCount: 0, contentMismatches: [] }));
    assert.equal(malformedUnsafe.evidenceComplete, false);
    assert.ok(malformedUnsafe.evidenceIssues.includes('invalid-unsafe-path-format'), unsafePath);
  }
  // Diagnostic strings are untrusted and may reach terminal/log consumers.
  for (const bad of ['line\nbreak', 'escape\x1b[31m', 'x'.repeat(513)]) {
    const malformedBlocker = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: [bad], issues: [], unsafeSourcePaths: [],
      contentMismatchCount: 0, contentMismatches: [] }));
    assert.equal(malformedBlocker.evidenceComplete, false);
    assert.ok(malformedBlocker.evidenceIssues.includes('invalid-audit-blockers'));
    const malformedIssue = triage(root, () => ({ windowsSourcePathsSafe: false,
      fileCount: 1, blockers: [], issues: [bad], unsafeSourcePaths: [],
      contentMismatchCount: 0, contentMismatches: [] }));
    assert.equal(malformedIssue.evidenceComplete, false);
    assert.ok(malformedIssue.evidenceIssues.includes('invalid-audit-issue-entry'));
  }
  console.log('PASS source-integrity-triage: drift classified, baseline unchanged, missing root fail-closed');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
