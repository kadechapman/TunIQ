#!/usr/bin/env node
'use strict';
// Static Windows launcher contract tests only: cannot prove PowerShell or
// native Electron startup on Linux. CI's build-only default is preserved.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const ps = fs.readFileSync(path.join(root, 'tools/windows-build-offline-preview.ps1'), 'utf8');
const cmd = fs.readFileSync(path.join(root, 'BUILD_AND_OPEN_OFFLINE_UI.cmd'), 'utf8');
const ci = fs.readFileSync(path.join(root, '.github/workflows/windows-offline-preview-build.yml'), 'utf8');
let checks = 0;
function check(name, predicate) { assert.ok(predicate, name); checks++; }
check('PowerShell has opt-in launch parameter', ps.startsWith('# Optional interactive launch') &&
  ps.includes('param([switch]$LaunchAfterVerifiedBuild)'));
check('CI does not request interactive launch', ci.includes('windows-build-offline-preview.ps1') &&
  !ci.includes('-LaunchAfterVerifiedBuild'));
check('User launcher opts in to verified interactive launch', cmd.includes('powershell.exe -NoProfile') &&
  cmd.includes('windows-build-offline-preview.ps1" -LaunchAfterVerifiedBuild'));
check('Launcher is anchored to extracted directory', cmd.includes('cd /d "%~dp0"'));
check('Launcher propagates build or launch failure', cmd.includes('set "RESULT=%ERRORLEVEL%"') &&
  cmd.includes('exit /b %RESULT%'));
check('User launcher labels offline no-ECU operation', cmd.includes('NO ECU READ, WRITE OR FLASH') &&
  cmd.includes('NOT the full TunIQ tuning application'));
const integrity = ps.indexOf("Step 'Record delivered preview tree integrity'");
const delivered = ps.indexOf("$deliveredExe = Join-Path $output");
const launch = ps.indexOf('if ($LaunchAfterVerifiedBuild) {');
const launchExe = ps.indexOf('Start-Process -FilePath $deliveredExe -WorkingDirectory $output -PassThru -ErrorAction Stop');
const success = ps.indexOf('$script:buildSucceeded = $true');
check('Interactive launch occurs after delivered smoke and integrity',
  integrity >= 0 && delivered < integrity && integrity < launch && launch < launchExe && launchExe < success);
check('Interactive process must survive until window appears',
  ps.includes('$interactivePreview.Refresh()') && ps.includes('if ($interactivePreview.HasExited)'));
check('Normal launch verifies a visible native HWND and exact preview title',
  ps.includes('[TunIQOfflineWindowProbe]::IsWindowVisible($handle)') &&
  ps.includes('$interactivePreview.MainWindowHandle') &&
  ps.includes('$interactivePreview.MainWindowTitle -ceq $expectedTitle') &&
  ps.includes('$dash = [char]0x2014') &&
  ps.includes('$expectedTitle = "TunIQ $dash OFFLINE UI PREVIEW $dash NO ECU ACCESS"'));
check('Interactive normal launch fails closed after bounded wait',
  ps.includes('$deadline = (Get-Date).AddSeconds(15)') &&
  ps.includes('if (-not $windowSeen) {') &&
  ps.includes('if (-not $interactiveApproved) {') &&
  ps.includes('Stop-Process -Id $interactivePreview.Id -Force -ErrorAction SilentlyContinue'));
check('No visible-window evidence can be emitted on failure', () => {
  const passed = ps.indexOf('$windowSeen = $true');
  const check = ps.indexOf('if (-not $windowSeen) {', passed);
  const proof = ps.indexOf("'interactive-window-evidence.json'", check);
  return passed > 0 && check > passed && proof > check;
});
check('Outcome differentiates process alive from window visible',
  ps.includes('interactiveLaunchWindowVisible = $script:interactiveLaunchWindowVisible') &&
  ps.includes('interactiveLaunchProcessAlive = $script:interactiveLaunchProcessAlive'));

check('Interactive proof binds visible HWND to exact delivered EXE and diagnostic run',
  ps.includes("deliveredExeSha256 = $deliveredHash.ToLowerInvariant()") &&
  ps.includes("diagnosticsRun = Split-Path $diagnostics -Leaf") &&
  ps.includes("deliveredPreviewDirectory = Split-Path $output -Leaf") &&
  ps.includes("probeMethod = 'user32-IsWindowVisible-and-exact-title'"));
check('No full-app entry point launched by new wrapper', !/src\\main\.js|npm start|flash\.js|pcmhammer\.exe/i.test(cmd));
check('Outcome differentiates interactive attempt and running process',
  ps.includes('interactiveLaunchRequested = [bool]$LaunchAfterVerifiedBuild') &&
  ps.includes('interactiveLaunchProcessAlive = $script:interactiveLaunchProcessAlive'));
check('No interactive launch when switch absent',
  ps.includes('if ($LaunchAfterVerifiedBuild) {') &&
  (ps.match(/Start-Process -FilePath \$deliveredExe -WorkingDirectory \$output -PassThru -ErrorAction Stop/g) || []).length === 1);
console.log(`Windows one-click offline preview launch contracts: ${checks}/${checks} passed (static source tests, NOT Windows runtime).`);
