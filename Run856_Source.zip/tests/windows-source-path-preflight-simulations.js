'use strict';
// Synthetic source paths and local temporary files only. No Windows build or ECU access.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { auditWindowsPaths, inspectWindowsSourceLayout } = require('../tools/windows-source-path-preflight');

function runWindowsSourcePathPreflightSimulations({ quiet = false } = {}) {
  let passed = 0;
  const check = (value, label) => { assert.ok(value, label); passed++; };
  const has = (paths, code) => auditWindowsPaths(paths).issues.some(issue => issue.code === code);
  check(auditWindowsPaths(['src/main.js', 'src/renderer/app.js']).safe, 'ordinary source paths accepted');
  check(has(['src/Foo.js', 'src/foo.js'], 'windows-case-collision'), 'case-folded filename collision rejected');
  check(has(['src/Foo/a.js', 'src/foo/b.js'], 'windows-case-collision'), 'case-folded directory collision rejected');
  check(has(['src/a.js', 'src/a.js'], 'duplicate-source-path'), 'duplicate manifest path rejected');
  check(has(['src/a', 'src/a/file.js'], 'file-directory-conflict'), 'file-as-directory conflict rejected');
  check(has(['src/a/file.js', 'src/a'], 'file-directory-conflict'), 'reverse-order file-directory conflict rejected');
  for (const unsafe of ['CON', 'aux.txt', 'COM1.log', 'LPT9', 'COM¹.txt', 'CONOUT$', 'file.', 'file ', 'a:b', 'a?b']) {
    check(has([`src/${unsafe}`], 'invalid-windows-component'), `Windows-invalid name ${unsafe} rejected`);
  }
  for (const unsafe of ['../outside', '/absolute', 'src//file', 'src/./file', 'src/../file', 'src\\file']) {
    check(!auditWindowsPaths([unsafe]).safe, `unsafe relative path ${unsafe} rejected`);
  }
  check(has(['a'.repeat(241)], 'invalid-relative-path'), 'overlong relative path rejected');
  check(has(['src/' + 'a'.repeat(256)], 'invalid-relative-path') ||
    has(['src/' + 'a'.repeat(256)], 'invalid-windows-component'), 'overlong component rejected');
  check(!auditWindowsPaths(null).safe, 'nonarray manifest paths rejected');
  check(!auditWindowsPaths(Array(10001).fill('a')).safe, 'excessive source file count rejected');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-windows-paths-'));
  const file = path.join(dir, 'src', 'safe.txt');
  const manifest = path.join(dir, 'SOURCE_MANIFEST.json');
  const digestFile = path.join(dir, 'SOURCE_MANIFEST_SHA256.txt');
  const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
  const safeRow = { path: 'src/safe.txt', size: 2, sha256: sha('ok') };
  const writeManifest = (extraRows = []) => {
    const bytes = Buffer.from(JSON.stringify({ files: [safeRow, ...extraRows] }));
    fs.writeFileSync(manifest, bytes);
    fs.writeFileSync(digestFile, `${sha(bytes)}  SOURCE_MANIFEST.json\n`);
  };
  try {
    fs.mkdirSync(path.dirname(file));
    fs.writeFileSync(file, 'ok');
    writeManifest();
    check(inspectWindowsSourceLayout(dir).windowsSourcePathsSafe, 'valid local source manifest accepted');
    fs.writeFileSync(file, 'no');
    check(inspectWindowsSourceLayout(dir).blockers.includes('source-manifest-content-mismatch'), 'modified source content rejected');
    fs.writeFileSync(file, 'ok');
    fs.writeFileSync(digestFile, '0'.repeat(64) + '  SOURCE_MANIFEST.json\n');
    check(inspectWindowsSourceLayout(dir).blockers.includes('manifest-digest-mismatch'), 'tampered manifest checksum rejected');
    writeManifest();
    fs.unlinkSync(file);
    check(inspectWindowsSourceLayout(dir).blockers.includes('source-path-missing-or-unsafe'), 'missing source file rejected');
    check(inspectWindowsSourceLayout(dir).unsafeSourcePaths.includes('src/safe.txt'), 'missing file path named in diagnostic');
    fs.writeFileSync(file, 'ok');
    // Historical test-result logs may be absent in a clean Git checkout,
    // but the exemption must never hide missing code or unsafe links.
    fs.mkdirSync(path.join(dir, 'test-results'));
    const absentRow = relative => ({ path: relative, size: 2, sha256: sha('ok') });
    writeManifest([absentRow('test-results/old-suite.log')]);
    check(inspectWindowsSourceLayout(dir).windowsSourcePathsSafe,
      'absent direct-child historical log remains optional');
    const presentLog = path.join(dir, 'test-results', 'old-suite.log');
    fs.writeFileSync(presentLog, 'no');
    check(inspectWindowsSourceLayout(dir).blockers.includes('source-manifest-content-mismatch'),
      'present historical log must match its manifest digest');
    fs.unlinkSync(presentLog);
    writeManifest([absentRow('test-results/untracked.js')]);
    check(inspectWindowsSourceLayout(dir).blockers.includes('source-path-missing-or-unsafe'),
      'missing non-log file inside test-results is rejected');
    writeManifest([absentRow('test-results/nested/old-suite.log')]);
    check(inspectWindowsSourceLayout(dir).blockers.includes('source-path-missing-or-unsafe'),
      'missing nested historical log is not exempt');
    const danglingLog = path.join(dir, 'test-results', 'dangling.log');
    try {
      fs.symlinkSync(path.join(dir, 'missing-target'), danglingLog);
      writeManifest([absentRow('test-results/dangling.log')]);
      check(inspectWindowsSourceLayout(dir).blockers.includes('source-path-missing-or-unsafe'),
        'dangling log symlink is not treated as an absent log');
      fs.unlinkSync(danglingLog);
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      if (!quiet) console.log('Windows source path preflight: symlink case unavailable on this filesystem');
    }
    writeManifest();
    // A missing log beneath a symlinked parent must not be exempt either.
    fs.rmdirSync(path.join(dir, 'test-results'));
    try {
      fs.mkdirSync(path.join(dir, 'outside-logs'));
      fs.symlinkSync(path.join(dir, 'outside-logs'), path.join(dir, 'test-results'), 'dir');
      writeManifest([absentRow('test-results/old-suite.log')]);
      check(inspectWindowsSourceLayout(dir).blockers.includes('source-path-missing-or-unsafe'),
        'symlinked historical-log directory is not exempt');
      fs.unlinkSync(path.join(dir, 'test-results'));
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      if (!quiet) console.log('Windows source path preflight: directory symlink case unavailable');
    }
    fs.mkdirSync(path.join(dir, 'test-results'));
    writeManifest();
    const cli = path.resolve(__dirname, '../tools/windows-source-path-preflight.js');
    const accepted = spawnSync(process.execPath, [cli, dir, '--require-safe'], { encoding: 'utf8' });
    check(accepted.status === 0 && JSON.parse(accepted.stdout).windowsSourcePathsSafe, 'strict CLI accepts verified manifest');
    fs.unlinkSync(file);
    const blocked = spawnSync(process.execPath, [cli, dir, '--require-safe'], { encoding: 'utf8' });
    check(blocked.status === 2, 'strict CLI blocks missing source');
    const report = spawnSync(process.execPath, [cli, dir, '--report'], { encoding: 'utf8' });
    check(report.status === 0 && !JSON.parse(report.stdout).windowsSourcePathsSafe, 'report mode does not assert readiness');
    check(spawnSync(process.execPath, [cli, dir, '--unknown'], { encoding: 'utf8' }).status === 1,
      'unknown CLI flag rejected');
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  if (!quiet) console.log(`Windows source path preflight: ${passed} offline checks passed (no Windows build)`);
  return { passed, windowsBuildVerified: false, physicalHardwareVerified: false };
}
if (require.main === module) runWindowsSourcePathPreflightSimulations();
module.exports = { runWindowsSourcePathPreflightSimulations };
