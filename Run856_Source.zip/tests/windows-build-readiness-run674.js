'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
 ['query delimiter', '../packages/alpha?mode=dev', true],
 ['fragment delimiter', '../packages/alpha#dev', true],
 ['query alone', '?workspace', true],
 ['fragment alone', '#workspace', true],
 ['valid sibling workspace', '../packages/alpha', false],
 ['valid nested workspace', '../packages/sub/alpha', false],
];
for (const [label, resolved, blocked] of cases) {
 const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq674-'));
 try {
  const pkg = {name:'tuniq',version:'1.0.0',dependencies:{alpha:'file:packages/alpha'}};
  const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:pkg.dependencies},'node_modules/alpha':{link:true,resolved}}};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify(pkg));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
  const result = assess(root);
  assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+' '+JSON.stringify(result.blockers));
  assert.strictEqual(result.ecmWriteAuthorized,false,label);
  assert.strictEqual(result.nativeWindowsRuntimeVerified,false,label);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run674: 6 dependency-tree workspace-link fixtures passed');
