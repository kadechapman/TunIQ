'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { stage, verify } = require('../tools/stage-browser-preview');
const scratch = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-browser-test-'));
let count = 0;
function check(name, fn) { fn(); count++; console.log(`PASS ${name}`); }
try {
  const output = path.join(scratch, 'preview');
  check('stage zero-dependency preview', () => assert.equal(stage(output).hardwareCodeIncluded, false));
  check('verify staged files', () => assert.equal(verify(output).verifiedFiles, 7));
  check('no production main, OBD or flash modules', () => {
    assert.deepEqual(fs.readdirSync(output).sort(), ['MANIFEST_SHA256.json','OPEN_PREVIEW.cmd','README.txt','src'].sort());
    assert.deepEqual(fs.readdirSync(path.join(output,'src','renderer')).sort(),
      ['app.js','browser-preview-bridge.js','engine-catalog.js','index.html','styles.css'].sort());
  });
  check('CSP retained and browser bridge loaded before renderer', () => {
    const html = fs.readFileSync(path.join(output,'src','renderer','index.html'),'utf8');
    assert.match(html, /script-src 'self'/);
    assert.ok(html.indexOf('browser-preview-bridge.js') < html.indexOf('engine-catalog.js'));
    assert.match(html, /ALL ECU OPERATIONS DISABLED/);
  });
  check('tampered staged content rejected', () => {
    const p = path.join(output,'src','renderer','app.js');
    fs.appendFileSync(p,'\n// tampered');
    assert.throws(() => verify(output), /integrity-failed/);
  });
  check('nonempty output refused', () => assert.throws(() => stage(output), /nonempty-output/));
  check('unsafe in-checkout output refused', () => assert.throws(() => stage(path.join(__dirname,'foo')), /overlapping-output/));
  check('browser API exposes no hardware or file write methods', () => {
    const listeners = {};
    const window = {};
    const document = { addEventListener: (name, fn) => { listeners[name] = fn; } };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../tools/browser-preview-bridge.js'),'utf8'), { window, document });
    assert.deepEqual(Object.keys(window.tuniq).sort(), ['getBootstrap','getKnowledgeState','getProjectFiles',
      'getWorkspaceSummary','listProjects','listTuneLibrary','setUiPreferences'].sort());
    assert.equal(typeof window.tuniq.listTuneLibrary, 'function');
    for (const method of ['connectDevice','importBin','flash','testWrite','writeCalibration','exportBin'])
      assert.equal(window.tuniq[method], undefined);
  });
  check('browser API blocks clicks on action buttons', () => {
    const listeners = {};
    const window = {};
    const document = { addEventListener: (name, fn) => { listeners[name] = fn; } };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../tools/browser-preview-bridge.js'),'utf8'), { window, document });
    let prevented = 0;
    const action = { closest: selector => selector === 'button' ? action : null, matches: () => false };
    listeners.click({ target: action, preventDefault: () => prevented++, stopImmediatePropagation: () => prevented++ });
    assert.equal(prevented, 2);
  });
  check('navigation marker on an ancestor never authorizes an action button', () => {
    const listeners = {};
    const window = {};
    const document = { addEventListener: (name, fn) => { listeners[name] = fn; } };
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../tools/browser-preview-bridge.js'),'utf8'), { window, document });
    let prevented = 0;
    // A wrapper with data-jump would match Element.closest() on the button,
    // but must not authorize the nested action button.
    const ancestor = { dataset: { jump: 'flash' } };
    const unsafeButton = {
      closest: selector => selector === 'button' ? unsafeButton :
        selector.includes('[data-jump]') ? ancestor : null,
      matches: () => false
    };
    listeners.click({ target: unsafeButton, preventDefault: () => prevented++,
      stopImmediatePropagation: () => prevented++ });
    assert.equal(prevented, 2);
  });
  check('real navigation button remains enabled while ordinary actions remain blocked', () => {
    const listeners = {};
    vm.runInNewContext(fs.readFileSync(path.join(__dirname,'../tools/browser-preview-bridge.js'),'utf8'),
      { window: {}, document: { addEventListener: (name, fn) => { listeners[name] = fn; } } });
    let prevented = 0;
    const navigation = { closest: selector => selector === 'button' ? navigation : null,
      matches: selector => selector.includes('button[data-page]') };
    const action = { closest: selector => selector === 'button' ? action : null,
      matches: () => false };
    for (const target of [navigation, action]) listeners.click({ target,
      preventDefault: () => prevented++, stopImmediatePropagation: () => prevented++ });
    assert.equal(prevented, 2);
  });
} finally { fs.rmSync(scratch, { recursive: true, force: true }); }

// Async preference API regression: mutations of returned values must never
// mutate internal state or evade the bounded page/scroll validation.
(async () => {
  const context = vm.createContext({ window: {}, document: { addEventListener() {} } });
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../tools/browser-preview-bridge.js'), 'utf8'), context);
  const returned = await vm.runInContext(
    "window.tuniq.setUiPreferences({recentPages:['workflow'],scrollPositions:{workflow:10}})", context);
  returned.uiPreferences.recentPages.push('invalid!');
  returned.uiPreferences.scrollPositions.workflow = -10;
  const snapshot = await context.window.tuniq.getBootstrap();
  assert.equal(JSON.stringify(snapshot.settings.uiPreferences),
    JSON.stringify({recentPages:['workflow'],scrollPositions:{workflow:10}}));
  snapshot.settings.uiPreferences.recentPages.push('invalid!');
  snapshot.settings.uiPreferences.scrollPositions.workflow = -20;
  const later = await context.window.tuniq.getBootstrap();
  assert.equal(JSON.stringify(later.settings.uiPreferences),
    JSON.stringify({recentPages:['workflow'],scrollPositions:{workflow:10}}));
  count++;
  console.log('PASS returned preference snapshots cannot mutate internal preview settings');
  // No caller may forge a successful flash operation through shared demo data.
  const first = await context.window.tuniq.getBootstrap();
  first.flash.status = 'success';
  first.flash.history.push({ action: 'flash', status: 'success' });
  const summary = await context.window.tuniq.getWorkspaceSummary();
  assert.equal(summary.flash.status, 'blocked');
  assert.equal(summary.flash.history.length, 0);
  summary.flash.status = 'complete';
  summary.flash.history.push({ action: 'test-write', status: 'success' });
  const next = await context.window.tuniq.getBootstrap();
  assert.equal(next.flash.status, 'blocked');
  assert.equal(next.flash.history.length, 0);
  assert.notStrictEqual(first.flash, summary.flash);
  assert.notStrictEqual(summary.flash, next.flash);
  count++;
  console.log('PASS browser preview flash snapshots cannot forge subsequent operation status');
  console.log(`BROWSER_PREVIEW_FIXTURES ${count}/${count} PASS`);
})().catch(error => { console.error(error); process.exitCode = 1; });
