'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['colon in final component','../packages/foo:bar',true],
 ['colon in parent component','../packages:bad/foo',true],
 ['colon with backslash','..\\packages\\foo:bar',true],
 ['drive relative','C:packages\\foo',true],
 ['ordinary relative','../packages/foo',false],
 ['ordinary backslash','..\\packages\\foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq677-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run677: six Windows colon/path fixtures passed');
