'use strict';
// Filesystem-only: no PCM Hammer launch, COM port, ECU access, or write.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01_BIN_SIZE, validateP01ReadFile, classifyPcmHammerResult } = require('../src/pcmhammer');

function runPcmHammerReadResultConsistencySimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-proof-consistency-'));
  let passed = 0;
  try {
    const file = path.join(root, 'complete.bin');
    fs.writeFileSync(file, Buffer.alloc(P01_BIN_SIZE, 0x59));
    const invalid = [
      { operation: 'readProperties', success: true, stopCode: null },
      { operation: 'testWrite', success: true, stopCode: null },
      { operation: 'read', success: true, stopCode: 42 },
      { operation: 'read', success: true, stopCode: { reason: 'failure' } },
      { operation: 'read', success: true, okExit: false },
      { operation: 'read', success: true, readCompleted: false },
      { operation: 'read', success: true, partial: true },
      { operation: 'read', success: true, blockFailures: 1 },
      { operation: 'read', success: true, blockFailures: '0' },
      { operation: 'read', success: true, readIntegrityFailure: true },
      { operation: 'read', success: true, readCompletionFailure: true },
      { operation: 'read', success: true, readUnitFailure: true },
      { operation: 'read', success: true, kernelTransferFailure: true },
      { operation: 'read', success: true, adapterOpenTimeout: true },
      { operation: 'read', success: true, disconnect: true }
    ];
    for (const evidence of invalid) {
      const result = validateP01ReadFile(file, evidence);
      assert.strictEqual(result.valid, false, `conflicting read proof accepted: ${JSON.stringify(evidence)}`);
      assert.strictEqual(result.code, 'read-result-conflict');
      passed++;
    }
    for (const log of ['Read not completed', 'Read completed: false',
      'Read completed unsuccessfully', 'Read status: failed', 'Read did not finish']) {
      const proof = classifyPcmHammerResult('read', `${log}\nRead completed successfully`, 0);
      assert.strictEqual(proof.success, false, `negated Full Read accepted: ${log}`);
      assert.strictEqual(proof.stopCode, 'read-incomplete');
      assert.strictEqual(validateP01ReadFile(file, proof).valid, false);
      passed++;
    }
    const propertyProof = classifyPcmHammerResult('readProperties',
      'OSID: 12212156\nRead completed: false', 0);
    assert.strictEqual(propertyProof.success, false);
    assert.strictEqual(propertyProof.stopCode, 'read-incomplete'); passed++;
    const classified = classifyPcmHammerResult('read', 'Read completed successfully', 0);
    assert.strictEqual(classified.success, true, 'control classifier must prove a completed read');
    assert.strictEqual(validateP01ReadFile(file, classified).valid, true,
      'a consistent classified read remains admissible'); passed++;
    assert.strictEqual(validateP01ReadFile(file, { success: true }).valid, true,
      'existing minimal synthetic read-proof fixture remains supported'); passed++;
    assert.strictEqual(validateP01ReadFile(file, { success: false }).valid, false,
      'explicit failed read remains rejected'); passed++;
    assert.strictEqual(fs.statSync(file).size, P01_BIN_SIZE, 'verification must not modify the BIN'); passed++;
    console.log(`✓ PCM Hammer Full Read result consistency: ${passed} offline checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) runPcmHammerReadResultConsistencySimulations();
module.exports = { runPcmHammerReadResultConsistencySimulations };
