'use strict';
// Read-only parser resource limits: synthetic text only; no ECU or serial calls.
const assert = require('assert');
const { normalizeText, parseCsvText, MAX_LOG_BYTES, MAX_LOG_ROWS, MAX_LOG_COLUMNS, MAX_CSV_LINE_CHARS } = require('../src/log-import');

function runLogImportLimitsSimulations({ quiet = false } = {}) {
  let passed = 0;
  const small = 'Time,Engine RPM,VIN\n0,850,PRIVATEVIN\n1,900,PRIVATEVIN\n';
  const parsed = parseCsvText(small);
  assert.equal(parsed.rows.length, 2);
  assert(parsed.privateRemoved.includes('VIN'));
  assert(!JSON.stringify(parsed.rows).includes('PRIVATEVIN')); passed++;

  const hugeRows = 'Time,Engine RPM\n' + '0,800\n'.repeat(MAX_LOG_ROWS + 1);
  assert.throws(() => parseCsvText(hugeRows), /50,000 row parsing limit/); passed++;
  assert.throws(() => normalizeText(hugeRows, '.csv'), /50,000 row parsing limit/); passed++;
  const exactRows = 'Time,Engine RPM\n' + '0,800\n'.repeat(MAX_LOG_ROWS);
  assert.equal(parseCsvText(exactRows).rows.length, MAX_LOG_ROWS); passed++;
  // Previously, Math.max(...times) threw RangeError for a large otherwise valid log.
  assert.equal(parseCsvText(exactRows).quality.durationSeconds, 0); passed++;

  const tooManyColumns = Array.from({ length: MAX_LOG_COLUMNS + 1 }, (_, i) => i === 0 ? 'Engine RPM' : `Field ${i}`).join(',');
  assert.throws(() => parseCsvText(tooManyColumns + '\n850'), /128 column parsing limit/); passed++;
  assert.throws(() => parseCsvText('Engine RPM\n' + Array.from({ length: MAX_LOG_COLUMNS + 1 }, () => '850').join(',')), /128 column parsing limit/); passed++;
  assert.throws(() => parseCsvText('Engine RPM,Time\n850,' + 'A'.repeat(MAX_CSV_LINE_CHARS)), /65,536 character limit/); passed++;
  assert.throws(() => parseCsvText('Engine RPM,Time\n850,' + 'A'.repeat(MAX_LOG_BYTES)), /16 MB text parsing limit/); passed++;

  const base = { format: 'TunIQ Web Log Package', columns: ['rpm','speed'], rows: [{rpm: 800, speed: 0}] };
  assert.equal(normalizeText(JSON.stringify(base), '.tuniqlog').rows.length, 1); passed++;
  assert.throws(() => normalizeText(JSON.stringify({ ...base, rows: Array(MAX_LOG_ROWS + 1).fill({ rpm: 800 }) }), '.tuniqlog'), /50,000 row parsing limit/); passed++;
  assert.throws(() => normalizeText(JSON.stringify({ ...base, columns: Array(MAX_LOG_COLUMNS + 1).fill('rpm') }), '.json'), /128 column parsing limit/); passed++;
  assert.throws(() => normalizeText(' '.repeat(MAX_LOG_BYTES + 1), '.tuniqlog'), /16 MB text parsing limit/); passed++;

  if (!quiet) console.log(`✓ Log parser bounded-resource simulations: ${passed} checks passed (no hardware)`);
  return { passed, hardwareVerified: false };
}
if (require.main === module) runLogImportLimitsSimulations();
module.exports = { runLogImportLimitsSimulations };
