'use strict';
// Source-only tests. Native Windows startup is NOT exercised here.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const code = fs.readFileSync(path.join(root, 'tools/windows-browser-preview-launcher.c'), 'utf8');
const build = fs.readFileSync(path.join(root, 'tools/build-windows-browser-preview-launcher.sh'), 'utf8');
let count = 0;
function check(label, fn) { fn(); count++; console.log('PASS ' + label); }
check('Windows GUI entry point', () => assert.match(code, /void mainCRTStartup\(void\)/));
check('Only packaged local HTML is launched', () => assert.match(code, /src\\\\renderer\\\\index\.html/));
check('No external network URL in launcher', () => assert.doesNotMatch(code, /https?:|WinHttp|InternetOpen|URLDownloadToFile/i));
check('No ECU modules or external processes are launched', () => assert.doesNotMatch(code, /flash\.js|pcmhammer|OBD|CreateProcess|WinExec|ShellExecuteA/i));
check('Missing HTML fails closed', () => assert.match(code, /attrs==0xffffffffUL\s*\|\|\s*\(attrs\s*&\s*\(0x10UL\s*\|\s*0x400UL\)\)/));
check('Reparse-point HTML is rejected (source inspection)', () => assert.match(code, /0x400UL/));
check('File attributes are read from the expected preview path', () => assert.match(code, /DWORD attrs=GetFileAttributesW\(path\)/));
check('Launcher handles ShellExecute failure', () => assert.match(code, /<=32ULL/));
check('Build uses x64 Windows PE GUI and no CRT', () => {
  assert.match(build, /-target x86_64-pc-windows-msvc/);
  assert.match(build, /\/subsystem:windows \/entry:mainCRTStartup \/nodefaultlib/);
});
check('Build stamps deterministic PE header', () => assert.match(build, /\/timestamp:0/));
check('Build refuses populated output directory', () => assert.match(build, /Refusing nonempty output directory/));
check('No import for serial/ECU communication', () => {
  const files = ['kernel32.def','shell32.def','user32.def'];
  const exports = files.map(f => fs.readFileSync(path.join(root,'tools/win-browser-imports',f),'utf8')).join('\n');
  assert.doesNotMatch(exports, /CreateFile|ReadFile|WriteFile|DeviceIoControl|WinHttp|InternetOpen|LoadLibrary|GetProcAddress/);
  assert.match(exports, /ShellExecuteW/);
});
console.log(`WINDOWS_BROWSER_LAUNCHER_SOURCE_FIXTURES ${count}/${count} PASS (NOT native Windows execution)`);
