'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['matching both', 'tuniq', '1.0.0', false],
  ['wrong name', 'other', '1.0.0', true],
  ['wrong version', 'tuniq', '2.0.0', true],
  ['wrong both', 'other', '2.0.0', true],
  ['nonstring name', 7, '1.0.0', true],
  ['null version', 'tuniq', null, true],
  ['absent optional identity', undefined, undefined, false],
];
for (const [label, name, version, blocked] of cases) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq669-'));
  try {
    const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0'}}};
    if (name !== undefined) lock.name = name;
    if (version !== undefined) lock.version = version;
    fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0'}));
    fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
    const result = assess(root);
    assert.strictEqual(result.blockers.includes('package-lock-top-level-identity-mismatch'),blocked,label);
    assert.strictEqual(result.ecmWriteAuthorized,false,label);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false,label);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
console.log('Run669: 7 top-level lockfile identity fixtures passed');
