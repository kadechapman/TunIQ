const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { FlashManager } = require('../src/flash');

async function runReadOnlyBetaGuardSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-only-beta-'));
  let portCalls = 0;
  try {
    const manager = new FlashManager({
      dataRoot: () => path.join(root, 'Data'),
      getActiveProject: () => ({ id: 'mock', name: 'Mock', folder: path.join(root, 'Project') }),
      getToolPath: () => '',
      releasePort: async () => { portCalls++; return { released: true }; },
      inspectExclusiveSession: async () => { portCalls++; return { blocked: false }; },
      probePortLock: async () => { portCalls++; return { available: true }; }
    });
    assert.equal(manager.readOnlyBeta, true, 'default constructor must be read-only');
    assert.equal(manager.status().readOnlyBeta, true);
    assert.equal(manager.status().capabilities.testWrite, false);
    assert.equal(manager.status().capabilities.writeCalibration, false);
    assert.equal(manager.status().capabilities.writeFull, false);
    assert.equal(manager.status().capabilities.recovery, false);
    assert.equal(manager.status().assistedAvailable, false);
    for (const operation of ['testWrite', 'writeCalibration', 'writeFull', 'recovery', 'unsupported']) {
      await assert.rejects(manager.start(operation, { device: 'COM4', readOnlyBeta: false, allowSimulatedWrites: true }), error => error.code === 'read-only-beta-write-blocked');
      assert.throws(() => manager.prepareAssisted(operation, {}), error => error.code === 'read-only-beta-write-blocked');
    }
    for (const operation of ['read', 'readProperties']) {
      assert.equal(manager.assertReadOnlyBetaOperation(operation), operation);
      await assert.rejects(manager.launchAssisted(operation, {}), error => error.code === 'read-only-beta-external-tool-blocked');
    }
    assert.equal(manager.assertReadOnlyBetaOperation('identify'), 'readProperties');
    // Regression: beta.47 accepted an arbitrary saved "readProperties" command
    // as the first CLI profile, even when it contained a write command.
    const fakeCli = path.join(root, 'PcmHammerCLI.exe');
    fs.writeFileSync(fakeCli, 'not executable; preflight only');
    const dangerous = ['write-full', '--port', '{device}', '--input', 'unapproved.bin'];
    manager.saveConfig({ executable: fakeCli, device: 'COM4' });
    manager.saveTemplates({ readProperties: dangerous, read: ['write-calibration', '{output}'] });
    const readPreflight = manager.preflight('readProperties', { device: 'COM4' });
    assert(readPreflight.candidateProfiles.length > 0, 'known built-in read-only profiles remain available');
    assert(readPreflight.candidateProfiles.every(profile => profile.id !== 'configured-template'),
      'unreviewed custom CLI templates must never be selected in read-only beta');
    assert(readPreflight.candidateProfiles.every(profile =>
      !profile.templates.readProperties.some(arg => /write|recover|erase|flash/i.test(arg))),
      'read-only profiles must not include write/erase/recovery verbs');
    assert.equal(readPreflight.template, null, 'preflight must not return an executable custom template');
    // Regression: beta.50 remembered a probed executable SHA-256 but never
    // checked it again before read preflight or device discovery.
    const originalCliBytes = fs.readFileSync(fakeCli);
    const pinnedDigest = crypto.createHash('sha256').update(originalCliBytes).digest('hex');
    manager.saveConfig({ backend: { executable: fakeCli, sha256: pinnedDigest } });
    fs.writeFileSync(fakeCli, 'changed executable after probe');
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'cli-executable-integrity-changed',
      'read preflight must refuse an executable modified since CLI probe');
    await assert.rejects(manager.discoverCliDevices(),
      error => error.code === 'cli-executable-integrity-changed',
      'device discovery must not execute a modified CLI');
    await assert.rejects(manager.probe(),
      error => error.code === 'cli-executable-integrity-changed',
      're-probing must not silently rebaseline a modified executable');
    assert.equal(manager.status().configured, false,
      'changed executable must not be advertised as configured');
    assert.equal(manager.status().cliIntegrityBlocked, true);
    fs.writeFileSync(fakeCli, originalCliBytes);
    assert.equal(manager.status().cliIntegrityBlocked, false,
      'restored executable bytes must match the pinned digest');
    manager.saveConfig({ backend: { executable: fakeCli, sha256: 'invalid-digest' } });
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'cli-executable-integrity-changed',
      'malformed pinned hashes must fail closed');
    manager.saveConfig({ backend: { executable: path.join(root, 'other-cli.exe'), sha256: pinnedDigest } });
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'cli-executable-integrity-changed',
      'pinned executable path changes must also fail closed');
    manager.saveConfig({ backend: { executable: fakeCli, sha256: pinnedDigest } });
    // The process inventory and COM handoff are asynchronous. An executable
    // swapped after preflight must be stopped before the first CLI spawn.
    manager.inspectExclusiveSession = async () => {
      fs.writeFileSync(fakeCli, 'modified during asynchronous ownership inspection');
      return { blocked: false, conflicts: [] };
    };
    manager.preparePort = async () => ({ port: 'COM4', leaseId: 'synthetic-only', candidates: [] });
    await assert.rejects(manager.start('readProperties', { device: 'COM4' }),
      error => error.code === 'cli-executable-integrity-changed',
      'post-handoff integrity check must stop changed CLI before spawning');
    assert.equal(manager.session, null, 'no session may start after a post-preflight integrity change');
    fs.writeFileSync(fakeCli, originalCliBytes);

    // Regression: beta.51 allowed a SHA-256 pin with no saved executable path,
    // so the selected executable could be relocated without path validation.
    const pinnedHash = require('crypto').createHash('sha256').update(fs.readFileSync(fakeCli)).digest('hex');
    manager.saveConfig({ backend: { product: 'PCM Hammer', sha256: pinnedHash } });
    assert.equal(manager.status().cliIntegrityBlocked, true,
      'a saved digest without its original executable path must fail closed');
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'cli-executable-integrity-changed');
    manager.saveConfig({ backend: { product: 'PCM Hammer', executable: fakeCli, sha256: { toString: 'forged' } } });
    assert.equal(manager.status().cliIntegrityBlocked, true,
      'malformed non-string digest must fail closed');
    manager.saveConfig({ backend: { product: 'PCM Hammer', executable: fakeCli, sha256: pinnedHash } });
    assert.equal(manager.status().cliIntegrityBlocked, false,
      'a correctly pinned executable must remain eligible');
    // Regression: beta.48 still prepended persisted arbitrary prefixArgs to
    // otherwise audited read-only CLI profiles, including write verbs.
    const maliciousPrefix = ['write-full', '--input', 'unapproved.bin'];
    manager.saveConfig({ prefixArgs: maliciousPrefix });
    let cliInvocations = 0;
    manager.runCapture = async () => { cliInvocations++; return { code: 0, text: 'mock CLI' }; };
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'read-only preflight must reject arbitrary executable prefix arguments');
    await assert.rejects(manager.probe(),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'read-only CLI probe must reject arbitrary executable prefix arguments before spawning');
    await assert.rejects(manager.discoverCliDevices(),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'read-only device discovery must reject arbitrary executable prefix arguments before spawning');
    assert.equal(cliInvocations, 0, 'unsafe prefix arguments must never reach a CLI process');
    assert.equal(manager.status().cliPrefixArgsBlocked, true, 'status must expose the blocked prefix configuration');
    assert.deepEqual(manager.resolveExecutable().prefixArgs, [],
      'restricted executable resolution must never expose unreviewed prefix arguments to any caller');
    assert.equal(manager.status().configured, false,
      'blocked CLI must not be advertised as configured');
    manager.saveConfig({ integrationMode: 'runtime-profile-discovery' });
    assert.equal(manager.status().capabilities.readProperties, false,
      'blocked CLI must not advertise a runnable read capability');
    manager.saveConfig({ prefixArgs: '--write-full' });
    assert.throws(() => manager.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'malformed saved prefix values must fail closed, not silently become an empty array');
    assert.equal(manager.status().cliPrefixArgsBlocked, true,
      'malformed saved prefix values must be reported as blocked');
    manager.saveConfig({ prefixArgs: [] });
    await assert.rejects(manager.probe({ executable: fakeCli, prefixArgs: '--write-full' }),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'malformed supplied prefix arguments must be rejected before configuration is saved');
    assert.deepEqual(manager.getConfig().prefixArgs, [],
      'rejected probe input must not poison the saved CLI configuration');
    manager.saveConfig({ prefixArgs: maliciousPrefix });
    assert.deepEqual(manager.getConfig().prefixArgs, maliciousPrefix,
      'rejected prefix configuration must remain intact for explicit user review');
    const explicitlyRestricted = new FlashManager({
      readOnlyBeta: true, platform: 'test', allowSimulatedCliPrefixArgs: true,
      dataRoot: () => path.join(root, 'ExplicitRestricted'),
      getActiveProject: () => ({ id: 'restricted', name: 'Restricted', folder: root }),
      getToolPath: () => fakeCli
    });
    explicitlyRestricted.saveConfig({ executable: fakeCli, prefixArgs: maliciousPrefix });
    assert.throws(() => explicitlyRestricted.preflight('readProperties', { device: 'COM4' }),
      error => error.code === 'read-only-beta-prefix-args-blocked',
      'explicit production read-only mode must override synthetic fixture settings');
    const synthetic = new FlashManager({
      platform: 'test', allowSimulatedWrites: true, dataRoot: () => path.join(root, 'Synthetic'),
      getActiveProject: () => ({ id: 'synthetic', name: 'Synthetic', folder: root }), getToolPath: () => fakeCli
    });
    synthetic.saveTemplates({ readProperties: dangerous });
    synthetic.saveConfig({ prefixArgs: maliciousPrefix });
    assert.deepEqual(synthetic.preflight('readProperties', { device: 'COM4' }).resolved.prefixArgs, maliciousPrefix,
      'test-only opt-out preserves synthetic legacy prefix behavior');
    assert.equal(synthetic.preflight('readProperties', { device: 'COM4' }).candidateProfiles[0].id,
      'configured-template', 'legacy synthetic test-only behavior remains isolated');
    assert.equal(portCalls, 0, 'rejected operations and preflight must not inspect, open or release COM port');
    assert.equal(manager.session, null, 'no hardware session may start');
    assert.equal(manager.getHistory().length, 0, 'no operation may enter history');
    assert(!fs.existsSync(path.join(root, 'Project')), 'blocked GUI/assisted operations must not create project files');
    const main = fs.readFileSync(path.join(__dirname, '../src/main.js'), 'utf8');
    assert(main.includes('readOnlyBeta: true,'), 'packaged Electron main process must explicitly enable read-only beta');
    assert(main.includes("flashManager.assertReadOnlyBetaOperation('writeCalibration')"), 'P01 write IPC must reject before state mutation');
    assert(main.includes("if (key === 'pcmHammer') throw"), 'unrestricted PCM Hammer GUI tool launch must be blocked');
    assert(main.includes("['goal-map', 'create-revision', 'test-write'].includes(state.phase)"), 'automatic calibration/test-write stages must pause');
    if (!quiet) console.log('Read-only beta guard: writes, GUI handoff, CLI templates/prefixes, pinned digest drift and post-handoff changes blocked; zero physical COM touches.');
    return { passed: true, scenarios: 15, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runReadOnlyBetaGuardSimulations().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { runReadOnlyBetaGuardSimulations };
