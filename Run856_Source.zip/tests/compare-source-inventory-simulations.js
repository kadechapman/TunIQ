'use strict';
const assert = require('assert/strict');
const { compare } = require('../tools/compare-source-inventory');
const a = 'a'.repeat(64), b = 'b'.repeat(64);
const entry = (path, sha256 = a, bytes = 1) => ({ path, sha256, bytes });
const baseline = { inventory: [entry('unchanged'), entry('changed'), entry('removed')] };
const current = { inventory: [entry('unchanged'), entry('changed', b), entry('added')] };
assert.deepEqual(compare(baseline, current), { added: ['added'], removed: ['removed'], modified: ['changed'], baselineCount: 3, currentCount: 3 });
assert.throws(() => compare({ sha256: a }, current), /per-file entries/);
assert.throws(() => compare({ inventory: [entry('x'), entry('x')] }, current), /duplicate/);
assert.throws(() => compare({ inventory: [entry('x', 'invalid')] }, current), /Malformed/);
assert.deepEqual(compare({ inventory: [entry('x', a, 1)] }, { inventory: [entry('x', a, 2)] }).modified, ['x']);
for (const unsafe of ['../secret', '/absolute', 'a/../b', 'a//b', 'a/./b', 'a\\b', '', 'C:/Windows/system.ini', 'a:stream', 'a?b', 'a*b', 'a|b', 'a\u0000b', 'a\u001fb']) {
  assert.throws(() => compare({ inventory: [entry(unsafe)] }, { inventory: [] }), /Malformed/);
}
assert.throws(() => compare({ inventory: [] }, { inventory: [entry('../escape')] }), /Malformed/);
assert.throws(() => compare({ inventory: [] }, { sha256: a }), /Both inventories/);
for (const unsafe of ['CON', 'aux.txt', 'a/NUL.log', 'folder./file', 'folder /file', 'name.', 'name ']) {
  assert.throws(() => compare({ inventory: [entry(unsafe)] }, { inventory: [] }), /Windows inventory path/);
}
assert.throws(() => compare({ inventory: [entry('File.js'), entry('file.js')] }, { inventory: [] }), /Duplicate Windows/);
assert.throws(() => compare({ inventory: [] }, { inventory: [entry('A/x'), entry('a/X')] }), /Duplicate Windows/);
assert.throws(() => compare({ inventory: [entry('SRC/File.js')] }, { inventory: [entry('src/file.js')] }), /Case-only rename/);
assert.throws(() => compare({ inventory: [entry('A.js')] }, { inventory: [entry('a.js', b)] }), /Case-only rename/);
assert.deepEqual(compare({ inventory: [entry('A.js')] }, { inventory: [entry('A.js', b)] }).modified, ['A.js']);
for (const paths of [['a', 'a/b'], ['a/b/c', 'a'], ['Dir/File', 'dir/file/child']]) {
  assert.throws(() => compare({ inventory: paths.map(p => entry(p)) }, { inventory: [] }), /File\/directory collision/);
}
assert.throws(() => compare({ inventory: [] }, { inventory: [entry('x'), entry('x/y')] }), /File\/directory collision/);
assert.throws(() => compare({ inventory: [entry('caf\u00e9.js'), entry('cafe\u0301.js')] }, { inventory: [] }), /Duplicate Windows/);
assert.throws(() => compare({ inventory: [entry('caf\u00e9.js')] }, { inventory: [entry('cafe\u0301.js')] }), /Case-only rename/);
console.log('PASS 40 inventory-diff fixture assertions');
