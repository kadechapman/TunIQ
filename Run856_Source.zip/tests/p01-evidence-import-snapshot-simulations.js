'use strict';
// Read-only local filesystem regressions. No ECU or serial access.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { P01EvidenceManager } = require('../src/p01-evidence');
const { normalizeFile, normalizeText } = require('../src/log-import');

function runP01EvidenceImportSnapshotSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-evidence-import-'));
  let passed = 0;
  try {
    const manager = new P01EvidenceManager({ dataRoot: () => path.join(root, 'data'), getActiveProject: () => null });
    const csv = path.join(root, 'session.csv');
    const csvText = 'Time,Engine RPM,Vehicle Speed\n0,850,0\n1,900,2\n';
    fs.writeFileSync(csv, csvText);
    const normalizedFromFile = normalizeFile(csv);
    const normalizedFromText = normalizeText(csvText, '.csv');
    assert.deepStrictEqual(normalizedFromText.rows, normalizedFromFile.rows); passed++;
    const imported = manager.importFile(csv);
    assert.equal(imported.sourceFileSha256, crypto.createHash('sha256').update(csvText).digest('hex')); passed++;
    assert.equal(imported.sourceFileSize, Buffer.byteLength(csvText)); passed++;
    assert(fs.existsSync(imported.normalizedPath)); passed++;
    assert.equal(manager.importFile(csv).duplicate, true); passed++;

    const xdf = path.join(root, '12212156.xdf');
    fs.writeFileSync(xdf, '<deftitle>12212156 P01</deftitle>');
    const definition = manager.importFile(xdf);
    assert.equal(definition.kind, 'definition'); passed++;
    assert.equal(definition.os, '12212156'); passed++;

    const packageFile = path.join(root, 'web.tuniqlog');
    fs.writeFileSync(packageFile, JSON.stringify({ format: 'TunIQ Web Log Package', profile: 'baseline', columns: ['rpm','speed'], rows: [{rpm: 850,speed: 0}] }));
    const packageFromText = normalizeText(fs.readFileSync(packageFile, 'utf8'), '.tuniqlog');
    assert.deepStrictEqual(normalizeFile(packageFile).rows, packageFromText.rows); passed++;
    const packaged = manager.importFile(packageFile);
    assert.equal(packaged.kind, 'live-log'); passed++;

    const big = path.join(root, 'oversized.bin');
    fs.writeFileSync(big, Buffer.alloc(1));
    fs.truncateSync(big, 100 * 1024 * 1024 + 1); // sparse: no 100 MB allocation
    assert.throws(() => manager.importFile(big), /100 MB/i); passed++;

    const link = path.join(root, 'linked.csv');
    try {
      fs.symlinkSync(csv, link);
      assert.throws(() => manager.importFile(link), /link|regular file|unsafe/i); passed++;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }

    const grown = path.join(root, 'growing.bin');
    fs.writeFileSync(grown, Buffer.alloc(8192, 0x34));
    const originalRead = fs.readSync;
    let grownOnce = false;
    try {
      fs.readSync = function(fd, buffer, offset, length, position) {
        const bytes = originalRead.call(fs, fd, buffer, offset, length, position);
        if (!grownOnce && bytes > 0) {
          grownOnce = true;
          fs.appendFileSync(grown, Buffer.from('unexpected appended data'));
        }
        return bytes;
      };
      assert.throws(() => manager.importFile(grown), /grew|changed|during import/i); passed++;
    } finally { fs.readSync = originalRead; }
    assert.equal(grownOnce, true); passed++;

    const replaced = path.join(root, 'replaced.bin');
    fs.writeFileSync(replaced, Buffer.alloc(64, 1));
    const originalOpen = fs.openSync;
    let replacedOnce = false;
    try {
      fs.openSync = function(file, ...args) {
        if (file === replaced && !replacedOnce) {
          replacedOnce = true;
          fs.renameSync(replaced, `${replaced}.old`);
          fs.writeFileSync(replaced, Buffer.alloc(64, 2));
        }
        return originalOpen.call(fs, file, ...args);
      };
      assert.throws(() => manager.importFile(replaced), /changed|select it again/i); passed++;
    } finally { fs.openSync = originalOpen; }
    assert.equal(replacedOnce, true); passed++;

    const truncated = path.join(root, 'truncated.bin');
    fs.writeFileSync(truncated, Buffer.alloc(8192, 5));
    const originalRead2 = fs.readSync;
    let truncatedOnce = false;
    try {
      fs.readSync = function(fd, buffer, offset, length, position) {
        if (!truncatedOnce) {
          truncatedOnce = true;
          fs.truncateSync(truncated, 10);
        }
        return originalRead2.call(fs, fd, buffer, offset, length, position);
      };
      assert.throws(() => manager.importFile(truncated), /truncated|changed/i); passed++;
    } finally { fs.readSync = originalRead2; }
    assert.equal(truncatedOnce, true); passed++;

    assert.equal(manager.imports().length, 3, 'rejected inputs must not enter the evidence index'); passed++;
    if (!quiet) console.log(`✓ P01 evidence snapshot import: ${passed} local-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runP01EvidenceImportSnapshotSimulations();
module.exports = { runP01EvidenceImportSnapshotSimulations };
