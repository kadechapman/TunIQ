'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
 ['leading space', ' ../packages/alpha', true],
 ['trailing space', '../packages/alpha ', true],
 ['leading newline', '\n../packages/alpha', true],
 ['valid sibling workspace', '../packages/alpha', false],
 ['valid nested workspace', '../packages/sub/alpha', false],
 ['valid relative folder', 'packages/alpha', true],
];
for (const [label, resolved, blocked] of cases) {
 const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq672-'));
 try {
  const pkg = {name:'tuniq',version:'1.0.0',dependencies:{alpha:'file:packages/alpha'}};
  const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:pkg.dependencies},'node_modules/alpha':{link:true,resolved}}};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify(pkg));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
  const result = assess(root);
  assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'),blocked,label + ' ' + JSON.stringify(result.blockers));
  assert.strictEqual(result.ecmWriteAuthorized,false,label);
  assert.strictEqual(result.nativeWindowsRuntimeVerified,false,label);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run672: 6 workspace-link whitespace-target fixtures passed');
