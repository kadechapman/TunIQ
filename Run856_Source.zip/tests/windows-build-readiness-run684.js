'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['encoded CON','../packages/%43ON',true],
 ['encoded NUL extension','../packages/%4eUL.txt',true],
 ['encoded COM1','../packages/CO%4d1',true],
 ['encoded LPT9','../packages/L%50T9',true],
 ['encoded CONIN','../packages/%43ONIN$',true],
 ['encoded CONOUT','../packages/CON%4fUT$.txt',true],
 ['encoded safe name','../packages/%66oo',false],
 ['encoded space','../packages/foo%20bar',false],
 ['malformed percent UTF8','../packages/%ff',true],
 ['normal name','../packages/foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq684-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run684: ten encoded device-name and malformed encoding fixtures passed');
