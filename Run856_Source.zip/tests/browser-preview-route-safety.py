#!/usr/bin/env python3
"""Source-only route isolation regression; no browser or ECU access."""
import asyncio
import importlib.util
from pathlib import Path

p = Path(__file__).resolve().parents[1] / 'tools/browser-preview-chromium-smoke.py'
spec = importlib.util.spec_from_file_location('tuniq_smoke', p)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class Request:
    def __init__(self, url, frame, nav):
        self.url, self.frame, self.nav = url, frame, nav
    def is_navigation_request(self):
        return self.nav

class Route:
    def __init__(self, request):
        self.request, self.action = request, None
    async def continue_(self):
        self.action = 'continue'
    async def abort(self):
        self.action = 'abort'

async def test():
    main, sub = object(), object()
    file_uri = 'file:///tmp/preview.html'
    cases = [
        (file_uri, main, True, 'continue'),
        (file_uri, main, False, 'abort'),
        (file_uri, sub, True, 'abort'),
        ('file:///tmp/other.html', main, True, 'abort'),
        ('https://example.invalid/', main, True, 'abort'),
        ('data:text/javascript,evil', sub, False, 'abort'),
    ]
    for url, frame, nav, expected in cases:
        route, denied = Route(Request(url, frame, nav)), []
        await module.handle_preview_route(route, file_uri, main, denied)
        assert route.action == expected, (url, expected, route.action)
        assert denied == ([] if expected == 'continue' else [url])
    route, denied = Route(Request(file_uri, main, True)), []
    await module.handle_preview_route(route, None, main, denied)
    assert route.action == 'abort' and denied == [file_uri]
    print('PASS 7 isolated preview routing fixtures; 14 assertions (source-only)')

asyncio.run(test())
