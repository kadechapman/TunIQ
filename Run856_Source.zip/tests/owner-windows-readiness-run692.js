'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const {inspect,exitCodeFor} = require('../tools/owner-windows-readiness-run687');
const root = path.join(__dirname,'..');
const request = 'Review VATS, electric fan output enablement and temperature thresholds, physical LSX Stage 2 cam, and removed knock sensors';
for (const project of [null, {}, {id:'x',controller:'E38',os:'unknown'}, {id:'x',controller:'P01',os:'unknown'}]) {
  const result = inspect(root,project,request);
  assert.equal(result.owner.ready,false);
  assert.equal(result.readyForUserTesting,false);
  assert.equal(result.ecmWriteAuthorized,false);
  assert.equal(exitCodeFor(result),2);
  assert.equal(Object.values(result.owner.calibrationGates).every(v=>v===false),true);
  if (!project || project.controller !== 'P01') {
    assert.equal(typeof result.owner.reviewError,'string');
    assert.match(result.owner.missingSafetyFacts.join(' '),/review unavailable/i);
  } else assert.equal(result.owner.reviewError,null);
}
console.log('Run692: 23 fail-closed controller-input assertions passed');
