'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['newline', 'packages/\nexample', true],
  ['tab', 'packages/\texample', true],
  ['carriage return', 'packages/\rexample', true],
  ['delete', 'packages/\x7fexample', true],
  ['ordinary workspace', 'packages/example', true],
  ['parent workspace', '../packages/example', false],
];
for (const [label, resolved, blocked] of cases) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(),'tuniq667-'));
  try {
    fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:{example:'1.0.0'}}));
    fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{example:'1.0.0'}},'node_modules/example':{link:true,resolved}}}));
    const result = assess(root);
    assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'),blocked,label);
    assert.strictEqual(result.ecmWriteAuthorized,false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false);
    if (!blocked) assert.deepStrictEqual(result.blockers,[],label);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
console.log('Run667: 6 control-character link target fixtures passed');
