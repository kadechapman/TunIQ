const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01HardwareTransactionManager } = require('../src/p01-hardware-transaction');

// Existing Windows simulation assertions supply the same captured admission
// tokens as the production CLI caller. Do not silently fall back to tokenless
// admission in tests: only explicit platform='test' fixtures may do that.
function admitPrepared(manager, args) {
  const { transactionId, preparationSequence } = manager.snapshot();
  return manager.assertCanStartProcess({ transactionId, preparationSequence, ...args });
}

async function runP01HardwareTransactionSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-p01-transaction-'));
  let now = 1_000_000;
  const waits = [];
  const manager = new P01HardwareTransactionManager({
    dataRoot: () => root,
    platform: 'win32',
    now: () => now,
    sleep: async ms => { waits.push(ms); now += ms; },
    interOperationCooldownMs: 4000,
    reopenRecoveryDelayMs: 5000
  });

  const first = manager.begin({ projectId: 'project-a', controller: 'P01', os: '9373372', port: 'COM4', operation: 'readProperties' });
  manager.markProcessStarted({ port: 'COM4', operation: 'readProperties', sessionId: 'properties-1' });
  now += 600;
  manager.markProcessClosed({ port: 'COM4', operation: 'readProperties', sessionId: 'properties-1', success: true });
  const second = manager.begin({ projectId: 'project-a', controller: 'P01', os: '9373372', port: 'COM4', operation: 'read' });
  assert.equal(second.transactionId, first.transactionId, 'same project and proven port must retain one transaction ID');
  const waited = await manager.settleBeforeOpen('COM4');
  assert.equal(waited, 4000, 'new protected step must wait for the full Windows RFCOMM cooldown');
  assert.equal(waits[0], 4000);

  manager.markProcessStarted({ port: 'COM4', operation: 'read', sessionId: 'read-1' });
  manager.markProcessClosed({ port: 'COM4', operation: 'read', sessionId: 'read-1', success: false, stopCode: 'adapter-open-failed', communicationStarted: false });
  assert.equal(manager.canAttemptControlledReopen({ port: 'COM4', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' }), true);
  const recovery = await manager.controlledReopen({ port: 'COM4', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' });
  assert.equal(recovery.waitMs, 5000);
  assert.equal(manager.canAttemptControlledReopen({ port: 'COM4', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' }), false, 'only one controlled reopen is allowed');

  const different = manager.begin({ projectId: 'project-b', controller: 'P01', os: '12212156', port: 'COM7', operation: 'readProperties' });
  assert.notEqual(different.transactionId, first.transactionId, 'another project/port must start an isolated transaction');
  assert.equal(different.recoveryCount, 0);
  assert.equal(different.port, 'COM7');

  const persisted = JSON.parse(fs.readFileSync(manager.file(), 'utf8'));
  assert.equal(persisted.projectId, 'project-b');
  assert(Array.isArray(persisted.history) && persisted.history.length >= 6, 'transaction ledger must persist preparation, process, cooldown, and recovery events');

  // Regression: readFileSync followed symlinks, and a dangling symlink
  // returned ENOENT (mistaken for a first-launch empty ledger). Either case
  // could replace unknown COM ownership evidence with a new preparation.
  const redirectedRoot = path.join(root, 'redirected-ledger');
  const redirected = new P01HardwareTransactionManager({
    dataRoot: () => redirectedRoot, platform: 'win32', now: () => now
  });
  redirected.begin({ projectId: 'redirected', port: 'COM8', operation: 'read' });
  const ledgerFile = redirected.file();
  const externalLedger = path.join(root, 'external-owner.json');
  fs.copyFileSync(ledgerFile, externalLedger);
  fs.unlinkSync(ledgerFile);
  fs.symlinkSync(externalLedger, ledgerFile);
  const linkedBefore = fs.readFileSync(externalLedger);
  assert.throws(() => redirected.snapshot(), /ledger unreadable.*blocked/i,
    'redirected ledger must not be accepted as COM ownership evidence');
  assert.throws(() => redirected.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /ledger unreadable.*blocked/i, 'redirected ledger must deny new COM preparation');
  assert.deepStrictEqual(fs.readFileSync(externalLedger), linkedBefore,
    'denied symlink must not modify its external target');
  fs.unlinkSync(ledgerFile);
  fs.symlinkSync(path.join(root, 'missing-owner.json'), ledgerFile);
  assert.throws(() => redirected.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /ledger unreadable.*blocked/i, 'dangling symlink must not be treated as a missing ledger');
  fs.unlinkSync(ledgerFile);
  fs.linkSync(externalLedger, ledgerFile);
  assert.throws(() => redirected.snapshot(), /ledger unreadable.*blocked/i,
    'multiply-linked ownership ledger must fail closed');
  fs.unlinkSync(ledgerFile);
  fs.copyFileSync(externalLedger, ledgerFile);
  assert.equal(redirected.snapshot().state, 'preparing',
    'normal single-link ledger remains readable after operator restoration');

  // Regression: the old manager accepted a reopen while a child still owned
  // the COM port and allowed direct controlledReopen() to bypass admission.
  const fresh = (name, sleepOverride = async ms => { now += ms; }) => new P01HardwareTransactionManager({
    dataRoot: () => path.join(root, name), platform: 'win32', now: () => now,
    sleep: sleepOverride, reopenRecoveryDelayMs: 5000
  });
  const guard = fresh('guard');
  const args = { port: 'COM8', operation: 'read', communicationStarted: false, stopCode: 'adapter-open-failed' };
  guard.begin({ projectId: 'guard-project', port: 'COM8', operation: 'read' });
  guard.markProcessStarted({ port: 'COM8', operation: 'read' });
  assert.equal(guard.canAttemptControlledReopen(args), false, 'running child must block COM reopen');
  await assert.rejects(guard.controlledReopen(args), /reopen denied/i);
  assert.equal(guard.snapshot().state, 'process-running', 'denied reopen must not release ownership');
  guard.markProcessClosed({ port: 'COM8', operation: 'read', success: false, stopCode: 'adapter-open-failed', communicationStarted: false });
  assert.equal(guard.canAttemptControlledReopen({ ...args, communicationStarted: undefined }), false,
    'unknown communication state cannot authorize retry');
  assert.equal(guard.canAttemptControlledReopen({ ...args, stopCode: 'adapter-locked' }), false,
    'a caller cannot replace the recorded failure with a retryable stop code');
  assert.equal(guard.canAttemptControlledReopen({ ...args, port: 'COM9' }), false,
    'retry cannot move to a different COM port');
  assert.equal(guard.canAttemptControlledReopen({ ...args, operation: 'testWrite' }), false,
    'test write must not enter automatic controlled-reopen path');
  assert.equal(guard.canAttemptControlledReopen(args), true, 'recorded closed pre-communication read may reopen once');
  await guard.controlledReopen(args);
  assert.equal(guard.canAttemptControlledReopen(args), false, 'one-reopen limit must persist');

  const communicated = fresh('communicated');
  communicated.begin({ projectId: 'communicated', port: 'COM8', operation: 'read' });
  communicated.markProcessStarted({ port: 'COM8', operation: 'read' });
  communicated.markProcessClosed({ port: 'COM8', operation: 'read', success: false,
    stopCode: 'adapter-open-failed', communicationStarted: true });
  assert.equal(communicated.canAttemptControlledReopen(args), false,
    'persisted evidence of PCM communication blocks reopening even if caller says false');
  const unknown = fresh('unknown');
  unknown.begin({ projectId: 'unknown', port: 'COM8', operation: 'read' });
  unknown.markProcessStarted({ port: 'COM8', operation: 'read' });
  unknown.markProcessClosed({ port: 'COM8', operation: 'read', success: false, stopCode: 'adapter-open-failed' });
  assert.equal(unknown.canAttemptControlledReopen(args), false,
    'older/unknown persisted communication state fails closed');

  // Regression: a pending cooldown must not mark a different project's
  // transaction ready to reopen after an asynchronous project switch.
  let resumeCooldown;
  const race = fresh('race', () => new Promise(resolve => { resumeCooldown = resolve; }));
  race.begin({ projectId: 'original', port: 'COM8', operation: 'read' });
  race.markProcessStarted({ port: 'COM8', operation: 'read' });
  race.markProcessClosed({ port: 'COM8', operation: 'read', success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false });
  const pending = race.controlledReopen(args);
  race.begin({ projectId: 'replacement', port: 'COM9', operation: 'readProperties' });
  resumeCooldown();
  await assert.rejects(pending, /transaction changed/i);
  assert.equal(race.snapshot().state, 'preparing', 'stale cooldown must not mark new project ready');
  assert.equal(race.snapshot().port, 'COM9', 'new project COM ownership must be preserved');

  // Regression: ordinary inter-operation cooldown (not controlledReopen)
  // previously promoted a replacement project's transaction to ready-to-open.
  const createPendingCooldown = (name) => {
    let release;
    const waiting = fresh(name, () => new Promise(resolve => { release = resolve; }));
    waiting.begin({ projectId: 'original', port: 'COM8', operation: 'readProperties' });
    waiting.markProcessStarted({ port: 'COM8', operation: 'readProperties' });
    waiting.markProcessClosed({ port: 'COM8', operation: 'readProperties', success: true });
    waiting.begin({ projectId: 'original', port: 'COM8', operation: 'read' });
    const pending = waiting.settleBeforeOpen('COM8');
    return { waiting, pending, release: () => release() };
  };
  const swapped = createPendingCooldown('settle-project-race');
  swapped.waiting.begin({ projectId: 'replacement', port: 'COM9', operation: 'readProperties' });
  swapped.release();
  await assert.rejects(swapped.pending, /transaction changed/i);
  assert.equal(swapped.waiting.snapshot().state, 'preparing', 'stale settle cannot mark replacement ready');
  assert.equal(swapped.waiting.snapshot().port, 'COM9', 'replacement port remains unchanged');

  const same = createPendingCooldown('settle-same-project-race');
  const beforeSequence = same.waiting.snapshot().preparationSequence;
  same.waiting.begin({ projectId: 'original', port: 'COM8', operation: 'read' });
  assert.equal(same.waiting.snapshot().preparationSequence, beforeSequence + 1,
    'even an identical new preparation must get a new sequence');
  same.release();
  await assert.rejects(same.pending, /transaction changed/i);
  assert.equal(same.waiting.snapshot().state, 'preparing', 'old cooldown cannot authorize same-project replacement');

  const running = createPendingCooldown('settle-child-race');
  running.waiting.markProcessStarted({ port: 'COM8', operation: 'read' });
  running.release();
  await assert.rejects(running.pending, /transaction changed/i);
  assert.equal(running.waiting.snapshot().state, 'process-running', 'cooldown cannot clear running child ownership');
  assert.throws(() => running.waiting.begin({ projectId: 'another', port: 'COM9', operation: 'read' }),
    /child still owns/i, 'begin must not overwrite a running child');
  assert.equal(running.waiting.snapshot().port, 'COM8');

  const duplicate = createPendingCooldown('settle-duplicate');
  await assert.rejects(duplicate.waiting.settleBeforeOpen('COM8'), /cooldown denied/i,
    'second settle must not authorize a concurrent COM open');
  duplicate.release();
  await duplicate.pending;
  assert.equal(duplicate.waiting.snapshot().state, 'ready-to-open', 'uninterrupted cooldown still succeeds');
  await assert.rejects(duplicate.waiting.settleBeforeOpen('COM8'), /cooldown denied/i,
    'ready-to-open state cannot be promoted repeatedly');
  const mismatched = fresh('settle-port-mismatch');
  mismatched.begin({ projectId: 'port-test', port: 'COM8', operation: 'read' });
  await assert.rejects(mismatched.settleBeforeOpen('COM9'), /cooldown denied/i,
    'a different COM port cannot be admitted');
  assert.equal(mismatched.snapshot().state, 'preparing');

  // A missing pinned COM port must never be promoted into a Windows open.
  // Previous cooldown admission treated an empty stored port as a wildcard.
  const missingPort = fresh('settle-missing-windows-port');
  missingPort.begin({ projectId: 'missing', port: '', operation: 'read' });
  await assert.rejects(missingPort.settleBeforeOpen(''), /cooldown denied/i);
  assert.equal(missingPort.snapshot().state, 'preparing', 'no-port Windows attempt must stay unadmitted');

  const substitutedPort = fresh('settle-late-port-substitution');
  substitutedPort.begin({ projectId: 'missing', port: '', operation: 'read' });
  await assert.rejects(substitutedPort.settleBeforeOpen('COM8'), /cooldown denied/i);
  assert.equal(substitutedPort.snapshot().port, '', 'unverified late COM selection must not become pinned');
  assert.equal(substitutedPort.snapshot().state, 'preparing', 'late substitution must not open COM');

  // Existing offline test-write fixture deliberately has no COM hardware.
  const synthetic = new P01HardwareTransactionManager({ dataRoot: () => path.join(root, 'settle-offline-fixture'),
    platform: 'test', now: () => now, interOperationCooldownMs: 0 });
  synthetic.begin({ projectId: 'offline-only', port: '', operation: 'testWrite' });
  assert.equal(await synthetic.settleBeforeOpen(''), 0, 'test-only no-port fixture stays functional');
  assert.equal(synthetic.snapshot().state, 'ready-to-open');

  // A late `close` callback from a previous CLI must not release a newer
  // process's COM ownership or rewrite its operation/session. The unpatched
  // manager changed project B's COM9 running state into COM4 process-closed.
  const staleClose = fresh('stale-child-close');
  staleClose.begin({ projectId: 'project-A', port: 'COM4', operation: 'read', sessionId: 'session-A' });
  staleClose.markProcessStarted({ port: 'COM4', operation: 'read', sessionId: 'session-A' });
  staleClose.markProcessClosed({ port: 'COM4', operation: 'read', sessionId: 'session-A', success: false });
  staleClose.begin({ projectId: 'project-B', port: 'COM9', operation: 'readProperties', sessionId: 'session-B' });
  staleClose.markProcessStarted({ port: 'COM9', operation: 'readProperties', sessionId: 'session-B' });
  const ownerBefore = staleClose.snapshot();
  assert.throws(() => staleClose.markProcessClosed({ port: 'COM4', operation: 'read', sessionId: 'session-A' }),
    /stale or mismatched/i, 'previous child must not close a newer COM owner');
  assert.deepStrictEqual(staleClose.snapshot(), ownerBefore, 'denied close must not mutate transaction or history');
  assert.equal(staleClose.snapshot().state, 'process-running', 'new child retains exclusive COM ownership');
  assert.equal(staleClose.snapshot().port, 'COM9');
  assert.equal(staleClose.snapshot().lastSessionId, 'session-B');
  assert.throws(() => staleClose.markProcessClosed({ port: 'COM9', operation: 'readProperties', sessionId: 'session-A' }),
    /stale or mismatched/i, 'same-port stale session must not close new child');
  assert.throws(() => staleClose.markProcessClosed({ port: 'COM9', operation: 'read', sessionId: 'session-B' }),
    /stale or mismatched/i, 'mismatched operation must not close new child');
  assert.equal(staleClose.snapshot().state, 'process-running');
  staleClose.markProcessClosed({ port: 'COM9', operation: 'readProperties', sessionId: 'session-B', success: true });
  assert.equal(staleClose.snapshot().state, 'operation-complete', 'matching close remains accepted');
  // Regression: a forged or stale process-close record must not authorize
  // another physical COM open without a start from this preparation sequence.
  const noStart = fresh('no-child-start');
  noStart.begin({ projectId: 'no-child', port: 'COM8', operation: 'read' });
  const unstartedSnapshot = noStart.snapshot();
  assert.throws(() => noStart.markProcessClosed({ port: 'COM8', operation: 'read', success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false }), /process close denied/i,
    'a close without child-start evidence must not alter the ledger');
  assert.deepStrictEqual(noStart.snapshot(), unstartedSnapshot);
  assert.equal(noStart.canAttemptControlledReopen(args), false,
    'a close without a child start cannot authorize a controlled reopen');
  await assert.rejects(noStart.controlledReopen(args), /reopen denied/i);
  assert.equal(noStart.snapshot().state, 'preparing', 'denied close and reopen preserve the prepared state');

  const staleStart = fresh('stale-child-start');
  staleStart.begin({ projectId: 'stale', port: 'COM8', operation: 'read' });
  staleStart.markProcessStarted({ port: 'COM8', operation: 'read' });
  staleStart.markProcessClosed({ port: 'COM8', operation: 'read', success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false });
  assert.equal(staleStart.canAttemptControlledReopen(args), true, 'same preparation child proof remains valid');
  staleStart.begin({ projectId: 'stale', port: 'COM8', operation: 'read' });
  const preparedAgain = staleStart.snapshot();
  assert.throws(() => staleStart.markProcessClosed({ port: 'COM8', operation: 'read', success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false }), /process close denied/i);
  assert.deepStrictEqual(staleStart.snapshot(), preparedAgain);
  assert.equal(staleStart.canAttemptControlledReopen(args), false,
    'a new preparation cannot reuse a prior child start');

  // Regression: a stale caller from an earlier begin() must not inherit the
  // COM admission of a newer, otherwise identical preparation. The original
  // pre-spawn gate only compared COM/operation/state and returned true.
  const superseded = fresh('superseded-preparation');
  const originalPrep = superseded.begin({ projectId: 'same', port: 'COM8', operation: 'read' });
  await superseded.settleBeforeOpen('COM8');
  const newPrep = superseded.begin({ projectId: 'same', port: 'COM8', operation: 'read' });
  await superseded.settleBeforeOpen('COM8');
  const newReady = superseded.snapshot();
  assert.equal(originalPrep.transactionId, newPrep.transactionId,
    'identical preparations reuse the transaction ID but not the sequence');
  assert.notEqual(originalPrep.preparationSequence, newPrep.preparationSequence);
  assert.throws(() => superseded.assertCanStartProcess({
    port: 'COM8', operation: 'read', sessionId: 'old-session',
    transactionId: originalPrep.transactionId, preparationSequence: originalPrep.preparationSequence
  }), /superseded/i, 'old caller must not spawn using a replacement preparation');
  assert.deepStrictEqual(superseded.snapshot(), newReady,
    'rejected stale admission must preserve the replacement transaction and history');
  assert.equal(superseded.assertCanStartProcess({
    port: 'COM8', operation: 'read', sessionId: 'new-session',
    transactionId: newPrep.transactionId, preparationSequence: newPrep.preparationSequence
  }), true, 'current preparation remains eligible for read-only CLI admission');
  assert.throws(() => superseded.assertCanStartProcess({
    port: 'COM8', operation: 'read', sessionId: 'new-session',
    transactionId: 'another-transaction', preparationSequence: newPrep.preparationSequence
  }), /superseded/i, 'mismatched transaction identity must also fail closed');

  // A tokenless or partially tokened Windows caller must not inherit a ready
  // transaction even when its COM port, operation and session all match.
  const tokenlessBefore = superseded.snapshot();
  for (const missingTokens of [
    {}, { transactionId: newPrep.transactionId },
    { preparationSequence: newPrep.preparationSequence },
    { transactionId: '', preparationSequence: newPrep.preparationSequence },
    { transactionId: newPrep.transactionId, preparationSequence: '2' }
  ]) {
    assert.throws(() => superseded.assertCanStartProcess({
      port: 'COM8', operation: 'read', sessionId: 'new-session', ...missingTokens
    }), /missing prepared transaction/i, 'Windows pre-spawn admission requires both valid captured tokens');
    assert.deepStrictEqual(superseded.snapshot(), tokenlessBefore,
      'denied tokenless admission cannot alter the COM ownership ledger');
  }
  assert.equal(superseded.assertCanStartProcess({
    port: 'COM8', operation: 'read', sessionId: 'new-session',
    transactionId: newPrep.transactionId, preparationSequence: newPrep.preparationSequence
  }), true, 'matching captured Windows tokens still admit the intended read');

  // Regression: the original implementation accepted a duplicate start and
  // silently replaced the active COM4 child with a fictitious COM9 child.
  const duplicateStart = fresh('duplicate-start');
  duplicateStart.begin({ projectId: 'dup', port: 'COM4', operation: 'read' });
  await duplicateStart.settleBeforeOpen('COM4');
  assert.equal(admitPrepared(duplicateStart, { port: 'COM4', operation: 'read', sessionId: 'child-1' }), true);
  duplicateStart.markProcessStarted({ port: 'COM4', operation: 'read', sessionId: 'child-1' });
  const activeChild = duplicateStart.snapshot();
  assert.throws(() => duplicateStart.markProcessStarted({ port: 'COM9', operation: 'readProperties', sessionId: 'child-2' }),
    /child-start denied/i, 'duplicate child start cannot steal a running COM owner');
  assert.deepStrictEqual(duplicateStart.snapshot(), activeChild, 'rejected child start cannot mutate ledger/history');
  assert.throws(() => admitPrepared(duplicateStart, { port: 'COM4', operation: 'read', sessionId: 'child-1' }),
    /spawn denied/i, 'pre-spawn gate rejects a still-running child');
  duplicateStart.markProcessClosed({ port: 'COM4', operation: 'read', sessionId: 'child-1', success: false,
    stopCode: 'cli-syntax-rejected', communicationStarted: false });
  assert.equal(admitPrepared(duplicateStart, { port: 'COM4', operation: 'read', sessionId: 'child-1' }), true,
    'same-session pre-communication retry remains eligible after confirmed close');
  assert.throws(() => admitPrepared(duplicateStart, { port: 'COM9', operation: 'read', sessionId: 'child-1' }),
    /spawn denied/i, 'a new COM port cannot be silently substituted');
  assert.throws(() => admitPrepared(duplicateStart, { port: 'COM4', operation: 'readProperties', sessionId: 'child-1' }),
    /spawn denied/i, 'a different operation cannot inherit the COM lease');
  assert.throws(() => admitPrepared(duplicateStart, { port: 'COM4', operation: 'read', sessionId: 'child-2' }),
    /spawn denied/i, 'another session cannot inherit a closed child retry');
  duplicateStart.begin({ projectId: 'dup', port: 'COM4', operation: 'read' });
  assert.throws(() => admitPrepared(duplicateStart, { port: 'COM4', operation: 'read', sessionId: 'child-1' }),
    /spawn denied/i, 'new preparation must settle before launching another child');
  const communicatedRetry = fresh('communicated-retry');
  communicatedRetry.begin({ projectId: 'communicated', port: 'COM8', operation: 'read' });
  await communicatedRetry.settleBeforeOpen('COM8');
  communicatedRetry.markProcessStarted({ port: 'COM8', operation: 'read', sessionId: 'child-1' });
  communicatedRetry.markProcessClosed({ port: 'COM8', operation: 'read', sessionId: 'child-1',
    success: false, communicationStarted: true });
  assert.throws(() => admitPrepared(communicatedRetry, { port: 'COM8', operation: 'read', sessionId: 'child-1' }),
    /spawn denied/i, 'PCM communication forbids a silent CLI retry');
  const forgedClose = fresh('forged-close-spawn');
  forgedClose.begin({ projectId: 'forged', port: 'COM8', operation: 'read' });
  assert.throws(() => forgedClose.markProcessClosed({ port: 'COM8', operation: 'read', success: false, communicationStarted: false }), /process close denied/i);
  assert.throws(() => admitPrepared(forgedClose, { port: 'COM8', operation: 'read' }),
    /spawn denied/i, 'forged close without child-start evidence cannot permit a retry');
  // A second close event previously demoted an already completed Full Read
  // to process-closed and changed communicationStarted from true to false.
  // That fabricated the exact evidence required for an automatic COM reopen.
  const monotonic = fresh('close-evidence-monotonic');
  const closeArgs = { port: 'COM8', operation: 'read', sessionId: 'completed-read' };
  monotonic.begin({ projectId: 'completed', ...closeArgs });
  monotonic.markProcessStarted(closeArgs);
  monotonic.markProcessClosed({ ...closeArgs, success: true, communicationStarted: true });
  const completed = monotonic.snapshot();
  assert.equal(completed.state, 'operation-complete');
  assert.throws(() => monotonic.markProcessClosed({ ...closeArgs, success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false }), /cannot be downgraded/i);
  assert.deepStrictEqual(monotonic.snapshot(), completed, 'late failure cannot demote completed read or change history');
  assert.equal(monotonic.canAttemptControlledReopen(args), false, 'completed read cannot become reopenable');

  const communicatedClose = fresh('closed-communication-evidence');
  communicatedClose.begin({ projectId: 'communicated', ...closeArgs });
  communicatedClose.markProcessStarted(closeArgs);
  communicatedClose.markProcessClosed({ ...closeArgs, success: false,
    stopCode: 'read-incomplete', communicationStarted: true });
  const communicatedSnapshot = communicatedClose.snapshot();
  assert.throws(() => communicatedClose.markProcessClosed({ ...closeArgs, success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false }), /cannot be downgraded/i);
  assert.deepStrictEqual(communicatedClose.snapshot(), communicatedSnapshot,
    'late close cannot erase proof that PCM communication started');
  assert.equal(communicatedClose.canAttemptControlledReopen(args), false,
    'communicated failure cannot be reclassified as pre-communication failure');
  // A second failure close used to replace the first failure's stop code.
  // A delayed callback could manufacture adapter-open-failed after an actual
  // CLI syntax rejection, incorrectly enabling an automatic COM reopen.
  const firstClose = fresh('first-failed-close-immutable');
  const failedCtx = { port: 'COM8', operation: 'read', sessionId: 'child-failure' };
  firstClose.begin({ projectId: 'first-failure', ...failedCtx });
  firstClose.markProcessStarted(failedCtx);
  firstClose.markProcessClosed({ ...failedCtx, success: false,
    stopCode: 'cli-syntax-rejected', communicationStarted: false });
  const firstFailureSnapshot = firstClose.snapshot();
  assert.equal(firstClose.canAttemptControlledReopen({ port: 'COM8', operation: 'read',
    communicationStarted: false, stopCode: 'adapter-open-failed' }), false);
  assert.throws(() => firstClose.markProcessClosed({ ...failedCtx, success: false,
    stopCode: 'adapter-open-failed', communicationStarted: false }), /first failed child-close evidence is immutable/i,
    'late failed close must not forge adapter-open failure proof');
  assert.deepStrictEqual(firstClose.snapshot(), firstFailureSnapshot,
    'late failed close must preserve the original stop code, timestamps and history');
  assert.equal(firstClose.canAttemptControlledReopen({ port: 'COM8', operation: 'read',
    communicationStarted: false, stopCode: 'adapter-open-failed' }), false,
    'rejected close must not authorize controlled reopen');
  assert.throws(() => firstClose.markProcessClosed({ ...failedCtx, success: false,
    stopCode: 'cli-syntax-rejected', communicationStarted: false }), /first failed child-close evidence is immutable/i,
    'even an identical duplicate failure is not new child-exit evidence');
  assert.deepStrictEqual(firstClose.snapshot(), firstFailureSnapshot);
  // A normal finalizer may still promote a closed child to completed when its
  // communication evidence is consistent; this is not a second CLI spawn.
  communicatedClose.markProcessClosed({ ...closeArgs, success: true, communicationStarted: true });
  assert.equal(communicatedClose.snapshot().state, 'operation-complete');
  // A callback missing the active child's session ID must not release COM.
  const sessionGuard = fresh('missing-session-close');
  sessionGuard.begin({ projectId: 'guard', port: 'COM8', operation: 'read' });
  sessionGuard.markProcessStarted({ port: 'COM8', operation: 'read', sessionId: 'child-A' });
  const beforeMissingSession = sessionGuard.snapshot();
  assert.throws(() => sessionGuard.markProcessClosed({ port: 'COM8', operation: 'read', success: true }),
    /process close denied/i);
  assert.deepStrictEqual(sessionGuard.snapshot(), beforeMissingSession,
    'missing-session close must not release the active child');
  sessionGuard.markProcessClosed({ port: 'COM8', operation: 'read', sessionId: 'child-A',
    success: false, stopCode: 'adapter-open-failed', communicationStarted: false });
  const closedOnce = sessionGuard.snapshot();
  assert.throws(() => sessionGuard.markProcessClosed({ port: 'COM8', operation: 'read',
    sessionId: 'child-B', success: true }), /process close denied/i);
  assert.deepStrictEqual(sessionGuard.snapshot(), closedOnce);
  sessionGuard.markProcessClosed({ port: 'COM8', operation: 'read', sessionId: 'child-A',
    success: true, communicationStarted: false });
  assert.equal(sessionGuard.snapshot().state, 'operation-complete');
  // Regression: a delayed duplicate success close previously rewrote the
  // stop code and history of an already completed Full Read. Finalized proof
  // must be immutable even when the port, operation and session still match.
  const finalImmutable = fresh('finalized-close-immutable');
  const finalCtx = { port: 'COM8', operation: 'read', sessionId: 'finished-read' };
  finalImmutable.begin({ projectId: 'finalized', ...finalCtx });
  finalImmutable.markProcessStarted(finalCtx);
  finalImmutable.markProcessClosed({ ...finalCtx, success: true, communicationStarted: false });
  const finalSnapshot = finalImmutable.snapshot();
  assert.throws(() => finalImmutable.markProcessClosed({ ...finalCtx, success: true,
    communicationStarted: false, stopCode: 'adapter-open-failed' }), /process close denied/i,
    'duplicate success must not rewrite completed read evidence');
  assert.deepStrictEqual(finalImmutable.snapshot(), finalSnapshot,
    'rejected duplicate close must preserve completed read history and timestamps');
  assert.throws(() => finalImmutable.markProcessClosed({ ...finalCtx, success: true,
    communicationStarted: false }), /process close denied/i,
    'even an identical duplicate close is not new evidence');
  assert.deepStrictEqual(finalImmutable.snapshot(), finalSnapshot);
  // Regression: a late child-start callback after a completed Full Read used
  // to demote immutable completion evidence to process-running. A pre-spawn
  // stop was likewise vulnerable to a stale start callback.
  assert.throws(() => finalImmutable.markProcessStarted(finalCtx), /child-start denied/i,
    'late child-start must not reopen a finalized Full Read');
  assert.deepStrictEqual(finalImmutable.snapshot(), finalSnapshot,
    'rejected late start preserves final evidence, timestamps, and history');
  const stoppedStart = fresh('stopped-child-start');
  stoppedStart.begin({ projectId: 'stopped', port: 'COM8', operation: 'read' });
  stoppedStart.save({ state: 'stopped', lastStopCode: 'read-output-unavailable' });
  const stoppedSnapshot = stoppedStart.snapshot();
  assert.throws(() => stoppedStart.markProcessStarted({ port: 'COM8', operation: 'read' }),
    /child-start denied/i, 'stale start cannot revive a stopped preparation');
  assert.deepStrictEqual(stoppedStart.snapshot(), stoppedSnapshot,
    'stopped preparation and its evidence remain unchanged');
  // Regression: a Devices symlink/junction can redirect the entire ledger
  // directory even if the JSON file itself is a valid regular file.
  const redirectedParentRoot = path.join(root, 'redirected-parent');
  const redirectedTargetRoot = path.join(root, 'redirected-parent-target');
  fs.mkdirSync(redirectedParentRoot, { recursive: true });
  fs.mkdirSync(redirectedTargetRoot, { recursive: true });
  const redirectedParent = new P01HardwareTransactionManager({
    dataRoot: () => redirectedParentRoot, platform: 'win32', now: () => now
  });
  fs.symlinkSync(redirectedTargetRoot, path.join(redirectedParentRoot, 'Devices'), 'dir');
  const externalParentLedger = path.join(redirectedTargetRoot, 'p01-hardware-transaction.json');
  assert.throws(() => redirectedParent.begin({ projectId: 'new-owner', port: 'COM8', operation: 'read' }),
    /parent redirected.*admission blocked/i, 'redirected Devices directory must deny preparation');
  assert.equal(fs.existsSync(externalParentLedger), false,
    'rejected preparation must not write into redirected ledger directory');
  const validLedger = fresh('unredirected-ledger-source');
  validLedger.begin({ projectId: 'existing-owner', port: 'COM8', operation: 'read' });
  const validBytes = fs.readFileSync(validLedger.file());
  fs.writeFileSync(externalParentLedger, validBytes);
  assert.throws(() => redirectedParent.snapshot(), /parent redirected.*admission blocked/i,
    'valid JSON in redirected parent must not count as trusted COM ownership');
  assert.throws(() => redirectedParent.assertCanStartProcess({ port: 'COM8', operation: 'read',
    transactionId: 'forged', preparationSequence: 1 }), /parent redirected.*admission blocked/i,
    'redirected parent must block CLI admission');
  assert.deepStrictEqual(fs.readFileSync(externalParentLedger), validBytes,
    'denied admission must preserve external ownership evidence');
  fs.unlinkSync(path.join(redirectedParentRoot, 'Devices'));
  redirectedParent.begin({ projectId: 'safe-owner', port: 'COM8', operation: 'read' });
  assert.equal(redirectedParent.snapshot().state, 'preparing',
    'normal newly created Devices directory must remain supported');

  // Regression: checking only Devices itself misses a symlink/junction at
  // dataRoot or higher. The external Devices folder is a normal directory,
  // so the old parent-only lstat accepted and rewrote another owner's ledger.
  const ancestorTarget = path.join(root, 'ancestor-external');
  const ancestorReal = new P01HardwareTransactionManager({
    dataRoot: () => ancestorTarget, platform: 'win32', now: () => now
  });
  ancestorReal.begin({ projectId: 'external-owner', port: 'COM8', operation: 'read' });
  const ancestorBytes = fs.readFileSync(ancestorReal.file());
  const ancestorAlias = path.join(root, 'ancestor-alias');
  fs.symlinkSync(ancestorTarget, ancestorAlias, 'dir');
  const ancestorRedirect = new P01HardwareTransactionManager({
    dataRoot: () => ancestorAlias, platform: 'win32', now: () => now
  });
  assert.throws(() => ancestorRedirect.snapshot(), /parent redirected.*admission blocked/i,
    'dataRoot symlink must not be trusted as ownership evidence');
  assert.throws(() => ancestorRedirect.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /parent redirected.*admission blocked/i, 'dataRoot symlink must deny preparation');
  assert.throws(() => ancestorRedirect.assertCanStartProcess({ port: 'COM8', operation: 'read',
    transactionId: 'forged', preparationSequence: 1 }), /parent redirected.*admission blocked/i,
    'dataRoot symlink must deny CLI launch');
  assert.deepStrictEqual(fs.readFileSync(ancestorReal.file()), ancestorBytes,
    'external ledger must remain unchanged after rejected dataRoot redirection');

  const upperAlias = path.join(root, 'ancestor-upper-alias');
  const upperReal = path.join(root, 'ancestor-upper-real');
  fs.mkdirSync(upperReal);
  fs.symlinkSync(upperReal, upperAlias, 'dir');
  const upperRedirect = new P01HardwareTransactionManager({
    dataRoot: () => path.join(upperAlias, 'new-project'), platform: 'win32', now: () => now
  });
  assert.throws(() => upperRedirect.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /parent redirected.*admission blocked/i,
    'an ancestor above a missing first-launch directory must deny preparation');
  assert.equal(fs.existsSync(path.join(upperReal, 'new-project')), false,
    'rejected ancestor redirection must not create directories outside the intended root');
  const firstLaunch = fresh('safe-nested-first-launch');
  const nestedLaunch = new P01HardwareTransactionManager({
    dataRoot: () => path.join(path.dirname(firstLaunch.dataRoot()), 'nested-first-launch', 'child'),
    platform: 'win32', now: () => now
  });
  nestedLaunch.begin({ projectId: 'first-launch', port: 'COM8', operation: 'read' });
  assert.equal(nestedLaunch.snapshot().state, 'preparing',
    'genuine missing directories must still be creatable on first launch');

  // A torn ledger used to be treated as an empty ledger, silently granting
  // begin() a new preparation while the previous child might still own COM8.
  const corrupt = fresh('corrupt-ledger-fail-closed');
  corrupt.begin({ projectId: 'safety', port: 'COM8', operation: 'read' });
  fs.writeFileSync(corrupt.file(), '{\"version\":1,', 'utf8');
  const tornBytes = fs.readFileSync(corrupt.file(), 'utf8');
  assert.throws(() => corrupt.snapshot(), /ledger invalid.*admission blocked/i);
  assert.throws(() => corrupt.begin({ projectId: 'safety', port: 'COM8', operation: 'read' }),
    /ledger invalid.*admission blocked/i, 'damaged ledger must not become a fresh preparation');
  assert.throws(() => corrupt.assertCanStartProcess({ port: 'COM8', operation: 'read',
    transactionId: 'stale', preparationSequence: 1 }), /ledger invalid.*admission blocked/i);
  assert.equal(fs.readFileSync(corrupt.file(), 'utf8'), tornBytes,
    'rejected admission must preserve damaged evidence for manual recovery');
  fs.writeFileSync(corrupt.file(), JSON.stringify({ version: 1, state: 'preparing', history: {} }));
  assert.throws(() => corrupt.snapshot(), /ledger invalid.*admission blocked/i,
    'structurally invalid JSON must also fail closed');

  // A valid JSON object with missing ownership fields is just as dangerous as
  // malformed JSON: blank() defaults previously hid the missing transaction ID.
  const incomplete = fresh('valid-json-missing-owner');
  incomplete.begin({ projectId: 'owner-before-corruption', port: 'COM8', operation: 'read' });
  for (const damaged of [
    { version: 1, state: 'preparing', history: [] },
    { ...incomplete.snapshot(), transactionId: '' },
    { ...incomplete.snapshot(), preparationSequence: 0 },
    { ...incomplete.snapshot(), state: 'process-running', lastProcessStartedPreparationSequence: 0 },
    { ...incomplete.snapshot(), state: 'unknown-state' }
  ]) {
    const damagedBytes = JSON.stringify(damaged);
    fs.writeFileSync(incomplete.file(), damagedBytes, 'utf8');
    assert.throws(() => incomplete.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
      /ledger invalid.*admission blocked/i, 'incomplete owner must not authorize replacement');
    assert.throws(() => incomplete.assertCanStartProcess({ port: 'COM8', operation: 'read',
      transactionId: 'replacement', preparationSequence: 1 }),
      /ledger invalid.*admission blocked/i, 'incomplete owner must not authorize spawn');
    assert.equal(fs.readFileSync(incomplete.file(), 'utf8'), damagedBytes,
      'rejected transaction must preserve incomplete ledger bytes');
  }

  // A killed atomic writer can leave a newer .tmp record beside a valid
  // old ledger. The old record must not authorize another COM owner. This
  // regression reconciles the orphan-write guard with symlink protection.
  const interrupted = fresh('interrupted-atomic-ledger');
  interrupted.begin({ projectId: 'first-owner', port: 'COM8', operation: 'read' });
  const oldLedger = fs.readFileSync(interrupted.file(), 'utf8');
  const orphanPath = `${interrupted.file()}.12345.0123456789abcdef.tmp`;
  const orphanBytes = '{"state":"process-running"';
  fs.writeFileSync(orphanPath, orphanBytes, 'utf8');
  assert.throws(() => interrupted.snapshot(), /interrupted update detected.*admission blocked/i,
    'a valid older ledger cannot override a crashed newer atomic update');
  assert.throws(() => interrupted.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /interrupted update detected.*admission blocked/i,
    'an orphan write must block another COM owner');
  assert.throws(() => interrupted.assertCanStartProcess({ port: 'COM8', operation: 'read',
    transactionId: 'stale', preparationSequence: 1 }),
    /interrupted update detected.*admission blocked/i,
    'orphan evidence must block a CLI spawn');
  assert.equal(fs.readFileSync(interrupted.file(), 'utf8'), oldLedger,
    'blocked admission must preserve the old ownership ledger');
  assert.equal(fs.readFileSync(orphanPath, 'utf8'), orphanBytes,
    'orphan bytes must be retained for manual recovery');
  fs.writeFileSync(`${interrupted.file()}.notes.tmp`, 'unrelated', 'utf8');
  fs.unlinkSync(orphanPath); // Simulated operator cleanup; production never auto-cleans.
  assert.equal(interrupted.snapshot().state, 'preparing',
    'unrelated temp file must not block a valid ledger');
  interrupted.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' });

  // An interrupted write may exist even when the live ledger was never
  // renamed into place; missing-file handling must still fail closed.
  const missing = fresh('interrupted-missing-ledger');
  const missingPath = `${missing.file()}.98765.0123456789abcdef.tmp`;
  fs.mkdirSync(path.dirname(missing.file()), { recursive: true });
  fs.writeFileSync(missingPath, '{"state":"process-running"', 'utf8');
  assert.throws(() => missing.begin({ projectId: 'new', port: 'COM8', operation: 'read' }),
    /interrupted update detected.*admission blocked/i,
    'missing live ledger cannot override an orphaned atomic write');
  assert.equal(fs.existsSync(missing.file()), false,
    'blocked first launch must not create a new ledger');
  assert.equal(fs.existsSync(missingPath), true, 'orphan evidence must remain');

  // An atomic writer can crash *during* a ledger read, after the first orphan
  // scan. The second scan must reject stale ownership evidence before return.
  const midRead = fresh('orphan-arrives-during-read');
  midRead.begin({ projectId: 'old-owner', port: 'COM8', operation: 'read' });
  const midReadOrphan = `${midRead.file()}.8765.0123456789abcdef.tmp`;
  const originalReadFileSync = fs.readFileSync;
  let injectedMidRead = false;
  try {
    fs.readFileSync = function (target, ...args) {
      if (!injectedMidRead && typeof target === 'number') {
        injectedMidRead = true;
        fs.writeFileSync(midReadOrphan, 'partial atomic write', 'utf8');
      }
      return originalReadFileSync.call(this, target, ...args);
    };
    assert.throws(() => midRead.snapshot(), /interrupted update detected.*admission blocked/i,
      'orphan created during ledger read must block a stale snapshot');
  } finally { fs.readFileSync = originalReadFileSync; }
  assert.equal(injectedMidRead, true, 'fixture must exercise the mid-read timing window');
  assert.equal(fs.readFileSync(midReadOrphan, 'utf8'), 'partial atomic write',
    'rejected mid-read orphan evidence must remain untouched');
  assert.throws(() => midRead.begin({ projectId: 'new-owner', port: 'COM8', operation: 'read' }),
    /interrupted update detected.*admission blocked/i,
    'interrupted writer evidence must block subsequent COM admission');

  // A missing live ledger can also race an orphan creation between the
  // directory scan and the lstat ENOENT response.
  const midMissing = fresh('orphan-arrives-during-missing-ledger-check');
  const missingOrphan = `${midMissing.file()}.8766.0123456789abcdef.tmp`;
  fs.mkdirSync(path.dirname(midMissing.file()), { recursive: true });
  const originalLstatSync = fs.lstatSync;
  let injectedMissing = false;
  try {
    fs.lstatSync = function (target, ...args) {
      if (!injectedMissing && target === midMissing.file()) {
        injectedMissing = true;
        fs.writeFileSync(missingOrphan, 'partial first write', 'utf8');
      }
      return originalLstatSync.call(this, target, ...args);
    };
    assert.throws(() => midMissing.begin({ projectId: 'new', port: 'COM8', operation: 'read' }),
      /interrupted update detected.*admission blocked/i,
      'orphan appearing at missing-ledger lookup must not permit first admission');
  } finally { fs.lstatSync = originalLstatSync; }
  assert.equal(injectedMissing, true);
  assert.equal(fs.readFileSync(missingOrphan, 'utf8'), 'partial first write');

  // Atomic replacement: if rename fails after the new ownership record was
  // durably written, retaining that pending record is essential. Deleting it
  // silently reauthorizes the older ledger despite an interrupted transition.
  const atomic = fresh('atomic-ledger-rename');
  atomic.begin({ projectId: 'atomic', port: 'COM8', operation: 'read' });
  const originalBytes = fs.readFileSync(atomic.file(), 'utf8');
  const originalRename = fs.renameSync;
  try {
    fs.renameSync = () => { const error = new Error('injected rename failure'); error.code = 'EACCES'; throw error; };
    assert.throws(() => atomic.save({ state: 'ready-to-open' }), /injected rename failure/);
  } finally { fs.renameSync = originalRename; }
  assert.equal(fs.readFileSync(atomic.file(), 'utf8'), originalBytes,
    'failed atomic replacement must not truncate the live COM ownership ledger');
  const pendingFiles = fs.readdirSync(path.dirname(atomic.file())).filter(name =>
    /^p01-hardware-transaction\.json\.\d+\.[a-f0-9]{16}\.tmp$/.test(name));
  assert.equal(pendingFiles.length, 1,
    'failed atomic replacement must retain its pending ownership record');
  const pendingPath = path.join(path.dirname(atomic.file()), pendingFiles[0]);
  assert.equal(JSON.parse(fs.readFileSync(pendingPath, 'utf8')).state, 'ready-to-open',
    'failed replacement must retain the newly written transition for operator review');
  assert.throws(() => atomic.snapshot(), /interrupted update detected.*admission blocked/i,
    'an older valid ledger must not be trusted after a failed atomic rename');
  assert.throws(() => atomic.begin({ projectId: 'replacement', port: 'COM8', operation: 'read' }),
    /interrupted update detected.*admission blocked/i,
    'a failed atomic rename must block another COM owner');
  assert.throws(() => atomic.assertCanStartProcess({ port: 'COM8', operation: 'read',
    transactionId: 'stale', preparationSequence: 1 }),
    /interrupted update detected.*admission blocked/i,
    'a failed atomic rename must block CLI launch');
  assert.equal(fs.readFileSync(atomic.file(), 'utf8'), originalBytes,
    'blocked admission must not change the previous complete ledger');
  // Simulated operator reconciliation only. Production never deletes this file.
  fs.unlinkSync(pendingPath);
  assert.equal(atomic.snapshot().state, 'preparing', 'operator reconciliation restores access to old ledger');
  atomic.save({ state: 'ready-to-open' });
  assert.equal(atomic.snapshot().state, 'ready-to-open', 'successful atomic replacement persists');
  if (!quiet) console.log('✓ P01 hardware transaction: late child-start and existing offline regression suite passed (no hardware)');
  return { passed: true };
}

if (require.main === module) runP01HardwareTransactionSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runP01HardwareTransactionSimulations };
