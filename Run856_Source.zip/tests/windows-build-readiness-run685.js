'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['encoded trailing space','../packages/foo%20',true],
 ['encoded trailing dot','../packages/foo%2e',true],
 ['encoded pipe','../packages/foo%7cbar',true],
 ['encoded less-than','../packages/foo%3cbar',true],
 ['encoded control','../packages/foo%0abar',true],
 ['encoded fragment','../packages/foo%23bar',true],
 ['encoded drive colon','../packages/C%3afolder',true],
 ['encoded path into node_modules','%2e%2e/other',true],
 ['encoded safe internal space','../packages/foo%20bar',false],
 ['encoded safe letter','../packages/%66oo',false],
 ['normal sibling workspace','../packages/foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq685-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run685: 11 encoded-path regression fixtures passed');
