const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { buildLaunchReadiness } = require('../src/launch-readiness');

function mkRoot() { return fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-launch-readiness-')); }
function write(root, name, value) { const file = path.join(root, name); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, typeof value === 'string' ? value : JSON.stringify(value, null, 2)); }
function baseline(root) {
  write(root, 'package.json', { version: '1.9.0-beta.19', license: 'UNLICENSED' });
  write(root, 'VERSION.json', { version: '1.9.0-beta.19', channel: 'beta' });
  write(root, '.github/workflows/windows-public-beta.yml', 'name: windows');
  write(root, 'SUPPORT.md', '# Support');
}
function runLaunchReadinessSimulations({ quiet = false } = {}) {
  const scenarios = [];
  {
    const root = mkRoot(); baseline(root);
    const report = buildLaunchReadiness({ appPath: root, betaState: { preferences: {}, matrix: [{ kind: 'flashing', status: 'experimental', id: 'p01' }] }, betaProgress: { overall: 55 }, updateStatus: { configured: false } });
    assert.equal(report.fullLaunchReady, false);
    assert(report.blockers.some(x => x.id === 'dependency-lock'));
    assert(report.blockers.some(x => x.id === 'license'));
    assert(report.blockers.some(x => x.id === 'verified-hardware'));
    scenarios.push('honest blockers'); fs.rmSync(root, { recursive: true, force: true });
  }
  // Regression: a placeholder or stale lockfile must never clear the
  // dependency reproducibility launch gate. This fails on beta.54.
  {
    const root = mkRoot(); baseline(root);
    const blocked = () => buildLaunchReadiness({ appPath: root }).blockers.some(x => x.id === 'dependency-lock');
    write(root, 'package.json', { name: 'tuniq-desktop', version: '1.9.0-beta.19',
      dependencies: { 'electron-updater': '6.6.2' }, devDependencies: { electron: '37.2.3' } });
    assert(blocked(), 'missing lockfile must block');
    write(root, 'package-lock.json', { lockfileVersion: 3 });
    assert(blocked(), 'empty placeholder lockfile must block');
    const integrity = 'sha512-' + Buffer.alloc(64, 0x23).toString('base64');
    const valid = { name: 'tuniq-desktop', version: '1.9.0-beta.19', lockfileVersion: 3,
      packages: { '': { name: 'tuniq-desktop', version: '1.9.0-beta.19',
        dependencies: { 'electron-updater': '6.6.2' }, devDependencies: { electron: '37.2.3' } },
        'node_modules/electron-updater': { version: '6.6.2', resolved: 'https://registry.npmjs.org/electron-updater/-/electron-updater-6.6.2.tgz', integrity },
        'node_modules/electron': { version: '37.2.3', resolved: 'https://registry.npmjs.org/electron/-/electron-37.2.3.tgz', integrity, dev: true } } };
    write(root, 'package-lock.json', valid);
    assert(!blocked(), 'complete matching direct dependency lockfile should clear only this gate');
    for (const change of [
      x => { x.packages[''].version = '1.9.0-beta.18'; },
      x => { x.packages[''].dependencies['electron-updater'] = '6.6.1'; },
      x => { x.packages['node_modules/electron'].version = '37.2.2'; },
      x => { delete x.packages['node_modules/electron'].integrity; },
      x => { x.packages['node_modules/electron'].resolved = 'http://example.invalid/electron.tgz'; }
    ]) {
      const mutated = JSON.parse(JSON.stringify(valid)); change(mutated);
      write(root, 'package-lock.json', mutated);
      assert(blocked(), 'stale, incomplete or insecure dependency metadata must block');
    }
    // A lockfile can have perfectly pinned direct dependencies while silently
    // omitting a package that a direct dependency needs. Such a file is not a
    // reproducible dependency tree and must not clear the release blocker.
    const withTransitive = JSON.parse(JSON.stringify(valid));
    withTransitive.packages['node_modules/electron-updater'].dependencies = { 'builder-util-runtime': '^9.0.0' };
    write(root, 'package-lock.json', withTransitive);
    assert(blocked(), 'missing transitive dependency must block');
    withTransitive.packages['node_modules/builder-util-runtime'] = {
      version: '9.3.1',
      resolved: 'https://registry.npmjs.org/builder-util-runtime/-/builder-util-runtime-9.3.1.tgz', integrity
    };
    write(root, 'package-lock.json', withTransitive);
    assert(!blocked(), 'complete synthetic transitive tree may clear the metadata-only gate');
    const badTransitive = JSON.parse(JSON.stringify(withTransitive));
    delete badTransitive.packages['node_modules/builder-util-runtime'].integrity;
    write(root, 'package-lock.json', badTransitive);
    assert(blocked(), 'unverified transitive tarball must block');
    const untrustedHost = JSON.parse(JSON.stringify(withTransitive));
    untrustedHost.packages['node_modules/builder-util-runtime'].resolved =
      'https://registry.npmjs.org.evil.example/builder-util-runtime.tgz';
    write(root, 'package-lock.json', untrustedHost);
    assert(blocked(), 'lookalike HTTPS registry host must not clear the gate');
    const invalidPath = JSON.parse(JSON.stringify(valid));
    invalidPath.packages['node_modules/../outside'] = {
      version: '1.0.0', resolved: 'https://registry.npmjs.org/outside/-/outside-1.0.0.tgz', integrity
    };
    write(root, 'package-lock.json', invalidPath);
    assert(blocked(), 'lockfile package path traversal must block');
    const malformed = JSON.parse(JSON.stringify(valid));
    malformed.packages[''].dependencies = null;
    write(root, 'package-lock.json', malformed);
    assert(blocked(), 'malformed root dependency object must fail closed without throwing');
    write(root, 'package-lock.json', valid);
    scenarios.push('dependency lockfile must be complete and synchronized');
    fs.rmSync(root, { recursive: true, force: true });
  }
  {
    const root = mkRoot(); baseline(root);
    write(root, 'package.json', { version: '1.9.0-beta.19', license: 'MIT' }); write(root, 'LICENSE', 'MIT'); write(root, 'package-lock.json', { lockfileVersion: 3 });
    write(root, 'RELEASE_ATTESTATION.json', { windowsCodeSigningVerified: true, privacyReviewed: true, thirdPartyRedistributionReviewed: true, incidentResponseReady: true, cleanWindowsInstallVerified: true });
    const report = buildLaunchReadiness({ appPath: root, betaState: { preferences: { updateFeedUrl: 'https://updates.example.test/tuniq/' }, matrix: [{ kind: 'flashing', status: 'verified', id: 'p01-obdlink' }] }, betaProgress: { overall: 88 }, updateStatus: { configured: true } });
    assert.equal(report.fullLaunchReady, false); assert(report.blockers.some(x => x.id === 'verified-hardware'));
    scenarios.push('verified matrix without evidence blocked'); fs.rmSync(root, { recursive: true, force: true });
  }
  {
    const root = mkRoot(); baseline(root); write(root, 'VERSION.json', { version: '1.9.0-beta.20', channel: 'beta' });
    const report = buildLaunchReadiness({ appPath: root, betaState: { preferences: {}, matrix: [] }, betaProgress: { overall: 50 }, updateStatus: {} });
    assert(report.blockers.some(x => x.id === 'version-sync'));
    scenarios.push('version drift blocked'); fs.rmSync(root, { recursive: true, force: true });
  }
  {
    const root = mkRoot(); baseline(root);
    const evidenceRoot = path.join(root, 'private-hardware-evidence');
    fs.mkdirSync(evidenceRoot, { recursive: true });
    const data = Buffer.alloc(524288, 0x31);
    const crypto = require('crypto');
    const hash = value => crypto.createHash('sha256').update(value).digest('hex');
    fs.writeFileSync(path.join(evidenceRoot, 'read-a.bin'), data);
    fs.writeFileSync(path.join(evidenceRoot, 'read-b.bin'), data);
    write(root, 'private-hardware-evidence/test-write.log', 'reviewed bench test write output');
    write(root, 'private-hardware-evidence/recovery.log', 'reviewed recovery validation');
    const record = { controller: 'P01', os: '9373372', interface: 'OBDLink MX+', physicalBenchTested: true, recoveryVerified: true, reviewed: true, reviewer: 'bench reviewer',
      reads: [{ path: 'read-a.bin', sha256: hash(data), sessionId: 'session-1' }, { path: 'read-b.bin', sha256: hash(data), sessionId: 'session-2' }],
      testWrite: { outcome: 'success', reviewed: true, log: { path: 'test-write.log', sha256: hash('reviewed bench test write output') } },
      recoveryReport: { reviewed: true, log: { path: 'recovery.log', sha256: hash('reviewed recovery validation') } }
    };
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    const entry = { kind: 'flashing', status: 'verified', id: 'p01', controllers: ['P01'], verifiedCombinations: [
      { controller: 'P01', os: '9373372', interface: 'OBDLink MX+' }
    ] };
    const opts = { appPath: root, betaState: { matrix: [entry] } };
    let result = buildLaunchReadiness(opts);
    assert(result.passed.some(x => x.id === 'verified-hardware'));
    for (const mismatched of [
      { controller: 'P01', os: '9379910', interface: 'OBDLink MX+' },
      { controller: 'P01', os: '9373372', interface: 'Other Interface' },
      { controller: 'P59', os: '9373372', interface: 'OBDLink MX+' }
    ]) {
      entry.verifiedCombinations = [mismatched];
      result = buildLaunchReadiness(opts);
      assert(result.blockers.some(x => x.id === 'verified-hardware'), `Mismatched ${JSON.stringify(mismatched)} must block launch`);
    }
    entry.verifiedCombinations = [];
    assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'), 'Broad Verified controller status without an exact combination must fail closed');
    entry.verifiedCombinations = [{ controller: 'P01', os: '9373372', interface: 'OBDLink MX+' }];
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    // A private evidence directory can appear ordinary even when an ancestor
    // is a symlink/junction. This must not silently relocate trusted evidence.
    const aliasParent = path.join(root, 'redirected-evidence-parent');
    try {
      fs.symlinkSync(root, aliasParent, process.platform === 'win32' ? 'junction' : 'dir');
      const redirected = buildLaunchReadiness({ ...opts,
        hardwareEvidenceRoot: path.join(aliasParent, 'private-hardware-evidence') });
      assert(redirected.blockers.some(x => x.id === 'verified-hardware'),
        'Private hardware evidence must reject symlink/junction ancestors above its root');
      scenarios.push('private hardware evidence root ancestor cannot be redirected');
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      console.warn('Evidence ancestor symlink fixture skipped: OS does not permit symlink creation');
    } finally { try { fs.unlinkSync(aliasParent); } catch {} }
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    // Regression: one evidenced P01 scope must not approve a second verified
    // P59/OS/interface scope without its own reviewed read and recovery proof.
    const unevidencedScope = { kind: 'flashing', status: 'verified', id: 'p59-obdlink', verifiedCombinations: [
      { controller: 'P59', os: '12579405', interface: 'OBDLink MX+' }
    ] };
    opts.betaState.matrix.push(unevidencedScope);
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'),
      'An evidenced P01 must not authorize an unevidenced P59 verified combination');
    opts.betaState.matrix.pop();
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    scenarios.push('every verified controller/OS/interface scope requires evidence');
    // Regression: copying one physical session's BINs/logs into a second
    // Verified adapter record must not qualify as independent bench evidence.
    const duplicatedRecord = JSON.parse(JSON.stringify(record));
    duplicatedRecord.interface = 'OBDLink LX';
    const secondAdapter = { kind: 'flashing', status: 'verified', id: 'p01-lx', verifiedCombinations: [
      { controller: 'P01', os: '9373372', interface: 'OBDLink LX' }
    ] };
    opts.betaState.matrix.push(secondAdapter);
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record, duplicatedRecord] });
    assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'),
      'A second Verified adapter cannot reuse the same BINs, session IDs, or logs as the first');
    opts.betaState.matrix.pop();
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    scenarios.push('cross-scope read/session/log evidence reuse rejected');

    // The manifest itself must be an independent private regular file.
    const manifestPath = path.join(evidenceRoot, 'hardware-verification.json');
    const originalManifest = fs.readFileSync(manifestPath);
    const outsideManifest = path.join(root, 'external-hardware-verification.json');
    fs.writeFileSync(outsideManifest, originalManifest);
    fs.rmSync(manifestPath);
    fs.linkSync(outsideManifest, manifestPath);
    assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'),
      'Hard-linked external manifest must not qualify hardware evidence');
    fs.rmSync(manifestPath);
    try {
      fs.symlinkSync(outsideManifest, manifestPath, 'file');
      assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'),
        'Symlinked external manifest must not qualify hardware evidence');
      fs.rmSync(manifestPath);
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      console.warn('Manifest symlink fixture skipped: OS does not permit symlink creation');
    }
    fs.writeFileSync(manifestPath, originalManifest);
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'),
      'Restored private manifest must pass integrity-only validation');
    fs.writeFileSync(manifestPath, ' '.repeat(1024 * 1024 + 1));
    assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'),
      'Oversized private manifest must fail closed');
    fs.writeFileSync(manifestPath, originalManifest);
    scenarios.push('private evidence manifest hard-link, symlink, and size guards');
    // Different path spellings must not disguise the same evidence file.
    const originalSecondPath = record.reads[1].path;
    record.reads[1].path = './read-a.bin';
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'), 'Alias of first read must not count as independent evidence');
    record.reads[1].path = originalSecondPath;
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    // Empty logs are not acceptable evidence, even with a matching digest.
    const savedRecoveryLog = fs.readFileSync(path.join(evidenceRoot, 'recovery.log'));
    fs.writeFileSync(path.join(evidenceRoot, 'recovery.log'), '');
    const savedRecoveryHash = record.recoveryReport.log.sha256;
    record.recoveryReport.log.sha256 = hash('');
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'), 'Empty recovery logs must not qualify hardware evidence');
    fs.writeFileSync(path.join(evidenceRoot, 'recovery.log'), savedRecoveryLog);
    record.recoveryReport.log.sha256 = savedRecoveryHash;
    write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    // Two distinct paths and session IDs must not disguise one hard-linked BIN.
    fs.rmSync(path.join(evidenceRoot, 'read-b.bin'));
    fs.linkSync(path.join(evidenceRoot, 'read-a.bin'), path.join(evidenceRoot, 'read-b.bin'));
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'), 'Hard-linked Full Reads must not count as independent physical evidence');
    fs.rmSync(path.join(evidenceRoot, 'read-b.bin'));
    fs.writeFileSync(path.join(evidenceRoot, 'read-b.bin'), data);
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'), 'Restored independent read must pass the file-integrity portion');
    // A log hard-linked from outside the private evidence tree is not isolated evidence.
    const outsideLog = path.join(root, 'external-test-write.log');
    fs.writeFileSync(outsideLog, 'reviewed bench test write output');
    fs.rmSync(path.join(evidenceRoot, 'test-write.log'));
    fs.linkSync(outsideLog, path.join(evidenceRoot, 'test-write.log'));
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'), 'Hard-linked external logs must not qualify hardware evidence');
    fs.rmSync(path.join(evidenceRoot, 'test-write.log'));
    fs.writeFileSync(path.join(evidenceRoot, 'test-write.log'), 'reviewed bench test write output');
    assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
    // A parent symlink or Windows junction must not redirect a private read.
    const outsideDir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-evidence-outside-'));
    try {
      fs.writeFileSync(path.join(outsideDir, 'read-b.bin'), data);
      const junction = path.join(evidenceRoot, 'redirected');
      try {
        fs.symlinkSync(outsideDir, junction, process.platform === 'win32' ? 'junction' : 'dir');
        record.reads[1].path = 'redirected/read-b.bin';
        write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
        assert(buildLaunchReadiness(opts).blockers.some(x => x.id === 'verified-hardware'),
          'Symlink/junction parent must never qualify private read evidence');
        record.reads[1].path = 'read-b.bin';
        write(root, 'private-hardware-evidence/hardware-verification.json', { records: [record] });
        assert(buildLaunchReadiness(opts).passed.some(x => x.id === 'verified-hardware'));
        scenarios.push('linked evidence parent rejected');
      } catch (error) {
        if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
        console.warn('Linked-parent fixture skipped: OS does not permit test symlink creation');
      }
    } finally { fs.rmSync(outsideDir, { recursive: true, force: true }); }
    scenarios.push('hard-linked BIN and external log spoofing rejected');
    fs.writeFileSync(path.join(evidenceRoot, 'read-b.bin'), Buffer.alloc(524288, 0x32));
    result = buildLaunchReadiness(opts);
    assert(result.blockers.some(x => x.id === 'verified-hardware'));
    scenarios.push('exact controller/OS/interface scope and tampered read enforcement');
    fs.rmSync(root, { recursive: true, force: true });
  }
  {
    const root = mkRoot(); baseline(root);
    const { writeSnapshot, verifySnapshot } = require('../tools/launch-snapshot');
    // Fingerprint fixtures must contain the required nonempty source roots.
    // These are inert test inputs, not executable production modules.
    write(root, 'src/fixture.js', '// source fixture');
    write(root, 'tools/fixture.js', '// tool fixture');
    write(root, 'tests/fixture.js', '// test fixture');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    write(root, 'VERSION.json', { version: '1.9.0-beta.20', channel: 'beta' });
    assert.equal(verifySnapshot(root).valid, false, 'A version change must invalidate a packaged snapshot');
    write(root, 'VERSION.json', { version: '1.9.0-beta.19', channel: 'beta' });
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    write(root, 'src/flash.js', 'const unsafeChange = true;');
    assert.equal(verifySnapshot(root).valid, false,
      'A changed flash execution source must invalidate a snapshot even when blocker counts are unchanged');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    write(root, '.github/workflows/windows-public-beta.yml', 'name: changed workflow');
    assert.equal(verifySnapshot(root).valid, false,
      'A changed release workflow must invalidate the prior launch snapshot');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    // A lockfile added after snapshot generation must invalidate the source
    // fingerprint even if the readiness blocker list stays unchanged.
    write(root, 'package-lock.json', { lockfileVersion: 3 });
    assert.equal(verifySnapshot(root).valid, false,
      'Adding a placeholder lockfile must invalidate source snapshot');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    write(root, 'package-lock.json', { lockfileVersion: 3, tampered: true });
    assert.equal(verifySnapshot(root).valid, false,
      'Editing lockfile bytes must invalidate source snapshot');
    writeSnapshot(root);
    write(root, 'tests/safety-contract.js', 'throw new Error("tampered safety test");');
    assert.equal(verifySnapshot(root).valid, false,
      'A changed regression test must invalidate the prior launch snapshot');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    // Regression: root-level JSON policy/attestation templates and new release
    // configuration must invalidate the source snapshot. Previously only a
    // fixed set of root JSON files was fingerprinted.
    write(root, 'RELEASE_ATTESTATION.template.json', { reviewed: false });
    assert.equal(verifySnapshot(root).valid, false,
      'Adding a release attestation template must invalidate source snapshot');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    write(root, 'RELEASE_ATTESTATION.template.json', { reviewed: true });
    assert.equal(verifySnapshot(root).valid, false,
      'Editing an attestation template must invalidate source snapshot');
    writeSnapshot(root);
    write(root, 'SECURITY_POLICY.json', { enforceReadOnly: false });
    assert.equal(verifySnapshot(root).valid, false,
      'Adding a root JSON release policy must invalidate source snapshot');
    writeSnapshot(root);
    assert.equal(verifySnapshot(root).valid, true);
    // Generated manifests are deliberately excluded: hashing them would
    // create a circular dependency with the snapshot/source archive.
    write(root, 'SOURCE_MANIFEST.json', { generated: 'changed' });
    assert.equal(verifySnapshot(root).valid, true,
      'Generated source manifest must not invalidate its own snapshot');
    const snapshot = JSON.parse(fs.readFileSync(path.join(root, 'LAUNCH_READINESS_CURRENT.json'), 'utf8'));
    assert.equal(snapshot.physicalHardwareVerified, false);
    assert(snapshot.blockers.some(x => x.id === 'verified-hardware'));
    snapshot.passed.find(x => x.id === 'version-sync').detail = '1.9.0-beta.18';
    write(root, 'LAUNCH_READINESS_CURRENT.json', snapshot);
    assert.equal(verifySnapshot(root).valid, false, 'Stale nested version detail must fail validation');
    scenarios.push('source snapshot freshness and provenance'); fs.rmSync(root, { recursive: true, force: true });
  }
  if (!quiet) console.log(`Launch readiness simulations: ${scenarios.length}/${scenarios.length} passed`);
  return { passed: true, scenarios };
}
if (require.main === module) runLaunchReadinessSimulations();
module.exports = { runLaunchReadinessSimulations };
