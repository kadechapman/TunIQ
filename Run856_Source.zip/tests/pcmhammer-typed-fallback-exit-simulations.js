'use strict';
// Offline parser/exit-code regression only; never opens a serial port.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { safeTypedDeviceFallback } = require('../src/pcmhammer-device-lease');

function runPcmHammerTypedFallbackExitSimulations() {
  const typedError = 'Error: unknown serial device type "elm".';
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-typed92-'));
  const validOutput = path.join(temp, 'backup.bin');
  const cases = [
    ['read', typedError, null, false],
    ['read', typedError, undefined, false],
    ['read', typedError, '64', false],
    ['read', typedError, 0, false],
    ['read', typedError, -1, false],
    ['read', typedError, -1073741819, false],
    ['read', typedError, 3221225477, false],
    ['read', typedError, 9009, false],
    ['read', typedError, Number.MAX_SAFE_INTEGER + 1, false],
    ['readProperties', typedError, -1, false],
    ['read', typedError, NaN, false],
    ['read', typedError, 64, true],
    ['readProperties', typedError, 1, true],
    ['testWrite', typedError, 64, false],
    ['writeFull', typedError, 64, false],
    ['read', 'Index 5 out of range', 64, false],
    ['read', 'No device matching "COM4:elm"', 1, true],
    ['read', 'Unrecognized device COM4:elm', 2, true],
    ['read', 'CRC errors: 2\n' + typedError, 64, false],
    ['read', 'CRC \x1b[31merrors: 2\x1b[0m\n' + typedError, 64, false],
    ['readProperties', 'Kernel upload: \x1b[31mfalse\x1b[0m\n' + typedError, 64, false],
    ['readProperties', '\x1b[?25l\n' + typedError, 64, false],
    ['read', typedError + '\n\x08', 64, false],
    ['readProperties', typedError + '\n\x00', 64, false],
    ['readProperties', typedError + '\n\x7f', 64, false],
    ['read', 'CRC err\rors: 2\n' + typedError, 64, false],
    ['readProperties', 'Kernel upl\road: false\n' + typedError, 64, false],
    ['readProperties', typedError + '\r', 64, false],
    ['read', 'CRC err\u200bors: 2\n' + typedError, 64, false],
    ['readProperties', 'Kernel upl\u202eoad: false\n' + typedError, 64, false],
    ['read', 'CRC err\u2028ors: 2\n' + typedError, 64, false],
    ['readProperties', typedError + '\ufeff', 64, false],
    ['readProperties', typedError + '\r\n', 64, true],
    ['readProperties', 'Opened \x1b[31mserial port COM4\x1b[0m\n' + typedError, 64, false],
    ['readProperties', 'Access to \x1b[31mport COM4 is denied\x1b[0m\n' + typedError, 64, false],
    ['read', 'Kernel upload: 0\n' + typedError, 64, false],
    ['readProperties', 'Kernel upload status: 0\n' + typedError, 64, false],
    ['readProperties', 'Loader execution: 1\n' + typedError, 64, false],
    ['read', 'Kernel upload: false\n' + typedError, 64, false],
    ['readProperties', 'Kernel transfer status: failed\n' + typedError, 64, false],
    ['read', 'Loader execution: false\n' + typedError, 64, false],
    ['read', 'CRC errors: 0002\n' + typedError, 64, false],
    ['read', 'CRC errors: 0x02\n' + typedError, 64, false],
    ['read', 'CRC errors: +2\n' + typedError, 64, false],
    ['read', 'CRC errors: -1\n' + typedError, 64, false],
    ['read', 'CRC errors: 0b10\n' + typedError, 64, false],
    ['read', 'CRC errors: 0xG2\n' + typedError, 64, false],
    ['read', 'CRC errors:\n' + typedError, 64, false],
    ['read', 'CRC errors: 0; Hash mismatches: +2\n' + typedError, 64, false],
    ['readProperties', 'Hash mismatches: 0X0A\n' + typedError, 64, false],
    ['read', 'Checksum validation: FAILED\n' + typedError, 64, false],
    ['readProperties', 'CRC check: FAILED\n' + typedError, 64, false],
    ['read', 'Read page 128 timeout\n' + typedError, 64, false],
    ['readProperties', 'Failed to read sector 0x1800\n' + typedError, 64, false],
    ['readProperties', 'Hash mismatches: 3\n' + typedError, 64, false],
    ['read', 'No response from PCM\n' + typedError, 64, false],
    ['read', 'TX: 6C 10 F0 22 F1\n' + typedError, 64, false],
    ['read', 'Access to port COM4 is denied\n' + typedError, 64, false],
    ['read', 'Unknown option --output', 64, false],
    ['read', 'Usage: PCM Hammer CLI', 64, false],
    ['read', 'Error: unknown serial device type \"j2534\"', 64, false],
    ['read', 'Error: unknown serial device type', 64, false],
    ['read', 'No device matching \"COM8:elm\"', 64, false],
    ['read', 'Unrecognized device COM8:elm', 64, false],
    ['read', 'Unknown serial device type \"elm\" for COM8:elm', 64, false],
    ['read', 'Unknown serial device type "elm" on COM8', 64, false],
    ['readProperties', 'Unknown serial device type "elm"; failed parsing COM7', 64, false],
    ['read', 'No device matching "COM4:elm"; unknown port COM9', 64, false],
    ['read', 'Unknown serial device type "elm" for COM4:slcan', 64, false],
    ['read', 'Opened serial port COM4\nUnknown serial device type "elm"\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['read', 'Serial port COM4 opened\nUnknown serial device type "elm"\nUsage: PCM Hammer CLI\nOperations: read-full', 64, false],
    ['readProperties', 'Opened serial port COM4\nUnknown serial device type "elm"\nUsage: PCM Hammer CLI', 64, false],
    ['read', 'Unknown serial device type "elm" for COM4', 64, true],
    ['read', 'Unknown serial device type \"elm\"', 64, true]
  ];
  for (const [operation, text, exitCode, expected] of cases) {
    assert.strictEqual(safeTypedDeviceFallback({ operation, text, exitCode, deviceSpec: 'COM4:elm', output: validOutput }), expected,
      `unsafe typed-device fallback: ${operation}, ${JSON.stringify(text)}, ${String(exitCode)}`);
  }
  assert.strictEqual(safeTypedDeviceFallback({ operation: 'read', text: typedError, exitCode: 64 }), false,
    'missing expected COMx:elm spec must never authorize fallback');
  assert.strictEqual(safeTypedDeviceFallback({ operation: 'read', text: typedError, exitCode: 64, deviceSpec: 'COM4' }), false,
    'plain COM spec must never authorize typed-device fallback');
  const blocked = [undefined, '', path.join(temp, 'missing', 'read.bin'), path.join(temp, 'NUL.bin')];
  for (const output of blocked) {
    assert.strictEqual(safeTypedDeviceFallback({ operation: 'read', text: typedError, exitCode: 64, deviceSpec: 'COM4:elm', output }), false);
  }
  fs.writeFileSync(validOutput, 'partial');
  assert.strictEqual(safeTypedDeviceFallback({ operation: 'read', text: typedError, exitCode: 64, deviceSpec: 'COM4:elm', output: validOutput }), false);
  fs.unlinkSync(validOutput);
  let symlinkTested = 0;
  try {
    const alias = path.join(temp, 'alias');
    fs.symlinkSync(temp, alias, process.platform === 'win32' ? 'junction' : 'dir');
    assert.strictEqual(safeTypedDeviceFallback({ operation: 'read', text: typedError, exitCode: 64, deviceSpec: 'COM4:elm', output: path.join(alias, 'read.bin') }), false);
    symlinkTested = 1;
  } catch (error) { if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error; }
  assert.strictEqual(safeTypedDeviceFallback({ operation: 'readProperties', text: typedError, exitCode: 64, deviceSpec: 'COM4:elm' }), true);
  fs.rmSync(temp, { recursive: true, force: true });
  return { passed: cases.length + 2 + blocked.length + 2 + symlinkTested + 1, hardwareVerified: false };
}
if (require.main === module) {
  const result = runPcmHammerTypedFallbackExitSimulations();
  console.log(`PCM Hammer typed-device fallback exit simulations: ${result.passed}/${result.passed} passed (offline only)`);
}
module.exports = { runPcmHammerTypedFallbackExitSimulations };
