'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['..\\packages\\electron', false],
  ['..\\..\\outside', true],
  ['../..\\outside', true],
  ['..\\../outside', true],
  ['..\\', true],
  ['packages\\electron', true],
  ['..\\packages\\..\\electron', false],
];
for (const [resolved, invalid] of cases) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq665-'));
  try {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}}));
    fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}},'node_modules/electron':{link:true,resolved}}}));
    const result = assess(root);
    assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'), invalid, resolved);
    assert.strictEqual(result.ecmWriteAuthorized, false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
    if (!invalid) assert.deepStrictEqual(result.blockers, []);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
console.log('Run665: 7 cross-platform Windows-link containment fixtures passed');
