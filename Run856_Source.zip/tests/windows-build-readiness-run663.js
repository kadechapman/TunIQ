'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const fixtures = [
  ['../electron', false], ['../packages/electron', false], ['packages/electron', true],
  ['/etc/passwd', true], ['C:\\temp\\electron', true],
  ['\\\\server\\share', true], ['folder' + String.fromCharCode(0) + 'bad', true]
];
for (const [resolved, invalid] of fixtures) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq663-'));
  try {
    fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}}));
    fs.writeFileSync(path.join(dir, 'package-lock.json'), JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}},'node_modules/electron':{link:true,resolved}}}));
    const result = assess(dir);
    assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'), invalid, JSON.stringify(resolved));
    assert.strictEqual(result.ecmWriteAuthorized, false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
    if (!invalid) assert.deepStrictEqual(result.blockers, []);
  } finally { fs.rmSync(dir, {recursive:true,force:true}); }
}
console.log('Run663: 7 portable link-target fixtures passed');
