'use strict';
// Filesystem-only fixtures: never connects to COM, OBD, or ECU hardware.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { auditPhoneLogImports } = require('../src/phone-log-import-audit');
const { importPhoneLog } = require('../src/log-import');

function runPhoneLogRecoveryAuditSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-phone-audit-'));
  const project = path.join(root, 'project');
  const logs = path.join(project, 'Logs');
  const source = path.join(root, 'phone.csv');
  fs.writeFileSync(source, 'Time,Engine RPM,VIN\n0,800,PRIVATE\n1,900,PRIVATE\n');
  const projectInfo = { id: 'test', name: 'Synthetic', folder: project };
  let passed = 0;
  const check = (condition, message) => { assert.ok(condition, message); passed++; };
  try {
    const absent = auditPhoneLogImports(project);
    check(absent.status === 'clean' && absent.scanned === 0, 'missing Logs is a clean, read-only result');
    check(!fs.existsSync(project), 'audit never creates a project');
    const result = importPhoneLog({ sourceFile: source, activeProject: projectInfo });
    let audit = auditPhoneLogImports(project);
    check(audit.status === 'clean', 'complete import is clean');
    check(audit.groups.length === 1 && audit.groups[0].status === 'complete', 'all three outputs recognized');
    check(audit.groups[0].present.join(',') === 'csv,meta,report', 'canonical parts identified');
    check(audit.groups[0].missing.length === 0, 'no missing outputs');
    const originalCsv = fs.readFileSync(result.csvPath);
    fs.unlinkSync(result.reportPath);
    audit = auditPhoneLogImports(project);
    check(audit.status === 'attention', 'interrupted publication is reported');
    check(audit.groups[0].status === 'incomplete', 'partial group classified incomplete');
    check(audit.groups[0].missing.join(',') === 'report', 'missing report identified');
    check(fs.readFileSync(result.csvPath).equals(originalCsv), 'audit leaves existing CSV untouched');
    const stage = path.join(logs, '.phone-log-stage-orphan');
    fs.mkdirSync(stage);
    fs.writeFileSync(path.join(stage, 'private.tmp'), 'do not inspect');
    audit = auditPhoneLogImports(project);
    check(audit.staging.length === 1 && audit.staging[0].type === 'directory', 'leftover staging identified');
    check(fs.existsSync(path.join(stage, 'private.tmp')), 'staging remains untouched');
    const badName = path.join(logs, 'Other-Imported-2026-10-19T10-00-00-000Z.csv');
    fs.symlinkSync(source, badName);
    audit = auditPhoneLogImports(project);
    check(audit.groups.some(g => g.status === 'unsafe' && g.unsafe.includes(path.basename(badName))), 'symlinked output flagged');
    check(fs.readFileSync(source, 'utf8').includes('PRIVATE'), 'source is not modified');
    const ignored = path.join(logs, 'unrelated.txt');
    fs.writeFileSync(ignored, 'unrelated');
    check(auditPhoneLogImports(project).groups.length === 2, 'unrelated files ignored');
    const capped = auditPhoneLogImports(project, { maxEntries: 1 });
    check(capped.truncated && capped.status === 'incomplete-scan', 'bounded scan cannot report clean on truncation');
    assert.throws(() => auditPhoneLogImports(project, { maxEntries: 10001 }), /entry limit/); passed++;
    const cli = path.join(__dirname, '../tools/audit-phone-log-imports.js');
    const run = spawnSync(process.execPath, [cli, project], { encoding: 'utf8' });
    check(run.status === 2, 'CLI flags incomplete imports with exit code 2');
    check(JSON.parse(run.stdout).status === 'attention', 'CLI prints parseable JSON');
    const noArgs = spawnSync(process.execPath, [cli], { encoding: 'utf8' });
    check(noArgs.status === 1, 'CLI rejects missing project argument');
    const linked = path.join(root, 'linked-project');
    fs.mkdirSync(linked);
    fs.symlinkSync(logs, path.join(linked, 'Logs'), 'dir');
    assert.throws(() => auditPhoneLogImports(linked), /non-symlink/); passed++;
    check(fs.existsSync(path.join(stage, 'private.tmp')), 'no cleanup or mutation occurred');

    // Deterministically redirect Logs at two different points in the scan.
    // Run64 would scan the external directory and could report 'clean'.
    // A successful audit must never certify a replacement directory.
    for (const phase of ['before-open', 'after-enumeration']) {
      const guardProject = path.join(root, `guard-${phase}`);
      const guardLogs = path.join(guardProject, 'Logs');
      const guardImport = importPhoneLog({ sourceFile: source, activeProject: { ...projectInfo, folder: guardProject } });
      const originalCsv = fs.readFileSync(guardImport.csvPath);
      const external = path.join(root, `external-${phase}`);
      const savedLogs = path.join(guardProject, 'Logs-original');
      fs.mkdirSync(external);
      fs.writeFileSync(path.join(external, 'private.txt'), 'not a TunIQ import');
      const originalOpen = fs.opendirSync;
      let swapped = false;
      const redirect = () => {
        fs.renameSync(guardLogs, savedLogs);
        fs.symlinkSync(external, guardLogs, 'dir');
        swapped = true;
      };
      try {
        fs.opendirSync = (...args) => {
          if (args[0] !== guardLogs) return originalOpen(...args);
          if (phase === 'before-open') redirect();
          const handle = originalOpen(...args);
          if (phase === 'after-enumeration') {
            return { readSync: () => handle.readSync(), closeSync: () => { handle.closeSync(); redirect(); } };
          }
          return handle;
        };
        assert.throws(() => auditPhoneLogImports(guardProject, { verifyContents: true }), /Logs directory changed during audit/);
        passed++;
      } finally {
        fs.opendirSync = originalOpen;
        if (swapped) {
          fs.unlinkSync(guardLogs);
          fs.renameSync(savedLogs, guardLogs);
        }
      }
      check(swapped && fs.readFileSync(guardImport.csvPath).equals(originalCsv), `${phase} redirect detected without modifying import`);
      check(fs.readFileSync(path.join(external, 'private.txt'), 'utf8') === 'not a TunIQ import', `${phase} external directory untouched`);
    }
    if (!quiet) console.log(`✓ Phone-log recovery audit: ${passed} read-only local checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runPhoneLogRecoveryAuditSimulations();
module.exports = { runPhoneLogRecoveryAuditSimulations };
