'use strict';
// Filesystem-only end-to-end read-proof regression; never opens a COM port or launches PCM Hammer.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { validateP01ReadFile, P01_BIN_SIZE } = require('../src/pcmhammer');
const { P01CommissioningManager } = require('../src/p01-commissioning');
function runFullReadCombinedGuardsSimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-combined-read-'));
  let passed = 0;
  try {
    const active = { id: 'combined-read-fixture', name: 'Combined read fixture', controller: 'P01', folder };
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'fixture-hw', serviceNumber: 'fixture-svc' });
    const file = path.join(folder, 'verified.bin');
    const original = Buffer.alloc(P01_BIN_SIZE, 0x21);
    fs.writeFileSync(file, original);
    const proof = validateP01ReadFile(file, { success: true });
    assert.equal(proof.valid, true, 'normal local Full Read must pass verification'); passed++;
    fs.writeFileSync(file, Buffer.alloc(P01_BIN_SIZE, 0x22));
    assert.throws(() => manager.recordRead(file, proof, { id: 'substituted', device: 'COM4' }), /digest|sha.?256|changed|mismatch/i);
    assert.equal(manager.load().reads.length, 0, 'substituted file must not enter the original ledger'); passed++;
    fs.writeFileSync(file, original);
    const validProof = validateP01ReadFile(file, { success: true });
    assert.equal(validProof.valid, true);
    const accepted = manager.recordRead(file, validProof, { id: 'original', device: 'COM4' });
    assert(accepted && manager.load().reads.length === 1, 'unchanged verified original should be recorded'); passed++;
    for (const alias of ['NUL.bin', 'read.bin.', 'read.bin:alternate']) {
      const candidate = path.join(folder, alias);
      fs.writeFileSync(candidate, original);
      const rejected = validateP01ReadFile(candidate, { success: true });
      assert.equal(rejected.valid, false, `${alias} must be rejected`);
      assert.match(rejected.code, /read-file-windows-alias/);
      passed++;
    }
    // Regression: an arbitrary complete-size file cannot qualify when a
    // caller omits CLI completion proof or passes a truthy non-boolean flag.
    for (const [label, evidence] of [
      ['missing', undefined], ['null', null], ['empty', {}],
      ['truthy-string', { success: 'true' }], ['numeric', { success: 1 }]
    ]) {
      const unproven = validateP01ReadFile(file, evidence);
      assert.equal(unproven.valid, false, `${label} CLI completion proof must fail closed`);
      assert.equal(unproven.code, 'read-result-unverified', `${label} proof must carry an explicit stop code`);
      passed++;
    }
    const failedCli = validateP01ReadFile(file, { success: false, stopCode: 'interrupted-read' });
    assert.equal(failedCli.valid, false, 'CLI failure cannot become a valid backup even if file size is complete'); passed++;
    const partial = path.join(folder, 'partial.bin');
    fs.writeFileSync(partial, Buffer.alloc(211, 0x33));
    assert.equal(validateP01ReadFile(partial, { success: true }).code, 'read-size-partial',
      'interrupted partial output must never become a verified original'); passed++;
    console.log(`✓ Combined Full Read import/ledger proof: ${passed} filesystem-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) runFullReadCombinedGuardsSimulations();
module.exports = { runFullReadCombinedGuardsSimulations };
