'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run650-'));
try {
  const pkg = { name:'fixture', version:'1.0.0', dependencies:{electron:'^30.0.0'} };
  fs.writeFileSync(path.join(root,'package.json'), JSON.stringify(pkg));
  const lock = { lockfileVersion:3, packages:{'':{name:'fixture',version:'1.0.0',dependencies:{}},'node_modules/electron':{version:'30.0.0'}} };
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
  let result=assess(root);
  assert(result.blockers.includes('package-lock-root-dependency-declarations-missing'));
  assert.deepStrictEqual(result.missingRootDependencyDeclarations,['electron']);
  lock.packages[''].dependencies={electron:'^30.0.0'};
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify(lock));
  result=assess(root);
  assert(!result.blockers.includes('package-lock-root-dependency-declarations-missing'));
  assert.deepStrictEqual(result.missingRootDependencyDeclarations,[]);
  console.log('PASS Run650 missing root lockfile dependency declaration and matching declaration');
} finally { fs.rmSync(root,{recursive:true,force:true}); }
