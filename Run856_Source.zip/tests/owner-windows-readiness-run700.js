'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { inspect, exitCodeFor } = require('../tools/owner-windows-readiness-run687');
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run700-'));
try {
  let report = inspect(temp, {controller:'P01',os:'unknown'}, 'review');
  assert.equal(report.readyForUserTesting, false);
  assert.equal(report.ecmWriteAuthorized, false);
  assert.ok(report.windows.blockers.includes('package-json-missing'));
  assert.equal(exitCodeFor(report), 2);
  fs.writeFileSync(path.join(temp,'package.json'), JSON.stringify({name:'fixture',version:'1.0.0'}));
  report = inspect(temp, {controller:'P01',os:'unknown'}, 'review');
  assert.ok(report.windows.blockers.includes('package-lock-missing'));
  assert.equal(report.owner.calibrationGates.exactOsVatsDefinitionVerified, false);
  assert.equal(report.owner.calibrationGates.electricFanOutputEnablementVerified, false);
  assert.equal(report.owner.calibrationGates.electricFanTemperatureThresholdsVerified, false);
  assert.equal(report.owner.calibrationGates.physicalCamCardAndCalibrationVerified, false);
  assert.equal(report.owner.calibrationGates.knockSensorRemovalDiagnosedWithProtectionPreserved, false);
  console.log('Run700: 9 source-only safety assertions passed');
} finally { fs.rmSync(temp,{recursive:true,force:true}); }
