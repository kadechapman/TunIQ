'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { inspect } = require('../tools/owner-windows-readiness-run687');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq687-'));
try {
 fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq-fixture',version:'1.0.0'}));
 const request = 'Disable VATS and enable ECM fan outputs with fan on at 210 F and off at 190 F. Tune my installed LSX Stage 2 cam. Both knock sensors were removed.';
 const report = inspect(root,{id:'fixture',name:'fixture',controller:'P01',os:'unknown'},request);
 assert(report.windows.blockers.includes('package-lock-missing'));
 assert.equal(report.readyForUserTesting,false);
 assert.equal(report.readyForPublicRelease,false);
 assert.equal(report.ecmWriteAuthorized,false);
 for(const type of ['fan-output-enable','physical-camshaft-tune','knock-sensor-delete'])
   assert(report.owner.unresolvedTypes.includes(type),type);
 assert(report.owner.missingSafetyFacts.some(x=>x.includes('operating-system (OS) ID')));
 assert.equal(report.windows.nativeWindowsRuntimeVerified,false);
 console.log('PASS 8 source-only owner readiness assertions');
} finally { fs.rmSync(root,{recursive:true,force:true}); }
