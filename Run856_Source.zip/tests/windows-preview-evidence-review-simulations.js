'use strict';
// Synthetic offline fixtures only; never claims a real Windows launch.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { writeEvidence } = require('../tools/windows-pe-integrity');
const { writeEvidence: writeTreeEvidence } = require('../tools/windows-preview-tree-integrity');
const { reviewEvidence, reviewEvidenceFixture } = require('../tools/windows-preview-evidence-review');
let checks = 0;
const check = (label, fn) => { fn(); checks++; };
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-evidence-review-'));
const outputRoot = path.join(root, 'dev-build-output');
const diagnostics = path.join(outputRoot, 'Run97-Diagnostics-' + 'a'.repeat(32));
const exeDir = path.join(outputRoot, 'Offline-UI-Preview-' + 'b'.repeat(32));
const exe = path.join(exeDir, 'TunIQ Offline UI Preview.exe');
const write = (name, data) => fs.writeFileSync(path.join(diagnostics, name), JSON.stringify(data));
const nonce = c => c.repeat(32);
const smoke = c => ({schemaVersion: 1, kind: 'tuniq-offline-preview-smoke',
  nonce: nonce(c), passed: true, reason: 'offline-renderer-ready',
  hardwareAvailable: false, writeHandlersRegistered: false});
try {
  fs.mkdirSync(outputRoot); fs.mkdirSync(diagnostics); fs.mkdirSync(exeDir);
  const bytes = Buffer.alloc(4096);
  bytes.write('MZ', 0, 'ascii'); bytes.writeUInt32LE(0x100, 0x3c);
  bytes.write('PE\0\0', 0x100, 'binary');
  bytes.writeUInt16LE(0x8664, 0x104); bytes.writeUInt16LE(0x0002, 0x116);
  bytes.writeUInt16LE(0x00f0, 0x114); bytes.writeUInt16LE(0x020b, 0x118);
  bytes.writeUInt16LE(2, 0x118 + 68);
  // The PE integrity gate now rejects header-only placeholders. Keep this
  // offline fixture structurally valid without claiming native execution.
  bytes.writeUInt16LE(1, 0x106); // one synthetic .text section
  bytes.writeUInt32LE(0x1000, 0x118 + 16); // entry RVA
  bytes.writeUInt32LE(0x1000, 0x118 + 32); // section alignment
  bytes.writeUInt32LE(0x200, 0x118 + 36); // file alignment
  bytes.writeUInt32LE(0x2000, 0x118 + 56); // image size
  bytes.writeUInt32LE(0x400, 0x118 + 60); // headers size
  bytes.write('.text', 0x208, 'ascii');
  bytes.writeUInt32LE(0x1000, 0x208 + 8);
  bytes.writeUInt32LE(0x1000, 0x208 + 12);
  bytes.writeUInt32LE(0x200, 0x208 + 16);
  bytes.writeUInt32LE(0x400, 0x208 + 20);
  fs.writeFileSync(exe, bytes); fs.truncateSync(exe, 2 * 1024 * 1024);
  fs.mkdirSync(path.join(exeDir, 'resources'));
  const appAsar = path.join(exeDir, 'resources', 'app.asar');
  fs.writeFileSync(appAsar, 'verified hardware-free preview payload');
  write('build-outcome.json', {schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
    passed: true, lastStep: 'Record delivered preview tree integrity', windowsRuntimeVerified: true,
    fullTunIQVerified: false, hardwareUsed: false,
    diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: path.basename(exeDir)});
  write('renderer-runtime-evidence.json', {schemaVersion: 1, kind: 'tuniq-isolated-renderer-runtime-smoke',
    nonce: nonce('1'), passed: true, actualElectronRuntime: true,
    nativeWindowsElectronVerified: true, rendererSnapshotValidated: true,
    primaryNavigationVerified: true, observedPrimaryPageCount: 9,
    runtimeBlockerCount: 0, snapshotBlockerCount: 0,
    fullTunIQVerified: false, hardwareUsed: false, ecuWriteOrFlashPerformed: false});
  for (const [file, c] of [['staged-smoke-evidence.json','2'],
    ['packaged-smoke-evidence.json','3'],['delivered-smoke-evidence.json','4']]) write(file, smoke(c));
  writeEvidence(exe, path.join(diagnostics, 'packaged-executable-integrity.json'));
  writeTreeEvidence(exeDir, path.join(diagnostics, 'packaged-preview-tree-integrity.json'));
  writeTreeEvidence(exeDir, path.join(diagnostics, 'delivered-preview-tree-integrity.json'));
  check('production reviewer rejects caller-supplied Windows platform on non-Windows hosts', () => {
    if (process.platform !== 'win32') {
      assert.throws(() => reviewEvidence(diagnostics, exe, {platform:'win32'}),
        /native-windows-host-required/);
    }
  });
  check('synthetic metadata checks return fixture-only, never Windows-runtime proof', () => {
    const result = reviewEvidenceFixture(diagnostics, exe);
    assert.equal(result.previewOnly, true); assert.equal(result.readyForUserTesting, false);
    assert.equal(result.passed, false); assert.equal(result.windowsHostConfirmed, false);
    assert.equal(result.fourDistinctStartupProofs, false);
    assert.equal(result.fixtureOnly, true); assert.equal(result.fixtureEvidenceValidated, true);
    assert.equal(result.fullTunIQVerified, false);
    assert.equal(result.deliveredTreeIntegrityVerified, false);
    assert.equal(result.deliveredExecutableSha256Verified, false);
    assert.equal(result.packagedToDeliveredTreeMatchVerified, false);
  });
  check('missing native Windows renderer marker blocks independent review', () => {
    const file = path.join(diagnostics, 'renderer-runtime-evidence.json');
    const valid = JSON.parse(fs.readFileSync(file, 'utf8'));
    write('renderer-runtime-evidence.json', {...valid, nativeWindowsElectronVerified: false});
    try { assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /four-native-preview-proofs/); }
    finally { write('renderer-runtime-evidence.json', valid); }
  });
  // Run194: the real Windows PowerShell 5.1 writer emits a UTF-8 BOM.
  // Run193's reviewer rejected that valid JSON before reaching native proofs.
  check('PowerShell UTF-8 BOM build outcome is accepted', () => {
    const file = path.join(diagnostics, 'build-outcome.json');
    const saved = fs.readFileSync(file);
    try {
      fs.writeFileSync(file, Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), saved]));
      assert.equal(reviewEvidenceFixture(diagnostics, exe).fixtureEvidenceValidated, true);
    } finally { fs.writeFileSync(file, saved); }
  });
  const interactiveOutcome = () => ({
    schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
    passed: true, lastStep: 'Open verified offline UI preview interactively',
    windowsRuntimeVerified: true, fullTunIQVerified: false, hardwareUsed: false,
    diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: path.basename(exeDir),
    interactiveLaunchRequested: true, interactiveLaunchProcessAlive: true,
    interactiveLaunchWindowVisible: true
  });
  const interactiveProof = () => ({
    schemaVersion: 1, kind: 'tuniq-offline-preview-visible-window', nonce: nonce('e'),
    diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: path.basename(exeDir),
    deliveredExeSha256: require('../tools/windows-pe-integrity').inspectPe(exe).sha256,
    probeMethod: 'user32-IsWindowVisible-and-exact-title', passed: true,
    actualWindowsWindowCheck: true, exactExpectedTitle: true, visible: true,
    hardwareUsed: false, fullTunIQVerified: false
  });
  check('one-click successful interactive step accepted only with bound window proof', () => {
    const outcomeFile = path.join(diagnostics, 'build-outcome.json');
    const proofFile = path.join(diagnostics, 'interactive-window-evidence.json');
    const saved = fs.readFileSync(outcomeFile);
    try {
      fs.writeFileSync(outcomeFile, '\ufeff' + JSON.stringify(interactiveOutcome()));
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatched-build-provenance/);
      fs.writeFileSync(proofFile, '\ufeff' + JSON.stringify(interactiveProof()));
      assert.equal(reviewEvidenceFixture(diagnostics, exe).fixtureEvidenceValidated, true);
      for (const changed of [
        {deliveredExeSha256: '0'.repeat(64)},
        {diagnosticsRun: 'Run97-Diagnostics-' + 'f'.repeat(32)},
        {visible: false},
        {hardwareUsed: true},
        {nonce: 'invalid'},
        {probeMethod: 'process-alive-only'}
      ]) {
        write('interactive-window-evidence.json', {...interactiveProof(), ...changed});
        assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatched-build-provenance/);
      }
      write('interactive-window-evidence.json', interactiveProof());
      write('build-outcome.json', {...interactiveOutcome(), interactiveLaunchWindowVisible:false});
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatched-build-provenance/);
    } finally {
      fs.writeFileSync(outcomeFile, saved);
      fs.rmSync(proofFile, {force:true});
    }
  });
  // Run172: an outcome swapped between lstat and readFileSync must not
  // certify a different build. Run171 reopened the path after its metadata
  // check, so a replacement with valid bytes was incorrectly accepted.
  check('build outcome replaced after metadata check cannot certify the build', () => {
    const file = path.join(diagnostics, 'build-outcome.json');
    const saved = fs.readFileSync(file);
    const displaced = file + '.untrusted';
    fs.writeFileSync(file, JSON.stringify({...JSON.parse(saved), passed: false}));
    const realRead = fs.readFileSync;
    let swapped = false;
    try {
      fs.readFileSync = function (target, ...args) {
        if (!swapped && target === file) {
          swapped = true;
          fs.renameSync(file, displaced);
          fs.writeFileSync(file, saved);
        }
        return realRead.call(fs, target, ...args);
      };
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe),
        /mismatched-build-provenance/);
    } finally {
      fs.readFileSync = realRead;
      fs.rmSync(file, {force:true});
      fs.rmSync(displaced, {force:true});
      fs.writeFileSync(file, saved);
    }
  });
  // Replacing the pathname while a descriptor is being read must also fail,
  // even if the opened descriptor still contains the originally valid bytes.
  check('build outcome replaced during descriptor read is rejected', () => {
    const file = path.join(diagnostics, 'build-outcome.json');
    const saved = fs.readFileSync(file);
    const displaced = file + '.swapped';
    const realRead = fs.readSync;
    let swapped = false;
    try {
      fs.readSync = function (fd, ...args) {
        if (!swapped && fs.fstatSync(fd).size === saved.length) {
          swapped = true;
          fs.renameSync(file, displaced);
          fs.writeFileSync(file, JSON.stringify({...JSON.parse(saved), passed:false}));
        }
        return realRead.call(fs, fd, ...args);
      };
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe),
        /mismatched-build-provenance/);
    } finally {
      fs.readSync = realRead;
      fs.rmSync(file, {force:true});
      fs.rmSync(displaced, {force:true});
      fs.writeFileSync(file, saved);
    }
  });
  check('premature success at packaged smoke step cannot verify delivered build', () => {
    const file = path.join(diagnostics, 'build-outcome.json');
    const valid = JSON.parse(fs.readFileSync(file, 'utf8'));
    write('build-outcome.json', {...valid, lastStep: 'Packaged Windows executable smoke'});
    try {
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /provenance|proofs|verified/i);
    } finally {
      write('build-outcome.json', valid);
    }
  });
  check('changed resources during package-to-delivery copy cannot be approved even with fresh delivered manifest', () => {
    const deliveredManifest = path.join(diagnostics, 'delivered-preview-tree-integrity.json');
    fs.writeFileSync(appAsar, 'copy changed resource that still satisfies smoke');
    fs.unlinkSync(deliveredManifest);
    writeTreeEvidence(exeDir, deliveredManifest);
    try {
      assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /integrity|mismatch/i);
    } finally {
      fs.writeFileSync(appAsar, 'verified hardware-free preview payload');
      fs.unlinkSync(deliveredManifest);
      writeTreeEvidence(exeDir, deliveredManifest);
    }
  });
  check('post-smoke tampering of app.asar must fail independent review', () => {
    fs.writeFileSync(appAsar, 'TAMPERED after delivered smoke');
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /integrity|mismatch/i);
    fs.writeFileSync(appAsar, 'verified hardware-free preview payload');
  });
  check('post-smoke extra injected file must fail independent review', () => {
    const injected = path.join(exeDir, 'unverified.dll');
    fs.writeFileSync(injected, 'injected after smoke');
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /integrity|mismatch/i);
    fs.unlinkSync(injected);
  });
  check('post-smoke removed app.asar must fail independent review', () => {
    fs.renameSync(appAsar, appAsar + '.saved');
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /integrity|mismatch|missing/i);
    fs.renameSync(appAsar + '.saved', appAsar);
  });
  check('missing delivered tree proof must fail independent review', () => {
    const proofFile = path.join(diagnostics, 'delivered-preview-tree-integrity.json');
    fs.renameSync(proofFile, proofFile + '.saved');
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /four-native-preview-proofs|ENOENT|integrity/i);
    fs.renameSync(proofFile + '.saved', proofFile);
  });
  check('real Linux CLI refuses to claim Windows verification', () => {
    if (process.platform === 'win32') return;
    const result = spawnSync(process.execPath, [path.join(__dirname, '../tools/windows-preview-evidence-review.js'), diagnostics, exe], {encoding:'utf8'});
    assert.equal(result.status, 2); assert.match(result.stderr, /native-windows-host-required/);
  });
  check('duplicate renderer nonces fail', () => {
    write('delivered-smoke-evidence.json', smoke('3'));
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /four-native-preview-proofs/);
    write('delivered-smoke-evidence.json', smoke('4'));
  });
  check('failed delivered smoke fails', () => {
    write('delivered-smoke-evidence.json', {...smoke('4'), passed: false});
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /four-native-preview-proofs/);
    write('delivered-smoke-evidence.json', smoke('4'));
  });
  check('tampered executable hash fails', () => {
    fs.appendFileSync(exe, 'tamper');
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatch/);
    fs.truncateSync(exe, 2 * 1024 * 1024);
  });
  check('missing PE integrity proof fails', () => {
    fs.renameSync(path.join(diagnostics, 'packaged-executable-integrity.json'), path.join(diagnostics, 'proof.backup'));
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /four-native-preview-proofs/);
    fs.renameSync(path.join(diagnostics, 'proof.backup'), path.join(diagnostics, 'packaged-executable-integrity.json'));
  });
  check('mismatched delivered directory in build outcome rejected', () => {
    write('build-outcome.json', {schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
      passed: true, lastStep: 'Record delivered preview tree integrity', windowsRuntimeVerified: true,
      fullTunIQVerified: false, hardwareUsed: false,
      diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: 'Offline-UI-Preview-' + 'c'.repeat(32)});
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatched-build-provenance/);
    write('build-outcome.json', {schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
      passed: true, lastStep: 'Record delivered preview tree integrity', windowsRuntimeVerified: true,
      fullTunIQVerified: false, hardwareUsed: false,
      diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: path.basename(exeDir)});
  });
  check('executable from a different output root rejected even if bytes match', () => {
    const foreign = path.join(root, 'different-output-root', path.basename(exeDir));
    fs.mkdirSync(path.dirname(foreign)); fs.mkdirSync(foreign);
    const other = path.join(foreign, path.basename(exe));
    fs.copyFileSync(exe, other);
    assert.throws(() => reviewEvidenceFixture(diagnostics, other), /mismatched-build-provenance/);
  });
  check('mismatched diagnostics run identifier rejected', () => {
    write('build-outcome.json', {schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
      passed: true, lastStep: 'Record delivered preview tree integrity', windowsRuntimeVerified: true,
      fullTunIQVerified: false, hardwareUsed: false,
      diagnosticsRun: 'Run97-Diagnostics-' + 'f'.repeat(32), deliveredPreviewDirectory: path.basename(exeDir)});
    assert.throws(() => reviewEvidenceFixture(diagnostics, exe), /mismatched-build-provenance/);
    write('build-outcome.json', {schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
      passed: true, lastStep: 'Record delivered preview tree integrity', windowsRuntimeVerified: true,
      fullTunIQVerified: false, hardwareUsed: false,
      diagnosticsRun: path.basename(diagnostics), deliveredPreviewDirectory: path.basename(exeDir)});
  });
  check('incorrect executable directory rejected', () => {
    assert.throws(() => reviewEvidenceFixture(diagnostics, path.join(root, 'preview.exe')), /unexpected-delivered/);
  });
  check('symlink diagnostics rejected', () => {
    const link = path.join(root, 'Run97-Diagnostics-' + 'c'.repeat(32));
    fs.symlinkSync(diagnostics, link, 'dir');
    assert.throws(() => reviewEvidenceFixture(link, exe), /unsafe-evidence-directory/);
  });
  console.log(`Independent Windows preview evidence offline fixtures: ${checks}/${checks} passed (NO native Windows execution).`);
} finally { fs.rmSync(root, {recursive:true, force:true}); }
