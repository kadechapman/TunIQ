'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['C:workspace\\electron', true],
  ['d:relative', true],
  ['file://workspace/electron', true],
  ['https://example.test/package', true],
  ['../packages/electron', false],
  ['packages/electron', true],
  ['../..\\outside', true],
];
for (const [resolved, invalid] of cases) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq666-'));
  try {
    fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}}));
    fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}},'node_modules/electron':{link:true,resolved}}}));
    const result = assess(root);
    assert.strictEqual(result.blockers.includes('package-lock-link-metadata-invalid'), invalid, resolved);
    assert.strictEqual(result.ecmWriteAuthorized, false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
    if (!invalid) assert.deepStrictEqual(result.blockers, []);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
console.log('Run666: 7 drive-relative and URI link fixtures passed');
