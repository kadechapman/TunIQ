'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const cases = [
  ['traversal', '../escape', true],
  ['scoped traversal', '@scope/../escape', true],
  ['prototype', '__proto__', true],
  ['windows separator', 'bad\\name', true],
  ['blank', '', true],
  ['valid scoped', '@scope/valid', false],
  ['valid plain', 'valid-name', false],
];
for (const [label, name, blocked] of cases) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq668-'));
  try {
    const lockDeps = Object.create(null);
    lockDeps[name] = '1.0.0';
    const packages = {'': {name:'tuniq',version:'1.0.0',dependencies:lockDeps}, 'node_modules/valid-name':{version:'1.0.0'}};
    fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0'}));
    fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages}));
    const result = assess(root);
    assert.strictEqual(result.blockers.includes('package-lock-root-dependency-names-invalid'),blocked,label);
    assert.strictEqual(result.ecmWriteAuthorized,false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false);
  } finally { fs.rmSync(root,{recursive:true,force:true}); }
}
console.log('Run668: 7 lockfile root dependency-name fixtures passed');
