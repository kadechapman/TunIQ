'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
function check(name, invalid) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq660-'));
  try {
    const pkg = {name:'tuniq',version:'1.0.0',dependencies:{[name]:'1.0.0'}};
    const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{[name]:'1.0.0'}},['node_modules/'+name]:{version:'1.0.0'}}};
    fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(pkg));
    fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
    const result = assess(dir);
    assert.strictEqual(result.blockers.includes('package-json-dependency-names-invalid'),invalid, name);
    assert.strictEqual(result.ecmWriteAuthorized,false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false);
    if (!invalid) assert.deepStrictEqual(result.blockers,[],name);
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
}
for (const name of ['', '.', '..', '../evil', 'foo/bar', '@scope/', '@/pkg', '@scope/../bad', '__proto__', 'constructor', 'prototype', 'bad\\name', 'bad name']) check(name,true);
for (const name of ['electron','@electron/rebuild','foo.bar','foo-bar']) check(name,false);
console.log('Run660: 17 dependency-name fixtures passed');
