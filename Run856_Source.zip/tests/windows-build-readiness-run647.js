'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run647-'));
try {
  const write = (name, content) => fs.writeFileSync(path.join(root, name), JSON.stringify(content));
  assert.deepStrictEqual(assess(root).blockers, ['package-json-missing']);
  write('package.json', { name: 'tuniq-test', version: '1.0.0' });
  assert.deepStrictEqual(assess(root).blockers, ['package-lock-missing']);
  write('package-lock.json', { lockfileVersion: 3, packages: { '': { name: 'wrong', version: '1.0.0' } } });
  assert.deepStrictEqual(assess(root).blockers, ['package-lock-root-mismatch']);
  write('package-lock.json', { lockfileVersion: 3, packages: { '': { name: 'tuniq-test', version: '1.0.0' } } });
  const result = assess(root);
  assert.deepStrictEqual(result.blockers, []);
  assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
  assert.strictEqual(result.ecmWriteAuthorized, false);
  console.log('PASS: 4 read-only readiness scenarios; no runtime or ECM authorization inferred');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
