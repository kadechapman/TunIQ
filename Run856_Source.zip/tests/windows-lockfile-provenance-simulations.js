'use strict';
// Cross-platform, actual CLI fixture: no npm downloads, Electron or ECU access.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-provenance-fixture-'));
const tool = path.resolve(__dirname, '..', 'tools', 'windows-lockfile-provenance.js');
const pkg = path.join(dir, 'package.json');
const lock = path.join(dir, 'package-lock.json');
const candidate = path.join(dir, 'package-lock.candidate.json');
const report = path.join(dir, 'dev-build-output', 'lockfile-provenance.json');
const source = path.join(dir, 'src', 'app.js');
const generated = path.join(dir, 'test-results', 'generated.json');
let checks = 0;
function run(mode, candidatePath = candidate) { return spawnSync(process.execPath, [tool, mode, candidatePath, report],
  { cwd: dir, encoding: 'utf8', timeout: 10000 }); }
function check(label, value) { assert(value, label); checks++; }
try {
  const pkgBytes = JSON.stringify({name:'tuniq-provenance-fixture', version:'1.0.0', private:true})+'\n';
  const lockBytes = JSON.stringify({name:'tuniq-provenance-fixture', version:'1.0.0', lockfileVersion:3,
    packages:{'':{name:'tuniq-provenance-fixture',version:'1.0.0'}}})+'\n';
  fs.mkdirSync(path.dirname(report));
  fs.mkdirSync(path.dirname(source));
  fs.mkdirSync(path.join(dir, 'tools'));
  fs.mkdirSync(path.join(dir, 'tests'));
  fs.mkdirSync(path.dirname(generated));
  fs.writeFileSync(source, 'reviewed application code\n');
  fs.writeFileSync(path.join(dir, 'VERSION.json'), '{"version":"1.0.0"}\n');
  fs.writeFileSync(path.join(dir, 'tools', 'fixture.js'), 'module.exports = true;\n');
  fs.writeFileSync(path.join(dir, 'tests', 'fixture.js'), 'module.exports = true;\n');
  fs.writeFileSync(generated, '{}\n');
  fs.writeFileSync(pkg, pkgBytes);
  fs.writeFileSync(lock, lockBytes);
  fs.writeFileSync(candidate, lockBytes);
  check('capture accepts identical genuine candidate bytes', run('--capture').status === 0);
  const evidence = JSON.parse(fs.readFileSync(report, 'utf8'));
  check('evidence records source and candidate digests without filesystem paths',
    evidence.kind === 'tuniq-windows-lockfile-provenance' && evidence.schemaVersion === 2 &&
    /^[a-f0-9]{64}$/.test(evidence.criticalSourceSha256) &&
    Number.isSafeInteger(evidence.criticalSourceFileCount) && evidence.criticalSourceFileCount >= 3 &&
    /^[a-f0-9]{64}$/.test(evidence.packageJsonSha256) &&
    evidence.lockfileSha256 === evidence.candidateSha256 &&
    evidence.nativeInstallVerified === false && !JSON.stringify(evidence).includes(dir));
  check('verify accepts unchanged package, lock, candidate and critical source', run('--verify').status === 0);
  fs.writeFileSync(generated, '{\"updated\":true}\n');
  check('verify tolerates generated test results after install', run('--verify').status === 0);
  fs.writeFileSync(source, 'synthetic npm lifecycle modified application code\n');
  check('verify rejects application source changed by npm lifecycle scripts', run('--verify').status !== 0);
  fs.writeFileSync(source, 'reviewed application code\n');
  check('verify accepts restored application source', run('--verify').status === 0);
  const toolFixture = path.join(dir, 'tools', 'fixture.js');
  fs.writeFileSync(toolFixture, 'module.exports = false;\n');
  check('verify rejects modified reviewed tool source', run('--verify').status !== 0);
  fs.writeFileSync(toolFixture, 'module.exports = true;\n');
  check('verify accepts restored reviewed tool source', run('--verify').status === 0);
  const unexpectedTool = path.join(dir, 'tools', 'unexpected.js');
  fs.writeFileSync(unexpectedTool, 'unreviewed tooling module\n');
  check('verify rejects newly added unreviewed tool source', run('--verify').status !== 0);
  fs.rmSync(unexpectedTool);
  check('verify accepts removal of unreviewed tool source', run('--verify').status === 0);
  const unexpectedTest = path.join(dir, 'tests', 'unexpected.js');
  fs.writeFileSync(unexpectedTest, 'unreviewed test module\n');
  check('verify rejects newly added unreviewed test source', run('--verify').status !== 0);
  fs.rmSync(unexpectedTest);
  check('verify accepts removal of unreviewed test source', run('--verify').status === 0);
  const nestedUnexpectedTool = path.join(dir, 'tools', 'unreviewed', 'nested.js');
  fs.mkdirSync(path.dirname(nestedUnexpectedTool));
  fs.writeFileSync(nestedUnexpectedTool, 'unreviewed nested tooling module\n');
  check('verify rejects unreviewed nested tooling source', run('--verify').status !== 0);
  fs.rmSync(path.dirname(nestedUnexpectedTool), {recursive:true});
  check('verify accepts removal of unreviewed nested tooling source', run('--verify').status === 0);
  const nestedUnexpectedTest = path.join(dir, 'tests', 'unreviewed', 'nested.js');
  fs.mkdirSync(path.dirname(nestedUnexpectedTest));
  fs.writeFileSync(nestedUnexpectedTest, 'unreviewed nested test module\n');
  check('verify rejects unreviewed nested test source', run('--verify').status !== 0);
  fs.rmSync(path.dirname(nestedUnexpectedTest), {recursive:true});
  check('verify accepts removal of unreviewed nested test source', run('--verify').status === 0);
  const testFixture = path.join(dir, 'tests', 'fixture.js');
  fs.writeFileSync(testFixture, 'module.exports = false;\n');
  check('verify rejects modified reviewed test source', run('--verify').status !== 0);
  fs.writeFileSync(testFixture, 'module.exports = true;\n');
  check('verify accepts restored reviewed test source', run('--verify').status === 0);
  fs.writeFileSync(path.join(dir, 'src', 'unexpected.js'), 'unreviewed module\n');
  check('verify rejects newly added application source', run('--verify').status !== 0);
  fs.rmSync(path.join(dir, 'src', 'unexpected.js'));
  check('verify accepts restored source file inventory', run('--verify').status === 0);
  // Run326: existsSync() used to hide newly created dangling symlinks from
  // the critical-source fingerprint. An npm lifecycle script could plant one
  // without changing the recorded hash. Verify fail-closed behavior whenever
  // the test host permits symlink creation (Windows may require Developer Mode).
  for (const relative of ['src/unreviewed-dangling.js', '.npmrc']) {
    const aliasPath = path.join(dir, relative);
    let created = false;
    try {
      fs.symlinkSync('nonexistent-tuniq-target', aliasPath, 'file');
      created = true;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      console.warn(`Dangling-symlink fixture unavailable on this host: ${relative}`);
    }
    if (created) {
      check(`verify rejects new dangling symlink at ${relative}`, run('--verify').status !== 0);
      fs.rmSync(aliasPath);
      check(`verify accepts removal of dangling symlink at ${relative}`, run('--verify').status === 0);
    }
  }
  // Run327: A FIFO/socket-like filesystem entry used to disappear from the
  // fingerprint. The test is POSIX-only; no such device is created on Windows.
  if (process.platform !== 'win32') {
    const fifo = path.join(dir, 'src', 'unreviewed.pipe');
    const mkfifo = spawnSync('mkfifo', [fifo], {encoding:'utf8', timeout:5000});
    if (mkfifo.status === 0) {
      check('verify rejects newly created non-regular FIFO in source', run('--verify').status !== 0);
      fs.rmSync(fifo);
      check('verify accepts removal of unreviewed FIFO', run('--verify').status === 0);
    } else {
      console.warn('FIFO fixture unavailable on this host; POSIX FIFO checks skipped.');
    }
  }
  // A missing optional root file becoming an empty directory was also
  // silently treated as absent. This is a synthetic source-integrity case.
  const npmrc = path.join(dir, '.npmrc');
  fs.mkdirSync(npmrc);
  check('verify rejects an empty directory replacing optional .npmrc file', run('--verify').status !== 0);
  fs.rmdirSync(npmrc);
  check('verify accepts restored absent optional .npmrc', run('--verify').status === 0);
  fs.rmSync(source);
  check('verify rejects removed reviewed application source', run('--verify').status !== 0);
  fs.writeFileSync(source, 'reviewed application code\n');
  check('verify accepts restored reviewed file', run('--verify').status === 0);
  check('verify rejects using working lockfile as its own independent candidate',
    run('--verify', lock).status !== 0);
  check('capture rejects working lockfile passed as candidate even with matching bytes',
    run('--capture', lock).status !== 0);
  fs.writeFileSync(report, JSON.stringify({...evidence, readyForUserTesting:true})+'\n');
  check('verify rejects injected readiness claims in provenance evidence', run('--verify').status !== 0);
  fs.writeFileSync(report, JSON.stringify(evidence)+'\n');
  check('capture refuses to overwrite existing evidence', run('--capture').status !== 0);
  fs.writeFileSync(pkg, pkgBytes + ' ');
  check('verify rejects package.json changed after preflight', run('--verify').status !== 0);
  fs.writeFileSync(pkg, pkgBytes);
  fs.writeFileSync(lock, lockBytes + ' ');
  check('verify rejects lockfile changed after preflight', run('--verify').status !== 0);
  fs.writeFileSync(lock, lockBytes);
  fs.writeFileSync(candidate, lockBytes + ' ');
  check('verify rejects candidate changed after preflight', run('--verify').status !== 0);
  fs.writeFileSync(candidate, lockBytes);
  fs.writeFileSync(report, JSON.stringify({...evidence, lockfileSha256:'0'.repeat(64)})+'\n');
  check('verify rejects forged digest metadata', run('--verify').status !== 0);
  fs.writeFileSync(report, JSON.stringify(evidence)+'\n');
  fs.writeFileSync(report, JSON.stringify({...evidence, criticalSourceSha256:'0'.repeat(64)})+'\n');
  check('verify rejects forged critical-source digest', run('--verify').status !== 0);
  fs.writeFileSync(report, JSON.stringify(evidence)+'\n');
  fs.rmSync(candidate);
  // Creating symlinks on Windows may require Developer Mode. Fall back to a
  // hardlink to exercise the same redirected/multiply-linked file rejection.
  let alias = 'symlink';
  try { fs.symlinkSync(lock, candidate); }
  catch (error) {
    if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    fs.linkSync(lock, candidate);
    alias = 'hardlink';
  }
  check(`verify rejects ${alias} candidate`, run('--verify').status !== 0);
  fs.rmSync(candidate);
  fs.writeFileSync(candidate, lockBytes);
  check('verify accepts restored, identical bytes', run('--verify').status === 0);
  console.log(`Windows lockfile provenance CLI fixtures: ${checks}/${checks} passed (actual Node CLI, offline; no native Windows runtime).`);
} finally { fs.rmSync(dir, {recursive:true, force:true}); }
