const assert = require('assert');
const { parseTuneRequest, buildGoalProposal, applyGoalApproved } = require('../src/goal-executor');
const { P01CommissioningManager } = require('../src/p01-commissioning');
const { commissionedCellIndex } = require('../src/commissioned-cell-index');

function workspaceF(projectId = 'service-p01') {
  return {
    mode: 'xdf', projectId, modified: {}, tables: {
      vats: {
        name: 'Vehicle Anti Theft System Enable', description: 'VATS operating mode', unit: '',
        rowHeaders: ['Value'], colHeaders: ['Value'], values: [[1]],
        enumLabels: [{ index: 0, value: 'Disabled' }, { index: 1, value: 'Enabled' }]
      },
      fans: {
        name: 'Cooling Fan Temperature Control', description: 'Electric fan coolant temperature thresholds', unit: 'deg F',
        rowHeaders: ['Fan 1 On', 'Fan 1 Off', 'Fan 2 On', 'Fan 2 Off'], colHeaders: ['Value'],
        values: [[205], [198], [215], [208]], min: 130, max: 235
      }
    }
  };
}

function runP01QuickServiceSimulations(options = {}) {
  const quiet = Boolean(options.quiet);
  const active = { id: 'service-p01', name: 'Second P01', controller: 'P01', os: '12212156' };
  const request = 'disable VATS and set the electric fans on at 210 F and off at 190 F';
  const parsed = parseTuneRequest(request);
  assert.deepEqual(parsed.intents.map(item => item.type), ['vats-disable', 'fan-control']);
  assert.equal(parsed.intents[1].fanOn, 210);
  assert.equal(parsed.intents[1].fanOff, 190);

  // Run294: proposal generation must reject corrupt decoded XDF values,
  // not only catch them later at approval. Number(null/false/''/[]) is zero;
  // Number('205') is 205. Neither conversion is trusted XDF cell evidence.
  // The synthetic OS and temperatures here do not prove ECU compatibility.
  for (const [label, invalid] of [
    ['null', null], ['boolean', false], ['empty-string', ''],
    ['empty-array', []], ['numeric-string', '205']
  ]) {
    const ws = workspaceF();
    ws.tables.vats.values[0][0] = invalid;
    ws.tables.fans.values[0][0] = invalid;
    const before = JSON.stringify(ws);
    const result = buildGoalProposal({ request, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [] });
    assert(!result.proposals.some(item => item.tableKey === 'vats'),
      `corrupt ${label} VATS cell produced a false numeric proposal`);
    assert(!result.proposals.some(item => item.tableKey === 'fans' && item.row === 0),
      `corrupt ${label} fan threshold produced a false numeric proposal`);
    assert.equal(JSON.stringify(ws), before, `proposal mutated ${label} workspace`);
  }
  // Run315: Number(null), Number(''), Number(false), Number([]) all equal
  // zero. A malformed saved commissioned map used to create a READY VATS +
  // fan proposal for row zero, and the final P01 map check also admitted it.
  // This is synthetic metadata-only testing, never a real ECM mapping.
  for (const invalid of [null, '', false, [], ' 0', '00', -1, 0.5, Infinity, '9007199254740992']) {
    assert.equal(commissionedCellIndex(invalid), null, `unsafe commissioned index admitted: ${String(invalid)}`);
    const ws = workspaceF();
    const before = JSON.stringify(ws);
    const badMap = { actions: {
      'vats-disable': { cells: [{ tableKey: 'vats', row: invalid, col: 0, role: 'disabled-state' }] },
      'fan-control': { cells: [{ tableKey: 'fans', row: 0, col: 0, role: 'fan-on' },
        { tableKey: 'fans', row: 1, col: 0, role: 'fan-off' }] }
    } };
    assert.throws(() => buildGoalProposal({ request, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [], parameterMap: badMap }),
    /invalid cell coordinate|commissioned calibration map/i,
    `malformed commissioned index ${String(invalid)} produced a partial proposal`);
    assert.equal(JSON.stringify(ws), before, `invalid commissioned index mutated the workspace: ${String(invalid)}`);
  }
  for (const good of [0, '0', 1, '1']) {
    assert.equal(commissionedCellIndex(good), Number(good), 'valid canonical coordinate was rejected');
  }
  const mappedValidString = buildGoalProposal({ request, workspace: workspaceF(), activeProject: active,
    parameterMap: { actions: { 'vats-disable': { cells: [{ tableKey: 'vats', row: '0', col: '0' }] },
      'fan-control': { cells: [{ tableKey: 'fans', row: '0', col: '0', role: 'fan-on' },
        { tableKey: 'fans', row: '1', col: '0', role: 'fan-off' }] } } } });
  assert.equal(mappedValidString.blocked, false, 'canonical numeric-string map compatibility regressed');
  assert(mappedValidString.actions.every(item => item.mapCommissioned),
    'canonical commissioned map must still be treated as commissioned');

  const mappedManager = Object.create(P01CommissioningManager.prototype);
  mappedManager.getActiveProject = () => active;
  mappedManager.isP01 = () => true;
  const mappedApproval = { id: 'goal-vats-disable:vats:0:0', actionType: 'vats-disable',
    tableKey: 'vats', row: 0, col: 0, tableName: 'VATS Enable', rowLabel: 'Value', colLabel: 'Value' };
  for (const invalid of [null, '', false, [], ' 0', '00']) {
    mappedManager.assertAiReady = () => ({ parameterMap: { actions: {
      'vats-disable': { cells: [{ tableKey: 'vats', row: invalid, col: 0 }] }
    } } });
    assert.throws(() => mappedManager.assertGoalProposalMapped({ proposals: [mappedApproval] }, [mappedApproval.id]),
      /not in the commissioned P01 parameter map/i,
      `final P01 map admission accepted malformed coordinate ${String(invalid)}`);
  }
  mappedManager.assertAiReady = () => ({ parameterMap: { actions: {
    'vats-disable': { cells: [{ tableKey: 'vats', row: '0', col: '0' }] }
  } } });
  assert.equal(mappedManager.assertGoalProposalMapped({ proposals: [mappedApproval] }, [mappedApproval.id]), true,
    'canonical commissioned coordinates should still pass the P01 map gate');

  let commissionSaved = false;
  const commissioningManager = Object.create(P01CommissioningManager.prototype);
  commissioningManager.getActiveProject = () => active;
  commissioningManager.load = () => ({ identity: { os: active.os }, canonicalReadSha256: 'synthetic-only' });
  commissioningManager.definition = () => ({ confirmedExact: true, sha256: 'synthetic-xdf-hash' });
  commissioningManager.save = () => { commissionSaved = true; };
  commissioningManager.appendActivity = () => {};
  commissioningManager.status = () => ({});
  const commissioningAction = { id: 'vats-disable', type: 'vats-disable', label: 'Synthetic VATS',
    proposals: [{ ...mappedApproval, row: null }] };
  assert.throws(() => commissioningManager.confirmGoalMap({ id: 'synthetic-proposal',
    actions: [commissioningAction] }, ['vats-disable']), /invalid XDF cell coordinate/i,
  'commissioning admitted a null coordinate as row zero');
  assert.equal(commissionSaved, false, 'rejected malformed map was persisted');

  const corruptCommissioned = workspaceF();
  corruptCommissioned.tables.vats.values[0][0] = null;
  corruptCommissioned.tables.fans.values[0][0] = null;
  const corruptMap = { actions: {
    'vats-disable': { cells: [{ tableKey: 'vats', row: 0, col: 0 }] },
    'fan-control': { cells: [
      { tableKey: 'fans', row: 0, col: 0, role: 'fan-on' },
      { tableKey: 'fans', row: 1, col: 0, role: 'fan-off' }
    ] }
  } };
  const mappedCorrupt = buildGoalProposal({ request, workspace: corruptCommissioned,
    activeProject: active, confirmations: {}, ruleFolders: [], parameterMap: corruptMap });
  assert(!mappedCorrupt.proposals.some(item => item.tableKey === 'vats' ||
    (item.tableKey === 'fans' && item.row === 0)),
  'commissioned map must not turn corrupt XDF cells into numeric values');
  const validZero = workspaceF();
  validZero.tables.vats.values[0][0] = 0;
  const validZeroProposal = buildGoalProposal({ request, workspace: validZero,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  assert(validZeroProposal.proposals.some(item => item.tableKey === 'vats' && item.current === 0),
    'genuine finite numeric zero must remain a valid decoded XDF value');

  // Run284: a request with explicitly different on/off engineering units
  // must not be silently treated as Celsius for both values. Previously
  // 95 F on / 80 C off became 95 C on / 80 C off and passed plausible
  // ranges, proposing a dangerously different temperature. Synthetic only.
  for (const mixedRequest of [
    'set fans on at 95 F and off at 80 C',
    'set fans on at 95 C and off at 80 F',
    'disable VATS and set fans on at 95 F and off at 80 C'
  ]) {
    const before = JSON.stringify(workspaceF());
    const ws = workspaceF();
    assert.throws(() => buildGoalProposal({ request: mixedRequest, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /mixed.*(?:Fahrenheit|Celsius)|different.*temperature.*units/i,
    'mixed explicit F/C fan request must require review, not silently reinterpret units');
    assert.equal(JSON.stringify(ws), before, 'mixed-unit request modified the workspace');
  }

  // Run292: extra fan thresholds expressed with activation synonyms and
  // arbitrary indexed fan banks were silently dropped while VATS + the
  // first temperature pair remained approvable. These are synthetic-only
  // examples; no real fan bank count or setpoint is inferred.
  for (const extra of [
    'fans engage at 215 F and engage at 220 F',
    'fans enabled at 215 F and enabled at 220 F',
    'fans release at 185 F and release at 180 F',
    'fan 3 enabled at 210 F',
    'fan #10 on threshold 210 F',
    'fan number 0 off temperature 190 F',
    // Run293: named/lettered banks are not represented by the generic
    // pair. These formerly produced five proposals with the extra
    // commissioning instruction silently discarded.
    'set fan three relay enabled',
    'set fan bank B output enabled',
    'fan B on threshold 215 F'
  ]) {
    const fullRequest = `${request}; ${extra}`;
    const ws = workspaceF();
    const before = JSON.stringify(ws);
    const revised = parseTuneRequest(fullRequest);
    assert(revised.unresolvedRequests.some(item =>
      item.type === 'fan-multiple-thresholds' || item.type === 'fan-bank-specific'),
    `unreviewed fan clause was silently omitted: ${extra}`);
    assert.throws(() => buildGoalProposal({ request: fullRequest, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [] }),
    /full tune request|fan|review/i, `unexpected partial proposal: ${extra}`);
    assert.equal(JSON.stringify(ws), before, `rejected request mutated workspace: ${extra}`);
  }

  // Read-only diagnostics are not themselves a bank calibration directive.
  const diagnostic = parseTuneRequest(`${request}; inspect fan bank B wiring`);
  assert(!diagnostic.unresolvedRequests.some(item => item.type === 'fan-bank-specific'),
    'read-only fan-bank inspection should not be mistaken for commissioning');

  const proposal = buildGoalProposal({ request: parsed, workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [] });
  assert.equal(proposal.blocked, false);
  assert.equal(proposal.actions.length, 2);
  const vats = proposal.proposals.find(item => item.actionType === 'vats-disable');
  const fanOn = proposal.proposals.filter(item => item.actionType === 'fan-control' && / On$/i.test(item.rowLabel));
  const fanOff = proposal.proposals.filter(item => item.actionType === 'fan-control' && / Off$/i.test(item.rowLabel));
  assert(vats, 'VATS disable proposal missing');
  assert.equal(vats.proposed, 0);
  assert.equal(fanOn.length, 2);
  assert.equal(fanOff.length, 2);
  assert(fanOn.every(item => item.proposed === 210));
  assert(fanOff.every(item => item.proposed === 190));

  // Run310: a table-level "On/Off" title used to override individual row
  // labels, proposing OFF temperatures into ON rows. A conflicting saved
  // commissioned map could even reverse both thresholds while marking the
  // action ready. Never propose the wrong role; this is fixture-only.
  const mixedRoleWorkspace = workspaceF();
  mixedRoleWorkspace.tables.fans.name = 'Cooling Fan On/Off Temperature Control';
  mixedRoleWorkspace.tables.fans.description = 'Fan on/off coolant thresholds';
  const mixedRoleBefore = JSON.stringify(mixedRoleWorkspace);
  const mixedRoleProposal = buildGoalProposal({ request, workspace: mixedRoleWorkspace,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  assert.equal(mixedRoleProposal.blocked, false, 'explicit ON/OFF rows must survive a mixed-role table title');
  assert.equal(mixedRoleProposal.proposals.filter(item => item.actionType === 'fan-control').length, 4);
  for (const item of mixedRoleProposal.proposals.filter(item => item.actionType === 'fan-control')) {
    assert.equal(item.proposed, /\bOn\b/i.test(item.rowLabel) ? 210 : 190,
      'table metadata must not override explicit ON/OFF row identity');
  }
  assert.equal(JSON.stringify(mixedRoleWorkspace), mixedRoleBefore, 'proposal mutated mixed-role fixture');

  const run310ReversedMap = { actions: { 'fan-control': { cells: [
    { tableKey: 'fans', row: 0, col: 0, role: 'fan-off' },
    { tableKey: 'fans', row: 1, col: 0, role: 'fan-on' }
  ] } } };
  const run310ReversedWorkspace = workspaceF();
  const run310ReversedBefore = JSON.stringify(run310ReversedWorkspace);
  const run310ReversedProposal = buildGoalProposal({ request, workspace: run310ReversedWorkspace,
    activeProject: active, confirmations: {}, ruleFolders: [], parameterMap: run310ReversedMap });
  assert(!run310ReversedProposal.proposals.some(item => item.actionType === 'fan-control'),
    'contradictory commissioned fan roles must not produce swapped threshold proposals');
  assert.equal(JSON.stringify(run310ReversedWorkspace), run310ReversedBefore, 'rejected map mutated fixture');

  const run310ConsistentMap = { actions: { 'fan-control': { cells: [
    { tableKey: 'fans', row: 0, col: 0, role: 'fan-on' },
    { tableKey: 'fans', row: 1, col: 0, role: 'fan-off' }
  ] } } };
  const run310ConsistentProposal = buildGoalProposal({ request, workspace: workspaceF(),
    activeProject: active, confirmations: {}, ruleFolders: [], parameterMap: run310ConsistentMap });
  assert.deepEqual(run310ConsistentProposal.proposals.filter(item => item.actionType === 'fan-control')
    .map(item => item.proposed), [210, 190], 'consistent commissioned roles remain eligible');

  // Run282: output/relay enablement is a separate ECM parameter from fan
  // temperature thresholds. A misleading deg F unit on an enable flag must
  // never turn a boolean fan-output cell into a 210-degree calibration.
  const mixedFanWorkspace = workspaceF();
  mixedFanWorkspace.tables.fanEnable = {
    name: 'Electric Fan Enable', description: 'Fan output enable bit', unit: 'deg F',
    rowHeaders: ['Fan 1 Enable'], colHeaders: ['Value'], values: [[0]], min: 0, max: 235
  };
  // Run283: "output enabled" and "relay enabled status" were missed by
  // the old "output enable" exclusion. Both are state/enablement cells,
  // regardless of an erroneous Fahrenheit label and temperature wording.
  mixedFanWorkspace.tables.fanOutputEnabled = {
    name: 'Cooling Fan Output Enabled Temperature',
    description: 'Fan relay enabled status at coolant temperature', unit: 'deg F',
    rowHeaders: ['Fan 1 Enabled'], colHeaders: ['Value'],
    values: [[0]], min: 0, max: 235
  };
  mixedFanWorkspace.tables.fanRelayEnablement = {
    name: 'Cooling Fan Relay Enablement Temperature',
    description: 'Fan relay enablement status at coolant temperature', unit: 'deg F',
    rowHeaders: ['Fan 2 Enablement'], colHeaders: ['Value'],
    values: [[0]], min: 0, max: 235
  };
  mixedFanWorkspace.tables.fanEnableTemp = {
    name: 'Electric Fan Enable Temperature', description: 'Temperature-related fan output enable flag', unit: 'deg F',
    rowHeaders: ['Fan 2 Enable'], colHeaders: ['Value'], values: [[0]], min: 0, max: 235
  };
  // Run309: bare enable/disable row labels previously inherited the table's
  // "temperature" metadata and were treated as 210/190-degree thresholds.
  // These are ambiguous boolean output states, even if an XDF says deg F.
  mixedFanWorkspace.tables.fanBareEnable = {
    name: 'Cooling Fan Temperature Control', description: 'Coolant temperature thresholds', unit: 'deg F',
    rowHeaders: ['Fan 3 Enable', 'Fan 3 Disable', 'Fan 4 Enabled', 'Fan 4 Disabled',
      'Fan 5 Enablement', 'Fan 5 Disablement'],
    colHeaders: ['Value'], values: [[0], [1], [0], [1], [0], [1]], min: 0, max: 235
  };
  const mixedFanProposal = buildGoalProposal({ request, workspace: mixedFanWorkspace,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  assert(!mixedFanProposal.proposals.some(item => item.tableKey === 'fanOutputEnabled'),
    'fan output enabled status must not become a coolant-temperature threshold');
  assert(!mixedFanProposal.proposals.some(item => item.tableKey === 'fanRelayEnablement'),
    'fan relay enablement status must not become a coolant-temperature threshold');
  assert(!mixedFanProposal.proposals.some(item => item.tableKey === 'fanEnableTemp'),
    'temperature-related output-enable flag must not be mistaken for a threshold');
  assert(!mixedFanProposal.proposals.some(item => item.tableKey === 'fanEnable'),
    'fan-output enable bit must not be mistaken for a temperature threshold');
  assert(!mixedFanProposal.proposals.some(item => item.tableKey === 'fanBareEnable'),
    'bare enable/disable row labels must not inherit a temperature threshold from the table title');
  assert.equal(mixedFanProposal.proposals.filter(item => item.actionType === 'fan-control').length, 4,
    'real threshold candidates must remain independently available');
  const mixedFanApplied = applyGoalApproved(mixedFanWorkspace, mixedFanProposal,
    mixedFanProposal.proposals.map(item => item.id));
  assert.equal(mixedFanApplied.workspace.tables.fanOutputEnabled.values[0][0], 0,
    'fan output enabled state must remain unchanged');
  assert.equal(mixedFanApplied.workspace.tables.fanRelayEnablement.values[0][0], 0,
    'fan relay enablement state must remain unchanged');
  assert.equal(mixedFanApplied.workspace.tables.fanEnableTemp.values[0][0], 0,
    'temperature-related fan output enable flag must remain untouched');
  assert.equal(mixedFanApplied.workspace.tables.fanEnable.values[0][0], 0,
    'fan output enablement must remain untouched by a threshold-only request');
  assert.deepEqual(mixedFanApplied.workspace.tables.fanBareEnable.values,
    [[0], [1], [0], [1], [0], [1]],
    'bare enable/disable output states must remain untouched');
  const delayedEnabledWorkspace = workspaceF();
  delayedEnabledWorkspace.tables.fans.name = 'Cooling Fan Output Enabled Temperature';
  delayedEnabledWorkspace.tables.fans.description = 'Fan relay enabled status at coolant temperature';
  delayedEnabledWorkspace.tables.fans.rowHeaders = ['Fan 1 Enabled', 'Fan 1 Disabled', 'Fan 2 Enabled', 'Fan 2 Disabled'];
  const delayedEnabledBefore = JSON.stringify(delayedEnabledWorkspace);
  assert.throws(() => applyGoalApproved(delayedEnabledWorkspace, proposal,
    proposal.proposals.map(item => item.id)), /non-temperature XDF cell|fan-output enablement/i,
    'delayed approval must reject output enabled status relabeling');
  assert.equal(JSON.stringify(delayedEnabledWorkspace), delayedEnabledBefore,
    'rejected delayed output-enable relabeling must not mutate VATS or fan cells');
  const relabeledFanWorkspace = workspaceF();
  relabeledFanWorkspace.tables.fans.name = 'Electric Fan Enable';
  relabeledFanWorkspace.tables.fans.description = 'Fan output enable bit';
  relabeledFanWorkspace.tables.fans.rowHeaders = ['Fan 1 Enable', 'Fan 1 Disable', 'Fan 2 Enable', 'Fan 2 Disable'];
  const relabeledBefore = JSON.stringify(relabeledFanWorkspace);
  assert.throws(() => applyGoalApproved(relabeledFanWorkspace, proposal, proposal.proposals.map(item => item.id)),
    /non-temperature XDF cell|fan-output enablement/i,
    'delayed approval must reject a threshold table relabeled as output enablement');
  assert.equal(JSON.stringify(relabeledFanWorkspace), relabeledBefore,
    'rejected enablement/threshold confusion must not mutate VATS or fan cells');

  // Run295: delayed approval must not treat an ON proposal ID as proof that
  // the current XDF row is still an ON threshold. Re-labeling only the row
  // previously wrote the ON temperature into an OFF cell and also applied VATS.
  // A generic, unlabeled row cannot independently prove the requested role.
  for (const [label, replacementLabel] of [
    ['opposite-off-label', 'Fan 1 Off'],
    ['unlabeled-threshold', 'Fan 1 Threshold']
  ]) {
    const changed = workspaceF();
    changed.tables.fans.rowHeaders[0] = replacementLabel;
    const before = JSON.stringify(changed);
    assert.throws(() => applyGoalApproved(changed, proposal,
      proposal.proposals.map(item => item.id)), /fan approval.*role|XDF cell labels|fan-temperature mapping/i,
    `${label}: delayed fan approval must fail closed`);
    assert.equal(JSON.stringify(changed), before,
      `${label}: failed fan approval must not partially modify VATS or fans`);
  }
  // Run296: an OFF row relabeled as both ON and OFF is not an unambiguous
  // OFF threshold. The old `fanRole` preferred OFF whenever it appeared,
  // so a delayed approval applied all five VATS/fan edits to a contradictory
  // XDF row. Mixed row/column labels must also fail closed, atomically.
  for (const [caseName, rowLabel, colLabel] of [
    ['on-off-slash', 'Fan 1 On / Off', 'Value'],
    ['on-and-off', 'Fan 1 On and Off', 'Value'],
    ['opposite-column', 'Fan 1 Off', 'Fan 1 On']
  ]) {
    const changed = workspaceF();
    changed.tables.fans.rowHeaders[1] = rowLabel;
    changed.tables.fans.colHeaders[0] = colLabel;
    const before = JSON.stringify(changed);
    assert.throws(() => applyGoalApproved(changed, proposal,
      proposal.proposals.map(item => item.id)),
    /fan approval.*role|XDF cell labels|fan-temperature mapping/i,
    `${caseName}: contradictory ON/OFF labels must block delayed approval`);
    assert.equal(JSON.stringify(changed), before,
      `${caseName}: contradictory labels must not partially modify VATS/fans`);
  }
  // Run298: an ON threshold's role can stay valid while its fan bank
  // changes. The old delayed-approval check accepted Fan 1 On -> Fan 2 On
  // and modified VATS plus all four fan cells. Fail before any mutation.
  for (const [caseName, edit] of [
    ['changed-fan-bank', ws => { ws.tables.fans.rowHeaders[0] = 'Fan 2 On'; }],
    ['changed-fan-column', ws => { ws.tables.fans.colHeaders[0] = 'Alternate Value'; }],
    ['missing-fan-row-label', ws => { ws.tables.fans.rowHeaders[0] = null; }]
  ]) {
    const changed = workspaceF();
    edit(changed);
    const before = JSON.stringify(changed);
    assert.throws(() => applyGoalApproved(changed, proposal,
      proposal.proposals.map(item => item.id)),
    /fan approval.*cell identity|fan-bank temperature mapping/i,
    `${caseName}: stale fan bank/label must reject delayed approval`);
    assert.equal(JSON.stringify(changed), before,
      `${caseName}: rejected fan mapping must not partially change VATS or fans`);
  }
  // Run305: changing only the XDF table name must invalidate a saved fan
  // proposal even when its temperature unit, row/column labels, and description
  // remain plausible. The old approval changed all five in-memory cells,
  // including VATS, without noticing the stale fan-table identity.
  for (const [caseName, newName, selectedIds] of [
    ['renamed-fan-table', 'Cooling Fan Temperature Control - replaced XDF table', proposal.proposals.map(item => item.id)],
    ['different-table-purpose', 'Engine Temperature Limiter', proposal.proposals.map(item => item.id)],
    ['fan-only-approval', 'Cooling Fan Temperature Control - another XDF', proposal.proposals.filter(item => item.actionType === 'fan-control').map(item => item.id)]
  ]) {
    const changed = workspaceF();
    changed.tables.fans.name = newName;
    const before = JSON.stringify(changed);
    assert.throws(() => applyGoalApproved(changed, proposal, selectedIds),
      /Fan approval.*XDF table\/cell identity/i,
      `${caseName}: stale fan table name must reject approval`);
    assert.equal(JSON.stringify(changed), before,
      `${caseName}: failed approval must not mutate any calibration cell`);
  }
  const applied = applyGoalApproved(workspaceF(), proposal, proposal.proposals.map(item => item.id));
  assert.equal(applied.workspace.tables.vats.values[0][0], 0);
  assert.deepEqual(applied.workspace.tables.fans.values, [[210], [190], [210], [190]]);
  assert.equal(Object.keys(applied.workspace.modified).length, 5);

  // Run274: a stale later fan cell used to throw AFTER VATS had already
  // changed in memory. Reject the whole approval before touching any cell.
  const staleWorkspace = workspaceF();
  const allIds = proposal.proposals.map(item => item.id);
  // Run292: a delayed approval must independently recheck unresolved fan
  // bank instructions even if the transport payload's parsed field is
  // modified to match the edited text. Reject before any VATS/fan mutation.
  for (const extra of ['fan 3 enabled at 210 F', 'fans engage at 215 F and engage at 220 F', 'set fan bank B output enabled']) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    edited.requestText += `; ${extra}`;
    edited.parsed = parseTuneRequest(edited.requestText);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, allIds),
      /unresolved safety requirements|full tune request|review/i,
      `delayed fan approval accepted unreviewed clause: ${extra}`);
    assert.equal(JSON.stringify(ws), before, `delayed fan rejection mutated workspace: ${extra}`);
  }
  // Run280: the saved request text and action identifiers are untrusted
  // transport fields. A previously approved VATS/fan subset must not be
  // applied after physical knock removal, knock-DTC suppression, or a real
  // camshaft tune is appended to the request. These are synthetic fixtures.
  for (const [label, extra] of [
    ['physical-knock-removal', 'I removed both knock sensors.'],
    ['knock-dtc-suppression', 'Suppress knock sensor DTCs.'],
    ['installed-stage2-cam', 'I installed an LSX Stage 2 cam.']
  ]) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    edited.requestText += ` ${extra}`;
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, allIds),
      /full tune request|unresolved|review/i, label);
    assert.equal(JSON.stringify(ws), before, `${label} changed workspace on rejection`);
  }
  for (const [label, edit] of [
    ['renamed-vats-id', p => {
      const item = p.proposals.find(x => x.actionType === 'vats-disable');
      item.id = item.id.replace('goal-vats-disable:', 'goal-unknown:');
      item.proposed = 1;
    }],
    ['misclassified-vats-action', p => {
      const item = p.proposals.find(x => x.actionType === 'vats-disable');
      item.id = item.id.replace('goal-vats-disable:', 'goal-rev:');
      item.actionType = 'rev-limit';
      item.proposed = 1;
    }]
  ]) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    edit(edited);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, edited.proposals.map(x => x.id)),
      /approval|action|identity|request/i, label);
    assert.equal(JSON.stringify(ws), before, `${label} changed workspace on rejection`);
  }
  staleWorkspace.tables.fans.values[0][0] = 999;
  const staleBefore = JSON.stringify(staleWorkspace);
  assert.throws(() => applyGoalApproved(staleWorkspace, proposal, allIds),
    /changed after the request was generated/i);
  assert.equal(JSON.stringify(staleWorkspace), staleBefore,
    'rejected multi-cell approval partially modified the workspace');

  // Run278: changing a fan target within the XDF's valid min/max, or
  // changing the table's engineering units after proposal generation, must
  // not silently change the approved request. All cases are synthetic;
  // these are not recommended temperatures for any physical engine.
  for (const [label, edit] of [
    ['fan-on-changed-in-range', (ws, p) => { p.proposals.find(x => x.id.startsWith('goal-fan-on:')).proposed = 212; }],
    ['fan-off-changed-in-range', (ws, p) => { p.proposals.find(x => x.id.startsWith('goal-fan-off:')).proposed = 192; }],
    ['fan-unit-relabelled', ws => { ws.tables.fans.unit = 'deg C'; }],
    ['fan-unit-erased', ws => { ws.tables.fans.unit = ''; ws.tables.fans.description = 'Electric fan thresholds'; }],
    ['fan-request-text-changed', (ws, p) => { p.requestText = 'disable VATS and set the electric fans on at 212 F and off at 190 F'; }],
    ['fan-role-misclassified', (ws, p) => { p.proposals.find(x => x.id.startsWith('goal-fan-on:')).actionType = 'vats-disable'; }]
  ]) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    edit(ws, edited);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, allIds),
      /fan approval|full tune request/i, label);
    assert.equal(JSON.stringify(ws), before, `${label} rejection partially modified the workspace`);
  }
  // Run279: A valid XDF enum state is not necessarily the owner's requested
  // VATS-disabled state. Edited approval data previously changed the VATS
  // proposal from disabled=0 to enabled=1 and was still applied. Reject
  // changed state, changed XDF labels, and a request that no longer asks to
  // disable VATS, before any selected cell changes (synthetic fixture only).
  for (const [label, edit] of [
    ['vats-changed-to-enabled-enum', (ws, p) => { p.proposals.find(x => x.actionType === 'vats-disable').proposed = 1; }],
    ['vats-enum-relabelled', ws => { ws.tables.vats.enumLabels = [
      { index: 0, value: 'Enabled' }, { index: 1, value: 'Disabled' }
    ]; }],
    ['vats-request-removed', (ws, p) => { p.requestText = 'set electric fans on at 210 F and off at 190 F'; }],
    ['vats-action-misclassified', (ws, p) => { p.proposals.find(x => x.id.startsWith('goal-vats-disable:')).actionType = 'fan-control'; }]
  ]) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    edit(ws, edited);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, allIds),
      /VATS approval|full tune request/i, label);
    assert.equal(JSON.stringify(ws), before, `${label} rejection partially modified the workspace`);
  }
  // Run303: a delayed VATS approval must not apply an old disabled-state
  // enum to a different XDF table/cell after a label edit. The numeric state
  // and OS fixture remain unchanged; these are synthetic in-memory tests.
  for (const [label, edit] of [
    ['vats-table-renamed', ws => { ws.tables.vats.name = 'Unrelated Feature'; }],
    ['vats-row-renamed', ws => { ws.tables.vats.rowHeaders[0] = 'Other Enabled State'; }],
    ['vats-column-renamed', ws => { ws.tables.vats.colHeaders[0] = 'Other Value'; }],
    ['vats-row-label-missing', ws => { ws.tables.vats.rowHeaders[0] = null; }]
  ]) {
    const ws = workspaceF();
    const beforeProposal = buildGoalProposal({ request, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [] });
    edit(ws);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, beforeProposal,
      beforeProposal.proposals.map(x => x.id)),
    /VATS approval.*(?:table|cell identity|XDF)/i,
    `${label} must reject stale VATS cell identity`);
    assert.equal(JSON.stringify(ws), before, `${label} mutated workspace before rejection`);
  }

  // A reversed but explicitly labeled synthetic XDF enum remains valid:
  // the guard must not hard-code a numeric VATS state.
  const reversedWorkspace = workspaceF();
  reversedWorkspace.tables.vats.values = [[0]];
  reversedWorkspace.tables.vats.enumLabels = [
    { index: 0, value: 'Enabled' }, { index: 1, value: 'Disabled' }
  ];
  const reversedProposal = buildGoalProposal({ request, workspace: reversedWorkspace,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  const reversedVats = reversedProposal.proposals.find(x => x.actionType === 'vats-disable');
  assert.equal(reversedVats.proposed, 1);
  assert.equal(applyGoalApproved(reversedWorkspace, reversedProposal,
    reversedProposal.proposals.map(x => x.id)).workspace.tables.vats.values[0][0], 1);

  // Recomputed temperature values are allowed when the actual table unit
  // and the generated proposal agree, including Celsius XDF conversions.
  const celsiusWorkspace = workspaceF();
  celsiusWorkspace.tables.fans.unit = 'deg C';
  celsiusWorkspace.tables.fans.min = 40;
  celsiusWorkspace.tables.fans.max = 110;
  celsiusWorkspace.tables.fans.values = [[96], [92], [100], [96]];
  const celsiusProposal = buildGoalProposal({ request, workspace: celsiusWorkspace,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  const celsiusResult = applyGoalApproved(celsiusWorkspace, celsiusProposal,
    celsiusProposal.proposals.map(item => item.id));
  assert.equal(celsiusResult.applied.length, 5,
    'a correctly generated Celsius fan proposal must remain usable');

  // Run281: contradictory XDF fan engineering units must not be resolved by
  // whichever label the parser checks first. A deg F unit with a deg C
  // description is ambiguous, even if a plausible numeric target fits the
  // definition's bounds. Reject at proposal time and on delayed approval.
  const conflictingUnits = workspaceF();
  conflictingUnits.tables.fans.description = 'Electric fan thresholds in deg C';
  conflictingUnits.tables.fans.min = 40;
  conflictingUnits.tables.fans.max = 110;
  const conflictingProposal = buildGoalProposal({ request, workspace: conflictingUnits,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  const conflictingFan = conflictingProposal.actions.find(item => item.type === 'fan-control');
  assert.equal(conflictingFan.status, 'blocked', 'contradictory XDF F/C labels were treated as a known unit');
  assert.equal(conflictingFan.proposals.length, 0,
    'ambiguous fan engineering units must not produce actionable temperature cells');
  const delayedConflict = workspaceF();
  delayedConflict.tables.fans.description = 'Electric fan thresholds in deg C';
  const delayedBefore = JSON.stringify(delayedConflict);
  assert.throws(() => applyGoalApproved(delayedConflict, proposal, allIds),
    /fan approval|unit|review/i,
    'approval did not reject a fan XDF that acquired contradictory F/C labels');
  assert.equal(JSON.stringify(delayedConflict), delayedBefore,
    'rejected conflicting fan units partially modified the workspace');

  // Run311: a table-level deg F label must not override explicit °C on
  // the individual fan rows. The old code proposed raw 210/190 into those
  // Celsius-labeled cells, even when the combined VATS/fan plan was ready.
  // Fixture temperatures and OS are not physical calibration recommendations.
  for (const [label, mutate] of [
    ['both-C-rows', ws => { ws.tables.fans.rowHeaders[0] = 'Fan 1 On (°C)'; ws.tables.fans.rowHeaders[1] = 'Fan 1 Off (°C)'; }],
    ['one-C-row', ws => { ws.tables.fans.rowHeaders[0] = 'Fan 1 On deg C'; }],
    ['mixed-cell-units', ws => { ws.tables.fans.rowHeaders[0] = 'Fan 1 On (°C / °F)'; }]
  ]) {
    const ws = workspaceF();
    mutate(ws);
    const before = JSON.stringify(ws);
    const mixed = buildGoalProposal({ request, workspace: ws,
      activeProject: active, confirmations: {}, ruleFolders: [] });
    const fan = mixed.actions.find(item => item.type === 'fan-control');
    assert.equal(fan.status, 'blocked', `${label}: contradictory cell units admitted`);
    assert.match(fan.requirements.join(' '), /row\/column temperature units/i);
    assert(fan.proposals.every(item => item.blocked), `${label}: unblocked fan proposal`);
    assert.equal(JSON.stringify(ws), before, `${label}: proposal mutated workspace`);
  }
  // The approval path independently rechecks the current XDF unit labels;
  // even an altered saved proposal cannot bypass this guard. No VATS/fan
  // cell may be partially applied on a failed combined approval.
  const unitApprovalWs = workspaceF();
  unitApprovalWs.tables.fans.rowHeaders[0] = 'Fan 1 On (°C)';
  const unitApprovalBefore = JSON.stringify(unitApprovalWs);
  const changedUnitProposal = JSON.parse(JSON.stringify(proposal));
  changedUnitProposal.proposals.find(item => item.id === 'goal-fan-on:fans:0:0').rowLabel = 'Fan 1 On (°C)';
  assert.throws(() => applyGoalApproved(unitApprovalWs, changedUnitProposal, allIds),
    /fan approval.*temperature units/i, 'delayed approval admitted conflicting fan cell units');
  assert.equal(JSON.stringify(unitApprovalWs), unitApprovalBefore,
    'unit-mismatch approval partially modified VATS/fan workspace');
  // Matching explicit per-cell Celsius labels remain usable with a Celsius XDF.
  const matchedCellUnits = workspaceF();
  matchedCellUnits.tables.fans.unit = 'deg C';
  matchedCellUnits.tables.fans.min = 40;
  matchedCellUnits.tables.fans.max = 110;
  matchedCellUnits.tables.fans.values = [[96], [92], [100], [96]];
  matchedCellUnits.tables.fans.rowHeaders[0] = 'Fan 1 On (°C)';
  matchedCellUnits.tables.fans.rowHeaders[1] = 'Fan 1 Off (°C)';
  const matchedProposal = buildGoalProposal({ request, workspace: matchedCellUnits,
    activeProject: active, confirmations: {}, ruleFolders: [] });
  assert.equal(matchedProposal.actions.find(item => item.type === 'fan-control').status, 'ready',
    'matching Celsius cell labels were incorrectly blocked');
  assert.equal(applyGoalApproved(matchedCellUnits, matchedProposal,
    matchedProposal.proposals.map(item => item.id)).applied.length, 5);

  // Run277: a decoded zero-valued VATS cell must not be treated as unchanged
  // when the workspace has lost its numeric value. JavaScript coerces null,
  // false, empty strings, and empty arrays to zero; these are not valid XDF
  // cell readings. Reject the entire multi-cell approval without mutation.
  const zeroVatsWorkspace = workspaceF();
  zeroVatsWorkspace.tables.vats.values[0][0] = 0;
  const zeroVatsProposal = buildGoalProposal({
    request, workspace: zeroVatsWorkspace, activeProject: active,
    confirmations: {}, ruleFolders: []
  });
  const zeroVatsIds = zeroVatsProposal.proposals.map(item => item.id);
  for (const [label, invalid] of [
    ['null', null], ['boolean', false], ['empty-string', ''],
    ['empty-array', []], ['numeric-string', '0']
  ]) {
    const ws = workspaceF();
    ws.tables.vats.values[0][0] = invalid;
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, zeroVatsProposal, zeroVatsIds),
      /changed after the request was generated or is not a finite numeric XDF cell/i, label);
    assert.equal(JSON.stringify(ws), before,
      `corrupt zero-valued VATS cell ${label} partially applied fan or VATS changes`);
  }
  const unchangedZeroVats = workspaceF();
  unchangedZeroVats.tables.vats.values[0][0] = 0;
  assert.equal(applyGoalApproved(unchangedZeroVats, zeroVatsProposal, zeroVatsIds).applied.length,
    zeroVatsIds.length, 'genuine numeric zero should remain a valid reviewed VATS cell');

  // A blocked later cell, missing ID, duplicate target, or non-finite value
  // must also fail without applying an earlier valid VATS change.
  for (const variant of ['blocked', 'missing-id', 'duplicate-cell', 'nonfinite']) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    const selected = edited.proposals.map(item => item.id);
    if (variant === 'blocked') edited.proposals[1].blocked = true;
    if (variant === 'missing-id') selected.push('unreviewed-cell');
    if (variant === 'duplicate-cell') {
      edited.proposals[1].tableKey = edited.proposals[0].tableKey;
      edited.proposals[1].row = edited.proposals[0].row;
      edited.proposals[1].col = edited.proposals[0].col;
      edited.proposals[1].current = edited.proposals[0].current;
    }
    if (variant === 'nonfinite') edited.proposals[1].proposed = Infinity;
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, selected),
      /blocked|missing|same calibration cell|non-finite/i, variant);
    assert.equal(JSON.stringify(ws), before, `partial mutation after ${variant} rejection`);
  }

  // Run276: approval data can be edited after generation. An out-of-range
  // fan threshold or a nonexistent VATS enum state must fail before ANY
  // selected calibration cell changes (synthetic fixture, no ECU access).
  for (const [variant, mutate, expected] of [
    ['fan-above-max', p => { p.proposals.find(item => item.actionType === 'fan-control').proposed = 300; }, /XDF calibration limits/i],
    ['fan-below-min', p => { p.proposals.find(item => item.actionType === 'fan-control').proposed = 100; }, /XDF calibration limits/i],
    ['vats-invalid-enum', p => { p.proposals.find(item => item.actionType === 'vats-disable').proposed = 2; }, /XDF enumerated state/i]
  ]) {
    const ws = workspaceF();
    const edited = JSON.parse(JSON.stringify(proposal));
    mutate(edited);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, edited, edited.proposals.map(item => item.id)),
      expected, variant);
    assert.equal(JSON.stringify(ws), before, `${variant} rejection partially modified workspace`);
  }
  for (const [variant, limit] of [['invalid-bound', 'unknown'], ['reversed-bound', 300]]) {
    const ws = workspaceF();
    ws.tables.fans.min = limit;
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, proposal, allIds),
      /invalid XDF calibration limits/i, variant);
    assert.equal(JSON.stringify(ws), before, `${variant} rejection partially modified workspace`);
  }

  // Run275: a saved approval for an earlier BIN/XDF must never apply to a
  // different source file in the same project, even when every cell value is
  // identical. These fingerprints and OS strings are synthetic fixtures,
  // not evidence of a real controller or compatible calibration.
  const fixtureBinding = (overrides = {}) => ({
    projectId: active.id, controller: 'P01', os: 'fixture-os-A',
    binSha256: 'a'.repeat(64), xdfSha256: 'b'.repeat(64), ...overrides
  });
  const fixtureActive = { ...active, os: 'fixture-os-A' };
  const boundWorkspace = (overrides = {}) => {
    const ws = workspaceF();
    ws.binding = fixtureBinding(overrides);
    return ws;
  };
  const boundProposal = buildGoalProposal({ request, workspace: boundWorkspace(),
    activeProject: fixtureActive, confirmations: {}, ruleFolders: [] });
  const boundIds = boundProposal.proposals.map(item => item.id);
  assert.deepEqual(boundProposal.binding, fixtureBinding(),
    'proposal must retain exact source fingerprints and OS identity');
  assert.equal(applyGoalApproved(boundWorkspace(), boundProposal, boundIds).applied.length, 5,
    'the same exact bound workspace must remain usable');

  // Run297: saved proposal text/parsed intents are editable transport data.
  // Adding a different or malformed explicit OS after generation previously
  // bypassed the proposal-time OS consistency check at delayed approval.
  // The bound OS is synthetic; this is not proof of a real P01 calibration.
  const numericBoundWorkspace = () => boundWorkspace({ os: active.os });
  const numericBoundProposal = buildGoalProposal({ request,
    workspace: numericBoundWorkspace(), activeProject: active,
    confirmations: {}, ruleFolders: [] });
  const numericIds = numericBoundProposal.proposals.map(item => item.id);
  for (const explicitOs of ['OS ID: 12587603', 'OS ID: unknown',
    'OS ID: 12212156 or 12587603']) {
    const ws = numericBoundWorkspace();
    const before = JSON.stringify(ws);
    const altered = JSON.parse(JSON.stringify(numericBoundProposal));
    altered.requestText += `; ${explicitOs}`;
    altered.parsed = parseTuneRequest(altered.requestText);
    assert.throws(() => applyGoalApproved(ws, altered, numericIds),
      /OS.*(?:conflict|mismatch|disagree)/i,
      `delayed approval accepted inconsistent explicit OS: ${explicitOs}`);
    assert.equal(JSON.stringify(ws), before,
      `OS mismatch partially changed workspace: ${explicitOs}`);
  }
  const matchingOs = JSON.parse(JSON.stringify(numericBoundProposal));
  matchingOs.requestText += '; OS ID: 12212156';
  matchingOs.parsed = parseTuneRequest(matchingOs.requestText);
  assert.equal(applyGoalApproved(numericBoundWorkspace(), matchingOs, numericIds).applied.length,
    numericIds.length, 'matching explicit OS must remain a valid consistency label');
  for (const [name, overrides] of [
    ['different-bin', { binSha256: 'c'.repeat(64) }],
    ['different-xdf', { xdfSha256: 'c'.repeat(64) }],
    ['different-os', { os: 'fixture-os-B' }]
  ]) {
    const ws = boundWorkspace(overrides);
    const before = JSON.stringify(ws);
    assert.throws(() => applyGoalApproved(ws, boundProposal, boundIds),
      /not bound to this exact OS\/BIN\/XDF/i, name);
    assert.equal(JSON.stringify(ws), before, `${name} rejection mutated workspace`);
  }
  const unboundProposal = buildGoalProposal({ request, workspace: workspaceF(),
    activeProject: fixtureActive, confirmations: {}, ruleFolders: [] });
  assert.throws(() => applyGoalApproved(boundWorkspace(), unboundProposal, boundIds),
    /not bound to this exact OS\/BIN\/XDF/i,
    'older saved proposals without a binding must not bypass the new guard');
  assert.throws(() => buildGoalProposal({ request, workspace: boundWorkspace(),
    activeProject: { ...fixtureActive, os: 'fixture-os-B' } }),
    /active project controller\/OS differs/i);
  for (const overrides of [{ xdfSha256: null }, { binSha256: '' }, { os: '' }]) {
    assert.throws(() => buildGoalProposal({ request, workspace: boundWorkspace(overrides),
      activeProject: fixtureActive }), /lacks an exact project\/OS\/BIN\/XDF binding/i);
  }

  const parameterMap = { actions: {
    'vats-disable': { cells: [{ tableKey: 'vats', row: 0, col: 0, role: 'disabled-state' }] },
    'fan-control': { cells: [
      { tableKey: 'fans', row: 0, col: 0, role: 'fan-on' },
      { tableKey: 'fans', row: 1, col: 0, role: 'fan-off' },
      { tableKey: 'fans', row: 2, col: 0, role: 'fan-on' },
      { tableKey: 'fans', row: 3, col: 0, role: 'fan-off' }
    ] }
  } };
  const commissioned = buildGoalProposal({ request, workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [], parameterMap });
  assert(commissioned.proposals.every(item => item.confidence === 'commissioned-os-map'));
  assert(commissioned.actions.every(action => action.mapCommissioned));

  // Run155: A missing or malformed commissioned disabledValue must not be
  // coerced to numeric zero. The synthetic enum intentionally reverses the
  // normal fixture order to prove that the value comes from definition
  // evidence, not an assumed VATS state or real controller address.
  const vatsFixture = workspaceF('synthetic-vats-enum');
  vatsFixture.tables.vats.values = [[0]];
  vatsFixture.tables.vats.enumLabels = [
    { index: 1, value: 'Disabled' }, { index: 0, value: 'Enabled' }
  ];
  const vatsProject = { ...active, id: 'synthetic-vats-enum', os: 'fixture-not-real' };
  function mappedVats(value, include = true) {
    const cell = { tableKey: 'vats', row: 0, col: 0, role: 'disabled-state' };
    if (include) cell.disabledValue = value;
    return buildGoalProposal({ request: 'disable VATS', workspace: vatsFixture,
      activeProject: vatsProject, confirmations: {}, ruleFolders: [],
      parameterMap: { actions: { 'vats-disable': { cells: [cell] } } } });
  }
  assert.equal(mappedVats(null).proposals[0].proposed, 1,
    'null commissioned value must use the explicit XDF enum, not zero');
  assert.equal(mappedVats(undefined, false).proposals[0].proposed, 1,
    'absent commissioned value must use the explicit XDF enum');
  assert.equal(mappedVats(1).proposals[0].proposed, 1,
    'finite numeric commissioned value remains supported');
  for (const invalid of ['', false, '0', 'not-a-number']) {
    const invalidProposal = mappedVats(invalid);
    assert.equal(invalidProposal.actions[0].status, 'blocked',
      `malformed commissioned disabledValue was accepted: ${String(invalid)}`);
    assert.equal(invalidProposal.proposals.length, 0,
      'malformed commissioned value must not generate a VATS proposal');
  }

  // A malformed XDF enum index is not proof of numeric zero either.
  const badEnum = workspaceF('synthetic-bad-enum');
  badEnum.tables.vats.name = 'VATS Mode';
  badEnum.tables.vats.description = 'Synthetic unmapped mode';
  badEnum.tables.vats.values = [[2]];
  const badEnumProject = { ...active, id: 'synthetic-bad-enum', os: 'fixture-not-real' };
  for (const index of [null, '', false, undefined]) {
    badEnum.tables.vats.enumLabels = [{ index, value: 'Disabled' }];
    const result = buildGoalProposal({ request: 'disable VATS', workspace: badEnum,
      activeProject: badEnumProject, confirmations: {}, ruleFolders: [] });
    assert.equal(result.actions[0].status, 'blocked',
      `malformed XDF disabled enum index was treated as zero: ${String(index)}`);
    assert.equal(result.proposals.length, 0);
  }

  // Run157 regression: a negative or contradictory enum label is not
  // evidence that the corresponding numeric value disables VATS. A loose
  // /disabled/ substring previously selected "Not Disabled" as the target.
  const ambiguousLabels = [
    [{ index: 0, value: 'Not Disabled' }, { index: 1, value: 'Enabled' }],
    [{ index: 0, value: 'Disabled / Enabled' }, { index: 1, value: 'Enabled' }],
    [{ index: 0, value: 'Disabled?' }, { index: 1, value: 'Enabled' }],
    [{ index: 0, value: 'Disabled' }, { index: 1, value: 'VATS Off' }]
  ];
  for (const labels of ambiguousLabels) {
    const ws = workspaceF('synthetic-ambiguous-vats');
    ws.tables.vats.name = 'VATS Mode';
    ws.tables.vats.description = 'Synthetic ambiguous enum';
    ws.tables.vats.values = [[2]]; // no binary flag fallback
    ws.tables.vats.enumLabels = labels;
    const proposal = buildGoalProposal({ request: 'disable VATS', workspace: ws,
      activeProject: { ...active, id: 'synthetic-ambiguous-vats', os: 'fixture-not-real' },
      confirmations: {}, ruleFolders: [] });
    assert.equal(proposal.proposals.length, 0,
      `ambiguous VATS label was accepted: ${labels.map(x => x.value).join(' | ')}`);
    assert.equal(proposal.actions[0].status, 'blocked');
  }

  // Run158: negated or contradictory *table/flag names* cannot serve as
  // binary VATS-state proof when no explicit enum or commissioned value exists.
  // Run157 hardened enum labels, but the fallback flag-name inference still
  // interpreted "VATS Not Enabled" as a positive enable flag (target zero).
  for (const name of ['VATS Not Enabled', 'VATS Not Disabled',
    'VATS Enable / Disable', 'VATS Enabled or Disabled']) {
    const ws = workspaceF('synthetic-vats-flag-ambiguity');
    ws.tables.vats.name = name;
    ws.tables.vats.description = 'Synthetic flag (no enum)';
    ws.tables.vats.enumLabels = [];
    ws.tables.vats.values = [[1]];
    const proposal = buildGoalProposal({ request: 'disable VATS', workspace: ws,
      activeProject: { ...active, id: 'synthetic-vats-flag-ambiguity', os: 'fixture-not-real' },
      confirmations: {}, ruleFolders: [] });
    assert.equal(proposal.actions[0].status, 'blocked',
      `ambiguous VATS flag label was accepted: ${name}`);
    assert.equal(proposal.proposals.length, 0);
  }
  // Ambiguous enum metadata must not be bypassed using a positive-looking
  // table name: the enum is more specific evidence than the fallback label.
  const conflictingEnum = workspaceF('synthetic-conflicting-enum');
  conflictingEnum.tables.vats.name = 'VATS Enable Flag';
  conflictingEnum.tables.vats.enumLabels = [
    { index: 0, value: 'Not Disabled' }, { index: 1, value: 'Enabled' }
  ];
  const conflictProposal = buildGoalProposal({ request: 'disable VATS',
    workspace: conflictingEnum,
    activeProject: { ...active, id: 'synthetic-conflicting-enum', os: 'fixture-not-real' },
    confirmations: {}, ruleFolders: [] });
  assert.equal(conflictProposal.actions[0].status, 'blocked');
  assert.equal(conflictProposal.proposals.length, 0);

  // The narrowly described positive enable flag remains a candidate only;
  // the owner must still commission its exact OS/XDF before real use.
  const positiveFlag = workspaceF('synthetic-positive-flag');
  positiveFlag.tables.vats.enumLabels = [];
  const positiveProposal = buildGoalProposal({ request: 'disable VATS',
    workspace: positiveFlag,
    activeProject: { ...active, id: 'synthetic-positive-flag', os: 'fixture-not-real' },
    confirmations: {}, ruleFolders: [] });
  assert.equal(positiveProposal.actions[0].status, 'ready');
  assert.equal(positiveProposal.proposals[0].proposed, 0);

  const workspaceC = workspaceF('service-c');
  workspaceC.tables.fans.unit = 'deg C';
  workspaceC.tables.fans.values = [[96.1], [91.1], [101.7], [97.8]];
  workspaceC.tables.fans.min = 60;
  workspaceC.tables.fans.max = 115;
  const cProposal = buildGoalProposal({ request, workspace: workspaceC, activeProject: { ...active, id: 'service-c' }, confirmations: {}, ruleFolders: [] });
  const cOn = cProposal.proposals.filter(item => item.actionType === 'fan-control' && / On$/i.test(item.rowLabel));
  const cOff = cProposal.proposals.filter(item => item.actionType === 'fan-control' && / Off$/i.test(item.rowLabel));
  assert(cOn.every(item => Math.abs(item.proposed - 98.888889) < 0.001));
  assert(cOff.every(item => Math.abs(item.proposed - 87.777778) < 0.001));

  const ambiguous = workspaceF('ambiguous');
  ambiguous.tables.vats = { name: 'VATS Type', rowHeaders: ['Value'], colHeaders: ['Value'], values: [[2]] };
  const ambiguousProposal = buildGoalProposal({ request: 'disable VATS', workspace: ambiguous, activeProject: { ...active, id: 'ambiguous' }, confirmations: {}, ruleFolders: [] });
  assert.equal(ambiguousProposal.actions[0].status, 'blocked');
  assert(/will not guess/i.test(ambiguousProposal.actions[0].requirements.join(' ')));

  const unitless = workspaceF('unitless');
  unitless.tables.fans.unit = '';
  unitless.tables.fans.description = 'Fan thresholds';
  const unitlessProposal = buildGoalProposal({ request: 'set fans on at 210 F and off at 190 F', workspace: unitless, activeProject: { ...active, id: 'unitless' }, confirmations: {}, ruleFolders: [] });
  assert.equal(unitlessProposal.actions[0].status, 'blocked');
  assert(/labeled engineering units/i.test(unitlessProposal.actions[0].requirements.join(' ')));

  assert.throws(() => buildGoalProposal({ request, workspace: workspaceF('wrong-project'), activeProject: active, confirmations: {}, ruleFolders: [] }), /does not match the active project/i);
  assert.throws(() => applyGoalApproved(workspaceF('other-project'), proposal, [vats.id]), /does not match/i);

  const invalidHysteresis = buildGoalProposal({ request: 'set fans on at 190 F and off at 210 F', workspace: workspaceF(), activeProject: active, confirmations: {}, ruleFolders: [] });
  const fanAction = invalidHysteresis.actions.find(item => item.type === 'fan-control');
  assert.equal(fanAction.status, 'blocked');
  assert(/lower than fan-on/i.test(fanAction.requirements.join(' ')));

  if (!quiet) console.log('✓ P01 quick service: project isolation, VATS disable, 210/190 fan mapping, C/F conversion, and no-guessed-address gates');
  return { scenarios: 9 };
}

if (require.main === module) {
  try { runP01QuickServiceSimulations(); }
  catch (error) { console.error(error.stack || error); process.exit(1); }
}

module.exports = { runP01QuickServiceSimulations };
