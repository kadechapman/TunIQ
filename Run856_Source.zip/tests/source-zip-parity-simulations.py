#!/usr/bin/env python3
"""Disposable, offline ZIP integrity fixtures. No Windows or ECU runtime."""
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
import warnings
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from importlib import import_module
zip_audit = import_module('source-zip-parity')

class SourceZipParityFixtures(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp(prefix='tuniq-zip-parity-'))
        self.repo = self.tmp / 'repo'
        self.repo.mkdir()
        def git(*args):
            subprocess.run(['git', '-C', str(self.repo), *args], check=True,
                           capture_output=True, timeout=15)
        git('init', '-q')
        git('config', 'user.name', 'Fixture')
        git('config', 'user.email', 'fixture@example.invalid')
        (self.repo / 'app.js').write_bytes(b'const value = 1;\n')
        (self.repo / 'package.json').write_bytes(b'{"private":true}\n')
        git('add', '.')
        git('commit', '-qm', 'fixture')
        self.commit = subprocess.check_output(['git', '-C', str(self.repo), 'rev-parse', 'HEAD']).decode().strip()
        self.archive = self.tmp / 'source.zip'

    def tearDown(self):
        shutil.rmtree(self.tmp)

    def make_zip(self, entries):
        with warnings.catch_warnings():
            warnings.simplefilter('ignore', UserWarning)
            with zipfile.ZipFile(self.archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                for name, data in entries:
                    info = zipfile.ZipInfo(name)
                    info.create_system = 3
                    info.external_attr = (0o100644 << 16)
                    z.writestr(info, data)
        return zip_audit.audit(self.repo, self.archive, self.commit)

    @property
    def good(self):
        return [('app.js', b'const value = 1;\n'), ('package.json', b'{"private":true}\n')]

    def test_clean_archive(self):
        result = self.make_zip(self.good)
        self.assertTrue(result['passed'])
        self.assertEqual(result['matchedFiles'], 2)

    def test_single_enclosing_folder(self):
        result = self.make_zip([('Source/' + name, data) for name, data in self.good])
        self.assertTrue(result['passed'])
        self.assertEqual(result['archiveRoot'], 'Source/')

    def test_mixed_root(self):
        result = self.make_zip([self.good[0], ('Source/package.json', self.good[1][1])])
        self.assertFalse(result['passed'])

    def test_changed_content(self):
        result = self.make_zip([('app.js', b'changed'), self.good[1]])
        self.assertFalse(result['passed'])
        self.assertIn('content-mismatch', [x['code'] for x in result['issues']])

    def test_duplicate_entry(self):
        result = self.make_zip(self.good + [self.good[0]])
        self.assertFalse(result['passed'])
        self.assertIn('duplicate-member', [x['code'] for x in result['issues']])

    def test_traversal(self):
        result = self.make_zip(self.good + [('../escape.js', b'bad')])
        self.assertFalse(result['passed'])
        self.assertIn('unsafe-path', [x['code'] for x in result['issues']])

    def test_traversal_as_common_prefix(self):
        result = self.make_zip([('../' + name, data) for name, data in self.good])
        self.assertFalse(result['passed'])
        self.assertIn('unsafe-path', [x['code'] for x in result['issues']])

    def test_drive_as_common_prefix(self):
        result = self.make_zip([('C:/' + name, data) for name, data in self.good])
        self.assertFalse(result['passed'])
        self.assertIn('unsafe-path', [x['code'] for x in result['issues']])

    def test_missing_and_extra(self):
        result = self.make_zip([self.good[0], ('extra.js', b'extra')])
        self.assertFalse(result['passed'])
        self.assertEqual({x['code'] for x in result['issues']}, {'missing-file', 'extra-file'})

    def test_symlink(self):
        with zipfile.ZipFile(self.archive, 'w') as z:
            for name, data in self.good:
                info = zipfile.ZipInfo(name)
                info.create_system = 3
                info.external_attr = ((0o120777 if name == 'app.js' else 0o100644) << 16)
                z.writestr(info, data)
        result = zip_audit.audit(self.repo, self.archive, self.commit)
        self.assertFalse(result['passed'])
        self.assertIn('unsafe-member-mode', [x['code'] for x in result['issues']])

    def make_mode_zip(self, mode, system=3):
        with zipfile.ZipFile(self.archive, 'w') as z:
            for name, data in self.good:
                info = zipfile.ZipInfo(name)
                info.create_system = system
                info.external_attr = (mode << 16) if system == 3 else 0
                z.writestr(info, data)
        return zip_audit.audit(self.repo, self.archive, self.commit)

    def test_executable_mode_cannot_replace_nonexecutable_git_file(self):
        result = self.make_mode_zip(0o100755)
        self.assertFalse(result['passed'], 'ZIP executable-bit mismatch was accepted')
        self.assertIn('source-mode-mismatch', [x['code'] for x in result['issues']])

    def test_matching_git_executable_mode_is_accepted(self):
        subprocess.run(['git', '-C', str(self.repo), 'update-index', '--chmod=+x', 'app.js'],
                       check=True, capture_output=True, timeout=15)
        subprocess.run(['git', '-C', str(self.repo), 'commit', '-qm', 'mark app executable'],
                       check=True, capture_output=True, timeout=15)
        commit = subprocess.check_output(['git', '-C', str(self.repo), 'rev-parse', 'HEAD']).decode().strip()
        with zipfile.ZipFile(self.archive, 'w') as z:
            for name, data in self.good:
                info = zipfile.ZipInfo(name)
                info.create_system = 3
                info.external_attr = ((0o100755 if name == 'app.js' else 0o100644) << 16)
                z.writestr(info, data)
        result = zip_audit.audit(self.repo, self.archive, commit)
        self.assertTrue(result['passed'], result['issues'])

    def test_setuid_mode_cannot_pass_content_parity(self):
        result = self.make_mode_zip(0o104755)
        self.assertFalse(result['passed'], 'ZIP setuid mode was accepted')
        self.assertIn('source-mode-mismatch', [x['code'] for x in result['issues']])

    def test_unproven_windows_dos_mode_cannot_claim_exact_git_parity(self):
        result = self.make_mode_zip(0, system=0)
        self.assertFalse(result['passed'], 'ZIP without permission metadata was accepted')
        self.assertIn('source-mode-mismatch', [x['code'] for x in result['issues']])

    def commit_virtual_files(self, entries):
        # Build Git index objects without creating Windows-invalid filenames
        # or case-colliding directories in the host working tree.
        for filename, data in entries:
            blob = subprocess.run(['git', '-C', str(self.repo), 'hash-object', '-w', '--stdin'],
                                  input=data, check=True, capture_output=True, timeout=15).stdout.decode().strip()
            subprocess.run(['git', '-C', str(self.repo), '-c', 'core.protectNTFS=false',
                            '-c', 'core.ignorecase=false', 'update-index', '--add',
                            '--cacheinfo', f'100644,{blob},{filename}'],
                           check=True, capture_output=True, timeout=15)
        tree = subprocess.check_output(['git', '-C', str(self.repo), 'write-tree']).decode().strip()
        commit = subprocess.check_output(['git', '-C', str(self.repo), 'commit-tree', tree,
                                          '-p', self.commit, '-m', 'virtual path fixture']).decode().strip()
        subprocess.run(['git', '-C', str(self.repo), 'update-ref', 'HEAD', commit],
                       check=True, capture_output=True, timeout=15)
        self.commit = commit
        return self.make_zip(self.good + entries)

    def make_committed_extra(self, filename, data=b'fixture\n'):
        return self.commit_virtual_files([(filename, data)])

    def test_windows_case_colliding_file_names(self):
        result = self.make_committed_extra('APP.js')
        self.assertFalse(result['passed'], 'Windows case-colliding paths were accepted')
        self.assertIn('windows-path-collision', [x['code'] for x in result['issues']])

    def test_windows_reserved_device_name(self):
        result = self.make_committed_extra('CON.txt')
        self.assertFalse(result['passed'], 'Windows device path was accepted')
        self.assertIn('windows-unsafe-path', [x['code'] for x in result['issues']])

    def test_windows_console_device_name(self):
        result = self.make_committed_extra('CONIN$.txt')
        self.assertFalse(result['passed'], 'Windows console device path was accepted')
        self.assertIn('windows-unsafe-path', [x['code'] for x in result['issues']])

    def test_windows_delete_control_character(self):
        result = self.make_committed_extra('notes\x7f.txt')
        self.assertFalse(result['passed'], 'Windows DEL control path was accepted')
        self.assertIn('windows-unsafe-path', [x['code'] for x in result['issues']])

    def test_windows_trailing_dot(self):
        result = self.make_committed_extra('notes.')
        self.assertFalse(result['passed'], 'Windows trailing-dot path was accepted')
        self.assertIn('windows-unsafe-path', [x['code'] for x in result['issues']])

    def test_windows_alternate_data_stream_colon(self):
        result = self.make_committed_extra('notes:stream')
        self.assertFalse(result['passed'], 'Windows alternate stream path was accepted')
        self.assertIn('windows-unsafe-path', [x['code'] for x in result['issues']])

    def test_windows_case_colliding_directory_prefix(self):
        # Distinct leaf files can still alias an intermediate directory on Windows.
        result = self.commit_virtual_files([('Src/a.txt', b'a'), ('src/b.txt', b'b')])
        self.assertFalse(result['passed'], 'Windows case-colliding directories were accepted')
        self.assertIn('windows-path-collision', [x['code'] for x in result['issues']])

    def test_directory_entry(self):
        result = self.make_zip(self.good + [('extra/', b'')])
        self.assertFalse(result['passed'])
        self.assertIn('directory-member', [x['code'] for x in result['issues']])

    def test_oversized_declared_file(self):
        original = zip_audit.MAX_FILE_BYTES
        try:
            zip_audit.MAX_FILE_BYTES = 2
            result = self.make_zip(self.good)
            self.assertFalse(result['passed'])
            self.assertIn('oversized-entry', [x['code'] for x in result['issues']])
        finally:
            zip_audit.MAX_FILE_BYTES = original

if __name__ == '__main__':
    unittest.main(verbosity=2)
