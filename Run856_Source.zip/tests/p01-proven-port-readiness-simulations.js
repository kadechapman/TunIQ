const assert = require('assert');
const fs = require('fs');
const path = require('path');
const { findLatestProvenPort, sessionProvesCommunication, proofFromSession, shouldReuseProof, validateProvenPortBinding, reconcileProvenHardwareState } = require('../src/p01-proven-port');
const { buildBetaProgress } = require('../src/beta-progress');

function runP01ProvenPortReadinessSimulations({ quiet = false } = {}) {
  const projectId = 'p01-service';
  const p01 = { identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' } };
  const history = [
    { id: 'failed-read', projectId, operation: 'read', state: 'failed', device: 'COM3' },
    { id: 'other-project', projectId: 'other', operation: 'readProperties', state: 'complete', device: 'COM8', identity: { controller: 'P01', os: '9373372' } },
    { id: 'properties-ok', projectId, operation: 'readProperties', state: 'complete', device: 'COM4', completedAt: '2026-08-04T00:00:00Z', identity: { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' } }
  ];
  const recovered = findLatestProvenPort({ history, projectId, p01, state: {} });
  assert.equal(recovered.port, 'COM4');
  assert.equal(recovered.sessionId, 'properties-ok');

  const current = findLatestProvenPort({ history, projectId, p01, state: { pcmHammerProvenPort: 'COM6', pcmHammerProvenAt: 'now', provenHardwareSession: { port: 'COM6', projectId, controller: 'P01', os: '9373372', operation: 'readProperties', source: 'guided-state' } } });
  assert.equal(current.port, 'COM4', 'unbacked saved COM6 proof must not outrank actual COM4 history');
  assert.equal(findLatestProvenPort({ history: [], projectId, p01, state: { provenHardwareSession: { port: 'COM6', projectId, controller: 'P01', os: '9373372', operation: 'readProperties' } } }), null, 'a fabricated saved proof without history cannot prove communication');
  const backed = findLatestProvenPort({ history, projectId, p01, state: { provenHardwareSession: { ...recovered } } });
  assert.equal(backed.source, 'guided-state-validated-against-history', 'matching saved proof may be reused only with historical provenance');
  const forgedId = findLatestProvenPort({ history, projectId, p01, state: { provenHardwareSession: { ...recovered, sessionId: 'not-in-history' } } });
  assert.equal(forgedId.sessionId, 'properties-ok');
  assert.equal(forgedId.source, 'flash-history', 'forged session ID must be ignored');
  const forgedLineage = findLatestProvenPort({ history, projectId, p01, state: { provenHardwareSession: { ...recovered, identitySourceSessionId: 'other-session' } } });
  assert.equal(forgedLineage.source, 'flash-history', 'forged identity provenance must be ignored');

  // A same-OS P01 replacement on COM4 must not inherit the earlier ECU's
  // successful connection, even if the saved project and port are unchanged.
  const conflictingHardware = { ...history[2], id: 'different-hardware',
    identity: { ...history[2].identity, hardwareId: 'OTHER-HW' } };
  const conflictingService = { ...history[2], id: 'different-service',
    identity: { ...history[2].identity, serviceNumber: 'OTHER-SERVICE' } };
  assert.equal(sessionProvesCommunication(conflictingHardware, { projectId, p01 }), false,
    'a P01 with the same OS but a different hardware ID must not prove this project');
  assert.equal(sessionProvesCommunication(conflictingService, { projectId, p01 }), false,
    'a P01 with the same OS but a different service number must not prove this project');
  assert.equal(findLatestProvenPort({ history: [conflictingHardware, ...history], projectId, p01 }), null,
    'a newer conflicting identity must invalidate older COM4 proof');
  assert.equal(findLatestProvenPort({ history: [conflictingService, ...history], projectId, p01 }), null,
    'a newer conflicting service number must invalidate older COM4 proof');
  const conflictingRead = { id: 'read-from-other-ecu', projectId, operation: 'read',
    state: 'complete', device: 'COM4', outputValidation: { valid: true },
    identity: { controller: 'P01', os: '9373372', hardwareId: 'OTHER-HW' } };
  assert.equal(findLatestProvenPort({ history: [conflictingRead, ...history], projectId, p01 }), null,
    'a newer successful read identifying different hardware must invalidate old proof');
  assert.equal(findLatestProvenPort({ history: [{ ...history[2], id: 'fresh-good' }, conflictingHardware, ...history], projectId, p01 }).sessionId,
    'fresh-good', 'a later valid identity read may re-establish proof after a conflict');

  // A newer failed/cancelled Read Properties is a new ECU-identity attempt,
  // not permission to silently reuse an older connection. A disconnected or
  // replaced ECU can share the same COM port. Full Read must wait for a fresh
  // successful Read Properties after the unsuccessful attempt.
  for (const terminalState of ['failed', 'cancelled', 'complete-unverified']) {
    const latestAttempt = { ...history[2], id: `new-${terminalState}-properties`, state: terminalState };
    assert.equal(findLatestProvenPort({ history: [latestAttempt, ...history], projectId, p01 }), null,
      `a newer ${terminalState} Read Properties must revoke older COM authority`);
    assert.equal(findLatestProvenPort({ history: [{ ...history[2], id: 'fresh-after-failure' }, latestAttempt, ...history], projectId, p01 }).sessionId,
      'fresh-after-failure', 'a fresh valid identity check may re-establish COM authority');
    assert.equal(findLatestProvenPort({ history: [{ ...latestAttempt, projectId: 'other-project' }, ...history], projectId, p01 }).sessionId,
      'properties-ok', "another project's failed identity check must not revoke this project");
  }
  assert.equal(findLatestProvenPort({ history: [{ ...history[2], id: 'failed-read-irrelevant', operation: 'read', state: 'failed' }, ...history], projectId, p01 }).sessionId,
    'properties-ok', 'a failed Full Read must retain earlier identity evidence for safe recovery');
  // Beta.29 regression: an in-flight identity recheck must suspend stale proof
  // immediately; a later Full Read cannot borrow identity across a failed check.
  for (const state of ['running', 'queued', 'starting', 'unknown']) {
    const inFlight = { ...history[2], id: `new-${state}-properties`, state };
    assert.equal(findLatestProvenPort({ history: [inFlight, ...history], projectId, p01 }), null,
      `an ${state} Read Properties must suspend older COM authority`);
  }
  const failedRecheck = { ...history[2], id: 'failed-recheck-before-read', state: 'failed' };
  const readAfterFailure = { id: 'read-after-failed-recheck', projectId, operation: 'read', state: 'complete',
    device: 'COM4', outputValidation: { valid: true }, identity: {} };
  assert.equal(findLatestProvenPort({ history: [readAfterFailure, failedRecheck, ...history], projectId, p01 }), null,
    'a Full Read after failed identity recheck cannot inherit older identity');
  assert.equal(findLatestProvenPort({ history: [
    { ...history[2], id: 'fresh-after-failed-recheck' }, readAfterFailure, failedRecheck, ...history
  ], projectId, p01 }).sessionId, 'fresh-after-failed-recheck',
    'new Read Properties restores proof after interrupted identity lineage');


  assert.equal(sessionProvesCommunication({ projectId, operation: 'read', state: 'complete', device: 'COM4', outputValidation: { valid: true } }, { projectId, p01 }), true);
  assert.equal(sessionProvesCommunication({ projectId, operation: 'read', state: 'complete', device: 'COM4', outputValidation: { valid: false } }, { projectId, p01 }), false);
  assert.equal(sessionProvesCommunication({ projectId, operation: 'read', state: 'complete', device: 'COM4' }, { projectId, p01 }), false, 'a missing full-read validation cannot prove hardware');
  assert.equal(sessionProvesCommunication({ projectId, operation: 'testWrite', state: 'complete', device: 'COM4' }, { projectId, p01 }), false, 'a Test Write needs an explicit pass');
  assert.equal(sessionProvesCommunication({ projectId, operation: 'testWrite', state: 'complete', device: 'COM4', testWritePassed: true }, { projectId, p01 }), true);
  assert.equal(sessionProvesCommunication({ projectId, operation: 'readProperties', state: 'complete-unverified', device: 'COM4', identity: { controller: 'P01', os: '9373372' } }, { projectId, p01 }), false);
  assert.equal(proofFromSession({ ...history[2], identity: { controller: 'P01', os: '' } }), null, 'incomplete Read Properties cannot be promoted');
  const priorProof = proofFromSession(history[2]);
  assert.equal(priorProof.identitySourceSessionId, 'properties-ok');
  const readSession = { id: 'read-ok', projectId, operation: 'read', state: 'complete', device: 'COM4', outputValidation: { valid: true }, identity: {} };
  const inherited = proofFromSession(readSession, 'live-pcmhammer-success', priorProof);
  assert.equal(inherited.os, '9373372', 'successful full read must retain exact prior OS identity');
  assert.equal(inherited.identitySourceSessionId, 'properties-ok', 'retained identity provenance must remain traceable');
  assert.equal(inherited.sessionId, 'read-ok');
  assert.equal(proofFromSession(readSession, 'live-pcmhammer-success', null), null, 'a read cannot invent OS identity');
  assert.equal(proofFromSession({ ...readSession, device: 'COM3' }, 'live-pcmhammer-success', priorProof), null, 'never inherit identity across ports');
  assert.equal(proofFromSession({ ...readSession, projectId: 'another-project' }, 'live-pcmhammer-success', priorProof), null, 'never inherit identity across projects');
  assert.equal(proofFromSession({ ...readSession, identity: { os: '9379910' } }, 'live-pcmhammer-success', priorProof), null, 'conflicting OSID must fail closed');
  assert.equal(proofFromSession({ ...readSession, outputValidation: { valid: false } }, 'live-pcmhammer-success', priorProof), null, 'failed read must never promote proof');
  const recoveredRead = findLatestProvenPort({ history: [readSession, ...history], projectId, p01 });
  assert.equal(recoveredRead.sessionId, 'read-ok', 'restart should preserve verified read with original identity provenance');
  assert.equal(recoveredRead.identitySourceSessionId, 'properties-ok');
  const olderSaved = findLatestProvenPort({ history: [readSession, ...history], projectId, p01,
    state: { provenHardwareSession: { ...priorProof } } });
  assert.equal(olderSaved.sessionId, 'read-ok', 'a stale saved Read Properties session must not override a newer verified Full Read');
  const malformedState = findLatestProvenPort({ history, projectId, p01, state: { provenHardwareSession: { port: 'COM6', projectId, os: '9373372' } } });
  assert.equal(malformedState.port, 'COM4', 'incomplete guided proof must not hide valid historical Read Properties');

  const validProof = { port: 'COM4', projectId, controller: 'P01', os: '9373372', operation: 'readProperties' };
  const bound = proof => validateProvenPortBinding({ proof, port: 'COM4', project: { id: projectId, controller: 'P01', os: '9373372' } });
  assert.equal(bound(validProof).valid, true);
  for (const [field, value, reason] of [
    ['port', 'COM3', 'port-mismatch'],
    ['projectId', 'other', 'project-mismatch'],
    ['controller', 'P59', 'controller-mismatch'],
    ['os', '9379910', 'os-mismatch'],
    ['operation', 'failed', 'operation-not-proven']
  ]) assert.equal(bound({ ...validProof, [field]: value }).reason, reason);
  assert.equal(bound(null).reason, 'missing-proof');
  assert.equal(validateProvenPortBinding({ proof: { ...validProof, hardwareId: 'OTHER-HW' },
    port: 'COM4', project: { id: projectId, controller: 'P01', os: '9373372', hardwareId: '9386530' } }).reason,
    'hardwareId-mismatch', 'direct COM reuse must reject a conflicting known hardware ID');
  assert.equal(validateProvenPortBinding({ proof: { ...validProof, serviceNumber: 'OTHER-SERVICE' },
    port: 'COM4', project: { id: projectId, controller: 'P01', os: '9373372', serviceNumber: '12200411' } }).reason,
    'serviceNumber-mismatch', 'direct COM reuse must reject a conflicting known service number');
  assert.equal(bound({ ...validProof, os: '' }).valid, false);
  assert.equal(bound({ ...validProof, projectId: '' }).valid, false);
  assert.equal(validateProvenPortBinding({ proof: validProof, port: 'COM4', project: { id: projectId, controller: '', os: '9373372' } }).valid, false);
  assert.equal(validateProvenPortBinding({ proof: validProof, port: 'COM4', project: { id: projectId, controller: 'P01', os: '' } }).valid, false, 'unknown active OS must not qualify for authoritative port reuse');
  // A different active project or changed OS cannot inherit a previous ECU's proven COM lane.
  assert.equal(validateProvenPortBinding({ proof: validProof, port: 'COM4', project: { id: projectId, controller: 'P01', os: '9379910' } }).valid, false);
  assert.equal(shouldReuseProof('read', recovered), true);
  assert.equal(shouldReuseProof('testWrite', recovered), true);
  assert.equal(shouldReuseProof('writeCalibration', recovered), false);

  // Regression: beta.27 returned the old guided-state claim unchanged when a
  // newer completed Read Properties session identified different hardware.
  const oldIdentity = { controller: 'P01', os: '9373372', hardwareId: '9386530', serviceNumber: '12200411' };
  const goodSession = { id: 'old-proof', projectId, operation: 'readProperties', state: 'complete',
    device: 'COM4', completedAt: '2026-10-15T15:00:00Z', identity: oldIdentity };
  const oldProof = proofFromSession(goodSession);
  const staleState = { device: 'COM4', pcmHammerProvenPort: 'COM4',
    pcmHammerProvenAt: oldProof.provenAt, pcmHammerProvenOperation: oldProof.operation,
    provenHardwareSession: oldProof };
  const conflicting = { ...goodSession, id: 'new-other-hardware',
    completedAt: '2026-10-15T15:10:00Z', identity: { ...oldIdentity, hardwareId: 'OTHER-ECU' } };
  const invalidated = findLatestProvenPort({ history: [conflicting, goodSession], projectId,
    p01: { identity: oldIdentity }, state: staleState });
  assert.equal(invalidated, null, 'newer conflicting ECU must invalidate older session history');
  const revoked = reconcileProvenHardwareState(staleState, invalidated);
  assert.equal(reconcileProvenHardwareState({ device: 'COM4' }, null).changed, false,
    'a new setup with no historical proof must not generate a false revocation warning');
  assert.equal(revoked.changed, true);
  assert.equal(revoked.cleared, true);
  assert.equal(revoked.patch.provenHardwareSession, null);
  assert.equal(revoked.patch.pcmHammerProvenPort, '');
  assert.equal(revoked.patch.pcmHammerProvenAt, null);
  assert.equal(revoked.patch.pcmHammerProvenOperation, null);
  assert.equal(revoked.patch.device, undefined, 'selected COM remains for fresh Read Properties');
  assert.equal(reconcileProvenHardwareState({ ...staleState, ...revoked.patch }, null).changed, false,
    'revocation must be idempotent and not create repeated warning records');
  const newProof = proofFromSession({ ...goodSession, id: 'later-valid', completedAt: '2026-10-15T15:20:00Z' });
  const reproof = reconcileProvenHardwareState(staleState, newProof);
  assert.equal(reproof.changed, true, 'new session identity must replace an older claim on the same COM');
  assert.equal(reproof.patch.provenHardwareSession.sessionId, 'later-valid');
  assert.equal(reconcileProvenHardwareState({ ...staleState, ...reproof.patch }, newProof).changed, false,
    'reconciliation of matching proof must be idempotent');

  const progress = buildBetaProgress({
    version: '1.9.0-beta.15',
    activeProject: { id: projectId, controller: 'P01', os: '9373372' },
    p01: { ...p01, readPair: { first: { sha256: 'a' } }, dualReadVerified: false, definition: null, testWrite: null },
    flash: { configured: true, integrated: true, lastSuccessfulDevice: 'COM4', lastSuccessfulOperation: 'readProperties' },
    knowledge: { mode: { mode: 'recommend' }, incidentClusterCount: 4, verifiedIncidentCount: 1, projectCount: 2, repairCount: 1 },
    beta: { agreementAccepted: true, queueCount: 0, preferences: { improvementOptIn: false } }
  });
  assert(progress.overall > 0 && progress.overall < 100);
  assert.equal(progress.areas.length, 6);
  assert(progress.nextPriorities.length > 0);
  assert(progress.areas.find(item => item.id === 'p01-commissioning').next.includes('second independent matching read'));

  const root = path.join(__dirname, '..');
  const main = fs.readFileSync(path.join(root, 'src', 'main.js'), 'utf8');
  const html = fs.readFileSync(path.join(root, 'src', 'renderer', 'index.html'), 'utf8');
  const renderer = fs.readFileSync(path.join(root, 'src', 'renderer', 'app.js'), 'utf8');
  assert(main.includes('recoverP01ProvenHardwareSession'));
  assert(main.includes('const reconciliation = reconcileProvenHardwareState(state, proof);'),
    'startup recovery must revoke stale authority instead of returning it unchanged');
  assert(main.includes('state = recoverP01ProvenHardwareSession(state, { persist: false });'),
    'every P01 hardware payload must revalidate authority against session history');
  assert(!main.includes('if (!proof) return state;'),
    'a missing valid history record must clear persisted COM authority');
  assert(!main.includes('legacy-successful-operation-recovery'), 'global last-successful COM port must never fabricate per-project proof');
  assert(main.includes('releaseVirtualAdapterBeforeP01Operation'));
  assert(main.includes('does not rescan alternate COM ports'));
  assert(main.includes('authoritativeProvenPort: pcmHammerProven'));
  assert(main.includes('provenHardwareSession'));
  assert(html.includes('id="betaOverallProgress"'));
  assert(html.includes('id="betaProgressGrid"'));
  assert(renderer.includes('function renderBetaProgress'));

  if (!quiet) console.log('✓ P01 proven-port continuity and beta readiness simulations: 9/9 passed');
  return { passed: true, scenarios: 9, overall: progress.overall };
}

if (require.main === module) runP01ProvenPortReadinessSimulations();
module.exports = { runP01ProvenPortReadinessSimulations };
