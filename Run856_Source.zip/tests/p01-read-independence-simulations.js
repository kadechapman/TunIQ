'use strict';
// Filesystem-only tests; never opens a COM port, launches PCM Hammer, or writes an ECU.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');
function runP01ReadIndependenceSimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-independence-'));
  let passed = 0;
  try {
    const active = { id: 'read-independence', name: 'Read proof fixture', controller: 'P01', os: '9379910', folder };
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'fixture-hw', serviceNumber: 'fixture-svc' });
    const dir = path.join(folder, 'Imports', 'PCM-Hammer'); fs.mkdirSync(dir, { recursive: true });
    const first = path.join(dir, 'P01-Read-session-a-p01_origin_read1.bin');
    const second = path.join(dir, 'P01-Read-session-b-p01_origin_read2.bin');
    const data = Buffer.alloc(P01_BIN_SIZE, 0x55);
    fs.writeFileSync(first, data); fs.writeFileSync(second, data);
    const unproven = manager.repairVerifiedReadPair('two unproven disk files');
    assert.equal(unproven.repaired, false, 'disk-only copied BINs must not self-certify as two ECU reads');
    assert.equal(manager.status().dualReadVerified, false); passed++;
    manager.recordRead(first, {}, { id: 'recorded-session-1', device: 'COM3', proofSource: 'session-1' });
    const oneRecorded = manager.load(); oneRecorded.readPair = null; manager.save(oneRecorded);
    const mixed = manager.repairVerifiedReadPair('one recorded and one disk-only');
    assert.equal(mixed.repaired, false, 'one ledger entry plus a copied BIN cannot form a verified pair'); passed++;
    manager.beginFreshReadPair('same file regression');
    manager.recordRead(first, {}, { id: 'first-session', device: 'COM3' });
    assert.throws(() => manager.recordRead(first, {}, { id: 'second-session', device: 'COM3' }), /different|independent|same file/i);
    assert.equal(manager.status().dualReadVerified, false); passed++;
    const alias = path.join(dir, 'P01-Read-hardlinked-copy.bin'); fs.linkSync(first, alias);
    manager.beginFreshReadPair('hardlink regression');
    assert.throws(() => manager.recordRead(first, {}, { id: 'hardlink-session-1', device: 'COM3' }), /link|alias|regular/i,
      'a multiply-linked first read must fail before it enters the ledger');
    assert.throws(() => manager.recordRead(alias, {}, { id: 'hardlink-session-2', device: 'COM3' }), /link|alias|regular/i);
    assert.equal(manager.status().dualReadVerified, false); passed++;
    fs.unlinkSync(alias);
    manager.beginFreshReadPair('first file replaced');
    manager.recordRead(first, {}, { id: 'fresh-session-1', device: 'COM3' });
    fs.writeFileSync(first, Buffer.alloc(P01_BIN_SIZE, 0x33));
    assert.throws(() => manager.recordRead(second, {}, { id: 'fresh-session-2', device: 'COM3' }), /first|changed|integrity|digest/i);
    assert.equal(manager.status().dualReadVerified, false); passed++;
    fs.writeFileSync(first, data);
    manager.beginFreshReadPair('two recorded reads');
    manager.recordRead(first, {}, { id: 'proven-session-1', device: 'COM3', proofSource: 'session-1' });
    manager.recordRead(second, {}, { id: 'proven-session-2', device: 'COM3', proofSource: 'session-2' });
    assert.equal(manager.status().dualReadVerified, true); passed++;
    const damaged = manager.load(); damaged.readPair = null; delete damaged.canonicalReadSha256;
    delete damaged.canonicalReadPath; delete damaged.dualReadVerifiedAt; manager.save(damaged);
    const repaired = manager.repairVerifiedReadPair('saved ledger repair');
    assert.equal(repaired.repaired, true); assert.equal(repaired.status.dualReadVerified, true); passed++;
    console.log(`✓ P01 read independence: ${passed} filesystem-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) runP01ReadIndependenceSimulations();
module.exports = { runP01ReadIndependenceSimulations };
