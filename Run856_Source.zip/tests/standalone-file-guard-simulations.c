/* Portable Win32 file-attribute admission tests; not native Windows. */
#include <stdio.h>
#include "../tools/windows-standalone-file-guard.h"
static int cases=0;
static int check(unsigned long attributes, unsigned long links,
                 unsigned long high, unsigned long low, int expected) {
  tuniq_win_file_info info={0};
  info.dwFileAttributes=attributes;
  info.nNumberOfLinks=links;
  info.nFileSizeHigh=high;
  info.nFileSizeLow=low;
  int actual=tuniq_preview_fresh_regular_file(&info);
  cases++;
  if(actual!=expected) {
    fprintf(stderr,"FAIL file guard case %d (expected %d, got %d)\n",cases,expected,actual);
    return 1;
  }
  return 0;
}
int main(void) {
  int failures=0;
  failures+=check(0x80,1,0,0,1); /* FILE_ATTRIBUTE_NORMAL */
  failures+=check(0x20,1,0,0,1); /* FILE_ATTRIBUTE_ARCHIVE */
  failures+=check(0x400,1,0,0,0); /* final-component symlink */
  failures+=check(0x420,1,0,0,0); /* reparse point + archive */
  failures+=check(0x10,1,0,0,0); /* directory */
  failures+=check(0x410,1,0,0,0); /* directory reparse point */
  failures+=check(0x80,2,0,0,0); /* hardlink alias */
  failures+=check(0x80,0,0,0,0); /* invalid link count */
  failures+=check(0x80,1,1,0,0); /* existing large content */
  failures+=check(0x80,1,0,1,0); /* existing content */
  cases++;
  if(tuniq_preview_fresh_regular_file(0)) failures++;
  if(failures) return 1;
  printf("STANDALONE_FILE_GUARD_PORTABLE_FIXTURES %d/%d PASS (NOT native Windows)\n",cases,cases);
  return 0;
}
