'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.join(__dirname, '..');
function runBlankIntakePhoneLogSimulations({quiet=false}={}) {
  const html=fs.readFileSync(path.join(root,'src/renderer/index.html'),'utf8');
  const renderer=fs.readFileSync(path.join(root,'src/renderer/app.js'),'utf8');
  const checks=[];
  for(const id of ['quickServiceRequest','p01AutoRequest','projectNotes','aiBuildNotes']){
    const match=html.match(new RegExp(`<textarea\\b[^>]*id="${id}"[^>]*>([\\s\\S]*?)<\\/textarea>`));
    assert(match,`${id} field must exist`);
    assert.equal(match[1].trim(),'',`${id} should have no default text`); // normalize below
    checks.push(`empty ${id}`);
  }
  assert(renderer.includes("$('#projectNotes').value='';"),'new project paths should not insert example notes');
  assert(!renderer.includes('const legacyEngine=intake?.engine||garageVehicle?.engine'),'new AI intake must not silently borrow an engine from a different saved context');
  checks.push('new project notes and AI engine blank by default');
  const web=fs.readFileSync(path.join(root,'web/app.js'),'utf8');
  const elements=new Map();
  const element=id=>{if(!elements.has(id))elements.set(id,{value:id==='profile'?'baseline':'',disabled:false,classList:{add(){},remove(){}},addEventListener(){},scrollIntoView(){}});return elements.get(id)};
  const ctx=vm.createContext({document:{getElementById:element},setTimeout(){},URL:{},Blob:class{}});
  vm.runInContext(web+'\nthis.testParse = parse;',ctx,{timeout:3000});
  const empty=ctx.testParse('Time,RPM,Speed,VIN\n00:01,,,ABC123\n00:02,,,ABC124');
  assert.equal(empty.rows.length,0,'empty phone sensor values must not be accepted as zero readings');
  assert(empty.privateRemoved.includes('VIN'),'private VIN column should be excluded');
  const valid=ctx.testParse('Time,RPM,Speed\n00:01,0,0\n00:02,800,10');
  assert.equal(valid.rows.length,2,'actual numeric zero must remain valid');
  assert.equal(valid.rows[0].rpm,0);
  checks.push('phone log empty-vs-zero rows, VIN privacy');
  if(!quiet)console.log(`PASS ${checks.length} blank-intake/phone-log checks: ${checks.join('; ')}`);
  return {passed:true,checks};
}
if(require.main===module)try{runBlankIntakePhoneLogSimulations()}catch(e){console.error(e.stack||e);process.exitCode=1}
module.exports={runBlankIntakePhoneLogSimulations};
