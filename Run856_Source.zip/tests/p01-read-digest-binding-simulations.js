'use strict';
// Filesystem-only verification: no adapter, PCM Hammer launch, ECU write or flash.
const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function digest(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function runP01ReadDigestBindingSimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-digest-binding-'));
  let passed = 0;
  try {
    const active = { id: 'digest-fixture', name: 'Digest fixture', controller: 'P01', folder };
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'test-id', serviceNumber: 'test-service' });
    const file = path.join(folder, 'read.bin');
    const original = Buffer.alloc(P01_BIN_SIZE, 0x51);
    const replacement = Buffer.alloc(P01_BIN_SIZE, 0x52);
    fs.writeFileSync(file, original);
    const verified = { size: original.length, sha256: digest(original) };
    fs.writeFileSync(file, replacement); // Simulate replacement after earlier validation.
    assert.throws(() => manager.recordRead(file, verified, { id: 'replaced-read', device: 'COM4' }),
      /digest|sha.?256|changed|mismatch/i, 'a same-size substituted read must not be recorded');
    assert.equal(manager.load().reads.length, 0, 'rejected read must not enter the commissioning ledger'); passed++;
    fs.writeFileSync(file, original);
    assert.throws(() => manager.recordRead(file, { ...verified, size: 123 }, { id: 'wrong-size' }),
      /size|changed|mismatch/i, 'claimed size must match the current file');
    assert.equal(manager.load().reads.length, 0); passed++;
    assert.throws(() => manager.recordRead(file, { ...verified, sha256: 'invalid' }, { id: 'bad-hash' }),
      /sha.?256|digest|invalid/i, 'malformed digest proof must fail closed');
    assert.equal(manager.load().reads.length, 0); passed++;
    const accepted = manager.recordRead(file, verified, { id: 'good-read', device: 'COM4' });
    assert(accepted && manager.load().reads.length === 1, 'unchanged verified read must remain accepted');
    assert.equal(manager.load().reads[0].sha256, verified.sha256); passed++;
    console.log(`✓ P01 read digest binding: ${passed} filesystem-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) runP01ReadDigestBindingSimulations();
module.exports = { runP01ReadDigestBindingSimulations };
