'use strict';
// Static workflow contract only; cannot claim a Windows runner actually ran.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '..', '.github', 'workflows',
  'windows-offline-preview-build.yml'), 'utf8');
let checks = 0;
const check = (name, predicate) => { assert(predicate, name); checks++; };
check('Windows runner', source.includes('runs-on: windows-latest'));
check('Manual and development branch trigger', source.includes('workflow_dispatch:') &&
  source.includes("- 'dev/**'"));
check('No write permission', source.includes('permissions:\n  contents: read'));
check('No retained checkout credentials', source.includes('persist-credentials: false'));
check('Bounded job', source.includes('timeout-minutes: 90'));
check('Actual preview build script', source.includes('windows-build-offline-preview.ps1'));
check('Preview stage hashes and package allowlist verified before native smoke and packaging', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  const first = build.indexOf("Step 'Verify staged preview file hashes and allowlist'");
  const smoke = build.indexOf("Launch staged preview in real Electron");
  const second = build.indexOf("Step 'Reverify staged preview before packaging'");
  const pack = build.indexOf("Step 'Package hardware-free preview only (NO installer)'");
  return first >= 0 && first < smoke && second > smoke && second < pack &&
    (build.match(/'tools\/stage-readonly-preview\.js','--verify',\$stage/g) || []).length === 2;
})());

check('Must verify outcome and four native smoke proofs',
  ['build-outcome.json','renderer-runtime-evidence.json','staged-smoke-evidence.json','packaged-smoke-evidence.json','delivered-smoke-evidence.json',
    'windowsRuntimeVerified -ne $true','hardwareUsed -ne $false',
    'fullTunIQVerified -ne $false'].every(x=>source.includes(x)));
check('Native renderer proof must show actual Electron runtime',
  source.includes('tuniq-isolated-renderer-runtime-smoke') && source.includes('actualElectronRuntime -ne $true'));
check('Native renderer fields must be checked by CI and Windows builder', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return ['nativeWindowsElectronVerified -ne $true', 'rendererSnapshotValidated -ne $true',
    'primaryNavigationVerified -ne $true', 'observedPrimaryPageCount -ne 9',
    'runtimeBlockerCount -ne 0', 'snapshotBlockerCount -ne 0'].every(field =>
      source.includes('$renderer.' + field) && build.includes('$rendererProof.' + field));
})());
check('Runtime and preview smoke nonces must be distinct',
  source.includes('Sort-Object -Unique') && source.includes('$smokeNonces') && source.includes('-ne 4'));
check('Must verify an actual preview executable',
  source.includes('TunIQ Offline UI Preview.exe') && source.includes('$executables.Count -ne 1'));
// The user downloads an Actions artifact, not the original smoke-tested
// directory. Require a single ZIP that is extracted and independently checked
// against the delivered-tree proof before any downloadable artifact is posted.
check('Download ZIP is created only after native evidence review', (() => {
  const review = source.indexOf('Independent delivered Windows evidence review failed.');
  const packageStep = source.indexOf('name: Package and verify downloadable Windows preview ZIP');
  const uploadStep = source.indexOf('name: Preserve verified downloadable Windows preview ZIP');
  return review >= 0 && packageStep > review && uploadStep > packageStep;
})());
check('Download ZIP is round-trip extracted and verified against native delivered tree',
  source.includes('ZipFile]::CreateFromDirectory') &&
  source.includes('Expand-Archive -LiteralPath $zip') &&
  source.includes("windows-preview-tree-integrity.js --verify $unpacked (Join-Path $folder 'delivered-preview-tree-integrity.json')") &&
  source.includes('Download ZIP does not match smoke-tested delivered tree.'));
check('Only verified ZIP and SHA-256 are uploaded for a bounded 90 days',
  /name: Preserve verified downloadable Windows preview ZIP\s+if: success\(\)/.test(source) &&
  source.includes('path: dev-build-output/verified-download/') &&
  source.includes('retention-days: 90') &&
  source.includes('Run_Windows_x64_Offline_UI_Preview.zip') &&
  source.includes('Run_Windows_x64_Offline_UI_Preview.sha256'));
check('Failure classification runs even on CI failure',
  /name: Publish safe build-failure classification\s+if: always\(\)/.test(source) &&
  source.includes('diagnose-windows-preview.js') && source.includes('GITHUB_STEP_SUMMARY'));
check('Failure diagnostics are always retained',
  /name: Preserve Windows build diagnostics, including on failure\s+if: always\(\)/.test(source));
check('Executable uploaded only after success',
  /name: Preserve verified downloadable Windows preview ZIP\s+if: success\(\)/.test(source));
check('Windows build enforces genuine lockfile generation', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return source.includes('windows-build-offline-preview.ps1') &&
    build.includes("'--package-lock=true','--save=true'") &&
    build.includes('npm returned success but did not write package-lock.json');
})());
check('Windows npm ci has bounded registry retries and timeout', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes("'npm.cmd' @('ci','--no-audit','--no-fund','--fetch-retries=0','--fetch-timeout=30000',$npmLogArg)");
})());
// The preview builder must bind the reviewed lock graph to the actual
// npm ci installation. A copied candidate alone cannot detect later edits.
check('Windows preview binds lockfile and package manifest across npm ci', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  const capture = build.indexOf("Step 'Capture preview dependency provenance'");
  const install = build.indexOf("Step 'Install locked Electron dependencies'");
  const verify = build.indexOf("Step 'Verify preview dependency provenance after npm ci'");
  return capture > build.indexOf("$candidate = Join-Path $diagnostics") &&
    capture < install && install < verify &&
    verify < build.indexOf("$suiteSource = Join-Path $env:TEMP") &&
    build.includes("'tools/windows-lockfile-provenance.js','--capture',$candidate,$provenanceReport") &&
    build.includes("'tools/windows-lockfile-provenance.js','--verify',$candidate,$provenanceReport");
})());
check('Installed lockfile is isolated from source-only offline suite', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes('$suiteSource = Join-Path $env:TEMP') &&
    build.includes("$suiteExcluded = @('node_modules','package-lock.json'") &&
    build.includes('Push-Location $suiteSource') &&
    build.includes("Step 'Complete offline simulated suite' 'npm.cmd' @('test')") &&
    build.includes('finally { Pop-Location }');
})());
check('Actual locked dependency installation precedes isolated offline suite', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.indexOf("Step 'Install locked Electron dependencies'") <
    build.indexOf("$suiteSource = Join-Path $env:TEMP") &&
    build.indexOf("$suiteSource = Join-Path $env:TEMP") <
    build.indexOf("Step 'Complete offline simulated suite'");
})());
check('Packaged executable integrity is checked independently by CI',
  source.includes('windows-pe-integrity.js --verify') &&
  source.includes('packaged-executable-integrity.json') &&
  source.includes('Packaged Windows PE integrity failed.'));
check('Windows build writes image SHA-256 after packaging', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes('windows-pe-integrity.js') &&
    build.includes('packaged-executable-integrity.json') &&
    build.includes('Record packaged Windows PE integrity');
})());
check('Delivered executable is byte-bound to smoke-tested package', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes('Get-FileHash -LiteralPath $exe -Algorithm SHA256') &&
    build.includes('Get-FileHash -LiteralPath $deliveredExe -Algorithm SHA256') &&
    build.includes('$packagedHash -ne $deliveredHash');
})());
check('Actual copied output must start with fresh smoke evidence', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes('Start-Process -FilePath $deliveredExe') &&
    build.includes('delivered-smoke-evidence.json') &&
    build.includes('$deliveredProof.nonce -ne $deliveredNonce') &&
    source.includes('delivered-smoke-evidence.json');
})());
check('Packaged and delivered preview trees are compared before approval', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  const reviewer = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-preview-evidence-review.js'), 'utf8');
  return build.includes("Step 'Record smoke-tested packaged preview tree'") &&
    build.includes("Step 'Verify delivered copy against packaged preview tree'") &&
    build.indexOf("Step 'Record smoke-tested packaged preview tree'") < build.indexOf('Copy-Item -LiteralPath (Join-Path $stage') &&
    build.indexOf("Step 'Verify delivered copy against packaged preview tree'") < build.indexOf("$script:currentStep = 'Delivered Windows executable smoke'") &&
    source.includes('packaged-preview-tree-integrity.json') &&
    source.includes('Packaged-to-delivered Windows preview tree mismatch.') &&
    reviewer.includes("verifyTreeEvidence(path.dirname(executable), path.join(diagnostics, 'packaged-preview-tree-integrity.json'))");
})());
check('Complete delivered preview tree integrity is checked by CI',
  source.includes('windows-preview-tree-integrity.js --verify') &&
  source.includes('delivered-preview-tree-integrity.json') &&
  source.includes('Delivered Windows preview tree integrity failed.'));
check('Windows build records delivered tree integrity after actual native smoke', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  return build.includes('windows-preview-tree-integrity.js') &&
    build.includes('delivered-preview-tree-integrity.json') &&
    build.indexOf('Record delivered preview tree integrity') > build.indexOf('Delivered Windows executable smoke');
})());
check('Independent delivered-executable evidence reviewer is mandatory',
  source.includes('windows-preview-evidence-review.js $folder $executables[0].FullName') &&
  source.includes('Independent delivered Windows evidence review failed.'));
check('Build outcome binds exact delivered output to diagnostic run', (() => {
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  const reviewer = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-preview-evidence-review.js'), 'utf8');
  return build.includes('diagnosticsRun = Split-Path $diagnostics -Leaf') &&
    build.includes('deliveredPreviewDirectory = $script:deliveredPreviewDirectory') &&
    reviewer.includes('verifyBuildProvenance(diagnostics, executable)');
})());
check('No production install or ECU actions',
  !/(npm (?:start|run dist:win)|electron-builder|pcmhammer\.exe|src\/main\.js\s*\)|\bTest-Write\b|\bflash\s+ecu\b)/i.test(source));
console.log(`Windows preview CI workflow static regressions: ${checks}/${checks} passed (source-only).`);
