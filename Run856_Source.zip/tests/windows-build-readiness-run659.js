'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
function check(name, version, expected) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq659-'));
  try {
    fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({name,version}));
    fs.writeFileSync(path.join(dir, 'package-lock.json'), JSON.stringify({lockfileVersion:3,packages:{'':{name,version}}}));
    const result = assess(dir);
    assert.strictEqual(result.blockers.includes('package-json-identity-invalid'), expected);
    assert.strictEqual(result.ecmWriteAuthorized, false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
  } finally { fs.rmSync(dir, {recursive:true,force:true}); }
}
for (const [name,version] of [[null,'1.0.0'],['','1.0.0'],['  ','1.0.0'],[42,'1.0.0'],['tuniq',null],['tuniq',''],['tuniq','  '],['tuniq',1]]) check(name,version,true);
check('tuniq','1.0.0',false);
console.log('Run659: 9 identity fixtures passed');
