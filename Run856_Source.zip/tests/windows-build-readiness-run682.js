'use strict';
const assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const {assess}=require('../tools/windows-build-readiness-run647');
const cases=[
 ['CONIN dollar','../packages/CONIN$',true],
 ['CONOUT dollar mixed case','../packages/conout$.txt',true],
 ['CONIN Windows slash','..\\packages\\CONIN$',true],
 ['CONOUT Windows slash','..\\packages\\CONOUT$',true],
 ['normal CONINPUT','../packages/CONINPUT',false],
 ['normal CONOUTER','../packages/CONOUTER',false],
 ['COM superscript two extension','../packages/com².txt',true],
 ['COM superscript three Windows','..\\packages\\COM³',true],
 ['LPT superscript one','../packages/LPT¹',true],
 ['LPT superscript two extension','../packages/lpt².txt',true],
 ['LPT superscript three Windows','..\\packages\\LPT³',true],
 ['normal COM10','../packages/COM10',false],
 ['normal LPT0','../packages/LPT0',false],
 ['normal workspace','../packages/foo',false]
];
for(const [label,resolved,blocked] of cases){
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'tuniq682-'));
 try {
  const deps={foo:'file:packages/foo'};
  fs.writeFileSync(path.join(root,'package.json'),JSON.stringify({name:'tuniq',version:'1.0.0',dependencies:deps}));
  fs.writeFileSync(path.join(root,'package-lock.json'),JSON.stringify({lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:deps},'node_modules/foo':{link:true,resolved}}}));
  const r=assess(root);
  assert.strictEqual(r.blockers.includes('package-lock-link-metadata-invalid'),blocked,label+': '+JSON.stringify(r.blockers));
  assert.strictEqual(r.ecmWriteAuthorized,false);
  assert.strictEqual(r.nativeWindowsRuntimeVerified,false);
 } finally {fs.rmSync(root,{recursive:true,force:true});}
}
console.log('Run682: fifteen Windows reserved-device fixtures passed');
