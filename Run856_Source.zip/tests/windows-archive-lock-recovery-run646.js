'use strict';
// An extracted source ZIP is not an authenticated Git checkout. Never promote
// a generated dependency lockfile from this state without commit provenance.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { generateCandidate } = require('../tools/generate-lockfile-candidate');
const { inspectWindowsDependencyLock } = require('../tools/windows-dependency-preflight');
const source = path.resolve(__dirname, '..');
const packageFile = path.join(source, 'package.json');
const before = fs.readFileSync(packageFile);
const audit = inspectWindowsDependencyLock(source);
assert.equal(audit.lockfileReady, false, 'archived source must not be certified without a lock');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-run646-'));
try {
  const output = path.join(root, 'candidate');
  assert.throws(() => generateCandidate(source, output, { offline: true }),
    /git|commit|repository|failed/i, 'missing Git provenance must fail closed');
  assert.equal(fs.existsSync(output), false, 'failed candidate must not leave output');
  assert.deepEqual(fs.readFileSync(packageFile), before, 'source manifest must remain unchanged');
  assert.equal(fs.existsSync(path.join(source, 'package-lock.json')), false);
  console.log('PASS Run646: missing lockfile and absent Git provenance block candidate; no source mutation');
} finally { fs.rmSync(root, { recursive: true, force: true }); }
