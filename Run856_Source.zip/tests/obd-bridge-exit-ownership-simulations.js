'use strict';
const assert = require('assert');
const { EventEmitter } = require('events');
const Module = require('module');
const path = require('path');
const fs = require('fs');
const os = require('os');
const { FlashManager } = require('../src/flash');

async function runObdBridgeExitOwnershipSimulations() {
  const originalLoad = Module._load;
  const children = [];
  const fakeSpawn = (command) => {
    assert.equal(command, 'powershell.exe');
    const child = new EventEmitter();
    child.pid = 1400 + children.length;
    child.stdout = new EventEmitter();
    child.stderr = new EventEmitter();
    child.killCount = 0;
    child.kill = () => { child.killCount++; return true; };
    children.push(child);
    return child;
  };
  const obdPath = require.resolve('../src/obd');
  let ObdManager;
  try {
    delete require.cache[obdPath];
    Module._load = function(request, parent, isMain) {
      if (request === 'child_process' && parent?.filename === obdPath) return { spawn: fakeSpawn };
      return originalLoad.apply(this, arguments);
    };
    ({ ObdManager } = require('../src/obd'));
  } finally { Module._load = originalLoad; }
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-bridge-ownership-'));
  try {
    const manager = new ObdManager({ dataRoot: () => root, getActiveProject: () => null, platform: 'win32' });
    const pending = manager.runBridge('Probe', { port: 'COM7', timeout: 10000 });
    assert.equal(children.length, 1);
    assert.equal(manager.bridgeChildren.size, 1);
    const aborted = manager.abortBridgeRequests('PCM Hammer handoff');
    assert.equal(aborted.aborted, 1);
    assert.equal(aborted.pendingExit, 1, 'kill request is not COM release evidence');
    await assert.rejects(pending, error => error.code === 'bridge-aborted');
    assert.equal(children[0].killCount, 1);
    await assert.rejects(manager.releaseForExternalTool({ port: 'COM7' }), error => error.code === 'bridge-exit-pending');
    await assert.rejects(manager.runBridge('Identify', { port: 'COM7' }), error => error.code === 'bridge-exit-pending');
    assert.equal(children.length, 1, 'no competing PowerShell child before confirmed close');
    children[0].emit('close', null);
    assert.equal(manager.bridgeChildren.size, 0);
    assert.equal((await manager.releaseForExternalTool({ port: 'COM7' })).released, false);

    const next = manager.runBridge('Probe', { port: 'COM7', timeout: 10000 });
    assert.equal(children.length, 2);
    children[1].stdout.emit('data', Buffer.from('{"success":true,"adapter":"STN"}\n'));
    children[1].emit('close', 0);
    assert.equal((await next).success, true);
    assert.equal(manager.bridgeChildren.size, 0);

    // A timed-out request must retain possible COM ownership after rejecting,
    // until the child actually exits. Timeout is clamped to 1000ms by design.
    const timedOut = manager.runBridge('Probe', { port: 'COM8', timeout: 1000 });
    await assert.rejects(timedOut, error => /timed out/i.test(error.message));
    assert.equal(manager.bridgeChildren.size, 1, 'timeout must not erase possible COM owner');
    await assert.rejects(manager.releaseForExternalTool({ port: 'COM8' }), error => error.code === 'bridge-exit-pending');
    children[2].emit('close', null);
    assert.equal(manager.bridgeChildren.size, 0);

    // Even the proven-port path, which intentionally avoids TunIQ COM probes,
    // must not start PCM Hammer while an old OBD bridge may still own the port.
    const flash = new FlashManager({ platform: 'test', dataRoot: () => root,
      getActiveProject: () => null, getToolPath: () => '', getDeviceStatus: () => ({}),
      releasePort: async () => ({ released: true }), appendActivity: () => {}, emit: () => {},
      abortBridgeRequests: () => ({ aborted: 1, pendingExit: 1 }) });
    await assert.rejects(flash.prepareExclusivePcmHammerLane('COM7', 'read', 'lease-test'), error => error.code === 'bridge-exit-pending');
    await assert.rejects(flash.handoffPort('COM7', 'read', 'lease-test'), error => error.code === 'bridge-exit-pending');
    console.log('✓ OBD bridge child-exit ownership: abort, handoff refusal, reentry, proven-port fail-closed');
    return { passed: true, scenarios: 9 };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
    delete require.cache[obdPath];
  }
}
if (require.main === module) runObdBridgeExitOwnershipSimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runObdBridgeExitOwnershipSimulations };
