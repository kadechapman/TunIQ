'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createStandalone } = require('../tools/build-standalone-browser-preview');
const { verify } = require('../tools/verify-standalone-browser-preview');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-standalone-verify-'));
try {
  const file = path.join(dir, 'preview.html');
  const bytes = createStandalone();
  fs.writeFileSync(file, bytes);
  const good = verify(file);
  assert.equal(good.verified, true);
  assert.equal(good.nativeWindowsElectronVerified, false);
  assert.equal(good.hardwareOperationsAvailable, false);
  assert.equal(good.bytes, bytes.length);
  fs.writeFileSync(file, Buffer.concat([bytes, Buffer.from('x')]));
  assert.throws(() => verify(file), /size mismatch/);
  const tampered = Buffer.from(bytes); tampered[100] ^= 1;
  fs.writeFileSync(file, tampered);
  assert.throws(() => verify(file), /content mismatch/);
  assert.throws(() => verify(path.join(dir, 'missing')), /ENOENT/);
  fs.unlinkSync(file); fs.symlinkSync('missing', file);
  assert.throws(() => verify(file), /Unsafe preview file/);
  console.log('PASS standalone browser preview byte verification: 9 assertions (source-only)');
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
