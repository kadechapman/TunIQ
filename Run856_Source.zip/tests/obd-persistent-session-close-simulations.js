'use strict';
const assert = require('assert');
const { EventEmitter } = require('events');
const { PersistentSerialSession, ObdManager } = require('../src/obd');
const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
function fakeChild() {
  const child = new EventEmitter();
  child.messages = [];
  child.killCount = 0;
  child.stdin = { writable: true, write: value => { child.messages.push(value); } };
  child.kill = () => { child.killCount++; return true; };
  return child;
}
async function runObdPersistentSessionCloseSimulations() {
  const session = new PersistentSerialSession('fake.ps1', 'COM7', 115200);
  const child = fakeChild();
  session.child = child;
  const closing = session.close({ graceMs: 10, timeoutMs: 200 });
  assert.strictEqual(session.close(), closing, 'concurrent close must share exit confirmation');
  assert.strictEqual(session.child, child, 'COM-owning child must remain visible until exit');
  let settled = false;
  closing.then(() => { settled = true; });
  await wait(25);
  assert.strictEqual(settled, false, 'kill request must not be treated as process exit');
  assert(child.killCount >= 1, 'stuck child should receive bounded termination request');
  assert(child.messages.some(value => value.includes('"action":"close"')));
  child.emit('close', 0);
  await closing;
  assert.strictEqual(session.child, null, 'exit event must release child ownership');

  const timeoutSession = new PersistentSerialSession('fake.ps1', 'COM8', 115200);
  const stuck = fakeChild();
  timeoutSession.child = stuck;
  await assert.rejects(timeoutSession.close({ graceMs: 5, timeoutMs: 35 }), /release is unverified/);
  assert.strictEqual(timeoutSession.child, stuck, 'timed-out close must retain possible COM owner');
  // If the OS later confirms exit, a subsequent close can succeed.
  const retry = timeoutSession.close({ graceMs: 5, timeoutMs: 100 });
  stuck.emit('close', 0);
  await retry;
  assert.strictEqual(timeoutSession.child, null);

  const manager = new ObdManager({ dataRoot: () => '/nonexistent-test-root', getActiveProject: () => null, platform: 'test' });
  const active = { port: 'COM9', adapter: 'Mock OBDLink' };
  const pendingChild = fakeChild();
  const closingSession = new PersistentSerialSession('fake.ps1', 'COM9', 115200);
  closingSession.child = pendingChild;
  manager.connection = active;
  manager.serialSession = closingSession;
  // A failed close must not erase the OBD ownership state or report release.
  await assert.rejects(manager.disconnect(), /release is unverified/);
  assert.strictEqual(manager.connection, active);
  assert.strictEqual(manager.serialSession, closingSession);
  await assert.rejects(manager.releaseForExternalTool({ port: 'COM9' }), /release is unverified/);
  assert.strictEqual(manager.serialSession, closingSession);
  // Clean up simulated process to avoid leaving any background activity.
  pendingChild.emit('close', 0);
  console.log('✓ persistent serial close waits for child exit, fails closed on timeout, and retains ownership on disconnect/release failure');
  return { passed: true, scenarios: 4 };
}
if (require.main === module) runObdPersistentSessionCloseSimulations().catch(error => { console.error(error); process.exitCode = 1; });
module.exports = { runObdPersistentSessionCloseSimulations };
