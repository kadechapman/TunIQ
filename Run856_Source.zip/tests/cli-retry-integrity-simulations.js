'use strict';
// Synthetic executable fixture only. Never opens an adapter or contacts a PCM.
const assert = require('assert');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager } = require('../src/flash');

async function runCliRetryIntegritySimulations({ quiet = false } = {}) {
  if (process.platform === 'win32') {
    if (!quiet) console.log('CLI retry integrity executable-swap fixture skipped on Windows (POSIX shebang required).');
    return { passed: 0, skipped: 1, hardwareVerified: false };
  }
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-cli-retry-pin-'));
  try {
    const executable = path.join(root, 'PcmHammerCLI');
    const invocationLog = path.join(root, 'invocations.log');
    const replacement = [
      '#!/usr/bin/env node',
      `require('fs').appendFileSync(${JSON.stringify(invocationLog)}, 'SECOND\\n');`,
      "console.error('No response from PCM');",
      "console.error('Usage: PCM Hammer CLI\\nOperations: read-properties');",
      'process.exitCode = 5;'
    ].join('\n') + '\n';
    const first = [
      '#!/usr/bin/env node',
      "const fs = require('fs');",
      `fs.appendFileSync(${JSON.stringify(invocationLog)}, 'FIRST\\n');`,
      `fs.writeFileSync(__filename, ${JSON.stringify(replacement)});`,
      'fs.chmodSync(__filename, 0o755);',
      "console.error('Unknown command');",
      "console.error('Usage: PCM Hammer CLI\\nOperations: read-properties');",
      'process.exitCode = 64;'
    ].join('\n') + '\n';
    fs.writeFileSync(executable, first, { mode: 0o755 });
    const digest = crypto.createHash('sha256').update(first).digest('hex');
    let completed = null;
    let portTouches = 0;
    const manager = new FlashManager({
      dataRoot: () => path.join(root, 'data'),
      getActiveProject: () => ({ id: 'synthetic', name: 'Synthetic', folder: path.join(root, 'project'), controller: 'P01' }),
      getToolPath: () => executable,
      getDeviceStatus: () => ({ connection: { port: 'COM4', voltage: 12.6 } }),
      inspectExclusiveSession: async () => ({ blocked: false, conflicts: [] }),
      releasePort: async () => { portTouches++; return { released: true }; },
      probePortLock: async () => { portTouches++; return { available: true, locked: false }; },
      appendActivity: () => {}, emit: () => {},
      onSessionComplete: async session => { completed = session; },
      platform: 'test', interOperationCooldownMs: 1
    });
    manager.saveConfig({ executable, device: 'COM4', backend: { product: 'PCM Hammer', executable, sha256: digest }, integrationMode: 'runtime-profile-discovery' });
    // Synthetic-only COM handoff. No real serial API or PCM Hammer binary is called.
    manager.preparePort = async () => ({ port: 'COM4', leaseId: 'synthetic-only', candidates: [{ port: 'COM4', source: 'synthetic' }], attempts: [] });
    await manager.start('readProperties', { device: 'COM4' });
    const start = Date.now();
    while (manager.session && Date.now() - start < 8000) await new Promise(resolve => setTimeout(resolve, 20));
    assert.equal(manager.session, null, 'simulated session must settle without unhandled errors');
    assert(completed, 'simulated failure must generate a completion record');
    const invocations = fs.readFileSync(invocationLog, 'utf8').trim().split(/\s+/);
    assert.deepEqual(invocations, ['FIRST'], 'modified executable must not be launched for another read-only CLI profile');
    assert.equal(completed.stopCode, 'cli-executable-integrity-changed', `stopped session must preserve integrity-specific reason; actual ${completed.stopCode}, state ${completed.state}, result ${JSON.stringify(completed.result)}`);
    assert.equal(completed.state, 'failed');
    assert.equal(portTouches, 0, 'synthetic guard must not access COM ports');

    // A help probe may also replace its own executable before the version
    // probe. A failed pin check must abort probe(), not be swallowed as a
    // syntax error and silently rebaseline the new executable's digest.
    const probeOriginal = [
      '#!/usr/bin/env node',
      "const fs = require('fs');",
      `fs.appendFileSync(${JSON.stringify(invocationLog)}, 'HELP\\n');`,
      `fs.writeFileSync(__filename, ${JSON.stringify(replacement)});`,
      'fs.chmodSync(__filename, 0o755);',
      "console.log('Usage: PCM Hammer CLI\\nOperations: read-properties and read-full');"
    ].join('\n') + '\n';
    fs.writeFileSync(executable, probeOriginal, { mode: 0o755 });
    fs.writeFileSync(invocationLog, '');
    const probeDigest = crypto.createHash('sha256').update(probeOriginal).digest('hex');
    manager.saveConfig({ backend: { product: 'PCM Hammer', executable, sha256: probeDigest } });
    await assert.rejects(manager.probe(),
      error => error.code === 'cli-executable-integrity-changed',
      'a modified CLI during help/version probing must stop instead of silently re-pinning');
    assert.equal(manager.getConfig().backend.sha256, probeDigest,
      'failed probe must preserve the original pinned SHA-256');
    assert.deepEqual(fs.readFileSync(invocationLog, 'utf8').trim().split(/\s+/), ['HELP'],
      'changed CLI must not run a second probe subprocess');
    assert.equal(portTouches, 0);
    if (!quiet) console.log('✓ CLI retry integrity: modified executable refused before retry and version probe (2/2 synthetic, zero COM access)');
    return { passed: 2, hardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runCliRetryIntegritySimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runCliRetryIntegritySimulations };
