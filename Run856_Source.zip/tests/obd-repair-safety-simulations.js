'use strict';
const assert = require('assert');
const { EventEmitter } = require('events');
const { ObdManager } = require('../src/obd');

async function runObdRepairSafetySimulations() {
  const calls = [];
  const manager = new ObdManager({
    platform: 'win32', dataRoot: () => '/not-used', getActiveProject: () => null,
    bridgeRunner: async action => { calls.push(action); return { success: true, devices: [] }; }
  });
  manager.disconnect = async () => { throw Object.assign(new Error('Persistent COM owner did not confirm exit'), { code: 'serial-close-unverified' }); };
  await assert.rejects(manager.repairBluetoothSerial(), error => error.code === 'serial-close-unverified');
  assert(!calls.includes('BluetoothRepair'), 'Bluetooth repair must not start after failed disconnect');

  const bridge = new EventEmitter();
  bridge.stdout = new EventEmitter();
  bridge.stderr = new EventEmitter();
  bridge.pid = 8123;
  bridge.kill = () => true;
  const killer = new EventEmitter();
  const commands = [];
  const serial = new ObdManager({
    platform: 'win32', dataRoot: () => '/not-used', getActiveProject: () => null,
    bridgeSpawn: command => { commands.push(command); return command === 'taskkill.exe' ? killer : bridge; }
  });
  const pending = serial.runBridge('Probe', { port: 'COM8', timeout: 10000 });
  assert.equal(serial.bridgeChildren.size, 1);
  serial.abortBridgeRequests('safe shutdown');
  await assert.rejects(pending, error => error.code === 'bridge-aborted');
  assert(commands.includes('taskkill.exe'));
  assert.doesNotThrow(() => killer.emit('error', new Error('taskkill unavailable')), 'async taskkill error must be handled');
  assert.equal(serial.bridgeChildren.size, 1, 'taskkill failure cannot release possible COM owner');
  await assert.rejects(serial.runBridge('Identify', { port: 'COM8' }), error => error.code === 'bridge-exit-pending');
  bridge.emit('close', 1);
  assert.equal(serial.bridgeChildren.size, 0, 'confirmed child close releases tracked owner');
  console.log('✓ failed disconnect blocks Bluetooth repair; taskkill async error retains COM owner until child close');
  return { passed: true, scenarios: 5 };
}
if (require.main === module) runObdRepairSafetySimulations().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
module.exports = { runObdRepairSafetySimulations };
