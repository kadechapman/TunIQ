'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const reviewer = require('../src/p01-request-review');
const reviewerPath = require.resolve('../tools/owner-windows-readiness-run687');
const original = reviewer.reviewP01Request;
const root = path.resolve(__dirname, '..');
try {
  for (const inconsistent of [
    { ready: true, unresolvedRequests: [{ type: 'VATS' }], missingSafetyFacts: [] },
    { ready: true, unresolvedRequests: [], missingSafetyFacts: ['Unverified ECM OS'] },
    { ready: true, unresolvedRequests: [{ type: 'fan' }], missingSafetyFacts: ['Unverified fan output'] }
  ]) {
    reviewer.reviewP01Request = () => inconsistent;
    delete require.cache[reviewerPath];
    const { inspect, exitCodeFor } = require(reviewerPath);
    const result = inspect(root, { controller: 'P01', os: 'unknown' }, 'review');
    assert.equal(result.owner.requestReviewReady, false);
    assert.match(result.owner.reviewError, /invalid result/);
    assert.equal(result.owner.ready, false);
    assert.equal(result.readyForUserTesting, false);
    assert.equal(result.ecmWriteAuthorized, false);
    assert.equal(exitCodeFor(result), 2);
  }
  reviewer.reviewP01Request = () => ({ ready: false, unresolvedRequests: [{type:'VATS'}], missingSafetyFacts: [] });
  delete require.cache[reviewerPath];
  const valid = require(reviewerPath).inspect(root, {controller:'P01'}, 'review');
  assert.equal(valid.owner.reviewError, null);
  assert.deepEqual(valid.owner.unresolvedTypes, ['VATS']);
  console.log('PASS Run698: 20 assertions across three contradictory and one valid fixture');
} finally {
  reviewer.reviewP01Request = original;
  delete require.cache[reviewerPath];
}
