'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-readiness-'));
try {
  fs.writeFileSync(path.join(dir, 'package.json'), JSON.stringify({name:'fixture',version:'1',dependencies:{electron:'^1.0.0'}}));
  const lock = {lockfileVersion:3,packages:{'':{name:'fixture',version:'1',dependencies:{electron:'^1.0.0'}}}};
  fs.writeFileSync(path.join(dir, 'package-lock.json'), JSON.stringify(lock));
  let result = assess(dir);
  assert(result.blockers.includes('package-lock-dependency-entries-missing'));
  assert.deepStrictEqual(result.missingDependencyEntries,['electron']);
  lock.packages['node_modules/electron']={version:'1.0.0',resolved:'https://example.invalid/electron.tgz',integrity:'sha512-fixture'};
  fs.writeFileSync(path.join(dir, 'package-lock.json'), JSON.stringify(lock));
  result=assess(dir);
  assert.strictEqual(result.lockfileDependencyEntriesPresent,true);
  assert.deepStrictEqual(result.blockers,[]);
  console.log('PASS: missing dependency entry blocks admission; present entry clears this specific blocker (fixture only)');
} finally { fs.rmSync(dir,{recursive:true,force:true}); }
