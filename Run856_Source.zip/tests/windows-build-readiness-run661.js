'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
for (const [version, invalid] of [[null,true],[42,true],['',true],['  ',true],[{},true],['1.2.3',false],[undefined,false]]) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(),'tuniq661-'));
  try {
    const pkg = {name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}};
    const entry = version === undefined ? {} : {version};
    const lock = {lockfileVersion:3,packages:{'':{name:'tuniq',version:'1.0.0',dependencies:{electron:'1.0.0'}},'node_modules/electron':entry}};
    fs.writeFileSync(path.join(dir,'package.json'),JSON.stringify(pkg));
    fs.writeFileSync(path.join(dir,'package-lock.json'),JSON.stringify(lock));
    const result = assess(dir);
    assert.strictEqual(result.blockers.includes('package-lock-resolved-versions-invalid'),invalid,String(version));
    assert.strictEqual(result.ecmWriteAuthorized,false);
    assert.strictEqual(result.nativeWindowsRuntimeVerified,false);
    if (!invalid) assert.deepStrictEqual(result.blockers,[]);
  } finally {fs.rmSync(dir,{recursive:true,force:true});}
}
console.log('Run661: 7 resolved-version fixtures passed');
