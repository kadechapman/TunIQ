'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const { inspect, exitCodeFor } = require('../tools/owner-windows-readiness-run687');
const { assess } = require('../tools/windows-build-readiness-run647');
const original = assess;
// Actual-source inspection is retained; tests check fail-closed output contracts.
const report = inspect(path.join(__dirname, '..'), {controller:'P01', os:'unknown'}, 'VATS fan cam knock');
assert.equal(report.readyForUserTesting, false);
assert.equal(report.readyForPublicRelease, false);
assert.equal(report.ecmWriteAuthorized, false);
assert.equal(report.windows.nativeWindowsRuntimeVerified, false);
assert.equal(exitCodeFor(report), 2);
assert.equal(typeof report.windows.packagePresent, 'boolean');
assert.equal(typeof report.windows.lockfilePresent, 'boolean');
assert.ok(report.windows.blockers.every(x => typeof x === 'string' && x.trim()));
console.log('Run696: 8 source-only safety assertions passed');
const readinessPath = require.resolve('../tools/windows-build-readiness-run647');
const ownerPath = require.resolve('../tools/owner-windows-readiness-run687');
const moduleRecord = require.cache[readinessPath];
for (const malformed of [{blockers:[null],packagePresent:true,lockfilePresent:true},{blockers:[],packagePresent:'yes',lockfilePresent:true},{blockers:[''],packagePresent:true,lockfilePresent:true}]) {
  moduleRecord.exports.assess = () => malformed;
  delete require.cache[ownerPath];
  const r = require(ownerPath).inspect('/fixture', {controller:'P01',os:'unknown'}, 'fan');
  assert.deepEqual(r.windows.blockers, ['windows-source-inspection-invalid']);
  assert.equal(r.readyForUserTesting, false);
  assert.equal(r.ecmWriteAuthorized, false);
}
moduleRecord.exports.assess = original;
delete require.cache[ownerPath];
console.log('Run696: 9 malformed-assessment assertions passed');
