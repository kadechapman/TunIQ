'use strict';
// Filesystem-only; no PCM Hammer process, serial COM port, or ECU access.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function runP01VerifiedPairLiveIntegritySimulations() {
  const folder = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-verified-pair-live-'));
  let passed = 0;
  try {
    const first = path.join(folder, 'first.bin');
    const second = path.join(folder, 'second.bin');
    const contents = Buffer.alloc(P01_BIN_SIZE, 0x41);
    fs.writeFileSync(first, contents); fs.writeFileSync(second, contents);
    const active = { id: 'live-integrity', name: 'Live integrity fixture', controller: 'P01', os: '9379910', folder, bin: first };
    const manager = new P01CommissioningManager({ getActiveProject: () => active });
    manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'fixture-hw', serviceNumber: 'fixture-svc' });
    manager.recordRead(first, {}, { id: 'first-session', proofSource: 'first-source' });
    manager.recordRead(second, {}, { id: 'second-session', proofSource: 'second-source' });
    assert.equal(manager.status().dualReadVerified, true); passed++;
    // A hostile/mistaken project BIN can be arbitrarily large. The original
    // fileInfo() used fs.readFileSync(fd), allocating for the entire file
    // before checking the expected 512 KiB size. Neither oversize evidence
    // nor a normal read should ever invoke an unbounded descriptor read.
    const oversized = path.join(folder, 'oversized.bin');
    const oversizeFd = fs.openSync(oversized, 'w');
    try { fs.ftruncateSync(oversizeFd, 16 * 1024 * 1024); }
    finally { fs.closeSync(oversizeFd); }
    const originalReadFile = fs.readFileSync;
    const originalRead = fs.readSync;
    let unboundedDescriptorReads = 0;
    let boundedDescriptorReads = 0;
    let oversizedDescriptorReads = 0;
    try {
      fs.readFileSync = function (target, ...args) {
        if (typeof target === 'number') {
          unboundedDescriptorReads += 1;
          throw new Error('unbounded descriptor read forbidden in P01 integrity check');
        }
        return originalReadFile.call(this, target, ...args);
      };
      fs.readSync = function (fd, buffer, offset, length, position) {
        assert(length <= P01_BIN_SIZE, 'descriptor reads must be bounded to P01 size');
        boundedDescriptorReads += 1;
        if (fs.fstatSync(fd).size > P01_BIN_SIZE) oversizedDescriptorReads += 1;
        return originalRead.call(this, fd, buffer, offset, length, position);
      };
      active.bin = oversized;
      assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false);
      assert.equal(unboundedDescriptorReads, 0,
        'oversized original must be rejected before any unbounded descriptor read'); passed++;
      assert.equal(oversizedDescriptorReads, 0,
        'oversized original must be rejected before reading file bytes'); passed++;
      const savedReadCount = manager.load().reads.length;
      assert.throws(() => manager.recordRead(oversized, {}, { id: 'oversized-session' }),
        /expected exactly 524288 bytes/,
        'oversized read must preserve the actionable size error');
      assert.equal(manager.load().reads.length, savedReadCount,
        'rejected oversized read must not enter the evidence ledger'); passed++;
      active.bin = first;
      assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, true,
        'valid 512 KiB original must still pass via bounded reads'); passed++;
      assert.equal(unboundedDescriptorReads, 0,
        'valid original must not require an unbounded descriptor read'); passed++;
      assert(boundedDescriptorReads >= 2,
        'valid original must be read with a bounded buffer and EOF probe'); passed++;
    } finally {
      fs.readFileSync = originalReadFile;
      fs.readSync = originalRead;
      active.bin = first;
    }
    // Regression: a symlinked active original previously passed the SHA-256
    // comparison and was treated as bound to the two verified Full Reads.
    // Some Windows CI runners cannot create symlinks without privileges.
    const linkedOriginal = path.join(folder, 'linked-original.bin');
    let symlinkAvailable = false;
    try {
      fs.symlinkSync(first, linkedOriginal);
      symlinkAvailable = true;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }
    if (symlinkAvailable) {
      active.bin = linkedOriginal;
      assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
        'a symlink must never stand in for the protected original'); passed++;
      // Simulate a file being swapped between lstat and open. The digest
      // must never be accepted from the replacement, even with identical bytes.
      const swappedPath = path.join(folder, 'swapped-original.bin');
      fs.copyFileSync(first, swappedPath);
      active.bin = swappedPath;
      const originalOpen = fs.openSync;
      let swapped = false;
      try {
        fs.openSync = function (file, ...args) {
          if (file === swappedPath && !swapped) {
            swapped = true;
            fs.unlinkSync(swappedPath);
            fs.symlinkSync(first, swappedPath);
          }
          return originalOpen.call(this, file, ...args);
        };
        assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
          'an original replaced between inspection and open must fail closed'); passed++;
        assert.equal(swapped, true, 'the simulated file swap must actually execute');
      } finally { fs.openSync = originalOpen; }
      // A redirected parent is also unsafe, even if the target bytes match.
      const redirectedFolder = path.join(folder, 'redirected');
      try {
        fs.symlinkSync(folder, redirectedFolder, process.platform === 'win32' ? 'junction' : 'dir');
        active.bin = path.join(redirectedFolder, 'first.bin');
        assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
          'an original beneath a symlink/junction parent must be rejected'); passed++;
      } catch (error) {
        if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      }
    }
    // An image that grows while being read must not be hashed as if the
    // original size still applied. Simulate a trailing byte at the EOF probe
    // without mutating the test fixture (works without Windows write sharing).
    const originalReadSync = fs.readSync;
    let extraByteSimulated = false;
    try {
      fs.readSync = function (fd, buffer, offset, length, position) {
        if (!extraByteSimulated && length === 1) {
          extraByteSimulated = true;
          buffer[offset] = 0x7f;
          return 1;
        }
        return originalReadSync.call(this, fd, buffer, offset, length, position);
      };
      assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
        'a byte beyond the expected image size must revoke original binding');
      assert.equal(extraByteSimulated, true, 'EOF probe must actually execute'); passed++;
    } finally { fs.readSync = originalReadSync; }
    let truncatedReadSimulated = false;
    try {
      fs.readSync = function (fd, buffer, offset, length, position) {
        if (!truncatedReadSimulated && length === P01_BIN_SIZE) {
          truncatedReadSimulated = true;
          return 0;
        }
        return originalReadSync.call(this, fd, buffer, offset, length, position);
      };
      assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
        'an early EOF must revoke original binding');
      assert.equal(truncatedReadSimulated, true, 'short-read simulation must actually execute'); passed++;
    } finally { fs.readSync = originalReadSync; }
    active.bin = first;
    assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, true,
      'restoring the direct original must restore valid read binding'); passed++;
    // The original cannot be a multiply-linked alias of another BIN either.
    const extraLink = path.join(folder, 'extra-link.bin');
    fs.linkSync(first, extraLink);
    assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
      'a hardlinked original must not be promoted as protected evidence'); passed++;
    fs.unlinkSync(extraLink);
    assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, true,
      'a direct singly-linked original remains valid'); passed++;
    fs.unlinkSync(second); fs.linkSync(first, second);
    assert.equal(manager.status().dualReadVerified, false, 'saved verified pair must be revoked if paths become hardlinks');
    assert.equal(manager.verifiedOriginalBinding(active, manager.load()).activeMatches, false,
      'original binding must not trust an aliased second read'); passed++;
    fs.unlinkSync(second); fs.writeFileSync(second, contents);
    assert.equal(manager.status().dualReadVerified, true, 'restored separate unchanged evidence should be valid'); passed++;
    fs.writeFileSync(second, Buffer.alloc(P01_BIN_SIZE, 0x99));
    assert.equal(manager.status().dualReadVerified, false, 'saved verified pair must fail if second read bytes change'); passed++;
    fs.writeFileSync(second, contents);
    fs.unlinkSync(second);
    assert.equal(manager.status().dualReadVerified, false, 'missing saved second read must fail closed'); passed++;
    console.log(`✓ P01 verified-pair live integrity: ${passed} filesystem-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally { fs.rmSync(folder, { recursive: true, force: true }); }
}
if (require.main === module) runP01VerifiedPairLiveIntegritySimulations();
module.exports = { runP01VerifiedPairLiveIntegritySimulations };
