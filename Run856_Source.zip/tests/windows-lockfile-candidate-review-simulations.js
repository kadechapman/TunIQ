'use strict';
// Real npm-generated offline lockfile fixture; no TunIQ install or hardware.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { spawnSync } = require('node:child_process');
const { reviewCandidate } = require('../tools/review-windows-lockfile-candidate');
let checks = 0;
function check(label, callback) { callback(); checks++; }
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-candidate-review-fixture-'));
const source = path.join(dir, 'source');
const artifact = path.join(dir, 'artifact');
fs.mkdirSync(source); fs.mkdirSync(artifact);
const pkgPath = path.join(source, 'package.json');
const lockPath = path.join(artifact, 'package-lock.candidate.json');
const proofPath = path.join(artifact, 'candidate-provenance.json');
const sha = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const run = (command, args, cwd) => spawnSync(command, args,
  { cwd, encoding: 'utf8', timeout: 20000, windowsHide: true,
    shell: process.platform === 'win32' && command === 'npm.cmd',
    env: { ...process.env, npm_config_update_notifier:'false' } });
function success(result, label) {
  assert.equal(result.error, undefined, `${label}: ${result.error?.message}`);
  assert.equal(result.status, 0, `${label}: ${result.stderr}`);
}
try {
  const packageText = '{"name":"tuniq-lock-review-fixture","version":"1.0.0","private":true}\n';
  fs.writeFileSync(pkgPath, packageText);
  const trackedPolicy = path.join(source, 'README.md');
  fs.writeFileSync(trackedPolicy, 'reviewed Windows lockfile policy\n');
  success(run('git', ['init','-q'], source), 'git init');
  success(run('git', ['-c','user.name=TunIQ Fixture','-c','user.email=tuniq-fixture@example.invalid',
    'add','package.json','README.md'], source), 'git add');
  success(run('git', ['-c','user.name=TunIQ Fixture','-c','user.email=tuniq-fixture@example.invalid',
    'commit','-qm','review fixture'], source), 'git commit');
  const commit = run('git', ['rev-parse','HEAD'], source).stdout.trim();
  const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';
  success(run(npm, ['install','--package-lock-only','--package-lock=true','--save=true',
    '--ignore-scripts','--no-audit','--no-fund','--offline','--fetch-retries=0'], source), 'npm lockfile');
  fs.copyFileSync(path.join(source, 'package-lock.json'), lockPath);
  fs.unlinkSync(path.join(source, 'package-lock.json'));
  const goodProof = {
    kind:'tuniq-windows-lockfile-candidate',schemaVersion:1,sourceCommit:commit,
    sourcePackageSha256:sha(Buffer.from(packageText)),
    candidateSha256:sha(fs.readFileSync(lockPath)),nodeVersion:process.version,
    npmVersion:run(npm,['--version'],source).stdout.trim(),
    metadataPreflightPassed:true,nativeInstallVerified:false,
    electronRuntimeVerified:false,fullTunIQVerified:false,physicalHardwareVerified:false
  };
  const writeProof = p => fs.writeFileSync(proofPath, JSON.stringify(p)+'\n');
  const reject = label => check(label, () => assert.throws(() => reviewCandidate(source,artifact)));
  writeProof(goodProof);
  check('genuine offline npm candidate accepted as metadata-only', () => {
    const result = reviewCandidate(source,artifact);
    assert.equal(result.passed,true);
    assert.equal(result.nativeInstallVerified,false);
    assert.equal(result.fullTunIQVerified,false);
    assert.equal(result.physicalHardwareVerified,false);
  });
  check('review does not promote lockfile into source checkout', () =>
    assert.equal(fs.existsSync(path.join(source,'package-lock.json')),false));
  // A reviewer must not bless a candidate stored inside the source checkout.
  // This can appear clean to git diff because the artifact is untracked.
  const embedded = path.join(source, 'untracked-review-artifact');
  fs.mkdirSync(embedded);
  fs.copyFileSync(lockPath, path.join(embedded, 'package-lock.candidate.json'));
  fs.copyFileSync(proofPath, path.join(embedded, 'candidate-provenance.json'));
  check('reject candidate artifact located inside source checkout', () =>
    assert.throws(() => reviewCandidate(source, embedded), /source|checkout|outside/i));
  // An outside-looking path may resolve into the checkout via a directory
  // symlink/junction. Windows can deny junction creation on locked-down CI.
  const alias = path.join(dir, 'source-directory-alias');
  let linked = false;
  try { fs.symlinkSync(source, alias, process.platform === 'win32' ? 'junction' : 'dir'); linked = true; }
  catch (error) {
    if (!(process.platform === 'win32' && ['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code))) throw error;
  }
  if (linked) check('reject artifact redirected into checkout through directory link', () =>
    assert.throws(() => reviewCandidate(source, path.join(alias, 'untracked-review-artifact')),
      /source|checkout|outside/i));

  for (const [field,value] of [
    ['sourceCommit','0'.repeat(40)], ['sourcePackageSha256','f'.repeat(64)],
    ['candidateSha256','a'.repeat(64)], ['nativeInstallVerified',true],
    ['electronRuntimeVerified',true], ['fullTunIQVerified',true],
    ['physicalHardwareVerified',true], ['metadataPreflightPassed',false],
    ['schemaVersion',2], ['nodeVersion','unknown'], ['npmVersion','unknown']
  ]) {
    writeProof({...goodProof,[field]:value}); reject(`reject forged ${field}`);
  }
  // The source commit alone is not proof that the on-disk manifest belongs
  // to that commit. A matching rewritten provenance must not bless a dirty
  // manifest that was never reviewed or committed.
  const changedPackageText = packageText.replace('\"private\":true', '\"private\":true,\"description\":\"uncommitted drift\"');
  fs.writeFileSync(pkgPath, changedPackageText);
  writeProof({...goodProof, sourcePackageSha256:sha(Buffer.from(changedPackageText))});
  reject('reject uncommitted source manifest despite matching forged provenance');
  fs.writeFileSync(pkgPath, packageText);
  writeProof(goodProof);
  // A source checkout with unrelated tracked changes cannot claim that the
  // entire review used the named, immutable source commit.
  fs.writeFileSync(trackedPolicy, 'uncommitted policy drift\n');
  reject('reject unrelated tracked source drift despite clean manifest and hashes');
  fs.writeFileSync(trackedPolicy, 'reviewed Windows lockfile policy\n');
  fs.writeFileSync(trackedPolicy, 'staged policy drift\n');
  success(run('git', ['add','README.md'], source), 'stage policy drift');
  reject('reject staged tracked policy drift despite clean manifest and hashes');
  success(run('git', ['reset','-q','HEAD','--','README.md'], source), 'reset staged policy');
  fs.writeFileSync(trackedPolicy, 'reviewed Windows lockfile policy\n');
  writeProof({...goodProof,unknownField:'surprise'}); reject('reject unreviewed provenance field');
  writeProof(goodProof);
  const originalCandidate = fs.readFileSync(lockPath);
  fs.writeFileSync(lockPath, Buffer.concat([originalCandidate,Buffer.from(' ')]));
  reject('reject candidate changed after proof');
  fs.writeFileSync(lockPath, originalCandidate);
  const wrongLock = JSON.parse(originalCandidate);
  wrongLock.packages[''].name = 'wrong-project';
  const wrongBytes = Buffer.from(JSON.stringify(wrongLock));
  fs.writeFileSync(lockPath, wrongBytes);
  writeProof({...goodProof,candidateSha256:sha(wrongBytes)});
  reject('reject correctly hashed but invalid lockfile metadata');
  fs.writeFileSync(lockPath,originalCandidate); writeProof(goodProof);
  fs.writeFileSync(proofPath,'{invalid json'); reject('reject invalid provenance JSON');
  writeProof(goodProof);
  fs.unlinkSync(lockPath);
  fs.symlinkSync(path.join(source,'package.json'),lockPath);
  reject('reject symlink candidate');
  fs.unlinkSync(lockPath); fs.writeFileSync(lockPath,originalCandidate);
  // Simulate a pathname being replaced between lstat and open, then restored
  // immediately, with stale path metadata (a deterministic adversarial
  // metadata fixture). The replacement contains identical bytes: hashes and
  // stale timestamps alone cannot prove the opened file's identity.
  // Windows does not permit this unlink-while-open fixture; the fd identity
  // check itself remains enabled on Windows.
  if (process.platform !== 'win32') {
    check('reject a swapped review input inode even after path restoration', () => {
      const originalOpen = fs.openSync;
      const originalLstat = fs.lstatSync;
      const baseline = originalLstat.call(fs, lockPath);
      let intercepted = false;
      fs.lstatSync = function (file, ...rest) {
        return file === lockPath ? baseline : originalLstat.call(fs, file, ...rest);
      };
      fs.openSync = function (file, flags, ...rest) {
        if (file !== lockPath || intercepted) return originalOpen.call(fs, file, flags, ...rest);
        intercepted = true;
        const saved = `${lockPath}.original`;
        fs.renameSync(lockPath, saved);
        fs.writeFileSync(lockPath, originalCandidate);
        try { return originalOpen.call(fs, file, flags, ...rest); }
        finally { fs.unlinkSync(lockPath); fs.renameSync(saved, lockPath); }
      };
      try {
        assert.throws(() => reviewCandidate(source, artifact), /changed|unsafe/i);
        assert.equal(intercepted, true, 'reviewer must bind read to an open file descriptor');
      } finally { fs.openSync = originalOpen; fs.lstatSync = originalLstat; }
      assert.deepEqual(fs.readFileSync(lockPath), originalCandidate);
    });
  }
  check('review still passes after negative fixtures', () => assert.equal(reviewCandidate(source,artifact).passed,true));
  const cli = run(process.execPath,[path.join(__dirname,'../tools/review-windows-lockfile-candidate.js'),artifact],source);
  check('actual reviewer CLI fails closed when invoked from unrelated checkout', () => assert.notEqual(cli.status,0));
  console.log(`Windows lockfile candidate review: ${checks}/${checks} passed (real offline npm lockfile; no native Electron).`);
} finally { fs.rmSync(dir,{recursive:true,force:true}); }
