'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { assess } = require('../tools/windows-build-readiness-run647');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq656-'));
const base = { name: 'fixture', version: '1.0.0' };
const lock = { lockfileVersion: 3, packages: { '': { ...base } } };
function check(pkg, l, expected) {
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(pkg));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(l));
  const result = assess(root);
  assert(result.blockers.includes(expected), JSON.stringify(result));
  assert.strictEqual(result.nativeWindowsRuntimeVerified, false);
  assert.strictEqual(result.ecmWriteAuthorized, false);
}
try {
  for (const bad of [null, 12, false, {}, '', '   ']) {
    check({ ...base, dependencies: { electron: bad } }, lock, 'package-json-dependency-specs-invalid');
    check(base, { ...lock, packages: { '': { ...base, dependencies: { electron: bad } } } }, 'package-lock-root-dependency-specs-invalid');
  }
  fs.writeFileSync(path.join(root, 'package.json'), JSON.stringify(base));
  fs.writeFileSync(path.join(root, 'package-lock.json'), JSON.stringify(lock));
  assert.deepStrictEqual(assess(root).blockers, []);
} finally { fs.rmSync(root, { recursive: true, force: true }); }
console.log('Run656: 12 malformed spec cases and valid empty dependency fixture passed');
