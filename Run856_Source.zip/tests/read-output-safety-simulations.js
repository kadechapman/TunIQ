'use strict';
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { checkUnusedReadDestination, checkSafeReadPath } = require('../src/read-output-safety');

function runReadOutputSafetySimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-output-safety-'));
  let passed = 0;
  try {
    const originals = path.join(root, 'Originals');
    fs.mkdirSync(originals);
    const unused = path.join(originals, 'unused.bin');
    assert.equal(checkUnusedReadDestination(unused).ok, true); passed++;
    assert.equal(checkSafeReadPath(unused).ok, true); passed++;
    const zero = path.join(originals, 'zero.bin');
    fs.writeFileSync(zero, Buffer.alloc(0));
    assert.equal(checkSafeReadPath(zero).ok, true, 'existing regular file may pass path policy for later integrity verification'); passed++;
    assert.equal(checkUnusedReadDestination(zero).code, 'read-output-exists'); passed++;
    assert.equal(checkUnusedReadDestination('').code, 'read-output-invalid'); passed++;
    // The destination parent must exist before any Full Read or CLI retry.
    // ENOENT for a parent is not evidence of an unused, writable backup path.
    for (const missing of [path.join(root, 'missing', 'read.bin'),
      path.join(root, 'missing', 'nested', 'read.bin')]) {
      assert.equal(checkUnusedReadDestination(missing).code, 'read-output-unavailable',
        'missing backup directory must fail closed'); passed++;
      assert.equal(checkUnusedReadDestination(missing, { allowMissingParents: true }).ok, true,
        'explicit preflight may inspect ancestors before creating a new directory'); passed++;
    }

    // Windows device aliases can discard read data even with a .bin extension.
    // NTFS alternate data streams and Win32 trailing-name normalization can
    // also alias an existing destination without an ordinary filename match.
    for (const name of ['NUL.bin', 'CON.bin', 'PRN', 'AUX.bin', 'COM1.bin', 'LPT9.bin',
      'stock.bin:other', 'stock.bin.', 'stock.bin ']) {
      assert.equal(checkUnusedReadDestination(path.join(originals, name)).code, 'read-output-windows-alias',
        `unsafe Windows output alias must be rejected: ${name}`);
      passed++;
    }
    // Windows treats superscript 1/2/3 as digits in COM/LPT device names.
    // Console aliases and invalid Win32 filename characters must also fail
    // before PCM Hammer can start a Full Read.
    for (const name of ['COM¹.bin', 'COM².bin', 'COM³.bin', 'LPT¹.bin', 'LPT².bin', 'LPT³.bin',
      'CONIN$.bin', 'CONOUT$.bin', 'read?.bin', 'read*.bin', 'read|backup.bin',
      'read<backup.bin', 'read"backup.bin', 'read\u0001backup.bin']) {
      assert.equal(checkUnusedReadDestination(path.join(originals, name)).code, 'read-output-windows-alias',
        `unsafe Win32 destination must be rejected: ${JSON.stringify(name)}`);
      passed++;
    }
    // A backslash is a Win32 path separator, not a legal filename character.
    // On POSIX, path.basename() does not split it, so validation must not
    // accidentally approve a path that becomes a reserved device/ADS name
    // when interpreted by the Windows PCM Hammer executable.
    if (process.platform !== 'win32') for (const rawName of ['backup\\NUL.bin', 'backup\\COM1.bin',
      'backup\\COM².bin', 'backup\\read.bin:stream',
      'backup\\read.bin.', 'backup\\normal.bin']) {
      const ambiguous = path.join(originals, rawName);
      assert.equal(checkSafeReadPath(ambiguous).code, 'read-output-windows-alias',
        `embedded Win32 separator must not bypass path validation: ${JSON.stringify(rawName)}`);
      passed++;
      assert.equal(checkUnusedReadDestination(ambiguous, { allowMissingParents: true }).code,
        'read-output-windows-alias', 'CLI preflight must reject the same path');
      passed++;
    }
    // Backup filenames with invisible formatting, bidi overrides, Unicode
    // line breaks or non-printing controls can misrepresent the actual BIN
    // location in a Windows dialog or incident log. They must fail closed on
    // all platforms, including if a later '..' erases the raw component.
    const ambiguousUnicodeNames = [
      'read\u200B.bin', // zero-width space
      'read\u200D.bin', // zero-width joiner
      'read\u202E.bin', // right-to-left override
      'read\u2066.bin', // left-to-right isolate
      'read\uFEFF.bin', // byte-order mark
      'read\u00AD.bin', // soft hyphen
      'read\u2028.bin', // Unicode line separator
      'read\u2029.bin', // Unicode paragraph separator
      'read\u0085.bin', // C1 control (NEL)
      'read\u007F.bin', // DEL
      'read\uD800.bin'  // unpaired UTF-16 surrogate
    ];
    for (const name of ambiguousUnicodeNames) {
      const raw = path.join(originals, name);
      assert.equal(checkSafeReadPath(raw).code, 'read-output-windows-alias',
        `ambiguous Unicode backup path must fail policy: ${JSON.stringify(name)}`); passed++;
      assert.equal(checkUnusedReadDestination(raw).code, 'read-output-windows-alias',
        'Full Read preflight must reject the same Unicode path'); passed++;
    }
    for (const name of ['read\u200B.bin', 'read\u202E.bin', 'read\u2028.bin', 'read\u0085.bin']) {
      const hidden = `${originals}${path.sep}${name}${path.sep}..${path.sep}read.bin`;
      assert.equal(checkSafeReadPath(hidden).code, 'read-output-windows-alias',
        'raw Unicode component must be rejected before normalization'); passed++;
      assert.equal(checkUnusedReadDestination(hidden).code, 'read-output-windows-alias',
        'Full Read preflight must reject hidden Unicode component'); passed++;
    }
    for (const name of ['café.bin', '日本語.bin', 'car-🚗.bin']) {
      const printable = path.join(originals, name);
      assert.equal(checkSafeReadPath(printable).ok, true,
        'ordinary printable Unicode backup names remain valid'); passed++;
      assert.equal(checkUnusedReadDestination(printable).ok, true,
        'ordinary printable Unicode names remain valid for Full Read'); passed++;
    }
    // Path normalization must not conceal a raw Win32 device/ADS/alias
    // component. Previous checks inspected only path.resolve(output), which
    // silently removed the unsafe segment when followed by "..".
    for (const hidden of ['NUL.bin', 'COM1.bin', 'COM².bin', 'CONIN$.bin',
      'read.bin:stream', 'trailing.', 'trailing ', 'bad?dir', 'bad<dir']) {
      const raw = `${originals}${path.sep}${hidden}${path.sep}..${path.sep}new.bin`;
      assert.equal(checkSafeReadPath(raw).code, 'read-output-windows-alias',
        `raw normalized-away Win32 alias must be rejected: ${JSON.stringify(hidden)}`);
      passed++;
      assert.equal(checkUnusedReadDestination(raw).code, 'read-output-windows-alias',
        'Full Read destination admission must reject the same raw alias');
      passed++;
    }
    const normalDotDot = `${originals}${path.sep}ordinary${path.sep}..${path.sep}new.bin`;
    assert.equal(checkSafeReadPath(normalDotDot).ok, true,
      'ordinary dot-dot normalization remains valid'); passed++;
    assert.equal(checkUnusedReadDestination(normalDotDot).ok, true,
      'ordinary dot-dot destination remains valid'); passed++;
    assert.equal(checkUnusedReadDestination(path.join(root, 'COM²', 'read.bin')).code,
      'read-output-windows-alias', 'superscript device-name parent must be rejected'); passed++;
    // UNC shares and Win32 device/extended-length namespaces are not safe
    // Full Read backup destinations. Check the ORIGINAL string: path.resolve()
    // can erase namespace syntax (especially on non-Windows CI hosts).
    for (const name of [String.raw`\\.\PhysicalDrive0`, String.raw`\\?\C:\Temp\read.bin`,
      String.raw`\\server\share\read.bin`, '//server/share/read.bin',
      String.raw`\??\C:\Temp\read.bin`, String.raw`C:relative-read.bin`,
      String.raw`\Device\HarddiskVolume1\read.bin`,
      String.raw`\Temp\read.bin`, String.raw`\Users\Public\read.bin`]) {
      assert.equal(checkUnusedReadDestination(name).code, 'read-output-unsafe-namespace',
        `device or network path must be rejected before normalization: ${JSON.stringify(name)}`);
      passed++;
    }
    // Both the preflight destination check and post-read/import path check
    // must reject drive-rooted backslash paths, even on POSIX test runners.
    for (const rooted of [String.raw`\Temp\read.bin`, String.raw`\Users\Public\read.bin`]) {
      assert.equal(checkSafeReadPath(rooted).code, 'read-output-unsafe-namespace',
        'Windows current-drive-rooted read/import path must not be trusted'); passed++;
    }
    assert.equal(checkUnusedReadDestination(path.join(originals, 'COM10.bin')).ok, true); passed++;
    assert.equal(checkUnusedReadDestination(path.join(originals, 'read-COM1-backup.bin')).ok, true); passed++;
    assert.equal(checkUnusedReadDestination(path.join(root, 'Originals.', 'read.bin')).code,
      'read-output-windows-alias', 'trailing-dot parent aliases must be rejected'); passed++;
    const notDirectory = path.join(originals, 'file');
    fs.writeFileSync(notDirectory, 'x');
    assert.equal(checkUnusedReadDestination(path.join(notDirectory, 'read.bin')).code, 'read-output-unavailable'); passed++;
    const link = path.join(root, 'linked-originals');
    try {
      fs.symlinkSync(originals, link, process.platform === 'win32' ? 'junction' : 'dir');
      assert.equal(checkUnusedReadDestination(path.join(link, 'new.bin')).code, 'read-output-symlink-parent'); passed++;
      assert.equal(checkUnusedReadDestination(link).code, 'read-output-exists'); passed++;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
    }
    if (!quiet) console.log(`✓ Read output path safety: ${passed} checks passed (local filesystem; no hardware)`);
    return { passed, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) runReadOutputSafetySimulations();
module.exports = { runReadOutputSafetySimulations };
