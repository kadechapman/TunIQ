'use strict';
// Offline filesystem integrity regressions. No Electron or Windows claims.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { inspectTree, writeEvidence, verifyEvidence, validateWindowsName } = require('../tools/windows-preview-tree-integrity');
const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-preview-tree-'));
const output = path.join(root, 'Offline-UI-Preview-' + 'a'.repeat(32));
const evidence = path.join(root, 'delivered-preview-tree-integrity.json');
let checks = 0;
const check = (name, fn) => { fn(); checks++; };
try {
  fs.mkdirSync(path.join(output, 'resources'), {recursive:true});
  fs.mkdirSync(path.join(output, 'locales'));
  fs.writeFileSync(path.join(output, 'TunIQ Offline UI Preview.exe'), 'synthetic exe');
  const asar = path.join(output, 'resources', 'app.asar');
  fs.writeFileSync(asar, 'synthetic preview app');
  const dll = path.join(output, 'libEGL.dll');
  fs.writeFileSync(dll, 'synthetic runtime dll');
  writeEvidence(output, evidence);
  check('fresh complete tree verifies', () => assert.equal(verifyEvidence(output, evidence), true));
  check('manifest contains app.asar, DLL and EXE', () => {
    const names = inspectTree(output).files.map(f=>f.path);
    assert.deepEqual(names, ['TunIQ Offline UI Preview.exe','libEGL.dll','resources/app.asar']);
  });
  // Run174 regression: Run173 hashed only files, so adding an empty
  // unreviewed directory after smoke passed verification unchanged.
  check('manifest binds even empty directory entries', () => {
    assert.deepEqual(inspectTree(output).directories, ['locales', 'resources']);
    assert.equal(inspectTree(output).directoryCount, 2);
  });
  check('unreviewed empty directory added after smoke is rejected', () => {
    const extra = path.join(output, 'unreviewed-empty');
    fs.mkdirSync(extra);
    try { assert.throws(() => verifyEvidence(output, evidence), /mismatch/); }
    finally { fs.rmdirSync(extra); }
  });
  check('unreviewed empty nested directory added after smoke is rejected', () => {
    const extra = path.join(output, 'resources', 'new-empty');
    fs.mkdirSync(extra);
    try { assert.throws(() => verifyEvidence(output, evidence), /mismatch/); }
    finally { fs.rmdirSync(extra); }
  });
  check('deleting a previously attested empty directory is rejected', () => {
    const existing = path.join(output, 'locales');
    fs.rmdirSync(existing);
    try { assert.throws(() => verifyEvidence(output, evidence), /mismatch/); }
    finally { fs.mkdirSync(existing); }
  });
  check('changed app.asar rejected', () => {
    fs.writeFileSync(asar, 'tampered app');
    assert.throws(()=>verifyEvidence(output,evidence),/mismatch/);
    fs.writeFileSync(asar, 'synthetic preview app');
  });
  check('changed DLL rejected', () => {
    fs.writeFileSync(dll, 'tampered runtime');
    assert.throws(()=>verifyEvidence(output,evidence),/mismatch/);
    fs.writeFileSync(dll, 'synthetic runtime dll');
  });
  check('new file rejected', () => {
    const file = path.join(output,'locales','unverified.pak');
    fs.writeFileSync(file,'added');
    assert.throws(()=>verifyEvidence(output,evidence),/mismatch/);
    fs.unlinkSync(file);
  });
  check('deleted resource rejected', () => {
    fs.unlinkSync(asar);
    assert.throws(()=>verifyEvidence(output,evidence),/missing-delivered|mismatch/);
    fs.writeFileSync(asar, 'synthetic preview app');
  });
  check('symlinked resource rejected', () => {
    fs.unlinkSync(dll); fs.symlinkSync(asar,dll);
    assert.throws(()=>verifyEvidence(output,evidence),/unsafe-delivered-link/);
    fs.unlinkSync(dll); fs.writeFileSync(dll, 'synthetic runtime dll');
  });
  check('hardlinked resource rejected', () => {
    const link=path.join(output,'duplicate.dll'); fs.linkSync(dll,link);
    assert.throws(()=>verifyEvidence(output,evidence),/unsafe-or-oversized-delivered-tree/);
    fs.unlinkSync(link);
  });
  check('missing asar rejected even without a manifest', () => {
    fs.unlinkSync(asar);
    assert.throws(()=>inspectTree(output),/missing-delivered/);
    fs.writeFileSync(asar, 'synthetic preview app');
  });
  check('existing manifest not overwritten', () =>
    assert.throws(()=>writeEvidence(output,evidence),/EEXIST/));
  check('evidence path replacement between metadata check and read cannot certify forged proof', () => {
    const originalProof = fs.readFileSync(evidence, 'utf8');
    const validCopy = path.join(root, 'original-proof.json');
    const moved = path.join(root, 'replaced-proof.json');
    fs.writeFileSync(validCopy, originalProof);
    fs.writeFileSync(evidence, JSON.stringify({ ...JSON.parse(originalProof), files: [] }, null, 2));
    const realRead = fs.readFileSync;
    let swapped = false;
    try {
      fs.readFileSync = function (file, ...args) {
        if (!swapped && file === evidence) {
          swapped = true;
          fs.renameSync(evidence, moved);
          fs.copyFileSync(validCopy, evidence);
        }
        return realRead.call(fs, file, ...args);
      };
      assert.throws(() => verifyEvidence(output, evidence), /mismatch|changed|unsafe/);
    } finally {
      fs.readFileSync = realRead;
      fs.rmSync(evidence, {force: true});
      fs.rmSync(moved, {force: true});
      fs.writeFileSync(evidence, originalProof);
      fs.rmSync(validCopy, {force: true});
    }
  });
  check('CLI verifies synthetic tree only', () => {
    const run = spawnSync(process.execPath, [path.join(__dirname,'../tools/windows-preview-tree-integrity.js'), '--verify', output, evidence], {encoding:'utf8'});
    assert.equal(run.status,0);
    assert.match(run.stdout,/NOT runtime/);
  });
  check('overly deep empty directory chain rejected before recursive traversal', () => {
    let nested = output;
    try {
      for (let i = 0; i < 34; i++) {
        nested = path.join(nested, 'd');
        fs.mkdirSync(nested);
      }
      assert.throws(() => inspectTree(output), /too-deep-delivered-tree/);
    } finally { fs.rmSync(path.join(output, 'd'), {recursive:true, force:true}); }
  });
  check('excessive empty directory fanout rejected even without files', () => {
    const parent = path.join(output, 'empty-directories');
    fs.mkdirSync(parent);
    try {
      for (let i = 0; i < 1025; i++) fs.mkdirSync(path.join(parent, `d${i}`));
      assert.throws(() => inspectTree(output), /too-many-delivered-directories/);
    } finally { fs.rmSync(parent, {recursive:true, force:true}); }
  });
  check('Windows device-name file rejected', () => {
    assert.throws(() => validateWindowsName('CON.txt'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const file = path.join(output, 'CON.txt');
    fs.writeFileSync(file, 'synthetic');
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.unlinkSync(file); }
  });
  check('Windows device-name empty directory rejected', () => {
    assert.throws(() => validateWindowsName('AUX'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const dir = path.join(output, 'AUX');
    fs.mkdirSync(dir);
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.rmdirSync(dir); }
  });
  check('Windows trailing-period filename rejected', () => {
    assert.throws(() => validateWindowsName('notes.'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const file = path.join(output, 'notes.');
    fs.writeFileSync(file, 'synthetic');
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.unlinkSync(file); }
  });
  check('Windows forbidden punctuation rejected', () => {
    assert.throws(() => validateWindowsName('bad?.dll'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const file = path.join(output, 'bad?.dll');
    fs.writeFileSync(file, 'synthetic');
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.unlinkSync(file); }
  });
  // Run229: Windows reserves CONIN$ and CONOUT$ even without extensions.
  // The source ZIP preflight rejects them; the delivered-tree verifier must
  // independently reject the same names before certifying a Windows package.
  check('Windows CONIN$ reserved device file rejected', () => {
    assert.throws(() => validateWindowsName('CONIN$'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const file = path.join(output, 'CONIN$');
    fs.writeFileSync(file, 'synthetic');
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.unlinkSync(file); }
  });
  check('Windows CONOUT$ reserved device directory with extension rejected', () => {
    assert.throws(() => validateWindowsName('CONOUT$.log'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const dir = path.join(output, 'CONOUT$.log');
    fs.mkdirSync(dir);
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.rmdirSync(dir); }
  });
  check('Windows DEL control-character filename rejected', () => {
    assert.throws(() => validateWindowsName('bad\x7fname.dll'), /unsafe-windows-delivered-name/);
    if (process.platform === 'win32') return;
    const file = path.join(output, 'bad\x7fname.dll');
    fs.writeFileSync(file, 'synthetic');
    try { assert.throws(() => inspectTree(output), /unsafe-windows-delivered-name/); }
    finally { fs.unlinkSync(file); }
  });
  check('ordinary Windows filenames remain accepted', () => {
    for (const name of ['conductor.dll', 'com10.dll', 'normal.pak'])
      assert.doesNotThrow(() => validateWindowsName(name));
    assert.throws(() => validateWindowsName('COM¹.txt'), /unsafe-windows-delivered-name/);
  });
  check('case-colliding directories rejected even with distinct child files', () => {
    if (process.platform === 'win32') return; // Windows normally aliases these names.
    const dir = path.join(output, 'Locales');
    fs.mkdirSync(dir);
    fs.writeFileSync(path.join(dir, 'en.pak'), 'synthetic');
    try { assert.throws(() => inspectTree(output), /delivered-path-case-collision/); }
    finally { fs.rmSync(dir, {recursive:true, force:true}); }
  });
  console.log(`Delivered preview tree integrity offline fixtures: ${checks}/${checks} passed (NO Windows runtime).`);
} finally { fs.rmSync(root,{recursive:true,force:true}); }
