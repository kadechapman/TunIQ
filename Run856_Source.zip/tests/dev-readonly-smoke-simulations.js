'use strict';
// Pure offline readiness tests. No Electron, npm install, COM ports, or ECU.
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const path = require('node:path');
const { summarizeDevReadonlySmoke, inspectDevReadonlySmoke } = require('../tools/dev-readonly-smoke');
const { inspectWindowsDependencyLock } = require('../tools/windows-dependency-preflight');

const base = {
  version: '1.0.0',
  contract: { startupContractSafe: true, blockers: [] },
  admission: { safe: true, blockers: [] },
  missing: [], lockfilePresent: true,
  dependency: { lockfileReady: true, blockers: [] }
};
let passed = 0;
function check(label, overrides, verify) {
  const result = summarizeDevReadonlySmoke({ ...base, ...overrides });
  verify(result);
  passed++;
}
check('valid metadata still not runtime verified', {}, r => {
  assert.equal(r.dependencyLockfileReady, true);
  assert.deepEqual(r.readinessBlockers, ['native-electron-startup-not-verified', 'windows-build-not-verified']);
  assert.equal(r.runnableBuildVerified, false);
  assert.equal(r.ecuCommunicationPerformed, false);
});
check('missing lockfile explicitly blocks readiness', {
  lockfilePresent: false, dependency: { lockfileReady: false, blockers: ['lockfile-missing'] }
}, r => {
  assert.equal(r.dependencyLockfilePresent, false);
  assert.equal(r.dependencyLockfileReady, false);
  assert(r.readinessBlockers.includes('dependency:lockfile-missing'));
  assert.deepEqual(r.blockers, []);
});
check('malformed present lockfile is not ready', {
  dependency: { lockfileReady: false, blockers: ['lockfile-invalid-json'] }
}, r => {
  assert.equal(r.dependencyLockfilePresent, true);
  assert.equal(r.dependencyLockfileReady, false);
  assert(r.readinessBlockers.includes('dependency:lockfile-invalid-json'));
});
check('unsafe symlink lockfile cannot pass', {
  dependency: { lockfileReady: false, blockers: ['lockfile-unsafe-file'] }
}, r => assert(r.readinessBlockers.includes('dependency:lockfile-unsafe-file')));
check('mismatched lockfile cannot pass', {
  dependency: { lockfileReady: false, blockers: ['lockfile-root-mismatch', 'lockfile-dependencies-set-mismatch'] }
}, r => {
  assert.equal(r.dependencyLockfileReady, false);
  assert.equal(r.dependencyLockfileBlockers.length, 2);
  assert.equal(r.readinessBlockers.length, 4);
});
check('inconsistent claimed readiness fails closed', {
  dependency: { lockfileReady: true, blockers: ['lockfile-transitive-integrity-invalid'] }
}, r => assert.equal(r.dependencyLockfileReady, false));
check('empty blocker list with failed readiness remains blocked', {
  dependency: { lockfileReady: false, blockers: [] }
}, r => assert(r.readinessBlockers.includes('dependency:lockfile-not-ready')));
check('source startup failure remains fatal', {
  contract: { startupContractSafe: false, blockers: ['unexpected-electron-entrypoint'] }
}, r => assert(r.blockers.includes('unexpected-electron-entrypoint')));
check('production write admission failure remains fatal', {
  admission: { safe: false, blockers: ['production-readonly-flag-missing'] }
}, r => assert(r.blockers.includes('production-readonly-flag-missing')));
check('missing renderer file remains fatal', { missing: ['src/renderer/app.js'] },
  r => assert(r.blockers.includes('missing:src/renderer/app.js')));
check('false startup safety without explanation remains fatal', {
  contract: { startupContractSafe: false, blockers: [] }
}, r => {
  assert.equal(r.startupContractSafe, false);
  assert(r.blockers.includes('startup-contract-not-safe'));
});
check('false production write admission without explanation remains fatal', {
  admission: { safe: false, blockers: [] }
}, r => {
  assert.equal(r.productionWriteAdmissionSafe, false);
  assert(r.blockers.includes('production-write-admission-not-safe'));
});
check('absent lockfile cannot be ready despite contradictory dependency claim', {
  lockfilePresent: false, dependency: { lockfileReady: true, blockers: [] }
}, r => {
  assert.equal(r.dependencyLockfileReady, false);
  assert(r.readinessBlockers.includes('dependency:lockfile-missing'));
});
check('missing preflight flags cannot silently pass', {
  contract: { blockers: [] }, admission: { blockers: [] }
}, r => {
  assert(r.blockers.includes('startup-contract-not-safe'));
  assert(r.blockers.includes('production-write-admission-not-safe'));
});
check('malformed dependency report cannot silently pass', {
  dependency: { lockfileReady: true, blockers: null }
}, r => {
  assert.equal(r.dependencyLockfileReady, false);
  assert(r.readinessBlockers.includes('dependency:invalid-dependency-report'));
});
const live = inspectDevReadonlySmoke();
assert.equal(live.mode, 'offline-source-only');
assert.equal(live.ecuCommunicationPerformed, false);
assert.equal(live.runnableBuildVerified, false);
const dependency = inspectWindowsDependencyLock();
assert.equal(live.dependencyLockfileReady, dependency.lockfileReady);
for (const reason of dependency.blockers) {
  assert(live.readinessBlockers.includes(`dependency:${reason}`));
}
passed++;
const cli = spawnSync(process.execPath, [path.join(__dirname, '../tools/dev-readonly-smoke.js')],
  { encoding: 'utf8', timeout: 15000 });
assert.equal(cli.status, 0, cli.stderr);
const cliReport = JSON.parse(cli.stdout);
assert.equal(cliReport.dependencyLockfileReady, dependency.lockfileReady);
assert.deepEqual(cliReport.dependencyLockfileBlockers, dependency.blockers);
passed++;
console.log(`Development read-only smoke regressions: ${passed}/${passed} passed (offline; no ECU access).`);
