'use strict';
// Offline source-only fixtures. Never loads Electron, a serial device, or an ECU.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { inspectElectronStartupContract } = require('../tools/electron-startup-contract-preflight');

function runElectronStartupContractPreflightSimulations({ quiet = false } = {}) {
  const source = path.resolve(__dirname, '..');
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-startup-contract-'));
  let passed = 0;
  const check = (condition, description) => { assert.ok(condition, description); passed++; };
  const files = ['package.json', 'src/main.js', 'src/preload.js', 'src/renderer/index.html',
    'src/renderer/app.js', 'src/renderer/engine-catalog.js', 'src/renderer/styles.css'];
  const restore = () => {
    fs.rmSync(path.join(root, 'src'), { recursive: true, force: true });
    for (const name of files) {
      const destination = path.join(root, name);
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      fs.copyFileSync(path.join(source, name), destination);
    }
  };
  const modify = (name, find, replace) => {
    const file = path.join(root, name);
    const original = fs.readFileSync(file, 'utf8');
    assert.ok(original.includes(find), `fixture missing ${find}`);
    fs.writeFileSync(file, original.replace(find, replace));
  };
  const reject = (name, code) => {
    const result = inspectElectronStartupContract(root);
    check(!result.startupContractSafe && result.blockers.includes(code), name);
  };
  try {
    restore();
    const baseline = inspectElectronStartupContract(root);
    check(baseline.startupContractSafe && baseline.blockers.length === 0, 'current source passes contract');
    check(baseline.registeredHandlers > 100 && baseline.invokedChannels > 100, 'full IPC surface audited');
    check(baseline.exposedMethods > 100 && baseline.usedMethods > 100, 'preload/renderer methods audited');
    check(baseline.electronRuntimeVerified === false && baseline.physicalHardwareVerified === false,
      'static result cannot certify runtime or hardware');
    restore(); modify('src/preload.js', "ipcRenderer.invoke('app:get-bootstrap')", "ipcRenderer.invoke('missing:handler')");
    reject('preload invoke with no handler rejected', 'unhandled-preload-channel');
    restore(); modify('src/preload.js', "ipcRenderer.invoke('app:get-bootstrap')", 'ipcRenderer.invoke(dynamicChannel)');
    reject('dynamic invoke rejected', 'dynamic-or-unparseable-ipc-channel');
    restore(); modify('src/main.js', "ipcMain.handle('app:get-bootstrap'", "ipcMain.handle(dynamicChannel");
    reject('dynamic handler rejected', 'dynamic-or-unparseable-ipc-channel');
    restore(); modify('src/main.js', "ipcMain.handle('app:get-bootstrap'", "ipcMain.handle('app:get-bootstrap'");
    fs.appendFileSync(path.join(root, 'src/main.js'), "\nipcMain.handle('app:get-bootstrap', async () => ({}));\n");
    reject('duplicate handler rejected', 'duplicate-ipc-handler');
    restore(); fs.appendFileSync(path.join(root, 'src/renderer/app.js'), '\nwindow.tuniq.nonexistentMethod();\n');
    reject('unexposed renderer API rejected', 'unexposed-renderer-method');
    restore(); fs.appendFileSync(path.join(root, 'src/preload.js'), '\nconst duplicate = { getBootstrap: () => null };\n');
    reject('duplicate exposed name rejected', 'duplicate-preload-method');
    restore(); modify('src/preload.js', "contextBridge.exposeInMainWorld('tuniq'", "contextBridge.exposeInMainWorld('other'");
    reject('missing isolated bridge rejected', 'missing-isolated-preload-bridge');
    restore(); modify('src/main.js', 'contextIsolation: true', 'contextIsolation: false');
    reject('disabled isolation rejected', 'missing-electron-window-isolation');
    restore(); modify('src/main.js', 'sandbox: true', 'sandbox: false');
    reject('disabled sandbox rejected', 'missing-electron-window-isolation');
    restore(); modify('src/main.js', 'nodeIntegration: false', 'nodeIntegration: true');
    reject('enabled node integration rejected', 'missing-electron-window-isolation');
    restore(); modify('src/main.js', 'attachRendererNavigationGuard(mainWindow.webContents)',
      'attachRendererNavigationGuard(anotherWindow.webContents)');
    reject('missing navigation guard rejected', 'navigation-guard-not-installed-before-load');
    restore(); modify('src/renderer/index.html', 'src="app.js"', 'src="https://example.invalid/app.js"');
    reject('remote renderer resource rejected', 'unsafe-or-missing-renderer-resource');
    // Regression: active HTML that bypasses the old src/href-only scan must fail closed.
    restore(); modify('src/renderer/index.html', '</body>', '<script>window.injected = true;</script>\n</body>');
    reject('inline script rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '</body>', '<script src=app.js></script>\n</body>');
    reject('unquoted script source rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '</body>', '<iframe src="https://example.invalid/"></iframe>\n</body>');
    reject('embedded frame rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '</head>', '<meta http-equiv="refresh" content="0;url=https://example.invalid">\n</head>');
    reject('HTML refresh rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '<body>', '<body onload="window.injected = true">');
    reject('inline HTML event handler rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '</head>', '<base href="https://example.invalid/">\n</head>');
    reject('base URL override rejected', 'unsafe-active-renderer-html');
    restore(); modify('src/renderer/index.html', '<script src="app.js"></script>', '<script src="app.js">window.injected = true;</script>');
    reject('script with inline body rejected', 'unsafe-active-renderer-html');
    // The previous source checker accepted the renderer with no CSP at all.
    // These tests ensure Chromium's defense-in-depth policy cannot be dropped
    // or silently weakened without failing the offline startup gate.
    const csp = `<meta http-equiv="Content-Security-Policy" content="script-src 'self'; object-src 'none'; base-uri 'none'; frame-src 'none'; form-action 'none'">`;
    restore(); modify('src/renderer/index.html', csp, '');
    reject('removed CSP rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp.replace("script-src 'self'", "script-src 'self' 'unsafe-inline'"));
    reject('unsafe-inline script CSP rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp.replace("script-src 'self'", "script-src 'self' 'unsafe-eval'"));
    reject('unsafe-eval script CSP rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp.replace("object-src 'none'", "object-src *"));
    reject('relaxed object policy rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp.replace("frame-src 'none'", "frame-src *"));
    reject('relaxed frame policy rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp + '\n  ' + csp);
    reject('duplicate CSP rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, '');
    modify('src/renderer/index.html', '</body>', `${csp}\n</body>`);
    reject('CSP after body rejected', 'missing-or-weakened-renderer-csp');
    restore(); modify('src/renderer/index.html', csp, csp.replace('Content-Security-Policy', 'X-Not-CSP'));
    reject('misnamed CSP rejected', 'missing-or-weakened-renderer-csp');
    restore(); fs.unlinkSync(path.join(root, 'src/renderer/app.js'));
    reject('missing renderer script rejected', 'missing-or-unsafe:src/renderer/app.js');
    restore(); fs.unlinkSync(path.join(root, 'src/renderer/styles.css'));
    fs.symlinkSync(path.join(source, 'src/renderer/styles.css'), path.join(root, 'src/renderer/styles.css'));
    reject('linked stylesheet rejected', 'unsafe-or-missing-renderer-resource');
    restore(); modify('package.json', '"main": "src/main.js"', '"main": "src/other.js"');
    reject('unexpected package entrypoint rejected', 'unexpected-electron-entrypoint');
    restore();
    const cli = path.join(source, 'tools/electron-startup-contract-preflight.js');
    const ok = spawnSync(process.execPath, [cli, root, '--require-safe'], { encoding: 'utf8' });
    check(ok.status === 0 && JSON.parse(ok.stdout).startupContractSafe, 'strict CLI succeeds on safe fixture');
    modify('src/preload.js', "ipcRenderer.invoke('app:get-bootstrap')", "ipcRenderer.invoke('missing:handler')");
    const fail = spawnSync(process.execPath, [cli, root, '--require-safe'], { encoding: 'utf8' });
    check(fail.status === 2 && !JSON.parse(fail.stdout).startupContractSafe, 'strict CLI blocks broken IPC');
    const report = spawnSync(process.execPath, [cli, root, '--report'], { encoding: 'utf8' });
    check(report.status === 0 && !JSON.parse(report.stdout).startupContractSafe, 'report mode is diagnostic only');
    const usage = spawnSync(process.execPath, [cli, root, '--invalid'], { encoding: 'utf8' });
    check(usage.status === 1, 'unknown CLI arguments rejected');
    if (!quiet) console.log(`Electron startup contract preflight: ${passed}/${passed} offline checks passed`);
    return { passed, electronRuntimeVerified: false, physicalHardwareVerified: false };
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
}
if (require.main === module) runElectronStartupContractPreflightSimulations();
module.exports = { runElectronStartupContractPreflightSimulations };
