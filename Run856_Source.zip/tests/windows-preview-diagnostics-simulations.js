'use strict';
// Deterministic offline fixtures: no Windows runtime, npm registry, or ECU access.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { diagnose, validProof, ALLOWED_STEPS } = require('../tools/diagnose-windows-preview');
let count = 0;
const check = (name, fn) => { fn(); count++; };
const dir = path.join(os.tmpdir(), `Run97-Diagnostics-${'c'.repeat(32)}`);
fs.rmSync(dir, { recursive: true, force: true });
fs.mkdirSync(dir);
const outcome = (lastStep, passed = false) => ({
  schemaVersion: 1, kind: 'tuniq-offline-preview-build-outcome',
  passed, lastStep, windowsRuntimeVerified: passed,
  fullTunIQVerified: false, hardwareUsed: false
});
const rendererProof = nonce => ({ schemaVersion: 1, kind: 'tuniq-isolated-renderer-runtime-smoke',
  nonce, passed: true, actualElectronRuntime: true, nativeWindowsElectronVerified: true,
  rendererSnapshotValidated: true, primaryNavigationVerified: true,
  observedPrimaryPageCount: 9, runtimeBlockerCount: 0, snapshotBlockerCount: 0,
  fullTunIQVerified: false, hardwareUsed: false, ecuWriteOrFlashPerformed: false });
const peProof = () => ({ schemaVersion: 1, kind: 'tuniq-offline-preview-windows-pe-integrity',
  sizeBytes: 1048576, sha256: 'f'.repeat(64), machine: 'amd64', subsystem: 'windows-gui',
  nativeStartupVerified: false, fullTunIQVerified: false });
const treeProof = () => ({schemaVersion: 1, kind: 'tuniq-offline-preview-delivered-tree-integrity',
  fileCount: 2, totalBytes: 2000000, files: [{path:'resources/app.asar', sizeBytes:100, sha256:'a'.repeat(64)},
    {path:'TunIQ Offline UI Preview.exe', sizeBytes:1999900, sha256:'b'.repeat(64)}],
  previewOnly: true, fullTunIQVerified: false, hardwareUsed: false});
const proof = nonce => ({ schemaVersion: 1, kind: 'tuniq-offline-preview-smoke',
  nonce, passed: true, reason: 'offline-renderer-ready',
  hardwareAvailable: false, writeHandlersRegistered: false });
const write = (file, data) => fs.writeFileSync(path.join(dir, file), typeof data === 'string' ? data : JSON.stringify(data));
try {
  check('reject unrelated diagnostics directory', () => assert.throws(() => diagnose(os.tmpdir()), /Expected/));
  check('missing outcome fails closed', () => assert.equal(diagnose(dir).failureCode, 'missing-or-invalid-outcome'));
  write('build-outcome.json', outcome('Resolve genuine npm lock graph without running scripts'));
  write('windows-build-transcript.txt', 'npm error code EAI_AGAIN\nnpm error path C:\\Users\\Private\\secret');
  check('DNS failure classified', () => assert.equal(diagnose(dir).failureCode, 'npm-registry-dns'));
  check('no private log paths exposed', () => assert(!JSON.stringify(diagnose(dir)).includes('Private')));
  // Run123: npm can fail before useful text reaches the PowerShell transcript.
  // The bounded, local npm debug log must still support safe classification.
  write('windows-build-transcript.txt', '');
  const npmDebug = '2026-10-24T02_17_20_578Z-debug-0.log';
  write(npmDebug, 'npm error code EAI_AGAIN\nnpm error path C:\\Users\\Private\\secret');
  check('npm debug-only DNS failure classified', () =>
    assert.equal(diagnose(dir).failureCode, 'npm-registry-dns'));
  check('npm debug-only private paths never copied into safe diagnosis', () =>
    assert(!JSON.stringify(diagnose(dir)).includes('Private')));
  fs.rmSync(path.join(dir, npmDebug));
  write('windows-build-transcript.txt', 'npm error code ERESOLVE');
  check('dependency graph failure classified', () => assert.equal(diagnose(dir).failureCode, 'npm-lock-resolution'));
  write('build-outcome.json', outcome('Install locked Electron dependencies'));
  write('windows-build-transcript.txt', 'npm error code EAI_AGAIN\nnpm error request to https://github.com/electron/electron/releases/download/v37.2.3/electron-v37.2.3-win32-x64.zip failed');
  check('Electron GitHub binary failure is not mislabeled npm registry DNS', () =>
    assert.equal(diagnose(dir).failureCode, 'electron-binary-download'));
  check('Electron download diagnosis avoids raw URLs and private paths', () =>
    assert(!JSON.stringify(diagnose(dir)).includes('electron-v37.2.3-win32-x64.zip')));
  write('windows-build-transcript.txt', 'npm error code EAI_AGAIN\nnpm error request to https://registry.npmjs.org/electron failed');
  check('npm registry DNS failure during npm ci remains correctly classified', () =>
    assert.equal(diagnose(dir).failureCode, 'npm-registry-dns'));
  write('windows-build-transcript.txt', 'Failed to download Electron: ECONNRESET');
  check('Electron postinstall download failure recognized', () =>
    assert.equal(diagnose(dir).failureCode, 'electron-binary-download'));
  write('build-outcome.json', outcome('Real hardware-isolated renderer runtime'));
  write('windows-build-transcript.txt', 'Isolated renderer runtime timed out after 45 seconds.');
  check('native renderer timeout classified', () => assert.equal(diagnose(dir).failureCode, 'isolated-renderer-runtime'));
  write('build-outcome.json', outcome('Launch staged preview in real Electron (smoke mode)'));
  write('windows-build-transcript.txt', 'Staged Electron smoke timed out after 30 seconds.');
  check('staged startup timeout classified', () => assert.equal(diagnose(dir).failureCode, 'staged-electron-smoke'));
  write('build-outcome.json', outcome('Packaged Windows executable smoke'));
  write('windows-build-transcript.txt', 'Packaged preview smoke failed (exit 2).');
  check('packaged startup failure classified', () => assert.equal(diagnose(dir).failureCode, 'packaged-electron-smoke'));
  write('windows-build-transcript.txt', '');
  write('build-outcome.json', outcome('Install locked Electron dependencies'));
  check('fallback step diagnosis', () => assert.equal(diagnose(dir).failureCode, 'npm-install-failed'));
  // Regression: native Start-Process can fail before any recognizable
  // stdout/stderr line is emitted. The last verified step must still yield
  // actionable classification, never an opaque 'unclassified' result.
  for (const [step, expected] of [
    ['Launch staged preview in real Electron (smoke mode)', 'staged-electron-smoke'],
    ['Validate staged Electron renderer evidence', 'staged-electron-smoke'],
    ['Packaged Windows executable smoke', 'packaged-electron-smoke'],
    ['Delivered Windows executable smoke', 'delivered-electron-smoke'],
    ['Verify delivered preview executable copy', 'delivered-executable-mismatch'],
    ['Stage strictly allowlisted, hardware-free Electron application', 'preview-staging-failed'],
    ['Complete offline simulated suite', 'offline-suite-failed'],
    ['windows-preflight', 'windows-preflight-failed']
  ]) {
    write('build-outcome.json', outcome(step));
    check(`log-free Windows failure classified: ${step}`, () => {
      const result = diagnose(dir);
      assert.equal(result.failureCode, expected);
      assert.equal(result.offlinePreviewEvidenceComplete, false);
      assert.equal(result.readyForUserTesting, false);
    });
  }
  // Regression: the transcript contains all previous steps. An earlier npm
  // EAI_AGAIN/ERESOLVE line must not override the later failed native step.
  for (const [step, expected] of [
    ['Real hardware-isolated renderer runtime', 'isolated-renderer-runtime'],
    ['Launch staged preview in real Electron (smoke mode)', 'staged-electron-smoke'],
    ['Packaged Windows executable smoke', 'packaged-electron-smoke'],
    ['Delivered Windows executable smoke', 'delivered-electron-smoke'],
    ['Verify delivered preview executable copy', 'delivered-executable-mismatch'],
    ['Record packaged Windows PE integrity', 'packaged-executable-integrity'],
    ['Record delivered preview tree integrity', 'delivered-tree-integrity'],
    ['Record smoke-tested packaged preview tree', 'packaged-tree-integrity'],
    ['Verify delivered copy against packaged preview tree', 'packaged-delivered-tree-mismatch'],
    ['Complete offline simulated suite', 'offline-suite-failed'],
    ['Production write-denial safety', 'read-only-admission-failed']
  ]) {
    write('build-outcome.json', outcome(step));
    write('windows-build-transcript.txt', 'npm error code EAI_AGAIN\nnpm error code ERESOLVE\n');
    check(`stale npm errors cannot override ${step}`, () => {
      assert.equal(diagnose(dir).failureCode, expected);
      assert.equal(diagnose(dir).readyForUserTesting, false);
    });
  }
  write('windows-build-transcript.txt', '');
  // Every pre-network step has an actionable, secret-free fallback even if
  // PowerShell or Node exits before writing a recognizable error line.
  for (const [step, expected] of [
    ['Offline source integrity and syntax', 'source-check-failed'],
    ['Source path safety', 'source-path-preflight-failed'],
    ['Production write-denial safety', 'read-only-admission-failed'],
    ['Offline Electron contract', 'electron-contract-failed'],
    ['Verify npm lockfile writer behavior (offline fixture)', 'lockfile-fixture-failed']
  ]) {
    write('build-outcome.json', outcome(step));
    check(`log-free preflight classified: ${step}`, () => assert.equal(diagnose(dir).failureCode, expected));
  }
  write('build-outcome.json', outcome('Packaged Windows executable smoke', true));
  check('claimed success at earlier step fails closed', () => assert.equal(diagnose(dir).failureCode, 'premature-success-claim'));
  write('staged-smoke-evidence.json', proof('a'.repeat(32)));
  write('packaged-smoke-evidence.json', proof('a'.repeat(32)));
  check('reused nonce cannot verify success', () => assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('packaged-smoke-evidence.json', proof('b'.repeat(32)));
  check('two preview proofs without renderer runtime do not verify success', () => assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('renderer-runtime-evidence.json', rendererProof('c'.repeat(32)));
  check('three native proofs without PE integrity are insufficient', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('packaged-executable-integrity.json', peProof());
  check('three native proofs without delivered-copy smoke are insufficient', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('delivered-smoke-evidence.json', proof('d'.repeat(32)));
  check('four native proofs and PE without delivered tree metadata remain incomplete', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('delivered-preview-tree-integrity.json', treeProof());
  check('delivered proof without matching packaged proof remains incomplete', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('packaged-preview-tree-integrity.json', treeProof());
  // Run134 regression: a success flag at an earlier build step must not
  // substitute for the final delivered-tree recording step.
  check('premature build success flag cannot complete Windows preview evidence', () => {
    const result = diagnose(dir);
    assert.equal(result.offlinePreviewEvidenceComplete, false);
    assert.equal(result.failureCode, 'premature-success-claim');
  });
  write('build-outcome.json', outcome('Record delivered preview tree integrity', true));
  check('four distinct native proofs and both integrity metadata recognized', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, true));
  // The Run262 writer emits these fields, but older consumers ignored them.
  // Each omission or false claim must fail closed before a Windows preview
  // can be considered evidence-complete (offline synthetic fixtures only).
  for (const [field, bad] of [
    ['nativeWindowsElectronVerified', undefined],
    ['nativeWindowsElectronVerified', false],
    ['rendererSnapshotValidated', false],
    ['primaryNavigationVerified', false],
    ['observedPrimaryPageCount', 8],
    ['runtimeBlockerCount', 1],
    ['snapshotBlockerCount', 1]
  ]) {
    check(`incomplete native renderer evidence rejected: ${field}=${bad}`, () => {
      const original = rendererProof('c'.repeat(32));
      const incomplete = {...original, [field]: bad};
      if (bad === undefined) delete incomplete[field];
      write('renderer-runtime-evidence.json', incomplete);
      try { assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false); }
      finally { write('renderer-runtime-evidence.json', original); }
    });
  }
  // Run194: successful one-click launch finishes AFTER tree integrity.
  // PowerShell 5.1 JSON also includes a UTF-8 BOM. Both are normal, not
  // evidence of a premature or invalid build.
  const goodOutcome = outcome('Record delivered preview tree integrity', true);
  const goodPe = peProof();
  const windowProof = {
    schemaVersion: 1, kind: 'tuniq-offline-preview-visible-window',
    nonce: 'e'.repeat(32), diagnosticsRun: path.basename(dir),
    deliveredPreviewDirectory: 'Offline-UI-Preview-' + 'b'.repeat(32),
    deliveredExeSha256: goodPe.sha256,
    probeMethod: 'user32-IsWindowVisible-and-exact-title',
    passed: true, actualWindowsWindowCheck: true, exactExpectedTitle: true,
    visible: true, hardwareUsed: false, fullTunIQVerified: false
  };
  check('PowerShell BOM build-only outcome parsed', () => {
    fs.writeFileSync(path.join(dir, 'build-outcome.json'), '\ufeff' + JSON.stringify(goodOutcome));
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, true);
  });
  check('one-click interactive outcome recognized with bound visible-window proof', () => {
    const interactiveOutcome = {...goodOutcome,
      lastStep: 'Open verified offline UI preview interactively',
      interactiveLaunchRequested: true, interactiveLaunchProcessAlive: true,
      interactiveLaunchWindowVisible: true,
      deliveredPreviewDirectory: windowProof.deliveredPreviewDirectory};
    fs.writeFileSync(path.join(dir, 'build-outcome.json'), '\ufeff' + JSON.stringify(interactiveOutcome));
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false);
    fs.writeFileSync(path.join(dir, 'interactive-window-evidence.json'), '\ufeff' + JSON.stringify(windowProof));
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, true);
    write('interactive-window-evidence.json', {...windowProof, deliveredExeSha256: '0'.repeat(64)});
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false);
    write('interactive-window-evidence.json', windowProof);
    write('build-outcome.json', {...interactiveOutcome, interactiveLaunchWindowVisible: false});
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false);
    fs.rmSync(path.join(dir, 'interactive-window-evidence.json'));
    write('build-outcome.json', goodOutcome);
  });
  write('delivered-smoke-evidence.json', proof('a'.repeat(32)));
  check('reused delivered nonce rejected', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('delivered-smoke-evidence.json', proof('d'.repeat(32)));
  check('PE metadata flag present', () => assert.equal(diagnose(dir).peIntegrityMetadataValid, true));
  check('tree metadata flag present', () => assert.equal(diagnose(dir).treeIntegrityMetadataValid, true));
  check('packaged tree metadata flag present', () => assert.equal(diagnose(dir).packagedTreeIntegrityMetadataValid, true));
  write('packaged-preview-tree-integrity.json', {...treeProof(), totalBytes: 1999999});
  check('mismatched packaged and delivered metadata blocks completion', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('packaged-preview-tree-integrity.json', treeProof());
  write('delivered-preview-tree-integrity.json', {...treeProof(), fileCount: 99});
  check('malformed delivered tree metadata blocks completion', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('delivered-preview-tree-integrity.json', treeProof());
  write('packaged-executable-integrity.json', { ...peProof(), sha256: 'bad' });
  check('invalid PE hash metadata blocks complete preview evidence', () =>
    assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('packaged-executable-integrity.json', peProof());
  write('renderer-runtime-evidence.json', rendererProof('b'.repeat(32)));
  check('reused renderer nonce rejected', () => assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, false));
  write('renderer-runtime-evidence.json', rendererProof('c'.repeat(32)));
  check('renderer evidence restored', () => assert.equal(diagnose(dir).offlinePreviewEvidenceComplete, true));
  check('delivered proof validity exposed', () => assert.equal(diagnose(dir).deliveredProofValid, true));
  check('even valid preview never authorizes full user testing', () => assert.equal(diagnose(dir).readyForUserTesting, false));
  check('invalid hardware flag rejected', () => assert.equal(validProof({ ...proof('a'.repeat(32)), hardwareAvailable: true }), false));
  fs.unlinkSync(path.join(dir, 'packaged-smoke-evidence.json'));
  fs.symlinkSync(path.join(dir, 'staged-smoke-evidence.json'), path.join(dir, 'packaged-smoke-evidence.json'));
  check('symlink evidence denied', () => assert.equal(diagnose(dir).packagedProofValid, false));
  fs.unlinkSync(path.join(dir, 'packaged-smoke-evidence.json'));
  write('windows-build-transcript.txt', '');
  write('build-outcome.json', outcome('Record packaged Windows PE integrity'));
  check('new PE integrity step is preserved', () =>
    assert.equal(diagnose(dir).lastStep, 'Record packaged Windows PE integrity'));
  check('failed PE integrity classified without relying on stdout', () =>
    assert.equal(diagnose(dir).failureCode, 'packaged-executable-integrity'));
  write('build-outcome.json', outcome('Record delivered preview tree integrity'));
  check('delivered tree integrity failure is classified', () =>
    assert.equal(diagnose(dir).failureCode, 'delivered-tree-integrity'));
  write('build-outcome.json', outcome('Resolve genuine npm lock graph without running scripts'));
  check('lockfile generation failure classified without npm log', () =>
    assert.equal(diagnose(dir).failureCode, 'npm-lockfile-generation-failed'));
  write('build-outcome.json', outcome('Review lock graph constraints'));
  check('rejected lockfile preflight classified without npm log', () =>
    assert.equal(diagnose(dir).failureCode, 'npm-lockfile-preflight-rejected'));
  // Provenance capture and post-install verification must fail closed even
  // when npm leaves no recognizable error text in the cumulative transcript.
  write('windows-build-transcript.txt', '');
  for (const [step, code] of [
    ['Capture preview dependency provenance', 'dependency-provenance-capture-failed'],
    ['Verify preview dependency provenance after npm ci', 'dependency-provenance-verify-failed']
  ]) {
    write('build-outcome.json', outcome(step));
    check(`provenance step failure classified: ${step}`, () =>
      assert.equal(diagnose(dir).failureCode, code));
  }
  const build = fs.readFileSync(path.join(__dirname, '..', 'tools', 'windows-build-offline-preview.ps1'), 'utf8');
  check('all build step labels are allowed for diagnostics', () => {
    const labels = [
      ...[...build.matchAll(/\bStep '([^']+)'/g)].map(match => match[1]),
      ...[...build.matchAll(/\$script:currentStep = '([^']+)'/g)].map(match => match[1])
    ];
    assert(labels.length > 10);
    for (const label of labels) assert(ALLOWED_STEPS.has(label), `Unclassified Windows build step: ${label}`);
  });
  write('windows-build-transcript.txt', 'x'.repeat(200000) + '\nnpm error code ENOTFOUND\n');
  write('build-outcome.json', outcome('Resolve genuine npm lock graph without running scripts'));
  check('bounded log tail catches final DNS error', () => assert.equal(diagnose(dir).failureCode, 'npm-registry-dns'));
  check('untrusted step text suppressed', () => {
    write('build-outcome.json', outcome('C:\\Users\\Private\\secret'));
    assert.equal(diagnose(dir).lastStep, 'unknown');
  });
  console.log(`Windows preview diagnostics regressions: ${count}/${count} passed (offline fixtures only).`);
} finally { fs.rmSync(dir, { recursive: true, force: true }); }
