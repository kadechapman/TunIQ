'use strict';
// Synthetic CSV and filesystem failure injection only. No ECU/OBD/COM operations.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { importPhoneLog } = require('../src/log-import');

function runPhoneLogAtomicOutputSimulations({ quiet = false } = {}) {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-phone-atomic-'));
  const sourceFile = path.join(root, 'phone.csv');
  const contents = 'Time,Engine RPM,VIN\n0,850,SECRET-VIN\n1,900,SECRET-VIN\n';
  fs.writeFileSync(sourceFile, contents);
  const project = { id: 'atomic-test', name: 'Synthetic', folder: path.join(root, 'project') };
  const logs = path.join(project.folder, 'Logs');
  let passed = 0;
  const assertNoOutputs = () => {
    const entries = fs.existsSync(logs) ? fs.readdirSync(logs) : [];
    assert.deepEqual(entries, [], `orphaned or staging output remains: ${entries.join(', ')}`);
    passed++;
  };
  try {
    // Fault during second publish: no CSV may remain without its metadata.
    const realLink = fs.linkSync;
    let linkCalls = 0;
    try {
      fs.linkSync = (...args) => {
        linkCalls++;
        if (linkCalls === 2) throw Object.assign(new Error('synthetic second publish failure'), { code: 'EIO' });
        return realLink(...args);
      };
      assert.throws(() => importPhoneLog({ sourceFile, activeProject: project }), /synthetic second publish failure/); passed++;
    } finally { fs.linkSync = realLink; }
    assert.equal(linkCalls, 2); passed++;
    assertNoOutputs();

    // Fault while staging the metadata: nothing is published.
    const realWrite = fs.writeFileSync;
    let didFail = false;
    try {
      fs.writeFileSync = (file, ...args) => {
        if (!didFail && String(file).endsWith('.meta.json')) {
          didFail = true;
          throw Object.assign(new Error('synthetic metadata stage failure'), { code: 'ENOSPC' });
        }
        return realWrite(file, ...args);
      };
      assert.throws(() => importPhoneLog({ sourceFile, activeProject: project }), /synthetic metadata stage failure/); passed++;
    } finally { fs.writeFileSync = realWrite; }
    assert.equal(didFail, true); passed++;
    assertNoOutputs();

    // Successful import publishes exactly the three expected files.
    const result = importPhoneLog({ sourceFile, activeProject: project });
    assert.equal(fs.existsSync(result.csvPath), true); passed++;
    assert.equal(fs.existsSync(result.metaPath), true); passed++;
    assert.equal(fs.existsSync(result.reportPath), true); passed++;
    assert.equal(fs.readdirSync(logs).length, 3); passed++;
    const csv = fs.readFileSync(result.csvPath, 'utf8');
    assert(csv.includes('850') && !csv.includes('SECRET-VIN')); passed++;
    const meta = JSON.parse(fs.readFileSync(result.metaPath, 'utf8'));
    const report = JSON.parse(fs.readFileSync(result.reportPath, 'utf8'));
    assert.equal(meta.csvPath, result.csvPath); passed++;
    assert.equal(report.sourceFileSha256, crypto.createHash('sha256').update(contents).digest('hex')); passed++;

    // The publication primitive must never replace a preexisting destination.
    // Simulate a competing creator of the first output immediately before link.
    const before = fs.readdirSync(logs);
    let collisionPath;
    try {
      fs.linkSync = (stage, target) => {
        if (!collisionPath) {
          collisionPath = target;
          realWrite(target, 'OTHER OWNER\n', { flag: 'wx' });
        }
        return realLink(stage, target);
      };
      assert.throws(() => importPhoneLog({ sourceFile, activeProject: project }), /EEXIST|exist/i); passed++;
    } finally { fs.linkSync = realLink; }
    assert.equal(fs.readFileSync(collisionPath, 'utf8'), 'OTHER OWNER\n'); passed++;
    const after = fs.readdirSync(logs);
    assert.deepEqual(after.sort(), [...before, path.basename(collisionPath)].sort()); passed++;

    if (!quiet) console.log(`✓ Phone-log atomic output: ${passed} local-only checks passed (no hardware)`);
    return { passed, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) runPhoneLogAtomicOutputSimulations();
module.exports = { runPhoneLogAtomicOutputSimulations };
