/* Portable native unit tests for the Windows launcher's UTF-16 TEMP guard.
 * Running this on Linux is NOT native Windows execution or Electron testing.
 */
#include <stdio.h>
#include <string.h>
#include "../tools/windows-standalone-temp-path.h"
static int cases = 0;
static int check(const char *path, int expected) {
  unsigned short utf16[32768];
  size_t i, n = strlen(path);
  if (n >= 32768) return 1;
  for (i = 0; i <= n; i++) utf16[i] = (unsigned char)path[i];
  int actual = tuniq_local_temp_path(utf16, (unsigned long)n);
  cases++;
  if (actual != expected) {
    fprintf(stderr, "FAIL path case %d (expected %d, got %d)\n", cases, expected, actual);
    return 1;
  }
  return 0;
}
/* Windows also reserves COM/LPT names using superscript 1, 2, and 3.
 * Construct UTF-16 code units directly; Linux wchar_t is not UTF-16. */
static int check_superscript_device(const char *stem, unsigned short digit, int expected) {
  unsigned short path[] = {'C', ':', '\\', 0, 0, 0, digit, '\\', 0};
  path[3] = (unsigned char)stem[0];
  path[4] = (unsigned char)stem[1];
  path[5] = (unsigned char)stem[2];
  int actual = tuniq_local_temp_path(path, 8);
  cases++;
  if (actual != expected) {
    fprintf(stderr, "FAIL UTF-16 superscript device case %d (expected %d, got %d)\n", cases, expected, actual);
    return 1;
  }
  return 0;
}
/* Check raw UTF-16, including surrogate pairs not representable by the
 * bytewise ASCII test helper. These are portable C tests, not Win32 tests. */
static int check_utf16(const unsigned short *path, unsigned long len, int expected) {
  int actual = tuniq_local_temp_path(path, len);
  cases++;
  if (actual != expected) {
    fprintf(stderr, "FAIL UTF-16 path case %d (expected %d, got %d)\n", cases, expected, actual);
    return 1;
  }
  return 0;
}
int main(void) {
  int errors = 0;
  errors += check("C:\\Users\\Public\\Temp\\", 1);
  errors += check("z:\\Temp\\", 1);
  errors += check("C:\\", 1);
  errors += check("\\\\server\\share\\Temp\\", 0);
  errors += check("\\\\?\\C:\\Temp\\", 0);
  errors += check("\\\\.\\C:\\Temp\\", 0);
  errors += check("Temp\\", 0);
  errors += check("C:Temp\\", 0);
  errors += check("C:/Temp/", 0);
  errors += check("C:\\Temp\\..\\", 0);
  errors += check("C:\\Temp\\.\\", 0);
  errors += check("C:\\Temp:stream\\", 0);
  errors += check("C:\\Te\nmp\\", 0);
  errors += check("C:\\Temp", 0);
  errors += check("C:\\Temp\\\\", 0);
  errors += check("1:\\Temp\\", 0);
  errors += check("", 0);
  /* Win32 device names, canonicalization aliases and forbidden characters. */
  errors += check("C:\\Temp.\\", 0);
  errors += check("C:\\Temp \\", 0);
  errors += check("C:\\CON\\", 0);
  errors += check("C:\\con.txt\\", 0);
  errors += check("C:\\PRN\\", 0);
  errors += check("C:\\AUX\\", 0);
  errors += check("C:\\NUL.txt\\", 0);
  errors += check("C:\\COM1\\", 0);
  errors += check("C:\\COM9.log\\", 0);
  errors += check("C:\\LPT1\\", 0);
  errors += check("C:\\LPT9.txt\\", 0);
  errors += check("C:\\Temp?\\", 0);
  errors += check("C:\\Temp*\\", 0);
  errors += check("C:\\Temp|\\", 0);
  errors += check("C:\\Temp<\\", 0);
  errors += check("C:\\Temp>\\", 0);
  errors += check("C:\\Temp\"\\", 0);
  errors += check("C:\\CON .txt\\", 0);
  errors += check("C:\\NUL  .cfg\\", 0);
  errors += check("C:\\LPT1 .log\\", 0);
  errors += check("C:\\Folder .txt\\", 1);
  errors += check("C:\\CONIN$\\", 0);
  errors += check("C:\\CONOUT$\\", 0);
  errors += check_superscript_device("COM", 0x00b9, 0);
  errors += check_superscript_device("COM", 0x00b2, 0);
  errors += check_superscript_device("COM", 0x00b3, 0);
  errors += check_superscript_device("LPT", 0x00b9, 0);
  errors += check_superscript_device("LPT", 0x00b2, 0);
  errors += check_superscript_device("LPT", 0x00b3, 0);
  const unsigned short high_surrogate[] = {'C', ':', '\\', 0xD800, '\\', 0};
  const unsigned short low_surrogate[] = {'C', ':', '\\', 0xDC00, '\\', 0};
  const unsigned short valid_surrogate_pair[] = {'C', ':', '\\', 0xD83D, 0xDE80, '\\', 0};
  const unsigned short reserved_superscript_space[] = {'C', ':', '\\', 'C', 'O', 'M', 0x00B2, ' ', '.', 't', 'x', 't', '\\', 0};
  errors += check_utf16(high_surrogate, 5, 0);
  errors += check_utf16(low_surrogate, 5, 0);
  errors += check_utf16(valid_surrogate_pair, 6, 1);
  errors += check_utf16(reserved_superscript_space, 13, 0);
  errors += check("C:\\COM10\\", 1);
  errors += check("C:\\CONTEXT\\", 1);
  if (tuniq_local_temp_path(0, 0)) errors++;
  cases++;
  if (errors) return 1;
  printf("STANDALONE_TEMP_PATH_NATIVE_FIXTURES %d/%d PASS (Linux unit tests; NOT Windows runtime)\n", cases, cases);
  return 0;
}
