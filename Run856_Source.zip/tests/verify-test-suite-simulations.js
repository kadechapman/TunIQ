'use strict';
const assert = require('assert');
const { Writable } = require('stream');
const { runSuite } = require('../tools/verify-test-suite');
const fs = require('fs');
const path = require('path');
const required = require('./suite-progress-required.json');
const banner = 'All TunIQ 1.9.0-beta.108 Structured Read Integrity Status Guard automated tests passed (76 groups).';
const groups = [...required.map(label => `✓ ${label}`),
  ...Array.from({ length: 76 - required.length }, (_, index) => `✓ verified extra group ${index + 1}`)];
const validOutput = [...groups, banner].join('\n');
function sink() { return new Writable({ write(_chunk, _encoding, callback) { callback(); } }); }
async function run(code, timeoutMs = 1200) {
  return runSuite(process.execPath, ['-e', code], { timeoutMs, output: sink(), errors: sink() });
}
async function main() {
  const success = await run(`console.log(${JSON.stringify(validOutput)})`);
  assert.equal(success.progressCount, 76);
  assert.equal(success.requiredCount, required.length);
  assert.equal(success.missingRequiredCount, 0);
  assert.equal(success.ok, true);
  assert.equal(success.reason, 'passed');
  // A successful child may exit after writing the final banner without a newline.
  // The verifier must consume the last stdout line on close, not only newline-terminated lines.
  // Regression: the previous permissive banner regex accepted a fabricated
  // version/name after otherwise valid progress, incorrectly certifying it.
  const wrongBuildBanner = 'All TunIQ 0.0.0 WRONG VERSION automated tests passed (76 groups).';
  const wrongBuild = await run(`console.log(${JSON.stringify([...groups, wrongBuildBanner].join('\n'))})`);
  assert.equal(wrongBuild.ok, false, 'wrong-version banner must not certify the current suite');
  assert.equal(wrongBuild.reason, 'missing-success-banner');
  // Regression: diagnostics after a valid success banner were silently ignored.
  const trailingFailure = await run(`console.log(${JSON.stringify(validOutput + '\nFAILURE: after banner')})`);
  assert.equal(trailingFailure.ok, false, 'post-banner diagnostic must fail closed');
  assert.equal(trailingFailure.reason, 'output-after-success-banner');
  const trailingProgress = await run(`console.log(${JSON.stringify(validOutput + '\n✓ unexpected post-banner group')})`);
  assert.equal(trailingProgress.ok, false, 'post-banner progress must fail closed');
  const trailingBlank = await run(`console.log(${JSON.stringify(validOutput + '\n')})`);
  assert.equal(trailingBlank.ok, true, 'blank lines after success remain harmless');
  const noFinalNewline = await run(`process.stdout.write(${JSON.stringify(validOutput)})`);
  assert.equal(noFinalNewline.ok, true, 'unterminated final success banner must count on clean exit');
  assert.equal(noFinalNewline.progressCount, 76);
  const noFinalGroupNewline = await run(`process.stdout.write(${JSON.stringify(groups.join('\n'))})`);
  assert.equal(noFinalGroupNewline.progressCount, 76, 'unterminated final group must be observed on close');
  assert.equal(noFinalGroupNewline.ok, false, 'groups without a banner cannot certify success');
  const noFinalNewlineOnStderr = await run(`process.stdout.write(${JSON.stringify(groups.join('\n') + '\n')}); process.stderr.write(${JSON.stringify(banner)})`);
  assert.equal(noFinalNewlineOnStderr.ok, false, 'stderr banner must never certify success');
  const noFinalNewlineFailed = await run(`process.stdout.write(${JSON.stringify(validOutput)}); process.exit(5)`);
  assert.equal(noFinalNewlineFailed.ok, false, 'failed child cannot be certified by an unterminated banner');
  // Regression: Run48 accepted 76 unrelated progress lines and a banner.
  // All named safety milestones must be observed before success is certified.
  const unrelated = Array.from({ length: 76 }, (_, i) => `✓ fabricated group ${i + 1}`);
  const fake = await run(`console.log(${JSON.stringify([...unrelated, banner].join('\n'))})`);
  assert.equal(fake.ok, false);
  assert.equal(fake.reason, 'missing-required-groups');
  assert.equal(fake.missingRequiredCount, required.length);
  // Regression: previously 76 valid groups plus unlimited unrelated labels
  // and a banner were accepted, while every unrelated label was retained.
  const tooManyGroups = [...groups, ...Array.from({ length: 129 }, (_, i) => `✓ unrelated ${i}`), banner];
  const runaway = await run(`console.log(${JSON.stringify(tooManyGroups.join('\n'))})`);
  assert.equal(runaway.ok, false, 'runaway progress cannot certify a suite');
  assert.equal(runaway.reason, 'excessive-group-progress');
  assert.equal(runaway.progressCount, 128, 'unique progress must be capped');
  const atCap = await run(`console.log(${JSON.stringify([
    ...groups, ...Array.from({ length: 128 - groups.length }, (_, i) => `✓ optional ${i}`), banner
  ].join('\n'))})`);
  assert.equal(atCap.ok, true, '128 distinct groups are permitted');
  const oversizedLabel = await run(`console.log(${JSON.stringify([
    ...groups, `✓ ${'Z'.repeat(513)}`, banner
  ].join('\n'))})`);
  assert.equal(oversizedLabel.ok, false, 'oversized labels cannot certify a suite');
  assert.equal(oversizedLabel.reason, 'oversized-group-label');
  const partialRequired = await run(`console.log(${JSON.stringify([
    ...groups.filter(line => line !== `✓ ${required[0]}`), '✓ unrelated substitute', banner
  ].join('\n'))})`);
  assert.equal(partialRequired.ok, false);
  assert.equal(partialRequired.reason, 'missing-required-groups');
  assert.equal(partialRequired.missingRequiredCount, 1);
  // Keep the independent manifest synchronized with the suite's named passes.
  const suiteSource = fs.readFileSync(path.join(__dirname, 'run-tests.js'), 'utf8');
  const staticPasses = [...suiteSource.matchAll(/\bpass\('((?:\\.|[^'\\])*)'\)/g)]
    .map(match => match[1]);
  assert.deepEqual([...required].sort(), staticPasses.sort());
  const missing = await run("console.log('other tests passed')");
  assert.equal(missing.ok, false);
  assert.equal(missing.reason, 'missing-success-banner');
  const failing = await run(`console.log(${JSON.stringify(validOutput)}); process.exit(7)`);
  assert.equal(failing.ok, false);
  assert.equal(failing.reason, 'exit-failure');
  const hanging = await run(`console.log(${JSON.stringify(validOutput)}); setInterval(()=>{},10000)`, 200);
  assert.equal(hanging.ok, false);
  assert.equal(hanging.reason, 'timeout');
  const invalid = await run('process.exit(0)', 200);
  assert.equal(invalid.ok, false);
  // Regression: a grandchild inherits the suite pipes, so killing the suite
  // process does not immediately deliver `close`. The verifier must still
  // return a failure within the requested deadline plus scheduling margin.
  const inheritedPipeCode = `
    require('child_process').spawn(process.execPath,
      ['-e', 'setTimeout(() => {}, 1600)'],
      { stdio: ['ignore', process.stdout, process.stderr] });
    console.log(${JSON.stringify(validOutput)});
    setInterval(() => {}, 10000);
  `;
  const started = Date.now();
  const inheritedPipe = await run(inheritedPipeCode, 150);
  const elapsed = Date.now() - started;
  assert.equal(inheritedPipe.ok, false);
  assert.equal(inheritedPipe.reason, 'timeout');
  assert.ok(elapsed < 1000, `Timeout must settle without waiting for inherited pipes (${elapsed} ms)`);
  assert.throws(() => runSuite(process.execPath, [], { timeoutMs: -1 }), /Invalid suite timeout/);
  assert.throws(() => runSuite(process.execPath, [], { idleTimeoutMs: 0 }), /Invalid suite idle timeout/);
  // A child can keep writing noise without completing any test group.
  // Such output must not extend the no-progress deadline.
  const noise = await runSuite(process.execPath, ['-e',
    "setInterval(() => console.log('still running'), 15)"],
    { timeoutMs: 1500, idleTimeoutMs: 180, output: sink(), errors: sink() });
  assert.equal(noise.ok, false);
  assert.equal(noise.reason, 'idle-timeout');
  assert.equal(noise.lastGroup, null);
  // Regression: a child can print fresh, unrelated checkmarks indefinitely.
  // Those are not verified progress and must NOT postpone the idle deadline.
  const unrelatedTicks = await runSuite(process.execPath, ['-e',
    "let n=0;setInterval(()=>console.log('✓ unrelated fake milestone '+(++n)),35)"],
    { timeoutMs: 1000, idleTimeoutMs: 180, output: sink(), errors: sink() });
  assert.equal(unrelatedTicks.reason, 'idle-timeout',
    'unrecognized checkmarks must not extend the verified-progress deadline');
  assert.equal(unrelatedTicks.requiredCount, 0);
  // A single real milestone repeated over and over is not new progress.
  const repeatedMilestone = await runSuite(process.execPath, ['-e',
    `setInterval(()=>console.log(${JSON.stringify('✓ ' + required[0])}),35)`],
    { timeoutMs: 1000, idleTimeoutMs: 180, output: sink(), errors: sink() });
  assert.equal(repeatedMilestone.reason, 'idle-timeout',
    'duplicate real milestones must not extend the verified-progress deadline');
  assert.equal(repeatedMilestone.requiredCount, 1);
  // The last completed group is recorded when a later group stalls.
  const stalled = await runSuite(process.execPath, ['-e',
    "console.log('✓ last successful safety group'); setInterval(() => {}, 1000)"],
    { timeoutMs: 1500, idleTimeoutMs: 200, output: sink(), errors: sink() });
  assert.equal(stalled.reason, 'idle-timeout');
  assert.equal(stalled.lastGroup, 'last successful safety group');
  assert.equal(stalled.progressCount, 1);
  // Regression: an idle suite previously emitted no intermediate diagnostic,
  // making an interrupted CI run indistinguishable from a silent stall.
  // Heartbeats are diagnostic-only: they cannot refresh the idle deadline.
  let diagnostics = '';
  const diagnosticSink = new Writable({ write(chunk, _encoding, callback) { diagnostics += chunk.toString(); callback(); } });
  const pending = await runSuite(process.execPath, ['-e',
    `console.log(${JSON.stringify('✓ ' + required[0])}); setInterval(() => {}, 1000)`],
    { timeoutMs: 1500, idleTimeoutMs: 260, diagnosticIntervalMs: 60,
      output: sink(), errors: diagnosticSink });
  assert.equal(pending.ok, false);
  assert.equal(pending.reason, 'idle-timeout');
  assert.equal(pending.requiredCount, 1);
  assert.match(diagnostics, /Suite pending \(NOT VERIFIED\): elapsedMs=\d+, idleMs=\d+, required=1\//);
  assert.match(diagnostics, /lastGroup=/);
  assert.match(diagnostics, /reason=idle-timeout/);
  assert.throws(() => runSuite(process.execPath, [], { diagnosticIntervalMs: 0 }), /Invalid suite diagnostic interval/);
  // Real, distinct required milestones continue to refresh the idle deadline.
  const progressingCode = `const groups=${JSON.stringify(required.slice(0, 4))};let n=0;const timer=setInterval(()=>{console.log('✓ '+groups[n++]);if(n===groups.length){clearInterval(timer);console.log(${JSON.stringify(banner)})}},70)`;
  const progressing = await runSuite(process.execPath, ['-e', progressingCode],
    { timeoutMs: 1500, idleTimeoutMs: 200, output: sink(), errors: sink() });
  assert.equal(progressing.ok, false);
  assert.equal(progressing.reason, 'insufficient-group-progress');
  assert.equal(progressing.progressCount, 4);
  assert.equal(progressing.requiredCount, 4);
  assert.equal(progressing.lastGroup, required[3]);
  // Regression: Run42 trusted a banner alone (even on stderr) with exit 0.
  const bannerOnly = await run(`console.log(${JSON.stringify(banner)})`);
  assert.equal(bannerOnly.ok, false);
  assert.equal(bannerOnly.reason, 'insufficient-group-progress');
  const stderrOnly = await run(`console.error(${JSON.stringify(validOutput)})`);
  assert.equal(stderrOnly.ok, false);
  assert.equal(stderrOnly.reason, 'missing-success-banner');
  const embeddedBanner = await run(`console.log(${JSON.stringify(groups.join('\n'))}); console.log('PREFIX ' + ${JSON.stringify(banner)})`);
  assert.equal(embeddedBanner.ok, false);
  assert.equal(embeddedBanner.reason, 'missing-success-banner');
  const tooFew = await run(`console.log(${JSON.stringify([...groups.slice(0, 75), banner].join('\n'))})`);
  assert.equal(tooFew.ok, false);
  assert.equal(tooFew.reason, 'insufficient-group-progress');
  const repeated = await run(`console.log(${JSON.stringify(Array(76).fill(groups[0]).concat(banner).join('\n'))})`);
  assert.equal(repeated.ok, false);
  assert.equal(repeated.progressCount, 1);
  const premature = await run(`console.log(${JSON.stringify([banner, ...groups].join('\n'))})`);
  assert.equal(premature.ok, false);
  assert.equal(premature.reason, 'premature-success-banner');
  // Regression Run73: the verifier previously accepted an early banner if
  // a second valid banner followed all required groups. Never launder an
  // early success claim into a passing result.
  const earlyThenValid = await run(`console.log(${JSON.stringify([banner, ...groups, banner].join('\n'))})`);
  assert.equal(earlyThenValid.ok, false, 'early banner cannot be repaired by a later banner');
  assert.equal(earlyThenValid.reason, 'premature-success-banner');
  const repeatedEarlyThenValid = await run(`console.log(${JSON.stringify([banner, banner, ...groups, banner].join('\n'))})`);
  assert.equal(repeatedEarlyThenValid.ok, false, 'repeated early banners must remain disqualifying');
  assert.equal(repeatedEarlyThenValid.reason, 'premature-success-banner');
  const splitUnicode = await run(`const b=Buffer.from(${JSON.stringify(validOutput + '\n')}); for (let i=0;i<b.length;i++) process.stdout.write(b.subarray(i,i+1));`);
  assert.equal(splitUnicode.ok, true);
  assert.equal(splitUnicode.progressCount, 76);
  const splitStreams = await run(`process.stderr.write('All TunIQ fake '); console.log(${JSON.stringify(validOutput)}); process.stderr.write('automated tests passed (76 groups).\\n');`);
  assert.equal(splitStreams.ok, true);
  assert.equal(splitStreams.progressCount, 76);
  console.log('Suite exit verification simulations: 36/36 passed');
}
if (require.main === module) main().catch(e => { console.error(e); process.exitCode = 1; });
module.exports = { main };
