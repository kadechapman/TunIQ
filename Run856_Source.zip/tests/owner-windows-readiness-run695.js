'use strict';
const assert = require('node:assert/strict');
const path = require('node:path');
const Module = require('node:module');
const source = path.resolve(__dirname, '../tools/owner-windows-readiness-run687.js');
const reviewPath = require.resolve('../src/p01-request-review');
const original = require.cache[reviewPath];
const fake = new Module(reviewPath);
fake.filename = reviewPath;
fake.loaded = true;
fake.exports = { reviewP01Request: () => ({ready:true, unresolvedRequests:null, missingSafetyFacts:null}) };
require.cache[reviewPath] = fake;
delete require.cache[source];
try {
  const {inspect, exitCodeFor} = require(source);
  const report = inspect(path.resolve(__dirname,'..'), {id:'fixture',controller:'P01',os:'unknown'}, 'Review VATS');
  assert.equal(report.readyForUserTesting,false);
  assert.equal(report.readyForPublicRelease,false);
  assert.equal(report.ecmWriteAuthorized,false);
  assert.equal(report.owner.ready,false);
  assert.equal(report.owner.requestReviewReady,false);
  assert.match(report.owner.reviewError,/invalid result/);
  assert.deepEqual(report.owner.unresolvedTypes,[]);
  assert.ok(report.owner.missingSafetyFacts.length > 0);
  assert.equal(exitCodeFor(report),2);
  assert.ok(Object.values(report.owner.calibrationGates).every(v=>v===false));
  console.log('Run695: 10 malformed-review fail-closed assertions passed');
} finally {
  delete require.cache[source];
  if(original) require.cache[reviewPath]=original;
  else delete require.cache[reviewPath];
}
