'use strict';
// Filesystem-only packaging tests. Uses disposable Git fixtures; never contacts hardware.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { inspectSourceExport } = require('../tools/source-export-parity');
function git(cwd, ...args) {
  const p = spawnSync('git', args, { cwd, encoding: 'utf8', windowsHide: true });
  assert.equal(p.status, 0, `git ${args.join(' ')}: ${p.stderr}`);
  return p.stdout.trim();
}
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-source-export-'));
try {
  const repo = path.join(temp, 'repo'), exported = path.join(temp, 'export');
  fs.mkdirSync(repo); fs.mkdirSync(exported);
  git(repo, 'init', '-q'); git(repo, 'config', 'user.email', 'fixture@example.invalid');
  git(repo, 'config', 'user.name', 'Fixture');
  fs.mkdirSync(path.join(repo, 'src'));
  fs.writeFileSync(path.join(repo, 'src', 'main.js'), 'module.exports = 1;\n');
  fs.writeFileSync(path.join(repo, 'package.json'), '{"private":true}\n');
  git(repo, 'add', '.'); git(repo, 'commit', '-qm', 'fixture');
  const commit = git(repo, 'rev-parse', 'HEAD');
  fs.mkdirSync(path.join(exported, 'src'));
  for (const file of ['src/main.js', 'package.json']) {
    fs.copyFileSync(path.join(repo, file), path.join(exported, file));
  }
  let result = inspectSourceExport(repo, exported, commit);
  assert.equal(result.passed, true); assert.equal(result.matchedFiles, 2);
  fs.writeFileSync(path.join(exported, 'src', 'main.js'), 'module.exports = 2;\n');
  result = inspectSourceExport(repo, exported, commit);
  assert.equal(result.passed, false); assert(result.issues.some(i => i.code === 'content-mismatch'));
  fs.copyFileSync(path.join(repo, 'src', 'main.js'), path.join(exported, 'src', 'main.js'));
  fs.writeFileSync(path.join(exported, 'extra.txt'), 'not tracked\n');
  result = inspectSourceExport(repo, exported, commit);
  assert.equal(result.passed, false); assert(result.issues.some(i => i.code === 'extra-file'));
  fs.unlinkSync(path.join(exported, 'extra.txt'));
  fs.unlinkSync(path.join(exported, 'package.json'));
  result = inspectSourceExport(repo, exported, commit);
  assert.equal(result.passed, false); assert(result.issues.some(i => i.code === 'missing-file'));
  fs.copyFileSync(path.join(repo, 'package.json'), path.join(exported, 'package.json'));
  // A source tree that changes after the commit must not be treated as the export authority.
  fs.writeFileSync(path.join(repo, 'src', 'main.js'), 'module.exports = 3;\n');
  result = inspectSourceExport(repo, exported, commit);
  assert.equal(result.passed, true, 'comparison must use committed Git blobs, not dirty worktree');
  if (process.platform !== 'win32') {
    fs.unlinkSync(path.join(exported, 'src', 'main.js'));
    fs.symlinkSync(path.join(repo, 'src', 'main.js'), path.join(exported, 'src', 'main.js'));
    result = inspectSourceExport(repo, exported, commit);
    assert.equal(result.passed, false); assert(result.issues.some(i => i.code === 'unsafe-entry'));
  }
  console.log('Source export parity fixtures passed: clean, changed, extra, missing, committed authority, symlink.');
} finally { fs.rmSync(temp, { recursive: true, force: true }); }
