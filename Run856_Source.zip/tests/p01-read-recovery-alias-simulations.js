'use strict';
// Offline filesystem regression only. No COM access, PCM Hammer, or ECU writes.
const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { P01CommissioningManager, P01_BIN_SIZE } = require('../src/p01-commissioning');

function runP01ReadRecoveryAliasSimulations() {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-read-recovery-alias-'));
  let passed = 0;
  let symlinkSkipped = false;
  try {
    function fixture(name) {
      const folder = path.join(root, name);
      fs.mkdirSync(folder, { recursive: true });
      const active = { id: name, name, controller: 'P01', os: '9379910', folder };
      const manager = new P01CommissioningManager({ getActiveProject: () => active });
      manager.recordIdentity({ controller: 'P01', os: '9379910', hardwareId: 'synthetic-hw', serviceNumber: 'synthetic-svc' });
      const first = path.join(folder, 'first.bin');
      const second = path.join(folder, 'second.bin');
      const contents = Buffer.alloc(P01_BIN_SIZE, 0x42);
      fs.writeFileSync(first, contents);
      fs.writeFileSync(second, contents);
      manager.recordRead(first, {}, { id: `${name}-session-one`, proofSource: `${name}-source-one` });
      manager.recordRead(second, {}, { id: `${name}-session-two`, proofSource: `${name}-source-two` });
      assert.equal(manager.status().dualReadVerified, true);
      const damaged = manager.load();
      damaged.readPair = null;
      delete damaged.canonicalReadSha256;
      delete damaged.canonicalReadPath;
      delete damaged.dualReadVerifiedAt;
      manager.save(damaged);
      return { manager, first, second };
    }

    const hardlink = fixture('hardlink');
    fs.unlinkSync(hardlink.second);
    fs.linkSync(hardlink.first, hardlink.second);
    assert.equal(hardlink.manager.repairVerifiedReadPair('hardlink alias').repaired, false,
      'two ledger sessions must not recover when paths are hardlinks to one BIN');
    assert.equal(hardlink.manager.status().dualReadVerified, false); passed++;

    const symlink = fixture('symlink');
    fs.unlinkSync(symlink.second);
    try {
      fs.symlinkSync(symlink.first, symlink.second, 'file');
      assert.equal(symlink.manager.repairVerifiedReadPair('symlink alias').repaired, false,
        'two ledger sessions must not recover through a symbolic link');
      assert.equal(symlink.manager.status().dualReadVerified, false); passed++;
    } catch (error) {
      if (!['EPERM', 'EACCES', 'ENOTSUP'].includes(error.code)) throw error;
      symlinkSkipped = true; // Some Windows test hosts lack symlink privileges.
    }

    const missing = fixture('missing');
    fs.unlinkSync(missing.second);
    assert.equal(missing.manager.repairVerifiedReadPair('missing file').repaired, false,
      'missing saved evidence must not restore a verified pair'); passed++;

    const independent = fixture('independent');
    const result = independent.manager.repairVerifiedReadPair('independent evidence');
    assert.equal(result.repaired, true, 'separate regular files with saved sessions should remain recoverable');
    assert.equal(result.status.dualReadVerified, true); passed++;

    console.log(`✓ P01 saved-read alias recovery: ${passed} offline assertions passed${symlinkSkipped ? ' (symlink check unavailable on this host)' : ''}`);
    return { passed, symlinkSkipped, hardwareVerified: false };
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
}
if (require.main === module) runP01ReadRecoveryAliasSimulations();
module.exports = { runP01ReadRecoveryAliasSimulations };
