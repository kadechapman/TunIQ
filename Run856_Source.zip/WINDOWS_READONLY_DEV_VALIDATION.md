# TunIQ write-disabled Windows validation kit (source checkpoint)

**This is not a runnable TunIQ release, nor authorization to connect to an ECU.**

The project's checked-in `package-lock.json` is currently missing. Electron and the Windows installer were **not** verified during creation of this kit. Do not plug in an OBDLink, attach a COM adapter to a vehicle, start `src/main.js`, run `npm start`, or perform Test Write/flash operations.

## Running on a Windows development computer

1. Extract the verified source ZIP to an ordinary local folder (not a network drive). Install Node.js 20+ and ensure `node.exe` and `npm.cmd` work in PowerShell. Use trusted network access to `registry.npmjs.org` and the Electron binary distribution, or the dependency stage cannot finish.
2. Start PowerShell in the extracted source folder and run `powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1 -PrepareOnly`. It checks the original source and tests, then creates an isolated temporary copy and resolves a **candidate** lockfile. The candidate is saved at `dev-build-output\package-lock.candidate.json`. **Review it**; it is not automatically promoted to a trusted checked-in `package-lock.json`.
3. Run `powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1` to repeat source checks, resolve/validate dependencies in an isolated copy, attempt `npm ci`, and run the **hardware-isolated** Electron renderer smoke test. It never runs the ECU-capable main process or produces an installer.
4. Keep the tool output for review. A nonzero exit code or an isolated renderer failure means the kit has **not** passed. Even success only proves the specific offline checks and isolated renderer test; it does not establish that the real Windows application starts or that production/physical ECU behavior is safe.

The isolated renderer test supplies five synthetic, read-only startup IPC responses. It does not invoke production `src/main.js`, expose device handlers, or certify real application startup.

The script does not modify the original `package.json`, readiness snapshot, or source manifest. Its dependency candidate is intentionally outside the tracked project path. It is essential to review that candidate and create a new auditable source checkpoint before attempting any normal desktop-app startup.

## Constraints

- **No automatic ECU reads, writes, Test Writes, flashes, or hardware IPC handlers.**
- **No full desktop-app startup and no installer packaging.**
- A genuine `npm ci` and native Electron runtime test must be evidenced on Windows before the relevant milestones can be counted.
- Physical-device testing, privacy/redistribution review, production signing, and incident-response checks remain separate release gates.
- `READY FOR USER TESTING` cannot be claimed from this kit alone.

## Run116: bounded native renderer proof and troubleshooting

The operator validation script no longer treats a bare `npm run test:renderer-runtime`
exit code as proof of native Windows startup. After a genuine lockfile and
`npm ci`, it launches `node_modules\electron\dist\electron.exe` directly with
a 45-second deadline, a fresh per-run nonce, and a unique evidence path. It
rejects missing, stale, incomplete, or unsuccessful renderer evidence even
if the process exits zero. The script always restores the two renderer-evidence
environment variables after the attempt.

A unique folder under `dev-build-output\Readonly-Validation-<guid>\` preserves
npm's own debug logs from both lockfile resolution and `npm ci`, plus
`renderer-runtime.stdout.log`, `renderer-runtime.stderr.log`, and (when emitted)
`renderer-runtime-evidence.json`. The folder path is printed before registry
access. Raw npm and Electron logs may contain local paths or private system
information; review them before sharing. A failure to produce native renderer
proof does **not** imply that the complete TunIQ application is runnable.

On Windows, with all ECU/OBD hardware physically disconnected, run:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run check
npm run test:windows-readonly-dev
npm run test:windows-lockfile-generation
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1 -PrepareOnly
powershell -NoProfile -File .\tools\windows-readonly-dev-validation.ps1
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

The final preview command separately attempts staged, packaged, and delivered
native Electron startup, with four distinct proof artifacts. A passing operator
renderer check alone is **not** a full application build, and a passing isolated
preview still cannot authorize ECU Test Write, write, flash, or public release.
