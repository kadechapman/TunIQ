# TunIQ v1.9.0-beta.90 — Typed Device Fallback Exit Guard

Source-only development checkpoint; **not** a runnable Windows installer or public beta.

## Change

The pinned OBDLink `COMx:elm` → plain `COMx` fallback previously accepted a matching text fragment without checking the PCM Hammer process exit code. A signal-terminated process (`exitCode: null`) or an unrelated `Index ... out of range` message could authorize a second CLI attempt when other guards passed. This checkpoint requires an actual numeric nonzero exit and explicit type-hint parser rejection. The existing `close`-event ownership, no-communication, no-output, cancellation, and Full Read destination checks remain mandatory.

## Limits

Only offline Node/Linux synthetic tests were performed. No Windows CLI/kernel, real OBDLink/PCM, physical Full Read, Test Write, write or flash. The guard is not proof of physical COM release. Dependency lockfile, Windows installer, licensing, signing, secure updates, privacy, third-party redistribution, recovery documentation and hardware evidence remain launch blockers.
