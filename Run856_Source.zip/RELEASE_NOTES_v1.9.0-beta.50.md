# TunIQ v1.9.0-beta.50 — Fail-Closed CLI Prefix Metadata Guard

**Source-only checkpoint. Not approved for user testing or public release.**

## Reproduced against verified beta.49

Although beta.49 rejected nonempty array `prefixArgs` at preflight, `resolveExecutable()` still exposed the untrusted prefix array to other callers. A future subprocess path could inadvertently bypass the check. Non-array saved values were silently interpreted as an empty array, and the status interface could report read capability even while the configured CLI was blocked. The new regression failed against unmodified beta.49.

## Changes

- In restricted read-only mode, `resolveExecutable()` returns an empty `prefixArgs` array when the saved prefix is unreviewed, with an explicit `cliPrefixArgsBlocked` flag. The existing preflight/probe/discovery guard now checks that flag, preserving the fail-closed stop.
- Reject malformed saved prefix values (e.g., strings), and reject malformed or nonempty supplied prefix arguments before probe settings are persisted.
- Mark blocked CLI configurations as not configured/integrated and suppress read capabilities in `status()` until prefix arguments are cleared.
- Preserve the explicitly scoped beta.49 synthetic Node mock exception for regression tests. Production `readOnlyBeta: true` continues to override that exception.

## Not verified

No physical ECU/OBDLink MX+ operations, Test Write, calibration write, or flash. No Windows CLI/kernel compatibility test, clean Windows installer, code signing, or physical interrupted-read recovery evidence. A filename check alone does not establish executable authenticity. Do not distribute this source checkpoint as a public beta.
