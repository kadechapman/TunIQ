# TunIQ v1.9.0-beta.107 — Reconciled Sector and Page Read Failure Guard

Source-only development checkpoint, October 17, 2026. **Not ready for user testing or public release.**

## Baseline

Built from the newest Library beta.106 Read Properties Block Failure Identity Guard, not the earlier beta.105 snapshot. Preserves beta.106 rejection of failed blocks during Read Properties and beta.105 failed-block Full Read protection.

## Change

PCM Hammer CLI output can describe memory access errors as failed sectors or pages, not only blocks. In beta.106, messages such as `Failed to read sector 0x1800` or `Read page 128 timeout` followed by `Read completed successfully` with exit code 0 could be accepted.

`src/pcmhammer-integrated.js` now shares an explicit memory-unit failure detector between the CLI runtime retry gate and the Full Read/Read Properties classifier in `src/pcmhammer.js`. Failed sector/page evidence produces `read-unit-failed`; existing failed-block stop codes are preserved. Such failures prohibit automatic command-profile or typed COM fallback.

Offline regressions cover sector/page errors, Read Properties identity admission, rejected full-size synthetic BINs, prohibited automatic retries, and successful memory progress controls. No production ECU-writing functionality changed.

## Limits

This is diagnostic text classification, not independent PCM data integrity or calibration checksum verification. No physical PCM Hammer/OBDLink connection, interrupted physical Full Read, clean Windows installer, or hardware recovery verification was performed. Never initiate a physical PCM Test Write or ECU write/flash from this checkpoint.
