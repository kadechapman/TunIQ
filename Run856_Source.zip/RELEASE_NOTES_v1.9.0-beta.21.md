# TunIQ v1.9.0-beta.21 — Evidence-Backed Hardware Launch Gate

- Fixed launch-gate false positive: support matrix `verified` alone no longer qualifies a controller for public release.
- Requires a private, controller-specific verification manifest and hash-matching, independent read files plus Test Write/recovery logs, reviewed by a named person.
- Invalid/missing/tampered evidence blocks release. Private BINs and logs are not bundled.
- This is a release audit safeguard, not proof of physical hardware performance or permission to flash.
- Physical P01/P59 read, Test Write and write remain unverified in this environment.
