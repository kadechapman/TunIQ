# TunIQ v1.9.0-beta.28 — Stale COM Proof Revocation

**Scope:** P01 guided-state COM proof invalidation; no changes to PCM Hammer binaries, calibration maps, kernels, checksum algorithms, or ECU write implementation.

## Safety correction
Beta.27 could correctly reject a newer conflicting hardware identity in session history, but `recoverP01ProvenHardwareSession()` returned the previous guided state unchanged when no valid proof remained. That state still contained `provenHardwareSession`, `pcmHammerProvenPort`, and `pcmHammerProvenAt`. The next guided hardware payload could inherit the stale claim.

Beta.28 clears those authority fields when reconstructed proof is unavailable, and rechecks the latest history immediately before generating every guided PCM Hammer payload. The user's selected COM port remains available for a fresh Read Properties. A later valid matching session can establish new proof.

## Verification limits
The regression uses synthetic P01 Read Properties history and software-only tests. No physical Windows COM, OBDLink MX+, PCM Full Read, Test Write, or write operation has been performed. Do not use this release as evidence of safe flashing.
