# TunIQ v1.9.0-beta.22 — Launch Snapshot Integrity Gate

- Fixed stale packaged launch snapshot (beta.20 top-level version and beta.19 nested version proof inside beta.21).
- Added `npm run release:snapshot` to generate a conservative source-only launch audit.
- Added `npm run check:snapshot`, automatically invoked by `npm run check`, to reject stale or modified snapshots, including nested details.
- Added regression test for version changes, nested tampering, and hardware-unverified provenance.
- No changes to PCM Hammer, ECU communication, tuning tables, or physical writing.
- Source-only readiness is not hardware certification; full public launch remains blocked.
