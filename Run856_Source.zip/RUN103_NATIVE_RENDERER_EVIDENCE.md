# Run103 — bounded Windows renderer evidence and diagnostics

Run103 is **source-only** until executed on Windows. It does not authorize full TunIQ testing, public release, ECU access, Test Writes, writes, or flashes.

The Windows offline-preview script now runs the isolated renderer directly in installed Electron with a 45-second timeout. It saves `renderer-runtime.stdout.log`, `renderer-runtime.stderr.log`, and a fresh nonce-bound `renderer-runtime-evidence.json`, even when the renderer exits unsuccessfully and a partial proof exists. The script fails closed if native renderer evidence is absent, stale, or unsuccessful. Staged and packaged Electron preview smokes remain mandatory. The GitHub Actions verification step checks all three proofs and requires three distinct nonces. The safe `diagnosis.json` now classifies isolated renderer failures separately.

## Run on Windows 10/11 (Node.js 20+)

Disconnect all ECU/OBD hardware. Extract the complete Run103 source ZIP. In PowerShell at its root:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect the newest `dev-build-output/Run97-Diagnostics-<guid>/` folder for `build-outcome.json`, `diagnosis.json`, `package-lock.candidate.json`, `windows-build-transcript.txt`, `renderer-runtime.stdout.log`, `renderer-runtime.stderr.log`, `renderer-runtime-evidence.json`, `staged-electron.stderr.log`, `staged-smoke-evidence.json`, `packaged-electron.stderr.log`, and `packaged-smoke-evidence.json`. Logs may include local usernames or paths; review before sharing.

A passing result proves only a hardware-isolated **offline UI preview** on that Windows runner. The production `src/main.js` application and ECU-capable functions remain untested. Do not run `npm start`, `dist:win`, or any hardware commands as part of this check.

## GitHub

After reviewing and migrating the complete source to a `dev/**` branch, `.github/workflows/windows-offline-preview-build.yml` can run the same checks on `windows-latest` and retain diagnostics. No CI result exists until that workflow actually runs.
