# TunIQ v1.9.0-beta.102 — Kernel Transfer Failure Evidence Guard

Source-only development checkpoint, **not ready for user testing or public release**.

## Offline safety fix

PCM Hammer may emit a kernel upload/load/execute/start/transfer failure, followed by a success footer or OSID, and report numeric exit zero. Prior source beta.101 could incorrectly accept this contradictory read-only result. The classifier now treats a kernel transfer failure diagnostic on a single log line as disqualifying evidence and emits `kernel-transfer-failed`. The Full Read BIN verifier therefore rejects otherwise complete-size synthetic BIN files when this stop is present. Existing protections remain.

## Verification boundaries

Regression scenarios use synthetic CLI strings only; they do not start PCM Hammer, open COM ports, contact an ECU, Test Write, write or flash. Linux tests cannot prove native Windows kernel compatibility, COM handle release, or physical interrupted Full Read recovery.

## Public-release blockers

Missing authentic dependency lockfile, license decision, secure update feed, signed Windows installer, clean Windows install, physical hardware evidence, privacy review, third-party redistribution review, and incident response/recovery signoff. Exact-OS definitions, checksums, protected backup binding and AI tuning restrictions also require qualification.
