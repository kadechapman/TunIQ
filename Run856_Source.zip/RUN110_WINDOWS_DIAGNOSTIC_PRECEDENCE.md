# Run110 — Windows build diagnosis uses the failed step, not stale npm errors

This is a source-only, hardware-disconnected change. It does **not** establish
Windows startup, a runnable full TunIQ build, or release readiness.

## Reproduced defect

`windows-build-transcript.txt` accumulates earlier steps. With a failed
`Delivered Windows executable smoke` outcome and an old `npm error code
EAI_AGAIN` line followed by `Delivered preview smoke timed out`, the Run109
classifier returned `npm-registry-dns`. That diagnosis incorrectly directed a
Windows tester to DNS troubleshooting instead of the failed copied executable.

## Correction

For explicitly allowlisted, non-network build stages, the last failed step
now determines a fixed, secret-free failure code and next action. This covers
source checks, read-only admission, isolated renderer, staged, packaged and
copied executable smoke, and PE integrity. Network/DNS/TLS classification
remains available for genuine npm lockfile and installation steps. New offline
fixtures test cumulative stale npm errors and previously log-free preflights.

The classifier still never grants full TunIQ readiness, never exposes raw
transcript paths or environment variables, and cannot replace actual Windows
startup evidence. No ECU/OBD or write/flash source was modified.

## Actual Windows handoff

On Windows 10/11 with Node.js 20+ and npm/GitHub Electron download access,
extract the verified source archive into a clean directory, disconnect all ECU
and OBD hardware, and run in PowerShell:

```powershell
node --version
npm --version
npm ping --registry=https://registry.npmjs.org/
npm run test:windows-preview-diagnostics
powershell -NoProfile -File .\tools\windows-build-offline-preview.ps1
```

Inspect `dev-build-output/Run97-Diagnostics-<guid>/diagnosis.json`,
`build-outcome.json`, `windows-build-transcript.txt`, and the four native smoke
logs/evidence files. A passing build verifies only the offline UI preview,
**not** the ECU-capable application.
