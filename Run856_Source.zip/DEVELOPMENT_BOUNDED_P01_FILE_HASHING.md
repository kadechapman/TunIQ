# Run52 — bounded, fail-closed P01 file verification

This is an offline, source-only reliability correction. No physical ECU or serial
interface was used, and no write/flash path was exercised.

## Reproduced defect

`src/p01-commissioning.js` previously called `fs.readFileSync(fd)` after
opening an untrusted project BIN. Even when the file was larger than the
expected 524,288-byte P01 image, the code attempted to read the entire file
before rejecting its size. A large or concurrently growing file could cause
unbounded memory allocation during read-only commissioning status checks.

The new regression fixture reproduced three unbounded descriptor-read attempts
when a 16-MiB sparse original was selected. The test failed before the fix.

## Correction

- Reject a file whose `lstat` or opened descriptor size differs from exactly
  524,288 bytes, before reading any bytes.
- Hash one fixed-size 524,288-byte buffer from the verified open descriptor,
  using bounded `fs.readSync` calls that tolerate short successful reads.
- Require all expected bytes and probe one extra byte for EOF. If the file
  grows, shrinks, changes identity or metadata, or a read fails, reject it.
- Preserve the specific expected-size diagnostic for `recordRead()` failures;
  the separate size lookup is **diagnostic only** and never admits evidence.
- Continue rejecting symlinks, multiply linked files, redirected parents, and
  path replacements using the prior direct-file proof checks.

## Verification scope and limitations

Tests use local synthetic 512-KiB images and a sparse 16-MiB fixture. They
assert that no unbounded descriptor reads occur, an oversized file is rejected
before reading, an exact-size image still passes, and synthetic early EOF and
extra-byte conditions fail closed. This is not a transactional filesystem lock
against privileged concurrent modification or timestamp restoration.

The source-only release gate remains closed. Native Windows execution, a
reproducible dependency lockfile, a runnable installer, physical independent
Full Reads, COM ownership and interrupted-read recovery are not verified.
