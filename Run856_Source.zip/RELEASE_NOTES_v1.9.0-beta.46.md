# TunIQ v1.9.0-beta.46 — Combined Windows Inventory and PCM Runtime Guard

Source-only safety checkpoint. **Not** a Windows-qualified installer or public beta.

- Retains beta.45's Windows process inventory identity validation: rejects absent, duplicate, invalid, or nameless process entries before authorizing adapter ownership.
- Fixes PCM Hammer CLI usage-footer misclassification after runtime PCM/ECU connection, response timeout, or kernel transfer failures; read-only command-profile cycling stops. Preserves genuine syntax-only fallback.
- Added a mock read-only CLI process test that confirms one attempted profile after a no-response error; retained inventory validation tests.
- No physical PCM operation or write. Nine release blockers remain, including Windows installation, physical read-only hardware evidence, pinned dependencies, licensing, signing, secure updates, privacy, redistribution and incident response.
