const assert = require('assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { FlashManager, FlashStopError } = require('../src/flash');
const { P01AutoManager } = require('../src/p01-auto');
const { rankAlternatePorts } = require('../src/com-recovery');

function project(root, id) {
  const folder = path.join(root, id);
  fs.mkdirSync(path.join(folder, 'Reports'), { recursive: true });
  return { id, name: 'Customline', folder, controller: 'P01' };
}

async function alternatePortScenario(root) {
  const active = project(root, 'alternate-port');
  const attempts = [];
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data-one'), getActiveProject: () => active, getToolPath: () => null,
    releasePort: async ({ port }) => ({ released: true, port }),
    probePortLock: async ({ port }) => { attempts.push(port); return port === 'COM4' ? { available: null, locked: false, timedOut: true, code: 'lock-probe-timeout', port } : { available: true, locked: false, port }; },
    findAlternatePorts: async () => rankAlternatePorts([{ port: 'COM5', name: 'OBDLink MX+ Outgoing', recognized: true, recommended: true }], 'COM4')
  });
  const preflight = { operation: 'readProperties', values: { device: 'COM4', port: 'COM4' } };
  const lease = await manager.preparePort(preflight);
  assert.equal(lease.port, 'COM5');
  assert.equal(preflight.values.device, 'COM5');
  return { name: 'selected-port-timeout-alternate-recovers', attempts, selected: lease.port, passed: true };
}

async function allPortsTimeoutScenario(root) {
  const active = project(root, 'all-timeout');
  let aborted = 0;
  const manager = new FlashManager({
    dataRoot: () => path.join(root, 'data-two'), getActiveProject: () => active, getToolPath: () => null,
    releasePort: async ({ port }) => ({ released: true, port }),
    probePortLock: async ({ port }) => ({ available: null, locked: false, timedOut: true, code: 'lock-probe-timeout', port }),
    findAlternatePorts: async () => [{ port: 'COM5' }], abortBridgeRequests: () => ({ aborted: ++aborted })
  });
  let stopped = null;
  try { await manager.preparePort({ operation: 'readProperties', values: { device: 'COM4', port: 'COM4' } }); }
  catch (error) { stopped = error; }
  assert(stopped instanceof FlashStopError);
  assert.equal(stopped.code, 'lock-probe-timeout');
  assert.equal(stopped.details.attempts.length, 2);
  const cleared = manager.clearTransientRecoveryState('simulation');
  assert.equal(cleared.bridge.aborted, 1);
  return { name: 'all-lock-probes-timeout-clean-stop', code: stopped.code, attempts: stopped.details.attempts.map(item => item.port), bridgeCleared: true, passed: true };
}

function legacyStuckResumeScenario(root) {
  const active = project(root, 'legacy-stuck');
  const manager = new P01AutoManager({ getActiveProject: () => active, appendActivity: () => {}, processInstanceId: 'beta16-process' });
  const legacy = { ...manager.blank(active), version: 2, status: 'running', phase: 'stopped-pcmhammer-start-failed', nextStep: 'read-properties', resumePhase: 'read-properties', blocker: 'The lockprobe request timed out.', stop: { code: 'pcmhammer-start-failed', priorPhase: 'waiting-read-properties' } };
  fs.writeFileSync(manager.file(active), JSON.stringify(legacy, null, 2));
  const loaded = manager.load(active);
  assert.equal(loaded.status, 'paused');
  assert.equal(manager.canResume(loaded), true);
  const recovered = manager.recover('simulation cleanup');
  assert.equal(recovered.status, 'paused');
  const resumed = manager.resume();
  assert.equal(resumed.status, 'running');
  assert.equal(resumed.phase, 'read-properties');
  return { name: 'beta15-stuck-state-migrates-and-resumes', recoveryCount: resumed.recoveryCount, phase: resumed.phase, passed: true };
}

(async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'tuniq-com-recovery-'));
  try {
    const scenarios = [await alternatePortScenario(root), await allPortsTimeoutScenario(root), legacyStuckResumeScenario(root)];
    const report = { type: 'tuniq-com-recovery-simulations', version: '1.7.0-beta.16', generatedAt: new Date().toISOString(), softwareSimulationOnly: true, realHardwareVerified: false, scenarios };
    const output = path.join(__dirname, '..', 'test-results', 'com-recovery-simulations.json');
    fs.mkdirSync(path.dirname(output), { recursive: true }); fs.writeFileSync(output, JSON.stringify(report, null, 2));
    scenarios.forEach((item, index) => console.log(`✓ COM recovery simulation ${index + 1}: ${item.name}`));
  } finally { fs.rmSync(root, { recursive: true, force: true }); }
})().catch(error => { console.error(error.stack || error); process.exit(1); });
