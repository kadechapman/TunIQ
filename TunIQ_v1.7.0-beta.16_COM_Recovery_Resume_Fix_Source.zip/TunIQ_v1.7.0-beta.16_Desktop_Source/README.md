# TunIQ v1.7.0-beta.16 — COM Recovery & Resume Fix

TunIQ beta.16 fixes the real Windows lock-probe timeout and stuck Guided P01 Resume state reported during Customline P01 hardware validation.

## Main changes

- Windows serial bridge requests are tracked and force-terminated after timeout.
- Lock-probe timeouts return a named `lock-probe-timeout` recovery code instead of a generic error.
- Guided Automatic P01 Setup always releases its runtime busy state after a failed COM check.
- Resume force-clears stale bridge requests and retries the exact failed step without repeating completed work.
- TunIQ tries recognized alternate OBDLink Bluetooth COM ports before stopping.
- The UI shows the exact selected and attempted COM ports.
- **Clear Stuck COM State** repairs old beta.15 states without deleting project data.
- **Use Assisted PCM Hammer** bypasses the failed ownership probe by opening normal PCM Hammer and importing its evidence.
- Existing protected-original, dual-read, exact-XDF, checksum, Test Write, voltage, and final-write confirmation rules remain unchanged.

## Run from source

1. Extract the source ZIP.
2. Run `INSTALL_AND_RUN_WINDOWS.bat`.
3. Reopen the existing Customline project.
4. Press **Clear Stuck COM State** if the old timeout is still shown.
5. Press **Resume Failed Step**, or choose **Use Assisted PCM Hammer**.

No real flash write is automatically authorized.
