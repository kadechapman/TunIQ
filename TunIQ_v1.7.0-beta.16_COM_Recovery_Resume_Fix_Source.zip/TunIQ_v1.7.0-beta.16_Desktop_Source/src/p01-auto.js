const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { isRecoverableP01Stop, normalizeP01RecoveryState } = require('./com-recovery');

const AUTO_VERSION = 3;
const TERMINAL = new Set(['ready-to-write', 'write-complete', 'failed', 'cancelled']);

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function clean(value, max = 2000) { return String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, max); }
function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function osCandidates(value) { return [...new Set((String(value || '').match(/\b\d{7,9}\b/g) || []))]; }
function now() { return new Date().toISOString(); }

function walkFiles(root, extension = '.xdf', maxDepth = 4, maxEntries = 10000) {
  if (!root || !fs.existsSync(root)) return [];
  const output = [];
  const queue = [{ folder: root, depth: 0 }];
  let visited = 0;
  const skip = new Set(['node_modules', '.git', '$recycle.bin', 'windows', 'winsxs']);
  while (queue.length && visited < maxEntries) {
    const current = queue.shift();
    let entries = [];
    try { entries = fs.readdirSync(current.folder, { withFileTypes: true }); } catch { continue; }
    for (const entry of entries) {
      visited += 1;
      if (visited >= maxEntries) break;
      const full = path.join(current.folder, entry.name);
      if (entry.isFile() && path.extname(entry.name).toLowerCase() === extension) output.push(full);
      else if (entry.isDirectory() && current.depth < maxDepth && !skip.has(entry.name.toLowerCase())) queue.push({ folder: full, depth: current.depth + 1 });
    }
  }
  return output;
}

function discoverExactXdfs({ os, folders = [], parseXdf }) {
  const expected = clean(os, 20);
  if (!expected) return [];
  const unique = new Map();
  folders.filter(Boolean).forEach((folder, folderIndex) => {
    for (const file of walkFiles(folder, '.xdf')) {
      const key = path.resolve(file).toLowerCase();
      if (unique.has(key)) continue;
      try {
        const parsed = parseXdf(file);
        const declared = osCandidates(`${path.basename(file)} ${parsed.title || ''} ${parsed.description || ''}`);
        if (!declared.includes(expected) || !(parsed.tables || []).length) continue;
        const warnings = Array.isArray(parsed.warnings) ? parsed.warnings.filter(Boolean) : [];
        const checksumCount = Array.isArray(parsed.checksums) ? parsed.checksums.length : 0;
        let score = 100 - folderIndex * 8;
        if (path.basename(file).includes(expected)) score += 18;
        if (String(parsed.title || '').includes(expected)) score += 18;
        score += Math.min(12, checksumCount * 4);
        score += Math.min(10, Math.floor((parsed.tables || []).length / 50));
        score -= Math.min(30, warnings.length * 5);
        unique.set(key, {
          path: file, name: path.basename(file), title: parsed.title || '', os: expected,
          tableCount: parsed.tables.length, checksumCount, warnings, score, sha256: sha256(file), sourceFolder: folder
        });
      } catch {}
    }
  });
  return [...unique.values()].sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}

function proposalScore(item, type) {
  const text = `${item.tableName || ''} ${item.rowLabel || ''} ${item.colLabel || ''} ${item.reason || ''}`.toLowerCase();
  let score = 0;
  if (type === 'rev-limit') {
    if (/fuel.*cut.*rpm|rpm.*fuel.*cut|engine.*speed.*limit|rev.*limit|max.*rpm/.test(text)) score += 30;
    if (/restore|resume|hysteresis|re-enable/.test(text)) score += 8;
    if (/fan|shaft|trans|speedometer/.test(text)) score -= 60;
  } else if (type === 'speed-limit') {
    if (/vehicle.*speed.*limit|speed.*limiter|top.*speed|max.*vehicle.*speed/.test(text)) score += 35;
    if (/speedometer|fan|shift|shaft|trans/.test(text)) score -= 60;
  } else if (type === 'ghost-cam') {
    if (/idle.*spark|spark.*idle/.test(text)) score += 25;
    if (/idle.*airflow|airflow.*idle|base.*running.*air/.test(text)) score += 25;
    if (/desired.*idle|idle.*speed|idle.*rpm/.test(text)) score += 25;
    if (/startup|crank|fan|highway|cruise|\bpe\b|power.*enrichment/.test(text)) score -= 40;
    if (/176|180|185|190|194|200|80|85|90|hot|normal/.test(text)) score += 4;
    if (/park|neutral|drive|gear|p\/n/.test(text)) score += 3;
  }
  return score;
}

function chooseBestTable(items, type, maximum) {
  const groups = new Map();
  for (const item of items) {
    const list = groups.get(item.tableKey) || [];
    list.push(item); groups.set(item.tableKey, list);
  }
  const ranked = [...groups.entries()].map(([tableKey, list]) => ({
    tableKey, list, score: Math.max(...list.map(item => proposalScore(item, type))) + Math.min(8, list.length)
  })).sort((a, b) => b.score - a.score || a.tableKey.localeCompare(b.tableKey));
  if (!ranked.length || ranked[0].score < 10) return { selected: [], ambiguous: false };
  const ambiguous = ranked.length > 1 && ranked[0].score === ranked[1].score && ranked[0].tableKey !== ranked[1].tableKey;
  return { selected: ranked[0].list.sort((a, b) => proposalScore(b, type) - proposalScore(a, type)).slice(0, maximum), ambiguous };
}

function selectGoalMapCandidates(proposal) {
  const selectedProposalIds = [];
  const actionIds = [];
  const blockers = [];
  const review = [];
  for (const action of proposal?.actions || []) {
    const candidates = (action.proposals || []).filter(item => Number.isFinite(Number(item.current)) && Number.isFinite(Number(item.proposed)));
    if (!candidates.length) { blockers.push(`${action.label}: no exact candidate cells were found.`); continue; }
    if (action.type === 'rev-limit') {
      const targets = candidates.filter(item => !/restore|resume|hysteresis|re-enable/i.test(`${item.id} ${item.rowLabel} ${item.colLabel}`));
      const restores = candidates.filter(item => /restore|resume|hysteresis|re-enable/i.test(`${item.id} ${item.rowLabel} ${item.colLabel}`));
      const target = chooseBestTable(targets, 'rev-limit', 2);
      const restore = chooseBestTable(restores, 'rev-limit', 1);
      if (!target.selected.length || target.ambiguous) blockers.push(`${action.label}: RPM cutoff mapping is missing or ambiguous.`);
      else {
        selectedProposalIds.push(...target.selected.map(item => item.id));
        if (restore.selected.length && !restore.ambiguous) selectedProposalIds.push(...restore.selected.map(item => item.id));
        actionIds.push(action.id);
      }
    } else if (action.type === 'speed-limit') {
      const best = chooseBestTable(candidates, 'speed-limit', 2);
      if (!best.selected.length || best.ambiguous) blockers.push(`${action.label}: vehicle-speed limiter mapping is missing or ambiguous.`);
      else { selectedProposalIds.push(...best.selected.map(item => item.id)); actionIds.push(action.id); }
    } else if (action.type === 'ghost-cam') {
      const spark = chooseBestTable(candidates.filter(item => /idle.*spark|spark.*idle/i.test(`${item.tableName} ${item.reason}`)), 'ghost-cam', 8);
      const airflow = chooseBestTable(candidates.filter(item => /idle.*airflow|airflow.*idle|base.*running.*air/i.test(`${item.tableName} ${item.reason}`)), 'ghost-cam', 6);
      const speed = chooseBestTable(candidates.filter(item => /desired.*idle|idle.*speed|idle.*rpm/i.test(`${item.tableName} ${item.reason}`)), 'ghost-cam', 4);
      if (!spark.selected.length || !airflow.selected.length || !speed.selected.length || spark.ambiguous || airflow.ambiguous || speed.ambiguous) {
        blockers.push(`${action.label}: TunIQ could not isolate one unambiguous idle-spark, idle-airflow, and desired-idle group.`);
      } else {
        selectedProposalIds.push(...spark.selected.map(item => item.id), ...airflow.selected.map(item => item.id), ...speed.selected.map(item => item.id));
        actionIds.push(action.id);
        review.push('Ghost-cam cells were restricted to one best-matching table per idle role and still require the user’s start-of-session risk authorization.');
      }
    }
  }
  return { actionIds: [...new Set(actionIds)], proposalIds: [...new Set(selectedProposalIds)], blockers, review, safeToAutoMap: blockers.length === 0 && actionIds.length > 0 };
}

class P01AutoManager {
  constructor(options) {
    this.getActiveProject = options.getActiveProject;
    this.appendActivity = options.appendActivity || (() => {});
    this.processInstanceId = options.processInstanceId || `${process.pid}-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
  }
  file(active = this.getActiveProject()) { return active?.folder ? path.join(active.folder, 'Reports', 'p01-auto-commissioning.json') : null; }
  blank(active = this.getActiveProject()) {
    return {
      type: 'p01-auto-commissioning', version: AUTO_VERSION, projectId: active?.id || null, projectName: active?.name || '',
      status: 'idle', phase: 'idle', nextStep: 'preflight', resumePhase: null, progress: 0,
      completedSteps: {}, lastCompletedStep: null, stop: null, blocker: null, messages: [],
      runInstanceId: this.processInstanceId, createdAt: now(), updatedAt: now()
    };
  }
  waitingResumePhase(phase) {
    return ({
      'waiting-read-properties': 'read-properties', 'waiting-identify': 'read-properties',
      'waiting-read-1': 'read-1', 'waiting-read-2': 'read-2', 'waiting-read-3': 'read-1',
      'waiting-test-write': 'test-write', 'waiting-write': 'ready-to-write'
    })[phase] || phase || 'preflight';
  }
  load(active = this.getActiveProject()) {
    const file = this.file(active); const saved = file ? readJson(file, null) : null;
    if (!saved || saved.projectId !== active?.id) return this.blank(active);
    let state = normalizeP01RecoveryState({ ...this.blank(active), ...saved, completedSteps: { ...(saved.completedSteps || {}) } });
    if (state.status === 'running' && /^waiting-/.test(state.phase || '') && state.runInstanceId && state.runInstanceId !== this.processInstanceId) {
      const resumePhase = this.waitingResumePhase(state.phase);
      const message = `TunIQ restarted while ${state.phase.replace(/^waiting-/, '').replace(/-/g, ' ')} was in progress. The completed-step ledger was preserved; resume will retry exactly ${resumePhase.replace(/-/g, ' ')}.`;
      state = {
        ...state, status: 'paused', resumePhase, nextStep: resumePhase, blocker: message,
        stop: { code: 'app-restarted-during-step', message, at: now(), phase: state.phase }, runInstanceId: this.processInstanceId,
        messages: [...(state.messages || []), { at: now(), level: 'warning', text: message }].slice(-120)
      };
      writeJson(file, { ...state, updatedAt: now() });
    }
    state.runInstanceId = this.processInstanceId;
    return state;
  }
  save(state, active = this.getActiveProject()) {
    if (!active?.folder) throw new Error('Create or activate a P01 project first.');
    const next = { ...state, version: AUTO_VERSION, projectId: active.id, projectName: active.name, runInstanceId: this.processInstanceId, updatedAt: now() };
    writeJson(this.file(active), next); return next;
  }
  begin(payload = {}) {
    const active = this.getActiveProject();
    if (!active) throw new Error('Create or activate a P01 project first.');
    if (String(active.controller || '').toUpperCase() !== 'P01') throw new Error('Guided Automatic P01 Setup only runs on a project whose controller is P01.');
    const request = clean(payload.request, 2000);
    if (!request) throw new Error('Describe the tune request before starting.');
    const state = {
      ...this.blank(active), id: `${Date.now()}-p01-guided`, status: 'running', phase: 'preflight', nextStep: 'preflight', progress: 2,
      request, confirmations: payload.confirmations || {}, device: clean(payload.device, 200),
      voltage: Number.isFinite(Number(payload.voltage)) ? Number(payload.voltage) : null,
      benchPowerConfirmed: Boolean(payload.benchPowerConfirmed), exactXdfAuthorization: Boolean(payload.exactXdfAuthorization),
      autoMapAuthorized: Boolean(payload.autoMapAuthorized), autoRevisionAuthorized: Boolean(payload.autoRevisionAuthorized),
      testWriteAuthorized: Boolean(payload.testWriteAuthorized), selectedXdf: clean(payload.selectedXdf, 1000),
      readAttempts: 0, completedSteps: {}, messages: [{ at: now(), level: 'info', text: 'Guided Automatic P01 Setup started.' }]
    };
    this.appendActivity('p01-guided-setup-started', { projectId: active.id, request });
    return this.save(state, active);
  }
  patch(patch = {}, message = null) {
    const active = this.getActiveProject(); const state = this.load(active);
    const next = { ...state, ...patch };
    if (message) next.messages = [...(state.messages || []), { at: now(), level: message.level || 'info', text: clean(message.text, 2000) }].slice(-120);
    return this.save(next, active);
  }
  advance(phase, progress, text) {
    return this.patch({ status: 'running', phase, nextStep: phase, resumePhase: null, progress: Math.max(0, Math.min(100, Number(progress) || 0)), blocker: null, stop: null }, text ? { text } : null);
  }
  completeStep(step, nextPhase, progress, text, evidence = {}) {
    const state = this.load();
    const completion = { at: now(), evidence };
    return this.patch({
      status: 'running', phase: nextPhase, nextStep: nextPhase, resumePhase: null,
      progress: Math.max(0, Math.min(100, Number(progress) || 0)), blocker: null, stop: null,
      completedSteps: { ...(state.completedSteps || {}), [step]: completion }, lastCompletedStep: step
    }, text ? { text } : null);
  }
  pause(codeOrPhase, blocker, patch = {}) {
    const current = this.load();
    const code = clean(patch.stopCode || codeOrPhase || 'workflow-stopped', 120);
    const resumePhase = patch.resumePhase || this.waitingResumePhase(patch.phase || current.phase || current.nextStep);
    const phase = patch.phase || `stopped-${code}`;
    const message = clean(blocker || 'The workflow stopped and requires attention.', 4000);
    const { stopCode, ...rest } = patch;
    return this.patch({ ...rest, status: 'paused', phase, nextStep: resumePhase, resumePhase, blocker: message, stop: { code, message, at: now(), priorPhase: current.phase } }, { level: 'warning', text: message });
  }
  canResume(state = this.load()) {
    if (!state || ['ready-to-write', 'write-complete'].includes(state.phase)) return false;
    if (state.status === 'paused') return true;
    if (state.stop?.code && isRecoverableP01Stop(state.stop.code)) return true;
    return /^stopped-|^assisted-/.test(String(state.phase || ''));
  }
  resume(patch = {}) {
    const state = this.load();
    if (!this.canResume(state)) return state;
    const phase = patch.phase || state.resumePhase || state.nextStep || this.waitingResumePhase(state.stop?.priorPhase || state.phase);
    return this.patch({ ...patch, status: 'running', phase, nextStep: phase, resumePhase: null, blocker: null, stop: null, recoveryCount: Number(state.recoveryCount || 0) + 1 }, { text: `Recovery cleared. Resuming from ${phase.replace(/-/g, ' ')}. Previously completed steps will not be repeated.` });
  }
  recover(reason = 'manual recovery') {
    const state = this.load();
    const phase = state.resumePhase || state.nextStep || this.waitingResumePhase(state.stop?.priorPhase || state.phase);
    return this.patch({ status: 'paused', phase: `stopped-recovered`, nextStep: phase, resumePhase: phase, blocker: `Transient COM/bridge state was cleared (${clean(reason, 300)}). Press Resume to retry ${phase.replace(/-/g, ' ')} or use Assisted PCM Hammer.`, stop: { code: 'manual-recovery', message: clean(reason, 1000), at: now(), priorPhase: state.phase }, recoveryCount: Number(state.recoveryCount || 0) + 1 }, { level: 'warning', text: `Transient COM/bridge state cleared. Resume is available for ${phase.replace(/-/g, ' ')}.` });
  }
  fail(error) {
    const text = error?.message || String(error || 'Guided Automatic P01 Setup failed.');
    this.appendActivity('p01-guided-setup-failed', { text });
    return this.patch({ status: 'failed', phase: 'failed', nextStep: null, blocker: clean(text, 4000), stop: { code: error?.code || 'unexpected-error', message: clean(text, 4000), at: now() } }, { level: 'error', text });
  }
  cancel() {
    this.appendActivity('p01-guided-setup-cancelled', {});
    return this.patch({ status: 'cancelled', phase: 'cancelled', nextStep: null, blocker: null, stop: null }, { level: 'warning', text: 'Guided Automatic P01 Setup was cancelled. Existing reads, evidence, and revisions were kept.' });
  }
  isActive(state = this.load()) { return state.status === 'running' && !TERMINAL.has(state.phase); }
}

module.exports = { P01AutoManager, discoverExactXdfs, selectGoalMapCandidates, walkFiles, AUTO_VERSION };
