const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const crypto = require('crypto');
const {
  P01_BIN_SIZE, OPERATIONS, normalizeOperation, tokenizeTemplate, expandTemplate, parseProgress,
  parseIdentityText, parseBackendIdentity, inferTemplates, classifyPcmHammerResult,
  validateP01ReadFile, assistedInstructions, sha256File, clean
} = require('./pcmhammer');

function ensureDir(folder) { fs.mkdirSync(folder, { recursive: true }); return folder; }
function readJson(file, fallback = null) { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } }
function writeJson(file, value) { ensureDir(path.dirname(file)); fs.writeFileSync(file, JSON.stringify(value, null, 2), 'utf8'); }
function safeName(value) { return String(value || 'PCM').replace(/[<>:"/\\|?*]+/g, '-').replace(/\s+/g, '-').replace(/^-+|-+$/g, '') || 'PCM'; }
function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
function uniqueFiles(files = []) { return [...new Set(files.filter(Boolean).map(file => path.resolve(String(file))))]; }
function fileFingerprint(file) {
  try { const stat = fs.statSync(file); return `${path.resolve(file)}:${stat.size}:${stat.mtimeMs}`; } catch { return path.resolve(String(file)); }
}

class FlashStopError extends Error {
  constructor(code, message, details = {}) { super(message); this.name = 'FlashStopError'; this.code = code; this.details = details; }
}

class FlashManager {
  constructor(options) {
    this.dataRoot = options.dataRoot;
    this.getActiveProject = options.getActiveProject;
    this.getToolPath = options.getToolPath;
    this.getDeviceStatus = options.getDeviceStatus || (() => ({}));
    this.releasePort = options.releasePort || (async () => ({ released: false }));
    this.probePortLock = options.probePortLock || (async () => ({ available: true, locked: false, supported: false }));
    this.findAlternatePorts = options.findAlternatePorts || (async () => []);
    this.abortBridgeRequests = options.abortBridgeRequests || (() => ({ aborted: 0 }));
    this.appendActivity = options.appendActivity || (() => {});
    this.emit = options.emit || (() => {});
    this.onReadComplete = options.onReadComplete || (() => {});
    this.onIdentifyComplete = options.onIdentifyComplete || (() => {});
    this.onSessionComplete = options.onSessionComplete || (() => {});
    this.session = null;
    this.history = null;
    this.assistedWatchers = new Map();
  }

  configFile() { return path.join(this.dataRoot(), 'Tools', 'pcmhammer-cli.json'); }
  sessionsRoot() { return ensureDir(path.join(this.dataRoot(), 'Logs', 'Flash')); }
  historyFile() { return path.join(this.sessionsRoot(), 'history.json'); }
  assistedStateFile(active = this.getActiveProject()) { return active?.folder ? path.join(active.folder, 'Reports', 'p01-assisted-pcmhammer.json') : null; }
  assistedFolder(active = this.getActiveProject()) { return active?.folder ? ensureDir(path.join(active.folder, 'Imports', 'PCM-Hammer-Assisted')) : null; }
  getHistory() { if (!Array.isArray(this.history)) this.history = readJson(this.historyFile(), []); return Array.isArray(this.history) ? this.history : []; }
  recordHistory(session) {
    const summary = { ...session, child: undefined, log: Array.isArray(session.log) ? session.log.slice(-120) : [] };
    const history = this.getHistory(); history.unshift(summary); if (history.length > 150) history.length = 150;
    this.history = history; writeJson(this.historyFile(), history); return summary;
  }
  getConfig() {
    const fallback = {
      executable: '', prefixArgs: [], device: '', mode: 'auto', probedAt: null, helpText: '',
      templates: { readProperties: null, read: null, testWrite: null, writeCalibration: null, writeFull: null, recovery: null }
    };
    const config = readJson(this.configFile(), fallback) || fallback;
    if (!config.templates?.readProperties && config.templates?.identify) config.templates.readProperties = config.templates.identify;
    delete config.templates?.identify;
    return { ...fallback, ...config, templates: { ...fallback.templates, ...(config.templates || {}) } };
  }
  saveConfig(patch = {}) {
    const current = this.getConfig();
    const next = { ...current, ...patch, templates: { ...current.templates, ...(patch.templates || {}) }, updatedAt: new Date().toISOString() };
    delete next.templates.identify;
    writeJson(this.configFile(), next);
    return next;
  }

  resolveExecutable() {
    const config = this.getConfig();
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const candidates = [];
    if (config.executable) candidates.push(config.executable);
    if (toolPath) {
      const folder = path.extname(toolPath) ? path.dirname(toolPath) : toolPath;
      candidates.push(toolPath);
      for (const name of ['PcmHammerCLI.exe', 'PCM Hammer CLI.exe', 'pcmhammer-cli.exe', 'PcmHammer.Console.exe', 'PcmHammerCLI']) candidates.push(path.join(folder, name));
    }
    for (const candidate of candidates) {
      try {
        if (fs.statSync(candidate).isFile() && /(?:cli|console)/i.test(path.basename(candidate))) return { executable: candidate, prefixArgs: Array.isArray(config.prefixArgs) ? config.prefixArgs : [] };
      } catch {}
    }
    return null;
  }
  resolveGuiExecutable() {
    const toolPath = this.getToolPath?.('pcmHammer') || '';
    const config = this.getConfig();
    const candidates = [];
    const addFolder = folder => {
      if (!folder) return;
      for (const name of ['PcmHammer.exe', 'PCM Hammer.exe', 'pcmhammer.exe']) candidates.push(path.join(folder, name));
    };
    if (config.guiExecutable) candidates.push(config.guiExecutable);
    for (const source of [toolPath, config.executable]) {
      if (!source) continue;
      const folder = path.extname(source) ? path.dirname(source) : source;
      if (!/(?:cli|console)/i.test(path.basename(source))) candidates.push(source);
      addFolder(folder);
      addFolder(path.dirname(folder)); // Portable releases commonly place Cli\ beside PcmHammer.exe.
      addFolder(path.join(folder, '..', 'PcmHammer'));
      addFolder(path.join(folder, '..', 'GUI'));
    }
    for (const candidate of [...new Set(candidates.map(item => path.resolve(item)))]) {
      try { if (fs.statSync(candidate).isFile() && !/(?:cli|console)/i.test(path.basename(candidate))) return candidate; } catch {}
    }
    return null;
  }

  saveGuiExecutable(executable) {
    if (!executable) return this.saveConfig({ guiExecutable: null });
    const resolved = path.resolve(String(executable));
    if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile() || /(?:cli|console)/i.test(path.basename(resolved))) {
      throw new FlashStopError('gui-invalid', 'Select the normal PcmHammer.exe application, not a CLI or console executable.');
    }
    return this.saveConfig({ guiExecutable: resolved });
  }

  async runCapture(executable, args, timeout = 15000) {
    return new Promise((resolve, reject) => {
      const child = spawn(executable, args, { windowsHide: true, cwd: path.dirname(executable) });
      let stdout = ''; let stderr = ''; let finished = false;
      const done = value => { if (finished) return; finished = true; clearTimeout(timer); resolve(value); };
      const timer = setTimeout(() => { try { child.kill(); } catch {} reject(new Error('PCM Hammer CLI probe timed out.')); }, timeout);
      child.stdout?.on('data', chunk => { stdout += chunk.toString(); });
      child.stderr?.on('data', chunk => { stderr += chunk.toString(); });
      child.on('error', error => { clearTimeout(timer); reject(error); });
      child.on('close', code => done({ code, stdout, stderr, text: `${stdout}\n${stderr}`.trim() }));
    });
  }

  async probe(payload = {}) {
    if (payload.executable) this.saveConfig({ executable: payload.executable, prefixArgs: payload.prefixArgs || [] });
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer 2.x CLI was not found. Configure the separate PcmHammerCLI executable, or use Guided Automatic P01 Setup assisted mode with the normal PCM Hammer app.');
    let helpResult = null;
    for (const attempt of [['--help'], ['-h'], ['help'], []]) {
      try {
        const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt]);
        if (result.text?.length > 20) { helpResult = result; break; }
      } catch {}
    }
    let versionText = '';
    for (const attempt of [['--version'], ['-v'], ['version']]) {
      try { const result = await this.runCapture(resolved.executable, [...resolved.prefixArgs, ...attempt], 8000); if (result.text) { versionText = result.text; break; } } catch {}
    }
    const combined = `${versionText}\n${helpResult?.text || ''}`;
    const backend = { ...parseBackendIdentity(combined, resolved.executable), sha256: sha256File(resolved.executable), executable: resolved.executable };
    if (!backend.official) {
      const config = this.saveConfig({ executable: resolved.executable, prefixArgs: resolved.prefixArgs, helpText: (helpResult?.text || '').slice(0, 50000), versionText: versionText.slice(0, 5000), backend, templates: {}, probedAt: new Date().toISOString(), lastProbeStop: { code: 'unsupported-cli', message: 'The selected executable did not identify itself as PCM Hammer 2.x CLI.' } });
      return { executable: resolved.executable, backend, capabilities: {}, templates: {}, help: (helpResult?.text || '').slice(0, 16000), probedAt: config.probedAt, assistedAvailable: Boolean(this.resolveGuiExecutable()), mode: 'assisted', stop: config.lastProbeStop };
    }
    const inferred = inferTemplates(helpResult?.text || '');
    const existing = this.getConfig().templates || {};
    const templates = {};
    for (const operation of Object.keys(OPERATIONS)) templates[operation] = inferred[operation] || existing[operation] || null;
    const config = this.saveConfig({ executable: resolved.executable, prefixArgs: resolved.prefixArgs, helpText: (helpResult?.text || '').slice(0, 50000), versionText: versionText.slice(0, 5000), backend, templates, probedAt: new Date().toISOString() });
    const capabilities = Object.fromEntries(Object.entries(config.templates).map(([key, value]) => [key, Boolean(value)]));
    return { executable: resolved.executable, backend, capabilities, templates: config.templates, help: (helpResult?.text || '').slice(0, 16000), probedAt: config.probedAt, assistedAvailable: Boolean(this.resolveGuiExecutable()) };
  }

  status() {
    const resolved = this.resolveExecutable();
    const config = this.getConfig();
    const active = this.getActiveProject();
    const assisted = active ? readJson(this.assistedStateFile(active), null) : null;
    return {
      configured: Boolean(resolved), executable: resolved?.executable || null,
      backend: config.backend || null,
      capabilities: Object.fromEntries(Object.entries(config.templates || {}).map(([key, value]) => [key, Boolean(value)])),
      templates: config.templates || {}, session: this.session ? { ...this.session, child: undefined } : null,
      device: config.device || '', probedAt: config.probedAt || null, history: this.getHistory().slice(0, 30),
      assistedAvailable: Boolean(this.resolveGuiExecutable()), assisted
    };
  }

  saveDevice(device) { return this.saveConfig({ device: clean(device, 200) }); }
  saveTemplates(templates) {
    const normalized = {};
    for (const operation of Object.keys(OPERATIONS)) {
      const template = templates?.[operation] ?? (operation === 'readProperties' ? templates?.identify : null);
      if (template == null || String(Array.isArray(template) ? template.join(' ') : template).trim() === '') { normalized[operation] = null; continue; }
      const text = String(Array.isArray(template) ? template.join(' ') : template);
      if (OPERATIONS[operation].io === 'input' && !text.includes('{input}')) throw new Error(`${operation} command template must include {input}.`);
      if (OPERATIONS[operation].io === 'output' && !text.includes('{output}')) throw new Error(`${operation} command template must include {output}.`);
      normalized[operation] = tokenizeTemplate(template);
    }
    return this.saveConfig({ templates: normalized });
  }

  preflight(operation, payload = {}) {
    const normalizedOperation = normalizeOperation(operation);
    if (!OPERATIONS[normalizedOperation]) throw new FlashStopError('unsupported-operation', `Unsupported PCM Hammer operation: ${operation}.`);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const config = this.getConfig();
    const resolved = this.resolveExecutable();
    if (!resolved) throw new FlashStopError('cli-not-found', 'PCM Hammer CLI is unavailable. Guided Automatic P01 Setup can switch to the normal PCM Hammer app and import its evidence.');
    const template = config.templates?.[normalizedOperation];
    if (!template) throw new FlashStopError('cli-operation-unavailable', `PCM Hammer CLI help did not expose a safe ${OPERATIONS[normalizedOperation].label} command. TunIQ will not invent a command; use the assisted normal-PCM-Hammer step.`);
    if (this.session) throw new FlashStopError('operation-running', 'Another PCM Hammer operation is already running.');
    const deviceStatus = this.getDeviceStatus() || {};
    const voltage = Number(payload.voltage ?? deviceStatus.connection?.voltage);
    const selectedDevice = payload.device || config.device || deviceStatus.connection?.port || '';
    const values = {
      device: selectedDevice, port: selectedDevice, project: active.folder, controller: active.controller || '',
      input: payload.input || '', output: payload.output || ''
    };
    const writeOperation = ['testWrite', 'writeCalibration', 'writeFull', 'recovery'].includes(normalizedOperation);
    if (writeOperation) {
      if (!values.input || !fs.existsSync(values.input)) throw new FlashStopError('input-missing', 'Select an existing revision BIN before Test Write or writing.');
      if (!active.bin || !fs.existsSync(active.bin)) throw new FlashStopError('original-missing', 'A protected verified original BIN is required before any write-related operation.');
      const sourceSize = fs.statSync(values.input).size;
      const originalSize = fs.statSync(active.bin).size;
      if (sourceSize !== originalSize) throw new FlashStopError('input-size-mismatch', `Revision size (${sourceSize}) does not match the protected original (${originalSize}).`);
      if (!Number.isFinite(voltage) && !payload.benchPowerConfirmed) throw new FlashStopError('power-proof-missing', 'Live voltage is unavailable. Enter voltage or confirm a regulated bench supply.');
      if (Number.isFinite(voltage) && voltage < 12.2) throw new FlashStopError('voltage-low', `Voltage is too low for a controlled ${OPERATIONS[normalizedOperation].label} (${voltage.toFixed(2)} V).`);
      if (normalizedOperation !== 'testWrite') {
        const expected = ['writeFull', 'recovery'].includes(normalizedOperation) ? `FULL WRITE ${active.name}` : `WRITE ${active.name}`;
        if (String(payload.confirmation || '').trim() !== expected) throw new FlashStopError('confirmation-missing', `Type exactly “${expected}” to authorize this operation.`);
        if (!payload.checksumApproved) throw new FlashStopError('checksum-not-approved', 'Checksum and compatibility validation must pass before writing.');
      }
    }
    if (normalizedOperation === 'read') {
      const output = values.output || path.join(active.folder, 'Originals', `${safeName(active.name)}-P01-Full-Read-${new Date().toISOString().replace(/[:.]/g, '-')}.bin`);
      ensureDir(path.dirname(output)); values.output = output;
    }
    return { operation: normalizedOperation, active, config, resolved, template, values, voltage: Number.isFinite(voltage) ? voltage : null };
  }

  async preparePort(preflight) {
    const selectedPort = preflight.values.device;
    if (!selectedPort) return { port: '', released: false, lockProbe: { supported: false, locked: false }, attempts: [] };
    const attempts = [];
    const testPort = async (port, source = 'selected') => {
      const release = await this.releasePort({ port, operation: preflight.operation });
      await sleep(120);
      const lockProbe = await this.probePortLock({ port, operation: preflight.operation, timeout: source === 'selected' ? 3500 : 2500 });
      const attempt = { port, source, release, lockProbe, at: new Date().toISOString() };
      attempts.push(attempt);
      return attempt;
    };

    let attempt = await testPort(selectedPort, 'selected');
    if (attempt.lockProbe?.available === true && !attempt.lockProbe?.locked) {
      return { port: selectedPort, released: Boolean(attempt.release?.released), release: attempt.release, lockProbe: attempt.lockProbe, attempts, alternateSelected: false };
    }

    let alternates = [];
    try { alternates = await this.findAlternatePorts(selectedPort); } catch {}
    for (const candidate of (Array.isArray(alternates) ? alternates : []).slice(0, 4)) {
      const candidatePort = clean(candidate?.port || candidate?.id, 30);
      if (!candidatePort || candidatePort === selectedPort) continue;
      const alternate = await testPort(candidatePort, 'alternate');
      if (alternate.lockProbe?.available === true && !alternate.lockProbe?.locked) {
        preflight.values.device = candidatePort;
        preflight.values.port = candidatePort;
        this.saveDevice(candidatePort);
        this.appendActivity('pcmhammer-alternate-com-selected', { from: selectedPort, to: candidatePort, operation: preflight.operation });
        return { port: candidatePort, released: Boolean(alternate.release?.released), release: alternate.release, lockProbe: alternate.lockProbe, attempts, alternateSelected: true, previousPort: selectedPort };
      }
    }

    const timedOut = attempts.some(item => item.lockProbe?.timedOut || item.lockProbe?.code === 'lock-probe-timeout');
    const locked = attempts.some(item => item.lockProbe?.locked || item.lockProbe?.available === false);
    const portList = attempts.map(item => item.port).join(', ');
    if (timedOut) {
      throw new FlashStopError('lock-probe-timeout', `TunIQ could not finish the COM ownership check for ${portList || selectedPort}. The serial bridge was force-cleared. Resume will retry this exact step, or use Assisted PCM Hammer without repeating the stuck probe.`, { port: selectedPort, attempts, recoverable: true, assistedRecommended: true });
    }
    if (locked) {
      const owner = attempt.lockProbe?.owner ? ` ${attempt.lockProbe.owner} appears to own ${selectedPort}.` : '';
      throw new FlashStopError('adapter-locked', `${selectedPort} is locked by another program.${owner} Close scanner apps, then resume this exact step.`, { port: selectedPort, attempts, recoverable: true });
    }
    throw new FlashStopError('com-port-unavailable', `TunIQ could not prove that ${selectedPort} or any recognized alternate COM port was available.`, { port: selectedPort, attempts, recoverable: true });
  }

  clearTransientRecoveryState(reason = 'workflow recovery') {
    const bridge = this.abortBridgeRequests(reason) || { aborted: 0 };
    if (this.session && !['writeCalibration','writeFull','recovery'].includes(this.session.operation)) {
      try { this.session.child?.kill(); } catch {}
      this.session = null;
    }
    return { bridge, activeSession: Boolean(this.session) };
  }

  async start(operation, payload = {}) {
    const preflight = this.preflight(operation, payload);
    const portLease = await this.preparePort(preflight);
    const args = [...preflight.resolved.prefixArgs, ...expandTemplate(preflight.template, preflight.values)];
    const session = {
      id: `${Date.now()}-${preflight.operation}`, operation: preflight.operation,
      projectId: preflight.active.id, projectName: preflight.active.name,
      executable: preflight.resolved.executable, backendSha256: preflight.config?.backend?.sha256 || '', backendVersion: preflight.config?.backend?.version || '',
      args, input: preflight.values.input || null, output: preflight.values.output || null,
      device: preflight.values.device || null, voltage: preflight.voltage, portLease,
      startedAt: new Date().toISOString(), state: 'running', progress: 0, phase: `Starting PCM Hammer ${OPERATIONS[preflight.operation].label}`, log: []
    };
    const sessionLog = path.join(this.sessionsRoot(), `${session.id}.log`);
    session.sessionLog = sessionLog;
    let child;
    try { child = spawn(preflight.resolved.executable, args, { windowsHide: true, cwd: preflight.active.folder }); }
    catch (error) { throw new FlashStopError('cli-launch-failed', `PCM Hammer CLI could not start: ${error.message}`); }
    session.child = child; this.session = session;
    const emit = () => this.emit('flash:progress', { ...session, child: undefined });
    const append = (stream, chunk) => {
      const text = chunk.toString(); fs.appendFileSync(sessionLog, text, 'utf8');
      for (const line of text.split(/\r?\n/).filter(Boolean)) {
        const entry = { at: new Date().toISOString(), stream, text: clean(line, 3000) };
        session.log.push(entry); if (session.log.length > 800) session.log.shift();
        session.progress = parseProgress(entry.text, session.progress);
        if (/read\s+propert|OSID|Hardware ID|Service No/i.test(entry.text)) session.phase = 'Reading controller properties';
        else if (/read|block/i.test(entry.text)) session.phase = 'Reading PCM';
        else if (/erase/i.test(entry.text)) session.phase = 'Erasing flash';
        else if (/write|program/i.test(entry.text)) session.phase = 'Writing flash';
        else if (/verif/i.test(entry.text)) session.phase = 'Verifying';
        const voltage = entry.text.match(/(?:battery\s+)?voltage(?:\s+is)?\s*:\s*(\d+(?:\.\d+)?)/i)?.[1];
        if (voltage) session.voltage = Number(voltage);
      }
      emit();
    };
    child.stdout?.on('data', chunk => append('stdout', chunk));
    child.stderr?.on('data', chunk => append('stderr', chunk));
    child.on('error', async error => {
      session.state = 'failed'; session.error = error.message; session.stopCode = /denied|busy|in use/i.test(error.message) ? 'adapter-locked' : 'cli-process-error';
      session.finishedAt = new Date().toISOString(); session.finalized = true; emit(); this.recordHistory(session); this.session = null;
      try { await this.onSessionComplete({ ...session, child: undefined }); } catch {}
    });
    child.on('close', async code => {
      if (session.finalized) return;
      session.exitCode = code; session.finishedAt = new Date().toISOString();
      const combinedLog = session.log.map(item => item.text).join('\n');
      session.result = classifyPcmHammerResult(session.operation, combinedLog, code);
      session.identity = parseIdentityText(combinedLog);
      if (Number.isFinite(session.identity.voltage)) session.voltage = session.identity.voltage;
      session.stopCode = session.result.stopCode;
      session.state = session.cancelRequested ? 'cancelled' : session.result.success ? 'complete' : 'failed';
      session.progress = session.result.success ? 100 : session.progress;
      session.testWritePassed = Boolean(session.result.testWritePassed);
      session.verified = Boolean(session.result.verificationPassed || session.result.testWritePassed);
      if (session.operation === 'read') {
        const validation = validateP01ReadFile(session.output, session.result);
        session.outputValidation = validation;
        if (!validation.valid) {
          const communicationStops = new Set(['adapter-locked', 'adapter-disconnected', 'repeated-block-read-failures', 'pcmhammer-failed']);
          const classifiedStop = session.result?.stopCode;
          session.state = 'failed';
          session.stopCode = communicationStops.has(classifiedStop) ? classifiedStop : validation.code;
          session.error = communicationStops.has(classifiedStop)
            ? `PCM Hammer stopped before a complete read (${classifiedStop}). ${validation.message}`
            : validation.message;
          if (session.output && fs.existsSync(session.output)) {
            const rejected = `${session.output}.rejected-${Date.now()}`;
            try { fs.renameSync(session.output, rejected); session.rejectedOutput = rejected; } catch {}
          }
        } else {
          session.outputInfo = validation;
          try { await this.onReadComplete(session.output, session.outputInfo, session); } catch (error) { session.state = 'failed'; session.stopCode = 'read-import-failed'; session.importWarning = error.message; }
        }
      }
      const identityUseful = session.operation === 'readProperties'
        ? Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.controller)
        : Boolean(session.identity.os || session.identity.hardwareId || session.identity.serviceNumber || session.identity.vin);
      if (identityUseful) {
        try { await this.onIdentifyComplete(session.identity, session); } catch (error) { session.identityWarning = error.message; if (session.operation === 'readProperties') { session.state = 'failed'; session.stopCode = 'identity-import-failed'; } }
      }
      if (session.operation === 'readProperties' && !identityUseful) {
        session.state = 'failed'; session.stopCode = 'properties-incomplete'; session.error = 'Read Properties finished without OSID, Hardware ID, service number, or controller evidence.';
      }
      if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && code === 0 && !session.verified) {
        session.state = 'complete-unverified'; session.stopCode = 'verification-not-proven';
        session.verificationWarning = 'PCM Hammer exited, but TunIQ did not parse an explicit verification-pass result. Re-read properties and read back before treating the hardware as verified.';
      }
      this.appendActivity(`flash-${session.operation}-${session.state}`, { projectId: session.projectId, projectName: session.projectName, input: session.input ? path.basename(session.input) : null, output: session.output ? path.basename(session.output) : null, exitCode: code, stopCode: session.stopCode, sessionLog });
      try { await this.onSessionComplete({ ...session, child: undefined }); } catch (error) { session.sessionCompletionWarning = error.message; }
      session.finalized = true; this.recordHistory(session); emit(); this.session = null;
    });
    this.appendActivity(`flash-${session.operation}-started`, { projectId: session.projectId, projectName: session.projectName, device: session.device, voltage: session.voltage, releasedTunIQPort: portLease.released });
    emit();
    return { ...session, child: undefined };
  }

  async cancel() {
    if (!this.session?.child) return this.status();
    const session = this.session;
    if (['writeCalibration', 'writeFull', 'recovery'].includes(session.operation) && /eras|writ|program|verif/i.test(session.phase || '')) {
      session.cancelBlocked = true; session.phase = 'Cancellation blocked during critical flash phase';
      session.log.push({ at: new Date().toISOString(), stream: 'safety', text: 'TunIQ will not terminate PCM Hammer during erase/write/verify. Maintain power and allow it to finish.' });
      this.emit('flash:progress', { ...session, child: undefined }); return this.status();
    }
    session.cancelRequested = true; session.phase = 'Safe cancellation requested';
    try {
      if (process.platform === 'win32' && session.child.pid) spawn('taskkill.exe', ['/PID', String(session.child.pid), '/T', '/F'], { windowsHide: true });
      else session.child.kill('SIGTERM');
    } catch {}
    return this.status();
  }

  prepareAssisted(operation, payload = {}, reason = null) {
    const normalizedOperation = normalizeOperation(operation);
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const folder = this.assistedFolder(active);
    const state = {
      type: 'pcmhammer-assisted-operation', version: 1, projectId: active.id, projectName: active.name,
      operation: normalizedOperation, status: 'waiting-for-evidence', folder,
      input: payload.input || null, device: payload.device || this.getConfig().device || this.getDeviceStatus()?.connection?.port || '',
      reason: reason ? clean(reason.message || reason, 2000) : 'CLI automation is unavailable for this step.',
      instructions: assistedInstructions(normalizedOperation, folder),
      knownFiles: fs.readdirSync(folder).map(name => fileFingerprint(path.join(folder, name))),
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString()
    };
    writeJson(this.assistedStateFile(active), state);
    return state;
  }

  async launchAssisted(operation, payload = {}, reason = null) {
    const state = this.prepareAssisted(operation, payload, reason);
    const gui = this.resolveGuiExecutable();
    if (state.device) {
      await this.releasePort({ port: state.device, operation: state.operation });
      await sleep(100);
      const lock = await this.probePortLock({ port: state.device, operation: state.operation });
      if (lock?.locked || lock?.available === false) {
        state.status = 'blocked'; state.stopCode = 'adapter-locked'; state.stopMessage = `${state.device} is still locked. Close the program using it before opening PCM Hammer.`;
        writeJson(this.assistedStateFile(), state); return state;
      }
    }
    if (gui) {
      try { const child = spawn(gui, [], { detached: true, windowsHide: false, cwd: path.dirname(gui), stdio: 'ignore' }); child.unref(); state.guiExecutable = gui; state.guiLaunchedAt = new Date().toISOString(); }
      catch (error) { state.launchWarning = error.message; }
    } else state.launchWarning = 'The normal PcmHammer.exe was not found. Open it manually.';
    state.updatedAt = new Date().toISOString(); writeJson(this.assistedStateFile(), state);
    this.watchAssisted(state);
    this.appendActivity('pcmhammer-assisted-started', { projectId: state.projectId, operation: state.operation, folder: state.folder, reason: state.reason });
    return state;
  }

  watchAssisted(state) {
    if (!state?.folder || this.assistedWatchers.has(state.projectId)) return;
    let timer = null;
    try {
      const watcher = fs.watch(state.folder, () => {
        clearTimeout(timer); timer = setTimeout(() => this.scanAssisted().catch(() => {}), 350);
      });
      watcher.on('error', () => {});
      this.assistedWatchers.set(state.projectId, watcher);
    } catch {}
  }
  stopAssistedWatcher(projectId) {
    const watcher = this.assistedWatchers.get(projectId); if (watcher) { try { watcher.close(); } catch {} this.assistedWatchers.delete(projectId); }
  }

  async importAssistedEvidence(files = [], payload = {}) {
    const active = this.getActiveProject();
    if (!active) throw new FlashStopError('no-active-project', 'Create or activate a project first.');
    const state = readJson(this.assistedStateFile(active), null) || this.prepareAssisted(payload.operation || 'readProperties', payload);
    const candidates = uniqueFiles(files).filter(file => fs.existsSync(file) && fs.statSync(file).isFile());
    if (!candidates.length) return { ...state, imported: [] };
    const imported = []; const logs = [];
    for (const file of candidates) {
      const ext = path.extname(file).toLowerCase();
      if (ext === '.bin') {
        const validation = validateP01ReadFile(file, { success: true });
        if (!validation.valid) { imported.push({ file, type: 'read', accepted: false, code: validation.code, message: validation.message }); continue; }
        const session = { id: `${Date.now()}-assisted-read`, operation: 'read', state: 'complete', device: state.device, proofSource: 'PCM Hammer WinForms assisted full read', result: { success: true }, assisted: true };
        try { await this.onReadComplete(file, validation, session); await this.onSessionComplete(session); imported.push({ file, type: 'read', accepted: true, sha256: validation.sha256, size: validation.size }); }
        catch (error) { imported.push({ file, type: 'read', accepted: false, code: 'read-import-failed', message: error.message }); }
      } else if (['.txt', '.log'].includes(ext)) logs.push({ file, text: fs.readFileSync(file, 'utf8') });
    }
    for (const log of logs) {
      const identity = parseIdentityText(log.text);
      const usefulIdentity = identity.os || identity.hardwareId || identity.serviceNumber || identity.controller;
      if (usefulIdentity) {
        const session = { id: `${Date.now()}-assisted-properties`, operation: 'readProperties', state: 'complete', device: state.device, proofSource: log.file, source: 'PCM Hammer WinForms Read Properties', assisted: true };
        try { await this.onIdentifyComplete(identity, session); await this.onSessionComplete(session); imported.push({ file: log.file, type: 'read-properties', accepted: true, identity }); }
        catch (error) { imported.push({ file: log.file, type: 'read-properties', accepted: false, code: 'identity-import-failed', message: error.message }); }
      }
      const testResult = classifyPcmHammerResult('testWrite', log.text, 0);
      if (testResult.testWritePassed && state.input && fs.existsSync(state.input)) {
        const session = { id: `${Date.now()}-assisted-test-write`, operation: 'testWrite', input: state.input, state: 'complete', testWritePassed: true, verified: true, device: state.device, proofSource: log.file, sessionLog: log.file, result: testResult, assisted: true };
        try { await this.onSessionComplete(session); imported.push({ file: log.file, type: 'test-write', accepted: true, input: state.input }); }
        catch (error) { imported.push({ file: log.file, type: 'test-write', accepted: false, code: 'test-write-import-failed', message: error.message }); }
      }
    }
    const accepted = imported.filter(item => item.accepted);
    state.imported = [...(state.imported || []), ...accepted.map(item => ({ ...item, importedAt: new Date().toISOString() }))].slice(-50);
    state.knownFiles = [...new Set([...(state.knownFiles || []), ...candidates.map(fileFingerprint)])];
    state.updatedAt = new Date().toISOString();
    if (accepted.length) state.status = 'evidence-imported';
    writeJson(this.assistedStateFile(active), state);
    return { ...state, imported };
  }

  async scanAssisted() {
    const active = this.getActiveProject();
    if (!active) return null;
    const state = readJson(this.assistedStateFile(active), null);
    if (!state?.folder || !fs.existsSync(state.folder)) return state;
    const known = new Set(state.knownFiles || []);
    const files = fs.readdirSync(state.folder).map(name => path.join(state.folder, name)).filter(file => {
      try { return fs.statSync(file).isFile() && !known.has(fileFingerprint(file)); } catch { return false; }
    });
    if (!files.length) { this.watchAssisted(state); return { ...state, imported: [] }; }
    return this.importAssistedEvidence(files, { operation: state.operation, input: state.input });
  }
}

module.exports = {
  FlashManager, FlashStopError, inferTemplates, expandTemplate, parseProgress, parseIdentityText,
  parseBackendIdentity, classifyPcmHammerResult, validateP01ReadFile, normalizeOperation, P01_BIN_SIZE
};
